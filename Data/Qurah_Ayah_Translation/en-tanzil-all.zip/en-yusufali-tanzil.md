<!--
Quran Translation
Name: Yusuf Ali
Translator: Abdullah Yusuf Ali
Language: English
ID: en.yusufali
Last Update: May 10, 2013
Source: Tanzil.net
-->

# 1

In the name of Allah, Most Gracious, Most Merciful.

# 2

Praise be to Allah, the Cherisher and Sustainer of the worlds;

# 3

Most Gracious, Most Merciful;

# 4

Master of the Day of Judgment.

# 5

Thee do we worship, and Thine aid we seek.

# 6

Show us the straight way,

# 7

The way of those on whom Thou hast bestowed Thy Grace, those whose (portion) is not wrath, and who go not astray.

# 8

A. L. M.

# 9

This is the Book; in it is guidance sure, without doubt, to those who fear Allah;

# 10

Who believe in the Unseen, are steadfast in prayer, and spend out of what We have provided for them;

# 11

And who believe in the Revelation sent to thee, and sent before thy time, and (in their hearts) have the assurance of the Hereafter.

# 12

They are on (true) guidance, from their Lord, and it is these who will prosper.

# 13

As to those who reject Faith, it is the same to them whether thou warn them or do not warn them; they will not believe.

# 14

Allah hath set a seal on their hearts and on their hearing, and on their eyes is a veil; great is the penalty they (incur).

# 15

Of the people there are some who say: "We believe in Allah and the Last Day;" but they do not (really) believe.

# 16

Fain would they deceive Allah and those who believe, but they only deceive themselves, and realise (it) not!

# 17

In their hearts is a disease; and Allah has increased their disease: And grievous is the penalty they (incur), because they are false (to themselves).

# 18

When it is said to them: "Make not mischief on the earth," they say: "Why, we only Want to make peace!"

# 19

Of a surety, they are the ones who make mischief, but they realise (it) not.

# 20

When it is said to them: "Believe as the others believe:" They say: "Shall we believe as the fools believe?" Nay, of a surety they are the fools, but they do not know.

# 21

When they meet those who believe, they say: "We believe;" but when they are alone with their evil ones, they say: "We are really with you: We (were) only jesting."

# 22

Allah will throw back their mockery on them, and give them rope in their trespasses; so they will wander like blind ones (To and fro).

# 23

These are they who have bartered Guidance for error: But their traffic is profitless, and they have lost true direction,

# 24

Their similitude is that of a man who kindled a fire; when it lighted all around him, Allah took away their light and left them in utter darkness. So they could not see.

# 25

Deaf, dumb, and blind, they will not return (to the path).

# 26

Or (another similitude) is that of a rain-laden cloud from the sky: In it are zones of darkness, and thunder and lightning: They press their fingers in their ears to keep out the stunning thunder-clap, the while they are in terror of death. But Allah is ever round the rejecters of Faith!

# 27

The lightning all but snatches away their sight; every time the light (Helps) them, they walk therein, and when the darkness grows on them, they stand still. And if Allah willed, He could take away their faculty of hearing and seeing; for Allah hath power over all things.

# 28

O ye people! Adore your Guardian-Lord, who created you and those who came before you, that ye may have the chance to learn righteousness;

# 29

Who has made the earth your couch, and the heavens your canopy; and sent down rain from the heavens; and brought forth therewith Fruits for your sustenance; then set not up rivals unto Allah when ye know (the truth).

# 30

And if ye are in doubt as to what We have revealed from time to time to Our servant, then produce a Sura like thereunto; and call your witnesses or helpers (If there are any) besides Allah, if your (doubts) are true.

# 31

But if ye cannot- and of a surety ye cannot- then fear the Fire whose fuel is men and stones,- which is prepared for those who reject Faith.

# 32

But give glad tidings to those who believe and work righteousness, that their portion is Gardens, beneath which rivers flow. Every time they are fed with fruits therefrom, they say: "Why, this is what we were fed with before," for they are given things in similitude; and they have therein companions pure (and holy); and they abide therein (for ever).

# 33

Allah disdains not to use the similitude of things, lowest as well as highest. Those who believe know that it is truth from their Lord; but those who reject Faith say: "What means Allah by this similitude?" By it He causes many to stray, and many He leads into the right path; but He causes not to stray, except those who forsake (the path),-

# 34

Those who break Allah's Covenant after it is ratified, and who sunder what Allah Has ordered to be joined, and do mischief on earth: These cause loss (only) to themselves.

# 35

How can ye reject the faith in Allah?- seeing that ye were without life, and He gave you life; then will He cause you to die, and will again bring you to life; and again to Him will ye return.

# 36

It is He Who hath created for you all things that are on earth; Moreover His design comprehended the heavens, for He gave order and perfection to the seven firmaments; and of all things He hath perfect knowledge.

# 37

Behold, thy Lord said to the angels: "I will create a vicegerent on earth." They said: "Wilt Thou place therein one who will make mischief therein and shed blood?- whilst we do celebrate Thy praises and glorify Thy holy (name)?" He said: "I know what ye know not."

# 38

And He taught Adam the names of all things; then He placed them before the angels, and said: "Tell me the names of these if ye are right."

# 39

They said: "Glory to Thee, of knowledge We have none, save what Thou Hast taught us: In truth it is Thou Who art perfect in knowledge and wisdom."

# 40

He said: "O Adam! Tell them their names." When he had told them, Allah said: "Did I not tell you that I know the secrets of heaven and earth, and I know what ye reveal and what ye conceal?"

# 41

And behold, We said to the angels: "Bow down to Adam" and they bowed down. Not so Iblis: he refused and was haughty: He was of those who reject Faith.

# 42

We said: "O Adam! dwell thou and thy wife in the Garden; and eat of the bountiful things therein as (where and when) ye will; but approach not this tree, or ye run into harm and transgression."

# 43

Then did Satan make them slip from the (garden), and get them out of the state (of felicity) in which they had been. We said: "Get ye down, all (ye people), with enmity between yourselves. On earth will be your dwelling-place and your means of livelihood - for a time."

# 44

Then learnt Adam from his Lord words of inspiration, and his Lord Turned towards him; for He is Oft-Returning, Most Merciful.

# 45

We said: "Get ye down all from here; and if, as is sure, there comes to you Guidance from me, whosoever follows My guidance, on them shall be no fear, nor shall they grieve.

# 46

"But those who reject Faith and belie Our Signs, they shall be companions of the Fire; they shall abide therein."

# 47

O Children of Israel! call to mind the (special) favour which I bestowed upon you, and fulfil your covenant with Me as I fulfil My Covenant with you, and fear none but Me.

# 48

And believe in what I reveal, confirming the revelation which is with you, and be not the first to reject Faith therein, nor sell My Signs for a small price; and fear Me, and Me alone.

# 49

And cover not Truth with falsehood, nor conceal the Truth when ye know (what it is).

# 50

And be steadfast in prayer; practise regular charity; and bow down your heads with those who bow down (in worship).

# 51

Do ye enjoin right conduct on the people, and forget (To practise it) yourselves, and yet ye study the Scripture? Will ye not understand?

# 52

Nay, seek (Allah's) help with patient perseverance and prayer: It is indeed hard, except to those who bring a lowly spirit,-

# 53

Who bear in mind the certainty that they are to meet their Lord, and that they are to return to Him.

# 54

Children of Israel! call to mind the (special) favour which I bestowed upon you, and that I preferred you to all other (for My Message).

# 55

Then guard yourselves against a day when one soul shall not avail another nor shall intercession be accepted for her, nor shall compensation be taken from her, nor shall anyone be helped (from outside).

# 56

And remember, We delivered you from the people of Pharaoh: They set you hard tasks and punishments, slaughtered your sons and let your women-folk live; therein was a tremendous trial from your Lord.

# 57

And remember We divided the sea for you and saved you and drowned Pharaoh's people within your very sight.

# 58

And remember We appointed forty nights for Moses, and in his absence ye took the calf (for worship), and ye did grievous wrong.

# 59

Even then We did forgive you; there was a chance for you to be grateful.

# 60

And remember We gave Moses the Scripture and the Criterion (Between right and wrong): There was a chance for you to be guided aright.

# 61

And remember Moses said to his people: "O my people! Ye have indeed wronged yourselves by your worship of the calf: So turn (in repentance) to your Maker, and slay yourselves (the wrong-doers); that will be better for you in the sight of your Maker." Then He turned towards you (in forgiveness): For He is Oft-Returning, Most Merciful.

# 62

And remember ye said: "O Moses! We shall never believe in thee until we see Allah manifestly," but ye were dazed with thunder and lighting even as ye looked on.

# 63

Then We raised you up after your death: Ye had the chance to be grateful.

# 64

And We gave you the shade of clouds and sent down to you Manna and quails, saying: "Eat of the good things We have provided for you:" (But they rebelled); to us they did no harm, but they harmed their own souls.

# 65

And remember We said: "Enter this town, and eat of the plenty therein as ye wish; but enter the gate with humility, in posture and in words, and We shall forgive you your faults and increase (the portion of) those who do good."

# 66

But the transgressors changed the word from that which had been given them; so We sent on the transgressors a plague from heaven, for that they infringed (Our command) repeatedly.

# 67

And remember Moses prayed for water for his people; We said: "Strike the rock with thy staff." Then gushed forth therefrom twelve springs. Each group knew its own place for water. So eat and drink of the sustenance provided by Allah, and do no evil nor mischief on the (face of the) earth.

# 68

And remember ye said: "O Moses! we cannot endure one kind of food (always); so beseech thy Lord for us to produce for us of what the earth groweth, -its pot-herbs, and cucumbers, Its garlic, lentils, and onions." He said: "Will ye exchange the better for the worse? Go ye down to any town, and ye shall find what ye want!" They were covered with humiliation and misery; they drew on themselves the wrath of Allah. This because they went on rejecting the Signs of Allah and slaying His Messengers without just cause. This because they rebelled and went on transgressing.

# 69

Those who believe (in the Qur'an), and those who follow the Jewish (scriptures), and the Christians and the Sabians,- any who believe in Allah and the Last Day, and work righteousness, shall have their reward with their Lord; on them shall be no fear, nor shall they grieve.

# 70

And remember We took your covenant and We raised above you (The towering height) of Mount (Sinai): (Saying): "Hold firmly to what We have given you and bring (ever) to remembrance what is therein: Perchance ye may fear Allah."

# 71

But ye turned back thereafter: Had it not been for the Grace and Mercy of Allah to you, ye had surely been among the lost.

# 72

And well ye knew those amongst you who transgressed in the matter of the Sabbath: We said to them: "Be ye apes, despised and rejected."

# 73

So We made it an example to their own time and to their posterity, and a lesson to those who fear Allah.

# 74

And remember Moses said to his people: "Allah commands that ye sacrifice a heifer." They said: "Makest thou a laughing-stock of us?" He said: "Allah save me from being an ignorant (fool)!"

# 75

They said: "Beseech on our behalf Thy Lord to make plain to us what (heifer) it is!" He said; "He says: The heifer should be neither too old nor too young, but of middling age. Now do what ye are commanded!"

# 76

They said: "Beseech on our behalf Thy Lord to make plain to us Her colour." He said: "He says: A fawn-coloured heifer, pure and rich in tone, the admiration of beholders!"

# 77

They said: "Beseech on our behalf Thy Lord to make plain to us what she is: To us are all heifers alike: We wish indeed for guidance, if Allah wills."

# 78

He said: "He says: A heifer not trained to till the soil or water the fields; sound and without blemish." They said: "Now hast thou brought the truth." Then they offered her in sacrifice, but not with good-will.

# 79

Remember ye slew a man and fell into a dispute among yourselves as to the crime: But Allah was to bring forth what ye did hide.

# 80

So We said: "Strike the (body) with a piece of the (heifer)." Thus Allah bringeth the dead to life and showeth you His Signs: Perchance ye may understand.

# 81

Thenceforth were your hearts hardened: They became like a rock and even worse in hardness. For among rocks there are some from which rivers gush forth; others there are which when split asunder send forth water; and others which sink for fear of Allah. And Allah is not unmindful of what ye do.

# 82

Can ye (o ye men of Faith) entertain the hope that they will believe in you?- Seeing that a party of them heard the Word of Allah, and perverted it knowingly after they understood it.

# 83

Behold! when they meet the men of Faith, they say: "We believe": But when they meet each other in private, they say: "Shall you tell them what Allah hath revealed to you, that they may engage you in argument about it before your Lord?"- Do ye not understand (their aim)?

# 84

Know they not that Allah knoweth what they conceal and what they reveal?

# 85

And there are among them illiterates, who know not the Book, but (see therein their own) desires, and they do nothing but conjecture.

# 86

Then woe to those who write the Book with their own hands, and then say:"This is from Allah," to traffic with it for miserable price!- Woe to them for what their hands do write, and for the gain they make thereby.

# 87

And they say: "The Fire shall not touch us but for a few numbered days:" Say: "Have ye taken a promise from Allah, for He never breaks His promise? or is it that ye say of Allah what ye do not know?"

# 88

Nay, those who seek gain in evil, and are girt round by their sins,- they are companions of the Fire: Therein shall they abide (For ever).

# 89

But those who have faith and work righteousness, they are companions of the Garden: Therein shall they abide (For ever).

# 90

And remember We took a covenant from the Children of Israel (to this effect): Worship none but Allah; treat with kindness your parents and kindred, and orphans and those in need; speak fair to the people; be steadfast in prayer; and practise regular charity. Then did ye turn back, except a few among you, and ye backslide (even now).

# 91

And remember We took your covenant (to this effect): Shed no blood amongst you, nor turn out your own people from your homes: and this ye solemnly ratified, and to this ye can bear witness.

# 92

After this it is ye, the same people, who slay among yourselves, and banish a party of you from their homes; assist (Their enemies) against them, in guilt and rancour; and if they come to you as captives, ye ransom them, though it was not lawful for you to banish them. Then is it only a part of the Book that ye believe in, and do ye reject the rest? but what is the reward for those among you who behave like this but disgrace in this life?- and on the Day of Judgment they shall be consigned to the most grievous penalty. For Allah is not unmindful of what ye do.

# 93

These are the people who buy the life of this world at the price of the Hereafter: their penalty shall not be lightened nor shall they be helped.

# 94

We gave Moses the Book and followed him up with a succession of messengers; We gave Jesus the son of Mary Clear (Signs) and strengthened him with the holy spirit. Is it that whenever there comes to you a messenger with what ye yourselves desire not, ye are puffed up with pride?- Some ye called impostors, and others ye slay!

# 95

They say, "Our hearts are the wrappings (which preserve Allah's Word: we need no more)." Nay, Allah's curse is on them for their blasphemy: Little is it they believe.

# 96

And when there comes to them a Book from Allah, confirming what is with them,- although from of old they had prayed for victory against those without Faith,- when there comes to them that which they (should) have recognised, they refuse to believe in it but the curse of Allah is on those without Faith.

# 97

Miserable is the price for which they have sold their souls, in that they deny (the revelation) which Allah has sent down, in insolent envy that Allah of His Grace should send it to any of His servants He pleases: Thus have they drawn on themselves Wrath upon Wrath. And humiliating is the punishment of those who reject Faith.

# 98

When it is said to them, "Believe in what Allah Hath sent down, "they say, "We believe in what was sent down to us:" yet they reject all besides, even if it be Truth confirming what is with them. Say: "Why then have ye slain the prophets of Allah in times gone by, if ye did indeed believe?"

# 99

There came to you Moses with clear (Signs); yet ye worshipped the calf (Even) after that, and ye did behave wrongfully.

# 100

And remember We took your covenant and We raised above you (the towering height) of Mount (Sinai): (Saying): "Hold firmly to what We have given you, and hearken (to the Law)": They said:" We hear, and we disobey:" And they had to drink into their hearts (of the taint) of the calf because of their Faithlessness. Say: "Vile indeed are the behests of your Faith if ye have any faith!"

# 101

Say: "If the last Home, with Allah, be for you specially, and not for anyone else, then seek ye for death, if ye are sincere."

# 102

But they will never seek for death, on account of the (sins) which their hands have sent on before them. and Allah is well-acquainted with the wrong-doers.

# 103

Thou wilt indeed find them, of all people, most greedy of life,-even more than the idolaters: Each one of them wishes He could be given a life of a thousand years: But the grant of such life will not save him from (due) punishment. For Allah sees well all that they do.

# 104

Say: Whoever is an enemy to Gabriel-for he brings down the (revelation) to thy heart by Allah's will, a confirmation of what went before, and guidance and glad tidings for those who believe,-

# 105

Whoever is an enemy to Allah and His angels and messengers, to Gabriel and Michael,- Lo! Allah is an enemy to those who reject Faith.

# 106

We have sent down to thee Manifest Signs (ayat); and none reject them but those who are perverse.

# 107

Is it not (the case) that every time they make a covenant, some party among them throw it aside?- Nay, Most of them are faithless.

# 108

And when there came to them a messenger from Allah, confirming what was with them, a party of the people of the Book threw away the Book of Allah behind their backs, as if (it had been something) they did not know!

# 109

They followed what the evil ones gave out (falsely) against the power of Solomon: the blasphemers Were, not Solomon, but the evil ones, teaching men Magic, and such things as came down at babylon to the angels Harut and Marut. But neither of these taught anyone (Such things) without saying: "We are only for trial; so do not blaspheme." They learned from them the means to sow discord between man and wife. But they could not thus harm anyone except by Allah's permission. And they learned what harmed them, not what profited them. And they knew that the buyers of (magic) would have no share in the happiness of the Hereafter. And vile was the price for which they did sell their souls, if they but knew!

# 110

If they had kept their Faith and guarded themselves from evil, far better had been the reward from their Lord, if they but knew!

# 111

O ye of Faith! Say not (to the Messenger) words of ambiguous import, but words of respect; and hearken (to him): To those without Faith is a grievous punishment.

# 112

It is never the wish of those without Faith among the People of the Book, nor of the Pagans, that anything good should come down to you from your Lord. But Allah will choose for His special Mercy whom He will - for Allah is Lord of grace abounding.

# 113

None of Our revelations do We abrogate or cause to be forgotten, but We substitute something better or similar: Knowest thou not that Allah Hath power over all things?

# 114

Knowest thou not that to Allah belongeth the dominion of the heavens and the earth? And besides Him ye have neither patron nor helper.

# 115

Would ye question your Messenger as Moses was questioned of old? but whoever changeth from Faith to Unbelief, Hath strayed without doubt from the even way.

# 116

Quite a number of the People of the Book wish they could Turn you (people) back to infidelity after ye have believed, from selfish envy, after the Truth hath become Manifest unto them: But forgive and overlook, Till Allah accomplish His purpose; for Allah Hath power over all things.

# 117

And be steadfast in prayer and regular in charity: And whatever good ye send forth for your souls before you, ye shall find it with Allah: for Allah sees Well all that ye do.

# 118

And they say: "None shall enter Paradise unless he be a Jew or a Christian." Those are their (vain) desires. Say: "Produce your proof if ye are truthful."

# 119

Nay,-whoever submits His whole self to Allah and is a doer of good,- He will get his reward with his Lord; on such shall be no fear, nor shall they grieve.

# 120

The Jews say: "The Christians have naught (to stand) upon; and the Christians say: "The Jews have naught (To stand) upon." Yet they (Profess to) study the (same) Book. Like unto their word is what those say who know not; but Allah will judge between them in their quarrel on the Day of Judgment.

# 121

And who is more unjust than he who forbids that in places for the worship of Allah, Allah's name should be celebrated?-whose zeal is (in fact) to ruin them? It was not fitting that such should themselves enter them except in fear. For them there is nothing but disgrace in this world, and in the world to come, an exceeding torment.

# 122

To Allah belong the east and the West: Whithersoever ye turn, there is the presence of Allah. For Allah is all-Pervading, all-Knowing.

# 123

They say: "Allah hath begotten a son": Glory be to Him.-Nay, to Him belongs all that is in the heavens and on earth: everything renders worship to Him.

# 124

To Him is due the primal origin of the heavens and the earth: When He decreeth a matter, He saith to it: "Be," and it is.

# 125

Say those without knowledge: "Why speaketh not Allah unto us? or why cometh not unto us a Sign?" So said the people before them words of similar import. Their hearts are alike. We have indeed made clear the Signs unto any people who hold firmly to Faith (in their hearts).

# 126

Verily We have sent thee in truth as a bearer of glad tidings and a warner: But of thee no question shall be asked of the Companions of the Blazing Fire.

# 127

Never will the Jews or the Christians be satisfied with thee unless thou follow their form of religion. Say: "The Guidance of Allah,-that is the (only) Guidance." Wert thou to follow their desires after the knowledge which hath reached thee, then wouldst thou find neither Protector nor helper against Allah.

# 128

Those to whom We have sent the Book study it as it should be studied: They are the ones that believe therein: Those who reject faith therein,- the loss is their own.

# 129

O Children of Israel! call to mind the special favour which I bestowed upon you, and that I preferred you to all others (for My Message).

# 130

Then guard yourselves against a Day when one soul shall not avail another, nor shall compensation be accepted from her nor shall intercession profit her nor shall anyone be helped (from outside).

# 131

And remember that Abraham was tried by his Lord with certain commands, which he fulfilled: He said: "I will make thee an Imam to the Nations." He pleaded: "And also (Imams) from my offspring!" He answered: "But My Promise is not within the reach of evil-doers."

# 132

Remember We made the House a place of assembly for men and a place of safety; and take ye the station of Abraham as a place of prayer; and We covenanted with Abraham and Isma'il, that they should sanctify My House for those who compass it round, or use it as a retreat, or bow, or prostrate themselves (therein in prayer).

# 133

And remember Abraham said: "My Lord, make this a City of Peace, and feed its people with fruits,-such of them as believe in Allah and the Last Day." He said: "(Yea), and such as reject Faith,-for a while will I grant them their pleasure, but will soon drive them to the torment of Fire,- an evil destination (indeed)!"

# 134

And remember Abraham and Isma'il raised the foundations of the House (With this prayer): "Our Lord! Accept (this service) from us: For Thou art the All-Hearing, the All-knowing.

# 135

"Our Lord! make of us Muslims, bowing to Thy (Will), and of our progeny a people Muslim, bowing to Thy (will); and show us our place for the celebration of (due) rites; and turn unto us (in Mercy); for Thou art the Oft-Returning, Most Merciful.

# 136

"Our Lord! send amongst them a Messenger of their own, who shall rehearse Thy Signs to them and instruct them in scripture and wisdom, and sanctify them: For Thou art the Exalted in Might, the Wise."

# 137

And who turns away from the religion of Abraham but such as debase their souls with folly? Him We chose and rendered pure in this world: And he will be in the Hereafter in the ranks of the Righteous.

# 138

Behold! his Lord said to him: "Bow (thy will to Me):" He said: "I bow (my will) to the Lord and Cherisher of the Universe."

# 139

And this was the legacy that Abraham left to his sons, and so did Jacob; "Oh my sons! Allah hath chosen the Faith for you; then die not except in the Faith of Islam."

# 140

Were ye witnesses when death appeared before Jacob? Behold, he said to his sons: "What will ye worship after me?" They said: "We shall worship Thy god and the god of thy fathers, of Abraham, Isma'il and Isaac,- the one (True) Allah: To Him we bow (in Islam)."

# 141

That was a people that hath passed away. They shall reap the fruit of what they did, and ye of what ye do! Of their merits there is no question in your case!

# 142

They say: "Become Jews or Christians if ye would be guided (To salvation)." Say thou: "Nay! (I would rather) the Religion of Abraham the True, and he joined not gods with Allah."

# 143

Say ye: "We believe in Allah, and the revelation given to us, and to Abraham, Isma'il, Isaac, Jacob, and the Tribes, and that given to Moses and Jesus, and that given to (all) prophets from their Lord: We make no difference between one and another of them: And we bow to Allah (in Islam)."

# 144

So if they believe as ye believe, they are indeed on the right path; but if they turn back, it is they who are in schism; but Allah will suffice thee as against them, and He is the All-Hearing, the All-Knowing.

# 145

(Our religion is) the Baptism of Allah: And who can baptize better than Allah? And it is He Whom we worship.

# 146

Say: Will ye dispute with us about Allah, seeing that He is our Lord and your Lord; that we are responsible for our doings and ye for yours; and that We are sincere (in our faith) in Him?

# 147

Or do ye say that Abraham, Isma'il Isaac, Jacob and the Tribes were Jews or Christians? Say: Do ye know better than Allah? Ah! who is more unjust than those who conceal the testimony they have from Allah? but Allah is not unmindful of what ye do!

# 148

That was a people that hath passed away. They shall reap the fruit of what they did, and ye of what ye do! Of their merits there is no question in your case:

# 149

The fools among the people will say: "What hath turned them from the Qibla to which they were used?" Say: To Allah belong both east and West: He guideth whom He will to a Way that is straight.

# 150

Thus, have We made of you an Ummat justly balanced, that ye might be witnesses over the nations, and the Messenger a witness over yourselves; and We appointed the Qibla to which thou wast used, only to test those who followed the Messenger from those who would turn on their heels (From the Faith). Indeed it was (A change) momentous, except to those guided by Allah. And never would Allah Make your faith of no effect. For Allah is to all people Most surely full of kindness, Most Merciful.

# 151

We see the turning of thy face (for guidance to the heavens: now Shall We turn thee to a Qibla that shall please thee. Turn then Thy face in the direction of the sacred Mosque: Wherever ye are, turn your faces in that direction. The people of the Book know well that that is the truth from their Lord. Nor is Allah unmindful of what they do.

# 152

Even if thou wert to bring to the people of the Book all the Signs (together), they would not follow Thy Qibla; nor art thou going to follow their Qibla; nor indeed will they follow each other's Qibla. If thou after the knowledge hath reached thee, Wert to follow their (vain) desires,-then wert thou Indeed (clearly) in the wrong.

# 153

The people of the Book know this as they know their own sons; but some of them conceal the truth which they themselves know.

# 154

The Truth is from thy Lord; so be not at all in doubt.

# 155

To each is a goal to which Allah turns him; then strive together (as in a race) Towards all that is good. Wheresoever ye are, Allah will bring you Together. For Allah Hath power over all things.

# 156

From whencesoever Thou startest forth, turn Thy face in the direction of the sacred Mosque; that is indeed the truth from the Lord. And Allah is not unmindful of what ye do.

# 157

So from whencesoever Thou startest forth, turn Thy face in the direction of the sacred Mosque; and wheresoever ye are, Turn your face thither: that there be no ground of dispute against you among the people, except those of them that are bent on wickedness; so fear them not, but fear Me; and that I may complete My favours on you, and ye May (consent to) be guided;

# 158

A similar (favour have ye already received) in that We have sent among you a Messenger of your own, rehearsing to you Our Signs, and sanctifying you, and instructing you in Scripture and Wisdom, and in new knowledge.

# 159

Then do ye remember Me; I will remember you. Be grateful to Me, and reject not Faith.

# 160

O ye who believe! seek help with patient perseverance and prayer; for Allah is with those who patiently persevere.

# 161

And say not of those who are slain in the way of Allah: "They are dead." Nay, they are living, though ye perceive (it) not.

# 162

Be sure we shall test you with something of fear and hunger, some loss in goods or lives or the fruits (of your toil), but give glad tidings to those who patiently persevere,

# 163

Who say, when afflicted with calamity: "To Allah We belong, and to Him is our return":-

# 164

They are those on whom (Descend) blessings from Allah, and Mercy, and they are the ones that receive guidance.

# 165

Behold! Safa and Marwa are among the Symbols of Allah. So if those who visit the House in the Season or at other times, should compass them round, it is no sin in them. And if any one obeyeth his own impulse to good,- be sure that Allah is He Who recogniseth and knoweth.

# 166

Those who conceal the clear (Signs) We have sent down, and the Guidance, after We have made it clear for the people in the Book,-on them shall be Allah's curse, and the curse of those entitled to curse,-

# 167

Except those who repent and make amends and openly declare (the Truth): To them I turn; for I am Oft-returning, Most Merciful.

# 168

Those who reject Faith, and die rejecting,- on them is Allah's curse, and the curse of angels, and of all mankind;

# 169

They will abide therein: Their penalty will not be lightened, nor will respite be their (lot).

# 170

And your Allah is One Allah: There is no god but He, Most Gracious, Most Merciful.

# 171

Behold! in the creation of the heavens and the earth; in the alternation of the night and the day; in the sailing of the ships through the ocean for the profit of mankind; in the rain which Allah Sends down from the skies, and the life which He gives therewith to an earth that is dead; in the beasts of all kinds that He scatters through the earth; in the change of the winds, and the clouds which they Trail like their slaves between the sky and the earth;- (Here) indeed are Signs for a people that are wise.

# 172

Yet there are men who take (for worship) others besides Allah, as equal (with Allah): They love them as they should love Allah. But those of Faith are overflowing in their love for Allah. If only the unrighteous could see, behold, they would see the penalty: that to Allah belongs all power, and Allah will strongly enforce the penalty.

# 173

Then would those who are followed clear themselves of those who follow (them): They would see the penalty, and all relations between them would be cut off.

# 174

And those who followed would say: "If only We had one more chance, We would clear ourselves of them, as they have cleared themselves of us." Thus will Allah show them (The fruits of) their deeds as (nothing but) regrets. Nor will there be a way for them out of the Fire.

# 175

O ye people! Eat of what is on earth, Lawful and good; and do not follow the footsteps of the evil one, for he is to you an avowed enemy.

# 176

For he commands you what is evil and shameful, and that ye should say of Allah that of which ye have no knowledge.

# 177

When it is said to them: "Follow what Allah hath revealed:" They say: "Nay! we shall follow the ways of our fathers." What! even though their fathers Were void of wisdom and guidance?

# 178

The parable of those who reject Faith is as if one were to shout Like a goat-herd, to things that listen to nothing but calls and cries: Deaf, dumb, and blind, they are void of wisdom.

# 179

O ye who believe! Eat of the good things that We have provided for you, and be grateful to Allah, if it is Him ye worship.

# 180

He hath only forbidden you dead meat, and blood, and the flesh of swine, and that on which any other name hath been invoked besides that of Allah. But if one is forced by necessity, without wilful disobedience, nor transgressing due limits,- then is he guiltless. For Allah is Oft-forgiving Most Merciful.

# 181

Those who conceal Allah's revelations in the Book, and purchase for them a miserable profit,- they swallow into themselves naught but Fire; Allah will not address them on the Day of Resurrection. Nor purify them: Grievous will be their penalty.

# 182

They are the ones who buy Error in place of Guidance and Torment in place of Forgiveness. Ah! what boldness (They show) for the Fire!

# 183

(Their doom is) because Allah sent down the Book in truth but those who seek causes of dispute in the Book are in a schism Far (from the purpose).

# 184

It is not righteousness that ye turn your faces Towards east or West; but it is righteousness- to believe in Allah and the Last Day, and the Angels, and the Book, and the Messengers; to spend of your substance, out of love for Him, for your kin, for orphans, for the needy, for the wayfarer, for those who ask, and for the ransom of slaves; to be steadfast in prayer, and practice regular charity; to fulfil the contracts which ye have made; and to be firm and patient, in pain (or suffering) and adversity, and throughout all periods of panic. Such are the people of truth, the Allah-fearing.

# 185

O ye who believe! the law of equality is prescribed to you in cases of murder: the free for the free, the slave for the slave, the woman for the woman. But if any remission is made by the brother of the slain, then grant any reasonable demand, and compensate him with handsome gratitude, this is a concession and a Mercy from your Lord. After this whoever exceeds the limits shall be in grave penalty.

# 186

In the Law of Equality there is (saving of) Life to you, o ye men of understanding; that ye may restrain yourselves.

# 187

It is prescribed, when death approaches any of you, if he leave any goods that he make a bequest to parents and next of kin, according to reasonable usage; this is due from the Allah-fearing.

# 188

If anyone changes the bequest after hearing it, the guilt shall be on those who make the change. For Allah hears and knows (All things).

# 189

But if anyone fears partiality or wrong-doing on the part of the testator, and makes peace between (The parties concerned), there is no wrong in him: For Allah is Oft-forgiving, Most Merciful.

# 190

O ye who believe! Fasting is prescribed to you as it was prescribed to those before you, that ye may (learn) self-restraint,-

# 191

(Fasting) for a fixed number of days; but if any of you is ill, or on a journey, the prescribed number (Should be made up) from days later. For those who can do it (With hardship), is a ransom, the feeding of one that is indigent. But he that will give more, of his own free will,- it is better for him. And it is better for you that ye fast, if ye only knew.

# 192

Ramadhan is the (month) in which was sent down the Qur'an, as a guide to mankind, also clear (Signs) for guidance and judgment (Between right and wrong). So every one of you who is present (at his home) during that month should spend it in fasting, but if any one is ill, or on a journey, the prescribed period (Should be made up) by days later. Allah intends every facility for you; He does not want to put to difficulties. (He wants you) to complete the prescribed period, and to glorify Him in that He has guided you; and perchance ye shall be grateful.

# 193

When My servants ask thee concerning Me, I am indeed close (to them): I listen to the prayer of every suppliant when he calleth on Me: Let them also, with a will, Listen to My call, and believe in Me: That they may walk in the right way.

# 194

Permitted to you, on the night of the fasts, is the approach to your wives. They are your garments and ye are their garments. Allah knoweth what ye used to do secretly among yourselves; but He turned to you and forgave you; so now associate with them, and seek what Allah Hath ordained for you, and eat and drink, until the white thread of dawn appear to you distinct from its black thread; then complete your fast Till the night appears; but do not associate with your wives while ye are in retreat in the mosques. Those are Limits (set by) Allah: Approach not nigh thereto. Thus doth Allah make clear His Signs to men: that they may learn self-restraint.

# 195

And do not eat up your property among yourselves for vanities, nor use it as bait for the judges, with intent that ye may eat up wrongfully and knowingly a little of (other) people's property.

# 196

They ask thee concerning the New Moons. Say: They are but signs to mark fixed periods of time in (the affairs of) men, and for Pilgrimage. It is no virtue if ye enter your houses from the back: It is virtue if ye fear Allah. Enter houses through the proper doors: And fear Allah: That ye may prosper.

# 197

Fight in the cause of Allah those who fight you, but do not transgress limits; for Allah loveth not transgressors.

# 198

And slay them wherever ye catch them, and turn them out from where they have Turned you out; for tumult and oppression are worse than slaughter; but fight them not at the Sacred Mosque, unless they (first) fight you there; but if they fight you, slay them. Such is the reward of those who suppress faith.

# 199

But if they cease, Allah is Oft-forgiving, Most Merciful.

# 200

And fight them on until there is no more Tumult or oppression, and there prevail justice and faith in Allah; but if they cease, Let there be no hostility except to those who practise oppression.

# 201

The prohibited month for the prohibited month,- and so for all things prohibited,- there is the law of equality. If then any one transgresses the prohibition against you, Transgress ye likewise against him. But fear Allah, and know that Allah is with those who restrain themselves.

# 202

And spend of your substance in the cause of Allah, and make not your own hands contribute to (your) destruction; but do good; for Allah loveth those who do good.

# 203

And complete the Hajj or 'umra in the service of Allah. But if ye are prevented (From completing it), send an offering for sacrifice, such as ye may find, and do not shave your heads until the offering reaches the place of sacrifice. And if any of you is ill, or has an ailment in his scalp, (Necessitating shaving), (He should) in compensation either fast, or feed the poor, or offer sacrifice; and when ye are in peaceful conditions (again), if any one wishes to continue the 'umra on to the hajj, He must make an offering, such as he can afford, but if he cannot afford it, He should fast three days during the hajj and seven days on his return, Making ten days in all. This is for those whose household is not in (the precincts of) the Sacred Mosque. And fear Allah, and know that Allah Is strict in punishment.

# 204

For Hajj are the months well known. If any one undertakes that duty therein, Let there be no obscenity, nor wickedness, nor wrangling in the Hajj. And whatever good ye do, (be sure) Allah knoweth it. And take a provision (With you) for the journey, but the best of provisions is right conduct. So fear Me, o ye that are wise.

# 205

It is no crime in you if ye seek of the bounty of your Lord (during pilgrimage). Then when ye pour down from (Mount) Arafat, celebrate the praises of Allah at the Sacred Monument, and celebrate His praises as He has directed you, even though, before this, ye went astray.

# 206

Then pass on at a quick pace from the place whence it is usual for the multitude so to do, and ask for Allah's forgiveness. For Allah is Oft-forgiving, Most Merciful.

# 207

So when ye have accomplished your holy rites, celebrate the praises of Allah, as ye used to celebrate the praises of your fathers,- yea, with far more Heart and soul. There are men who say: "Our Lord! Give us (Thy bounties) in this world!" but they will have no portion in the Hereafter.

# 208

And there are men who say: "Our Lord! Give us good in this world and good in the Hereafter, and defend us from the torment of the Fire!"

# 209

To these will be allotted what they have earned; and Allah is quick in account.

# 210

Celebrate the praises of Allah during the Appointed Days. But if any one hastens to leave in two days, there is no blame on him, and if any one stays on, there is no blame on him, if his aim is to do right. Then fear Allah, and know that ye will surely be gathered unto Him.

# 211

There is the type of man whose speech about this world's life May dazzle thee, and he calls Allah to witness about what is in his heart; yet is he the most contentious of enemies.

# 212

When he turns his back, His aim everywhere is to spread mischief through the earth and destroy crops and cattle. But Allah loveth not mischief.

# 213

When it is said to him, "Fear Allah", He is led by arrogance to (more) crime. Enough for him is Hell;-An evil bed indeed (To lie on)!

# 214

And there is the type of man who gives his life to earn the pleasure of Allah: And Allah is full of kindness to (His) devotees.

# 215

O ye who believe! Enter into Islam whole-heartedly; and follow not the footsteps of the evil one; for he is to you an avowed enemy.

# 216

If ye backslide after the clear (Signs) have come to you, then know that Allah is Exalted in Power, Wise.

# 217

Will they wait until Allah comes to them in canopies of clouds, with angels (in His train) and the question is (thus) settled? but to Allah do all questions go back (for decision).

# 218

Ask the Children of Israel how many clear (Signs) We have sent them. But if any one, after Allah's favour has come to him, substitutes (something else), Allah is strict in punishment.

# 219

The life of this world is alluring to those who reject faith, and they scoff at those who believe. But the righteous will be above them on the Day of Resurrection; for Allah bestows His abundance without measure on whom He will.

# 220

Mankind was one single nation, and Allah sent Messengers with glad tidings and warnings; and with them He sent the Book in truth, to judge between people in matters wherein they differed; but the People of the Book, after the clear Signs came to them, did not differ among themselves, except through selfish contumacy. Allah by His Grace Guided the believers to the Truth, concerning that wherein they differed. For Allah guided whom He will to a path that is straight.

# 221

Or do ye think that ye shall enter the Garden (of bliss) without such (trials) as came to those who passed away before you? they encountered suffering and adversity, and were so shaken in spirit that even the Messenger and those of faith who were with him cried: "When (will come) the help of Allah?" Ah! Verily, the help of Allah is (always) near!

# 222

They ask thee what they should spend (In charity). Say: Whatever ye spend that is good, is for parents and kindred and orphans and those in want and for wayfarers. And whatever ye do that is good, -Allah knoweth it well.

# 223

Fighting is prescribed for you, and ye dislike it. But it is possible that ye dislike a thing which is good for you, and that ye love a thing which is bad for you. But Allah knoweth, and ye know not.

# 224

They ask thee concerning fighting in the Prohibited Month. Say: "Fighting therein is a grave (offence); but graver is it in the sight of Allah to prevent access to the path of Allah, to deny Him, to prevent access to the Sacred Mosque, and drive out its members." Tumult and oppression are worse than slaughter. Nor will they cease fighting you until they turn you back from your faith if they can. And if any of you Turn back from their faith and die in unbelief, their works will bear no fruit in this life and in the Hereafter; they will be companions of the Fire and will abide therein.

# 225

Those who believed and those who suffered exile and fought (and strove and struggled) in the path of Allah,- they have the hope of the Mercy of Allah: And Allah is Oft-forgiving, Most Merciful.

# 226

They ask thee concerning wine and gambling. Say: "In them is great sin, and some profit, for men; but the sin is greater than the profit." They ask thee how much they are to spend; Say: "What is beyond your needs." Thus doth Allah Make clear to you His Signs: In order that ye may consider-

# 227

(Their bearings) on this life and the Hereafter. They ask thee concerning orphans. Say: "The best thing to do is what is for their good; if ye mix their affairs with yours, they are your brethren; but Allah knows the man who means mischief from the man who means good. And if Allah had wished, He could have put you into difficulties: He is indeed Exalted in Power, Wise."

# 228

Do not marry unbelieving women (idolaters), until they believe: A slave woman who believes is better than an unbelieving woman, even though she allures you. Nor marry (your girls) to unbelievers until they believe: A man slave who believes is better than an unbeliever, even though he allures you. Unbelievers do (but) beckon you to the Fire. But Allah beckons by His Grace to the Garden (of bliss) and forgiveness, and makes His Signs clear to mankind: That they may celebrate His praise.

# 229

They ask thee concerning women's courses. Say: They are a hurt and a pollution: So keep away from women in their courses, and do not approach them until they are clean. But when they have purified themselves, ye may approach them in any manner, time, or place ordained for you by Allah. For Allah loves those who turn to Him constantly and He loves those who keep themselves pure and clean.

# 230

Your wives are as a tilth unto you; so approach your tilth when or how ye will; but do some good act for your souls beforehand; and fear Allah. And know that ye are to meet Him (in the Hereafter), and give (these) good tidings to those who believe.

# 231

And make not Allah's (name) an excuse in your oaths against doing good, or acting rightly, or making peace between persons; for Allah is One Who heareth and knoweth all things.

# 232

Allah will not call you to account for thoughtlessness in your oaths, but for the intention in your hearts; and He is Oft-forgiving, Most Forbearing.

# 233

For those who take an oath for abstention from their wives, a waiting for four months is ordained; if then they return, Allah is Oft-forgiving, Most Merciful.

# 234

But if their intention is firm for divorce, Allah heareth and knoweth all things.

# 235

Divorced women shall wait concerning themselves for three monthly periods. Nor is it lawful for them to hide what Allah Hath created in their wombs, if they have faith in Allah and the Last Day. And their husbands have the better right to take them back in that period, if they wish for reconciliation. And women shall have rights similar to the rights against them, according to what is equitable; but men have a degree (of advantage) over them. And Allah is Exalted in Power, Wise.

# 236

A divorce is only permissible twice: after that, the parties should either hold Together on equitable terms, or separate with kindness. It is not lawful for you, (Men), to take back any of your gifts (from your wives), except when both parties fear that they would be unable to keep the limits ordained by Allah. If ye (judges) do indeed fear that they would be unable to keep the limits ordained by Allah, there is no blame on either of them if she give something for her freedom. These are the limits ordained by Allah; so do not transgress them if any do transgress the limits ordained by Allah, such persons wrong (Themselves as well as others).

# 237

So if a husband divorces his wife (irrevocably), He cannot, after that, re-marry her until after she has married another husband and He has divorced her. In that case there is no blame on either of them if they re-unite, provided they feel that they can keep the limits ordained by Allah. Such are the limits ordained by Allah, which He makes plain to those who understand.

# 238

When ye divorce women, and they fulfil the term of their ('Iddat), either take them back on equitable terms or set them free on equitable terms; but do not take them back to injure them, (or) to take undue advantage; if any one does that; He wrongs his own soul. Do not treat Allah's Signs as a jest, but solemnly rehearse Allah's favours on you, and the fact that He sent down to you the Book and Wisdom, for your instruction. And fear Allah, and know that Allah is well acquainted with all things.

# 239

When ye divorce women, and they fulfil the term of their ('Iddat), do not prevent them from marrying their (former) husbands, if they mutually agree on equitable terms. This instruction is for all amongst you, who believe in Allah and the Last Day. That is (the course Making for) most virtue and purity amongst you and Allah knows, and ye know not.

# 240

The mothers shall give such to their offspring for two whole years, if the father desires to complete the term. But he shall bear the cost of their food and clothing on equitable terms. No soul shall have a burden laid on it greater than it can bear. No mother shall be Treated unfairly on account of her child. Nor father on account of his child, an heir shall be chargeable in the same way. If they both decide on weaning, by mutual consent, and after due consultation, there is no blame on them. If ye decide on a foster-mother for your offspring, there is no blame on you, provided ye pay (the mother) what ye offered, on equitable terms. But fear Allah and know that Allah sees well what ye do.

# 241

If any of you die and leave widows behind, they shall wait concerning themselves four months and ten days: When they have fulfilled their term, there is no blame on you if they dispose of themselves in a just and reasonable manner. And Allah is well acquainted with what ye do.

# 242

There is no blame on you if ye make an offer of betrothal or hold it in your hearts. Allah knows that ye cherish them in your hearts: But do not make a secret contract with them except in terms Honourable, nor resolve on the tie of marriage till the term prescribed is fulfilled. And know that Allah Knoweth what is in your hearts, and take heed of Him; and know that Allah is Oft-forgiving, Most Forbearing.

# 243

There is no blame on you if ye divorce women before consummation or the fixation of their dower; but bestow on them (A suitable gift), the wealthy according to his means, and the poor according to his means;- A gift of a reasonable amount is due from those who wish to do the right thing.

# 244

And if ye divorce them before consummation, but after the fixation of a dower for them, then the half of the dower (Is due to them), unless they remit it or (the man's half) is remitted by him in whose hands is the marriage tie; and the remission (of the man's half) is the nearest to righteousness. And do not forget Liberality between yourselves. For Allah sees well all that ye do.

# 245

Guard strictly your (habit of) prayers, especially the Middle Prayer; and stand before Allah in a devout (frame of mind).

# 246

If ye fear (an enemy), pray on foot, or riding, (as may be most convenient), but when ye are in security, celebrate Allah's praises in the manner He has taught you, which ye knew not (before).

# 247

Those of you who die and leave widows should bequeath for their widows a year's maintenance and residence; but if they leave (The residence), there is no blame on you for what they do with themselves, provided it is reasonable. And Allah is Exalted in Power, Wise.

# 248

For divorced women Maintenance (should be provided) on a reasonable (scale). This is a duty on the righteous.

# 249

Thus doth Allah Make clear His Signs to you: In order that ye may understand.

# 250

Didst thou not Turn by vision to those who abandoned their homes, though they were thousands (In number), for fear of death? Allah said to them: "Die": Then He restored them to life. For Allah is full of bounty to mankind, but Most of them are ungrateful.

# 251

Then fight in the cause of Allah, and know that Allah Heareth and knoweth all things.

# 252

Who is he that will loan to Allah a beautiful loan, which Allah will double unto his credit and multiply many times? It is Allah that giveth (you) Want or plenty, and to Him shall be your return.

# 253

Hast thou not Turned thy vision to the Chiefs of the Children of Israel after (the time of) Moses? they said to a prophet (That was) among them: "Appoint for us a king, that we May fight in the cause of Allah." He said: "Is it not possible, if ye were commanded to fight, that that ye will not fight?" They said: "How could we refuse to fight in the cause of Allah, seeing that we were turned out of our homes and our families?" but when they were commanded to fight, they turned back, except a small band among them. But Allah Has full knowledge of those who do wrong.

# 254

Their Prophet said to them: "Allah hath appointed Talut as king over you." They said: "How can he exercise authority over us when we are better fitted than he to exercise authority, and he is not even gifted, with wealth in abundance?" He said: "Allah hath Chosen him above you, and hath gifted him abundantly with knowledge and bodily prowess: Allah Granteth His authority to whom He pleaseth. Allah careth for all, and He knoweth all things."

# 255

And (further) their Prophet said to them: "A Sign of his authority is that there shall come to you the Ark of the covenant, with (an assurance) therein of security from your Lord, and the relics left by the family of Moses and the family of Aaron, carried by angels. In this is a symbol for you if ye indeed have faith."

# 256

When Talut set forth with the armies, he said: "Allah will test you at the stream: if any drinks of its water, He goes not with my army: Only those who taste not of it go with me: A mere sip out of the hand is excused." but they all drank of it, except a few. When they crossed the river,- He and the faithful ones with him,- they said: "This day We cannot cope with Goliath and his forces." but those who were convinced that they must meet Allah, said: "How oft, by Allah's will, Hath a small force vanquished a big one? Allah is with those who steadfastly persevere."

# 257

When they advanced to meet Goliath and his forces, they prayed: "Our Lord! Pour out constancy on us and make our steps firm: Help us against those that reject faith."

# 258

By Allah's will they routed them; and David slew Goliath; and Allah gave him power and wisdom and taught him whatever (else) He willed. And did not Allah Check one set of people by means of another, the earth would indeed be full of mischief: But Allah is full of bounty to all the worlds.

# 259

These are the Signs of Allah: we rehearse them to thee in truth: verily Thou art one of the messengers.

# 260

Those messengers We endowed with gifts, some above others: To one of them Allah spoke; others He raised to degrees (of honour); to Jesus the son of Mary We gave clear (Signs), and strengthened him with the holy spirit. If Allah had so willed, succeeding generations would not have fought among each other, after clear (Signs) had come to them, but they (chose) to wrangle, some believing and others rejecting. If Allah had so willed, they would not have fought each other; but Allah Fulfilleth His plan.

# 261

O ye who believe! Spend out of (the bounties) We have provided for you, before the Day comes when no bargaining (Will avail), nor friendship nor intercession. Those who reject Faith they are the wrong-doers.

# 262

Allah! There is no god but He,-the Living, the Self-subsisting, Eternal. No slumber can seize Him nor sleep. His are all things in the heavens and on earth. Who is there can intercede in His presence except as He permitteth? He knoweth what (appeareth to His creatures as) before or after or behind them. Nor shall they compass aught of His knowledge except as He willeth. His Throne doth extend over the heavens and the earth, and He feeleth no fatigue in guarding and preserving them for He is the Most High, the Supreme (in glory).

# 263

Let there be no compulsion in religion: Truth stands out clear from Error: whoever rejects evil and believes in Allah hath grasped the most trustworthy hand-hold, that never breaks. And Allah heareth and knoweth all things.

# 264

Allah is the Protector of those who have faith: from the depths of darkness He will lead them forth into light. Of those who reject faith the patrons are the evil ones: from light they will lead them forth into the depths of darkness. They will be companions of the fire, to dwell therein (For ever).

# 265

Hast thou not Turned thy vision to one who disputed with Abraham About his Lord, because Allah had granted him power? Abraham said: "My Lord is He Who Giveth life and death." He said: "I give life and death". Said Abraham: "But it is Allah that causeth the sun to rise from the east: Do thou then cause him to rise from the West." Thus was he confounded who (in arrogance) rejected faith. Nor doth Allah Give guidance to a people unjust.

# 266

Or (take) the similitude of one who passed by a hamlet, all in ruins to its roofs. He said: "Oh! how shall Allah bring it (ever) to life, after (this) its death?" but Allah caused him to die for a hundred years, then raised him up (again). He said: "How long didst thou tarry (thus)?" He said: (Perhaps) a day or part of a day." He said: "Nay, thou hast tarried thus a hundred years; but look at thy food and thy drink; they show no signs of age; and look at thy donkey: And that We may make of thee a sign unto the people, Look further at the bones, how We bring them together and clothe them with flesh." When this was shown clearly to him, he said: "I know that Allah hath power over all things."

# 267

When Abraham said: "Show me, Lord, how You will raise the dead, " He replied: "Have you no faith?" He said "Yes, but just to reassure my heart." Allah said, "Take four birds, draw them to you, and cut their bodies to pieces. Scatter them over the mountain-tops, then call them back. They will come swiftly to you. Know that Allah is Mighty, Wise."

# 268

The parable of those who spend their substance in the way of Allah is that of a grain of corn: it groweth seven ears, and each ear Hath a hundred grains. Allah giveth manifold increase to whom He pleaseth: And Allah careth for all and He knoweth all things.

# 269

Those who spend their substance in the cause of Allah, and follow not up their gifts with reminders of their generosity or with injury,-for them their reward is with their Lord: on them shall be no fear, nor shall they grieve.

# 270

Kind words and the covering of faults are better than charity followed by injury. Allah is free of all wants, and He is Most-Forbearing.

# 271

O ye who believe! cancel not your charity by reminders of your generosity or by injury,- like those who spend their substance to be seen of men, but believe neither in Allah nor in the Last Day. They are in parable like a hard, barren rock, on which is a little soil: on it falls heavy rain, which leaves it (Just) a bare stone. They will be able to do nothing with aught they have earned. And Allah guideth not those who reject faith.

# 272

And the likeness of those who spend their substance, seeking to please Allah and to strengthen their souls, is as a garden, high and fertile: heavy rain falls on it but makes it yield a double increase of harvest, and if it receives not Heavy rain, light moisture sufficeth it. Allah seeth well whatever ye do.

# 273

Does any of you wish that he should have a garden with date-palms and vines and streams flowing underneath, and all kinds of fruit, while he is stricken with old age, and his children are not strong (enough to look after themselves)- that it should be caught in a whirlwind, with fire therein, and be burnt up? Thus doth Allah make clear to you (His) Signs; that ye may consider.

# 274

O ye who believe! Give of the good things which ye have (honourably) earned, and of the fruits of the earth which We have produced for you, and do not even aim at getting anything which is bad, in order that out of it ye may give away something, when ye yourselves would not receive it except with closed eyes. And know that Allah is Free of all wants, and worthy of all praise.

# 275

The Evil one threatens you with poverty and bids you to conduct unseemly. Allah promiseth you His forgiveness and bounties. And Allah careth for all and He knoweth all things.

# 276

He granteth wisdom to whom He pleaseth; and he to whom wisdom is granted receiveth indeed a benefit overflowing; but none will grasp the Message but men of understanding.

# 277

And whatever ye spend in charity or devotion, be sure Allah knows it all. But the wrong-doers have no helpers.

# 278

If ye disclose (acts of) charity, even so it is well, but if ye conceal them, and make them reach those (really) in need, that is best for you: It will remove from you some of your (stains of) evil. And Allah is well acquainted with what ye do.

# 279

It is not required of thee (O Messenger), to set them on the right path, but Allah sets on the right path whom He pleaseth. Whatever of good ye give benefits your own souls, and ye shall only do so seeking the "Face" of Allah. Whatever good ye give, shall be rendered back to you, and ye shall not Be dealt with unjustly.

# 280

(Charity is) for those in need, who, in Allah's cause are restricted (from travel), and cannot move about in the land, seeking (For trade or work): the ignorant man thinks, because of their modesty, that they are free from want. Thou shalt know them by their (Unfailing) mark: They beg not importunately from all the sundry. And whatever of good ye give, be assured Allah knoweth it well.

# 281

Those who (in charity) spend of their goods by night and by day, in secret and in public, have their reward with their Lord: on them shall be no fear, nor shall they grieve.

# 282

Those who devour usury will not stand except as stand one whom the Evil one by his touch Hath driven to madness. That is because they say: "Trade is like usury," but Allah hath permitted trade and forbidden usury. Those who after receiving direction from their Lord, desist, shall be pardoned for the past; their case is for Allah (to judge); but those who repeat (The offence) are companions of the Fire: They will abide therein (for ever).

# 283

Allah will deprive usury of all blessing, but will give increase for deeds of charity: For He loveth not creatures ungrateful and wicked.

# 284

Those who believe, and do deeds of righteousness, and establish regular prayers and regular charity, will have their reward with their Lord: on them shall be no fear, nor shall they grieve.

# 285

O ye who believe! Fear Allah, and give up what remains of your demand for usury, if ye are indeed believers.

# 286

If ye do it not, Take notice of war from Allah and His Messenger: But if ye turn back, ye shall have your capital sums: Deal not unjustly, and ye shall not be dealt with unjustly.

# 287

If the debtor is in a difficulty, grant him time Till it is easy for him to repay. But if ye remit it by way of charity, that is best for you if ye only knew.

# 288

And fear the Day when ye shall be brought back to Allah. Then shall every soul be paid what it earned, and none shall be dealt with unjustly.

# 289

O ye who believe! When ye deal with each other, in transactions involving future obligations in a fixed period of time, reduce them to writing Let a scribe write down faithfully as between the parties: let not the scribe refuse to write: as Allah Has taught him, so let him write. Let him who incurs the liability dictate, but let him fear His Lord Allah, and not diminish aught of what he owes. If they party liable is mentally deficient, or weak, or unable Himself to dictate, Let his guardian dictate faithfully, and get two witnesses, out of your own men, and if there are not two men, then a man and two women, such as ye choose, for witnesses, so that if one of them errs, the other can remind her. The witnesses should not refuse when they are called on (For evidence). Disdain not to reduce to writing (your contract) for a future period, whether it be small or big: it is juster in the sight of Allah, More suitable as evidence, and more convenient to prevent doubts among yourselves but if it be a transaction which ye carry out on the spot among yourselves, there is no blame on you if ye reduce it not to writing. But take witness whenever ye make a commercial contract; and let neither scribe nor witness suffer harm. If ye do (such harm), it would be wickedness in you. So fear Allah; For it is Good that teaches you. And Allah is well acquainted with all things. If ye are on a journey, and cannot find a scribe, a pledge with possession (may serve the purpose). And if one of you deposits a thing on trust with another, let the trustee (faithfully) discharge his trust, and let him Fear his Lord conceal not evidence; for whoever conceals it, - his heart is tainted with sin. And Allah knoweth all that ye do.

# 290

If ye are on a journey, and cannot find a scribe, a pledge with possession (may serve the purpose). And if one of you deposits a thing on trust with another, Let the trustee (Faithfully) discharge His trust, and let him fear his Lord. Conceal not evidence; for whoever conceals it,- His heart is tainted with sin. And Allah Knoweth all that ye do.

# 291

To Allah belongeth all that is in the heavens and on earth. Whether ye show what is in your minds or conceal it, Allah Calleth you to account for it. He forgiveth whom He pleaseth, and punisheth whom He pleaseth, for Allah hath power over all things.

# 292

The Messenger believeth in what hath been revealed to him from his Lord, as do the men of faith. Each one (of them) believeth in Allah, His angels, His books, and His messengers. "We make no distinction (they say) between one and another of His messengers." And they say: "We hear, and we obey: (We seek) Thy forgiveness, our Lord, and to Thee is the end of all journeys."

# 293

On no soul doth Allah Place a burden greater than it can bear. It gets every good that it earns, and it suffers every ill that it earns. (Pray:) "Our Lord! Condemn us not if we forget or fall into error; our Lord! Lay not on us a burden Like that which Thou didst lay on those before us; Our Lord! Lay not on us a burden greater than we have strength to bear. Blot out our sins, and grant us forgiveness. Have mercy on us. Thou art our Protector; Help us against those who stand against faith."

# 294

A. L. M.

# 295

Allah! There is no god but He,-the Living, the Self-Subsisting, Eternal.

# 296

It is He Who sent down to thee (step by step), in truth, the Book, confirming what went before it; and He sent down the Law (of Moses) and the Gospel (of Jesus) before this, as a guide to mankind, and He sent down the criterion (of judgment between right and wrong).

# 297

Then those who reject Faith in the Signs of Allah will suffer the severest penalty, and Allah is Exalted in Might, Lord of Retribution.

# 298

From Allah, verily nothing is hidden on earth or in the heavens.

# 299

He it is Who shapes you in the wombs as He pleases. There is no god but He, the Exalted in Might, the Wise.

# 300

He it is Who has sent down to thee the Book: In it are verses basic or fundamental (of established meaning); they are the foundation of the Book: others are allegorical. But those in whose hearts is perversity follow the part thereof that is allegorical, seeking discord, and searching for its hidden meanings, but no one knows its hidden meanings except Allah. And those who are firmly grounded in knowledge say: "We believe in the Book; the whole of it is from our Lord:" and none will grasp the Message except men of understanding.

# 301

"Our Lord!" (they say), "Let not our hearts deviate now after Thou hast guided us, but grant us mercy from Thine own Presence; for Thou art the Grantor of bounties without measure.

# 302

"Our Lord! Thou art He that will gather mankind Together against a day about which there is no doubt; for Allah never fails in His promise."

# 303

Those who reject Faith,- neither their possessions nor their (numerous) progeny will avail them aught against Allah: They are themselves but fuel for the Fire.

# 304

(Their plight will be) no better than that of the people of Pharaoh, and their predecessors: They denied our Signs, and Allah called them to account for their sins. For Allah is strict in punishment.

# 305

Say to those who reject Faith: "Soon will ye be vanquished and gathered together to Hell,-an evil bed indeed (to lie on)!

# 306

"There has already been for you a Sign in the two armies that met (in combat): One was fighting in the cause of Allah, the other resisting Allah; these saw with their own eyes Twice their number. But Allah doth support with His aid whom He pleaseth. In this is a warning for such as have eyes to see."

# 307

Fair in the eyes of men is the love of things they covet: Women and sons; Heaped-up hoards of gold and silver; horses branded (for blood and excellence); and (wealth of) cattle and well-tilled land. Such are the possessions of this world's life; but in nearness to Allah is the best of the goals (To return to).

# 308

Say: Shall I give you glad tidings of things Far better than those? For the righteous are Gardens in nearness to their Lord, with rivers flowing beneath; therein is their eternal home; with companions pure (and holy); and the good pleasure of Allah. For in Allah's sight are (all) His servants,-

# 309

(Namely), those who say: "Our Lord! we have indeed believed: forgive us, then, our sins, and save us from the agony of the Fire;"-

# 310

Those who show patience, Firmness and self-control; who are true (in word and deed); who worship devoutly; who spend (in the way of Allah); and who pray for forgiveness in the early hours of the morning.

# 311

There is no god but He: That is the witness of Allah, His angels, and those endued with knowledge, standing firm on justice. There is no god but He, the Exalted in Power, the Wise.

# 312

The Religion before Allah is Islam (submission to His Will): Nor did the People of the Book dissent therefrom except through envy of each other, after knowledge had come to them. But if any deny the Signs of Allah, Allah is swift in calling to account.

# 313

So if they dispute with thee, say: "I have submitted My whole self to Allah and so have those who follow me." And say to the People of the Book and to those who are unlearned: "Do ye (also) submit yourselves?" If they do, they are in right guidance, but if they turn back, Thy duty is to convey the Message; and in Allah's sight are (all) His servants.

# 314

As to those who deny the Signs of Allah and in defiance of right, slay the prophets, and slay those who teach just dealing with mankind, announce to them a grievous penalty.

# 315

They are those whose works will bear no fruit in this world and in the Hereafter nor will they have anyone to help.

# 316

Hast thou not turned Thy vision to those who have been given a portion of the Book? They are invited to the Book of Allah, to settle their dispute, but a party of them Turn back and decline (The arbitration).

# 317

This because they say: "The Fire shall not touch us but for a few numbered days": For their forgeries deceive them as to their own religion.

# 318

But how (will they fare) when we gather them together against a day about which there is no doubt, and each soul will be paid out just what it has earned, without (favour or) injustice?

# 319

Say: "O Allah! Lord of Power (And Rule), Thou givest power to whom Thou pleasest, and Thou strippest off power from whom Thou pleasest: Thou enduest with honour whom Thou pleasest, and Thou bringest low whom Thou pleasest: In Thy hand is all good. Verily, over all things Thou hast power.

# 320

"Thou causest the night to gain on the day, and thou causest the day to gain on the night; Thou bringest the Living out of the dead, and Thou bringest the dead out of the Living; and Thou givest sustenance to whom Thou pleasest, without measure."

# 321

Let not the believers Take for friends or helpers Unbelievers rather than believers: if any do that, in nothing will there be help from Allah: except by way of precaution, that ye may Guard yourselves from them. But Allah cautions you (To remember) Himself; for the final goal is to Allah.

# 322

Say: "Whether ye hide what is in your hearts or reveal it, Allah knows it all: He knows what is in the heavens, and what is on earth. And Allah has power over all things.

# 323

"On the Day when every soul will be confronted with all the good it has done, and all the evil it has done, it will wish there were a great distance between it and its evil. But Allah cautions you (To remember) Himself. And Allah is full of kindness to those that serve Him."

# 324

Say: "If ye do love Allah, Follow me: Allah will love you and forgive you your sins: For Allah is Oft-Forgiving, Most Merciful."

# 325

Say: "Obey Allah and His Messenger": But if they turn back, Allah loveth not those who reject Faith.

# 326

Allah did choose Adam and Noah, the family of Abraham, and the family of 'Imran above all people,-

# 327

Offspring, one of the other: And Allah heareth and knoweth all things.

# 328

Behold! a woman of 'Imran said: "O my Lord! I do dedicate unto Thee what is in my womb for Thy special service: So accept this of me: For Thou hearest and knowest all things."

# 329

When she was delivered, she said: "O my Lord! Behold! I am delivered of a female child!"- and Allah knew best what she brought forth- "And no wise is the male Like the female. I have named her Mary, and I commend her and her offspring to Thy protection from the Evil One, the Rejected."

# 330

Right graciously did her Lord accept her: He made her grow in purity and beauty: To the care of Zakariya was she assigned. Every time that he entered (Her) chamber to see her, He found her supplied with sustenance. He said: "O Mary! Whence (comes) this to you?" She said: "From Allah: for Allah Provides sustenance to whom He pleases without measure."

# 331

There did Zakariya pray to his Lord, saying: "O my Lord! Grant unto me from Thee a progeny that is pure: for Thou art He that heareth prayer!

# 332

While he was standing in prayer in the chamber, the angels called unto him: "Allah doth give thee glad tidings of Yahya, witnessing the truth of a Word from Allah, and (be besides) noble, chaste, and a prophet,- of the (goodly) company of the righteous."

# 333

He said: "O my Lord! How shall I have son, seeing I am very old, and my wife is barren?" "Thus," was the answer, "Doth Allah accomplish what He willeth."

# 334

He said: "O my Lord! Give me a Sign!" "Thy Sign," was the answer, "Shall be that thou shalt speak to no man for three days but with signals. Then celebrate the praises of thy Lord again and again, and glorify Him in the evening and in the morning."

# 335

Behold! the angels said: "O Mary! Allah hath chosen thee and purified thee- chosen thee above the women of all nations.

# 336

"O Mary! worship Thy Lord devoutly: Prostrate thyself, and bow down (in prayer) with those who bow down."

# 337

This is part of the tidings of the things unseen, which We reveal unto thee (O Messenger!) by inspiration: Thou wast not with them when they cast lots with arrows, as to which of them should be charged with the care of Mary: Nor wast thou with them when they disputed (the point).

# 338

Behold! the angels said: "O Mary! Allah giveth thee glad tidings of a Word from Him: his name will be Christ Jesus, the son of Mary, held in honour in this world and the Hereafter and of (the company of) those nearest to Allah;

# 339

"He shall speak to the people in childhood and in maturity. And he shall be (of the company) of the righteous."

# 340

She said: "O my Lord! How shall I have a son when no man hath touched me?" He said: "Even so: Allah createth what He willeth: When He hath decreed a plan, He but saith to it, 'Be,' and it is!

# 341

"And Allah will teach him the Book and Wisdom, the Law and the Gospel,

# 342

"And (appoint him) a messenger to the Children of Israel, (with this message): "'I have come to you, with a Sign from your Lord, in that I make for you out of clay, as it were, the figure of a bird, and breathe into it, and it becomes a bird by Allah's leave: And I heal those born blind, and the lepers, and I quicken the dead, by Allah's leave; and I declare to you what ye eat, and what ye store in your houses. Surely therein is a Sign for you if ye did believe;

# 343

"'(I have come to you), to attest the Law which was before me. And to make lawful to you part of what was (Before) forbidden to you; I have come to you with a Sign from your Lord. So fear Allah, and obey me.

# 344

"'It is Allah Who is my Lord and your Lord; then worship Him. This is a Way that is straight.'"

# 345

When Jesus found Unbelief on their part He said: "Who will be My helpers to (the work of) Allah?" Said the disciples: "We are Allah's helpers: We believe in Allah, and do thou bear witness that we are Muslims.

# 346

"Our Lord! we believe in what Thou hast revealed, and we follow the Messenger; then write us down among those who bear witness."

# 347

And (the unbelievers) plotted and planned, and Allah too planned, and the best of planners is Allah.

# 348

Behold! Allah said: "O Jesus! I will take thee and raise thee to Myself and clear thee (of the falsehoods) of those who blaspheme; I will make those who follow thee superior to those who reject faith, to the Day of Resurrection: Then shall ye all return unto me, and I will judge between you of the matters wherein ye dispute.

# 349

"As to those who reject faith, I will punish them with terrible agony in this world and in the Hereafter, nor will they have anyone to help."

# 350

"As to those who believe and work righteousness, Allah will pay them (in full) their reward; but Allah loveth not those who do wrong."

# 351

"This is what we rehearse unto thee of the Signs and the Message of Wisdom."

# 352

The similitude of Jesus before Allah is as that of Adam; He created him from dust, then said to him: "Be". And he was.

# 353

The Truth (comes) from Allah alone; so be not of those who doubt.

# 354

If any one disputes in this matter with thee, now after (full) knowledge Hath come to thee, say: "Come! let us gather together,- our sons and your sons, our women and your women, ourselves and yourselves: Then let us earnestly pray, and invoke the curse of Allah on those who lie!"

# 355

This is the true account: There is no god except Allah; and Allah-He is indeed the Exalted in Power, the Wise.

# 356

But if they turn back, Allah hath full knowledge of those who do mischief.

# 357

Say: "O People of the Book! come to common terms as between us and you: That we worship none but Allah; that we associate no partners with him; that we erect not, from among ourselves, Lords and patrons other than Allah." If then they turn back, say ye: "Bear witness that we (at least) are Muslims (bowing to Allah's Will).

# 358

Ye People of the Book! Why dispute ye about Abraham, when the Law and the Gospel Were not revealed Till after him? Have ye no understanding?

# 359

Ah! Ye are those who fell to disputing (Even) in matters of which ye had some knowledge! but why dispute ye in matters of which ye have no knowledge? It is Allah Who knows, and ye who know not!

# 360

Abraham was not a Jew nor yet a Christian; but he was true in Faith, and bowed his will to Allah's (Which is Islam), and he joined not gods with Allah.

# 361

Without doubt, among men, the nearest of kin to Abraham, are those who follow him, as are also this Prophet and those who believe: And Allah is the Protector of those who have faith.

# 362

It is the wish of a section of the People of the Book to lead you astray. But they shall lead astray (Not you), but themselves, and they do not perceive!

# 363

Ye People of the Book! Why reject ye the Signs of Allah, of which ye are (Yourselves) witnesses?

# 364

Ye People of the Book! Why do ye clothe Truth with falsehood, and conceal the Truth, while ye have knowledge?

# 365

A section of the People of the Book say: "Believe in the morning what is revealed to the believers, but reject it at the end of the day; perchance they may (themselves) Turn back;

# 366

"And believe no one unless he follows your religion." Say: "True guidance is the Guidance of Allah: (Fear ye) Lest a revelation be sent to someone (else) Like unto that which was sent unto you? or that those (Receiving such revelation) should engage you in argument before your Lord?" Say: "All bounties are in the hand of Allah: He granteth them to whom He pleaseth: And Allah careth for all, and He knoweth all things."

# 367

For His Mercy He specially chooseth whom He pleaseth; for Allah is the Lord of bounties unbounded.

# 368

Among the People of the Book are some who, if entrusted with a hoard of gold, will (readily) pay it back; others, who, if entrusted with a single silver coin, will not repay it unless thou constantly stoodest demanding, because, they say, "there is no call on us (to keep faith) with these ignorant (Pagans)." but they tell a lie against Allah, and (well) they know it.

# 369

Nay.- Those that keep their plighted faith and act aright,-verily Allah loves those who act aright.

# 370

As for those who sell the faith they owe to Allah and their own plighted word for a small price, they shall have no portion in the Hereafter: Nor will Allah (Deign to) speak to them or look at them on the Day of Judgment, nor will He cleans them (of sin): They shall have a grievous penalty.

# 371

There is among them a section who distort the Book with their tongues: (As they read) you would think it is a part of the Book, but it is no part of the Book; and they say, "That is from Allah," but it is not from Allah: It is they who tell a lie against Allah, and (well) they know it!

# 372

It is not (possible) that a man, to whom is given the Book, and Wisdom, and the prophetic office, should say to people: "Be ye my worshippers rather than Allah's": on the contrary (He would say) "Be ye worshippers of Him Who is truly the Cherisher of all: For ye have taught the Book and ye have studied it earnestly."

# 373

Nor would he instruct you to take angels and prophets for Lords and patrons. What! would he bid you to unbelief after ye have bowed your will (To Allah in Islam)?

# 374

Behold! Allah took the covenant of the prophets, saying: "I give you a Book and Wisdom; then comes to you a messenger, confirming what is with you; do ye believe in him and render him help." Allah said: "Do ye agree, and take this my Covenant as binding on you?" They said: "We agree." He said: "Then bear witness, and I am with you among the witnesses."

# 375

If any turn back after this, they are perverted transgressors.

# 376

Do they seek for other than the Religion of Allah?-while all creatures in the heavens and on earth have, willing or unwilling, bowed to His Will (Accepted Islam), and to Him shall they all be brought back.

# 377

Say: "We believe in Allah, and in what has been revealed to us and what was revealed to Abraham, Isma'il, Isaac, Jacob, and the Tribes, and in (the Books) given to Moses, Jesus, and the prophets, from their Lord: We make no distinction between one and another among them, and to Allah do we bow our will (in Islam)."

# 378

If anyone desires a religion other than Islam (submission to Allah), never will it be accepted of him; and in the Hereafter He will be in the ranks of those who have lost (All spiritual good).

# 379

How shall Allah Guide those who reject Faith after they accepted it and bore witness that the Messenger was true and that Clear Signs had come unto them? but Allah guides not a people unjust.

# 380

Of such the reward is that on them (rests) the curse of Allah, of His angels, and of all mankind;-

# 381

In that will they dwell; nor will their penalty be lightened, nor respite be (their lot);-

# 382

Except for those that repent (Even) after that, and make amends; for verily Allah is Oft-Forgiving, Most Merciful.

# 383

But those who reject Faith after they accepted it, and then go on adding to their defiance of Faith,- never will their repentance be accepted; for they are those who have (of set purpose) gone astray.

# 384

As to those who reject Faith, and die rejecting,- never would be accepted from any such as much gold as the earth contains, though they should offer it for ransom. For such is (in store) a penalty grievous, and they will find no helpers.

# 385

By no means shall ye attain righteousness unless ye give (freely) of that which ye love; and whatever ye give, of a truth Allah knoweth it well.

# 386

All food was lawful to the Children of Israel, except what Israel Made unlawful for itself, before the Law (of Moses) was revealed. Say: "Bring ye the Law and study it, if ye be men of truth."

# 387

If any, after this, invent a lie and attribute it to Allah, they are indeed unjust wrong-doers.

# 388

Say: "Allah speaketh the Truth: follow the religion of Abraham, the sane in faith; he was not of the Pagans."

# 389

The first House (of worship) appointed for men was that at Bakka: Full of blessing and of guidance for all kinds of beings:

# 390

In it are Signs Manifest; (for example), the Station of Abraham; whoever enters it attains security; Pilgrimage thereto is a duty men owe to Allah,- those who can afford the journey; but if any deny faith, Allah stands not in need of any of His creatures.

# 391

Say: "O People of the Book! Why reject ye the Signs of Allah, when Allah is Himself witness to all ye do?"

# 392

Say: "O ye People of the Book! Why obstruct ye those who believe, from the path of Allah, Seeking to make it crooked, while ye were yourselves witnesses (to Allah's Covenant)? but Allah is not unmindful of all that ye do."

# 393

O ye who believe! If ye listen to a faction among the People of the Book, they would (indeed) render you apostates after ye have believed!

# 394

And how would ye deny Faith while unto you are rehearsed the Signs of Allah, and among you Lives the Messenger? Whoever holds firmly to Allah will be shown a way that is straight.

# 395

O ye who believe! Fear Allah as He should be feared, and die not except in a state of Islam.

# 396

And hold fast, all together, by the rope which Allah (stretches out for you), and be not divided among yourselves; and remember with gratitude Allah's favour on you; for ye were enemies and He joined your hearts in love, so that by His Grace, ye became brethren; and ye were on the brink of the pit of Fire, and He saved you from it. Thus doth Allah make His Signs clear to you: That ye may be guided.

# 397

Let there arise out of you a band of people inviting to all that is good, enjoining what is right, and forbidding what is wrong: They are the ones to attain felicity.

# 398

Be not like those who are divided amongst themselves and fall into disputations after receiving Clear Signs: For them is a dreadful penalty,-

# 399

On the Day when some faces will be (lit up with) white, and some faces will be (in the gloom of) black: To those whose faces will be black, (will be said): "Did ye reject Faith after accepting it? Taste then the penalty for rejecting Faith."

# 400

But those whose faces will be (lit with) white,- they will be in (the light of) Allah's mercy: therein to dwell (for ever).

# 401

These are the Signs of Allah: We rehearse them to thee in Truth: And Allah means no injustice to any of His creatures.

# 402

To Allah belongs all that is in the heavens and on earth: To Him do all questions go back (for decision).

# 403

Ye are the best of peoples, evolved for mankind, enjoining what is right, forbidding what is wrong, and believing in Allah. If only the People of the Book had faith, it were best for them: among them are some who have faith, but most of them are perverted transgressors.

# 404

They will do you no harm, barring a trifling annoyance; if they come out to fight you, they will show you their backs, and no help shall they get.

# 405

Shame is pitched over them (Like a tent) wherever they are found, except when under a covenant (of protection) from Allah and from men; they draw on themselves wrath from Allah, and pitched over them is (the tent of) destitution. This because they rejected the Signs of Allah, and slew the prophets in defiance of right; this because they rebelled and transgressed beyond bounds.

# 406

Not all of them are alike: Of the People of the Book are a portion that stand (For the right): They rehearse the Signs of Allah all night long, and they prostrate themselves in adoration.

# 407

They believe in Allah and the Last Day; they enjoin what is right, and forbid what is wrong; and they hasten (in emulation) in (all) good works: They are in the ranks of the righteous.

# 408

Of the good that they do, nothing will be rejected of them; for Allah knoweth well those that do right.

# 409

Those who reject Faith,- neither their possessions nor their (numerous) progeny will avail them aught against Allah: They will be companions of the Fire,-dwelling therein (for ever).

# 410

What they spend in the life of this (material) world May be likened to a wind which brings a nipping frost: It strikes and destroys the harvest of men who have wronged their own souls: it is not Allah that hath wronged them, but they wrong themselves.

# 411

O ye who believe! Take not into your intimacy those outside your ranks: They will not fail to corrupt you. They only desire your ruin: Rank hatred has already appeared from their mouths: What their hearts conceal is far worse. We have made plain to you the Signs, if ye have wisdom.

# 412

Ah! ye are those who love them, but they love you not,- though ye believe in the whole of the Book. When they meet you, they say, "We believe": But when they are alone, they bite off the very tips of their fingers at you in their rage. Say: "Perish in your rage; Allah knoweth well all the secrets of the heart."

# 413

If aught that is good befalls you, it grieves them; but if some misfortune overtakes you, they rejoice at it. But if ye are constant and do right, not the least harm will their cunning do to you; for Allah Compasseth round about all that they do.

# 414

Remember that morning Thou didst leave Thy household (early) to post the faithful at their stations for battle: And Allah heareth and knoweth all things:

# 415

Remember two of your parties Meditated cowardice; but Allah was their protector, and in Allah should the faithful (Ever) put their trust.

# 416

Allah had helped you at Badr, when ye were a contemptible little force; then fear Allah; thus May ye show your gratitude.

# 417

Remember thou saidst to the Faithful: "Is it not enough for you that Allah should help you with three thousand angels (Specially) sent down?

# 418

"Yea, - if ye remain firm, and act aright, even if the enemy should rush here on you in hot haste, your Lord would help you with five thousand angels Making a terrific onslaught.

# 419

Allah made it but a message of hope for you, and an assurance to your hearts: (in any case) there is no help except from Allah. The Exalted, the Wise:

# 420

That He might cut off a fringe of the Unbelievers or expose them to infamy, and they should then be turned back, frustrated of their purpose.

# 421

Not for thee, (but for Allah), is the decision: Whether He turn in mercy to them, or punish them; for they are indeed wrong-doers.

# 422

To Allah belongeth all that is in the heavens and on earth. He forgiveth whom He pleaseth and punisheth whom He pleaseth; but Allah is Oft-Forgiving, Most Merciful.

# 423

O ye who believe! Devour not usury, doubled and multiplied; but fear Allah; that ye may (really) prosper.

# 424

Fear the Fire, which is repaired for those who reject Faith:

# 425

And obey Allah and the Messenger; that ye may obtain mercy.

# 426

Be quick in the race for forgiveness from your Lord, and for a Garden whose width is that (of the whole) of the heavens and of the earth, prepared for the righteous,-

# 427

Those who spend (freely), whether in prosperity, or in adversity; who restrain anger, and pardon (all) men;- for Allah loves those who do good;-

# 428

And those who, having done something to be ashamed of, or wronged their own souls, earnestly bring Allah to mind, and ask for forgiveness for their sins,- and who can forgive sins except Allah?- and are never obstinate in persisting knowingly in (the wrong) they have done.

# 429

For such the reward is forgiveness from their Lord, and Gardens with rivers flowing underneath,- an eternal dwelling: How excellent a recompense for those who work (and strive)!

# 430

Many were the Ways of Life that have passed away before you: travel through the earth, and see what was the end of those who rejected Truth.

# 431

Here is a plain statement to men, a guidance and instruction to those who fear Allah!

# 432

So lose not heart, nor fall into despair: For ye must gain mastery if ye are true in Faith.

# 433

If a wound hath touched you, be sure a similar wound hath touched the others. Such days (of varying fortunes) We give to men and men by turns: that Allah may know those that believe, and that He may take to Himself from your ranks Martyr-witnesses (to Truth). And Allah loveth not those that do wrong.

# 434

Allah's object also is to purge those that are true in Faith and to deprive of blessing Those that resist Faith.

# 435

Did ye think that ye would enter Heaven without Allah testing those of you who fought hard (In His Cause) and remained steadfast?

# 436

Ye did indeed wish for death before ye met him: Now ye have seen him with your own eyes, (And ye flinch!)

# 437

Muhammad is no more than a messenger: many Were the messenger that passed away before him. If he died or were slain, will ye then Turn back on your heels? If any did turn back on his heels, not the least harm will he do to Allah; but Allah (on the other hand) will swiftly reward those who (serve Him) with gratitude.

# 438

Nor can a soul die except by Allah's leave, the term being fixed as by writing. If any do desire a reward in this life, We shall give it to him; and if any do desire a reward in the Hereafter, We shall give it to him. And swiftly shall We reward those that (serve us with) gratitude.

# 439

How many of the prophets fought (in Allah's way), and with them (fought) Large bands of godly men? but they never lost heart if they met with disaster in Allah's way, nor did they weaken (in will) nor give in. And Allah Loves those who are firm and steadfast.

# 440

All that they said was: "Our Lord! Forgive us our sins and anything We may have done that transgressed our duty: Establish our feet firmly, and help us against those that resist Faith."

# 441

And Allah gave them a reward in this world, and the excellent reward of the Hereafter. For Allah Loveth those who do good.

# 442

O ye who believe! If ye obey the Unbelievers, they will drive you back on your heels, and ye will turn back (from Faith) to your own loss.

# 443

Nay, Allah is your protector, and He is the best of helpers.

# 444

Soon shall We cast terror into the hearts of the Unbelievers, for that they joined companions with Allah, for which He had sent no authority: their abode will be the Fire: And evil is the home of the wrong-doers!

# 445

Allah did indeed fulfil His promise to you when ye with His permission Were about to annihilate your enemy,-until ye flinched and fell to disputing about the order, and disobeyed it after He brought you in sight (of the booty) which ye covet. Among you are some that hanker after this world and some that desire the Hereafter. Then did He divert you from your foes in order to test you but He forgave you: For Allah is full of grace to those who believe.

# 446

Behold! ye were climbing up the high ground, without even casting a side glance at any one, and the Messenger in your rear was calling you back. There did Allah give you one distress after another by way of requital, to teach you not to grieve for (the booty) that had escaped you and for (the ill) that had befallen you. For Allah is well aware of all that ye do.

# 447

After (the excitement) of the distress, He sent down calm on a band of you overcome with slumber, while another band was stirred to anxiety by their own feelings, Moved by wrong suspicions of Allah-suspicions due to ignorance. They said: "What affair is this of ours?" Say thou: "Indeed, this affair is wholly Allah's." They hide in their minds what they dare not reveal to thee. They say (to themselves): "If we had had anything to do with this affair, We should not have been in the slaughter here." Say: "Even if you had remained in your homes, those for whom death was decreed would certainly have gone forth to the place of their death"; but (all this was) that Allah might test what is in your breasts and purge what is in your hearts. For Allah knoweth well the secrets of your hearts.

# 448

Those of you who turned back on the day the two hosts Met,-it was Satan who caused them to fail, because of some (evil) they had done. But Allah Has blotted out (their fault): For Allah is Oft-Forgiving, Most Forbearing.

# 449

O ye who believe! Be not like the Unbelievers, who say of their brethren, when they are travelling through the Earth or engaged in fighting: "If they had stayed with us, they would not have died, or been slain." This that Allah may make it a cause of sighs and regrets in their hearts. It is Allah that gives Life and Death, and Allah sees well all that ye do.

# 450

And if ye are slain, or die, in the way of Allah, forgiveness and mercy from Allah are far better than all they could amass.

# 451

And if ye die, or are slain, Lo! it is unto Allah that ye are brought together.

# 452

It is part of the Mercy of Allah that thou dost deal gently with them Wert thou severe or harsh-hearted, they would have broken away from about thee: so pass over (Their faults), and ask for (Allah's) forgiveness for them; and consult them in affairs (of moment). Then, when thou hast Taken a decision put thy trust in Allah. For Allah loves those who put their trust (in Him).

# 453

If Allah helps you, none can overcome you: If He forsakes you, who is there, after that, that can help you? in Allah, then, Let believers put their trust.

# 454

No prophet could (ever) be false to his trust. If any person is so false, He shall, on the Day of Judgment, restore what he misappropriated; then shall every soul receive its due,- whatever it earned,- and none shall be dealt with unjustly.

# 455

Is the man who follows the good pleasure of Allah Like the man who draws on himself the wrath of Allah, and whose abode is in Hell?- A woeful refuge!

# 456

They are in varying gardens in the sight of Allah, and Allah sees well all that they do.

# 457

Allah did confer a great favour on the believers when He sent among them a messenger from among themselves, rehearsing unto them the Signs of Allah, sanctifying them, and instructing them in Scripture and Wisdom, while, before that, they had been in manifest error.

# 458

What! When a single disaster smites you, although ye smote (your enemies) with one twice as great, do ye say?- "Whence is this?" Say (to them): "It is from yourselves: For Allah hath power over all things."

# 459

What ye suffered on the day the two armies Met, was with the leave of Allah, in order that He might test the believers,-

# 460

And the Hypocrites also. These were told: "Come, fight in the way of Allah, or (at least) drive (The foe from your city)." They said: "Had we known how to fight, we should certainly have followed you." They were that day nearer to Unbelief than to Faith, saying with their lips what was not in their hearts but Allah hath full knowledge of all they conceal.

# 461

(They are) the ones that say, (of their brethren slain), while they themselves sit (at ease): "If only they had listened to us they would not have been slain." Say: "Avert death from your own selves, if ye speak the truth."

# 462

Think not of those who are slain in Allah's way as dead. Nay, they live, finding their sustenance in the presence of their Lord;

# 463

They rejoice in the bounty provided by Allah: And with regard to those left behind, who have not yet joined them (in their bliss), the (Martyrs) glory in the fact that on them is no fear, nor have they (cause to) grieve.

# 464

They glory in the Grace and the bounty from Allah, and in the fact that Allah suffereth not the reward of the Faithful to be lost (in the least).

# 465

Of those who answered the call of Allah and the Messenger, even after being wounded, those who do right and refrain from wrong have a great reward;-

# 466

Men said to them: "A great army is gathering against you": And frightened them: But it (only) increased their Faith: They said: "For us Allah sufficeth, and He is the best disposer of affairs."

# 467

And they returned with Grace and bounty from Allah: no harm ever touched them: For they followed the good pleasure of Allah: And Allah is the Lord of bounties unbounded.

# 468

It is only the Evil One that suggests to you the fear of his votaries: Be ye not afraid of them, but fear Me, if ye have Faith.

# 469

Let not those grieve thee who rush headlong into Unbelief: Not the least harm will they do to Allah: Allah's plan is that He will give them no portion in the Hereafter, but a severe punishment.

# 470

Those who purchase Unbelief at the price of faith,- not the least harm will they do to Allah, but they will have a grievous punishment.

# 471

Let not the Unbelievers think that our respite to them is good for themselves: We grant them respite that they may grow in their iniquity: But they will have a shameful punishment.

# 472

Allah will not leave the believers in the state in which ye are now, until He separates what is evil from what is good nor will He disclose to you the secrets of the Unseen. But He chooses of His Messengers (For the purpose) whom He pleases. So believe in Allah. And His messengers: And if ye believe and do right, ye have a reward without measure.

# 473

And let not those who covetously withhold of the gifts which Allah Hath given them of His Grace, think that it is good for them: Nay, it will be the worse for them: soon shall the things which they covetously withheld be tied to their necks Like a twisted collar, on the Day of Judgment. To Allah belongs the heritage of the heavens and the earth; and Allah is well-acquainted with all that ye do.

# 474

Allah hath heard the taunt of those who say: "Truly, Allah is indigent and we are rich!"- We shall certainly record their word and (their act) of slaying the prophets in defiance of right, and We shall say: "Taste ye the penalty of the Scorching Fire!

# 475

"This is because of the (unrighteous deeds) which your hands sent on before ye: For Allah never harms those who serve Him."

# 476

They (also) said: "Allah took our promise not to believe in an messenger unless He showed us a sacrifice consumed by Fire (From heaven)." Say: "There came to you messengers before me, with clear Signs and even with what ye ask for: why then did ye slay them, if ye speak the truth?"

# 477

Then if they reject thee, so were rejected messengers before thee, who came with Clear Signs, Books of dark prophecies, and the Book of Enlightenment.

# 478

Every soul shall have a taste of death: And only on the Day of Judgment shall you be paid your full recompense. Only he who is saved far from the Fire and admitted to the Garden will have attained the object (of Life): For the life of this world is but goods and chattels of deception.

# 479

Ye shall certainly be tried and tested in your possessions and in your personal selves; and ye shall certainly Hear much that will grieve you, from those who received the Book before you and from those who worship many gods. But if ye persevere patiently, and guard against evil,-then that will be a determining factor in all affairs.

# 480

And remember Allah took a covenant from the People of the Book, to make it known and clear to mankind, and not to hide it; but they threw it away behind their backs, and purchased with it some miserable gain! And vile was the bargain they made!

# 481

Think not that those who exult in what they have brought about, and love to be praised for what they have not done,- think escape the penalty. For them is a penalty Grievous indeed.

# 482

To Allah belongeth the dominion of the heavens and the earth; and Allah hath power over all things.

# 483

Behold! in the creation of the heavens and the earth, and the alternation of night and day,- there are indeed Signs for men of understanding,-

# 484

Men who celebrate the praises of Allah, standing, sitting, and lying down on their sides, and contemplate the (wonders of) creation in the heavens and the earth, (With the thought): "Our Lord! not for naught Hast Thou created (all) this! Glory to Thee! Give us salvation from the penalty of the Fire.

# 485

"Our Lord! any whom Thou dost admit to the Fire, Truly Thou coverest with shame, and never will wrong-doers Find any helpers!

# 486

"Our Lord! we have heard the call of one calling (Us) to Faith, 'Believe ye in the Lord,' and we have believed. Our Lord! Forgive us our sins, blot out from us our iniquities, and take to Thyself our souls in the company of the righteous.

# 487

"Our Lord! Grant us what Thou didst promise unto us through Thine messengers, and save us from shame on the Day of Judgment: For Thou never breakest Thy promise."

# 488

And their Lord hath accepted of them, and answered them: "Never will I suffer to be lost the work of any of you, be he male or female: Ye are members, one of another: Those who have left their homes, or been driven out therefrom, or suffered harm in My Cause, or fought or been slain,- verily, I will blot out from them their iniquities, and admit them into Gardens with rivers flowing beneath;- A reward from the presence of Allah, and from His presence is the best of rewards."

# 489

Let not the strutting about of the Unbelievers through the land deceive thee:

# 490

Little is it for enjoyment: Their ultimate abode is Hell: what an evil bed (To lie on)!

# 491

On the other hand, for those who fear their Lord, are Gardens, with rivers flowing beneath; therein are they to dwell (for ever),- a gift from the presence of Allah; and that which is in the presence of Allah is the best (bliss) for the righteous.

# 492

And there are, certainly, among the People of the Book, those who believe in Allah, in the revelation to you, and in the revelation to them, bowing in humility to Allah: They will not sell the Signs of Allah for a miserable gain! For them is a reward with their Lord, and Allah is swift in account.

# 493

O ye who believe! Persevere in patience and constancy; vie in such perseverance; strengthen each other; and fear Allah; that ye may prosper.

# 494

O mankind! reverence your Guardian-Lord, who created you from a single person, created, of like nature, His mate, and from them twain scattered (like seeds) countless men and women;- reverence Allah, through whom ye demand your mutual (rights), and (reverence) the wombs (That bore you): for Allah ever watches over you.

# 495

To orphans restore their property (When they reach their age), nor substitute (your) worthless things for (their) good ones; and devour not their substance (by mixing it up) with your own. For this is indeed a great sin.

# 496

If ye fear that ye shall not be able to deal justly with the orphans, Marry women of your choice, Two or three or four; but if ye fear that ye shall not be able to deal justly (with them), then only one, or (a captive) that your right hands possess, that will be more suitable, to prevent you from doing injustice.

# 497

And give the women (on marriage) their dower as a free gift; but if they, of their own good pleasure, remit any part of it to you, Take it and enjoy it with right good cheer.

# 498

To those weak of understanding Make not over your property, which Allah hath made a means of support for you, but feed and clothe them therewith, and speak to them words of kindness and justice.

# 499

Make trial of orphans until they reach the age of marriage; if then ye find sound judgment in them, release their property to them; but consume it not wastefully, nor in haste against their growing up. If the guardian is well-off, Let him claim no remuneration, but if he is poor, let him have for himself what is just and reasonable. When ye release their property to them, take witnesses in their presence: But all-sufficient is Allah in taking account.

# 500

From what is left by parents and those nearest related there is a share for men and a share for women, whether the property be small or large,-a determinate share.

# 501

But if at the time of division other relatives, or orphans or poor, are present, feed them out of the (property), and speak to them words of kindness and justice.

# 502

Let those (disposing of an estate) have the same fear in their minds as they would have for their own if they had left a helpless family behind: Let them fear Allah, and speak words of appropriate (comfort).

# 503

Those who unjustly eat up the property of orphans, eat up a Fire into their own bodies: They will soon be enduring a Blazing Fire!

# 504

Allah (thus) directs you as regards your Children's (Inheritance): to the male, a portion equal to that of two females: if only daughters, two or more, their share is two-thirds of the inheritance; if only one, her share is a half. For parents, a sixth share of the inheritance to each, if the deceased left children; if no children, and the parents are the (only) heirs, the mother has a third; if the deceased Left brothers (or sisters) the mother has a sixth. (The distribution in all cases ('s) after the payment of legacies and debts. Ye know not whether your parents or your children are nearest to you in benefit. These are settled portions ordained by Allah; and Allah is All-knowing, Al-wise.

# 505

In what your wives leave, your share is a half, if they leave no child; but if they leave a child, ye get a fourth; after payment of legacies and debts. In what ye leave, their share is a fourth, if ye leave no child; but if ye leave a child, they get an eighth; after payment of legacies and debts. If the man or woman whose inheritance is in question, has left neither ascendants nor descendants, but has left a brother or a sister, each one of the two gets a sixth; but if more than two, they share in a third; after payment of legacies and debts; so that no loss is caused (to any one). Thus is it ordained by Allah; and Allah is All-knowing, Most Forbearing.

# 506

Those are limits set by Allah: those who obey Allah and His Messenger will be admitted to Gardens with rivers flowing beneath, to abide therein (for ever) and that will be the supreme achievement.

# 507

But those who disobey Allah and His Messenger and transgress His limits will be admitted to a Fire, to abide therein: And they shall have a humiliating punishment.

# 508

If any of your women are guilty of lewdness, Take the evidence of four (Reliable) witnesses from amongst you against them; and if they testify, confine them to houses until death do claim them, or Allah ordain for them some (other) way.

# 509

If two men among you are guilty of lewdness, punish them both. If they repent and amend, Leave them alone; for Allah is Oft-returning, Most Merciful.

# 510

Allah accept the repentance of those who do evil in ignorance and repent soon afterwards; to them will Allah turn in mercy: For Allah is full of knowledge and wisdom.

# 511

Of no effect is the repentance of those who continue to do evil, until death faces one of them, and he says, "Now have I repented indeed;" nor of those who die rejecting Faith: for them have We prepared a punishment most grievous.

# 512

O ye who believe! Ye are forbidden to inherit women against their will. Nor should ye treat them with harshness, that ye may Take away part of the dower ye have given them,-except where they have been guilty of open lewdness; on the contrary live with them on a footing of kindness and equity. If ye take a dislike to them it may be that ye dislike a thing, and Allah brings about through it a great deal of good.

# 513

But if ye decide to take one wife in place of another, even if ye had given the latter a whole treasure for dower, Take not the least bit of it back: Would ye take it by slander and manifest wrong?

# 514

And how could ye take it when ye have gone in unto each other, and they have Taken from you a solemn covenant?

# 515

And marry not women whom your fathers married,- except what is past: It was shameful and odious,- an abominable custom indeed.

# 516

Prohibited to you (For marriage) are:- Your mothers, daughters, sisters; father's sisters, Mother's sisters; brother's daughters, sister's daughters; foster-mothers (Who gave you suck), foster-sisters; your wives' mothers; your step-daughters under your guardianship, born of your wives to whom ye have gone in,- no prohibition if ye have not gone in;- (Those who have been) wives of your sons proceeding from your loins; and two sisters in wedlock at one and the same time, except for what is past; for Allah is Oft-forgiving, Most Merciful;-

# 517

Also (prohibited are) women already married, except those whom your right hands possess: Thus hath Allah ordained (Prohibitions) against you: Except for these, all others are lawful, provided ye seek (them in marriage) with gifts from your property,- desiring chastity, not lust, seeing that ye derive benefit from them, give them their dowers (at least) as prescribed; but if, after a dower is prescribed, agree Mutually (to vary it), there is no blame on you, and Allah is All-knowing, All-wise.

# 518

If any of you have not the means wherewith to wed free believing women, they may wed believing girls from among those whom your right hands possess: And Allah hath full knowledge about your faith. Ye are one from another: Wed them with the leave of their owners, and give them their dowers, according to what is reasonable: They should be chaste, not lustful, nor taking paramours: when they are taken in wedlock, if they fall into shame, their punishment is half that for free women. This (permission) is for those among you who fear sin; but it is better for you that ye practise self-restraint. And Allah is Oft-forgiving, Most Merciful.

# 519

Allah doth wish to make clear to you and to show you the ordinances of those before you; and (He doth wish to) turn to you (In Mercy): And Allah is All-knowing, All-wise.

# 520

Allah doth wish to Turn to you, but the wish of those who follow their lusts is that ye should turn away (from Him),- far, far away.

# 521

Allah doth wish to lighten your (difficulties): For man was created Weak (in flesh).

# 522

O ye who believe! Eat not up your property among yourselves in vanities: But let there be amongst you Traffic and trade by mutual good-will: Nor kill (or destroy) yourselves: for verily Allah hath been to you Most Merciful!

# 523

If any do that in rancour and injustice,- soon shall We cast them into the Fire: And easy it is for Allah.

# 524

If ye (but) eschew the most heinous of the things which ye are forbidden to do, We shall expel out of you all the evil in you, and admit you to a gate of great honour.

# 525

And in no wise covet those things in which Allah Hath bestowed His gifts More freely on some of you than on others: To men is allotted what they earn, and to women what they earn: But ask Allah of His bounty. For Allah hath full knowledge of all things.

# 526

To (benefit) every one, We have appointed shares and heirs to property left by parents and relatives. To those, also, to whom your right hand was pledged, give their due portion. For truly Allah is witness to all things.

# 527

Men are the protectors and maintainers of women, because Allah has given the one more (strength) than the other, and because they support them from their means. Therefore the righteous women are devoutly obedient, and guard in (the husband's) absence what Allah would have them guard. As to those women on whose part ye fear disloyalty and ill-conduct, admonish them (first), (Next), refuse to share their beds, (And last) beat them (lightly); but if they return to obedience, seek not against them Means (of annoyance): For Allah is Most High, great (above you all).

# 528

If ye fear a breach between them twain, appoint (two) arbiters, one from his family, and the other from hers; if they wish for peace, Allah will cause their reconciliation: For Allah hath full knowledge, and is acquainted with all things.

# 529

Serve Allah, and join not any partners with Him; and do good- to parents, kinsfolk, orphans, those in need, neighbours who are near, neighbours who are strangers, the companion by your side, the wayfarer (ye meet), and what your right hands possess: For Allah loveth not the arrogant, the vainglorious;-

# 530

(Nor) those who are niggardly or enjoin niggardliness on others, or hide the bounties which Allah hath bestowed on them; for We have prepared, for those who resist Faith, a punishment that steeps them in contempt;-

# 531

Not those who spend of their substance, to be seen of men, but have no faith in Allah and the Last Day: If any take the Evil One for their intimate, what a dreadful intimate he is!

# 532

And what burden Were it on them if they had faith in Allah and in the Last Day, and they spent out of what Allah hath given them for sustenance? For Allah hath full knowledge of them.

# 533

Allah is never unjust in the least degree: If there is any good (done), He doubleth it, and giveth from His own presence a great reward.

# 534

How then if We brought from each people a witness, and We brought thee as a witness against these people!

# 535

On that day those who reject Faith and disobey the messenger will wish that the earth Were made one with them: But never will they hide a single fact from Allah!

# 536

O ye who believe! Approach not prayers with a mind befogged, until ye can understand all that ye say,- nor in a state of ceremonial impurity (Except when travelling on the road), until after washing your whole body. If ye are ill, or on a journey, or one of you cometh from offices of nature, or ye have been in contact with women, and ye find no water, then take for yourselves clean sand or earth, and rub therewith your faces and hands. For Allah doth blot out sins and forgive again and again.

# 537

Hast thou not turned Thy vision to those who were given a portion of the Book? they traffic in error, and wish that ye should lose the right path.

# 538

But Allah hath full knowledge of your enemies: Allah is enough for a protector, and Allah is enough for a Helper.

# 539

Of the Jews there are those who displace words from their (right) places, and say: "We hear and we disobey"; and "Hear what is not Heard"; and "Ra'ina"; with a twist of their tongues and a slander to Faith. If only they had said: "What hear and we obey"; and "Do hear"; and "Do look at us"; it would have been better for them, and more proper; but Allah hath cursed them for their Unbelief; and but few of them will believe.

# 540

O ye People of the Book! believe in what We have (now) revealed, confirming what was (already) with you, before We change the face and fame of some (of you) beyond all recognition, and turn them hindwards, or curse them as We cursed the Sabbath-breakers, for the decision of Allah Must be carried out.

# 541

Allah forgiveth not that partners should be set up with Him; but He forgiveth anything else, to whom He pleaseth; to set up partners with Allah is to devise a sin Most heinous indeed.

# 542

Hast thou not turned Thy vision to those who claim sanctity for themselves? Nay-but Allah Doth sanctify whom He pleaseth. But never will they fail to receive justice in the least little thing.

# 543

Behold! how they invent a lie against Allah! but that by itself is a manifest sin!

# 544

Hast thou not turned Thy vision to those who were given a portion of the Book? they believe in sorcery and Evil, and say to the Unbelievers that they are better guided in the (right) way Than the believers!

# 545

They are (men) whom Allah hath cursed: And those whom Allah Hath cursed, thou wilt find, have no one to help.

# 546

Have they a share in dominion or power? Behold, they give not a farthing to their fellow-men?

# 547

Or do they envy mankind for what Allah hath given them of his bounty? but We had already given the people of Abraham the Book and Wisdom, and conferred upon them a great kingdom.

# 548

Some of them believed, and some of them averted their faces from him: And enough is Hell for a burning fire.

# 549

Those who reject our Signs, We shall soon cast into the Fire: as often as their skins are roasted through, We shall change them for fresh skins, that they may taste the penalty: for Allah is Exalted in Power, Wise.

# 550

But those who believe and do deeds of righteousness, We shall soon admit to Gardens, with rivers flowing beneath,- their eternal home: Therein shall they have companions pure and holy: We shall admit them to shades, cool and ever deepening.

# 551

Allah doth command you to render back your Trusts to those to whom they are due; And when ye judge between man and man, that ye judge with justice: Verily how excellent is the teaching which He giveth you! For Allah is He Who heareth and seeth all things.

# 552

O ye who believe! Obey Allah, and obey the Messenger, and those charged with authority among you. If ye differ in anything among yourselves, refer it to Allah and His Messenger, if ye do believe in Allah and the Last Day: That is best, and most suitable for final determination.

# 553

Hast thou not turned Thy vision to those who declare that they believe in the revelations that have come to thee and to those before thee? Their (real) wish is to resort together for judgment (in their disputes) to the Evil One, though they were ordered to reject him. But Satan's wish is to lead them astray far away (from the right).

# 554

When it is said to them: "Come to what Allah hath revealed, and to the Messenger": Thou seest the Hypocrites avert their faces from thee in disgust.

# 555

How then, when they are seized by misfortune, because of the deeds which they hands have sent forth? Then their come to thee, swearing by Allah: "We meant no more than good-will and conciliation!"

# 556

Those men,-Allah knows what is in their hearts; so keep clear of them, but admonish them, and speak to them a word to reach their very souls.

# 557

We sent not a messenger, but to be obeyed, in accordance with the will of Allah. If they had only, when they were unjust to themselves, come unto thee and asked Allah's forgiveness, and the Messenger had asked forgiveness for them, they would have found Allah indeed Oft-returning, Most Merciful.

# 558

But no, by the Lord, they can have no (real) Faith, until they make thee judge in all disputes between them, and find in their souls no resistance against Thy decisions, but accept them with the fullest conviction.

# 559

If We had ordered them to sacrifice their lives or to leave their homes, very few of them would have done it: But if they had done what they were (actually) told, it would have been best for them, and would have gone farthest to strengthen their (faith);

# 560

And We should then have given them from our presence a great reward;

# 561

And We should have shown them the Straight Way.

# 562

All who obey Allah and the messenger are in the company of those on whom is the Grace of Allah,- of the prophets (who teach), the sincere (lovers of Truth), the witnesses (who testify), and the Righteous (who do good): Ah! what a beautiful fellowship!

# 563

Such is the bounty from Allah: And sufficient is it that Allah knoweth all.

# 564

O ye who believe! Take your precautions, and either go forth in parties or go forth all together.

# 565

There are certainly among you men who would tarry behind: If a misfortune befalls you, they say: "Allah did favour us in that we were not present among them."

# 566

But if good fortune comes to you from Allah, they would be sure to say - as if there had never been Ties of affection between you and them - "Oh! I wish I had been with them; a fine thing should I then have made of it!"

# 567

Let those fight in the cause of Allah Who sell the life of this world for the hereafter. To him who fighteth in the cause of Allah,- whether he is slain or gets victory - Soon shall We give him a reward of great (value).

# 568

And why should ye not fight in the cause of Allah and of those who, being weak, are ill-treated (and oppressed)?- Men, women, and children, whose cry is: "Our Lord! Rescue us from this town, whose people are oppressors; and raise for us from Thee one who will protect; and raise for us from Thee one who will help!"

# 569

Those who believe fight in the cause of Allah, and those who reject Faith Fight in the cause of Evil: So fight ye against the friends of Satan: feeble indeed is the cunning of Satan.

# 570

Hast thou not turned Thy vision to those who were told to hold back their hands (from fight) but establish regular prayers and spend in regular charity? When (at length) the order for fighting was issued to them, behold! a section of them feared men as - or even more than - they should have feared Allah: They said: "Our Lord! Why hast Thou ordered us to fight? Wouldst Thou not Grant us respite to our (natural) term, near (enough)?" Say: "Short is the enjoyment of this world: the Hereafter is the best for those who do right: Never will ye be dealt with unjustly in the very least!

# 571

"Wherever ye are, death will find you out, even if ye are in towers built up strong and high!" If some good befalls them, they say, "This is from Allah"; but if evil, they say, "This is from thee" (O Prophet). Say: "All things are from Allah." But what hath come to these people, that they fail to understand a single fact?

# 572

Whatever good, (O man!) happens to thee, is from Allah; but whatever evil happens to thee, is from thy (own) soul. and We have sent thee as a messenger to (instruct) mankind. And enough is Allah for a witness.

# 573

He who obeys the Messenger, obeys Allah: But if any turn away, We have not sent thee to watch over their (evil deeds).

# 574

They have "Obedience" on their lips; but when they leave thee, a section of them Meditate all night on things very different from what thou tellest them. But Allah records their nightly (plots): So keep clear of them, and put thy trust in Allah, and enough is Allah as a disposer of affairs.

# 575

Do they not consider the Qur'an (with care)? Had it been from other Than Allah, they would surely have found therein Much discrepancy.

# 576

When there comes to them some matter touching (Public) safety or fear, they divulge it. If they had only referred it to the Messenger, or to those charged with authority among them, the proper investigators would have Tested it from them (direct). Were it not for the Grace and Mercy of Allah unto you, all but a few of you would have fallen into the clutches of Satan.

# 577

Then fight in Allah's cause - Thou art held responsible only for thyself - and rouse the believers. It may be that Allah will restrain the fury of the Unbelievers; for Allah is the strongest in might and in punishment.

# 578

Whoever recommends and helps a good cause becomes a partner therein: And whoever recommends and helps an evil cause, shares in its burden: And Allah hath power over all things.

# 579

When a (courteous) greeting is offered you, meet it with a greeting still more courteous, or (at least) of equal courtesy. Allah takes careful account of all things.

# 580

Allah! There is no god but He: of a surety He will gather you together against the Day of Judgment, about which there is no doubt. And whose word can be truer than Allah's?

# 581

Why should ye be divided into two parties about the Hypocrites? Allah hath upset them for their (evil) deeds. Would ye guide those whom Allah hath thrown out of the Way? For those whom Allah hath thrown out of the Way, never shalt thou find the Way.

# 582

They but wish that ye should reject Faith, as they do, and thus be on the same footing (as they): But take not friends from their ranks until they flee in the way of Allah (From what is forbidden). But if they turn renegades, seize them and slay them wherever ye find them; and (in any case) take no friends or helpers from their ranks;-

# 583

Except those who join a group between whom and you there is a treaty (of peace), or those who approach you with hearts restraining them from fighting you as well as fighting their own people. If Allah had pleased, He could have given them power over you, and they would have fought you: Therefore if they withdraw from you but fight you not, and (instead) send you (Guarantees of) peace, then Allah Hath opened no way for you (to war against them).

# 584

Others you will find that wish to gain your confidence as well as that of their people: Every time they are sent back to temptation, they succumb thereto: if they withdraw not from you nor give you (guarantees) of peace besides restraining their hands, seize them and slay them wherever ye get them: In their case We have provided you with a clear argument against them.

# 585

Never should a believer kill a believer; but (If it so happens) by mistake, (Compensation is due): If one (so) kills a believer, it is ordained that he should free a believing slave, and pay compensation to the deceased's family, unless they remit it freely. If the deceased belonged to a people at war with you, and he was a believer, the freeing of a believing slave (Is enough). If he belonged to a people with whom ye have treaty of Mutual alliance, compensation should be paid to his family, and a believing slave be freed. For those who find this beyond their means, (is prescribed) a fast for two months running: by way of repentance to Allah: for Allah hath all knowledge and all wisdom.

# 586

If a man kills a believer intentionally, his recompense is Hell, to abide therein (For ever): And the wrath and the curse of Allah are upon him, and a dreadful penalty is prepared for him.

# 587

O ye who believe! When ye go abroad in the cause of Allah, investigate carefully, and say not to any one who offers you a salutation: "Thou art none of a believer!" Coveting the perishable goods of this life: with Allah are profits and spoils abundant. Even thus were ye yourselves before, till Allah conferred on you His favours: Therefore carefully investigate. For Allah is well aware of all that ye do.

# 588

Not equal are those believers who sit (at home) and receive no hurt, and those who strive and fight in the cause of Allah with their goods and their persons. Allah hath granted a grade higher to those who strive and fight with their goods and persons than to those who sit (at home). Unto all (in Faith) Hath Allah promised good: But those who strive and fight Hath He distinguished above those who sit (at home) by a special reward,-

# 589

Ranks specially bestowed by Him, and Forgiveness and Mercy. For Allah is Oft-forgiving, Most Merciful.

# 590

When angels take the souls of those who die in sin against their souls, they say: "In what (plight) Were ye?" They reply: "Weak and oppressed Were we in the earth." They say: "Was not the earth of Allah spacious enough for you to move yourselves away (From evil)?" Such men will find their abode in Hell,- What an evil refuge! -

# 591

Except those who are (really) weak and oppressed - men, women, and children - who have no means in their power, nor (a guide-post) to their way.

# 592

For these, there is hope that Allah will forgive: For Allah doth blot out (sins) and forgive again and again.

# 593

He who forsakes his home in the cause of Allah, finds in the earth Many a refuge, wide and spacious: Should he die as a refugee from home for Allah and His Messenger, His reward becomes due and sure with Allah: And Allah is Oft-forgiving, Most Merciful.

# 594

When ye travel through the earth, there is no blame on you if ye shorten your prayers, for fear the Unbelievers May attack you: For the Unbelievers are unto you open enemies.

# 595

When thou (O Messenger) art with them, and standest to lead them in prayer, Let one party of them stand up (in prayer) with thee, Taking their arms with them: When they finish their prostrations, let them Take their position in the rear. And let the other party come up which hath not yet prayed - and let them pray with thee, Taking all precaution, and bearing arms: the Unbelievers wish, if ye were negligent of your arms and your baggage, to assault you in a single rush. But there is no blame on you if ye put away your arms because of the inconvenience of rain or because ye are ill; but take (every) precaution for yourselves. For the Unbelievers Allah hath prepared a humiliating punishment.

# 596

When ye pass (Congregational) prayers, celebrate Allah's praises, standing, sitting down, or lying down on your sides; but when ye are free from danger, set up Regular Prayers: For such prayers are enjoined on believers at stated times.

# 597

And slacken not in following up the enemy: If ye are suffering hardships, they are suffering similar hardships; but ye have Hope from Allah, while they have none. And Allah is full of knowledge and wisdom.

# 598

We have sent down to thee the Book in truth, that thou mightest judge between men, as guided by Allah: so be not (used) as an advocate by those who betray their trust;

# 599

But seek the forgiveness of Allah; for Allah is Oft-forgiving, Most Merciful.

# 600

Contend not on behalf of such as betray their own souls; for Allah loveth not one given to perfidy and crime:

# 601

They may hide (Their crimes) from men, but they cannot hide (Them) from Allah, seeing that He is in their midst when they plot by night, in words that He cannot approve: And Allah Doth compass round all that they do.

# 602

Ah! These are the sort of men on whose behalf ye may contend in this world; but who will contend with Allah on their behalf on the Day of Judgment, or who will carry their affairs through?

# 603

If any one does evil or wrongs his own soul but afterwards seeks Allah's forgiveness, he will find Allah Oft-forgiving, Most Merciful.

# 604

And if any one earns sin. he earns it against His own soul: for Allah is full of knowledge and wisdom.

# 605

But if any one earns a fault or a sin and throws it on to one that is innocent, He carries (on himself) (Both) a falsehood and a flagrant sin.

# 606

But for the Grace of Allah to thee and his Mercy, a party of them would certainly have plotted to lead thee astray. But (in fact) they will only Lead their own souls astray, and to thee they can do no harm in the least. For Allah hath sent down to thee the Book and wisdom and taught thee what thou Knewest not (before): And great is the Grace of Allah unto thee.

# 607

In most of their secret talks there is no good: But if one exhorts to a deed of charity or justice or conciliation between men, (Secrecy is permissible): To him who does this, seeking the good pleasure of Allah, We shall soon give a reward of the highest (value).

# 608

If anyone contends with the Messenger even after guidance has been plainly conveyed to him, and follows a path other than that becoming to men of Faith, We shall leave him in the path he has chosen, and land him in Hell,- what an evil refuge!

# 609

Allah forgiveth not (The sin of) joining other gods with Him; but He forgiveth whom He pleaseth other sins than this: one who joins other gods with Allah, Hath strayed far, far away (from the right).

# 610

(The Pagans), leaving Him, call but upon female deities: They call but upon satan the persistent rebel!

# 611

Allah did curse him, but he said: "I will take of Thy servants a portion Marked off;

# 612

"I will mislead them, and I will create in them false desires; I will order them to slit the ears of cattle, and to deface the (fair) nature created by Allah." Whoever, forsaking Allah, takes satan for a friend, hath of a surety suffered a loss that is manifest.

# 613

Satan makes them promises, and creates in them false desires; but satan's promises are nothing but deception.

# 614

They (his dupes) will have their dwelling in Hell, and from it they will find no way of escape.

# 615

But those who believe and do deeds of righteousness,- we shall soon admit them to gardens, with rivers flowing beneath,-to dwell therein for ever. Allah's promise is the truth, and whose word can be truer than Allah's?

# 616

Not your desires, nor those of the People of the Book (can prevail): whoever works evil, will be requited accordingly. Nor will he find, besides Allah, any protector or helper.

# 617

If any do deeds of righteousness,- be they male or female - and have faith, they will enter Heaven, and not the least injustice will be done to them.

# 618

Who can be better in religion than one who submits his whole self to Allah, does good, and follows the way of Abraham the true in Faith? For Allah did take Abraham for a friend.

# 619

But to Allah belong all things in the heavens and on earth: And He it is that Encompasseth all things.

# 620

They ask thy instruction concerning the women say: Allah doth instruct you about them: And (remember) what hath been rehearsed unto you in the Book, concerning the orphans of women to whom ye give not the portions prescribed, and yet whom ye desire to marry, as also concerning the children who are weak and oppressed: that ye stand firm for justice to orphans. There is not a good deed which ye do, but Allah is well-acquainted therewith.

# 621

If a wife fears cruelty or desertion on her husband's part, there is no blame on them if they arrange an amicable settlement between themselves; and such settlement is best; even though men's souls are swayed by greed. But if ye do good and practise self-restraint, Allah is well-acquainted with all that ye do.

# 622

Ye are never able to be fair and just as between women, even if it is your ardent desire: But turn not away (from a woman) altogether, so as to leave her (as it were) hanging (in the air). If ye come to a friendly understanding, and practise self-restraint, Allah is Oft-forgiving, Most Merciful.

# 623

But if they disagree (and must part), Allah will provide abundance for all from His all-reaching bounty: for Allah is He that careth for all and is Wise.

# 624

To Allah belong all things in the heavens and on earth. Verily we have directed the People of the Book before you, and you (o Muslims) to fear Allah. But if ye deny Him, lo! unto Allah belong all things in the heavens and on earth, and Allah is free of all wants, worthy of all praise.

# 625

Yea, unto Allah belong all things in the heavens and on earth, and enough is Allah to carry through all affairs.

# 626

If it were His will, He could destroy you, o mankind, and create another race; for He hath power this to do.

# 627

If any one desires a reward in this life, in Allah's (gift) is the reward (both) of this life and of the hereafter: for Allah is He that heareth and seeth (all things).

# 628

O ye who believe! stand out firmly for justice, as witnesses to Allah, even as against yourselves, or your parents, or your kin, and whether it be (against) rich or poor: for Allah can best protect both. Follow not the lusts (of your hearts), lest ye swerve, and if ye distort (justice) or decline to do justice, verily Allah is well-acquainted with all that ye do.

# 629

O ye who believe! Believe in Allah and His Messenger, and the scripture which He hath sent to His Messenger and the scripture which He sent to those before (him). Any who denieth Allah, His angels, His Books, His Messengers, and the Day of Judgment, hath gone far, far astray.

# 630

Those who believe, then reject faith, then believe (again) and (again) reject faith, and go on increasing in unbelief,- Allah will not forgive them nor guide them nor guide them on the way.

# 631

To the Hypocrites give the glad tidings that there is for them (but) a grievous penalty;-

# 632

Yea, to those who take for friends unbelievers rather than believers: is it honour they seek among them? Nay,- all honour is with Allah.

# 633

Already has He sent you Word in the Book, that when ye hear the signs of Allah held in defiance and ridicule, ye are not to sit with them unless they turn to a different theme: if ye did, ye would be like them. For Allah will collect the hypocrites and those who defy faith - all in Hell:-

# 634

(These are) the ones who wait and watch about you: if ye do gain a victory from Allah, they say: "Were we not with you?"- but if the unbelievers gain a success, they say (to them): "Did we not gain an advantage over you, and did we not guard you from the believers?" but Allah will judge betwixt you on the Day of Judgment. And never will Allah grant to the unbelievers a way (to triumphs) over the believers.

# 635

The Hypocrites - they think they are over-reaching Allah, but He will over-reach them: When they stand up to prayer, they stand without earnestness, to be seen of men, but little do they hold Allah in remembrance;

# 636

(They are) distracted in mind even in the midst of it,- being (sincerely) for neither one group nor for another whom Allah leaves straying,- never wilt thou find for him the way.

# 637

O ye who believe! Take not for friends unbelievers rather than believers: Do ye wish to offer Allah an open proof against yourselves?

# 638

The Hypocrites will be in the lowest depths of the Fire: no helper wilt thou find for them;-

# 639

Except for those who repent, mend (their lives) hold fast to Allah, and purify their religion as in Allah's sight: if so they will be (numbered) with the believers. And soon will Allah grant to the believers a reward of immense value.

# 640

What can Allah gain by your punishment, if ye are grateful and ye believe? Nay, it is Allah that recogniseth (all good), and knoweth all things.

# 641

Allah loveth not that evil should be noised abroad in public speech, except where injustice hath been done; for Allah is He who heareth and knoweth all things.

# 642

Whether ye publish a good deed or conceal it or cover evil with pardon, verily Allah doth blot out (sins) and hath power (in the judgment of values).

# 643

Those who deny Allah and His messengers, and (those who) wish to separate Allah from His messengers, saying: "We believe in some but reject others": And (those who) wish to take a course midway,-

# 644

They are in truth (equally) unbelievers; and we have prepared for unbelievers a humiliating punishment.

# 645

To those who believe in Allah and His messengers and make no distinction between any of the messengers, we shall soon give their (due) rewards: for Allah is Oft-forgiving, Most Merciful.

# 646

The people of the Book ask thee to cause a book to descend to them from heaven: Indeed they asked Moses for an even greater (miracle), for they said: "Show us Allah in public," but they were dazed for their presumption, with thunder and lightning. Yet they worshipped the calf even after clear signs had come to them; even so we forgave them; and gave Moses manifest proofs of authority.

# 647

And for their covenant we raised over them (the towering height) of Mount (Sinai); and (on another occasion) we said: "Enter the gate with humility"; and (once again) we commanded them: "Transgress not in the matter of the sabbath." And we took from them a solemn covenant.

# 648

(They have incurred divine displeasure): In that they broke their covenant; that they rejected the signs of Allah; that they slew the Messengers in defiance of right; that they said, "Our hearts are the wrappings (which preserve Allah's Word; We need no more)";- Nay, Allah hath set the seal on their hearts for their blasphemy, and little is it they believe;-

# 649

That they rejected Faith; that they uttered against Mary a grave false charge;

# 650

That they said (in boast), "We killed Christ Jesus the son of Mary, the Messenger of Allah";- but they killed him not, nor crucified him, but so it was made to appear to them, and those who differ therein are full of doubts, with no (certain) knowledge, but only conjecture to follow, for of a surety they killed him not:-

# 651

Nay, Allah raised him up unto Himself; and Allah is Exalted in Power, Wise;-

# 652

And there is none of the People of the Book but must believe in him before his death; and on the Day of Judgment he will be a witness against them;-

# 653

For the iniquity of the Jews We made unlawful for them certain (foods) good and wholesome which had been lawful for them;- in that they hindered many from Allah's Way;-

# 654

That they took usury, though they were forbidden; and that they devoured men's substance wrongfully;- we have prepared for those among them who reject faith a grievous punishment.

# 655

But those among them who are well-grounded in knowledge, and the believers, believe in what hath been revealed to thee and what was revealed before thee: And (especially) those who establish regular prayer and practise regular charity and believe in Allah and in the Last Day: To them shall We soon give a great reward.

# 656

We have sent thee inspiration, as We sent it to Noah and the Messengers after him: we sent inspiration to Abraham, Isma'il, Isaac, Jacob and the Tribes, to Jesus, Job, Jonah, Aaron, and solomon, and to David We gave the Psalms.

# 657

Of some messengers We have already told thee the story; of others We have not;- and to Moses Allah spoke direct;-

# 658

Messengers who gave good news as well as warning, that mankind, after (the coming) of the messengers, should have no plea against Allah: For Allah is Exalted in Power, Wise.

# 659

But Allah beareth witness that what He hath sent unto thee He hath sent from His (own) knowledge, and the angels bear witness: But enough is Allah for a witness.

# 660

Those who reject Faith and keep off (men) from the way of Allah, have verily strayed far, far away from the Path.

# 661

Those who reject Faith and do wrong,- Allah will not forgive them nor guide them to any way-

# 662

Except the way of Hell, to dwell therein for ever. And this to Allah is easy.

# 663

O Mankind! The Messenger hath come to you in truth from Allah: believe in him: It is best for you. But if ye reject Faith, to Allah belong all things in the heavens and on earth: And Allah is All-knowing, All-wise.

# 664

O People of the Book! Commit no excesses in your religion: Nor say of Allah aught but the truth. Christ Jesus the son of Mary was (no more than) a messenger of Allah, and His Word, which He bestowed on Mary, and a spirit proceeding from Him: so believe in Allah and His messengers. Say not "Trinity": desist: it will be better for you: for Allah is one Allah: Glory be to Him: (far exalted is He) above having a son. To Him belong all things in the heavens and on earth. And enough is Allah as a Disposer of affairs.

# 665

Christ disdaineth nor to serve and worship Allah, nor do the angels, those nearest (to Allah): those who disdain His worship and are arrogant,-He will gather them all together unto Himself to (answer).

# 666

But to those who believe and do deeds of righteousness, He will give their (due) rewards,- and more, out of His bounty: But those who are disdainful and arrogant, He will punish with a grievous penalty; Nor will they find, besides Allah, any to protect or help them.

# 667

O mankind! verily there hath come to you a convincing proof from your Lord: For We have sent unto you a light (that is) manifest.

# 668

Then those who believe in Allah, and hold fast to Him,- soon will He admit them to mercy and grace from Himself, and guide them to Himself by a straight way.

# 669

They ask thee for a legal decision. Say: Allah directs (thus) about those who leave no descendants or ascendants as heirs. If it is a man that dies, leaving a sister but no child, she shall have half the inheritance: If (such a deceased was) a woman, who left no child, Her brother takes her inheritance: If there are two sisters, they shall have two-thirds of the inheritance (between them): if there are brothers and sisters, (they share), the male having twice the share of the female. Thus doth Allah make clear to you (His law), lest ye err. And Allah hath knowledge of all things.

# 670

O ye who believe! fulfil (all) obligations. Lawful unto you (for food) are all four-footed animals, with the exceptions named: But animals of the chase are forbidden while ye are in the sacred precincts or in pilgrim garb: for Allah doth command according to His will and plan.

# 671

O ye who believe! Violate not the sanctity of the symbols of Allah, nor of the sacred month, nor of the animals brought for sacrifice, nor the garlands that mark out such animals, nor the people resorting to the sacred house, seeking of the bounty and good pleasure of their Lord. But when ye are clear of the sacred precincts and of pilgrim garb, ye may hunt and let not the hatred of some people in (once) shutting you out of the Sacred Mosque lead you to transgression (and hostility on your part). Help ye one another in righteousness and piety, but help ye not one another in sin and rancour: fear Allah: for Allah is strict in punishment.

# 672

Forbidden to you (for food) are: dead meat, blood, the flesh of swine, and that on which hath been invoked the name of other than Allah; that which hath been killed by strangling, or by a violent blow, or by a headlong fall, or by being gored to death; that which hath been (partly) eaten by a wild animal; unless ye are able to slaughter it (in due form); that which is sacrificed on stone (altars); (forbidden) also is the division (of meat) by raffling with arrows: that is impiety. This day have those who reject faith given up all hope of your religion: yet fear them not but fear Me. This day have I perfected your religion for you, completed My favour upon you, and have chosen for you Islam as your religion. But if any is forced by hunger, with no inclination to transgression, Allah is indeed Oft-forgiving, Most Merciful.

# 673

They ask thee what is lawful to them (as food). Say: lawful unto you are (all) things good and pure: and what ye have taught your trained hunting animals (to catch) in the manner directed to you by Allah: eat what they catch for you, but pronounce the name of Allah over it: and fear Allah; for Allah is swift in taking account.

# 674

This day are (all) things good and pure made lawful unto you. The food of the People of the Book is lawful unto you and yours is lawful unto them. (Lawful unto you in marriage) are (not only) chaste women who are believers, but chaste women among the People of the Book, revealed before your time,- when ye give them their due dowers, and desire chastity, not lewdness, nor secret intrigues if any one rejects faith, fruitless is his work, and in the Hereafter he will be in the ranks of those who have lost (all spiritual good).

# 675

O ye who believe! when ye prepare for prayer, wash your faces, and your hands (and arms) to the elbows; Rub your heads (with water); and (wash) your feet to the ankles. If ye are in a state of ceremonial impurity, bathe your whole body. But if ye are ill, or on a journey, or one of you cometh from offices of nature, or ye have been in contact with women, and ye find no water, then take for yourselves clean sand or earth, and rub therewith your faces and hands, Allah doth not wish to place you in a difficulty, but to make you clean, and to complete his favour to you, that ye may be grateful.

# 676

And call in remembrance the favour of Allah unto you, and His covenant, which He ratified with you, when ye said: "We hear and we obey": And fear Allah, for Allah knoweth well the secrets of your hearts.

# 677

O ye who believe! stand out firmly for Allah, as witnesses to fair dealing, and let not the hatred of others to you make you swerve to wrong and depart from justice. Be just: that is next to piety: and fear Allah. For Allah is well-acquainted with all that ye do.

# 678

To those who believe and do deeds of righteousness hath Allah promised forgiveness and a great reward.

# 679

Those who reject faith and deny our signs will be companions of Hell-fire.

# 680

O ye who believe! Call in remembrance the favour of Allah unto you when certain men formed the design to stretch out their hands against you, but (Allah) held back their hands from you: so fear Allah. And on Allah let believers put (all) their trust.

# 681

Allah did aforetime take a covenant from the Children of Israel, and we appointed twelve captains among them. And Allah said: "I am with you: if ye (but) establish regular prayers, practise regular charity, believe in my messengers, honour and assist them, and loan to Allah a beautiful loan, verily I will wipe out from you your evils, and admit you to gardens with rivers flowing beneath; but if any of you, after this, resisteth faith, he hath truly wandered from the path or rectitude."

# 682

But because of their breach of their covenant, We cursed them, and made their hearts grow hard; they change the words from their (right) places and forget a good part of the message that was sent them, nor wilt thou cease to find them- barring a few - ever bent on (new) deceits: but forgive them, and overlook (their misdeeds): for Allah loveth those who are kind.

# 683

From those, too, who call themselves Christians, We did take a covenant, but they forgot a good part of the message that was sent them: so we estranged them, with enmity and hatred between the one and the other, to the day of judgment. And soon will Allah show them what it is they have done.

# 684

O people of the Book! There hath come to you our Messenger, revealing to you much that ye used to hide in the Book, and passing over much (that is now unnecessary): There hath come to you from Allah a (new) light and a perspicuous Book, -

# 685

Wherewith Allah guideth all who seek His good pleasure to ways of peace and safety, and leadeth them out of darkness, by His will, unto the light,- guideth them to a path that is straight.

# 686

In blasphemy indeed are those that say that Allah is Christ the son of Mary. Say: "Who then hath the least power against Allah, if His will were to destroy Christ the son of Mary, his mother, and all every - one that is on the earth? For to Allah belongeth the dominion of the heavens and the earth, and all that is between. He createth what He pleaseth. For Allah hath power over all things."

# 687

(Both) the Jews and the Christians say: "We are sons of Allah, and his beloved." Say: "Why then doth He punish you for your sins? Nay, ye are but men,- of the men he hath created: He forgiveth whom He pleaseth, and He punisheth whom He pleaseth: and to Allah belongeth the dominion of the heavens and the earth, and all that is between: and unto Him is the final goal (of all)"

# 688

O People of the Book! Now hath come unto you, making (things) clear unto you, Our Messenger, after the break in (the series of) our messengers, lest ye should say: "There came unto us no bringer of glad tidings and no warner (from evil)": But now hath come unto you a bringer of glad tidings and a warner (from evil). And Allah hath power over all things.

# 689

Remember Moses said to his people: "O my people! Call in remembrance the favour of Allah unto you, when He produced prophets among you, made you kings, and gave you what He had not given to any other among the peoples.

# 690

"O my people! Enter the holy land which Allah hath assigned unto you, and turn not back ignominiously, for then will ye be overthrown, to your own ruin."

# 691

They said: "O Moses! In this land are a people of exceeding strength: Never shall we enter it until they leave it: if (once) they leave, then shall we enter."

# 692

(But) among (their) Allah-fearing men were two on whom Allah had bestowed His grace: They said: "Assault them at the (proper) Gate: when once ye are in, victory will be yours; But on Allah put your trust if ye have faith."

# 693

They said: "O Moses! while they remain there, never shall we be able to enter, to the end of time. Go thou, and thy Lord, and fight ye two, while we sit here (and watch)."

# 694

He said: "O my Lord! I have power only over myself and my brother: so separate us from this rebellious people!"

# 695

Allah said: "Therefore will the land be out of their reach for forty years: In distraction will they wander through the land: But sorrow thou not over these rebellious people.

# 696

Recite to them the truth of the story of the two sons of Adam. Behold! they each presented a sacrifice (to Allah): It was accepted from one, but not from the other. Said the latter: "Be sure I will slay thee." "Surely," said the former, "Allah doth accept of the sacrifice of those who are righteous.

# 697

"If thou dost stretch thy hand against me, to slay me, it is not for me to stretch my hand against thee to slay thee: for I do fear Allah, the cherisher of the worlds.

# 698

"For me, I intend to let thee draw on thyself my sin as well as thine, for thou wilt be among the companions of the fire, and that is the reward of those who do wrong."

# 699

The (selfish) soul of the other led him to the murder of his brother: he murdered him, and became (himself) one of the lost ones.

# 700

Then Allah sent a raven, who scratched the ground, to show him how to hide the shame of his brother. "Woe is me!" said he; "Was I not even able to be as this raven, and to hide the shame of my brother?" then he became full of regrets-

# 701

On that account: We ordained for the Children of Israel that if any one slew a person - unless it be for murder or for spreading mischief in the land - it would be as if he slew the whole people: and if any one saved a life, it would be as if he saved the life of the whole people. Then although there came to them Our messengers with clear signs, yet, even after that, many of them continued to commit excesses in the land.

# 702

The punishment of those who wage war against Allah and His Messenger, and strive with might and main for mischief through the land is: execution, or crucifixion, or the cutting off of hands and feet from opposite sides, or exile from the land: that is their disgrace in this world, and a heavy punishment is theirs in the Hereafter;

# 703

Except for those who repent before they fall into your power: in that case, know that Allah is Oft-forgiving, Most Merciful.

# 704

O ye who believe! Do your duty to Allah, seek the means of approach unto Him, and strive with might and main in his cause: that ye may prosper.

# 705

As to those who reject Faith,- if they had everything on earth, and twice repeated, to give as ransom for the penalty of the Day of Judgment, it would never be accepted of them, theirs would be a grievous penalty.

# 706

Their wish will be to get out of the Fire, but never will they get out therefrom: their penalty will be one that endures.

# 707

As to the thief, Male or female, cut off his or her hands: a punishment by way of example, from Allah, for their crime: and Allah is Exalted in power.

# 708

But if the thief repents after his crime, and amends his conduct, Allah turneth to him in forgiveness; for Allah is Oft-forgiving, Most Merciful.

# 709

Knowest thou not that to Allah (alone) belongeth the dominion of the heavens and the earth? He punisheth whom He pleaseth, and He forgiveth whom He pleaseth: and Allah hath power over all things.

# 710

O Messenger! let not those grieve thee, who race each other into unbelief: (whether it be) among those who say "We believe" with their lips but whose hearts have no faith; or it be among the Jews,- men who will listen to any lie,- will listen even to others who have never so much as come to thee. They change the words from their (right) times and places: they say, "If ye are given this, take it, but if not, beware!" If any one's trial is intended by Allah, thou hast no authority in the least for him against Allah. For such - it is not Allah's will to purify their hearts. For them there is disgrace in this world, and in the Hereafter a heavy punishment.

# 711

(They are fond of) listening to falsehood, of devouring anything forbidden. If they do come to thee, either judge between them, or decline to interfere. If thou decline, they cannot hurt thee in the least. If thou judge, judge in equity between them. For Allah loveth those who judge in equity.

# 712

But why do they come to thee for decision, when they have (their own) law before them?- therein is the (plain) command of Allah; yet even after that, they would turn away. For they are not (really) People of Faith.

# 713

It was We who revealed the law (to Moses): therein was guidance and light. By its standard have been judged the Jews, by the prophets who bowed (as in Islam) to Allah's will, by the rabbis and the doctors of law: for to them was entrusted the protection of Allah's book, and they were witnesses thereto: therefore fear not men, but fear me, and sell not my signs for a miserable price. If any do fail to judge by (the light of) what Allah hath revealed, they are (no better than) Unbelievers.

# 714

We ordained therein for them: "Life for life, eye for eye, nose or nose, ear for ear, tooth for tooth, and wounds equal for equal." But if any one remits the retaliation by way of charity, it is an act of atonement for himself. And if any fail to judge by (the light of) what Allah hath revealed, they are (No better than) wrong-doers.

# 715

And in their footsteps We sent Jesus the son of Mary, confirming the Law that had come before him: We sent him the Gospel: therein was guidance and light, and confirmation of the Law that had come before him: a guidance and an admonition to those who fear Allah.

# 716

Let the people of the Gospel judge by what Allah hath revealed therein. If any do fail to judge by (the light of) what Allah hath revealed, they are (no better than) those who rebel.

# 717

To thee We sent the Scripture in truth, confirming the scripture that came before it, and guarding it in safety: so judge between them by what Allah hath revealed, and follow not their vain desires, diverging from the Truth that hath come to thee. To each among you have we prescribed a law and an open way. If Allah had so willed, He would have made you a single people, but (His plan is) to test you in what He hath given you: so strive as in a race in all virtues. The goal of you all is to Allah; it is He that will show you the truth of the matters in which ye dispute;

# 718

And this (He commands): Judge thou between them by what Allah hath revealed, and follow not their vain desires, but beware of them lest they beguile thee from any of that (teaching) which Allah hath sent down to thee. And if they turn away, be assured that for some of their crime it is Allah's purpose to punish them. And truly most men are rebellious.

# 719

Do they then seek after a judgment of (the days of) ignorance? But who, for a people whose faith is assured, can give better judgment than Allah?

# 720

O ye who believe! take not the Jews and the Christians for your friends and protectors: They are but friends and protectors to each other. And he amongst you that turns to them (for friendship) is of them. Verily Allah guideth not a people unjust.

# 721

Those in whose hearts is a disease - thou seest how eagerly they run about amongst them, saying: "We do fear lest a change of fortune bring us disaster." Ah! perhaps Allah will give (thee) victory, or a decision according to His will. Then will they repent of the thoughts which they secretly harboured in their hearts.

# 722

And those who believe will say: "Are these the men who swore their strongest oaths by Allah, that they were with you?" All that they do will be in vain, and they will fall into (nothing but) ruin.

# 723

O ye who believe! if any from among you turn back from his Faith, soon will Allah produce a people whom He will love as they will love Him,- lowly with the believers, mighty against the rejecters, fighting in the way of Allah, and never afraid of the reproaches of such as find fault. That is the grace of Allah, which He will bestow on whom He pleaseth. And Allah encompasseth all, and He knoweth all things.

# 724

Your (real) friends are (no less than) Allah, His Messenger, and the (fellowship of) believers,- those who establish regular prayers and regular charity, and they bow down humbly (in worship).

# 725

As to those who turn (for friendship) to Allah, His Messenger, and the (fellowship of) believers,- it is the fellowship of Allah that must certainly triumph.

# 726

O ye who believe! take not for friends and protectors those who take your religion for a mockery or sport,- whether among those who received the Scripture before you, or among those who reject Faith; but fear ye Allah, if ye have faith (indeed).

# 727

When ye proclaim your call to prayer they take it (but) as mockery and sport; that is because they are a people without understanding.

# 728

Say: "O people of the Book! Do ye disapprove of us for no other reason than that we believe in Allah, and the revelation that hath come to us and that which came before (us), and (perhaps) that most of you are rebellious and disobedient?"

# 729

Say: "Shall I point out to you something much worse than this, (as judged) by the treatment it received from Allah? those who incurred the curse of Allah and His wrath, those of whom some He transformed into apes and swine, those who worshipped evil;- these are (many times) worse in rank, and far more astray from the even path!"

# 730

When they come to thee, they say: "We believe": but in fact they enter with a mind against Faith, and they go out with the same but Allah knoweth fully all that they hide.

# 731

Many of them dost thou see, racing each other in sin and rancour, and their eating of things forbidden. Evil indeed are the things that they do.

# 732

Why do not the rabbis and the doctors of Law forbid them from their (habit of) uttering sinful words and eating things forbidden? Evil indeed are their works.

# 733

The Jews say: "Allah's hand is tied up." Be their hands tied up and be they accursed for the (blasphemy) they utter. Nay, both His hands are widely outstretched: He giveth and spendeth (of His bounty) as He pleaseth. But the revelation that cometh to thee from Allah increaseth in most of them their obstinate rebellion and blasphemy. Amongst them we have placed enmity and hatred till the Day of Judgment. Every time they kindle the fire of war, Allah doth extinguish it; but they (ever) strive to do mischief on earth. And Allah loveth not those who do mischief.

# 734

If only the People of the Book had believed and been righteous, We should indeed have blotted out their iniquities and admitted them to gardens of bliss.

# 735

If only they had stood fast by the Law, the Gospel, and all the revelation that was sent to them from their Lord, they would have enjoyed happiness from every side. There is from among them a party on the right course: but many of them follow a course that is evil.

# 736

O Messenger! proclaim the (message) which hath been sent to thee from thy Lord. If thou didst not, thou wouldst not have fulfilled and proclaimed His mission. And Allah will defend thee from men (who mean mischief). For Allah guideth not those who reject Faith.

# 737

Say: "O People of the Book! ye have no ground to stand upon unless ye stand fast by the Law, the Gospel, and all the revelation that has come to you from your Lord." It is the revelation that cometh to thee from thy Lord, that increaseth in most of them their obstinate rebellion and blasphemy. But sorrow thou not over (these) people without Faith.

# 738

Those who believe (in the Qur'an), those who follow the Jewish (scriptures), and the Sabians and the Christians,- any who believe in Allah and the Last Day, and work righteousness,- on them shall be no fear, nor shall they grieve.

# 739

We took the covenant of the Children of Israel and sent them messengers, every time, there came to them a messenger with what they themselves desired not - some (of these) they called impostors, and some they (go so far as to) slay.

# 740

They thought there would be no trial (or punishment); so they became blind and deaf; yet Allah (in mercy) turned to them; yet again many of them became blind and deaf. But Allah sees well all that they do.

# 741

They do blaspheme who say: "Allah is Christ the son of Mary." But said Christ: "O Children of Israel! worship Allah, my Lord and your Lord." Whoever joins other gods with Allah,- Allah will forbid him the garden, and the Fire will be his abode. There will for the wrong-doers be no one to help.

# 742

They do blaspheme who say: Allah is one of three in a Trinity: for there is no god except One Allah. If they desist not from their word (of blasphemy), verily a grievous penalty will befall the blasphemers among them.

# 743

Why turn they not to Allah, and seek His forgiveness? For Allah is Oft-forgiving, Most Merciful.

# 744

Christ the son of Mary was no more than a messenger; many were the messengers that passed away before him. His mother was a woman of truth. They had both to eat their (daily) food. See how Allah doth make His signs clear to them; yet see in what ways they are deluded away from the truth!

# 745

Say: "Will ye worship, besides Allah, something which hath no power either to harm or benefit you? But Allah,- He it is that heareth and knoweth all things."

# 746

Say: "O people of the Book! exceed not in your religion the bounds (of what is proper), trespassing beyond the truth, nor follow the vain desires of people who went wrong in times gone by,- who misled many, and strayed (themselves) from the even way.

# 747

Curses were pronounced on those among the Children of Israel who rejected Faith, by the tongue of David and of Jesus the son of Mary: because they disobeyed and persisted in excesses.

# 748

Nor did they (usually) forbid one another the iniquities which they committed: evil indeed were the deeds which they did.

# 749

Thou seest many of them turning in friendship to the Unbelievers. Evil indeed are (the works) which their souls have sent forward before them (with the result), that Allah's wrath is on them, and in torment will they abide.

# 750

If only they had believed in Allah, in the Prophet, and in what hath been revealed to him, never would they have taken them for friends and protectors, but most of them are rebellious wrong-doers.

# 751

Strongest among men in enmity to the believers wilt thou find the Jews and Pagans; and nearest among them in love to the believers wilt thou find those who say, "We are Christians": because amongst these are men devoted to learning and men who have renounced the world, and they are not arrogant.

# 752

And when they listen to the revelation received by the Messenger, thou wilt see their eyes overflowing with tears, for they recognise the truth: they pray: "Our Lord! we believe; write us down among the witnesses.

# 753

"What cause can we have not to believe in Allah and the truth which has come to us, seeing that we long for our Lord to admit us to the company of the righteous?"

# 754

And for this their prayer hath Allah rewarded them with gardens, with rivers flowing underneath,- their eternal home. Such is the recompense of those who do good.

# 755

But those who reject Faith and belie our Signs,- they shall be companions of Hell-fire.

# 756

O ye who believe! make not unlawful the good things which Allah hath made lawful for you, but commit no excess: for Allah loveth not those given to excess.

# 757

Eat of the things which Allah hath provided for you, lawful and good; but fear Allah, in Whom ye believe.

# 758

Allah will not call you to account for what is futile in your oaths, but He will call you to account for your deliberate oaths: for expiation, feed ten indigent persons, on a scale of the average for the food of your families; or clothe them; or give a slave his freedom. If that is beyond your means, fast for three days. That is the expiation for the oaths ye have sworn. But keep to your oaths. Thus doth Allah make clear to you His signs, that ye may be grateful.

# 759

O ye who believe! Intoxicants and gambling, (dedication of) stones, and (divination by) arrows, are an abomination,- of Satan's handwork: eschew such (abomination), that ye may prosper.

# 760

Satan's plan is (but) to excite enmity and hatred between you, with intoxicants and gambling, and hinder you from the remembrance of Allah, and from prayer: will ye not then abstain?

# 761

Obey Allah, and obey the Messenger, and beware (of evil): if ye do turn back, know ye that it is Our Messenger's duty to proclaim (the message) in the clearest manner.

# 762

On those who believe and do deeds of righteousness there is no blame for what they ate (in the past), when they guard themselves from evil, and believe, and do deeds of righteousness,- (or) again, guard themselves from evil and believe,- (or) again, guard themselves from evil and do good. For Allah loveth those who do good.

# 763

O ye who believe! Allah doth but make a trial of you in a little matter of game well within reach of game well within reach of your hands and your lances, that He may test who feareth him unseen: any who transgress thereafter, will have a grievous penalty.

# 764

O ye who believe! Kill not game while in the sacred precincts or in pilgrim garb. If any of you doth so intentionally, the compensation is an offering, brought to the Ka'ba, of a domestic animal equivalent to the one he killed, as adjudged by two just men among you; or by way of atonement, the feeding of the indigent; or its equivalent in fasts: that he may taste of the penalty of his deed. Allah forgives what is past: for repetition Allah will exact from him the penalty. For Allah is Exalted, and Lord of Retribution.

# 765

Lawful to you is the pursuit of water-game and its use for food,- for the benefit of yourselves and those who travel; but forbidden is the pursuit of land-game;- as long as ye are in the sacred precincts or in pilgrim garb. And fear Allah, to Whom ye shall be gathered back.

# 766

Allah made the Ka'ba, the Sacred House, an asylum of security for men, as also the Sacred Months, the animals for offerings, and the garlands that mark them: That ye may know that Allah hath knowledge of what is in the heavens and on earth and that Allah is well acquainted with all things.

# 767

Know ye that Allah is strict in punishment and that Allah is Oft-forgiving, Most Merciful.

# 768

The Messenger's duty is but to proclaim (the message). But Allah knoweth all that ye reveal and ye conceal.

# 769

Say: "Not equal are things that are bad and things that are good, even though the abundance of the bad may dazzle thee; so fear Allah, O ye that understand; that (so) ye may prosper."

# 770

O ye who believe! Ask not questions about things which, if made plain to you, may cause you trouble. But if ye ask about things when the Qur'an is being revealed, they will be made plain to you, Allah will forgive those: for Allah is Oft-forgiving, Most Forbearing.

# 771

Some people before you did ask such questions, and on that account lost their faith.

# 772

It was not Allah who instituted (superstitions like those of) a slit-ear she-camel, or a she-camel let loose for free pasture, or idol sacrifices for twin-births in animals, or stallion-camels freed from work: It is blasphemers who invent a lie against Allah; but most of them lack wisdom.

# 773

When it is said to them: "Come to what Allah hath revealed; come to the Messenger": They say: "Enough for us are the ways we found our fathers following." what! even though their fathers were void of knowledge and guidance?

# 774

O ye who believe! Guard your own souls: If ye follow (right) guidance, no hurt can come to you from those who stray. the goal of you all is to Allah: it is He that will show you the truth of all that ye do.

# 775

O ye who believe! When death approaches any of you, (take) witnesses among yourselves when making bequests,- two just men of your own (brotherhood) or others from outside if ye are journeying through the earth, and the chance of death befalls you (thus). If ye doubt (their truth), detain them both after prayer, and let them both swear by Allah: "We wish not in this for any worldly gain, even though the (beneficiary) be our near relation: we shall hide not the evidence before Allah: if we do, then behold! the sin be upon us!"

# 776

But if it gets known that these two were guilty of the sin (of perjury), let two others stand forth in their places,- nearest in kin from among those who claim a lawful right: let them swear by Allah: "We affirm that our witness is truer than that of those two, and that we have not trespassed (beyond the truth): if we did, behold! the wrong be upon us!"

# 777

That is most suitable: that they may give the evidence in its true nature and shape, or else they would fear that other oaths would be taken after their oaths. But fear Allah, and listen (to His counsel): for Allah guideth not a rebellious people:

# 778

One day will Allah gather the messengers together, and ask: "What was the response ye received (from men to your teaching)?" They will say: "We have no knowledge: it is Thou Who knowest in full all that is hidden."

# 779

Then will Allah say: "O Jesus the son of Mary! Recount My favour to thee and to thy mother. Behold! I strengthened thee with the holy spirit, so that thou didst speak to the people in childhood and in maturity. Behold! I taught thee the Book and Wisdom, the Law and the Gospel and behold! thou makest out of clay, as it were, the figure of a bird, by My leave, and thou breathest into it and it becometh a bird by My leave, and thou healest those born blind, and the lepers, by My leave. And behold! thou bringest forth the dead by My leave. And behold! I did restrain the Children of Israel from (violence to) thee when thou didst show them the clear Signs, and the unbelievers among them said: 'This is nothing but evident magic.'

# 780

"And behold! I inspired the disciples to have faith in Me and Mine Messenger: they said, 'We have faith, and do thou bear witness that we bow to Allah as Muslims'".

# 781

Behold! the disciples, said: "O Jesus the son of Mary! can thy Lord send down to us a table set (with viands) from heaven?" Said Jesus: "Fear Allah, if ye have faith."

# 782

They said: "We only wish to eat thereof and satisfy our hearts, and to know that thou hast indeed told us the truth; and that we ourselves may be witnesses to the miracle."

# 783

Said Jesus the son of Mary: "O Allah our Lord! Send us from heaven a table set (with viands), that there may be for us - for the first and the last of us - a solemn festival and a sign from thee; and provide for our sustenance, for thou art the best Sustainer (of our needs)."

# 784

Allah said: "I will send it down unto you: But if any of you after that resisteth faith, I will punish him with a penalty such as I have not inflicted on any one among all the peoples."

# 785

And behold! Allah will say: "O Jesus the son of Mary! Didst thou say unto men, worship me and my mother as gods in derogation of Allah'?" He will say: "Glory to Thee! never could I say what I had no right (to say). Had I said such a thing, thou wouldst indeed have known it. Thou knowest what is in my heart, Thou I know not what is in Thine. For Thou knowest in full all that is hidden.

# 786

"Never said I to them aught except what Thou didst command me to say, to wit, 'worship Allah, my Lord and your Lord'; and I was a witness over them whilst I dwelt amongst them; when Thou didst take me up Thou wast the Watcher over them, and Thou art a witness to all things.

# 787

"If Thou dost punish them, they are Thy servant: If Thou dost forgive them, Thou art the Exalted in power, the Wise."

# 788

Allah will say: "This is a day on which the truthful will profit from their truth: theirs are gardens, with rivers flowing beneath,- their eternal Home: Allah well-pleased with them, and they with Allah: That is the great salvation, (the fulfilment of all desires).

# 789

To Allah doth belong the dominion of the heavens and the earth, and all that is therein, and it is He Who hath power over all things.

# 790

Praise be Allah, Who created the heavens and the earth, and made the darkness and the light. Yet those who reject Faith hold (others) as equal, with their Guardian-Lord.

# 791

He it is created you from clay, and then decreed a stated term (for you). And there is in His presence another determined term; yet ye doubt within yourselves!

# 792

And He is Allah in the heavens and on earth. He knoweth what ye hide, and what ye reveal, and He knoweth the (recompense) which ye earn (by your deeds).

# 793

But never did a single one of the signs of their Lord reach them, but they turned away therefrom.

# 794

And now they reject the truth when it reaches them: but soon shall they learn the reality of what they used to mock at.

# 795

See they not how many of those before them We did destroy?- generations We had established on the earth, in strength such as We have not given to you - for whom We poured out rain from the skies in abundance, and gave (fertile) streams flowing beneath their (feet): yet for their sins We destroyed them, and raised in their wake fresh generations (to succeed them).

# 796

If We had sent unto thee a written (message) on parchment, so that they could touch it with their hands, the Unbelievers would have been sure to say: "This is nothing but obvious magic!"

# 797

They say: "Why is not an angel sent down to him?" If we did send down an angel, the matter would be settled at once, and no respite would be granted them.

# 798

If We had made it an angel, We should have sent him as a man, and We should certainly have caused them confusion in a matter which they have already covered with confusion.

# 799

Mocked were (many) messengers before thee; but their scoffers were hemmed in by the thing that they mocked.

# 800

Say: "Travel through the earth and see what was the end of those who rejected Truth."

# 801

Say: "To whom belongeth all that is in the heavens and on earth?" Say: "To Allah. He hath inscribed for Himself (the rule of) Mercy. That He will gather you together for the Day of Judgment, there is no doubt whatever. It is they who have lost their own souls, that will not believe.

# 802

To him belongeth all that dwelleth (or lurketh) in the night and the day. For he is the one who heareth and knoweth all things."

# 803

Say: "Shall I take for my protector any other than Allah, the Maker of the heavens and the earth? And He it is that feedeth but is not fed." Say: "Nay! but I am commanded to be the first of those who bow to Allah (in Islam), and be not thou of the company of those who join gods with Allah."

# 804

Say: "I would, if I disobeyed my Lord, indeed have fear of the penalty of a Mighty Day.

# 805

"On that day, if the penalty is averted from any, it is due to Allah's mercy; And that would be (Salvation), the obvious fulfilment of all desire.

# 806

"If Allah touch thee with affliction, none can remove it but He; if He touch thee with happiness, He hath power over all things.

# 807

"He is the irresistible, (watching) from above over His worshippers; and He is the Wise, acquainted with all things."

# 808

Say: "What thing is most weighty in evidence?" Say: "Allah is witness between me and you; This Qur'an hath been revealed to me by inspiration, that I may warn you and all whom it reaches. Can ye possibly bear witness that besides Allah there is another Allah?" Say: "Nay! I cannot bear witness!" Say: "But in truth He is the one Allah, and I truly am innocent of (your blasphemy of) joining others with Him."

# 809

Those to whom We have given the Book know this as they know their own sons. Those who have lost their own souls refuse therefore to believe.

# 810

Who doth more wrong than he who inventeth a lie against Allah or rejecteth His signs? But verily the wrong-doers never shall prosper.

# 811

One day shall We gather them all together: We shall say to those who ascribed partners (to Us): "Where are the partners whom ye (invented and) talked about?"

# 812

There will then be (left) no subterfuge for them but to say: "By Allah our Lord, we were not those who joined gods with Allah."

# 813

Behold! how they lie against their own souls! But the (lie) which they invented will leave them in the lurch.

# 814

Of them there are some who (pretend to) listen to thee; but We have thrown veils on their hearts, So they understand it not, and deafness in their ears; if they saw every one of the signs, not they will believe in them; in so much that when they come to thee, they (but) dispute with thee; the Unbelievers say: "These are nothing but tales of the ancients."

# 815

Others they keep away from it, and themselves they keep away; but they only destroy their own souls, and they perceive it not.

# 816

If thou couldst but see when they are confronted with the Fire! They will say: "Would that we were but sent back! Then would we not reject the signs of our Lord, but would be amongst those who believe!"

# 817

Yea, in their own (eyes) will become manifest what before they concealed. But if they were returned, they would certainly relapse to the things they were forbidden, for they are indeed liars.

# 818

And they (sometimes) say: "There is nothing except our life on this earth, and never shall we be raised up again."

# 819

If thou couldst but see when they are confronted with their Lord! He will say: "Is not this the truth?" They will say: "Yea, by our Lord!" He will say: "Taste ye then the penalty, because ye rejected Faith."

# 820

Lost indeed are they who treat it as a falsehood that they must meet Allah,- until on a sudden the hour is on them, and they say: "Ah! woe unto us that we took no thought of it"; for they bear their burdens on their backs, and evil indeed are the burdens that they bear?

# 821

What is the life of this world but play and amusement? But best is the home in the hereafter, for those who are righteous. Will ye not then understand?

# 822

We know indeed the grief which their words do cause thee: It is not thee they reject: it is the signs of Allah, which the wicked contemn.

# 823

Rejected were the messengers before thee: with patience and constancy they bore their rejection and their wrongs, until Our aid did reach them: there is none that can alter the words (and decrees) of Allah. Already hast thou received some account of those messengers.

# 824

If their spurning is hard on thy mind, yet if thou wert able to seek a tunnel in the ground or a ladder to the skies and bring them a sign,- (what good?). If it were Allah's will, He could gather them together unto true guidance: so be not thou amongst those who are swayed by ignorance (and impatience)!

# 825

Those who listen (in truth), be sure, will accept: as to the dead, Allah will raise them up; then will they be turned unto Him.

# 826

They say: "Why is not a sign sent down to him from his Lord?" Say: "Allah hath certainly power to send down a sign: but most of them understand not.

# 827

There is not an animal (that lives) on the earth, nor a being that flies on its wings, but (forms part of) communities like you. Nothing have we omitted from the Book, and they (all) shall be gathered to their Lord in the end.

# 828

Those who reject our signs are deaf and dumb,- in the midst of darkness profound: whom Allah willeth, He leaveth to wander: whom He willeth, He placeth on the way that is straight.

# 829

Say: "Think ye to yourselves, if there come upon you the wrath of Allah, or the Hour (that ye dread), would ye then call upon other than Allah?- (reply) if ye are truthful!

# 830

"Nay,- On Him would ye call, and if it be His will, He would remove (the distress) which occasioned your call upon Him, and ye would forget (the false gods) which ye join with Him!"

# 831

Before thee We sent (messengers) to many nations, and We afflicted the nations with suffering and adversity, that they might learn humility.

# 832

When the suffering reached them from us, why then did they not learn humility? On the contrary their hearts became hardened, and Satan made their (sinful) acts seem alluring to them.

# 833

But when they forgot the warning they had received, We opened to them the gates of all (good) things, until, in the midst of their enjoyment of Our gifts, on a sudden, We called them to account, when lo! they were plunged in despair!

# 834

Of the wrong-doers the last remnant was cut off. Praise be to Allah, the Cherisher of the worlds.

# 835

Say: "Think ye, if Allah took away your hearing and your sight, and sealed up your hearts, who - a god other than Allah - could restore them to you?" See how We explain the signs by various (symbols); yet they turn aside.

# 836

Say: "Think ye, if the punishment of Allah comes to you, whether suddenly or openly, will any be destroyed except those who do wrong?

# 837

We send the messengers only to give good news and to warn: so those who believe and mend (their lives),- upon them shall be no fear, nor shall they grieve.

# 838

But those who reject our signs,- them shall punishment touch, for that they ceased not from transgressing.

# 839

Say: "I tell you not that with me are the treasures of Allah, nor do I know what is hidden, nor do I tell you I am an angel. I but follow what is revealed to me." Say: "can the blind be held equal to the seeing?" Will ye then consider not?

# 840

Give this warning to those in whose (hearts) is the fear that they will be brought (to judgment) before their Lord: except for Him they will have no protector nor intercessor: that they may guard (against evil).

# 841

Send not away those who call on their Lord morning and evening, seeking His face. In naught art thou accountable for them, and in naught are they accountable for thee, that thou shouldst turn them away, and thus be (one) of the unjust.

# 842

Thus did We try some of them by comparison with others, that they should say: "Is it these then that Allah hath favoured from amongst us?" Doth not Allah know best those who are grateful?

# 843

When those come to thee who believe in Our signs, Say: "Peace be on you: Your Lord hath inscribed for Himself (the rule of) mercy: verily, if any of you did evil in ignorance, and thereafter repented, and amend (his conduct), lo! He is Oft-forgiving, Most Merciful.

# 844

Thus do We explain the signs in detail: that the way of the sinners may be shown up.

# 845

Say: "I am forbidden to worship those - others than Allah - whom ye call upon." Say: "I will not follow your wain desires: If I did, I would stray from the path, and be not of the company of those who receive guidance."

# 846

Say: "For me, I (work) on a clear sign from my Lord, but ye reject Him. What ye would see hastened, is not in my power. The command rests with none but Allah: He declares the truth, and He is the best of judges."

# 847

Say: "If what ye would see hastened were in my power, the matter would be settled at once between you and me. But Allah knoweth best those who do wrong."

# 848

With Him are the keys of the unseen, the treasures that none knoweth but He. He knoweth whatever there is on the earth and in the sea. Not a leaf doth fall but with His knowledge: there is not a grain in the darkness (or depths) of the earth, nor anything fresh or dry (green or withered), but is (inscribed) in a record clear (to those who can read).

# 849

It is He who doth take your souls by night, and hath knowledge of all that ye have done by day: by day doth He raise you up again; that a term appointed be fulfilled; In the end unto Him will be your return; then will He show you the truth of all that ye did.

# 850

He is the irresistible, (watching) from above over His worshippers, and He sets guardians over you. At length, when death approaches one of you, Our angels take his soul, and they never fail in their duty.

# 851

Then are men returned unto Allah, their protector, the (only) reality: Is not His the command? and He is the swiftest in taking account.

# 852

Say: "Who is it that delivereth you from the dark recesses of land and sea, when ye call upon Him in humility and silent terror: 'If He only delivers us from these (dangers), (we vow) we shall truly show our gratitude'?"

# 853

Say "It is Allah that delivereth you from these and all (other) distresses: and yet ye worship false gods!"

# 854

Say: "He hath power to send calamities on you, from above and below, or to cover you with confusion in party strife, giving you a taste of mutual vengeance - each from the other." See how We explain the signs by various (symbols); that they may understand.

# 855

But thy people reject this, though it is the truth. Say: "Not mine is the responsibility for arranging your affairs;

# 856

For every message is a limit of time, and soon shall ye know it."

# 857

When thou seest men engaged in vain discourse about Our signs, turn away from them unless they turn to a different theme. If Satan ever makes thee forget, then after recollection, sit not thou in the company of those who do wrong.

# 858

On their account no responsibility falls on the righteous, but (their duty) is to remind them, that they may (learn to) fear Allah.

# 859

Leave alone those who take their religion to be mere play and amusement, and are deceived by the life of this world. But proclaim (to them) this (truth): that every soul delivers itself to ruin by its own acts: it will find for itself no protector or intercessor except Allah: if it offered every ransom, (or reparation), none will be accepted: such is (the end of) those who deliver themselves to ruin by their own acts: they will have for drink (only) boiling water, and for punishment, one most grievous: for they persisted in rejecting Allah.

# 860

Say: "Shall we indeed call on others besides Allah,- things that can do us neither good nor harm,- and turn on our heels after receiving guidance from Allah? - like one whom the evil ones have made into a fool, wandering bewildered through the earth, his friends calling, come to us', (vainly) guiding him to the path." Say: "Allah's guidance is the (only) guidance, and we have been directed to submit ourselves to the Lord of the worlds;-

# 861

"To establish regular prayers and to fear Allah: for it is to Him that we shall be gathered together."

# 862

It is He who created the heavens and the earth in true (proportions): the day He saith, "Be," behold! it is. His word is the truth. His will be the dominion the day the trumpet will be blown. He knoweth the unseen as well as that which is open. For He is the Wise, well acquainted (with all things).

# 863

Lo! Abraham said to his father Azar: "Takest thou idols for gods? For I see thee and thy people in manifest error."

# 864

So also did We show Abraham the power and the laws of the heavens and the earth, that he might (with understanding) have certitude.

# 865

When the night covered him over, He saw a star: He said: "This is my Lord." But when it set, He said: "I love not those that set."

# 866

When he saw the moon rising in splendour, he said: "This is my Lord." But when the moon set, He said: "unless my Lord guide me, I shall surely be among those who go astray."

# 867

When he saw the sun rising in splendour, he said: "This is my Lord; this is the greatest (of all)." But when the sun set, he said: "O my people! I am indeed free from your (guilt) of giving partners to Allah.

# 868

"For me, I have set my face, firmly and truly, towards Him Who created the heavens and the earth, and never shall I give partners to Allah."

# 869

His people disputed with him. He said: "(Come) ye to dispute with me, about Allah, when He (Himself) hath guided me? I fear not (the beings) ye associate with Allah: Unless my Lord willeth, (nothing can happen). My Lord comprehendeth in His knowledge all things. Will ye not (yourselves) be admonished?

# 870

"How should I fear (the beings) ye associate with Allah, when ye fear not to give partners to Allah without any warrant having been given to you? Which of (us) two parties hath more right to security? (tell me) if ye know.

# 871

"It is those who believe and confuse not their beliefs with wrong - that are (truly) in security, for they are on (right) guidance."

# 872

That was the reasoning about Us, which We gave to Abraham (to use) against his people: We raise whom We will, degree after degree: for thy Lord is full of wisdom and knowledge.

# 873

We gave him Isaac and Jacob: all (three) guided: and before him, We guided Noah, and among his progeny, David, Solomon, Job, Joseph, Moses, and Aaron: thus do We reward those who do good:

# 874

And Zakariya and John, and Jesus and Elias: all in the ranks of the righteous:

# 875

And Isma'il and Elisha, and Jonas, and Lot: and to all We gave favour above the nations:

# 876

(To them) and to their fathers, and progeny and brethren: We chose them, and we guided them to a straight way.

# 877

This is the guidance of Allah: He giveth that guidance to whom He pleaseth, of His worshippers. If they were to join other gods with Him, all that they did would be vain for them.

# 878

These were the men to whom We gave the Book, and authority, and prophethood: if these (their descendants) reject them, Behold! We shall entrust their charge to a new people who reject them not.

# 879

Those were the (prophets) who received Allah's guidance: Copy the guidance they received; Say: "No reward for this do I ask of you: This is no less than a message for the nations."

# 880

No just estimate of Allah do they make when they say: "Nothing doth Allah send down to man (by way of revelation)" Say: "Who then sent down the Book which Moses brought?- a light and guidance to man: But ye make it into (separate) sheets for show, while ye conceal much (of its contents): therein were ye taught that which ye knew not- neither ye nor your fathers." Say: "Allah (sent it down)": Then leave them to plunge in vain discourse and trifling.

# 881

And this is a Book which We have sent down, bringing blessings, and confirming (the revelations) which came before it: that thou mayest warn the mother of cities and all around her. Those who believe in the Hereafter believe in this (Book), and they are constant in guarding their prayers.

# 882

Who can be more wicked than one who inventeth a lie against Allah, or saith, "I have received inspiration," when he hath received none, or (again) who saith, "I can reveal the like of what Allah hath revealed"? If thou couldst but see how the wicked (do fare) in the flood of confusion at death! - the angels stretch forth their hands, (saying),"Yield up your souls: this day shall ye receive your reward,- a penalty of shame, for that ye used to tell lies against Allah, and scornfully to reject of His signs!"

# 883

"And behold! ye come to us bare and alone as We created you for the first time: ye have left behind you all (the favours) which We bestowed on you: We see not with you your intercessors whom ye thought to be partners in your affairs: so now all relations between you have been cut off, and your (pet) fancies have left you in the lurch!"

# 884

It is Allah Who causeth the seed-grain and the date-stone to split and sprout. He causeth the living to issue from the dead, and He is the one to cause the dead to issue from the living. That is Allah: then how are ye deluded away from the truth?

# 885

He it is that cleaveth the day-break (from the dark): He makes the night for rest and tranquillity, and the sun and moon for the reckoning (of time): Such is the judgment and ordering of (Him), the Exalted in Power, the Omniscient.

# 886

It is He Who maketh the stars (as beacons) for you, that ye may guide yourselves, with their help, through the dark spaces of land and sea: We detail Our signs for people who know.

# 887

It is He Who hath produced you from a single person: here is a place of sojourn and a place of departure: We detail Our signs for people who understand.

# 888

It is He Who sendeth down rain from the skies: with it We produce vegetation of all kinds: from some We produce green (crops), out of which We produce grain, heaped up (at harvest); out of the date-palm and its sheaths (or spathes) (come) clusters of dates hanging low and near: and (then there are) gardens of grapes, and olives, and pomegranates, each similar (in kind) yet different (in variety): when they begin to bear fruit, feast your eyes with the fruit and the ripeness thereof. Behold! in these things there are signs for people who believe.

# 889

Yet they make the Jinns equals with Allah, though Allah did create the Jinns; and they falsely, having no knowledge, attribute to Him sons and daughters. Praise and glory be to Him! (for He is) above what they attribute to Him!

# 890

To Him is due the primal origin of the heavens and the earth: How can He have a son when He hath no consort? He created all things, and He hath full knowledge of all things.

# 891

That is Allah, your Lord! there is no god but He, the Creator of all things: then worship ye Him: and He hath power to dispose of all affairs.

# 892

No vision can grasp Him, but His grasp is over all vision: He is above all comprehension, yet is acquainted with all things.

# 893

"Now have come to you, from your Lord, proofs (to open your eyes): if any will see, it will be for (the good of) his own soul; if any will be blind, it will be to his own (harm): I am not (here) to watch over your doings."

# 894

Thus do we explain the signs by various (symbols): that they may say, "Thou hast taught (us) diligently," and that We may make the matter clear to those who know.

# 895

Follow what thou art taught by inspiration from thy Lord: there is no god but He: and turn aside from those who join gods with Allah.

# 896

If it had been Allah's plan, they would not have taken false gods: but We made thee not one to watch over their doings, nor art thou set over them to dispose of their affairs.

# 897

Revile not ye those whom they call upon besides Allah, lest they out of spite revile Allah in their ignorance. Thus have We made alluring to each people its own doings. In the end will they return to their Lord, and We shall then tell them the truth of all that they did.

# 898

They swear their strongest oaths by Allah, that if a (special) sign came to them, by it they would believe. Say: "Certainly (all) signs are in the power of Allah: but what will make you (Muslims) realise that (even) if (special) signs came, they will not believe."?

# 899

We (too) shall turn to (confusion) their hearts and their eyes, even as they refused to believe in this in the first instance: We shall leave them in their trespasses, to wander in distraction.

# 900

Even if We did send unto them angels, and the dead did speak unto them, and We gathered together all things before their very eyes, they are not the ones to believe, unless it is in Allah's plan. But most of them ignore (the truth).

# 901

Likewise did We make for every Messenger an enemy,- evil ones among men and jinns, inspiring each other with flowery discourses by way of deception. If thy Lord had so planned, they would not have done it: so leave them and their inventions alone.

# 902

To such (deceit) let the hearts of those incline, who have no faith in the hereafter: let them delight in it, and let them earn from it what they may.

# 903

Say: "Shall I seek for judge other than Allah? - when He it is Who hath sent unto you the Book, explained in detail." They know full well, to whom We have given the Book, that it hath been sent down from thy Lord in truth. Never be then of those who doubt.

# 904

The word of thy Lord doth find its fulfilment in truth and in justice: None can change His words: for He is the one who heareth and knoweth all.

# 905

Wert thou to follow the common run of those on earth, they will lead thee away from the way of Allah. They follow nothing but conjecture: they do nothing but lie.

# 906

Thy Lord knoweth best who strayeth from His way: He knoweth best who they are that receive His guidance.

# 907

So eat of (meats) on which Allah's name hath been pronounced, if ye have faith in His signs.

# 908

Why should ye not eat of (meats) on which Allah's name hath been pronounced, when He hath explained to you in detail what is forbidden to you - except under compulsion of necessity? But many do mislead (men) by their appetites unchecked by knowledge. Thy Lord knoweth best those who transgress.

# 909

Eschew all sin, open or secret: those who earn sin will get due recompense for their "earnings."

# 910

Eat not of (meats) on which Allah's name hath not been pronounced: That would be impiety. But the evil ones ever inspire their friends to contend with you if ye were to obey them, ye would indeed be Pagans.

# 911

Can he who was dead, to whom We gave life, and a light whereby he can walk amongst men, be like him who is in the depths of darkness, from which he can never come out? Thus to those without faith their own deeds seem pleasing.

# 912

Thus have We placed leaders in every town, its wicked men, to plot (and burrow) therein: but they only plot against their own souls, and they perceive it not.

# 913

When there comes to them a sign (from Allah), They say: "We shall not believe until we receive one (exactly) like those received by Allah's messengers." Allah knoweth best where (and how) to carry out His mission. Soon will the wicked be overtaken by humiliation before Allah, and a severe punishment, for all their plots.

# 914

Those whom Allah (in His plan) willeth to guide,- He openeth their breast to Islam; those whom He willeth to leave straying,- He maketh their breast close and constricted, as if they had to climb up to the skies: thus doth Allah (heap) the penalty on those who refuse to believe.

# 915

This is the way of thy Lord, leading straight: We have detailed the signs for those who receive admonition.

# 916

For them will be a home of peace in the presence of their Lord: He will be their friend, because they practised (righteousness).

# 917

One day will He gather them all together, (and say): "O ye assembly of Jinns! Much (toll) did ye take of men." Their friends amongst men will say: "Our Lord! we made profit from each other: but (alas!) we reached our term - which thou didst appoint for us." He will say: "The Fire be your dwelling-place: you will dwell therein for ever, except as Allah willeth." for thy Lord is full of wisdom and knowledge.

# 918

Thus do we make the wrong-doers turn to each other, because of what they earn.

# 919

"O ye assembly of Jinns and men! came there not unto you messengers from amongst you, setting forth unto you My signs, and warning you of the meeting of this Day of yours?" They will say: "We bear witness against ourselves." It was the life of this world that deceived them. So against themselves will they bear witness that they rejected Faith.

# 920

(The messengers were sent) thus, for thy Lord would not destroy for their wrong-doing men's habitations whilst their occupants were unwarned.

# 921

To all are degrees (or ranks) according to their deeds: for thy Lord is not unmindful of anything that they do.

# 922

Thy Lord is self-sufficient, full of Mercy: if it were His will, He could destroy you, and in your place appoint whom He will as your successors, even as He raised you up from the posterity of other people.

# 923

All that hath been promised unto you will come to pass: nor can ye frustrate it (in the least bit).

# 924

Say: "O my people! Do whatever ye can: I will do (my part): soon will ye know who it is whose end will be (best) in the Hereafter: certain it is that the wrong-doers will not prosper."

# 925

Out of what Allah hath produced in abundance in tilth and in cattle, they assigned Him a share: they say, according to their fancies: "This is for Allah, and this" - for our "partners"! but the share of their" partners "reacheth not Allah, whilst the share of Allah reacheth their "partners"! evil (and unjust) is their assignment!

# 926

Even so, in the eyes of most of the pagans, their "partners" made alluring the slaughter of their children, in order to lead them to their own destruction, and cause confusion in their religion. If Allah had willed, they would not have done so: But leave alone them and their inventions.

# 927

And they say that such and such cattle and crops are taboo, and none should eat of them except those whom - so they say - We wish; further, there are cattle forbidden to yoke or burden, and cattle on which, (at slaughter), the name of Allah is not pronounced; - inventions against Allah's name: soon will He requite them for their inventions.

# 928

They say: "What is in the wombs of such and such cattle is specially reserved (for food) for our men, and forbidden to our women; but if it is still-born, then all have share therein. For their (false) attribution (of superstitions to Allah), He will soon punish them: for He is full of wisdom and knowledge.

# 929

Lost are those who slay their children, from folly, without knowledge, and forbid food which Allah hath provided for them, inventing (lies) against Allah. They have indeed gone astray and heeded no guidance.

# 930

It is He Who produceth gardens, with trellises and without, and dates, and tilth with produce of all kinds, and olives and pomegranates, similar (in kind) and different (in variety): eat of their fruit in their season, but render the dues that are proper on the day that the harvest is gathered. But waste not by excess: for Allah loveth not the wasters.

# 931

Of the cattle are some for burden and some for meat: eat what Allah hath provided for you, and follow not the footsteps of Satan: for he is to you and avowed enemy.

# 932

(Take) eight (head of cattle) in (four) pairs: of sheep a pair, and of goats a pair; say, hath He forbidden the two males, or the two females, or (the young) which the wombs of the two females enclose? Tell me with knowledge if ye are truthful:

# 933

Of camels a pair, and oxen a pair; say, hath He forbidden the two males, or the two females, or (the young) which the wombs of the two females enclose? - Were ye present when Allah ordered you such a thing? But who doth more wrong than one who invents a lie against Allah, to lead astray men without knowledge? For Allah guideth not people who do wrong.

# 934

Say: "I find not in the message received by me by inspiration any (meat) forbidden to be eaten by one who wishes to eat it, unless it be dead meat, or blood poured forth, or the flesh of swine,- for it is an abomination - or, what is impious, (meat) on which a name has been invoked, other than Allah's". But (even so), if a person is forced by necessity, without wilful disobedience, nor transgressing due limits,- thy Lord is Oft-forgiving, Most Merciful.

# 935

For those who followed the Jewish Law, We forbade every (animal) with undivided hoof, and We forbade them that fat of the ox and the sheep, except what adheres to their backs or their entrails, or is mixed up with a bone: this in recompense for their wilful disobedience: for We are true (in Our ordinances).

# 936

If they accuse thee of falsehood, say: "Your Lord is full of mercy all-embracing; but from people in guilt never will His wrath be turned back.

# 937

Those who give partners (to Allah) will say: "If Allah had wished, we should not have given partners to Him nor would our fathers; nor should we have had any taboos." So did their ancestors argue falsely, until they tasted of Our wrath. Say: "Have ye any (certain) knowledge? If so, produce it before us. Ye follow nothing but conjecture: ye do nothing but lie."

# 938

Say: "With Allah is the argument that reaches home: if it had been His will, He could indeed have guided you all."

# 939

Say: "Bring forward your witnesses to prove that Allah did forbid so and so." If they bring such witnesses, be not thou amongst them: Nor follow thou the vain desires of such as treat our signs as falsehoods, and such as believe not in the Hereafter: for they hold others as equal with their Guardian-Lord.

# 940

Say: "Come, I will rehearse what Allah hath (really) prohibited you from": Join not anything as equal with Him; be good to your parents; kill not your children on a plea of want;- We provide sustenance for you and for them;- come not nigh to shameful deeds. Whether open or secret; take not life, which Allah hath made sacred, except by way of justice and law: thus doth He command you, that ye may learn wisdom.

# 941

And come not nigh to the orphan's property, except to improve it, until he attain the age of full strength; give measure and weight with (full) justice;- no burden do We place on any soul, but that which it can bear;- whenever ye speak, speak justly, even if a near relative is concerned; and fulfil the covenant of Allah: thus doth He command you, that ye may remember.

# 942

Verily, this is My way, leading straight: follow it: follow not (other) paths: they will scatter you about from His (great) path: thus doth He command you. that ye may be righteous.

# 943

Moreover, We gave Moses the Book, completing (Our favour) to those who would do right, and explaining all things in detail,- and a guide and a mercy, that they might believe in the meeting with their Lord.

# 944

And this is a Book which We have revealed as a blessing: so follow it and be righteous, that ye may receive mercy:

# 945

Lest ye should say: "The Book was sent down to two Peoples before us, and for our part, we remained unacquainted with all that they learned by assiduous study:"

# 946

Or lest ye should say: "If the Book had only been sent down to us, we should have followed its guidance better than they." Now then hath come unto you a clear (sign) from your Lord,- and a guide and a mercy: then who could do more wrong than one who rejecteth Allah's signs, and turneth away therefrom? In good time shall We requite those who turn away from Our signs, with a dreadful penalty, for their turning away.

# 947

Are they waiting to see if the angels come to them, or thy Lord (Himself), or certain of the signs of thy Lord! the day that certain of the signs of thy Lord do come, no good will it do to a soul to believe in them then if it believed not before nor earned righteousness through its faith. Say: "Wait ye: we too are waiting."

# 948

As for those who divide their religion and break up into sects, thou hast no part in them in the least: their affair is with Allah: He will in the end tell them the truth of all that they did.

# 949

He that doeth good shall have ten times as much to his credit: He that doeth evil shall only be recompensed according to his evil: no wrong shall be done unto (any of) them.

# 950

Say: "Verily, my Lord hath guided me to a way that is straight,- a religion of right,- the path (trod) by Abraham the true in Faith, and he (certainly) joined not gods with Allah."

# 951

Say: "Truly, my prayer and my service of sacrifice, my life and my death, are (all) for Allah, the Cherisher of the Worlds:

# 952

No partner hath He: this am I commanded, and I am the first of those who bow to His will.

# 953

Say: "Shall I seek for (my) Cherisher other than Allah, when He is the Cherisher of all things (that exist)? Every soul draws the meed of its acts on none but itself: no bearer of burdens can bear the burden of another. Your goal in the end is towards Allah: He will tell you the truth of the things wherein ye disputed."

# 954

It is He Who hath made you (His) agents, inheritors of the earth: He hath raised you in ranks, some above others: that He may try you in the gifts He hath given you: for thy Lord is quick in punishment: yet He is indeed Oft-forgiving, Most Merciful.

# 955

Alif, Lam, Mim, Sad.

# 956

A Book revealed unto thee,- So let thy heart be oppressed no more by any difficulty on that account,- that with it thou mightest warn (the erring) and teach the Believers).

# 957

Follow (O men!) the revelation given unto you from your Lord, and follow not, as friends or protectors, other than Him. Little it is ye remember of admonition.

# 958

How many towns have We destroyed (for their sins)? Our punishment took them on a sudden by night or while they slept for their afternoon rest.

# 959

When (thus) Our punishment took them, no cry did they utter but this: "Indeed we did wrong."

# 960

Then shall we question those to whom Our message was sent and those by whom We sent it.

# 961

And verily, We shall recount their whole story with knowledge, for We were never absent (at any time or place).

# 962

The balance that day will be true (to nicety): those whose scale (of good) will be heavy, will prosper:

# 963

Those whose scale will be light, will be their souls in perdition, for that they wrongfully treated Our signs.

# 964

It is We Who have placed you with authority on earth, and provided you therein with means for the fulfilment of your life: small are the thanks that ye give!

# 965

It is We Who created you and gave you shape; then We bade the angels prostrate to Adam, and they prostrate; not so Iblis; He refused to be of those who prostrate.

# 966

(Allah) said: "What prevented thee from prostrating when I commanded thee?" He said: "I am better than he: Thou didst create me from fire, and him from clay."

# 967

(Allah) said: "Get thee down from this: it is not for thee to be arrogant here: get out, for thou art of the meanest (of creatures)."

# 968

He said: "Give me respite till the day they are raised up."

# 969

(Allah) said: "Be thou among those who have respite."

# 970

He said: "Because thou hast thrown me out of the way, lo! I will lie in wait for them on thy straight way:

# 971

"Then will I assault them from before them and behind them, from their right and their left: Nor wilt thou find, in most of them, gratitude (for thy mercies)."

# 972

(Allah) said: "Get out from this, disgraced and expelled. If any of them follow thee,- Hell will I fill with you all.

# 973

"O Adam! dwell thou and thy wife in the Garden, and enjoy (its good things) as ye wish: but approach not this tree, or ye run into harm and transgression."

# 974

Then began Satan to whisper suggestions to them, bringing openly before their minds all their shame that was hidden from them (before): he said: "Your Lord only forbade you this tree, lest ye should become angels or such beings as live for ever."

# 975

And he swore to them both, that he was their sincere adviser.

# 976

So by deceit he brought about their fall: when they tasted of the tree, their shame became manifest to them, and they began to sew together the leaves of the garden over their bodies. And their Lord called unto them: "Did I not forbid you that tree, and tell you that Satan was an avowed enemy unto you?"

# 977

They said: "Our Lord! We have wronged our own souls: If thou forgive us not and bestow not upon us Thy Mercy, we shall certainly be lost."

# 978

(Allah) said: "Get ye down. With enmity between yourselves. On earth will be your dwelling-place and your means of livelihood,- for a time."

# 979

He said: "Therein shall ye live, and therein shall ye die; but from it shall ye be taken out (at last)."

# 980

O ye Children of Adam! We have bestowed raiment upon you to cover your shame, as well as to be an adornment to you. But the raiment of righteousness,- that is the best. Such are among the Signs of Allah, that they may receive admonition!

# 981

O ye Children of Adam! Let not Satan seduce you, in the same manner as He got your parents out of the Garden, stripping them of their raiment, to expose their shame: for he and his tribe watch you from a position where ye cannot see them: We made the evil ones friends (only) to those without faith.

# 982

When they do aught that is shameful, they say: "We found our fathers doing so"; and "Allah commanded us thus": Say: "Nay, Allah never commands what is shameful: do ye say of Allah what ye know not?"

# 983

Say: "My Lord hath commanded justice; and that ye set your whole selves (to Him) at every time and place of prayer, and call upon Him, making your devotion sincere as in His sight: such as He created you in the beginning, so shall ye return."

# 984

Some He hath guided: Others have (by their choice) deserved the loss of their way; in that they took the evil ones, in preference to Allah, for their friends and protectors, and think that they receive guidance.

# 985

O Children of Adam! wear your beautiful apparel at every time and place of prayer: eat and drink: But waste not by excess, for Allah loveth not the wasters.

# 986

Say: Who hath forbidden the beautiful (gifts) of Allah, which He hath produced for His servants, and the things, clean and pure, (which He hath provided) for sustenance? Say: They are, in the life of this world, for those who believe, (and) purely for them on the Day of Judgment. Thus do We explain the signs in detail for those who understand.

# 987

Say: the things that my Lord hath indeed forbidden are: shameful deeds, whether open or secret; sins and trespasses against truth or reason; assigning of partners to Allah, for which He hath given no authority; and saying things about Allah of which ye have no knowledge.

# 988

To every people is a term appointed: when their term is reached, not an hour can they cause delay, nor (an hour) can they advance (it in anticipation).

# 989

O ye Children of Adam! whenever there come to you messengers from amongst you, rehearsing My signs unto you,- those who are righteous and mend (their lives),- on them shall be no fear nor shall they grieve.

# 990

But those who reject Our signs and treat them with arrogance,- they are companions of the Fire, to dwell therein (for ever).

# 991

Who is more unjust than one who invents a lie against Allah or rejects His Signs? For such, their portion appointed must reach them from the Book (of decrees): until, when our messengers (of death) arrive and take their souls, they say: "Where are the things that ye used to invoke besides Allah?" They will reply, "They have left us in the lurch," And they will bear witness against themselves, that they had rejected Allah.

# 992

He will say: "Enter ye in the company of the peoples who passed away before you - men and jinns, - into the Fire." Every time a new people enters, it curses its sister-people (that went before), until they follow each other, all into the Fire. Saith the last about the first: "Our Lord! it is these that misled us: so give them a double penalty in the Fire." He will say: "Doubled for all": but this ye do not understand.

# 993

Then the first will say to the last: "See then! No advantage have ye over us; so taste ye of the penalty for all that ye did!"

# 994

To those who reject Our signs and treat them with arrogance, no opening will there be of the gates of heaven, nor will they enter the garden, until the camel can pass through the eye of the needle: Such is Our reward for those in sin.

# 995

For them there is Hell, as a couch (below) and folds and folds of covering above: such is Our requital of those who do wrong.

# 996

But those who believe and work righteousness,- no burden do We place on any soul, but that which it can bear,- they will be Companions of the Garden, therein to dwell (for ever).

# 997

And We shall remove from their hearts any lurking sense of injury;- beneath them will be rivers flowing;- and they shall say: "Praise be to Allah, who hath guided us to this (felicity): never could we have found guidance, had it not been for the guidance of Allah: indeed it was the truth, that the messengers of our Lord brought unto us." And they shall hear the cry: "Behold! the garden before you! Ye have been made its inheritors, for your deeds (of righteousness)."

# 998

The Companions of the Garden will call out to the Companions of the Fire: "We have indeed found the promises of our Lord to us true: Have you also found Your Lord's promises true?" They shall say, "Yes"; but a crier shall proclaim between them: "The curse of Allah is on the wrong-doers;-

# 999

"Those who would hinder (men) from the path of Allah and would seek in it something crooked: they were those who denied the Hereafter."

# 1000

Between them shall be a veil, and on the heights will be men who would know every one by his marks: they will call out to the Companions of the Garden, "peace on you": they will not have entered, but they will have an assurance (thereof).

# 1001

When their eyes shall be turned towards the Companions of the Fire, they will say: "Our Lord! send us not to the company of the wrong-doers."

# 1002

The men on the heights will call to certain men whom they will know from their marks, saying: "Of what profit to you were your hoards and your arrogant ways?

# 1003

"Behold! are these not the men whom you swore that Allah with His Mercy would never bless? Enter ye the Garden: no fear shall be on you, nor shall ye grieve."

# 1004

The Companions of the Fire will call to the Companions of the Garden: "Pour down to us water or anything that Allah doth provide for your sustenance." They will say: "Both these things hath Allah forbidden to those who rejected Him."

# 1005

"Such as took their religion to be mere amusement and play, and were deceived by the life of the world." That day shall We forget them as they forgot the meeting of this day of theirs, and as they were wont to reject Our signs.

# 1006

For We had certainly sent unto them a Book, based on knowledge, which We explained in detail,- a guide and a mercy to all who believe.

# 1007

Do they just wait for the final fulfilment of the event? On the day the event is finally fulfilled, those who disregarded it before will say: "The messengers of our Lord did indeed bring true (tidings). Have we no intercessors now to intercede on our behalf? Or could we be sent back? then should we behave differently from our behaviour in the past." In fact they will have lost their souls, and the things they invented will leave them in the lurch.

# 1008

Your Guardian-Lord is Allah, Who created the heavens and the earth in six days, and is firmly established on the throne (of authority): He draweth the night as a veil o'er the day, each seeking the other in rapid succession: He created the sun, the moon, and the stars, (all) governed by laws under His command. Is it not His to create and to govern? Blessed be Allah, the Cherisher and Sustainer of the worlds!

# 1009

Call on your Lord with humility and in private: for Allah loveth not those who trespass beyond bounds.

# 1010

Do no mischief on the earth, after it hath been set in order, but call on Him with fear and longing (in your hearts): for the Mercy of Allah is (always) near to those who do good.

# 1011

It is He Who sendeth the winds like heralds of glad tidings, going before His mercy: when they have carried the heavy-laden clouds, We drive them to a land that is dead, make rain to descend thereon, and produce every kind of harvest therewith: thus shall We raise up the dead: perchance ye may remember.

# 1012

From the land that is clean and good, by the will of its Cherisher, springs up produce, (rich) after its kind: but from the land that is bad, springs up nothing but that which is niggardly: thus do we explain the signs by various (symbols) to those who are grateful.

# 1013

We sent Noah to his people. He said: "O my people! worship Allah! ye have no other god but Him. I fear for you the punishment of a dreadful day!

# 1014

The leaders of his people said: "Ah! we see thee evidently wandering (in mind)."

# 1015

He said: "O my people! No wandering is there in my (mind): on the contrary I am a messenger from the Lord and Cherisher of the worlds!

# 1016

"I but fulfil towards you the duties of my Lord's mission: Sincere is my advice to you, and I know from Allah something that ye know not.

# 1017

"Do ye wonder that there hath come to you a message from your Lord, through a man of your own people, to warn you,- so that ye may fear Allah and haply receive His Mercy?"

# 1018

But they rejected him, and We delivered him, and those with him, in the Ark: but We overwhelmed in the flood those who rejected Our signs. They were indeed a blind people!

# 1019

To the 'Ad people, (We sent) Hud, one of their (own) brethren: He said: O my people! worship Allah! ye have no other god but Him will ye not fear (Allah)?"

# 1020

The leaders of the Unbelievers among his people said: "Ah! we see thou art an imbecile!" and "We think thou art a liar!"

# 1021

He said: "O my people! I am no imbecile, but (I am) a messenger from the Lord and Cherisher of the worlds!

# 1022

"I but fulfil towards you the duties of my Lord's mission: I am to you a sincere and trustworthy adviser.

# 1023

"Do ye wonder that there hath come to you a message from your Lord through a man of your own people, to warn you? call in remembrance that He made you inheritors after the people of Noah, and gave you a stature tall among the nations. Call in remembrance the benefits (ye have received) from Allah: that so ye may prosper."

# 1024

They said: "Comest thou to us, that we may worship Allah alone, and give up the cult of our fathers? bring us what thou threatenest us with, if so be that thou tellest the truth!"

# 1025

He said: "Punishment and wrath have already come upon you from your Lord: dispute ye with me over names which ye have devised - ye and your fathers,- without authority from Allah? then wait: I am amongst you, also waiting."

# 1026

We saved him and those who adhered to him. By Our mercy, and We cut off the roots of those who rejected Our signs and did not believe.

# 1027

To the Thamud people (We sent) Salih, one of their own brethren: He said: "O my people! worship Allah: ye have no other god but Him. Now hath come unto you a clear (Sign) from your Lord! This she-camel of Allah is a Sign unto you: So leave her to graze in Allah's earth, and let her come to no harm, or ye shall be seized with a grievous punishment.

# 1028

"And remember how He made you inheritors after the 'Ad people and gave you habitations in the land: ye build for yourselves palaces and castles in (open) plains, and carve out homes in the mountains; so bring to remembrance the benefits (ye have received) from Allah, and refrain from evil and mischief on the earth."

# 1029

The leaders of the arrogant party among his people said to those who were reckoned powerless - those among them who believed: "know ye indeed that Salih is a messenger from his Lord?" They said: "We do indeed believe in the revelation which hath been sent through him."

# 1030

The Arrogant party said: "For our part, we reject what ye believe in."

# 1031

Then they ham-strung the she-camel, and insolently defied the order of their Lord, saying: "O Salih! bring about thy threats, if thou art a messenger (of Allah)!"

# 1032

So the earthquake took them unawares, and they lay prostrate in their homes in the morning!

# 1033

So Salih left them, saying: "O my people! I did indeed convey to you the message for which I was sent by my Lord: I gave you good counsel, but ye love not good counsellors!"

# 1034

We also (sent) Lut: He said to his people: "Do ye commit lewdness such as no people in creation (ever) committed before you?

# 1035

"For ye practise your lusts on men in preference to women: ye are indeed a people transgressing beyond bounds."

# 1036

And his people gave no answer but this: they said, "Drive them out of your city: these are indeed men who want to be clean and pure!"

# 1037

But we saved him and his family, except his wife: she was of those who legged behind.

# 1038

And we rained down on them a shower (of brimstone): Then see what was the end of those who indulged in sin and crime!

# 1039

To the Madyan people We sent Shu'aib, one of their own brethren: he said: "O my people! worship Allah; Ye have no other god but Him. Now hath come unto you a clear (Sign) from your Lord! Give just measure and weight, nor withhold from the people the things that are their due; and do no mischief on the earth after it has been set in order: that will be best for you, if ye have Faith.

# 1040

"And squat not on every road, breathing threats, hindering from the path of Allah those who believe in Him, and seeking in it something crooked; But remember how ye were little, and He gave you increase. And hold in your mind's eye what was the end of those who did mischief.

# 1041

"And if there is a party among you who believes in the message with which I have been sent, and a party which does not believe, hold yourselves in patience until Allah doth decide between us: for He is the best to decide.

# 1042

The leaders, the arrogant party among his people, said: "O Shu'aib! we shall certainly drive thee out of our city - (thee) and those who believe with thee; or else ye (thou and they) shall have to return to our ways and religion." He said: "What! even though we do detest (them)?

# 1043

"We should indeed invent a lie against Allah, if we returned to your ways after Allah hath rescued us therefrom; nor could we by any manner of means return thereto unless it be as in the will and plan of Allah, Our Lord. Our Lord can reach out to the utmost recesses of things by His knowledge. In the Allah is our trust. our Lord! decide Thou between us and our people in truth, for Thou art the best to decide."

# 1044

The leaders, the unbelievers among his people, said: "If ye follow Shu'aib, be sure then ye are ruined!"

# 1045

But the earthquake took them unawares, and they lay prostrate in their homes before the morning!

# 1046

The men who reject Shu'aib became as if they had never been in the homes where they had flourished: the men who rejected Shu'aib - it was they who were ruined!

# 1047

So Shu'aib left them, saying: "O my people! I did indeed convey to you the messages for which I was sent by my Lord: I gave you good counsel, but how shall I lament over a people who refuse to believe!"

# 1048

Whenever We sent a prophet to a town, We took up its people in suffering and adversity, in order that they might learn humility.

# 1049

Then We changed their suffering into prosperity, until they grew and multiplied, and began to say: "Our fathers (too) were touched by suffering and affluence"... Behold! We called them to account of a sudden, while they realised not (their peril).

# 1050

If the people of the towns had but believed and feared Allah, We should indeed have opened out to them (All kinds of) blessings from heaven and earth; but they rejected (the truth), and We brought them to book for their misdeeds.

# 1051

Did the people of the towns feel secure against the coming of Our wrath by night while they were asleep?

# 1052

Or else did they feel secure against its coming in broad daylight while they played about (care-free)?

# 1053

Did they then feel secure against the plan of Allah?- but no one can feel secure from the Plan of Allah, except those (doomed) to ruin!

# 1054

To those who inherit the earth in succession to its (previous) possessors, is it not a guiding, (lesson) that, if We so willed, We could punish them (too) for their sins, and seal up their hearts so that they could not hear?

# 1055

Such were the towns whose story We (thus) relate unto thee: There came indeed to them their messengers with clear (signs): But they would not believe what they had rejected before. Thus doth Allah seal up the hearts of those who reject faith.

# 1056

Most of them We found not men (true) to their covenant: but most of them We found rebellious and disobedient.

# 1057

Then after them We sent Moses with Our signs to Pharaoh and his chiefs, but they wrongfully rejected them: So see what was the end of those who made mischief.

# 1058

Moses said: "O Pharaoh! I am a messenger from the Lord of the worlds,-

# 1059

One for whom it is right to say nothing but truth about Allah. Now have I come unto you (people), from your Lord, with a clear (Sign): So let the Children of Israel depart along with me."

# 1060

(Pharaoh) said: "If indeed thou hast come with a Sign, show it forth,- if thou tellest the truth."

# 1061

Then (Moses) threw his rod, and behold! it was a serpent, plain (for all to see)!

# 1062

And he drew out his hand, and behold! it was white to all beholders!

# 1063

Said the Chiefs of the people of Pharaoh: "This is indeed a sorcerer well-versed.

# 1064

"His plan is to get you out of your land: then what is it ye counsel?"

# 1065

They said: "Keep him and his brother in suspense (for a while); and send to the cities men to collect-

# 1066

And bring up to thee all (our) sorcerers well-versed."

# 1067

So there came the sorcerers to Pharaoh: They said, "of course we shall have a (suitable) reward if we win!"

# 1068

He said: "Yea, (and more),- for ye shall in that case be (raised to posts) nearest (to my person)."

# 1069

They said: "O Moses! wilt thou throw (first), or shall we have the (first) throw?"

# 1070

Said Moses: "Throw ye (first)." So when they threw, they bewitched the eyes of the people, and struck terror into them: for they showed a great (feat of) magic.

# 1071

We put it into Moses's mind by inspiration: "Throw (now) thy rod": and behold! it swallows up straight away all the falsehoods which they fake!

# 1072

Thus truth was confirmed, and all that they did was made of no effect.

# 1073

So the (great ones) were vanquished there and then, and were made to look small.

# 1074

But the sorcerers fell down prostrate in adoration.

# 1075

Saying: "We believe in the Lord of the Worlds,-

# 1076

"The Lord of Moses and Aaron."

# 1077

Said Pharaoh: "Believe ye in Him before I give you permission? Surely this is a trick which ye have planned in the city to drive out its people: but soon shall ye know (the consequences).

# 1078

"Be sure I will cut off your hands and your feet on apposite sides, and I will cause you all to die on the cross."

# 1079

They said: "For us, We are but sent back unto our Lord:

# 1080

"But thou dost wreak thy vengeance on us simply because we believed in the Signs of our Lord when they reached us! Our Lord! pour out on us patience and constancy, and take our souls unto thee as Muslims (who bow to thy will)!

# 1081

Said the chiefs of Pharaoh's people: "Wilt thou leave Moses and his people, to spread mischief in the land, and to abandon thee and thy gods?" He said: "Their male children will we slay; (only) their females will we save alive; and we have over them (power) irresistible."

# 1082

Said Moses to his people: "Pray for help from Allah, and (wait) in patience and constancy: for the earth is Allah's, to give as a heritage to such of His servants as He pleaseth; and the end is (best) for the righteous.

# 1083

They said: "We have had (nothing but) trouble, both before and after thou camest to us." He said: "It may be that your Lord will destroy your enemy and make you inheritors in the earth; that so He may try you by your deeds."

# 1084

We punished the people of Pharaoh with years (of droughts) and shortness of crops; that they might receive admonition.

# 1085

But when good (times) came, they said, "This is due to us;" When gripped by calamity, they ascribed it to evil omens connected with Moses and those with him! Behold! in truth the omens of evil are theirs in Allah's sight, but most of them do not understand!

# 1086

They said (to Moses): "Whatever be the Signs thou bringest, to work therewith thy sorcery on us, we shall never believe in thee.

# 1087

So We sent (plagues) on them: Wholesale death, Locusts, Lice, Frogs, And Blood: Signs openly self-explained: but they were steeped in arrogance,- a people given to sin.

# 1088

Every time the penalty fell on them, they said: "O Moses! on your behalf call on thy Lord in virtue of his promise to thee: If thou wilt remove the penalty from us, we shall truly believe in thee, and we shall send away the Children of Israel with thee."

# 1089

But every time We removed the penalty from them according to a fixed term which they had to fulfil,- Behold! they broke their word!

# 1090

So We exacted retribution from them: We drowned them in the sea, because they rejected Our Signs and failed to take warning from them.

# 1091

And We made a people, considered weak (and of no account), inheritors of lands in both east and west, - lands whereon We sent down Our blessings. The fair promise of thy Lord was fulfilled for the Children of Israel, because they had patience and constancy, and We levelled to the ground the great works and fine buildings which Pharaoh and his people erected (with such pride).

# 1092

We took the Children of Israel (with safety) across the sea. They came upon a people devoted entirely to some idols they had. They said: "O Moses! fashion for us a god like unto the gods they have." He said: "Surely ye are a people without knowledge.

# 1093

"As to these folk,- the cult they are in is (but) a fragment of a ruin, and vain is the (worship) which they practise."

# 1094

He said: "Shall I seek for you a god other than the (true) Allah, when it is Allah Who hath endowed you with gifts above the nations?"

# 1095

And remember We rescued you from Pharaoh's people, who afflicted you with the worst of penalties, who slew your male children and saved alive your females: in that was a momentous trial from your Lord.

# 1096

We appointed for Moses thirty nights, and completed (the period) with ten (more): thus was completed the term (of communion) with his Lord, forty nights. And Moses had charged his brother Aaron (before he went up): "Act for me amongst my people: Do right, and follow not the way of those who do mischief."

# 1097

When Moses came to the place appointed by Us, and his Lord addressed him, He said: "O my Lord! show (Thyself) to me, that I may look upon thee." Allah said: "By no means canst thou see Me (direct); But look upon the mount; if it abide in its place, then shalt thou see Me." When his Lord manifested His glory on the Mount, He made it as dust. And Moses fell down in a swoon. When he recovered his senses he said: "Glory be to Thee! to Thee I turn in repentance, and I am the first to believe."

# 1098

(Allah) said: "O Moses! I have chosen thee above (other) men, by the mission I (have given thee) and the words I (have spoken to thee): take then the (revelation) which I give thee, and be of those who give thanks."

# 1099

And We ordained laws for him in the tablets in all matters, both commanding and explaining all things, (and said): "Take and hold these with firmness, and enjoin thy people to hold fast by the best in the precepts: soon shall I show you the homes of the wicked,- (How they lie desolate)."

# 1100

Those who behave arrogantly on the earth in defiance of right - them will I turn away from My signs: Even if they see all the signs, they will not believe in them; and if they see the way of right conduct, they will not adopt it as the way; but if they see the way of error, that is the way they will adopt. For they have rejected our signs, and failed to take warning from them.

# 1101

Those who reject Our signs and the meeting in the Hereafter,- vain are their deeds: Can they expect to be rewarded except as they have wrought?

# 1102

The people of Moses made, in his absence, out of their ornaments, the image of calf, (for worship): it seemed to low: did they not see that it could neither speak to them, nor show them the way? They took it for worship and they did wrong.

# 1103

When they repented, and saw that they had erred, they said: "If our Lord have not mercy upon us and forgive us, we shall indeed be of those who perish."

# 1104

When Moses came back to his people, angry and grieved, he said: "Evil it is that ye have done in my place in my absence: did ye make haste to bring on the judgment of your Lord?" He put down the tablets, seized his brother by (the hair of) his head, and dragged him to him. Aaron said: "Son of my mother! the people did indeed reckon me as naught, and went near to slaying me! Make not the enemies rejoice over my misfortune, nor count thou me amongst the people of sin."

# 1105

Moses prayed: "O my Lord! forgive me and my brother! admit us to Thy mercy! for Thou art the Most Merciful of those who show mercy!"

# 1106

Those who took the calf (for worship) will indeed be overwhelmed with wrath from their Lord, and with shame in this life: thus do We recompense those who invent (falsehoods).

# 1107

But those who do wrong but repent thereafter and (truly) believe,- verily thy Lord is thereafter Oft-Forgiving, Most Merciful.

# 1108

When the anger of Moses was appeased, he took up the tablets: in the writing thereon was guidance and Mercy for such as fear their Lord.

# 1109

And Moses chose seventy of his people for Our place of meeting: when they were seized with violent quaking, he prayed: "O my Lord! if it had been Thy will Thou couldst have destroyed, long before, both them and me: wouldst Thou destroy us for the deeds of the foolish ones among us? this is no more than Thy trial: by it Thou causest whom Thou wilt to stray, and Thou leadest whom Thou wilt into the right path. Thou art our Protector: so forgive us and give us Thy mercy; for Thou art the best of those who forgive.

# 1110

"And ordain for us that which is good, in this life and in the Hereafter: for we have turned unto Thee." He said: "With My punishment I visit whom I will; but My mercy extendeth to all things. That (mercy) I shall ordain for those who do right, and practise regular charity, and those who believe in Our signs;-

# 1111

"Those who follow the messenger, the unlettered Prophet, whom they find mentioned in their own (scriptures),- in the law and the Gospel;- for he commands them what is just and forbids them what is evil; he allows them as lawful what is good (and pure) and prohibits them from what is bad (and impure); He releases them from their heavy burdens and from the yokes that are upon them. So it is those who believe in him, honour him, help him, and follow the light which is sent down with him,- it is they who will prosper."

# 1112

Say: "O men! I am sent unto you all, as the Messenger of Allah, to Whom belongeth the dominion of the heavens and the earth: there is no god but He: it is He That giveth both life and death. So believe in Allah and His Messenger, the Unlettered Prophet, who believeth in Allah and His words: follow him that (so) ye may be guided."

# 1113

Of the people of Moses there is a section who guide and do justice in the light of truth.

# 1114

We divided them into twelve tribes or nations. We directed Moses by inspiration, when his (thirsty) people asked him for water: "Strike the rock with thy staff": out of it there gushed forth twelve springs: Each group knew its own place for water. We gave them the shade of clouds, and sent down to them manna and quails, (saying): "Eat of the good things We have provided for you": (but they rebelled); to Us they did no harm, but they harmed their own souls.

# 1115

And remember it was said to them: "Dwell in this town and eat therein as ye wish, but say the word of humility and enter the gate in a posture of humility: We shall forgive you your faults; We shall increase (the portion of) those who do good."

# 1116

But the transgressors among them changed the word from that which had been given them so we sent on them a plague from heaven. For that they repeatedly transgressed.

# 1117

Ask them concerning the town standing close by the sea. Behold! they transgressed in the matter of the Sabbath. For on the day of their Sabbath their fish did come to them, openly holding up their heads, but on the day they had no Sabbath, they came not: thus did We make a trial of them, for they were given to transgression.

# 1118

When some of them said: "Why do ye preach to a people whom Allah will destroy or visit with a terrible punishment?"- said the preachers:" To discharge our duty to your Lord, and perchance they may fear Him."

# 1119

When they disregarded the warnings that had been given them, We rescued those who forbade Evil; but We visited the wrong-doers with a grievous punishment because they were given to transgression.

# 1120

When in their insolence they transgressed (all) prohibitions, We said to them: "Be ye apes, despised and rejected."

# 1121

Behold! thy Lord did declare that He would send against them, to the Day of Judgment, those who would afflict them with grievous penalty. Thy Lord is quick in retribution, but He is also Oft-forgiving, Most Merciful.

# 1122

We broke them up into sections on this earth. There are among them some that are the righteous, and some that are the opposite. We have tried them with both prosperity and adversity: In order that they might turn (to us).

# 1123

After them succeeded an (evil) generation: They inherited the Book, but they chose (for themselves) the vanities of this world, saying (for excuse): "(Everything) will be forgiven us." (Even so), if similar vanities came their way, they would (again) seize them. Was not the covenant of the Book taken from them, that they would not ascribe to Allah anything but the truth? and they study what is in the Book. But best for the righteous is the home in the Hereafter. Will ye not understand?

# 1124

As to those who hold fast by the Book and establish regular prayer,- never shall We suffer the reward of the righteous to perish.

# 1125

When We shook the Mount over them, as if it had been a canopy, and they thought it was going to fall on them (We said): "Hold firmly to what We have given you, and bring (ever) to remembrance what is therein; perchance ye may fear Allah."

# 1126

When thy Lord drew forth from the Children of Adam - from their loins - their descendants, and made them testify concerning themselves, (saying): "Am I not your Lord (who cherishes and sustains you)?"- They said: "Yea! We do testify!" (This), lest ye should say on the Day of Judgment: "Of this we were never mindful":

# 1127

Or lest ye should say: "Our fathers before us may have taken false gods, but we are (their) descendants after them: wilt Thou then destroy us because of the deeds of men who were futile?"

# 1128

Thus do We explain the signs in detail; and perchance they may turn (unto Us).

# 1129

Relate to them the story of the man to whom We sent Our signs, but he passed them by: so Satan followed him up, and he went astray.

# 1130

If it had been Our will, We should have elevated him with Our signs; but he inclined to the earth, and followed his own vain desires. His similitude is that of a dog: if you attack him, he lolls out his tongue, or if you leave him alone, he (still) lolls out his tongue. That is the similitude of those who reject Our signs; So relate the story; perchance they may reflect.

# 1131

Evil as an example are people who reject Our signs and wrong their own souls.

# 1132

Whom Allah doth guide,- he is on the right path: whom He rejects from His guidance,- such are the persons who perish.

# 1133

Many are the Jinns and men we have made for Hell: They have hearts wherewith they understand not, eyes wherewith they see not, and ears wherewith they hear not. They are like cattle,- nay more misguided: for they are heedless (of warning).

# 1134

The most beautiful names belong to Allah: so call on him by them; but shun such men as use profanity in his names: for what they do, they will soon be requited.

# 1135

Of those We have created are people who direct (others) with truth. And dispense justice therewith.

# 1136

Those who reject Our signs, We shall gradually visit with punishment, in ways they perceive not;

# 1137

Respite will I grant unto them: for My scheme is strong (and unfailing).

# 1138

Do they not reflect? Their companion is not seized with madness: he is but a perspicuous warner.

# 1139

Do they see nothing in the government of the heavens and the earth and all that Allah hath created? (Do they not see) that it may well be that their terms is nigh drawing to an end? In what message after this will they then believe?

# 1140

To such as Allah rejects from His guidance, there can be no guide: He will leave them in their trespasses, wandering in distraction.

# 1141

They ask thee about the (final) Hour - when will be its appointed time? Say: "The knowledge thereof is with my Lord (alone): None but He can reveal as to when it will occur. Heavy were its burden through the heavens and the earth. Only, all of a sudden will it come to you." They ask thee as if thou Wert eager in search thereof: Say: "The knowledge thereof is with Allah (alone), but most men know not."

# 1142

Say: "I have no power over any good or harm to myself except as Allah willeth. If I had knowledge of the unseen, I should have multiplied all good, and no evil should have touched me: I am but a warner, and a bringer of glad tidings to those who have faith."

# 1143

It is He Who created you from a single person, and made his mate of like nature, in order that he might dwell with her (in love). When they are united, she bears a light burden and carries it about (unnoticed). When she grows heavy, they both pray to Allah their Lord, (saying): "If Thou givest us a goodly child, we vow we shall (ever) be grateful."

# 1144

But when He giveth them a goodly child, they ascribe to others a share in the gift they have received: but Allah is exalted high above the partners they ascribe to Him.

# 1145

Do they indeed ascribe to Him as partners things that can create nothing, but are themselves created?

# 1146

No aid can they give them, nor can they aid themselves!

# 1147

If ye call them to guidance, they will not obey: For you it is the same whether ye call them or ye hold your peace!

# 1148

Verily those whom ye call upon besides Allah are servants like unto you: Call upon them, and let them listen to your prayer, if ye are (indeed) truthful!

# 1149

Have they feet to walk with? Or hands to lay hold with? Or eyes to see with? Or ears to hear with? Say: "Call your 'god-partners', scheme (your worst) against me, and give me no respite!

# 1150

"For my Protector is Allah, Who revealed the Book (from time to time), and He will choose and befriend the righteous.

# 1151

"But those ye call upon besides Him, are unable to help you, and indeed to help themselves."

# 1152

If thou callest them to guidance, they hear not. Thou wilt see them looking at thee, but they see not.

# 1153

Hold to forgiveness; command what is right; But turn away from the ignorant.

# 1154

If a suggestion from Satan assail thy (mind), seek refuge with Allah; for He heareth and knoweth (all things).

# 1155

Those who fear Allah, when a thought of evil from Satan assaults them, bring Allah to remembrance, when lo! they see (aright)!

# 1156

But their brethren (the evil ones) plunge them deeper into error, and never relax (their efforts).

# 1157

If thou bring them not a revelation, they say: "Why hast thou not got it together?" Say: "I but follow what is revealed to me from my Lord: this is (nothing but) lights from your Lord, and Guidance, and mercy, for any who have faith."

# 1158

When the Qur'an is read, listen to it with attention, and hold your peace: that ye may receive Mercy.

# 1159

And do thou (O reader!) Bring thy Lord to remembrance in thy (very) soul, with humility and in reverence, without loudness in words, in the mornings and evenings; and be not thou of those who are unheedful.

# 1160

Those who are near to thy Lord, disdain not to do Him worship: They celebrate His praises, and prostrate before Him.

# 1161

They ask thee concerning (things taken as) spoils of war. Say: "(such) spoils are at the disposal of Allah and the Messenger: So fear Allah, and keep straight the relations between yourselves: Obey Allah and His Messenger, if ye do believe."

# 1162

For, Believers are those who, when Allah is mentioned, feel a tremor in their hearts, and when they hear His signs rehearsed, find their faith strengthened, and put (all) their trust in their Lord;

# 1163

Who establish regular prayers and spend (freely) out of the gifts We have given them for sustenance:

# 1164

Such in truth are the believers: they have grades of dignity with their Lord, and forgiveness, and generous sustenance:

# 1165

Just as thy Lord ordered thee out of thy house in truth, even though a party among the Believers disliked it,

# 1166

Disputing with thee concerning the truth after it was made manifest, as if they were being driven to death and they (actually) saw it.

# 1167

Behold! Allah promised you one of the two (enemy) parties, that it should be yours: Ye wished that the one unarmed should be yours, but Allah willed to justify the Truth according to His words and to cut off the roots of the Unbelievers;-

# 1168

That He might justify Truth and prove Falsehood false, distasteful though it be to those in guilt.

# 1169

Remember ye implored the assistance of your Lord, and He answered you: "I will assist you with a thousand of the angels, ranks on ranks."

# 1170

Allah made it but a message of hope, and an assurance to your hearts: (in any case) there is no help except from Allah: and Allah is Exalted in Power, Wise.

# 1171

Remember He covered you with a sort of drowsiness, to give you calm as from Himself, and he caused rain to descend on you from heaven, to clean you therewith, to remove from you the stain of Satan, to strengthen your hearts, and to plant your feet firmly therewith.

# 1172

Remember thy Lord inspired the angels (with the message): "I am with you: give firmness to the Believers: I will instil terror into the hearts of the Unbelievers: smite ye above their necks and smite all their finger-tips off them."

# 1173

This because they contended against Allah and His Messenger: If any contend against Allah and His Messenger, Allah is strict in punishment.

# 1174

Thus (will it be said): "Taste ye then of the (punishment): for those who resist Allah, is the penalty of the Fire."

# 1175

O ye who believe! when ye meet the Unbelievers in hostile array, never turn your backs to them.

# 1176

If any do turn his back to them on such a day - unless it be in a stratagem of war, or to retreat to a troop (of his own)- he draws on himself the wrath of Allah, and his abode is Hell,- an evil refuge (indeed)!

# 1177

It is not ye who slew them; it was Allah: when thou threwest (a handful of dust), it was not thy act, but Allah's: in order that He might test the Believers by a gracious trial from Himself: for Allah is He Who heareth and knoweth (all things).

# 1178

That, and also because Allah is He Who makes feeble the plans and stratagem of the Unbelievers.

# 1179

(O Unbelievers!) if ye prayed for victory and judgment, now hath the judgment come to you: if ye desist (from wrong), it will be best for you: if ye return (to the attack), so shall We. Not the least good will your forces be to you even if they were multiplied: for verily Allah is with those who believe!

# 1180

O ye who believe! Obey Allah and His Messenger, and turn not away from him when ye hear (him speak).

# 1181

Nor be like those who say, "We hear," but listen not:

# 1182

For the worst of beasts in the sight of Allah are the deaf and the dumb,- those who understand not.

# 1183

If Allah had found in them any good. He would indeed have made them listen: (As it is), if He had made them listen, they would but have turned back and declined (Faith).

# 1184

O ye who believe! give your response to Allah and His Messenger, when He calleth you to that which will give you life; and know that Allah cometh in between a man and his heart, and that it is He to Whom ye shall (all) be gathered.

# 1185

And fear tumult or oppression, which affecteth not in particular (only) those of you who do wrong: and know that Allah is strict in punishment.

# 1186

Call to mind when ye were a small (band), despised through the land, and afraid that men might despoil and kidnap you; But He provided a safe asylum for you, strengthened you with His aid, and gave you Good things for sustenance: that ye might be grateful.

# 1187

O ye that believe! betray not the trust of Allah and the Messenger, nor misappropriate knowingly things entrusted to you.

# 1188

And know ye that your possessions and your progeny are but a trial; and that it is Allah with Whom lies your highest reward.

# 1189

O ye who believe! if ye fear Allah, He will grant you a criterion (to judge between right and wrong), remove from you (all) evil (that may afflict) you, and forgive you: for Allah is the Lord of grace unbounded.

# 1190

Remember how the Unbelievers plotted against thee, to keep thee in bonds, or slay thee, or get thee out (of thy home). They plot and plan, and Allah too plans; but the best of planners is Allah.

# 1191

When Our Signs are rehearsed to them, they say: "We have heard this (before): if we wished, we could say (words) like these: these are nothing but tales of the ancients."

# 1192

Remember how they said: "O Allah if this is indeed the Truth from Thee, rain down on us a shower of stones form the sky, or send us a grievous penalty."

# 1193

But Allah was not going to send them a penalty whilst thou wast amongst them; nor was He going to send it whilst they could ask for pardon.

# 1194

But what plea have they that Allah should not punish them, when they keep out (men) from the sacred Mosque - and they are not its guardians? No men can be its guardians except the righteous; but most of them do not understand.

# 1195

Their prayer at the House (of Allah) is nothing but whistling and clapping of hands: (Its only answer can be), "Taste ye the penalty because ye blasphemed."

# 1196

The Unbelievers spend their wealth to hinder (man) from the path of Allah, and so will they continue to spend; but in the end they will have (only) regrets and sighs; at length they will be overcome: and the Unbelievers will be gathered together to Hell;-

# 1197

In order that Allah may separate the impure from the pure, put the impure, one on another, heap them together, and cast them into Hell. They will be the ones to have lost.

# 1198

Say to the Unbelievers, if (now) they desist (from Unbelief), their past would be forgiven them; but if they persist, the punishment of those before them is already (a matter of warning for them).

# 1199

And fight them on until there is no more tumult or oppression, and there prevail justice and faith in Allah altogether and everywhere; but if they cease, verily Allah doth see all that they do.

# 1200

If they refuse, be sure that Allah is your Protector - the best to protect and the best to help.

# 1201

And know that out of all the booty that ye may acquire (in war), a fifth share is assigned to Allah,- and to the Messenger, and to near relatives, orphans, the needy, and the wayfarer,- if ye do believe in Allah and in the revelation We sent down to Our servant on the Day of Testing,- the Day of the meeting of the two forces. For Allah hath power over all things.

# 1202

Remember ye were on the hither side of the valley, and they on the farther side, and the caravan on lower ground than ye. Even if ye had made a mutual appointment to meet, ye would certainly have failed in the appointment: But (thus ye met), that Allah might accomplish a matter already enacted; that those who died might die after a clear Sign (had been given), and those who lived might live after a Clear Sign (had been given). And verily Allah is He Who heareth and knoweth (all things).

# 1203

Remember in thy dream Allah showed them to thee as few: if He had shown them to thee as many, ye would surely have been discouraged, and ye would surely have disputed in (your) decision; but Allah saved (you): for He knoweth well the (secrets) of (all) hearts.

# 1204

And remember when ye met, He showed them to you as few in your eyes, and He made you appear as contemptible in their eyes: that Allah might accomplish a matter already enacted. For to Allah do all questions go back (for decision).

# 1205

O ye who believe! When ye meet a force, be firm, and call Allah in remembrance much (and often); that ye may prosper:

# 1206

And obey Allah and His Messenger; and fall into no disputes, lest ye lose heart and your power depart; and be patient and persevering: For Allah is with those who patiently persevere:

# 1207

And be not like those who started from their homes insolently and to be seen of men, and to hinder (men) from the path of Allah: For Allah compasseth round about all that they do.

# 1208

Remember Satan made their (sinful) acts seem alluring to them, and said: "No one among men can overcome you this day, while I am near to you": But when the two forces came in sight of each other, he turned on his heels, and said: "Lo! I am clear of you; lo! I see what ye see not; Lo! I fear Allah: for Allah is strict in punishment."

# 1209

Lo! the hypocrites say, and those in whose hearts is a disease: "These people,- their religion has misled them." But if any trust in Allah, behold! Allah is Exalted in might, Wise.

# 1210

If thou couldst see, when the angels take the souls of the Unbelievers (at death), (How) they smite their faces and their backs, (saying): "Taste the penalty of the blazing Fire-

# 1211

"Because of (the deeds) which your (own) hands sent forth; for Allah is never unjust to His servants:

# 1212

"(Deeds) after the manner of the people of Pharaoh and of those before them: They rejected the Signs of Allah, and Allah punished them for their crimes: for Allah is Strong, and Strict in punishment:

# 1213

"Because Allah will never change the grace which He hath bestowed on a people until they change what is in their (own) souls: and verily Allah is He Who heareth and knoweth (all things)."

# 1214

(Deeds) after the manner of the people of Pharaoh and those before them": They treated as false the Signs of their Lord: so We destroyed them for their crimes, and We drowned the people of Pharaoh: for they were all oppressors and wrong-doers.

# 1215

For the worst of beasts in the sight of Allah are those who reject Him: They will not believe.

# 1216

They are those with whom thou didst make a covenant, but they break their covenant every time, and they have not the fear (of Allah).

# 1217

If ye gain the mastery over them in war, disperse, with them, those who follow them, that they may remember.

# 1218

If thou fearest treachery from any group, throw back (their covenant) to them, (so as to be) on equal terms: for Allah loveth not the treacherous.

# 1219

Let not the unbelievers think that they can get the better (of the godly): they will never frustrate (them).

# 1220

Against them make ready your strength to the utmost of your power, including steeds of war, to strike terror into (the hearts of) the enemies, of Allah and your enemies, and others besides, whom ye may not know, but whom Allah doth know. Whatever ye shall spend in the cause of Allah, shall be repaid unto you, and ye shall not be treated unjustly.

# 1221

But if the enemy incline towards peace, do thou (also) incline towards peace, and trust in Allah: for He is One that heareth and knoweth (all things).

# 1222

Should they intend to deceive thee,- verily Allah sufficeth thee: He it is That hath strengthened thee with His aid and with (the company of) the Believers;

# 1223

And (moreover) He hath put affection between their hearts: not if thou hadst spent all that is in the earth, couldst thou have produced that affection, but Allah hath done it: for He is Exalted in might, Wise.

# 1224

O Prophet! sufficient unto thee is Allah,- (unto thee) and unto those who follow thee among the Believers.

# 1225

O Prophet! rouse the Believers to the fight. If there are twenty amongst you, patient and persevering, they will vanquish two hundred: if a hundred, they will vanquish a thousand of the Unbelievers: for these are a people without understanding.

# 1226

For the present, Allah hath lightened your (task), for He knoweth that there is a weak spot in you: But (even so), if there are a hundred of you, patient and persevering, they will vanquish two hundred, and if a thousand, they will vanquish two thousand, with the leave of Allah: for Allah is with those who patiently persevere.

# 1227

It is not fitting for a prophet that he should have prisoners of war until he hath thoroughly subdued the land. Ye look for the temporal goods of this world; but Allah looketh to the Hereafter: And Allah is Exalted in might, Wise.

# 1228

Had it not been for a previous ordainment from Allah, a severe penalty would have reached you for the (ransom) that ye took.

# 1229

But (now) enjoy what ye took in war, lawful and good: but fear Allah: for Allah is Oft-forgiving, Most Merciful.

# 1230

O Prophet! say to those who are captives in your hands: "If Allah findeth any good in your hearts, He will give you something better than what has been taken from you, and He will forgive you: for Allah is Oft-forgiving, Most Merciful."

# 1231

But if they have treacherous designs against thee, (O Messenger!), they have already been in treason against Allah, and so hath He given (thee) power over them. And Allah so He Who hath (full) knowledge and wisdom.

# 1232

Those who believed, and adopted exile, and fought for the Faith, with their property and their persons, in the cause of Allah, as well as those who gave (them) asylum and aid,- these are (all) friends and protectors, one of another. As to those who believed but came not into exile, ye owe no duty of protection to them until they come into exile; but if they seek your aid in religion, it is your duty to help them, except against a people with whom ye have a treaty of mutual alliance. And (remember) Allah seeth all that ye do.

# 1233

The Unbelievers are protectors, one of another: Unless ye do this, (protect each other), there would be tumult and oppression on earth, and great mischief.

# 1234

Those who believe, and adopt exile, and fight for the Faith, in the cause of Allah as well as those who give (them) asylum and aid,- these are (all) in very truth the Believers: for them is the forgiveness of sins and a provision most generous.

# 1235

And those who accept Faith subsequently, and adopt exile, and fight for the Faith in your company,- they are of you. But kindred by blood have prior rights against each other in the Book of Allah. Verily Allah is well-acquainted with all things.

# 1236

A (declaration) of immunity from Allah and His Messenger, to those of the Pagans with whom ye have contracted mutual alliances:-

# 1237

Go ye, then, for four months, backwards and forwards, (as ye will), throughout the land, but know ye that ye cannot frustrate Allah (by your falsehood) but that Allah will cover with shame those who reject Him.

# 1238

And an announcement from Allah and His Messenger, to the people (assembled) on the day of the Great Pilgrimage,- that Allah and His Messenger dissolve (treaty) obligations with the Pagans. If then, ye repent, it were best for you; but if ye turn away, know ye that ye cannot frustrate Allah. And proclaim a grievous penalty to those who reject Faith.

# 1239

(But the treaties are) not dissolved with those Pagans with whom ye have entered into alliance and who have not subsequently failed you in aught, nor aided any one against you. So fulfil your engagements with them to the end of their term: for Allah loveth the righteous.

# 1240

But when the forbidden months are past, then fight and slay the Pagans wherever ye find them, an seize them, beleaguer them, and lie in wait for them in every stratagem (of war); but if they repent, and establish regular prayers and practise regular charity, then open the way for them: for Allah is Oft-forgiving, Most Merciful.

# 1241

If one amongst the Pagans ask thee for asylum, grant it to him, so that he may hear the word of Allah; and then escort him to where he can be secure. That is because they are men without knowledge.

# 1242

How can there be a league, before Allah and His Messenger, with the Pagans, except those with whom ye made a treaty near the sacred Mosque? As long as these stand true to you, stand ye true to them: for Allah doth love the righteous.

# 1243

How (can there be such a league), seeing that if they get an advantage over you, they respect not in you the ties either of kinship or of covenant? With (fair words from) their mouths they entice you, but their hearts are averse from you; and most of them are rebellious and wicked.

# 1244

The Signs of Allah have they sold for a miserable price, and (many) have they hindered from His way: evil indeed are the deeds they have done.

# 1245

In a Believer they respect not the ties either of kinship or of covenant! It is they who have transgressed all bounds.

# 1246

But (even so), if they repent, establish regular prayers, and practise regular charity,- they are your brethren in Faith: (thus) do We explain the Signs in detail, for those who understand.

# 1247

But if they violate their oaths after their covenant, and taunt you for your Faith,- fight ye the chiefs of Unfaith: for their oaths are nothing to them: that thus they may be restrained.

# 1248

Will ye not fight people who violated their oaths, plotted to expel the Messenger, and took the aggressive by being the first (to assault) you? Do ye fear them? Nay, it is Allah Whom ye should more justly fear, if ye believe!

# 1249

Fight them, and Allah will punish them by your hands, cover them with shame, help you (to victory) over them, heal the breasts of Believers,

# 1250

And still the indignation of their hearts. For Allah will turn (in mercy) to whom He will; and Allah is All-Knowing, All-Wise.

# 1251

Or think ye that ye shall be abandoned, as though Allah did not know those among you who strive with might and main, and take none for friends and protectors except Allah, His Messenger, and the (community of) Believers? But Allah is well-acquainted with (all) that ye do.

# 1252

It is not for such as join gods with Allah, to visit or maintain the mosques of Allah while they witness against their own souls to infidelity. The works of such bear no fruit: In Fire shall they dwell.

# 1253

The mosques of Allah shall be visited and maintained by such as believe in Allah and the Last Day, establish regular prayers, and practise regular charity, and fear none (at all) except Allah. It is they who are expected to be on true guidance.

# 1254

Do ye make the giving of drink to pilgrims, or the maintenance of the Sacred Mosque, equal to (the pious service of) those who believe in Allah and the Last Day, and strive with might and main in the cause of Allah? They are not comparable in the sight of Allah: and Allah guides not those who do wrong.

# 1255

Those who believe, and suffer exile and strive with might and main, in Allah's cause, with their goods and their persons, have the highest rank in the sight of Allah: they are the people who will achieve (salvation).

# 1256

Their Lord doth give them glad tidings of a Mercy from Himself, of His good pleasure, and of gardens for them, wherein are delights that endure:

# 1257

They will dwell therein for ever. Verily in Allah's presence is a reward, the greatest (of all).

# 1258

O ye who believe! take not for protectors your fathers and your brothers if they love infidelity above Faith: if any of you do so, they do wrong.

# 1259

Say: If it be that your fathers, your sons, your brothers, your mates, or your kindred; the wealth that ye have gained; the commerce in which ye fear a decline: or the dwellings in which ye delight - are dearer to you than Allah, or His Messenger, or the striving in His cause;- then wait until Allah brings about His decision: and Allah guides not the rebellious.

# 1260

Assuredly Allah did help you in many battle-fields and on the day of Hunain: Behold! your great numbers elated you, but they availed you naught: the land, for all that it is wide, did constrain you, and ye turned back in retreat.

# 1261

But Allah did pour His calm on the Messenger and on the Believers, and sent down forces which ye saw not: He punished the Unbelievers; thus doth He reward those without Faith.

# 1262

Again will Allah, after this, turn (in mercy) to whom He will: for Allah is Oft-forgiving, Most Merciful.

# 1263

O ye who believe! Truly the Pagans are unclean; so let them not, after this year of theirs, approach the Sacred Mosque. And if ye fear poverty, soon will Allah enrich you, if He wills, out of His bounty, for Allah is All-knowing, All-wise.

# 1264

Fight those who believe not in Allah nor the Last Day, nor hold that forbidden which hath been forbidden by Allah and His Messenger, nor acknowledge the religion of Truth, (even if they are) of the People of the Book, until they pay the Jizya with willing submission, and feel themselves subdued.

# 1265

The Jews call 'Uzair a son of Allah, and the Christians call Christ the son of Allah. That is a saying from their mouth; (in this) they but imitate what the unbelievers of old used to say. Allah's curse be on them: how they are deluded away from the Truth!

# 1266

They take their priests and their anchorites to be their lords in derogation of Allah, and (they take as their Lord) Christ the son of Mary; yet they were commanded to worship but One Allah: there is no god but He. Praise and glory to Him: (Far is He) from having the partners they associate (with Him).

# 1267

Fain would they extinguish Allah's light with their mouths, but Allah will not allow but that His light should be perfected, even though the Unbelievers may detest (it).

# 1268

It is He Who hath sent His Messenger with guidance and the Religion of Truth, to proclaim it over all religion, even though the Pagans may detest (it).

# 1269

O ye who believe! there are indeed many among the priests and anchorites, who in Falsehood devour the substance of men and hinder (them) from the way of Allah. And there are those who bury gold and silver and spend it not in the way of Allah: announce unto them a most grievous penalty-

# 1270

On the Day when heat will be produced out of that (wealth) in the fire of Hell, and with it will be branded their foreheads, their flanks, and their backs, their flanks, and their backs.- "This is the (treasure) which ye buried for yourselves: taste ye, then, the (treasures) ye buried!"

# 1271

The number of months in the sight of Allah is twelve (in a year)- so ordained by Him the day He created the heavens and the earth; of them four are sacred: that is the straight usage. So wrong not yourselves therein, and fight the Pagans all together as they fight you all together. But know that Allah is with those who restrain themselves.

# 1272

Verily the transposing (of a prohibited month) is an addition to Unbelief: the Unbelievers are led to wrong thereby: for they make it lawful one year, and forbidden another year, in order to adjust the number of months forbidden by Allah and make such forbidden ones lawful. The evil of their course seems pleasing to them. But Allah guideth not those who reject Faith.

# 1273

O ye who believe! what is the matter with you, that, when ye are asked to go forth in the cause of Allah, ye cling heavily to the earth? Do ye prefer the life of this world to the Hereafter? But little is the comfort of this life, as compared with the Hereafter.

# 1274

Unless ye go forth, He will punish you with a grievous penalty, and put others in your place; but Him ye would not harm in the least. For Allah hath power over all things.

# 1275

If ye help not (your leader), (it is no matter): for Allah did indeed help him, when the Unbelievers drove him out: he had no more than one companion; they two were in the cave, and he said to his companion, "Have no fear, for Allah is with us": then Allah sent down His peace upon him, and strengthened him with forces which ye saw not, and humbled to the depths the word of the Unbelievers. But the word of Allah is exalted to the heights: for Allah is Exalted in might, Wise.

# 1276

Go ye forth, (whether equipped) lightly or heavily, and strive and struggle, with your goods and your persons, in the cause of Allah. That is best for you, if ye (but) knew.

# 1277

If there had been immediate gain (in sight), and the journey easy, they would (all) without doubt have followed thee, but the distance was long, (and weighed) on them. They would indeed swear by Allah, "If we only could, we should certainly have come out with you": They would destroy their own souls; for Allah doth know that they are certainly lying.

# 1278

Allah give thee grace! why didst thou grant them until those who told the truth were seen by thee in a clear light, and thou hadst proved the liars?

# 1279

Those who believe in Allah and the Last Day ask thee for no exemption from fighting with their goods and persons. And Allah knoweth well those who do their duty.

# 1280

Only those ask thee for exemption who believe not in Allah and the Last Day, and whose hearts are in doubt, so that they are tossed in their doubts to and fro.

# 1281

If they had intended to come out, they would certainly have made some preparation therefor; but Allah was averse to their being sent forth; so He made them lag behind, and they were told, "Sit ye among those who sit (inactive)."

# 1282

If they had come out with you, they would not have added to your (strength) but only (made for) disorder, hurrying to and fro in your midst and sowing sedition among you, and there would have been some among you who would have listened to them. But Allah knoweth well those who do wrong.

# 1283

Indeed they had plotted sedition before, and upset matters for thee, until,- the Truth arrived, and the Decree of Allah became manifest much to their disgust.

# 1284

Among them is (many) a man who says: "Grant me exemption and draw me not into trial." Have they not fallen into trial already? and indeed Hell surrounds the Unbelievers (on all sides).

# 1285

If good befalls thee, it grieves them; but if a misfortune befalls thee, they say, "We took indeed our precautions beforehand," and they turn away rejoicing.

# 1286

Say: "Nothing will happen to us except what Allah has decreed for us: He is our protector": and on Allah let the Believers put their trust.

# 1287

Say: "Can you expect for us (any fate) other than one of two glorious things- (Martyrdom or victory)? But we can expect for you either that Allah will send his punishment from Himself, or by our hands. So wait (expectant); we too will wait with you."

# 1288

Say: "Spend (for the cause) willingly or unwillingly: not from you will it be accepted: for ye are indeed a people rebellious and wicked."

# 1289

The only reasons why their contributions are not accepted are: that they reject Allah and His Messenger; that they come to prayer without earnestness; and that they offer contributions unwillingly.

# 1290

Let not their wealth nor their (following in) sons dazzle thee: in reality Allah's plan is to punish them with these things in this life, and that their souls may perish in their (very) denial of Allah.

# 1291

They swear by Allah that they are indeed of you; but they are not of you: yet they are afraid (to appear in their true colours).

# 1292

If they could find a place to flee to, or caves, or a place of concealment, they would turn straightaway thereto, with an obstinate rush.

# 1293

And among them are men who slander thee in the matter of (the distribution of) the alms: if they are given part thereof, they are pleased, but if not, behold! they are indignant!

# 1294

If only they had been content with what Allah and His Messenger gave them, and had said, "Sufficient unto us is Allah! Allah and His Messenger will soon give us of His bounty: to Allah do we turn our hopes!" (that would have been the right course).

# 1295

Alms are for the poor and the needy, and those employed to administer the (funds); for those whose hearts have been (recently) reconciled (to Truth); for those in bondage and in debt; in the cause of Allah; and for the wayfarer: (thus is it) ordained by Allah, and Allah is full of knowledge and wisdom.

# 1296

Among them are men who molest the Prophet and say, "He is (all) ear." Say, "He listens to what is best for you: he believes in Allah, has faith in the Believers, and is a Mercy to those of you who believe." But those who molest the Messenger will have a grievous penalty.

# 1297

To you they swear by Allah. In order to please you: But it is more fitting that they should please Allah and His Messenger, if they are Believers.

# 1298

Know they not that for those who oppose Allah and His Messenger, is the Fire of Hell?- wherein they shall dwell. That is the supreme disgrace.

# 1299

The Hypocrites are afraid lest a Sura should be sent down about them, showing them what is (really passing) in their hearts. Say: "Mock ye! But verily Allah will bring to light all that ye fear (should be revealed).

# 1300

If thou dost question them, they declare (with emphasis): "We were only talking idly and in play." Say: "Was it at Allah, and His Signs, and His Messenger, that ye were mocking?"

# 1301

Make ye no excuses: ye have rejected Faith after ye had accepted it. If We pardon some of you, We will punish others amongst you, for that they are in sin.

# 1302

The Hypocrites, men and women, (have an understanding) with each other: They enjoin evil, and forbid what is just, and are close with their hands. They have forgotten Allah; so He hath forgotten them. Verily the Hypocrites are rebellious and perverse.

# 1303

Allah hath promised the Hypocrites men and women, and the rejecters, of Faith, the fire of Hell: Therein shall they dwell: Sufficient is it for them: for them is the curse of Allah, and an enduring punishment,-

# 1304

As in the case of those before you: they were mightier than you in power, and more flourishing in wealth and children. They had their enjoyment of their portion: and ye have of yours, as did those before you; and ye indulge in idle talk as they did. They!- their work are fruitless in this world and in the Hereafter, and they will lose (all spiritual good).

# 1305

Hath not the story reached them of those before them?- the People of Noah, and 'Ad, and Thamud; the People of Abraham, the men of Midian, and the cities overthrown. To them came their messengers with clear signs. It is not Allah Who wrongs them, but they wrong their own souls.

# 1306

The Believers, men and women, are protectors one of another: they enjoin what is just, and forbid what is evil: they observe regular prayers, practise regular charity, and obey Allah and His Messenger. On them will Allah pour His mercy: for Allah is Exalted in power, Wise.

# 1307

Allah hath promised to Believers, men and women, gardens under which rivers flow, to dwell therein, and beautiful mansions in gardens of everlasting bliss. But the greatest bliss is the good pleasure of Allah: that is the supreme felicity.

# 1308

O Prophet! strive hard against the unbelievers and the Hypocrites, and be firm against them. Their abode is Hell,- an evil refuge indeed.

# 1309

They swear by Allah that they said nothing (evil), but indeed they uttered blasphemy, and they did it after accepting Islam; and they meditated a plot which they were unable to carry out: this revenge of theirs was (their) only return for the bounty with which Allah and His Messenger had enriched them! If they repent, it will be best for them; but if they turn back (to their evil ways), Allah will punish them with a grievous penalty in this life and in the Hereafter: They shall have none on earth to protect or help them.

# 1310

Amongst them are men who made a covenant with Allah, that if He bestowed on them of His bounty, they would give (largely) in charity, and be truly amongst those who are righteous.

# 1311

But when He did bestow of His bounty, they became covetous, and turned back (from their covenant), averse (from its fulfilment).

# 1312

So He hath put as a consequence hypocrisy into their hearts, (to last) till the Day, whereon they shall meet Him: because they broke their covenant with Allah, and because they lied (again and again).

# 1313

Know they not that Allah doth know their secret (thoughts) and their secret counsels, and that Allah knoweth well all things unseen?

# 1314

Those who slander such of the believers as give themselves freely to (deeds of) charity, as well as such as can find nothing to give except the fruits of their labour,- and throw ridicule on them,- Allah will throw back their ridicule on them: and they shall have a grievous penalty.

# 1315

Whether thou ask for their forgiveness, or not, (their sin is unforgivable): if thou ask seventy times for their forgiveness, Allah will not forgive them: because they have rejected Allah and His Messenger: and Allah guideth not those who are perversely rebellious.

# 1316

Those who were left behind (in the Tabuk expedition) rejoiced in their inaction behind the back of the Messenger of Allah: they hated to strive and fight, with their goods and their persons, in the cause of Allah: they said, "Go not forth in the heat." Say, "The fire of Hell is fiercer in heat." If only they could understand!

# 1317

Let them laugh a little: much will they weep: a recompense for the (evil) that they do.

# 1318

If, then, Allah bring thee back to any of them, and they ask thy permission to come out (with thee), say: "Never shall ye come out with me, nor fight an enemy with me: for ye preferred to sit inactive on the first occasion: Then sit ye (now) with those who lag behind."

# 1319

Nor do thou ever pray for any of them that dies, nor stand at his grave; for they rejected Allah and His Messenger, and died in a state of perverse rebellion.

# 1320

Nor let their wealth nor their (following in) sons dazzle thee: Allah's plan is to punish them with these things in this world, and that their souls may perish in their (very) denial of Allah.

# 1321

When a Sura comes down, enjoining them to believe in Allah and to strive and fight along with His Messenger, those with wealth and influence among them ask thee for exemption, and say: "Leave us (behind): we would be with those who sit (at home)."

# 1322

They prefer to be with (the women), who remain behind (at home): their hearts are sealed and so they understand not.

# 1323

But the Messenger, and those who believe with him, strive and fight with their wealth and their persons: for them are (all) good things: and it is they who will prosper.

# 1324

Allah hath prepared for them gardens under which rivers flow, to dwell therein: that is the supreme felicity.

# 1325

And there were, among the desert Arabs (also), men who made excuses and came to claim exemption; and those who were false to Allah and His Messenger (merely) sat inactive. Soon will a grievous penalty seize the Unbelievers among them.

# 1326

There is no blame on those who are infirm, or ill, or who find no resources to spend (on the cause), if they are sincere (in duty) to Allah and His Messenger: no ground (of complaint) can there be against such as do right: and Allah is Oft-forgiving, Most Merciful.

# 1327

Nor (is there blame) on those who came to thee to be provided with mounts, and when thou saidst, "I can find no mounts for you," they turned back, their eyes streaming with tears of grief that they had no resources wherewith to provide the expenses.

# 1328

The ground (of complaint) is against such as claim exemption while they are rich. They prefer to stay with the (women) who remain behind: Allah hath sealed their hearts; so they know not (What they miss).

# 1329

They will present their excuses to you when ye return to them. Say thou: "Present no excuses: we shall not believe you: Allah hath already informed us of the true state of matters concerning you: It is your actions that Allah and His Messenger will observe: in the end will ye be brought back to Him Who knoweth what is hidden and what is open: then will He show you the truth of all that ye did."

# 1330

They will swear to you by Allah, when ye return to them, that ye may leave them alone. So leave them alone: For they are an abomination, and Hell is their dwelling-place,-a fitting recompense for the (evil) that they did.

# 1331

They will swear unto you, that ye may be pleased with them but if ye are pleased with them, Allah is not pleased with those who disobey.

# 1332

The Arabs of the desert are the worst in Unbelief and hypocrisy, and most fitted to be in ignorance of the command which Allah hath sent down to His Messenger: But Allah is All-knowing, All-Wise.

# 1333

Some of the desert Arabs look upon their payments as a fine, and watch for disasters for you: on them be the disaster of evil: for Allah is He That heareth and knoweth (all things).

# 1334

But some of the desert Arabs believe in Allah and the Last Day, and look on their payments as pious gifts bringing them nearer to Allah and obtaining the prayers of the Messenger. Aye, indeed they bring them nearer (to Him): soon will Allah admit them to His Mercy: for Allah is Oft-forgiving, Most Merciful.

# 1335

The vanguard (of Islam)- the first of those who forsook (their homes) and of those who gave them aid, and (also) those who follow them in (all) good deeds,- well-pleased is Allah with them, as are they with Him: for them hath He prepared gardens under which rivers flow, to dwell therein for ever: that is the supreme felicity.

# 1336

Certain of the desert Arabs round about you are hypocrites, as well as (desert Arabs) among the Medina folk: they are obstinate in hypocrisy: thou knowest them not: We know them: twice shall We punish them: and in addition shall they be sent to a grievous penalty.

# 1337

Others (there are who) have acknowledged their wrong-doings: they have mixed an act that was good with another that was evil. Perhaps Allah will turn unto them (in Mercy): for Allah is Oft-Forgiving, Most Merciful.

# 1338

Of their goods, take alms, that so thou mightest purify and sanctify them; and pray on their behalf. Verily thy prayers are a source of security for them: And Allah is One Who heareth and knoweth.

# 1339

Know they not that Allah doth accept repentance from His votaries and receives their gifts of charity, and that Allah is verily He, the Oft-Returning, Most Merciful?

# 1340

And say: "Work (righteousness): Soon will Allah observe your work, and His Messenger, and the Believers: Soon will ye be brought back to the knower of what is hidden and what is open: then will He show you the truth of all that ye did."

# 1341

There are (yet) others, held in suspense for the command of Allah, whether He will punish them, or turn in mercy to them: and Allah is All-Knowing, Wise.

# 1342

And there are those who put up a mosque by way of mischief and infidelity - to disunite the Believers - and in preparation for one who warred against Allah and His Messenger aforetime. They will indeed swear that their intention is nothing but good; But Allah doth declare that they are certainly liars.

# 1343

Never stand thou forth therein. There is a mosque whose foundation was laid from the first day on piety; it is more worthy of the standing forth (for prayer) therein. In it are men who love to be purified; and Allah loveth those who make themselves pure.

# 1344

Which then is best? - he that layeth his foundation on piety to Allah and His good pleasure? - or he that layeth his foundation on an undermined sand-cliff ready to crumble to pieces? and it doth crumble to pieces with him, into the fire of Hell. And Allah guideth not people that do wrong.

# 1345

The foundation of those who so build is never free from suspicion and shakiness in their hearts, until their hearts are cut to pieces. And Allah is All-Knowing, Wise.

# 1346

Allah hath purchased of the believers their persons and their goods; for theirs (in return) is the garden (of Paradise): they fight in His cause, and slay and are slain: a promise binding on Him in truth, through the Law, the Gospel, and the Qur'an: and who is more faithful to his covenant than Allah? then rejoice in the bargain which ye have concluded: that is the achievement supreme.

# 1347

Those that turn (to Allah) in repentance; that serve Him, and praise Him; that wander in devotion to the cause of Allah,: that bow down and prostrate themselves in prayer; that enjoin good and forbid evil; and observe the limit set by Allah;- (These do rejoice). So proclaim the glad tidings to the Believers.

# 1348

It is not fitting, for the Prophet and those who believe, that they should pray for forgiveness for Pagans, even though they be of kin, after it is clear to them that they are companions of the Fire.

# 1349

And Abraham prayed for his father's forgiveness only because of a promise he had made to him. But when it became clear to him that he was an enemy to Allah, he dissociated himself from him: for Abraham was most tender-hearted, forbearing.

# 1350

And Allah will not mislead a people after He hath guided them, in order that He may make clear to them what to fear (and avoid)- for Allah hath knowledge of all things.

# 1351

Unto Allah belongeth the dominion of the heavens and the earth. He giveth life and He taketh it. Except for Him ye have no protector nor helper.

# 1352

Allah turned with favour to the Prophet, the Muhajirs, and the Ansar,- who followed him in a time of distress, after that the hearts of a part of them had nearly swerved (from duty); but He turned to them (also): for He is unto them Most Kind, Most Merciful.

# 1353

(He turned in mercy also) to the three who were left behind; (they felt guilty) to such a degree that the earth seemed constrained to them, for all its spaciousness, and their (very) souls seemed straitened to them,- and they perceived that there is no fleeing from Allah (and no refuge) but to Himself. Then He turned to them, that they might repent: for Allah is Oft-Returning, Most Merciful.

# 1354

O ye who believe! Fear Allah and be with those who are true (in word and deed).

# 1355

It was not fitting for the people of Medina and the Bedouin Arabs of the neighbourhood, to refuse to follow Allah's Messenger, nor to prefer their own lives to his: because nothing could they suffer or do, but was reckoned to their credit as a deed of righteousness,- whether they suffered thirst, or fatigue, or hunger, in the cause of Allah, or trod paths to raise the ire of the Unbelievers, or received any injury whatever from an enemy: for Allah suffereth not the reward to be lost of those who do good;-

# 1356

Nor could they spend anything (for the cause) - small or great- nor cut across a valley, but the deed is inscribed to their credit: that Allah may requite their deed with the best (possible reward).

# 1357

Nor should the Believers all go forth together: if a contingent from every expedition remained behind, they could devote themselves to studies in religion, and admonish the people when they return to them,- that thus they (may learn) to guard themselves (against evil).

# 1358

O ye who believe! fight the unbelievers who gird you about, and let them find firmness in you: and know that Allah is with those who fear Him.

# 1359

Whenever there cometh down a sura, some of them say: "Which of you has had His faith increased by it?" Yea, those who believe,- their faith is increased and they do rejoice.

# 1360

But those in whose hearts is a disease,- it will add doubt to their doubt, and they will die in a state of Unbelief.

# 1361

See they not that they are tried every year once or twice? Yet they turn not in repentance, and they take no heed.

# 1362

Whenever there cometh down a Sura, they look at each other, (saying), "Doth anyone see you?" Then they turn aside: Allah hath turned their hearts (from the light); for they are a people that understand not.

# 1363

Now hath come unto you a Messenger from amongst yourselves: it grieves him that ye should perish: ardently anxious is he over you: to the Believers is he most kind and merciful.

# 1364

But if they turn away, Say: "Allah sufficeth me: there is no god but He: On Him is my trust,- He the Lord of the Throne (of Glory) Supreme!"

# 1365

A. L. R. These are the ayats of the Book of Wisdom.

# 1366

Is it a matter of wonderment to men that We have sent Our inspiration to a man from among themselves?- that he should warn mankind (of their danger), and give the good news to the Believers that they have before their Lord the lofty rank of truth. (But) say the Unbelievers: "This is indeed an evident sorcerer!"

# 1367

Verily your Lord is Allah, who created the heavens and the earth in six days, and is firmly established on the throne (of authority), regulating and governing all things. No intercessor (can plead with Him) except after His leave (hath been obtained). This is Allah your Lord; Him therefore serve ye: will ye not receive admonition?

# 1368

To Him will be your return- of all of you. The promise of Allah is true and sure. It is He Who beginneth the process of creation, and repeateth it, that He may reward with justice those who believe and work righteousness; but those who reject Him will have draughts of boiling fluids, and a penalty grievous, because they did reject Him.

# 1369

It is He Who made the sun to be a shining glory and the moon to be a light (of beauty), and measured out stages for her; that ye might know the number of years and the count (of time). Nowise did Allah create this but in truth and righteousness. (Thus) doth He explain His Signs in detail, for those who understand.

# 1370

Verily, in the alternation of the night and the day, and in all that Allah hath created, in the heavens and the earth, are signs for those who fear Him.

# 1371

Those who rest not their hope on their meeting with Us, but are pleased and satisfied with the life of the present, and those who heed not Our Signs,-

# 1372

Their abode is the Fire, because of the (evil) they earned.

# 1373

Those who believe, and work righteousness,- their Lord will guide them because of their faith: beneath them will flow rivers in gardens of bliss.

# 1374

(This will be) their cry therein: "Glory to Thee, O Allah!" And "Peace" will be their greeting therein! and the close of their cry will be: "Praise be to Allah, the Cherisher and Sustainer of the worlds!"

# 1375

If Allah were to hasten for men the ill (they have earned) as they would fain hasten on the good,- then would their respite be settled at once. But We leave those who rest not their hope on their meeting with Us, in their trespasses, wandering in distraction to and fro.

# 1376

When trouble toucheth a man, He crieth unto Us (in all postures)- lying down on his side, or sitting, or standing. But when We have solved his trouble, he passeth on his way as if he had never cried to Us for a trouble that touched him! thus do the deeds of transgressors seem fair in their eyes!

# 1377

Generations before you We destroyed when they did wrong: their messengers came to them with clear-signs, but they would not believe! thus do We requite those who sin!

# 1378

Then We made you heirs in the land after them, to see how ye would behave!

# 1379

But when Our Clear Signs are rehearsed unto them, those who rest not their hope on their meeting with Us, Say: "Bring us a reading other than this, or change this," Say: "It is not for me, of my own accord, to change it: I follow naught but what is revealed unto me: if I were to disobey my Lord, I should myself fear the penalty of a Great Day (to come)."

# 1380

Say: "If Allah had so willed, I should not have rehearsed it to you, nor would He have made it known to you. A whole life-time before this have I tarried amongst you: will ye not then understand?"

# 1381

Who doth more wrong than such as forge a lie against Allah, or deny His Signs? But never will prosper those who sin.

# 1382

They serve, besides Allah, things that hurt them not nor profit them, and they say: "These are our intercessors with Allah." Say: "Do ye indeed inform Allah of something He knows not, in the heavens or on earth?- Glory to Him! and far is He above the partners they ascribe (to Him)!"

# 1383

Mankind was but one nation, but differed (later). Had it not been for a word that went forth before from thy Lord, their differences would have been settled between them.

# 1384

They say: "Why is not a sign sent down to him from his Lord?" Say: "The Unseen is only for Allah (to know), then wait ye: I too will wait with you."

# 1385

When We make mankind taste of some mercy after adversity hath touched them, behold! they take to plotting against Our Signs! Say: "Swifter to plan is Allah!" Verily, Our messengers record all the plots that ye make!

# 1386

He it is Who enableth you to traverse through land and sea; so that ye even board ships;- they sail with them with a favourable wind, and they rejoice thereat; then comes a stormy wind and the waves come to them from all sides, and they think they are being overwhelmed: they cry unto Allah, sincerely offering (their) duty unto Him saying, "If thou dost deliver us from this, we shall truly show our gratitude!"

# 1387

But when he delivereth them, behold! they transgress insolently through the earth in defiance of right! O mankind! your insolence is against your own souls,- an enjoyment of the life of the present: in the end, to Us is your return, and We shall show you the truth of all that ye did.

# 1388

The likeness of the life of the present is as the rain which We send down from the skies: by its mingling arises the produce of the earth- which provides food for men and animals: (It grows) till the earth is clad with its golden ornaments and is decked out (in beauty): the people to whom it belongs think they have all powers of disposal over it: There reaches it Our command by night or by day, and We make it like a harvest clean-mown, as if it had not flourished only the day before! thus do We explain the Signs in detail for those who reflect.

# 1389

But Allah doth call to the Home of Peace: He doth guide whom He pleaseth to a way that is straight.

# 1390

To those who do right is a goodly (reward)- Yea, more (than in measure)! No darkness nor shame shall cover their faces! they are companions of the garden; they will abide therein (for aye)!

# 1391

But those who have earned evil will have a reward of like evil: ignominy will cover their (faces): No defender will they have from (the wrath of) Allah: Their faces will be covered, as it were, with pieces from the depth of the darkness of night: they are companions of the Fire: they will abide therein (for aye)!

# 1392

One day shall We gather them all together. Then shall We say to those who joined gods (with Us): "To your place! ye and those ye joined as 'partners' We shall separate them, and their "Partners" shall say: "It was not us that ye worshipped!

# 1393

"Enough is Allah for a witness between us and you: we certainly knew nothing of your worship of us!"

# 1394

There will every soul prove (the fruits of) the deeds it sent before: they will be brought back to Allah their rightful Lord, and their invented falsehoods will leave them in the lurch.

# 1395

Say: "Who is it that sustains you (in life) from the sky and from the earth? or who is it that has power over hearing and sight? And who is it that brings out the living from the dead and the dead from the living? and who is it that rules and regulates all affairs?" They will soon say, "Allah". Say, "will ye not then show piety (to Him)?"

# 1396

Such is Allah, your real Cherisher and Sustainer: apart from truth, what (remains) but error? How then are ye turned away?

# 1397

Thus is the word of thy Lord proved true against those who rebel: Verily they will not believe.

# 1398

Say: "Of your 'partners', can any originate creation and repeat it?" Say: "It is Allah Who originates creation and repeats it: then how are ye deluded away (from the truth)?"

# 1399

Say: "Of your 'partners' is there any that can give any guidance towards truth?" Say: "It is Allah Who gives guidance towards truth, is then He Who gives guidance to truth more worthy to be followed, or he who finds not guidance (himself) unless he is guided? what then is the matter with you? How judge ye?"

# 1400

But most of them follow nothing but fancy: truly fancy can be of no avail against truth. Verily Allah is well aware of all that they do.

# 1401

This Qur'an is not such as can be produced by other than Allah; on the contrary it is a confirmation of (revelations) that went before it, and a fuller explanation of the Book - wherein there is no doubt - from the Lord of the worlds.

# 1402

Or do they say, "He forged it"? say: "Bring then a Sura like unto it, and call (to your aid) anyone you can besides Allah, if it be ye speak the truth!"

# 1403

Nay, they charge with falsehood that whose knowledge they cannot compass, even before the elucidation thereof hath reached them: thus did those before them make charges of falsehood: but see what was the end of those who did wrong!

# 1404

Of them there are some who believe therein, and some who do not: and thy Lord knoweth best those who are out for mischief.

# 1405

If they charge thee with falsehood, say: "My work to me, and yours to you! ye are free from responsibility for what I do, and I for what ye do!"

# 1406

Among them are some who (pretend to) listen to thee: But canst thou make the deaf to hear,- even though they are without understanding?

# 1407

And among them are some who look at thee: but canst thou guide the blind,- even though they will not see?

# 1408

Verily Allah will not deal unjustly with man in aught: It is man that wrongs his own soul.

# 1409

One day He will gather them together: (It will be) as if they had tarried but an hour of a day: they will recognise each other: assuredly those will be lost who denied the meeting with Allah and refused to receive true guidance.

# 1410

Whether We show thee (realised in thy life-time) some part of what We promise them,- or We take thy soul (to Our Mercy) (Before that),- in any case, to Us is their return: ultimately Allah is witness, to all that they do.

# 1411

To every people (was sent) a messenger: when their messenger comes (before them), the matter will be judged between them with justice, and they will not be wronged.

# 1412

They say: "When will this promise come to pass,- if ye speak the truth?"

# 1413

Say: "I have no power over any harm or profit to myself except as Allah willeth. To every people is a term appointed: when their term is reached, not an hour can they cause delay, nor (an hour) can they advance (it in anticipation)."

# 1414

Say: "Do ye see,- if His punishment should come to you by night or by day,- what portion of it would the sinners wish to hasten?

# 1415

"Would ye then believe in it at last, when it actually cometh to pass? (It will then be said): 'Ah! now? and ye wanted (aforetime) to hasten it on!'

# 1416

"At length will be said to the wrong-doers: 'Taste ye the enduring punishment! ye get but the recompense of what ye earned!'"

# 1417

They seek to be informed by thee: "Is that true?" Say: "Aye! by my Lord! it is the very truth! and ye cannot frustrate it!"

# 1418

Every soul that hath sinned, if it possessed all that is on earth, would fain give it in ransom: They would declare (their) repentance when they see the penalty: but the judgment between them will be with justice, and no wrong will be done unto them.

# 1419

Is it not (the case) that to Allah belongeth whatever is in the heavens and on earth? Is it not (the case) that Allah's promise is assuredly true? Yet most of them understand not.

# 1420

It is He Who giveth life and who taketh it, and to Him shall ye all be brought back.

# 1421

O mankind! there hath come to you a direction from your Lord and a healing for the (diseases) in your hearts,- and for those who believe, a guidance and a Mercy.

# 1422

Say: "In the bounty of Allah. And in His Mercy,- in that let them rejoice": that is better than the (wealth) they hoard.

# 1423

Say: "See ye what things Allah hath sent down to you for sustenance? Yet ye hold forbidden some things thereof and (some things) lawful." Say: "Hath Allah indeed permitted you, or do ye invent (things) to attribute to Allah?"

# 1424

And what think those who invent lies against Allah, of the Day of Judgment? Verily Allah is full of bounty to mankind, but most of them are ungrateful.

# 1425

In whatever business thou mayest be, and whatever portion thou mayest be reciting from the Qur'an,- and whatever deed ye (mankind) may be doing,- We are witnesses thereof when ye are deeply engrossed therein. Nor is hidden from thy Lord (so much as) the weight of an atom on the earth or in heaven. And not the least and not the greatest of these things but are recorded in a clear record.

# 1426

Behold! verily on the friends of Allah there is no fear, nor shall they grieve;

# 1427

Those who believe and (constantly) guard against evil;-

# 1428

For them are glad tidings, in the life of the present and in the Hereafter; no change can there be in the words of Allah. This is indeed the supreme felicity.

# 1429

Let not their speech grieve thee: for all power and honour belong to Allah: It is He Who heareth and knoweth (all things).

# 1430

Behold! verily to Allah belong all creatures, in the heavens and on earth. What do they follow who worship as His "partners" other than Allah? They follow nothing but fancy, and they do nothing but lie.

# 1431

He it is That hath made you the night that ye may rest therein, and the day to make things visible (to you). Verily in this are signs for those who listen (to His Message).

# 1432

They say: "Allah hath begotten a son!" - Glory be to Him! He is self-sufficient! His are all things in the heavens and on earth! No warrant have ye for this! say ye about Allah what ye know not?

# 1433

Say: "Those who invent a lie against Allah will never prosper."

# 1434

A little enjoyment in this world!- and then, to Us will be their return, then shall We make them taste the severest penalty for their blasphemies.

# 1435

Relate to them the story of Noah. Behold! he said to his people: "O my people, if it be hard on your (mind) that I should stay (with you) and commemorate the signs of Allah,- yet I put my trust in Allah. Get ye then an agreement about your plan and among your partners, so your plan be on to you dark and dubious. Then pass your sentence on me, and give me no respite.

# 1436

"But if ye turn back, (consider): no reward have I asked of you: my reward is only due from Allah, and I have been commanded to be of those who submit to Allah's will (in Islam)."

# 1437

They rejected Him, but We delivered him, and those with him, in the Ark, and We made them inherit (the earth), while We overwhelmed in the flood those who rejected Our Signs. Then see what was the end of those who were warned (but heeded not)!

# 1438

Then after him We sent (many) messengers to their peoples: they brought them Clear Signs, but they would not believe what they had already rejected beforehand. Thus do We seal the hearts of the transgressors.

# 1439

Then after them sent We Moses and Aaron to Pharaoh and his chiefs with Our Signs. But they were arrogant: they were a people in sin.

# 1440

When the Truth did come to them from Us, they said: "This is indeed evident sorcery!"

# 1441

Said Moses: "Say ye (this) about the truth when it hath (actually) reached you? Is sorcery (like) this? But sorcerers will not prosper."

# 1442

They said: "Hast thou come to us to turn us away from the ways we found our fathers following,- in order that thou and thy brother may have greatness in the land? But not we shall believe in you!"

# 1443

Said Pharaoh: "Bring me every sorcerer well versed."

# 1444

When the sorcerers came, Moses said to them: "Throw ye what ye (wish) to throw!"

# 1445

When they had had their throw, Moses said: "What ye have brought is sorcery: Allah will surely make it of no effect: for Allah prospereth not the work of those who make mischief.

# 1446

"And Allah by His words doth prove and establish His truth, however much the sinners may hate it!"

# 1447

But none believed in Moses except some children of his people, because of the fear of Pharaoh and his chiefs, lest they should persecute them; and certainly Pharaoh was mighty on the earth and one who transgressed all bounds.

# 1448

Moses said: "O my people! If ye do (really) believe in Allah, then in Him put your trust if ye submit (your will to His)."

# 1449

They said: "In Allah do we put out trust. Our Lord! make us not a trial for those who practise oppression;

# 1450

"And deliver us by Thy Mercy from those who reject (Thee)."

# 1451

We inspired Moses and his brother with this Message: "Provide dwellings for your people in Egypt, make your dwellings into places of worship, and establish regular prayers: and give glad tidings to those who believe!"

# 1452

Moses prayed: "Our Lord! Thou hast indeed bestowed on Pharaoh and his chiefs splendour and wealth in the life of the present, and so, Our Lord, they mislead (men) from Thy Path. Deface, our Lord, the features of their wealth, and send hardness to their hearts, so they will not believe until they see the grievous penalty."

# 1453

Allah said: "Accepted is your prayer (O Moses and Aaron)! So stand ye straight, and follow not the path of those who know not."

# 1454

We took the Children of Israel across the sea: Pharaoh and his hosts followed them in insolence and spite. At length, when overwhelmed with the flood, he said: "I believe that there is no god except Him Whom the Children of Israel believe in: I am of those who submit (to Allah in Islam)."

# 1455

(It was said to him): "Ah now!- But a little while before, wast thou in rebellion!- and thou didst mischief (and violence)!

# 1456

"This day shall We save thee in the body, that thou mayest be a sign to those who come after thee! but verily, many among mankind are heedless of Our Signs!"

# 1457

We settled the Children of Israel in a beautiful dwelling-place, and provided for them sustenance of the best: it was after knowledge had been granted to them, that they fell into schisms. Verily Allah will judge between them as to the schisms amongst them, on the Day of Judgment.

# 1458

If thou wert in doubt as to what We have revealed unto thee, then ask those who have been reading the Book from before thee: the Truth hath indeed come to thee from thy Lord: so be in no wise of those in doubt.

# 1459

Nor be of those who reject the signs of Allah, or thou shalt be of those who perish.

# 1460

Those against whom the word of thy Lord hath been verified would not believe-

# 1461

Even if every Sign was brought unto them,- until they see (for themselves) the penalty grievous.

# 1462

Why was there not a single township (among those We warned), which believed,- so its faith should have profited it,- except the people of Jonah? When they believed, We removed from them the penalty of ignominy in the life of the present, and permitted them to enjoy (their life) for a while.

# 1463

If it had been thy Lord's will, they would all have believed,- all who are on earth! wilt thou then compel mankind, against their will, to believe!

# 1464

No soul can believe, except by the will of Allah, and He will place doubt (or obscurity) on those who will not understand.

# 1465

Say: "Behold all that is in the heavens and on earth"; but neither Signs nor Warners profit those who believe not.

# 1466

Do they then expect (any thing) but (what happened in) the days of the men who passed away before them? Say: "Wait ye then: for I, too, will wait with you."

# 1467

In the end We deliver Our messengers and those who believe: Thus is it fitting on Our part that We should deliver those who believe!

# 1468

Say: "O ye men! If ye are in doubt as to my religion, (behold!) I worship not what ye worship, other than Allah! But I worship Allah - Who will take your souls (at death): I am commanded to be (in the ranks) of the Believers,

# 1469

"And further (thus): 'set thy face towards religion with true piety, and never in any wise be of the Unbelievers;

# 1470

"'Nor call on any, other than Allah;- Such will neither profit thee nor hurt thee: if thou dost, behold! thou shalt certainly be of those who do wrong.'"

# 1471

If Allah do touch thee with hurt, there is none can remove it but He: if He do design some benefit for thee, there is none can keep back His favour: He causeth it to reach whomsoever of His servants He pleaseth. And He is the Oft-Forgiving, Most Merciful.

# 1472

Say: "O ye men! Now Truth hath reached you from your Lord! those who receive guidance, do so for the good of their own souls; those who stray, do so to their own loss: and I am not (set) over you to arrange your affairs."

# 1473

Follow thou the inspiration sent unto thee, and be patient and constant, till Allah do decide: for He is the best to decide.

# 1474

A. L. R. (This is) a Book, with verses basic or fundamental (of established meaning), further explained in detail,- from One Who is Wise and Well-acquainted (with all things):

# 1475

(It teacheth) that ye should worship none but Allah. (Say): "Verily I am (sent) unto you from Him to warn and to bring glad tidings:

# 1476

"(And to preach thus), 'Seek ye the forgiveness of your Lord, and turn to Him in repentance; that He may grant you enjoyment, good (and true), for a term appointed, and bestow His abounding grace on all who abound in merit! But if ye turn away, then I fear for you the penalty of a great day:

# 1477

'To Allah is your return, and He hath power over all things.'"

# 1478

Behold! they fold up their hearts, that they may lie hid from Him! Ah even when they cover themselves with their garments, He knoweth what they conceal, and what they reveal: for He knoweth well the (inmost secrets) of the hearts.

# 1479

There is no moving creature on earth but its sustenance dependeth on Allah: He knoweth the time and place of its definite abode and its temporary deposit: All is in a clear Record.

# 1480

He it is Who created the heavens and the earth in six Days - and His Throne was over the waters - that He might try you, which of you is best in conduct. But if thou wert to say to them, "Ye shall indeed be raised up after death", the Unbelievers would be sure to say, "This is nothing but obvious sorcery!"

# 1481

If We delay the penalty for them for a definite term, they are sure to say, "What keeps it back?" Ah! On the day it (actually) reaches them, nothing will turn it away from them, and they will be completely encircled by that which they used to mock at!

# 1482

If We give man a taste of Mercy from Ourselves, and then withdraw it from him, behold! he is in despair and (falls into) blasphemy.

# 1483

But if We give him a taste of (Our) favours after adversity hath touched him, he is sure to say, "All evil has departed from me:" Behold! he falls into exultation and pride.

# 1484

Not so do those who show patience and constancy, and work righteousness; for them is forgiveness (of sins) and a great reward.

# 1485

Perchance thou mayest (feel the inclination) to give up a part of what is revealed unto thee, and thy heart feeleth straitened lest they say, "Why is not a treasure sent down unto him, or why does not an angel come down with him?" But thou art there only to warn! It is Allah that arrangeth all affairs!

# 1486

Or they may say, "He forged it," Say, "Bring ye then ten suras forged, like unto it, and call (to your aid) whomsoever ye can, other than Allah!- If ye speak the truth!

# 1487

"If then they (your false gods) answer not your (call), know ye that this revelation is sent down (replete) with the knowledge of Allah, and that there is no god but He! will ye even then submit (to Islam)?"

# 1488

Those who desire the life of the present and its glitter,- to them we shall pay (the price of) their deeds therein,- without diminution.

# 1489

They are those for whom there is nothing in the Hereafter but the Fire: vain are the designs they frame therein, and of no effect and the deeds that they do!

# 1490

Can they be (like) those who accept a Clear (Sign) from their Lord, and whom a witness from Himself doth teach, as did the Book of Moses before it,- a guide and a mercy? They believe therein; but those of the Sects that reject it,- the Fire will be their promised meeting-place. Be not then in doubt thereon: for it is the truth from thy Lord: yet many among men do not believe!

# 1491

Who doth more wrong than those who invent a life against Allah? They will be turned back to the presence of their Lord, and the witnesses will say, "These are the ones who lied against their Lord! Behold! the Curse of Allah is on those who do wrong!-

# 1492

"Those who would hinder (men) from the path of Allah and would seek in it something crooked: these were they who denied the Hereafter!"

# 1493

They will in no wise frustrate (His design) on earth, nor have they protectors besides Allah! Their penalty will be doubled! They lost the power to hear, and they did not see!

# 1494

They are the ones who have lost their own souls: and the (fancies) they invented have left them in the lurch!

# 1495

Without a doubt, these are the very ones who will lose most in the Hereafter!

# 1496

But those who believe and work righteousness, and humble themselves before their Lord,- They will be companions of the gardens, to dwell therein for aye!

# 1497

These two kinds (of men) may be compared to the blind and deaf, and those who can see and hear well. Are they equal when compared? Will ye not then take heed?

# 1498

We sent Noah to his people (with a mission): "I have come to you with a Clear Warning:

# 1499

"That ye serve none but Allah: Verily I do fear for you the penalty of a grievous day."

# 1500

But the chiefs of the Unbelievers among his people said: "We see (in) thee nothing but a man like ourselves: Nor do we see that any follow thee but the meanest among us, in judgment immature: Nor do we see in you (all) any merit above us: in fact we think ye are liars!"

# 1501

He said: "O my people! See ye if (it be that) I have a Clear Sign from my Lord, and that He hath sent Mercy unto me from His own presence, but that the Mercy hath been obscured from your sight? shall we compel you to accept it when ye are averse to it?

# 1502

"And O my people! I ask you for no wealth in return: my reward is from none but Allah: But I will not drive away (in contempt) those who believe: for verily they are to meet their Lord, and ye I see are the ignorant ones!

# 1503

"And O my people! who would help me against Allah if I drove them away? Will ye not then take heed?

# 1504

"I tell you not that with me are the treasures of Allah, nor do I know what is hidden, nor claim I to be an angel. Nor yet do I say, of those whom your eyes do despise that Allah will not grant them (all) that is good: Allah knoweth best what is in their souls: I should, if I did, indeed be a wrong-doer."

# 1505

They said: "O Noah! thou hast disputed with us, and (much) hast thou prolonged the dispute with us: now bring upon us what thou threatenest us with, if thou speakest the truth!?"

# 1506

He said: "Truly, Allah will bring it on you if He wills,- and then, ye will not be able to frustrate it!

# 1507

"Of no profit will be my counsel to you, much as I desire to give you (good) counsel, if it be that Allah willeth to leave you astray: He is your Lord! and to Him will ye return!"

# 1508

Or do they say, "He has forged it"? Say: "If I had forged it, on me were my sin! and I am free of the sins of which ye are guilty!

# 1509

It was revealed to Noah: "None of thy people will believe except those who have believed already! So grieve no longer over their (evil) deeds.

# 1510

"But construct an Ark under Our eyes and Our inspiration, and address Me no (further) on behalf of those who are in sin: for they are about to be overwhelmed (in the Flood)."

# 1511

Forthwith he (starts) constructing the Ark: Every time that the chiefs of his people passed by him, they threw ridicule on him. He said: "If ye ridicule us now, we (in our turn) can look down on you with ridicule likewise!

# 1512

"But soon will ye know who it is on whom will descend a penalty that will cover them with shame,- on whom will be unloosed a penalty lasting:"

# 1513

At length, behold! there came Our command, and the fountains of the earth gushed forth! We said: "Embark therein, of each kind two, male and female, and your family - except those against whom the word has already gone forth,- and the Believers." but only a few believed with him.

# 1514

So he said: "Embark ye on the Ark, In the name of Allah, whether it move or be at rest! For my Lord is, be sure, Oft-Forgiving, Most Merciful!"

# 1515

So the Ark floated with them on the waves (towering) like mountains, and Noah called out to his son, who had separated himself (from the rest): "O my son! embark with us, and be not with the unbelievers!"

# 1516

The son replied: "I will betake myself to some mountain: it will save me from the water." Noah said: "This day nothing can save, from the command of Allah, any but those on whom He hath mercy! "And the waves came between them, and the son was among those overwhelmed in the Flood.

# 1517

Then the word went forth: "O earth! swallow up thy water, and O sky! Withhold (thy rain)!" and the water abated, and the matter was ended. The Ark rested on Mount Judi, and the word went forth: "Away with those who do wrong!"

# 1518

And Noah called upon his Lord, and said: "O my Lord! surely my son is of my family! and Thy promise is true, and Thou art the justest of Judges!"

# 1519

He said: "O Noah! He is not of thy family: For his conduct is unrighteous. So ask not of Me that of which thou hast no knowledge! I give thee counsel, lest thou act like the ignorant!"

# 1520

Noah said: "O my Lord! I do seek refuge with Thee, lest I ask Thee for that of which I have no knowledge. And unless thou forgive me and have Mercy on me, I should indeed be lost!"

# 1521

The word came: "O Noah! Come down (from the Ark) with peace from Us, and blessing on thee and on some of the peoples (who will spring) from those with thee: but (there will be other) peoples to whom We shall grant their pleasures (for a time), but in the end will a grievous penalty reach them from Us."

# 1522

Such are some of the stories of the unseen, which We have revealed unto thee: before this, neither thou nor thy people knew them. So persevere patiently: for the End is for those who are righteous.

# 1523

To the 'Ad People (We sent) Hud, one of their own brethren. He said: "O my people! worship Allah! ye have no other god but Him. (Your other gods) ye do nothing but invent!

# 1524

"O my people! I ask of you no reward for this (Message). My reward is from none but Him who created me: Will ye not then understand?

# 1525

"And O my people! Ask forgiveness of your Lord, and turn to Him (in repentance): He will send you the skies pouring abundant rain, and add strength to your strength: so turn ye not back in sin!"

# 1526

They said: "O Hud! No Clear (Sign) that hast thou brought us, and we are not the ones to desert our gods on thy word! Nor shall we believe in thee!

# 1527

"We say nothing but that (perhaps) some of our gods may have seized thee with imbecility." He said: "I call Allah to witness, and do ye bear witness, that I am free from the sin of ascribing, to Him,

# 1528

"Other gods as partners! so scheme (your worst) against me, all of you, and give me no respite.

# 1529

"I put my trust in Allah, My Lord and your Lord! There is not a moving creature, but He hath grasp of its fore-lock. Verily, it is my Lord that is on a straight Path.

# 1530

"If ye turn away,- I (at least) have conveyed the Message with which I was sent to you. My Lord will make another people to succeed you, and you will not harm Him in the least. For my Lord hath care and watch over all things."

# 1531

So when Our decree issued, We saved Hud and those who believed with him, by (special) Grace from Ourselves: We saved them from a severe penalty.

# 1532

Such were the 'Ad People: they rejected the Signs of their Lord and Cherisher; disobeyed His messengers; And followed the command of every powerful, obstinate transgressor.

# 1533

And they were pursued by a Curse in this life,- and on the Day of Judgment. Ah! Behold! for the 'Ad rejected their Lord and Cherisher! Ah! Behold! removed (from sight) were 'Ad the people of Hud!

# 1534

To the Thamud People (We sent) Salih, one of their own brethren. He said: "O my people! Worship Allah: ye have no other god but Him. It is He Who hath produced you from the earth and settled you therein: then ask forgiveness of Him, and turn to Him (in repentance): for my Lord is (always) near, ready to answer."

# 1535

They said: "O Salih! thou hast been of us! a centre of our hopes hitherto! dost thou (now) forbid us the worship of what our fathers worshipped? But we are really in suspicious (disquieting) doubt as to that to which thou invitest us."

# 1536

He said: "O my people! do ye see? if I have a Clear (Sign) from my Lord and He hath sent Mercy unto me from Himself,- who then can help me against Allah if I were to disobey Him? What then would ye add to my (portion) but perdition?

# 1537

"And O my people! This she-camel of Allah is a symbol to you: leave her to feed on Allah's (free) earth, and inflict no harm on her, or a swift penalty will seize you!"

# 1538

But they did ham-string her. So he said: "Enjoy yourselves in your homes for three days: (Then will be your ruin): (Behold) there a promise not to be belied!"

# 1539

When Our Decree issued, We saved Salih and those who believed with him, by (special) Grace from Ourselves - and from the Ignominy of that day. For thy Lord - He is the Strong One, and able to enforce His Will.

# 1540

The (mighty) Blast overtook the wrong-doers, and they lay prostrate in their homes before the morning,-

# 1541

As if they had never dwelt and flourished there. Ah! Behold! for the Thamud rejected their Lord and Cherisher! Ah! Behold! removed (from sight) were the Thamud!

# 1542

There came Our messengers to Abraham with glad tidings. They said, "Peace!" He answered, "Peace!" and hastened to entertain them with a roasted calf.

# 1543

But when he saw their hands went not towards the (meal), he felt some mistrust of them, and conceived a fear of them. They said: "Fear not: We have been sent against the people of Lut."

# 1544

And his wife was standing (there), and she laughed: But we gave her glad tidings of Isaac, and after him, of Jacob.

# 1545

She said: "Alas for me! shall I bear a child, seeing I am an old woman, and my husband here is an old man? That would indeed be a wonderful thing!"

# 1546

They said: "Dost thou wonder at Allah's decree? The grace of Allah and His blessings on you, o ye people of the house! for He is indeed worthy of all praise, full of all glory!"

# 1547

When fear had passed from (the mind of) Abraham and the glad tidings had reached him, he began to plead with us for Lut's people.

# 1548

For Abraham was, without doubt, forbearing (of faults), compassionate, and given to look to Allah.

# 1549

O Abraham! Seek not this. The decree of thy Lord hath gone forth: for them there cometh a penalty that cannot be turned back!

# 1550

When Our messengers came to Lut, he was grieved on their account and felt himself powerless (to protect) them. He said: "This is a distressful day."

# 1551

And his people came rushing towards him, and they had been long in the habit of practising abominations. He said: "O my people! Here are my daughters: they are purer for you (if ye marry)! Now fear Allah, and cover me not with shame about my guests! Is there not among you a single right-minded man?"

# 1552

They said: "Well dost thou know we have no need of thy daughters: indeed thou knowest quite well what we want!"

# 1553

He said: "Would that I had power to suppress you or that I could betake myself to some powerful support."

# 1554

(The Messengers) said: "O Lut! We are Messengers from thy Lord! By no means shall they reach thee! now travel with thy family while yet a part of the night remains, and let not any of you look back: but thy wife (will remain behind): To her will happen what happens to the people. Morning is their time appointed: Is not the morning nigh?"

# 1555

When Our Decree issued, We turned (the cities) upside down, and rained down on them brimstones hard as baked clay, spread, layer on layer,-

# 1556

Marked as from thy Lord: Nor are they ever far from those who do wrong!

# 1557

To the Madyan People (We sent) Shu'aib, one of their own brethren: he said: "O my people! worship Allah: Ye have no other god but Him. And give not short measure or weight: I see you in prosperity, but I fear for you the penalty of a day that will compass (you) all round.

# 1558

"And O my people! give just measure and weight, nor withhold from the people the things that are their due: commit not evil in the land with intent to do mischief.

# 1559

"That which is left you by Allah is best for you, if ye (but) believed! but I am not set over you to keep watch!"

# 1560

They said: "O Shu'aib! Does thy (religion of) prayer command thee that we leave off the worship which our fathers practised, or that we leave off doing what we like with our property? truly, thou art the one that forbeareth with faults and is right-minded!"

# 1561

He said: "O my people! see ye whether I have a Clear (Sign) from my Lord, and He hath given me sustenance (pure and) good as from Himself? I wish not, in opposition to you, to do that which I forbid you to do. I only desire (your) betterment to the best of my power; and my success (in my task) can only come from Allah. In Him I trust, and unto Him I look.

# 1562

"And O my people! let not my dissent (from you) cause you to sin, lest ye suffer a fate similar to that of the people of Noah or of Hud or of Salih, nor are the people of Lut far off from you!

# 1563

"But ask forgiveness of your Lord, and turn unto Him (in repentance): For my Lord is indeed full of mercy and loving-kindness."

# 1564

They said: "O Shu'aib! much of what thou sayest we do not understand! In fact among us we see that thou hast no strength! Were it not for thy family, we should certainly have stoned thee! for thou hast among us no great position!"

# 1565

He said: "O my people! is then my family of more consideration with you than Allah? For ye cast Him away behind your backs (with contempt). But verily my Lord encompasseth on all sides all that ye do!

# 1566

"And O my people! Do whatever ye can: I will do (my part): Soon will ye know who it is on whom descends the penalty of ignominy; and who is a liar! and watch ye! for I too am watching with you!"

# 1567

When Our decree issued, We saved Shu'aib and those who believed with him, by (special) mercy from Ourselves: But the (mighty) blast did seize the wrong-doers, and they lay prostrate in their homes by the morning,-

# 1568

As if they had never dwelt and flourished there! Ah! Behold! How the Madyan were removed (from sight) as were removed the Thamud!

# 1569

And we sent Moses, with Our Clear (Signs) and an authority manifest,

# 1570

Unto Pharaoh and his chiefs: but they followed the command of Pharaoh and the command of Pharaoh was no right (guide).

# 1571

He will go before his people on the Day of Judgment, and lead them into the Fire (as cattle are led to water): But woeful indeed will be the place to which they are led!

# 1572

And they are followed by a curse in this (life) and on the Day of Judgment: and woeful is the gift which shall be given (unto them)!

# 1573

These are some of the stories of communities which We relate unto thee: of them some are standing, and some have been mown down (by the sickle of time).

# 1574

It was not We that wronged them: They wronged their own souls: the deities, other than Allah, whom they invoked, profited them no whit when there issued the decree of thy Lord: Nor did they add aught (to their lot) but perdition!

# 1575

Such is the chastisement of thy Lord when He chastises communities in the midst of their wrong: grievous, indeed, and severe is His chastisement.

# 1576

In that is a Sign for those who fear the penalty of the Hereafter: that is a Day for which mankind will be gathered together: that will be a Day of Testimony.

# 1577

Nor shall We delay it but for a term appointed.

# 1578

The day it arrives, no soul shall speak except by His leave: of those (gathered) some will be wretched and some will be blessed.

# 1579

Those who are wretched shall be in the Fire: There will be for them therein (nothing but) the heaving of sighs and sobs:

# 1580

They will dwell therein for all the time that the heavens and the earth endure, except as thy Lord willeth: for thy Lord is the (sure) accomplisher of what He planneth.

# 1581

And those who are blessed shall be in the Garden: They will dwell therein for all the time that the heavens and the earth endure, except as thy Lord willeth: a gift without break.

# 1582

Be not then in doubt as to what these men worship. They worship nothing but what their fathers worshipped before (them): but verily We shall pay them back (in full) their portion without (the least) abatement.

# 1583

We certainly gave the Book to Moses, but differences arose therein: had it not been that a word had gone forth before from thy Lord, the matter would have been decided between them, but they are in suspicious doubt concerning it.

# 1584

And, of a surety, to all will your Lord pay back (in full the recompense) of their deeds: for He knoweth well all that they do.

# 1585

Therefore stand firm (in the straight Path) as thou art commanded,- thou and those who with thee turn (unto Allah); and transgress not (from the Path): for He seeth well all that ye do.

# 1586

And incline not to those who do wrong, or the Fire will seize you; and ye have no protectors other than Allah, nor shall ye be helped.

# 1587

And establish regular prayers at the two ends of the day and at the approaches of the night: For those things, that are good remove those that are evil: Be that the word of remembrance to those who remember (their Lord):

# 1588

And be steadfast in patience; for verily Allah will not suffer the reward of the righteous to perish.

# 1589

Why were there not, among the generations before you, persons possessed of balanced good sense, prohibiting (men) from mischief in the earth - except a few among them whom We saved (from harm)? But the wrong-doers pursued the enjoyment of the good things of life which were given them, and persisted in sin.

# 1590

Nor would thy Lord be the One to destroy communities for a single wrong-doing, if its members were likely to mend.

# 1591

If thy Lord had so willed, He could have made mankind one people: but they will not cease to dispute.

# 1592

Except those on whom thy Lord hath bestowed His Mercy: and for this did He create them: and the Word of thy Lord shall be fulfilled: "I will fill Hell with jinns and men all together."

# 1593

All that we relate to thee of the stories of the messengers,- with it We make firm thy heart: in them there cometh to thee the Truth, as well as an exhortation and a message of remembrance to those who believe.

# 1594

Say to those who do not believe: "Do what ever ye can: We shall do our part;

# 1595

"And wait ye! We too shall wait."

# 1596

To Allah do belong the unseen (secrets) of the heavens and the earth, and to Him goeth back every affair (for decision): then worship Him, and put thy trust in Him: and thy Lord is not unmindful of aught that ye do.

# 1597

A. L. R. These are the symbols (or Verses) of the perspicuous Book.

# 1598

We have sent it down as an Arabic Qur'an, in order that ye may learn wisdom.

# 1599

We do relate unto thee the most beautiful of stories, in that We reveal to thee this (portion of the) Qur'an: before this, thou too was among those who knew it not.

# 1600

Behold! Joseph said to his father: "O my father! I did see eleven stars and the sun and the moon: I saw them prostrate themselves to me!"

# 1601

Said (the father): "My (dear) little son! relate not thy vision to thy brothers, lest they concoct a plot against thee: for Satan is to man an avowed enemy!

# 1602

"Thus will thy Lord choose thee and teach thee the interpretation of stories (and events) and perfect His favour to thee and to the posterity of Jacob - even as He perfected it to thy fathers Abraham and Isaac aforetime! for Allah is full of knowledge and wisdom."

# 1603

Verily in Joseph and his brethren are signs (or symbols) for seekers (after Truth).

# 1604

They said: "Truly Joseph and his brother are loved more by our father than we: But we are a goodly body! really our father is obviously wandering (in his mind)!

# 1605

"Slay ye Joseph or cast him out to some (unknown) land, that so the favour of your father may be given to you alone: (there will be time enough) for you to be righteous after that!"

# 1606

Said one of them: "Slay not Joseph, but if ye must do something, throw him down to the bottom of the well: he will be picked up by some caravan of travellers."

# 1607

They said: "O our father! why dost thou not trust us with Joseph,- seeing we are indeed his sincere well-wishers?

# 1608

"Send him with us tomorrow to enjoy himself and play, and we shall take every care of him."

# 1609

(Jacob) said: "Really it saddens me that ye should take him away: I fear lest the wolf should devour him while ye attend not to him."

# 1610

They said: "If the wolf were to devour him while we are (so large) a party, then should we indeed (first) have perished ourselves!"

# 1611

So they did take him away, and they all agreed to throw him down to the bottom of the well: and We put into his heart (this Message): 'Of a surety thou shalt (one day) tell them the truth of this their affair while they know (thee) not'

# 1612

Then they came to their father in the early part of the night, weeping.

# 1613

They said: "O our father! We went racing with one another, and left Joseph with our things; and the wolf devoured him.... But thou wilt never believe us even though we tell the truth."

# 1614

They stained his shirt with false blood. He said: "Nay, but your minds have made up a tale (that may pass) with you, (for me) patience is most fitting: Against that which ye assert, it is Allah (alone) Whose help can be sought"..

# 1615

Then there came a caravan of travellers: they sent their water-carrier (for water), and he let down his bucket (into the well)... He said: "Ah there! Good news! Here is a (fine) young man!" So they concealed him as a treasure! But Allah knoweth well all that they do!

# 1616

The (Brethren) sold him for a miserable price, for a few dirhams counted out: in such low estimation did they hold him!

# 1617

The man in Egypt who bought him, said to his wife: "Make his stay (among us) honourable: may be he will bring us much good, or we shall adopt him as a son." Thus did We establish Joseph in the land, that We might teach him the interpretation of stories (and events). And Allah hath full power and control over His affairs; but most among mankind know it not.

# 1618

When Joseph attained His full manhood, We gave him power and knowledge: thus do We reward those who do right.

# 1619

But she in whose house he was, sought to seduce him from his (true) self: she fastened the doors, and said: "Now come, thou (dear one)!" He said: "Allah forbid! truly (thy husband) is my lord! he made my sojourn agreeable! truly to no good come those who do wrong!"

# 1620

And (with passion) did she desire him, and he would have desired her, but that he saw the evidence of his Lord: thus (did We order) that We might turn away from him (all) evil and shameful deeds: for he was one of Our servants, sincere and purified.

# 1621

So they both raced each other to the door, and she tore his shirt from the back: they both found her lord near the door. She said: "What is the (fitting) punishment for one who formed an evil design against thy wife, but prison or a grievous chastisement?"

# 1622

He said: "It was she that sought to seduce me - from my (true) self." And one of her household saw (this) and bore witness, (thus):- "If it be that his shirt is rent from the front, then is her tale true, and he is a liar!

# 1623

"But if it be that his shirt is torn from the back, then is she the liar, and he is telling the truth!"

# 1624

So when he saw his shirt,- that it was torn at the back,- (her husband) said: "Behold! It is a snare of you women! truly, mighty is your snare!

# 1625

"O Joseph, pass this over! (O wife), ask forgiveness for thy sin, for truly thou hast been at fault!"

# 1626

Ladies said in the City: "The wife of the (great) 'Aziz is seeking to seduce her slave from his (true) self: Truly hath he inspired her with violent love: we see she is evidently going astray."

# 1627

When she heard of their malicious talk, she sent for them and prepared a banquet for them: she gave each of them a knife: and she said (to Joseph), "Come out before them." When they saw him, they did extol him, and (in their amazement) cut their hands: they said, "Allah preserve us! no mortal is this! this is none other than a noble angel!"

# 1628

She said: "There before you is the man about whom ye did blame me! I did seek to seduce him from his (true) self but he did firmly save himself guiltless!.... and now, if he doth not my bidding, he shall certainly be cast into prison, and (what is more) be of the company of the vilest!"

# 1629

He said: "O my Lord! the prison is more to my liking than that to which they invite me: Unless Thou turn away their snare from me, I should (in my youthful folly) feel inclined towards them and join the ranks of the ignorant."

# 1630

So his Lord hearkened to him (in his prayer), and turned away from him their snare: Verily He heareth and knoweth (all things).

# 1631

Then it occurred to the men, after they had seen the signs, (that it was best) to imprison him for a time.

# 1632

Now with him there came into the prison two young men. Said one of them: "I see myself (in a dream) pressing wine." said the other: "I see myself (in a dream) carrying bread on my head, and birds are eating, thereof." "Tell us" (they said) "The truth and meaning thereof: for we see thou art one that doth good (to all)."

# 1633

He said: "Before any food comes (in due course) to feed either of you, I will surely reveal to you the truth and meaning of this ere it befall you: that is part of the (duty) which my Lord hath taught me. I have (I assure you) abandoned the ways of a people that believe not in Allah and that (even) deny the Hereafter.

# 1634

"And I follow the ways of my fathers,- Abraham, Isaac, and Jacob; and never could we attribute any partners whatever to Allah: that (comes) of the grace of Allah to us and to mankind: yet most men are not grateful.

# 1635

"O my two companions of the prison! (I ask you): are many lords differing among themselves better, or the One Allah, Supreme and Irresistible?

# 1636

"If not Him, ye worship nothing but names which ye have named,- ye and your fathers,- for which Allah hath sent down no authority: the command is for none but Allah: He hath commanded that ye worship none but Him: that is the right religion, but most men understand not...

# 1637

"O my two companions of the prison! As to one of you, he will pour out the wine for his lord to drink: as for the other, he will hang from the cross, and the birds will eat from off his head. (so) hath been decreed that matter whereof ye twain do enquire"...

# 1638

And of the two, to that one whom he consider about to be saved, he said: "Mention me to thy lord." But Satan made him forget to mention him to his lord: and (Joseph) lingered in prison a few (more) years.

# 1639

The king (of Egypt) said: "I do see (in a vision) seven fat kine, whom seven lean ones devour, and seven green ears of corn, and seven (others) withered. O ye chiefs! Expound to me my vision if it be that ye can interpret visions."

# 1640

They said: "A confused medley of dreams: and we are not skilled in the interpretation of dreams."

# 1641

But the man who had been released, one of the two (who had been in prison) and who now bethought him after (so long) a space of time, said: "I will tell you the truth of its interpretation: send ye me (therefore)."

# 1642

"O Joseph!" (he said) "O man of truth! Expound to us (the dream) of seven fat kine whom seven lean ones devour, and of seven green ears of corn and (seven) others withered: that I may return to the people, and that they may understand."

# 1643

(Joseph) said: "For seven years shall ye diligently sow as is your wont: and the harvests that ye reap, ye shall leave them in the ear,- except a little, of which ye shall eat.

# 1644

"Then will come after that (period) seven dreadful (years), which will devour what ye shall have laid by in advance for them,- (all) except a little which ye shall have (specially) guarded.

# 1645

"Then will come after that (period) a year in which the people will have abundant water, and in which they will press (wine and oil)."

# 1646

So the king said: "Bring ye him unto me." But when the messenger came to him, (Joseph) said: "Go thou back to thy lord, and ask him, 'What is the state of mind of the ladies who cut their hands'? For my Lord is certainly well aware of their snare."

# 1647

(The king) said (to the ladies): "What was your affair when ye did seek to seduce Joseph from his (true) self?" The ladies said: "Allah preserve us! no evil know we against him!" Said the 'Aziz's wife: "Now is the truth manifest (to all): it was I who sought to seduce him from his (true) self: He is indeed of those who are (ever) true (and virtuous).

# 1648

"This (say I), in order that He may know that I have never been false to him in his absence, and that Allah will never guide the snare of the false ones.

# 1649

"Nor do I absolve my own self (of blame): the (human) soul is certainly prone to evil, unless my Lord do bestow His Mercy: but surely my Lord is Oft-forgiving, Most Merciful."

# 1650

So the king said: "Bring him unto me; I will take him specially to serve about my own person." Therefore when he had spoken to him, he said: "Be assured this day, thou art, before our own presence, with rank firmly established, and fidelity fully proved!

# 1651

(Joseph) said: "Set me over the store-houses of the land: I will indeed guard them, as one that knows (their importance)."

# 1652

Thus did We give established power to Joseph in the land, to take possession therein as, when, or where he pleased. We bestow of our Mercy on whom We please, and We suffer not, to be lost, the reward of those who do good.

# 1653

But verily the reward of the Hereafter is the best, for those who believe, and are constant in righteousness.

# 1654

Then came Joseph's brethren: they entered his presence, and he knew them, but they knew him not.

# 1655

And when he had furnished them forth with provisions (suitable) for them, he said: "Bring unto me a brother ye have, of the same father as yourselves, (but a different mother): see ye not that I pay out full measure, and that I do provide the best hospitality?

# 1656

"Now if ye bring him not to me, ye shall have no measure (of corn) from me, nor shall ye (even) come near me."

# 1657

They said: "We shall certainly seek to get our wish about him from his father: Indeed we shall do it."

# 1658

And (Joseph) told his servants to put their stock-in-trade (with which they had bartered) into their saddle-bags, so they should know it only when they returned to their people, in order that they might come back.

# 1659

Now when they returned to their father, they said: "O our father! No more measure of grain shall we get (unless we take our brother): So send our brother with us, that we may get our measure; and we will indeed take every care of him."

# 1660

He said: "Shall I trust you with him with any result other than when I trusted you with his brother aforetime? But Allah is the best to take care (of him), and He is the Most Merciful of those who show mercy!"

# 1661

Then when they opened their baggage, they found their stock-in-trade had been returned to them. They said: "O our father! What (more) can we desire? this our stock-in-trade has been returned to us: so we shall get (more) food for our family; We shall take care of our brother; and add (at the same time) a full camel's load (of grain to our provisions). This is but a small quantity.

# 1662

(Jacob) said: "Never will I send him with you until ye swear a solemn oath to me, in Allah's name, that ye will be sure to bring him back to me unless ye are yourselves hemmed in (and made powerless). And when they had sworn their solemn oath, he said: "Over all that we say, be Allah the witness and guardian!"

# 1663

Further he said: "O my sons! enter not all by one gate: enter ye by different gates. Not that I can profit you aught against Allah (with my advice): None can command except Allah: On Him do I put my trust: and let all that trust put their trust on Him."

# 1664

And when they entered in the manner their father had enjoined, it did not profit them in the least against (the plan of) Allah: It was but a necessity of Jacob's soul, which he discharged. For he was, by our instruction, full of knowledge (and experience): but most men know not.

# 1665

Now when they came into Joseph's presence, he received his (full) brother to stay with him. He said (to him): "Behold! I am thy (own) brother; so grieve not at aught of their doings."

# 1666

At length when he had furnished them forth with provisions (suitable) for them, he put the drinking cup into his brother's saddle-bag. Then shouted out a crier: "O ye (in) the caravan! behold! ye are thieves, without doubt!"

# 1667

They said, turning towards them: "What is it that ye miss?"

# 1668

They said: "We miss the great beaker of the king; for him who produces it, is (the reward of) a camel load; I will be bound by it."

# 1669

(The brothers) said: "By Allah! well ye know that we came not to make mischief in the land, and we are no thieves!"

# 1670

(The Egyptians) said: "What then shall be the penalty of this, if ye are (proved) to have lied?"

# 1671

They said: "The penalty should be that he in whose saddle-bag it is found, should be held (as bondman) to atone for the (crime). Thus it is we punish the wrong-doers!"

# 1672

So he began (the search) with their baggage, before (he came to) the baggage of his brother: at length he brought it out of his brother's baggage. Thus did We plan for Joseph. He could not take his brother by the law of the king except that Allah willed it (so). We raise to degrees (of wisdom) whom We please: but over all endued with knowledge is one, the All-Knowing.

# 1673

They said: "If he steals, there was a brother of his who did steal before (him)." But these things did Joseph keep locked in his heart, revealing not the secrets to them. He (simply) said (to himself): "Ye are the worse situated; and Allah knoweth best the truth of what ye assert!"

# 1674

They said: "O exalted one! Behold! he has a father, aged and venerable, (who will grieve for him); so take one of us in his place; for we see that thou art (gracious) in doing good."

# 1675

He said: "Allah forbid that we take other than him with whom we found our property: indeed (if we did so), we should be acting wrongfully.

# 1676

Now when they saw no hope of his (yielding), they held a conference in private. The leader among them said: "Know ye not that your father did take an oath from you in Allah's name, and how, before this, ye did fail in your duty with Joseph? Therefore will I not leave this land until my father permits me, or Allah commands me; and He is the best to command.

# 1677

"Turn ye back to your father, and say, 'O our father! behold! thy son committed theft! we bear witness only to what we know, and we could not well guard against the unseen!

# 1678

"'Ask at the town where we have been and the caravan in which we returned, and (you will find) we are indeed telling the truth.'"

# 1679

Jacob said: "Nay, but ye have yourselves contrived a story (good enough) for you. So patience is most fitting (for me). Maybe Allah will bring them (back) all to me (in the end). For He is indeed full of knowledge and wisdom."

# 1680

And he turned away from them, and said: "How great is my grief for Joseph!" And his eyes became white with sorrow, and he fell into silent melancholy.

# 1681

They said: "By Allah! (never) wilt thou cease to remember Joseph until thou reach the last extremity of illness, or until thou die!"

# 1682

He said: "I only complain of my distraction and anguish to Allah, and I know from Allah that which ye know not...

# 1683

"O my sons! go ye and enquire about Joseph and his brother, and never give up hope of Allah's Soothing Mercy: truly no one despairs of Allah's Soothing Mercy, except those who have no faith."

# 1684

Then, when they came (back) into (Joseph's) presence they said: "O exalted one! distress has seized us and our family: we have (now) brought but scanty capital: so pay us full measure, (we pray thee), and treat it as charity to us: for Allah doth reward the charitable."

# 1685

He said: "Know ye how ye dealt with Joseph and his brother, not knowing (what ye were doing)?"

# 1686

They said: "Art thou indeed Joseph?" He said, "I am Joseph, and this is my brother: Allah has indeed been gracious to us (all): behold, he that is righteous and patient,- never will Allah suffer the reward to be lost, of those who do right."

# 1687

They said: "By Allah! indeed has Allah preferred thee above us, and we certainly have been guilty of sin!"

# 1688

He said: "This day let no reproach be (cast) on you: Allah will forgive you, and He is the Most Merciful of those who show mercy!

# 1689

"Go with this my shirt, and cast it over the face of my father: he will come to see (clearly). Then come ye (here) to me together with all your family."

# 1690

When the caravan left (Egypt), their father said: "I do indeed scent the presence of Joseph: Nay, think me not a dotard."

# 1691

They said: "By Allah! truly thou art in thine old wandering mind."

# 1692

Then when the bearer of the good news came, He cast (the shirt) over his face, and he forthwith regained clear sight. He said: "Did I not say to you, 'I know from Allah that which ye know not?'"

# 1693

They said: "O our father! ask for us forgiveness for our sins, for we were truly at fault."

# 1694

He said: "Soon will I ask my Lord for forgiveness for you: for he is indeed Oft-Forgiving, Most Merciful."

# 1695

Then when they entered the presence of Joseph, he provided a home for his parents with himself, and said: "Enter ye Egypt (all) in safety if it please Allah."

# 1696

And he raised his parents high on the throne (of dignity), and they fell down in prostration, (all) before him. He said: "O my father! this is the fulfilment of my vision of old! Allah hath made it come true! He was indeed good to me when He took me out of prison and brought you (all here) out of the desert, (even) after Satan had sown enmity between me and my brothers. Verily my Lord understandeth best the mysteries of all that He planneth to do, for verily He is full of knowledge and wisdom.

# 1697

"O my Lord! Thou hast indeed bestowed on me some power, and taught me something of the interpretation of dreams and events,- O Thou Creator of the heavens and the earth! Thou art my Protector in this world and in the Hereafter. Take Thou my soul (at death) as one submitting to Thy will (as a Muslim), and unite me with the righteous."

# 1698

Such is one of the stories of what happened unseen, which We reveal by inspiration unto thee; nor wast thou (present) with them then when they concerted their plans together in the process of weaving their plots.

# 1699

Yet no faith will the greater part of mankind have, however ardently thou dost desire it.

# 1700

And no reward dost thou ask of them for this: it is no less than a message for all creatures.

# 1701

And how many Signs in the heavens and the earth do they pass by? Yet they turn (their faces) away from them!

# 1702

And most of them believe not in Allah without associating (other as partners) with Him!

# 1703

Do they then feel secure from the coming against them of the covering veil of the wrath of Allah,- or of the coming against them of the (final) Hour all of a sudden while they perceive not?

# 1704

Say thou: "This is my way: I do invite unto Allah,- on evidence clear as the seeing with one's eyes,- I and whoever follows me. Glory to Allah! and never will I join gods with Allah!"

# 1705

Nor did We send before thee (as messengers) any but men, whom we did inspire,- (men) living in human habitations. Do they not travel through the earth, and see what was the end of those before them? But the home of the hereafter is best, for those who do right. Will ye not then understand?

# 1706

(Respite will be granted) until, when the messengers give up hope (of their people) and (come to) think that they were treated as liars, there reaches them Our help, and those whom We will are delivered into safety. But never will be warded off our punishment from those who are in sin.

# 1707

There is, in their stories, instruction for men endued with understanding. It is not a tale invented, but a confirmation of what went before it,- a detailed exposition of all things, and a guide and a mercy to any such as believe.

# 1708

A. L. M. R. These are the signs (or verses) of the Book: that which hath been revealed unto thee from thy Lord is the Truth; but most men believe not.

# 1709

Allah is He Who raised the heavens without any pillars that ye can see; is firmly established on the throne (of authority); He has subjected the sun and the moon (to his Law)! Each one runs (its course) for a term appointed. He doth regulate all affairs, explaining the signs in detail, that ye may believe with certainty in the meeting with your Lord.

# 1710

And it is He who spread out the earth, and set thereon mountains standing firm and (flowing) rivers: and fruit of every kind He made in pairs, two and two: He draweth the night as a veil o'er the Day. Behold, verily in these things there are signs for those who consider!

# 1711

And in the earth are tracts (diverse though) neighbouring, and gardens of vines and fields sown with corn, and palm trees - growing out of single roots or otherwise: watered with the same water, yet some of them We make more excellent than others to eat. Behold, verily in these things there are signs for those who understand!

# 1712

If thou dost marvel (at their want of faith), strange is their saying: "When we are (actually) dust, shall we indeed then be in a creation renewed?" They are those who deny their Lord! They are those round whose necks will be yokes (of servitude): they will be Companions of the Fire, to dwell therein (for aye)!

# 1713

They ask thee to hasten on the evil in preference to the good: Yet have come to pass, before them, (many) exemplary punishments! But verily thy Lord is full of forgiveness for mankind for their wrong-doing, and verily thy Lord is (also) strict in punishment.

# 1714

And the Unbelievers say: "Why is not a sign sent down to him from his Lord?" But thou art truly a warner, and to every people a guide.

# 1715

Allah doth know what every female (womb) doth bear, by how much the wombs fall short (of their time or number) or do exceed. Every single thing is before His sight, in (due) proportion.

# 1716

He knoweth the unseen and that which is open: He is the Great, the Most High.

# 1717

It is the same (to Him) whether any of you conceal his speech or declare it openly; whether he lie hid by night or walk forth freely by day.

# 1718

For each (such person) there are (angels) in succession, before and behind him: They guard him by command of Allah. Allah does not change a people's lot unless they change what is in their hearts. But when (once) Allah willeth a people's punishment, there can be no turning it back, nor will they find, besides Him, any to protect.

# 1719

It is He Who doth show you the lightning, by way both of fear and of hope: It is He Who doth raise up the clouds, heavy with (fertilising) rain!

# 1720

Nay, thunder repeateth His praises, and so do the angels, with awe: He flingeth the loud-voiced thunder-bolts, and therewith He striketh whomsoever He will.. yet these (are the men) who (dare to) dispute about Allah, with the strength of His power (supreme)!

# 1721

For Him (alone) is prayer in Truth: any others that they call upon besides Him hear them no more than if they were to stretch forth their hands for water to reach their mouths but it reaches them not: for the prayer of those without Faith is nothing but (futile) wandering (in the mind).

# 1722

Whatever beings there are in the heavens and the earth do prostrate themselves to Allah (Acknowledging subjection),- with good-will or in spite of themselves: so do their shadows in the morning and evenings.

# 1723

Say: "Who is the Lord and Sustainer of the heavens and the earth?" Say: "(It is) Allah." Say: "Do ye then take (for worship) protectors other than Him, such as have no power either for good or for harm to themselves?" Say: "Are the blind equal with those who see? Or the depths of darkness equal with light?" Or do they assign to Allah partners who have created (anything) as He has created, so that the creation seemed to them similar? Say: "Allah is the Creator of all things: He is the One, the Supreme and Irresistible."

# 1724

He sends down water from the skies, and the channels flow, each according to its measure: But the torrent bears away to foam that mounts up to the surface. Even so, from that (ore) which they heat in the fire, to make ornaments or utensils therewith, there is a scum likewise. Thus doth Allah (by parables) show forth Truth and Vanity. For the scum disappears like forth cast out; while that which is for the good of mankind remains on the earth. Thus doth Allah set forth parables.

# 1725

For those who respond to their Lord, are (all) good things. But those who respond not to Him,- Even if they had all that is in the heavens and on earth, and as much more, (in vain) would they offer it for ransom. For them will the reckoning be terrible: their abode will be Hell,- what a bed of misery!

# 1726

Is then one who doth know that that which hath been revealed unto thee from thy Lord is the Truth, like one who is blind? It is those who are endued with understanding that receive admonition;-

# 1727

Those who fulfil the covenant of Allah and fail not in their plighted word;

# 1728

Those who join together those things which Allah hath commanded to be joined, hold their Lord in awe, and fear the terrible reckoning;

# 1729

Those who patiently persevere, seeking the countenance of their Lord; Establish regular prayers; spend, out of (the gifts) We have bestowed for their sustenance, secretly and openly; and turn off Evil with good: for such there is the final attainment of the (eternal) home,-

# 1730

Gardens of perpetual bliss: they shall enter there, as well as the righteous among their fathers, their spouses, and their offspring: and angels shall enter unto them from every gate (with the salutation):

# 1731

"Peace unto you for that ye persevered in patience! Now how excellent is the final home!"

# 1732

But those who break the Covenant of Allah, after having plighted their word thereto, and cut asunder those things which Allah has commanded to be joined, and work mischief in the land;- on them is the curse; for them is the terrible home!

# 1733

Allah doth enlarge, or grant by (strict) measure, the sustenance (which He giveth) to whomso He pleaseth. (The wordly) rejoice in the life of this world: But the life of this world is but little comfort in the Hereafter.

# 1734

The Unbelievers say: "Why is not a sign sent down to him from his Lord?" Say: "Truly Allah leaveth, to stray, whom He will; But He guideth to Himself those who turn to Him in penitence,-

# 1735

"Those who believe, and whose hearts find satisfaction in the remembrance of Allah: for without doubt in the remembrance of Allah do hearts find satisfaction.

# 1736

"For those who believe and work righteousness, is (every) blessedness, and a beautiful place of (final) return."

# 1737

Thus have we sent thee amongst a People before whom (long since) have (other) Peoples (gone and) passed away; in order that thou mightest rehearse unto them what We send down unto thee by inspiration; yet do they reject (Him), the Most Gracious! Say: "He is my Lord! There is no god but He! On Him is my trust, and to Him do I turn!"

# 1738

If there were a Qur'an with which mountains were moved, or the earth were cloven asunder, or the dead were made to speak, (this would be the one!) But, truly, the command is with Allah in all things! Do not the Believers know, that, had Allah (so) willed, He could have guided all mankind (to the right)? But the Unbelievers,- never will disaster cease to seize them for their (ill) deeds, or to settle close to their homes, until the promise of Allah come to pass, for, verily, Allah will not fail in His promise.

# 1739

Mocked were (many) messengers before thee: but I granted respite to the unbelievers, and finally I punished them: Then how (terrible) was my requital!

# 1740

Is then He who standeth over every soul (and knoweth) all that it doth, (like any others)? And yet they ascribe partners to Allah. Say: "But name them! is it that ye will inform Him of something he knoweth not on earth, or is it (just) a show of words?" Nay! to those who believe not, their pretence seems pleasing, but they are kept back (thereby) from the path. And those whom Allah leaves to stray, no one can guide.

# 1741

For them is a penalty in the life of this world, but harder, truly, is the penalty of the Hereafter: and defender have they none against Allah.

# 1742

The parable of the Garden which the righteous are promised!- beneath it flow rivers: perpetual is the enjoyment thereof and the shade therein: such is the end of the Righteous; and the end of Unbelievers in the Fire.

# 1743

Those to whom We have given the Book rejoice at what hath been revealed unto thee: but there are among the clans those who reject a part thereof. Say: "I am commanded to worship Allah, and not to join partners with Him. Unto Him do I call, and unto Him is my return."

# 1744

Thus have We revealed it to be a judgment of authority in Arabic. Wert thou to follow their (vain) desires after the knowledge which hath reached thee, then wouldst thou find neither protector nor defender against Allah.

# 1745

We did send messengers before thee, and appointed for them wives and children: and it was never the part of a messenger to bring a sign except as Allah permitted (or commanded). For each period is a Book (revealed).

# 1746

Allah doth blot out or confirm what He pleaseth: with Him is the Mother of the Book.

# 1747

Whether We shall show thee (within thy life-time) part of what we promised them or take to ourselves thy soul (before it is all accomplished),- thy duty is to make (the Message) reach them: it is our part to call them to account.

# 1748

See they not that We gradually reduce the land (in their control) from its outlying borders? (Where) Allah commands, there is none to put back His Command: and He is swift in calling to account.

# 1749

Those before them did (also) devise plots; but in all things the master-planning is Allah's He knoweth the doings of every soul: and soon will the Unbelievers know who gets home in the end.

# 1750

The Unbelievers say: "No messenger art thou." Say: "Enough for a witness between me and you is Allah, and such as have knowledge of the Book."

# 1751

A. L. R. A Book which We have revealed unto thee, in order that thou mightest lead mankind out of the depths of darkness into light - by the leave of their Lord - to the Way of (Him) the Exalted in power, worthy of all praise!-

# 1752

Of Allah, to Whom do belong all things in the heavens and on earth! But alas for the Unbelievers for a terrible penalty (their Unfaith will bring them)!-

# 1753

Those who love the life of this world more than the Hereafter, who hinder (men) from the Path of Allah and seek therein something crooked: they are astray by a long distance.

# 1754

We sent not a messenger except (to teach) in the language of his (own) people, in order to make (things) clear to them. Now Allah leaves straying those whom He pleases and guides whom He pleases: and He is Exalted in power, full of Wisdom.

# 1755

We sent Moses with Our signs (and the command). "Bring out thy people from the depths of darkness into light, and teach them to remember the Days of Allah." Verily in this there are Signs for such as are firmly patient and constant,- grateful and appreciative.

# 1756

Remember! Moses said to his people: "Call to mind the favour of Allah to you when He delivered you from the people of Pharaoh: they set you hard tasks and punishments, slaughtered your sons, and let your women-folk live: therein was a tremendous trial from your Lord."

# 1757

And remember! your Lord caused to be declared (publicly): "If ye are grateful, I will add more (favours) unto you; But if ye show ingratitude, truly My punishment is terrible indeed."

# 1758

And Moses said: "If ye show ingratitude, ye and all on earth together, yet is Allah free of all wants, worthy of all praise.

# 1759

Has not the story reached you, (O people!), of those who (went) before you? - of the people of Noah, and 'Ad, and Thamud? - And of those who (came) after them? None knows them but Allah. To them came messengers with Clear (Signs); but they put their hands up to their mouths, and said: "We do deny (the mission) on which ye have been sent, and we are really in suspicious (disquieting) doubt as to that to which ye invite us."

# 1760

Their messengers said: "Is there a doubt about Allah, The Creator of the heavens and the earth? It is He Who invites you, in order that He may forgive you your sins and give you respite for a term appointed!" They said: "Ah! ye are no more than human, like ourselves! Ye wish to turn us away from the (gods) our fathers used to worship: then bring us some clear authority."

# 1761

Their messengers said to them: "True, we are human like yourselves, but Allah doth grant His grace to such of his servants as He pleases. It is not for us to bring you an authority except as Allah permits. And on Allah let all men of faith put their trust.

# 1762

"No reason have we why we should not put our trust on Allah. Indeed He Has guided us to the Ways we (follow). We shall certainly bear with patience all the hurt you may cause us. For those who put their trust should put their trust on Allah."

# 1763

And the Unbelievers said to their messengers: "Be sure we shall drive you out of our land, or ye shall return to our religion." But their Lord inspired (this Message) to them: "Verily We shall cause the wrong-doers to perish!

# 1764

"And verily We shall cause you to abide in the land, and succeed them. This for such as fear the Time when they shall stand before My tribunal,- such as fear the punishment denounced."

# 1765

But they sought victory and decision (there and then), and frustration was the lot of every powerful obstinate transgressor.

# 1766

In front of such a one is Hell, and he is given, for drink, boiling fetid water.

# 1767

In gulps will he sip it, but never will he be near swallowing it down his throat: death will come to him from every quarter, yet will he not die: and in front of him will be a chastisement unrelenting.

# 1768

The parable of those who reject their Lord is that their works are as ashes, on which the wind blows furiously on a tempestuous day: No power have they over aught that they have earned: that is the straying far, far (from the goal).

# 1769

Seest thou not that Allah created the heavens and the earth in Truth? If He so will, He can remove you and put (in your place) a new creation?

# 1770

Nor is that for Allah any great matter.

# 1771

They will all be marshalled before Allah together: then will the weak say to those who were arrogant, "For us, we but followed you; can ye then avail us to all against the wrath of Allah?" They will reply, "If we had received the Guidance of Allah, we should have given it to you: to us it makes no difference (now) whether we rage, or bear (these torments) with patience: for ourselves there is no way of escape."

# 1772

And Satan will say when the matter is decided: "It was Allah Who gave you a promise of Truth: I too promised, but I failed in my promise to you. I had no authority over you except to call you but ye listened to me: then reproach not me, but reproach your own souls. I cannot listen to your cries, nor can ye listen to mine. I reject your former act in associating me with Allah. For wrong-doers there must be a grievous penalty."

# 1773

But those who believe and work righteousness will be admitted to gardens beneath which rivers flow,- to dwell therein for aye with the leave of their Lord. Their greeting therein will be: "Peace!"

# 1774

Seest thou not how Allah sets forth a parable? - A goodly word like a goodly tree, whose root is firmly fixed, and its branches (reach) to the heavens,- of its Lord. So Allah sets forth parables for men, in order that they may receive admonition.

# 1775

It brings forth its fruit at all times, by the leave of its Lord. So Allah sets forth parables for men, in order that they may receive admonition.

# 1776

And the parable of an evil Word is that of an evil tree: It is torn up by the root from the surface of the earth: it has no stability.

# 1777

Allah will establish in strength those who believe, with the word that stands firm, in this world and in the Hereafter; but Allah will leave, to stray, those who do wrong: Allah doeth what He willeth.

# 1778

Hast thou not turned thy vision to those who have changed the favour of Allah. Into blasphemy and caused their people to descend to the House of Perdition?-

# 1779

Into Hell? They will burn therein,- an evil place to stay in!

# 1780

And they set up (idols) as equal to Allah, to mislead (men) from the Path! Say: "Enjoy (your brief power)! But verily ye are making straightway for Hell!"

# 1781

Speak to my servants who have believed, that they may establish regular prayers, and spend (in charity) out of the sustenance we have given them, secretly and openly, before the coming of a Day in which there will be neither mutual bargaining nor befriending.

# 1782

It is Allah Who hath created the heavens and the earth and sendeth down rain from the skies, and with it bringeth out fruits wherewith to feed you; it is He Who hath made the ships subject to you, that they may sail through the sea by His command; and the rivers (also) hath He made subject to you.

# 1783

And He hath made subject to you the sun and the moon, both diligently pursuing their courses; and the night and the day hath he (also) made subject to you.

# 1784

And He giveth you of all that ye ask for. But if ye count the favours of Allah, never will ye be able to number them. Verily, man is given up to injustice and ingratitude.

# 1785

Remember Abraham said: "O my Lord! make this city one of peace and security: and preserve me and my sons from worshipping idols.

# 1786

"O my Lord! they have indeed led astray many among mankind; He then who follows my (ways) is of me, and he that disobeys me,- but Thou art indeed Oft-forgiving, Most Merciful.

# 1787

"O our Lord! I have made some of my offspring to dwell in a valley without cultivation, by Thy Sacred House; in order, O our Lord, that they may establish regular Prayer: so fill the hearts of some among men with love towards them, and feed them with fruits: so that they may give thanks.

# 1788

"O our Lord! truly Thou dost know what we conceal and what we reveal: for nothing whatever is hidden from Allah, whether on earth or in heaven.

# 1789

"Praise be to Allah, Who hath granted unto me in old age Isma'il and Isaac: for truly my Lord is He, the Hearer of Prayer!

# 1790

O my Lord! make me one who establishes regular Prayer, and also (raise such) among my offspring O our Lord! and accept Thou my Prayer.

# 1791

"O our Lord! cover (us) with Thy Forgiveness - me, my parents, and (all) Believers, on the Day that the Reckoning will be established!

# 1792

Think not that Allah doth not heed the deeds of those who do wrong. He but giveth them respite against a Day when the eyes will fixedly stare in horror,-

# 1793

They running forward with necks outstretched, their heads uplifted, their gaze returning not towards them, and their hearts a (gaping) void!

# 1794

So warn mankind of the Day when the Wrath will reach them: then will the wrong-doers say: "Our Lord! respite us (if only) for a short term: we will answer Thy call, and follow the messengers!" "What! were ye not wont to swear aforetime that ye should suffer no decline?

# 1795

"And ye dwelt in the dwellings of men who wronged their own souls; ye were clearly shown how We dealt with them; and We put forth (many) parables in your behoof!"

# 1796

Mighty indeed were the plots which they made, but their plots were (well) within the sight of Allah, even though they were such as to shake the hills!

# 1797

Never think that Allah would fail his messengers in His promise: for Allah is Exalted in power, - the Lord of Retribution.

# 1798

One day the earth will be changed to a different earth, and so will be the heavens, and (men) will be marshalled forth, before Allah, the One, the Irresistible;

# 1799

And thou wilt see the sinners that day bound together in fetters;-

# 1800

Their garments of liquid pitch, and their faces covered with Fire;

# 1801

That Allah may requite each soul according to its deserts; and verily Allah is swift in calling to account.

# 1802

Here is a Message for mankind: Let them take warning therefrom, and let them know that He is (no other than) One Allah: let men of understanding take heed.

# 1803

A. L. R. These are the Ayats of Revelation,- of a Qur'an that makes things clear.

# 1804

Again and again will those who disbelieve, wish that they had bowed (to Allah's will) in Islam.

# 1805

Leave them alone, to enjoy (the good things of this life) and to please themselves: let (false) hope amuse them: soon will knowledge (undeceive them).

# 1806

Never did We destroy a population that had not a term decreed and assigned beforehand.

# 1807

Neither can a people anticipate its term, nor delay it.

# 1808

They say: "O thou to whom the Message is being revealed! truly thou art mad (or possessed)!

# 1809

"Why bringest thou not angels to us if it be that thou hast the Truth?"

# 1810

We send not the angels down except for just cause: if they came (to the ungodly), behold! no respite would they have!

# 1811

We have, without doubt, sent down the Message; and We will assuredly guard it (from corruption).

# 1812

We did send messengers before thee amongst the religious sects of old:

# 1813

But never came a messenger to them but they mocked him.

# 1814

Even so do we let it creep into the hearts of the sinners -

# 1815

That they should not believe in the (Message); but the ways of the ancients have passed away.

# 1816

Even if We opened out to them a gate from heaven, and they were to continue (all day) ascending therein,

# 1817

They would only say: "Our eyes have been intoxicated: Nay, we have been bewitched by sorcery."

# 1818

It is We Who have set out the zodiacal signs in the heavens, and made them fair-seeming to (all) beholders;

# 1819

And (moreover) We have guarded them from every cursed devil:

# 1820

But any that gains a hearing by stealth, is pursued by a flaming fire, bright (to see).

# 1821

And the earth We have spread out (like a carpet); set thereon mountains firm and immovable; and produced therein all kinds of things in due balance.

# 1822

And We have provided therein means of subsistence,- for you and for those for whose sustenance ye are not responsible.

# 1823

And there is not a thing but its (sources and) treasures (inexhaustible) are with Us; but We only send down thereof in due and ascertainable measures.

# 1824

And We send the fecundating winds, then cause the rain to descend from the sky, therewith providing you with water (in abundance), though ye are not the guardians of its stores.

# 1825

And verily, it is We Who give life, and Who give death: it is We Who remain inheritors (after all else passes away).

# 1826

To Us are known those of you who hasten forward, and those who lag behind.

# 1827

Assuredly it is thy Lord Who will gather them together: for He is perfect in Wisdom and Knowledge.

# 1828

We created man from sounding clay, from mud moulded into shape;

# 1829

And the Jinn race, We had created before, from the fire of a scorching wind.

# 1830

Behold! thy Lord said to the angels: "I am about to create man, from sounding clay from mud moulded into shape;

# 1831

"When I have fashioned him (in due proportion) and breathed into him of My spirit, fall ye down in obeisance unto him."

# 1832

So the angels prostrated themselves, all of them together:

# 1833

Not so Iblis: he refused to be among those who prostrated themselves.

# 1834

(Allah) said: "O Iblis! what is your reason for not being among those who prostrated themselves?"

# 1835

(Iblis) said: "I am not one to prostrate myself to man, whom Thou didst create from sounding clay, from mud moulded into shape."

# 1836

(Allah) said: "Then get thee out from here; for thou art rejected, accursed.

# 1837

"And the curse shall be on thee till the day of Judgment."

# 1838

(Iblis) said: "O my Lord! give me then respite till the Day the (dead) are raised."

# 1839

(Allah) said: "Respite is granted thee

# 1840

"Till the Day of the Time appointed."

# 1841

(Iblis) said: "O my Lord! because Thou hast put me in the wrong, I will make (wrong) fair-seeming to them on the earth, and I will put them all in the wrong,-

# 1842

"Except Thy servants among them, sincere and purified (by Thy Grace)."

# 1843

(Allah) said: "This (way of My sincere servants) is indeed a way that leads straight to Me.

# 1844

"For over My servants no authority shalt thou have, except such as put themselves in the wrong and follow thee."

# 1845

And verily, Hell is the promised abode for them all!

# 1846

To it are seven gates: for each of those gates is a (special) class (of sinners) assigned.

# 1847

The righteous (will be) amid gardens and fountains (of clear-flowing water).

# 1848

(Their greeting will be): "Enter ye here in peace and security."

# 1849

And We shall remove from their hearts any lurking sense of injury: (they will be) brothers (joyfully) facing each other on thrones (of dignity).

# 1850

There no sense of fatigue shall touch them, nor shall they (ever) be asked to leave.

# 1851

Tell My servants that I am indeed the Oft-forgiving, Most Merciful;

# 1852

And that My Penalty will be indeed the most grievous Penalty.

# 1853

Tell them about the guests of Abraham.

# 1854

When they entered his presence and said, "Peace!" He said, "We feel afraid of you!"

# 1855

They said: "Fear not! We give thee glad tidings of a son endowed with wisdom."

# 1856

He said: "Do ye give me glad tidings that old age has seized me? Of what, then, is your good news?"

# 1857

They said: "We give thee glad tidings in truth: be not then in despair!"

# 1858

He said: "And who despairs of the mercy of his Lord, but such as go astray?"

# 1859

Abraham said: "What then is the business on which ye (have come), O ye messengers (of Allah)?"

# 1860

They said: "We have been sent to a people (deep) in sin,

# 1861

"Excepting the adherents of Lut: them we are certainly (charged) to save (from harm),- All -

# 1862

"Except his wife, who, We have ascertained, will be among those who will lag behind."

# 1863

At length when the messengers arrived among the adherents of Lut,

# 1864

He said: "Ye appear to be uncommon folk."

# 1865

They said: "Yea, we have come to thee to accomplish that of which they doubt.

# 1866

"We have brought to thee that which is inevitably due, and assuredly we tell the truth.

# 1867

"Then travel by night with thy household, when a portion of the night (yet remains), and do thou bring up the rear: let no one amongst you look back, but pass on whither ye are ordered."

# 1868

And We made known this decree to him, that the last remnants of those (sinners) should be cut off by the morning.

# 1869

The inhabitants of the city came in (mad) joy (at news of the young men).

# 1870

Lut said: "These are my guests: disgrace me not:

# 1871

"But fear Allah, and shame me not."

# 1872

They said: "Did we not forbid thee (to speak) for all and sundry?"

# 1873

He said: "There are my daughters (to marry), if ye must act (so)."

# 1874

Verily, by thy life (O Prophet), in their wild intoxication, they wander in distraction, to and fro.

# 1875

But the (mighty) Blast overtook them before morning,

# 1876

And We turned (the cities) upside down, and rained down on them brimstones hard as baked clay.

# 1877

Behold! in this are Signs for those who by tokens do understand.

# 1878

And the (cities were) right on the high-road.

# 1879

Behold! in this is a sign for those who believed.

# 1880

And the Companions of the Wood were also wrong-doers;

# 1881

So We exacted retribution from them. They were both on an open highway, plain to see.

# 1882

The Companions of the Rocky Tract also rejected the messengers:

# 1883

We sent them Our Signs, but they persisted in turning away from them.

# 1884

Out of the mountains did they hew (their) edifices, (feeling themselves) secure.

# 1885

But the (mighty) Blast seized them of a morning,

# 1886

And of no avail to them was all that they did (with such art and care)!

# 1887

We created not the heavens, the earth, and all between them, but for just ends. And the Hour is surely coming (when this will be manifest). So overlook (any human faults) with gracious forgiveness.

# 1888

For verily it is thy Lord who is the Master-Creator, knowing all things.

# 1889

And We have bestowed upon thee the Seven Oft-repeated (verses) and the Grand Qur'an.

# 1890

Strain not thine eyes. (Wistfully) at what We have bestowed on certain classes of them, nor grieve over them: but lower thy wing (in gentleness) to the believers.

# 1891

And say: "I am indeed he that warneth openly and without ambiguity,"-

# 1892

(Of just such wrath) as We sent down on those who divided (Scripture into arbitrary parts),-

# 1893

(So also on such) as have made Qur'an into shreds (as they please).

# 1894

Therefore, by the Lord, We will, of a surety, call them to account,

# 1895

For all their deeds.

# 1896

Therefore expound openly what thou art commanded, and turn away from those who join false gods with Allah.

# 1897

For sufficient are We unto thee against those who scoff,-

# 1898

Those who adopt, with Allah, another god: but soon will they come to know.

# 1899

We do indeed know how thy heart is distressed at what they say.

# 1900

But celebrate the praises of thy Lord, and be of those who prostrate themselves in adoration.

# 1901

And serve thy Lord until there come unto thee the Hour that is Certain.

# 1902

(Inevitable) cometh (to pass) the Command of Allah: seek ye not then to hasten it: Glory to Him, and far is He above having the partners they ascribe unto Him!

# 1903

He doth send down His angels with inspiration of His Command, to such of His servants as He pleaseth, (saying): "Warn (Man) that there is no god but I: so do your duty unto Me."

# 1904

He has created the heavens and the earth for just ends: Far is He above having the partners they ascribe to Him!

# 1905

He has created man from a sperm-drop; and behold this same (man) becomes an open disputer!

# 1906

And cattle He has created for you (men): from them ye derive warmth, and numerous benefits, and of their (meat) ye eat.

# 1907

And ye have a sense of pride and beauty in them as ye drive them home in the evening, and as ye lead them forth to pasture in the morning.

# 1908

And they carry your heavy loads to lands that ye could not (otherwise) reach except with souls distressed: for your Lord is indeed Most Kind, Most Merciful,

# 1909

And (He has created) horses, mules, and donkeys, for you to ride and use for show; and He has created (other) things of which ye have no knowledge.

# 1910

And unto Allah leads straight the Way, but there are ways that turn aside: if Allah had willed, He could have guided all of you.

# 1911

It is He who sends down rain from the sky: from it ye drink, and out of it (grows) the vegetation on which ye feed your cattle.

# 1912

With it He produces for you corn, olives, date-palms, grapes and every kind of fruit: verily in this is a sign for those who give thought.

# 1913

He has made subject to you the Night and the Day; the sun and the moon; and the stars are in subjection by His Command: verily in this are Signs for men who are wise.

# 1914

And the things on this earth which He has multiplied in varying colours (and qualities): verily in this is a sign for men who celebrate the praises of Allah (in gratitude).

# 1915

It is He Who has made the sea subject, that ye may eat thereof flesh that is fresh and tender, and that ye may extract therefrom ornaments to wear; and thou seest the ships therein that plough the waves, that ye may seek (thus) of the bounty of Allah and that ye may be grateful.

# 1916

And He has set up on the earth mountains standing firm, lest it should shake with you; and rivers and roads; that ye may guide yourselves;

# 1917

And marks and sign-posts; and by the stars (men) guide themselves.

# 1918

Is then He Who creates like one that creates not? Will ye not receive admonition?

# 1919

If ye would count up the favours of Allah, never would ye be able to number them: for Allah is Oft-Forgiving, Most Merciful.

# 1920

And Allah doth know what ye conceal, and what ye reveal.

# 1921

Those whom they invoke besides Allah create nothing and are themselves created.

# 1922

(They are things) dead, lifeless: nor do they know when they will be raised up.

# 1923

Your Allah is one Allah: as to those who believe not in the Hereafter, their hearts refuse to know, and they are arrogant.

# 1924

Undoubtedly Allah doth know what they conceal, and what they reveal: verily He loveth not the arrogant.

# 1925

When it is said to them, "What is it that your Lord has revealed?" they say, "Tales of the ancients!"

# 1926

Let them bear, on the Day of Judgment, their own burdens in full, and also (something) of the burdens of those without knowledge, whom they misled. Alas, how grievous the burdens they will bear!

# 1927

Those before them did also plot (against Allah's Way): but Allah took their structures from their foundations, and the roof fell down on them from above; and the Wrath seized them from directions they did not perceive.

# 1928

Then, on the Day of Judgment, He will cover them with shame, and say: "Where are My 'partners' concerning whom ye used to dispute (with the godly)?" Those endued with knowledge will say: "This Day, indeed, are the Unbelievers covered with shame and misery,-

# 1929

"(Namely) those whose lives the angels take in a state of wrong-doing to their own souls." Then would they offer submission (with the pretence), "We did no evil (knowingly)." (The angels will reply), "Nay, but verily Allah knoweth all that ye did;

# 1930

"So enter the gates of Hell, to dwell therein. Thus evil indeed is the abode of the arrogant."

# 1931

To the righteous (when) it is said, "What is it that your Lord has revealed?" they say, "All that is good." To those who do good, there is good in this world, and the Home of the Hereafter is even better and excellent indeed is the Home of the righteous,-

# 1932

Gardens of Eternity which they will enter: beneath them flow (pleasant) rivers: they will have therein all that they wish: thus doth Allah reward the righteous,-

# 1933

(Namely) those whose lives the angels take in a state of purity, saying (to them), "Peace be on you; enter ye the Garden, because of (the good) which ye did (in the world)."

# 1934

Do the (ungodly) wait until the angels come to them, or there comes the Command of thy Lord (for their doom)? So did those who went before them. But Allah wronged them not: nay, they wronged their own souls.

# 1935

But the evil results of their deeds overtook them, and that very (Wrath) at which they had scoffed hemmed them in.

# 1936

The worshippers of false gods say: "If Allah had so willed, we should not have worshipped aught but Him - neither we nor our fathers,- nor should we have prescribed prohibitions other than His." So did those who went before them. But what is the mission of messengers but to preach the Clear Message?

# 1937

For We assuredly sent amongst every People a messenger, (with the Command), "Serve Allah, and eschew Evil": of the People were some whom Allah guided, and some on whom error became inevitably (established). So travel through the earth, and see what was the end of those who denied (the Truth).

# 1938

If thou art anxious for their guidance, yet Allah guideth not such as He leaves to stray, and there is none to help them.

# 1939

They swear their strongest oaths by Allah, that Allah will not raise up those who die: Nay, but it is a promise (binding) on Him in truth: but most among mankind realise it not.

# 1940

(They must be raised up), in order that He may manifest to them the truth of that wherein they differ, and that the rejecters of Truth may realise that they had indeed (surrendered to) Falsehood.

# 1941

For to anything which We have willed, We but say the word, "Be", and it is.

# 1942

To those who leave their homes in the cause of Allah, after suffering oppression,- We will assuredly give a goodly home in this world; but truly the reward of the Hereafter will be greater. If they only realised (this)!

# 1943

(They are) those who persevere in patience, and put their trust on their Lord.

# 1944

And before thee also the messengers We sent were but men, to whom We granted inspiration: if ye realise this not, ask of those who possess the Message.

# 1945

(We sent them) with Clear Signs and Books of dark prophecies; and We have sent down unto thee (also) the Message; that thou mayest explain clearly to men what is sent for them, and that they may give thought.

# 1946

Do then those who devise evil (plots) feel secure that Allah will not cause the earth to swallow them up, or that the Wrath will not seize them from directions they little perceive?-

# 1947

Or that He may not call them to account in the midst of their goings to and fro, without a chance of their frustrating Him?-

# 1948

Or that He may not call them to account by a process of slow wastage - for thy Lord is indeed full of kindness and mercy.

# 1949

Do they not look at Allah's creation, (even) among (inanimate) things,- How their (very) shadows turn round, from the right and the left, prostrating themselves to Allah, and that in the humblest manner?

# 1950

And to Allah doth obeisance all that is in the heavens and on earth, whether moving (living) creatures or the angels: for none are arrogant (before their Lord).

# 1951

They all revere their Lord, high above them, and they do all that they are commanded.

# 1952

Allah has said: "Take not (for worship) two gods: for He is just One Allah: then fear Me (and Me alone)."

# 1953

To Him belongs whatever is in the heavens and on earth, and to Him is duty due always: then will ye fear other than Allah?

# 1954

And ye have no good thing but is from Allah: and moreover, when ye are touched by distress, unto Him ye cry with groans;

# 1955

Yet, when He removes the distress from you, behold! some of you turn to other gods to join with their Lord-

# 1956

(As if) to show their ingratitude for the favours we have bestowed on them! then enjoy (your brief day): but soon will ye know (your folly)!

# 1957

And they (even) assign, to things they do not know, a portion out of that which We have bestowed for their sustenance! By Allah, ye shall certainly be called to account for your false inventions.

# 1958

And they assign daughters for Allah! - Glory be to Him! - and for themselves (sons,- the issue) they desire!

# 1959

When news is brought to one of them, of (the birth of) a female (child), his face darkens, and he is filled with inward grief!

# 1960

With shame does he hide himself from his people, because of the bad news he has had! Shall he retain it on (sufferance and) contempt, or bury it in the dust? Ah! what an evil (choice) they decide on?

# 1961

To those who believe not in the Hereafter, applies the similitude of evil: to Allah applies the highest similitude: for He is the Exalted in Power, full of Wisdom.

# 1962

If Allah were to punish men for their wrong-doing, He would not leave, on the (earth), a single living creature: but He gives them respite for a stated Term: When their Term expires, they would not be able to delay (the punishment) for a single hour, just as they would not be able to anticipate it (for a single hour).

# 1963

They attribute to Allah what they hate (for themselves), and their tongues assert the falsehood that all good things are for themselves: without doubt for them is the Fire, and they will be the first to be hastened on into it!

# 1964

By Allah, We (also) sent (Our messengers) to Peoples before thee; but Satan made, (to the wicked), their own acts seem alluring: He is also their patron today, but they shall have a most grievous penalty.

# 1965

And We sent down the Book to thee for the express purpose, that thou shouldst make clear to them those things in which they differ, and that it should be a guide and a mercy to those who believe.

# 1966

And Allah sends down rain from the skies, and gives therewith life to the earth after its death: verily in this is a Sign for those who listen.

# 1967

And verily in cattle (too) will ye find an instructive sign. From what is within their bodies between excretions and blood, We produce, for your drink, milk, pure and agreeable to those who drink it.

# 1968

And from the fruit of the date-palm and the vine, ye get out wholesome drink and food: behold, in this also is a sign for those who are wise.

# 1969

And thy Lord taught the Bee to build its cells in hills, on trees, and in (men's) habitations;

# 1970

Then to eat of all the produce (of the earth), and find with skill the spacious paths of its Lord: there issues from within their bodies a drink of varying colours, wherein is healing for men: verily in this is a Sign for those who give thought.

# 1971

It is Allah who creates you and takes your souls at death; and of you there are some who are sent back to a feeble age, so that they know nothing after having known (much): for Allah is All-Knowing, All-Powerful.

# 1972

Allah has bestowed His gifts of sustenance more freely on some of you than on others: those more favoured are not going to throw back their gifts to those whom their right hands possess, so as to be equal in that respect. Will they then deny the favours of Allah?

# 1973

And Allah has made for you mates (and companions) of your own nature, and made for you, out of them, sons and daughters and grandchildren, and provided for you sustenance of the best: will they then believe in vain things, and be ungrateful for Allah's favours?-

# 1974

And worship others than Allah,- such as have no power of providing them, for sustenance, with anything in heavens or earth, and cannot possibly have such power?

# 1975

Invent not similitudes for Allah: for Allah knoweth, and ye know not.

# 1976

Allah sets forth the Parable (of two men: one) a slave under the dominion of another; He has no power of any sort; and (the other) a man on whom We have bestowed goodly favours from Ourselves, and he spends thereof (freely), privately and publicly: are the two equal? (By no means;) praise be to Allah. But most of them understand not.

# 1977

Allah sets forth (another) Parable of two men: one of them dumb, with no power of any sort; a wearisome burden is he to his master; whichever way be directs him, he brings no good: is such a man equal with one who commands Justice, and is on a Straight Way?

# 1978

To Allah belongeth the Mystery of the heavens and the earth. And the Decision of the Hour (of Judgment) is as the twingkling of an eye, or even quicker: for Allah hath power over all things.

# 1979

It is He Who brought you forth from the wombs of your mothers when ye knew nothing; and He gave you hearing and sight and intelligence and affections: that ye may give thanks (to Allah).

# 1980

Do they not look at the birds, held poised in the midst of (the air and) the sky? Nothing holds them up but (the power of) Allah. Verily in this are signs for those who believe.

# 1981

It is Allah Who made your habitations homes of rest and quiet for you; and made for you, out of the skins of animals, (tents for) dwellings, which ye find so light (and handy) when ye travel and when ye stop (in your travels); and out of their wool, and their soft fibres (between wool and hair), and their hair, rich stuff and articles of convenience (to serve you) for a time.

# 1982

It is Allah Who made out of the things He created, some things to give you shade; of the hills He made some for your shelter; He made you garments to protect you from heat, and coats of mail to protect you from your (mutual) violence. Thus does He complete His favours on you, that ye may bow to His Will (in Islam).

# 1983

But if they turn away, thy duty is only to preach the clear Message.

# 1984

They recognise the favours of Allah; then they deny them; and most of them are (creatures) ungrateful.

# 1985

One Day We shall raise from all Peoples a Witness: then will no excuse be accepted from Unbelievers, nor will they receive any favours.

# 1986

When the wrong-doers (actually) see the Penalty, then will it in no way be mitigated, nor will they then receive respite.

# 1987

When those who gave partners to Allah will see their "partners", they will say: "Our Lord! these are our 'partners,' those whom we used to invoke besides Thee." But they will throw back their word at them (and say): "Indeed ye are liars!"

# 1988

That Day shall they (openly) show (their) submission to Allah; and all their inventions shall leave them in the lurch.

# 1989

Those who reject Allah and hinder (men) from the Path of Allah - for them will We add Penalty to Penalty; for that they used to spread mischief.

# 1990

One day We shall raise from all Peoples a witness against them, from amongst themselves: and We shall bring thee as a witness against these (thy people): and We have sent down to thee the Book explaining all things, a Guide, a Mercy, and Glad Tidings to Muslims.

# 1991

Allah commands justice, the doing of good, and liberality to kith and kin, and He forbids all shameful deeds, and injustice and rebellion: He instructs you, that ye may receive admonition.

# 1992

Fulfil the Covenant of Allah when ye have entered into it, and break not your oaths after ye have confirmed them; indeed ye have made Allah your surety; for Allah knoweth all that ye do.

# 1993

And be not like a woman who breaks into untwisted strands the yarn which she has spun, after it has become strong. Nor take your oaths to practise deception between yourselves, lest one party should be more numerous than another: for Allah will test you by this; and on the Day of Judgment He will certainly make clear to you (the truth of) that wherein ye disagree.

# 1994

If Allah so willed, He could make you all one people: But He leaves straying whom He pleases, and He guides whom He pleases: but ye shall certainly be called to account for all your actions.

# 1995

And take not your oaths, to practise deception between yourselves, with the result that someone's foot may slip after it was firmly planted, and ye may have to taste the evil (consequences) of having hindered (men) from the Path of Allah, and a Mighty Wrath descend on you.

# 1996

Nor sell the covenant of Allah for a miserable price: for with Allah is (a prize) far better for you, if ye only knew.

# 1997

What is with you must vanish: what is with Allah will endure. And We will certainly bestow, on those who patiently persevere, their reward according to the best of their actions.

# 1998

Whoever works righteousness, man or woman, and has Faith, verily, to him will We give a new Life, a life that is good and pure and We will bestow on such their reward according to the best of their actions.

# 1999

When thou dost read the Qur'an, seek Allah's protection from Satan the rejected one.

# 2000

No authority has he over those who believe and put their trust in their Lord.

# 2001

His authority is over those only, who take him as patron and who join partners with Allah.

# 2002

When We substitute one revelation for another,- and Allah knows best what He reveals (in stages),- they say, "Thou art but a forger": but most of them understand not.

# 2003

Say, the Holy Spirit has brought the revelation from thy Lord in Truth, in order to strengthen those who believe, and as a Guide and Glad Tidings to Muslims.

# 2004

We know indeed that they say, "It is a man that teaches him." The tongue of him they wickedly point to is notably foreign, while this is Arabic, pure and clear.

# 2005

Those who believe not in the Signs of Allah,- Allah will not guide them, and theirs will be a grievous Penalty.

# 2006

It is those who believe not in the Signs of Allah, that forge falsehood: it is they who lie!

# 2007

Any one who, after accepting faith in Allah, utters Unbelief,- except under compulsion, his heart remaining firm in Faith - but such as open their breast to Unbelief, on them is Wrath from Allah, and theirs will be a dreadful Penalty.

# 2008

This because they love the life of this world better than the Hereafter: and Allah will not guide those who reject Faith.

# 2009

Those are they whose hearts, ears, and eyes Allah has sealed up, and they take no heed.

# 2010

Without doubt, in the Hereafter they will perish.

# 2011

But verily thy Lord,- to those who leave their homes after trials and persecutions,- and who thereafter strive and fight for the faith and patiently persevere,- Thy Lord, after all this is oft-forgiving, Most Merciful.

# 2012

One Day every soul will come up struggling for itself, and every soul will be recompensed (fully) for all its actions, and none will be unjustly dealt with.

# 2013

Allah sets forth a Parable: a city enjoying security and quiet, abundantly supplied with sustenance from every place: Yet was it ungrateful for the favours of Allah: so Allah made it taste of hunger and terror (in extremes) (closing in on it) like a garment (from every side), because of the (evil) which (its people) wrought.

# 2014

And there came to them a Messenger from among themselves, but they falsely rejected him; so the Wrath seized them even in the midst of their iniquities.

# 2015

So eat of the sustenance which Allah has provided for you, lawful and good; and be grateful for the favours of Allah, if it is He Whom ye serve.

# 2016

He has only forbidden you dead meat, and blood, and the flesh of swine, and any (food) over which the name of other than Allah has been invoked. But if one is forced by necessity, without wilful disobedience, nor transgressing due limits,- then Allah is Oft-Forgiving, Most Merciful.

# 2017

But say not - for any false thing that your tongues may put forth,- "This is lawful, and this is forbidden," so as to ascribe false things to Allah. For those who ascribe false things to Allah, will never prosper.

# 2018

(In such falsehood) is but a paltry profit; but they will have a most grievous Penalty.

# 2019

To the Jews We prohibited such things as We have mentioned to thee before: We did them no wrong, but they were used to doing wrong to themselves.

# 2020

But verily thy Lord,- to those who do wrong in ignorance, but who thereafter repent and make amends,- thy Lord, after all this, is Oft-Forgiving, Most Merciful.

# 2021

Abraham was indeed a model, devoutly obedient to Allah, (and) true in Faith, and he joined not gods with Allah:

# 2022

He showed his gratitude for the favours of Allah, who chose him, and guided him to a Straight Way.

# 2023

And We gave him Good in this world, and he will be, in the Hereafter, in the ranks of the Righteous.

# 2024

So We have taught thee the inspired (Message), "Follow the ways of Abraham the True in Faith, and he joined not gods with Allah."

# 2025

The Sabbath was only made (strict) for those who disagreed (as to its observance); But Allah will judge between them on the Day of Judgment, as to their differences.

# 2026

Invite (all) to the Way of thy Lord with wisdom and beautiful preaching; and argue with them in ways that are best and most gracious: for thy Lord knoweth best, who have strayed from His Path, and who receive guidance.

# 2027

And if ye do catch them out, catch them out no worse than they catch you out: But if ye show patience, that is indeed the best (course) for those who are patient.

# 2028

And do thou be patient, for thy patience is but from Allah; nor grieve over them: and distress not thyself because of their plots.

# 2029

For Allah is with those who restrain themselves, and those who do good.

# 2030

Glory to (Allah) Who did take His servant for a Journey by night from the Sacred Mosque to the farthest Mosque, whose precincts We did bless,- in order that We might show him some of Our Signs: for He is the One Who heareth and seeth (all things).

# 2031

We gave Moses the Book, and made it a Guide to the Children of Israel, (commanding): "Take not other than Me as Disposer of (your) affairs."

# 2032

O ye that are sprung from those whom We carried (in the Ark) with Noah! Verily he was a devotee most grateful.

# 2033

And We gave (Clear) Warning to the Children of Israel in the Book, that twice would they do mischief on the earth and be elated with mighty arrogance (and twice would they be punished)!

# 2034

When the first of the warnings came to pass, We sent against you Our servants given to terrible warfare: They entered the very inmost parts of your homes; and it was a warning (completely) fulfilled.

# 2035

Then did We grant you the Return as against them: We gave you increase in resources and sons, and made you the more numerous in man-power.

# 2036

If ye did well, ye did well for yourselves; if ye did evil, (ye did it) against yourselves. So when the second of the warnings came to pass, (We permitted your enemies) to disfigure your faces, and to enter your Temple as they had entered it before, and to visit with destruction all that fell into their power.

# 2037

It may be that your Lord may (yet) show Mercy unto you; but if ye revert (to your sins), We shall revert (to Our punishments): And we have made Hell a prison for those who reject (all Faith).

# 2038

Verily this Qur'an doth guide to that which is most right (or stable), and giveth the Glad Tidings to the Believers who work deeds of righteousness, that they shall have a magnificent reward;

# 2039

And to those who believe not in the Hereafter, (it announceth) that We have prepared for them a Penalty Grievous (indeed).

# 2040

The prayer that man should make for good, he maketh for evil; for man is given to hasty (deeds).

# 2041

We have made the Night and the Day as two (of Our) Signs: the Sign of the Night have We obscured, while the Sign of the Day We have made to enlighten you; that ye may seek bounty from your Lord, and that ye may know the number and count of the years: all things have We explained in detail.

# 2042

Every man's fate We have fastened on his own neck: On the Day of Judgment We shall bring out for him a scroll, which he will see spread open.

# 2043

(It will be said to him:) "Read thine (own) record: Sufficient is thy soul this day to make out an account against thee."

# 2044

Who receiveth guidance, receiveth it for his own benefit: who goeth astray doth so to his own loss: No bearer of burdens can bear the burden of another: nor would We visit with Our Wrath until We had sent an messenger (to give warning).

# 2045

When We decide to destroy a population, We (first) send a definite order to those among them who are given the good things of this life and yet transgress; so that the word is proved true against them: then (it is) We destroy them utterly.

# 2046

How many generations have We destroyed after Noah? and enough is thy Lord to note and see the sins of His servants.

# 2047

If any do wish for the transitory things (of this life), We readily grant them - such things as We will, to such person as We will: in the end have We provided Hell for them: they will burn therein, disgraced and rejected.

# 2048

Those who do wish for the (things of) the Hereafter, and strive therefor with all due striving, and have Faith,- they are the ones whose striving is acceptable (to Allah).

# 2049

Of the bounties of thy Lord We bestow freely on all- These as well as those: The bounties of thy Lord are not closed (to anyone).

# 2050

See how We have bestowed more on some than on others; but verily the Hereafter is more in rank and gradation and more in excellence.

# 2051

Take not with Allah another object of worship; or thou (O man!) wilt sit in disgrace and destitution.

# 2052

Thy Lord hath decreed that ye worship none but Him, and that ye be kind to parents. Whether one or both of them attain old age in thy life, say not to them a word of contempt, nor repel them, but address them in terms of honour.

# 2053

And, out of kindness, lower to them the wing of humility, and say: "My Lord! bestow on them thy Mercy even as they cherished me in childhood."

# 2054

Your Lord knoweth best what is in your hearts: If ye do deeds of righteousness, verily He is Most Forgiving to those who turn to Him again and again (in true penitence).

# 2055

And render to the kindred their due rights, as (also) to those in want, and to the wayfarer: But squander not (your wealth) in the manner of a spendthrift.

# 2056

Verily spendthrifts are brothers of the Evil Ones; and the Evil One is to his Lord (himself) ungrateful.

# 2057

And even if thou hast to turn away from them in pursuit of the Mercy from thy Lord which thou dost expect, yet speak to them a word of easy kindness.

# 2058

Make not thy hand tied (like a niggard's) to thy neck, nor stretch it forth to its utmost reach, so that thou become blameworthy and destitute.

# 2059

Verily thy Lord doth provide sustenance in abundance for whom He pleaseth, and He provideth in a just measure. For He doth know and regard all His servants.

# 2060

Kill not your children for fear of want: We shall provide sustenance for them as well as for you. Verily the killing of them is a great sin.

# 2061

Nor come nigh to adultery: for it is a shameful (deed) and an evil, opening the road (to other evils).

# 2062

Nor take life - which Allah has made sacred - except for just cause. And if anyone is slain wrongfully, we have given his heir authority (to demand qisas or to forgive): but let him not exceed bounds in the matter of taking life; for he is helped (by the Law).

# 2063

Come not nigh to the orphan's property except to improve it, until he attains the age of full strength; and fulfil (every) engagement, for (every) engagement will be enquired into (on the Day of Reckoning).

# 2064

Give full measure when ye measure, and weigh with a balance that is straight: that is the most fitting and the most advantageous in the final determination.

# 2065

And pursue not that of which thou hast no knowledge; for every act of hearing, or of seeing or of (feeling in) the heart will be enquired into (on the Day of Reckoning).

# 2066

Nor walk on the earth with insolence: for thou canst not rend the earth asunder, nor reach the mountains in height.

# 2067

Of all such things the evil is hateful in the sight of thy Lord.

# 2068

These are among the (precepts of) wisdom, which thy Lord has revealed to thee. Take not, with Allah, another object of worship, lest thou shouldst be thrown into Hell, blameworthy and rejected.

# 2069

Has then your Lord (O Pagans!) preferred for you sons, and taken for Himself daughters among the angels? Truly ye utter a most dreadful saying!

# 2070

We have explained (things) in various (ways) in this Qur'an, in order that they may receive admonition, but it only increases their flight (from the Truth)!

# 2071

Say: If there had been (other) gods with Him, as they say,- behold, they would certainly have sought out a way to the Lord of the Throne!

# 2072

Glory to Him! He is high above all that they say!- Exalted and Great (beyond measure)!

# 2073

The seven heavens and the earth, and all beings therein, declare His glory: there is not a thing but celebrates His praise; And yet ye understand not how they declare His glory! Verily He is Oft-Forbear, Most Forgiving!

# 2074

When thou dost recite the Qur'an, We put, between thee and those who believe not in the Hereafter, a veil invisible:

# 2075

And We put coverings over their hearts (and minds) lest they should understand the Qur'an, and deafness into their ears: when thou dost commemorate thy Lord and Him alone in the Qur'an, they turn on their backs, fleeing (from the Truth).

# 2076

We know best why it is they listen, when they listen to thee; and when they meet in private conference, behold, the wicked say, "Ye follow none other than a man bewitched!"

# 2077

See what similes they strike for thee: but they have gone astray, and never can they find a way.

# 2078

They say: "What! when we are reduced to bones and dust, should we really be raised up (to be) a new creation?"

# 2079

Say: "(Nay!) be ye stones or iron,

# 2080

"Or created matter which, in your minds, is hardest (to be raised up),- (Yet shall ye be raised up)!" then will they say: "Who will cause us to return?" Say: "He who created you first!" Then will they wag their heads towards thee, and say, "When will that be?" Say, "May be it will be quite soon!

# 2081

"It will be on a Day when He will call you, and ye will answer (His call) with (words of) His praise, and ye will think that ye tarried but a little while!"

# 2082

Say to My servants that they should (only) say those things that are best: for Satan doth sow dissensions among them: For Satan is to man an avowed enemy.

# 2083

It is your Lord that knoweth you best: If He please, He granteth you mercy, or if He please, punishment: We have not sent thee to be a disposer of their affairs for them.

# 2084

And it is your Lord that knoweth best all beings that are in the heavens and on earth: We did bestow on some prophets more (and other) gifts than on others: and We gave to David (the gift of) the Psalms.

# 2085

Say: "Call on those - besides Him - whom ye fancy: they have neither the power to remove your troubles from you nor to change them."

# 2086

Those whom they call upon do desire (for themselves) means of access to their Lord, - even those who are nearest: they hope for His Mercy and fear His Wrath: for the Wrath of thy Lord is something to take heed of.

# 2087

There is not a population but We shall destroy it before the Day of Judgment or punish it with a dreadful Penalty: that is written in the (eternal) Record.

# 2088

And We refrain from sending the signs, only because the men of former generations treated them as false: We sent the she-camel to the Thamud to open their eyes, but they treated her wrongfully: We only send the Signs by way of terror (and warning from evil).

# 2089

Behold! We told thee that thy Lord doth encompass mankind round about: We granted the vision which We showed thee, but as a trial for men,- as also the Cursed Tree (mentioned) in the Qur'an: We put terror (and warning) into them, but it only increases their inordinate transgression!

# 2090

Behold! We said to the angels: "Bow down unto Adam": They bowed down except Iblis: He said, "Shall I bow down to one whom Thou didst create from clay?"

# 2091

He said: "Seest Thou? this is the one whom Thou hast honoured above me! If Thou wilt but respite me to the Day of Judgment, I will surely bring his descendants under my sway - all but a few!"

# 2092

(Allah) said: "Go thy way; if any of them follow thee, verily Hell will be the recompense of you (all)- an ample recompense.

# 2093

"Lead to destruction those whom thou canst among them, with thy (seductive) voice; make assaults on them with thy cavalry and thy infantry; mutually share with them wealth and children; and make promises to them." But Satan promises them nothing but deceit.

# 2094

"As for My servants, no authority shalt thou have over them:" Enough is thy Lord for a Disposer of affairs.

# 2095

Your Lord is He That maketh the Ship go smoothly for you through the sea, in order that ye may seek of his Bounty. For he is unto you most Merciful.

# 2096

When distress seizes you at sea, those that ye call upon - besides Himself - leave you in the lurch! but when He brings you back safe to land, ye turn away (from Him). Most ungrateful is man!

# 2097

Do ye then feel secure that He will not cause you to be swallowed up beneath the earth when ye are on land, or that He will not send against you a violent tornado (with showers of stones) so that ye shall find no one to carry out your affairs for you?

# 2098

Or do ye feel secure that He will not send you back a second time to sea and send against you a heavy gale to drown you because of your ingratitude, so that ye find no helper. Therein against Us?

# 2099

We have honoured the sons of Adam; provided them with transport on land and sea; given them for sustenance things good and pure; and conferred on them special favours, above a great part of our creation.

# 2100

One day We shall call together all human beings with their (respective) Imams: those who are given their record in their right hand will read it (with pleasure), and they will not be dealt with unjustly in the least.

# 2101

But those who were blind in this world, will be blind in the hereafter, and most astray from the Path.

# 2102

And their purpose was to tempt thee away from that which We had revealed unto thee, to substitute in our name something quite different; (in that case), behold! they would certainly have made thee (their) friend!

# 2103

And had We not given thee strength, thou wouldst nearly have inclined to them a little.

# 2104

In that case We should have made thee taste an equal portion (of punishment) in this life, and an equal portion in death: and moreover thou wouldst have found none to help thee against Us!

# 2105

Their purpose was to scare thee off the land, in order to expel thee; but in that case they would not have stayed (therein) after thee, except for a little while.

# 2106

(This was Our) way with the messengers We sent before thee: thou wilt find no change in Our ways.

# 2107

Establish regular prayers - at the sun's decline till the darkness of the night, and the morning prayer and reading: for the prayer and reading in the morning carry their testimony.

# 2108

And pray in the small watches of the morning: (it would be) an additional prayer (or spiritual profit) for thee: soon will thy Lord raise thee to a Station of Praise and Glory!

# 2109

Say: "O my Lord! Let my entry be by the Gate of Truth and Honour, and likewise my exit by the Gate of Truth and Honour; and grant me from Thy Presence an authority to aid (me)."

# 2110

And say: "Truth has (now) arrived, and Falsehood perished: for Falsehood is (by its nature) bound to perish."

# 2111

We send down (stage by stage) in the Qur'an that which is a healing and a mercy to those who believe: to the unjust it causes nothing but loss after loss.

# 2112

Yet when We bestow Our favours on man, he turns away and becomes remote on his side (instead of coming to Us), and when evil seizes him he gives himself up to despair!

# 2113

Say: "Everyone acts according to his own disposition: But your Lord knows best who it is that is best guided on the Way."

# 2114

They ask thee concerning the Spirit (of inspiration). Say: "The Spirit (cometh) by command of my Lord: of knowledge it is only a little that is communicated to you, (O men!)"

# 2115

If it were Our Will, We could take away that which We have sent thee by inspiration: then wouldst thou find none to plead thy affair in that matter as against Us,-

# 2116

Except for Mercy from thy Lord: for his bounty is to thee (indeed) great.

# 2117

Say: "If the whole of mankind and Jinns were to gather together to produce the like of this Qur'an, they could not produce the like thereof, even if they backed up each other with help and support.

# 2118

And We have explained to man, in this Qur'an, every kind of similitude: yet the greater part of men refuse (to receive it) except with ingratitude!

# 2119

They say: "We shall not believe in thee, until thou cause a spring to gush forth for us from the earth,

# 2120

"Or (until) thou have a garden of date trees and vines, and cause rivers to gush forth in their midst, carrying abundant water;

# 2121

"Or thou cause the sky to fall in pieces, as thou sayest (will happen), against us; or thou bring Allah and the angels before (us) face to face:

# 2122

"Or thou have a house adorned with gold, or thou mount a ladder right into the skies. No, we shall not even believe in thy mounting until thou send down to us a book that we could read." Say: "Glory to my Lord! Am I aught but a man,- a messenger?"

# 2123

What kept men back from belief when Guidance came to them, was nothing but this: they said, "Has Allah sent a man (like us) to be (His) Messenger?"

# 2124

Say, "If there were settled, on earth, angels walking about in peace and quiet, We should certainly have sent them down from the heavens an angel for a messenger."

# 2125

Say: "Enough is Allah for a witness between me and you: for He is well acquainted with His servants, and He sees (all things).

# 2126

It is he whom Allah guides, that is on true Guidance; but he whom He leaves astray - for such wilt thou find no protector besides Him. On the Day of Judgment We shall gather, them together, prone on their faces, blind, dumb, and deaf: their abode will be Hell: every time it shows abatement, We shall increase from them the fierceness of the Fire.

# 2127

That is their recompense, because they rejected Our signs, and said, "When we are reduced to bones and broken dust, should we really be raised up (to be) a new Creation?"

# 2128

See they not that Allah, Who created the heavens and the earth, has power to create the like of them (anew)? Only He has decreed a term appointed, of which there is no doubt. But the unjust refuse (to receive it) except with ingratitude.

# 2129

Say: "If ye had control of the Treasures of the Mercy of my Lord, behold, ye would keep them back, for fear of spending them: for man is (every) niggardly!"

# 2130

To Moses We did give Nine Clear Signs: As the Children of Israel: when he came to them, Pharaoh said to him: "O Moses! I consider thee, indeed, to have been worked upon by sorcery!

# 2131

Moses said, "Thou knowest well that these things have been sent down by none but the Lord of the heavens and the earth as eye-opening evidence: and I consider thee indeed, O Pharaoh, to be one doomed to destruction!"

# 2132

So he resolved to remove them from the face of the earth: but We did drown him and all who were with him.

# 2133

And We said thereafter to the Children of Israel, "Dwell securely in the land (of promise)": but when the second of the warnings came to pass, We gathered you together in a mingled crowd.

# 2134

We sent down the (Qur'an) in Truth, and in Truth has it descended: and We sent thee but to give Glad Tidings and to warn (sinners).

# 2135

(It is) a Qur'an which We have divided (into parts from time to time), in order that thou mightest recite it to men at intervals: We have revealed it by stages.

# 2136

Say: "Whether ye believe in it or not, it is true that those who were given knowledge beforehand, when it is recited to them, fall down on their faces in humble prostration,

# 2137

"And they say: 'Glory to our Lord! Truly has the promise of our Lord been fulfilled!'"

# 2138

They fall down on their faces in tears, and it increases their (earnest) humility.

# 2139

Say: "Call upon Allah, or call upon Rahman: by whatever name ye call upon Him, (it is well): for to Him belong the Most Beautiful Names. Neither speak thy Prayer aloud, nor speak it in a low tone, but seek a middle course between."

# 2140

Say: "Praise be to Allah, who begets no son, and has no partner in (His) dominion: Nor (needs) He any to protect Him from humiliation: yea, magnify Him for His greatness and glory!"

# 2141

Praise be to Allah, Who hath sent to His Servant the Book, and hath allowed therein no Crookedness:

# 2142

(He hath made it) Straight (and Clear) in order that He may warn (the godless) of a terrible Punishment from Him, and that He may give Glad Tidings to the Believers who work righteous deeds, that they shall have a goodly Reward,

# 2143

Wherein they shall remain for ever:

# 2144

Further, that He may warn those (also) who say, "Allah hath begotten a son":

# 2145

No knowledge have they of such a thing, nor had their fathers. It is a grievous thing that issues from their mouths as a saying what they say is nothing but falsehood!

# 2146

Thou wouldst only, perchance, fret thyself to death, following after them, in grief, if they believe not in this Message.

# 2147

That which is on earth we have made but as a glittering show for the earth, in order that We may test them - as to which of them are best in conduct.

# 2148

Verily what is on earth we shall make but as dust and dry soil (without growth or herbage).

# 2149

Or dost thou reflect that the Companions of the Cave and of the Inscription were wonders among Our Sign?

# 2150

Behold, the youths betook themselves to the Cave: they said, "Our Lord! bestow on us Mercy from Thyself, and dispose of our affair for us in the right way!"

# 2151

Then We draw (a veil) over their ears, for a number of years, in the Cave, (so that they heard not):

# 2152

Then We roused them, in order to test which of the two parties was best at calculating the term of years they had tarried!

# 2153

We relate to thee their story in truth: they were youths who believed in their Lord, and We advanced them in guidance:

# 2154

We gave strength to their hearts: Behold, they stood up and said: "Our Lord is the Lord of the heavens and of the earth: never shall we call upon any god other than Him: if we did, we should indeed have uttered an enormity!

# 2155

"These our people have taken for worship gods other than Him: why do they not bring forward an authority clear (and convincing) for what they do? Who doth more wrong than such as invent a falsehood against Allah?

# 2156

"When ye turn away from them and the things they worship other than Allah, betake yourselves to the Cave: Your Lord will shower His mercies on you and disposes of your affair towards comfort and ease."

# 2157

Thou wouldst have seen the sun, when it rose, declining to the right from their Cave, and when it set, turning away from them to the left, while they lay in the open space in the midst of the Cave. Such are among the Signs of Allah: He whom Allah, guides is rightly guided; but he whom Allah leaves to stray,- for him wilt thou find no protector to lead him to the Right Way.

# 2158

Thou wouldst have deemed them awake, whilst they were asleep, and We turned them on their right and on their left sides: their dog stretching forth his two fore-legs on the threshold: if thou hadst come up on to them, thou wouldst have certainly turned back from them in flight, and wouldst certainly have been filled with terror of them.

# 2159

Such (being their state), we raised them up (from sleep), that they might question each other. Said one of them, "How long have ye stayed (here)?" They said, "We have stayed (perhaps) a day, or part of a day." (At length) they (all) said, "Allah (alone) knows best how long ye have stayed here.... Now send ye then one of you with this money of yours to the town: let him find out which is the best food (to be had) and bring some to you, that (ye may) satisfy your hunger therewith: And let him behave with care and courtesy, and let him not inform any one about you.

# 2160

"For if they should come upon you, they would stone you or force you to return to their cult, and in that case ye would never attain prosperity."

# 2161

Thus did We make their case known to the people, that they might know that the promise of Allah is true, and that there can be no doubt about the Hour of Judgment. Behold, they dispute among themselves as to their affair. (Some) said, "Construct a building over them": Their Lord knows best about them: those who prevailed over their affair said, "Let us surely build a place of worship over them."

# 2162

(Some) say they were three, the dog being the fourth among them; (others) say they were five, the dog being the sixth,- doubtfully guessing at the unknown; (yet others) say they were seven, the dog being the eighth. Say thou: "My Lord knoweth best their number; It is but few that know their (real case)." Enter not, therefore, into controversies concerning them, except on a matter that is clear, nor consult any of them about (the affair of) the Sleepers.

# 2163

Nor say of anything, "I shall be sure to do so and so tomorrow"-

# 2164

Without adding, "So please Allah!" and call thy Lord to mind when thou forgettest, and say, "I hope that my Lord will guide me ever closer (even) than this to the right road."

# 2165

So they stayed in their Cave three hundred years, and (some) add nine (more)

# 2166

Say: "Allah knows best how long they stayed: with Him is (the knowledge of) the secrets of the heavens and the earth: how clearly He sees, how finely He hears (everything)! They have no protector other than Him; nor does He share His Command with any person whatsoever.

# 2167

And recite (and teach) what has been revealed to thee of the Book of thy Lord: none can change His Words, and none wilt thou find as a refuge other than Him.

# 2168

And keep thy soul content with those who call on their Lord morning and evening, seeking His Face; and let not thine eyes pass beyond them, seeking the pomp and glitter of this Life; no obey any whose heart We have permitted to neglect the remembrance of Us, one who follows his own desires, whose case has gone beyond all bounds.

# 2169

Say, "The truth is from your Lord": Let him who will believe, and let him who will, reject (it): for the wrong-doers We have prepared a Fire whose (smoke and flames), like the walls and roof of a tent, will hem them in: if they implore relief they will be granted water like melted brass, that will scald their faces, how dreadful the drink! How uncomfortable a couch to recline on!

# 2170

As to those who believe and work righteousness, verily We shall not suffer to perish the reward of any who do a (single) righteous deed.

# 2171

For them will be Gardens of Eternity; beneath them rivers will flow; they will be adorned therein with bracelets of gold, and they will wear green garments of fine silk and heavy brocade: They will recline therein on raised thrones. How good the recompense! How beautiful a couch to recline on!

# 2172

Set forth to them the parable of two men: for one of them We provided two gardens of grape-vines and surrounded them with date palms; in between the two We placed corn-fields.

# 2173

Each of those gardens brought forth its produce, and failed not in the least therein: in the midst of them We caused a river to flow.

# 2174

(Abundant) was the produce this man had: he said to his companion, in the course of a mutual argument: "more wealth have I than you, and more honour and power in (my following of) men."

# 2175

He went into his garden in a state (of mind) unjust to his soul: He said, "I deem not that this will ever perish,

# 2176

"Nor do I deem that the Hour (of Judgment) will (ever) come: Even if I am brought back to my Lord, I shall surely find (there) something better in exchange."

# 2177

His companion said to him, in the course of the argument with him: "Dost thou deny Him Who created thee out of dust, then out of a sperm-drop, then fashioned thee into a man?

# 2178

"But (I think) for my part that He is Allah, My Lord, and none shall I associate with my Lord.

# 2179

"Why didst thou not, as thou wentest into thy garden, say: 'Allah's will (be done)! There is no power but with Allah!' If thou dost see me less than thee in wealth and sons,

# 2180

"It may be that my Lord will give me something better than thy garden, and that He will send on thy garden thunderbolts (by way of reckoning) from heaven, making it (but) slippery sand!-

# 2181

"Or the water of the garden will run off underground so that thou wilt never be able to find it."

# 2182

So his fruits (and enjoyment) were encompassed (with ruin), and he remained twisting and turning his hands over what he had spent on his property, which had (now) tumbled to pieces to its very foundations, and he could only say, "Woe is me! Would I had never ascribed partners to my Lord and Cherisher!"

# 2183

Nor had he numbers to help him against Allah, nor was he able to deliver himself.

# 2184

There, the (only) protection comes from Allah, the True One. He is the Best to reward, and the Best to give success.

# 2185

Set forth to them the similitude of the life of this world: It is like the rain which we send down from the skies: the earth's vegetation absorbs it, but soon it becomes dry stubble, which the winds do scatter: it is (only) Allah who prevails over all things.

# 2186

Wealth and sons are allurements of the life of this world: But the things that endure, good deeds, are best in the sight of thy Lord, as rewards, and best as (the foundation for) hopes.

# 2187

One Day We shall remove the mountains, and thou wilt see the earth as a level stretch, and We shall gather them, all together, nor shall We leave out any one of them.

# 2188

And they will be marshalled before thy Lord in ranks, (with the announcement), "Now have ye come to Us (bare) as We created you first: aye, ye thought We shall not fulfil the appointment made to you to meet (Us)!":

# 2189

And the Book (of Deeds) will be placed (before you); and thou wilt see the sinful in great terror because of what is (recorded) therein; they will say, "Ah! woe to us! what a Book is this! It leaves out nothing small or great, but takes account thereof!" They will find all that they did, placed before them: And not one will thy Lord treat with injustice.

# 2190

Behold! We said to the angels, "Bow down to Adam": They bowed down except Iblis. He was one of the Jinns, and he broke the Command of his Lord. Will ye then take him and his progeny as protectors rather than Me? And they are enemies to you! Evil would be the exchange for the wrong-doers!

# 2191

I called them not to witness the creation of the heavens and the earth, nor (even) their own creation: nor is it for helpers such as Me to take as lead (men) astray!

# 2192

One Day He will say, "Call on those whom ye thought to be My partners," and they will call on them, but they will not listen to them; and We shall make for them a place of common perdition.

# 2193

And the Sinful shall see the fire and apprehend that they have to fall therein: no means will they find to turn away therefrom.

# 2194

We have explained in detail in this Qur'an, for the benefit of mankind, every kind of similitude: but man is, in most things, contentious.

# 2195

And what is there to keep back men from believing, now that Guidance has come to them, nor from praying for forgiveness from their Lord, but that (they ask that) the ways of the ancients be repeated with them, or the Wrath be brought to them face to face?

# 2196

We only send the messengers to give Glad Tidings and to give warnings: But the unbelievers dispute with vain argument, in order therewith to weaken the truth, and they treat My Signs as a jest, as also the fact that they are warned!

# 2197

And who doth more wrong than one who is reminded of the Signs of his Lord, but turns away from them, forgetting the (deeds) which his hands have sent forth? Verily We have set veils over their hearts lest they should understand this, and over their ears, deafness, if thou callest them to guidance, even then will they never accept guidance.

# 2198

But your Lord is Most forgiving, full of Mercy. If He were to call them (at once) to account for what they have earned, then surely He would have hastened their punishment: but they have their appointed time, beyond which they will find no refuge.

# 2199

Such were the populations we destroyed when they committed iniquities; but we fixed an appointed time for their destruction.

# 2200

Behold, Moses said to his attendant, "I will not give up until I reach the junction of the two seas or (until) I spend years and years in travel."

# 2201

But when they reached the Junction, they forgot (about) their Fish, which took its course through the sea (straight) as in a tunnel.

# 2202

When they had passed on (some distance), Moses said to his attendant: "Bring us our early meal; truly we have suffered much fatigue at this (stage of) our journey."

# 2203

He replied: "Sawest thou (what happened) when we betook ourselves to the rock? I did indeed forget (about) the Fish: none but Satan made me forget to tell (you) about it: it took its course through the sea in a marvellous way!"

# 2204

Moses said: "That was what we were seeking after:" So they went back on their footsteps, following (the path they had come).

# 2205

So they found one of Our servants, on whom We had bestowed Mercy from Ourselves and whom We had taught knowledge from Our own Presence.

# 2206

Moses said to him: "May I follow thee, on the footing that thou teach me something of the (Higher) Truth which thou hast been taught?"

# 2207

(The other) said: "Verily thou wilt not be able to have patience with me!"

# 2208

"And how canst thou have patience about things about which thy understanding is not complete?"

# 2209

Moses said: "Thou wilt find me, if Allah so will, (truly) patient: nor shall I disobey thee in aught."

# 2210

The other said: "If then thou wouldst follow me, ask me no questions about anything until I myself speak to thee concerning it."

# 2211

So they both proceeded: until, when they were in the boat, he scuttled it. Said Moses: "Hast thou scuttled it in order to drown those in it? Truly a strange thing hast thou done!"

# 2212

He answered: "Did I not tell thee that thou canst have no patience with me?"

# 2213

Moses said: "Rebuke me not for forgetting, nor grieve me by raising difficulties in my case."

# 2214

Then they proceeded: until, when they met a young man, he slew him. Moses said: "Hast thou slain an innocent person who had slain none? Truly a foul (unheard of) thing hast thou done!"

# 2215

He answered: "Did I not tell thee that thou canst have no patience with me?"

# 2216

(Moses) said: "If ever I ask thee about anything after this, keep me not in thy company: then wouldst thou have received (full) excuse from my side."

# 2217

Then they proceeded: until, when they came to the inhabitants of a town, they asked them for food, but they refused them hospitality. They found there a wall on the point of falling down, but he set it up straight. (Moses) said: "If thou hadst wished, surely thou couldst have exacted some recompense for it!"

# 2218

He answered: "This is the parting between me and thee: now will I tell thee the interpretation of (those things) over which thou wast unable to hold patience.

# 2219

"As for the boat, it belonged to certain men in dire want: they plied on the water: I but wished to render it unserviceable, for there was after them a certain king who seized on every boat by force.

# 2220

"As for the youth, his parents were people of Faith, and we feared that he would grieve them by obstinate rebellion and ingratitude (to Allah and man).

# 2221

"So we desired that their Lord would give them in exchange (a son) better in purity (of conduct) and closer in affection.

# 2222

"As for the wall, it belonged to two youths, orphans, in the Town; there was, beneath it, a buried treasure, to which they were entitled: their father had been a righteous man: So thy Lord desired that they should attain their age of full strength and get out their treasure - a mercy (and favour) from thy Lord. I did it not of my own accord. Such is the interpretation of (those things) over which thou wast unable to hold patience."

# 2223

They ask thee concerning Zul-qarnain. Say, "I will rehearse to you something of his story."

# 2224

Verily We established his power on earth, and We gave him the ways and the means to all ends.

# 2225

One (such) way he followed,

# 2226

Until, when he reached the setting of the sun, he found it set in a spring of murky water: Near it he found a People: We said: "O Zul-qarnain! (thou hast authority,) either to punish them, or to treat them with kindness."

# 2227

He said: "Whoever doth wrong, him shall we punish; then shall he be sent back to his Lord; and He will punish him with a punishment unheard-of (before).

# 2228

"But whoever believes, and works righteousness,- he shall have a goodly reward, and easy will be his task as We order it by our Command."

# 2229

Then followed he (another) way,

# 2230

Until, when he came to the rising of the sun, he found it rising on a people for whom We had provided no covering protection against the sun.

# 2231

(He left them) as they were: We completely understood what was before him.

# 2232

Then followed he (another) way,

# 2233

Until, when he reached (a tract) between two mountains, he found, beneath them, a people who scarcely understood a word.

# 2234

They said: "O Zul-qarnain! the Gog and Magog (People) do great mischief on earth: shall we then render thee tribute in order that thou mightest erect a barrier between us and them?

# 2235

He said: "(The power) in which my Lord has established me is better (than tribute): Help me therefore with strength (and labour): I will erect a strong barrier between you and them:

# 2236

"Bring me blocks of iron." At length, when he had filled up the space between the two steep mountain-sides, He said, "Blow (with your bellows)" Then, when he had made it (red) as fire, he said: "Bring me, that I may pour over it, molten lead."

# 2237

Thus were they made powerless to scale it or to dig through it.

# 2238

He said: "This is a mercy from my Lord: But when the promise of my Lord comes to pass, He will make it into dust; and the promise of my Lord is true."

# 2239

On that day We shall leave them to surge like waves on one another: the trumpet will be blown, and We shall collect them all together.

# 2240

And We shall present Hell that day for Unbelievers to see, all spread out,-

# 2241

(Unbelievers) whose eyes had been under a veil from remembrance of Me, and who had been unable even to hear.

# 2242

Do the Unbelievers think that they can take My servants as protectors besides Me? Verily We have prepared Hell for the Unbelievers for (their) entertainment.

# 2243

Say: "Shall we tell you of those who lose most in respect of their deeds?-

# 2244

"Those whose efforts have been wasted in this life, while they thought that they were acquiring good by their works?"

# 2245

They are those who deny the Signs of their Lord and the fact of their having to meet Him (in the Hereafter): vain will be their works, nor shall We, on the Day of Judgment, give them any weight.

# 2246

That is their reward, Hell, because they rejected Faith, and took My Signs and My Messengers by way of jest.

# 2247

As to those who believe and work righteous deeds, they have, for their entertainment, the Gardens of Paradise,

# 2248

Wherein they shall dwell (for aye): no change will they wish for from them.

# 2249

Say: "If the ocean were ink (wherewith to write out) the words of my Lord, sooner would the ocean be exhausted than would the words of my Lord, even if we added another ocean like it, for its aid."

# 2250

Say: "I am but a man like yourselves, (but) the inspiration has come to me, that your Allah is one Allah: whoever expects to meet his Lord, let him work righteousness, and, in the worship of his Lord, admit no one as partner.

# 2251

Kaf. Ha. Ya. 'Ain. Sad.

# 2252

(This is) a recital of the Mercy of thy Lord to His servant Zakariya.

# 2253

Behold! he cried to his Lord in secret,

# 2254

Praying: "O my Lord! infirm indeed are my bones, and the hair of my head doth glisten with grey: but never am I unblest, O my Lord, in my prayer to Thee!

# 2255

"Now I fear (what) my relatives (and colleagues) (will do) after me: but my wife is barren: so give me an heir as from Thyself,-

# 2256

"(One that) will (truly) represent me, and represent the posterity of Jacob; and make him, O my Lord! one with whom Thou art well-pleased!"

# 2257

(His prayer was answered): "O Zakariya! We give thee good news of a son: His name shall be Yahya: on none by that name have We conferred distinction before."

# 2258

He said: "O my Lord! How shall I have a son, when my wife is barren and I have grown quite decrepit from old age?"

# 2259

He said: "So (it will be) thy Lord saith, 'that is easy for Me: I did indeed create thee before, when thou hadst been nothing!'"

# 2260

(Zakariya) said: "O my Lord! give me a Sign." "Thy Sign," was the answer, "Shall be that thou shalt speak to no man for three nights, although thou art not dumb."

# 2261

So Zakariya came out to his people from him chamber: He told them by signs to celebrate Allah's praises in the morning and in the evening.

# 2262

(To his son came the command): "O Yahya! take hold of the Book with might": and We gave him Wisdom even as a youth,

# 2263

And piety (for all creatures) as from Us, and purity: He was devout,

# 2264

And kind to his parents, and he was not overbearing or rebellious.

# 2265

So Peace on him the day he was born, the day that he dies, and the day that he will be raised up to life (again)!

# 2266

Relate in the Book (the story of) Mary, when she withdrew from her family to a place in the East.

# 2267

She placed a screen (to screen herself) from them; then We sent her our angel, and he appeared before her as a man in all respects.

# 2268

She said: "I seek refuge from thee to (Allah) Most Gracious: (come not near) if thou dost fear Allah."

# 2269

He said: "Nay, I am only a messenger from thy Lord, (to announce) to thee the gift of a holy son.

# 2270

She said: "How shall I have a son, seeing that no man has touched me, and I am not unchaste?"

# 2271

He said: "So (it will be): Thy Lord saith, 'that is easy for Me: and (We wish) to appoint him as a Sign unto men and a Mercy from Us': It is a matter (so) decreed."

# 2272

So she conceived him, and she retired with him to a remote place.

# 2273

And the pains of childbirth drove her to the trunk of a palm-tree: She cried (in her anguish): "Ah! would that I had died before this! would that I had been a thing forgotten and out of sight!"

# 2274

But (a voice) cried to her from beneath the (palm-tree): "Grieve not! for thy Lord hath provided a rivulet beneath thee;

# 2275

"And shake towards thyself the trunk of the palm-tree: It will let fall fresh ripe dates upon thee.

# 2276

"So eat and drink and cool (thine) eye. And if thou dost see any man, say, 'I have vowed a fast to (Allah) Most Gracious, and this day will I enter into not talk with any human being'"

# 2277

At length she brought the (babe) to her people, carrying him (in her arms). They said: "O Mary! truly an amazing thing hast thou brought!

# 2278

"O sister of Aaron! Thy father was not a man of evil, nor thy mother a woman unchaste!"

# 2279

But she pointed to the babe. They said: "How can we talk to one who is a child in the cradle?"

# 2280

He said: "I am indeed a servant of Allah: He hath given me revelation and made me a prophet;

# 2281

"And He hath made me blessed wheresoever I be, and hath enjoined on me Prayer and Charity as long as I live;

# 2282

"(He) hath made me kind to my mother, and not overbearing or miserable;

# 2283

"So peace is on me the day I was born, the day that I die, and the day that I shall be raised up to life (again)"!

# 2284

Such (was) Jesus the son of Mary: (it is) a statement of truth, about which they (vainly) dispute.

# 2285

It is not befitting to (the majesty of) Allah that He should beget a son. Glory be to Him! when He determines a matter, He only says to it, "Be", and it is.

# 2286

Verily Allah is my Lord and your Lord: Him therefore serve ye: this is a Way that is straight.

# 2287

But the sects differ among themselves: and woe to the unbelievers because of the (coming) Judgment of a Momentous Day!

# 2288

How plainly will they see and hear, the Day that they will appear before Us! but the unjust today are in error manifest!

# 2289

But warn them of the Day of Distress, when the matter will be determined: for (behold,) they are negligent and they do not believe!

# 2290

It is We Who will inherit the earth, and all beings thereon: to Us will they all be returned.

# 2291

(Also mention in the Book (the story of) Abraham: He was a man of Truth, a prophet.

# 2292

Behold, he said to his father: "O my father! why worship that which heareth not and seeth not, and can profit thee nothing?

# 2293

"O my father! to me hath come knowledge which hath not reached thee: so follow me: I will guide thee to a way that is even and straight.

# 2294

"O my father! serve not Satan: for Satan is a rebel against (Allah) Most Gracious.

# 2295

"O my father! I fear lest a Penalty afflict thee from (Allah) Most Gracious, so that thou become to Satan a friend."

# 2296

(The father) replied: "Dost thou hate my gods, O Abraham? If thou forbear not, I will indeed stone thee: Now get away from me for a good long while!"

# 2297

Abraham said: "Peace be on thee: I will pray to my Lord for thy forgiveness: for He is to me Most Gracious.

# 2298

"And I will turn away from you (all) and from those whom ye invoke besides Allah: I will call on my Lord: perhaps, by my prayer to my Lord, I shall be not unblest."

# 2299

When he had turned away from them and from those whom they worshipped besides Allah, We bestowed on him Isaac and Jacob, and each one of them We made a prophet.

# 2300

And We bestowed of Our Mercy on them, and We granted them lofty honour on the tongue of truth.

# 2301

Also mention in the Book (the story of) Moses: for he was specially chosen, and he was a messenger (and) a prophet.

# 2302

And we called him from the right side of Mount (Sinai), and made him draw near to Us, for mystic (converse).

# 2303

And, out of Our Mercy, We gave him his brother Aaron, (also) a prophet.

# 2304

Also mention in the Book (the story of) Isma'il: He was (strictly) true to what he promised, and he was a messenger (and) a prophet.

# 2305

He used to enjoin on his people Prayer and Charity, and he was most acceptable in the sight of his Lord.

# 2306

Also mention in the Book the case of Idris: He was a man of truth (and sincerity), (and) a prophet:

# 2307

And We raised him to a lofty station.

# 2308

Those were some of the prophets on whom Allah did bestow His Grace,- of the posterity of Adam, and of those who We carried (in the Ark) with Noah, and of the posterity of Abraham and Israel of those whom We guided and chose. Whenever the Signs of (Allah) Most Gracious were rehearsed to them, they would fall down in prostrate adoration and in tears.

# 2309

But after them there followed a posterity who missed prayers and followed after lusts soon, then, will they face Destruction,-

# 2310

Except those who repent and believe, and work righteousness: for these will enter the Garden and will not be wronged in the least,-

# 2311

Gardens of Eternity, those which (Allah) Most Gracious has promised to His servants in the Unseen: for His promise must (necessarily) come to pass.

# 2312

They will not there hear any vain discourse, but only salutations of Peace: And they will have therein their sustenance, morning and evening.

# 2313

Such is the Garden which We give as an inheritance to those of Our servants who guard against Evil.

# 2314

(The angels say:) "We descend not but by command of thy Lord: to Him belongeth what is before us and what is behind us, and what is between: and thy Lord never doth forget,-

# 2315

"Lord of the heavens and of the earth, and of all that is between them; so worship Him, and be constant and patient in His worship: knowest thou of any who is worthy of the same Name as He?"

# 2316

Man says: "What! When I am dead, shall I then be raised up alive?"

# 2317

But does not man call to mind that We created him before out of nothing?

# 2318

So, by thy Lord, without doubt, We shall gather them together, and (also) the Evil Ones (with them); then shall We bring them forth on their knees round about Hell;

# 2319

Then shall We certainly drag out from every sect all those who were worst in obstinate rebellion against (Allah) Most Gracious.

# 2320

And certainly We know best those who are most worthy of being burned therein.

# 2321

Not one of you but will pass over it: this is, with thy Lord, a Decree which must be accomplished.

# 2322

But We shall save those who guarded against evil, and We shall leave the wrong-doers therein, (humbled) to their knees.

# 2323

When Our Clear Signs are rehearsed to them, the Unbelievers say to those who believe, "Which of the two sides is best in point of position? Which makes the best show in council?"

# 2324

But how many (countless) generations before them have we destroyed, who were even better in equipment and in glitter to the eye?

# 2325

Say: "If any men go astray, (Allah) Most Gracious extends (the rope) to them, until, when they see the warning of Allah (being fulfilled) - either in punishment or in (the approach of) the Hour,- they will at length realise who is worst in position, and (who) weakest in forces!

# 2326

"And Allah doth advance in guidance those who seek guidance: and the things that endure, Good Deeds, are best in the sight of thy Lord, as rewards, and best in respect of (their) eventual return."

# 2327

Hast thou then seen the (sort of) man who rejects Our Signs, yet says: "I shall certainly be given wealth and children?"

# 2328

Has he penetrated to the Unseen, or has he taken a contract with (Allah) Most Gracious?

# 2329

Nay! We shall record what he says, and We shall add and add to his punishment.

# 2330

To Us shall return all that he talks of and he shall appear before Us bare and alone.

# 2331

And they have taken (for worship) gods other than Allah, to give them power and glory!

# 2332

Instead, they shall reject their worship, and become adversaries against them.

# 2333

Seest thou not that We have set the Evil Ones on against the unbelievers, to incite them with fury?

# 2334

So make no haste against them, for We but count out to them a (limited) number (of days).

# 2335

The day We shall gather the righteous to (Allah) Most Gracious, like a band presented before a king for honours,

# 2336

And We shall drive the sinners to Hell, like thirsty cattle driven down to water,-

# 2337

None shall have the power of intercession, but such a one as has received permission (or promise) from (Allah) Most Gracious.

# 2338

They say: "(Allah) Most Gracious has begotten a son!"

# 2339

Indeed ye have put forth a thing most monstrous!

# 2340

At it the skies are ready to burst, the earth to split asunder, and the mountains to fall down in utter ruin,

# 2341

That they should invoke a son for (Allah) Most Gracious.

# 2342

For it is not consonant with the majesty of (Allah) Most Gracious that He should beget a son.

# 2343

Not one of the beings in the heavens and the earth but must come to (Allah) Most Gracious as a servant.

# 2344

He does take an account of them (all), and hath numbered them (all) exactly.

# 2345

And everyone of them will come to Him singly on the Day of Judgment.

# 2346

On those who believe and work deeds of righteousness, will (Allah) Most Gracious bestow love.

# 2347

So have We made the (Qur'an) easy in thine own tongue, that with it thou mayest give Glad Tidings to the righteous, and warnings to people given to contention.

# 2348

But how many (countless) generations before them have We destroyed? Canst thou find a single one of them (now) or hear (so much as) a whisper of them?

# 2349

Ta-Ha.

# 2350

We have not sent down the Qur'an to thee to be (an occasion) for thy distress,

# 2351

But only as an admonition to those who fear (Allah),-

# 2352

A revelation from Him Who created the earth and the heavens on high.

# 2353

(Allah) Most Gracious is firmly established on the throne (of authority).

# 2354

To Him belongs what is in the heavens and on earth, and all between them, and all beneath the soil.

# 2355

If thou pronounce the word aloud, (it is no matter): for verily He knoweth what is secret and what is yet more hidden.

# 2356

Allah! there is no god but He! To Him belong the most Beautiful Names.

# 2357

Has the story of Moses reached thee?

# 2358

Behold, he saw a fire: So he said to his family, "Tarry ye; I perceive a fire; perhaps I can bring you some burning brand therefrom, or find some guidance at the fire."

# 2359

But when he came to the fire, a voice was heard: "O Moses!

# 2360

"Verily I am thy Lord! therefore (in My presence) put off thy shoes: thou art in the sacred valley Tuwa.

# 2361

"I have chosen thee: listen, then, to the inspiration (sent to thee).

# 2362

"Verily, I am Allah: There is no god but I: So serve thou Me (only), and establish regular prayer for celebrating My praise.

# 2363

"Verily the Hour is coming - My design is to keep it hidden - for every soul to receive its reward by the measure of its Endeavour.

# 2364

"Therefore let not such as believe not therein but follow their own lusts, divert thee therefrom, lest thou perish!"..

# 2365

"And what is that in the right hand, O Moses?"

# 2366

He said, "It is my rod: on it I lean; with it I beat down fodder for my flocks; and in it I find other uses."

# 2367

(Allah) said, "Throw it, O Moses!"

# 2368

He threw it, and behold! It was a snake, active in motion.

# 2369

(Allah) said, "Seize it, and fear not: We shall return it at once to its former condition"..

# 2370

"Now draw thy hand close to thy side: It shall come forth white (and shining), without harm (or stain),- as another Sign,-

# 2371

"In order that We may show thee (two) of our Greater Signs.

# 2372

"Go thou to Pharaoh, for he has indeed transgressed all bounds."

# 2373

(Moses) said: "O my Lord! expand me my breast;

# 2374

"Ease my task for me;

# 2375

"And remove the impediment from my speech,

# 2376

"So they may understand what I say:

# 2377

"And give me a Minister from my family,

# 2378

"Aaron, my brother;

# 2379

"Add to my strength through him,

# 2380

"And make him share my task:

# 2381

"That we may celebrate Thy praise without stint,

# 2382

"And remember Thee without stint:

# 2383

"For Thou art He that (ever) regardeth us."

# 2384

(Allah) said: "Granted is thy prayer, O Moses!"

# 2385

"And indeed We conferred a favour on thee another time (before).

# 2386

"Behold! We sent to thy mother, by inspiration, the message:

# 2387

"'Throw (the child) into the chest, and throw (the chest) into the river: the river will cast him up on the bank, and he will be taken up by one who is an enemy to Me and an enemy to him': But I cast (the garment of) love over thee from Me: and (this) in order that thou mayest be reared under Mine eye.

# 2388

"Behold! thy sister goeth forth and saith, 'shall I show you one who will nurse and rear the (child)?' So We brought thee back to thy mother, that her eye might be cooled and she should not grieve. Then thou didst slay a man, but We saved thee from trouble, and We tried thee in various ways. Then didst thou tarry a number of years with the people of Midian. Then didst thou come hither as ordained, O Moses!

# 2389

"And I have prepared thee for Myself (for service)"..

# 2390

"Go, thou and thy brother, with My Signs, and slacken not, either of you, in keeping Me in remembrance.

# 2391

"Go, both of you, to Pharaoh, for he has indeed transgressed all bounds;

# 2392

"But speak to him mildly; perchance he may take warning or fear (Allah)."

# 2393

They (Moses and Aaron) said: "Our Lord! We fear lest he hasten with insolence against us, or lest he transgress all bounds."

# 2394

He said: "Fear not: for I am with you: I hear and see (everything).

# 2395

"So go ye both to him, and say, 'Verily we are messengers sent by thy Lord: Send forth, therefore, the Children of Israel with us, and afflict them not: with a Sign, indeed, have we come from thy Lord! and peace to all who follow guidance!

# 2396

"'Verily it has been revealed to us that the Penalty (awaits) those who reject and turn away.'"

# 2397

(When this message was delivered), (Pharaoh) said: "Who, then, O Moses, is the Lord of you two?"

# 2398

He said: "Our Lord is He Who gave to each (created) thing its form and nature, and further, gave (it) guidance."

# 2399

(Pharaoh) said: "What then is the condition of previous generations?"

# 2400

He replied: "The knowledge of that is with my Lord, duly recorded: my Lord never errs, nor forgets,-

# 2401

"He Who has, made for you the earth like a carpet spread out; has enabled you to go about therein by roads (and channels); and has sent down water from the sky." With it have We produced diverse pairs of plants each separate from the others.

# 2402

Eat (for yourselves) and pasture your cattle: verily, in this are Signs for men endued with understanding.

# 2403

From the (earth) did We create you, and into it shall We return you, and from it shall We bring you out once again.

# 2404

And We showed Pharaoh all Our Signs, but he did reject and refuse.

# 2405

He said: "Hast thou come to drive us out of our land with thy magic, O Moses?

# 2406

"But we can surely produce magic to match thine! So make a tryst between us and thee, which we shall not fail to keep - neither we nor thou - in a place where both shall have even chances."

# 2407

Moses said: "Your tryst is the Day of the Festival, and let the people be assembled when the sun is well up."

# 2408

So Pharaoh withdrew: He concerted his plan, and then came (back).

# 2409

Moses said to him: Woe to you! Forge not ye a lie against Allah, lest He destroy you (at once) utterly by chastisement: the forger must suffer frustration!"

# 2410

So they disputed, one with another, over their affair, but they kept their talk secret.

# 2411

They said: "These two are certainly (expert) magicians: their object is to drive you out from your land with their magic, and to do away with your most cherished institutions.

# 2412

"Therefore concert your plan, and then assemble in (serried) ranks: He wins (all along) today who gains the upper hand."

# 2413

They said: "O Moses! whether wilt thou that thou throw (first) or that we be the first to throw?"

# 2414

He said, "Nay, throw ye first!" Then behold their ropes and their rods-so it seemed to him on account of their magic - began to be in lively motion!

# 2415

So Moses conceived in his mind a (sort of) fear.

# 2416

We said: "Fear not! for thou hast indeed the upper hand:

# 2417

"Throw that which is in thy right hand: Quickly will it swallow up that which they have faked what they have faked is but a magician's trick: and the magician thrives not, (no matter) where he goes."

# 2418

So the magicians were thrown down to prostration: they said, "We believe in the Lord of Aaron and Moses".

# 2419

(Pharaoh) said: "Believe ye in Him before I give you permission? Surely this must be your leader, who has taught you magic! be sure I will cut off your hands and feet on opposite sides, and I will have you crucified on trunks of palm-trees: so shall ye know for certain, which of us can give the more severe and the more lasting punishment!"

# 2420

They said: "Never shall we regard thee as more than the Clear Signs that have come to us, or than Him Who created us! so decree whatever thou desirest to decree: for thou canst only decree (touching) the life of this world.

# 2421

"For us, we have believed in our Lord: may He forgive us our faults, and the magic to which thou didst compel us: for Allah is Best and Most Abiding."

# 2422

Verily he who comes to his Lord as a sinner (at Judgment),- for him is Hell: therein shall he neither die nor live.

# 2423

But such as come to Him as Believers who have worked righteous deeds,- for them are ranks exalted,-

# 2424

Gardens of Eternity, beneath which flow rivers: they will dwell therein for aye: such is the reward of those who purify themselves (from evil).

# 2425

We sent an inspiration to Moses: "Travel by night with My servants, and strike a dry path for them through the sea, without fear of being overtaken (by Pharaoh) and without (any other) fear."

# 2426

Then Pharaoh pursued them with his forces, but the waters completely overwhelmed them and covered them up.

# 2427

Pharaoh led his people astray instead of leading them aright.

# 2428

O ye Children of Israel! We delivered you from your enemy, and We made a Covenant with you on the right side of Mount (Sinai), and We sent down to you Manna and quails:

# 2429

(Saying): "Eat of the good things We have provided for your sustenance, but commit no excess therein, lest My Wrath should justly descend on you: and those on whom descends My Wrath do perish indeed!

# 2430

"But, without doubt, I am (also) He that forgives again and again, to those who repent, believe, and do right, who,- in fine, are ready to receive true guidance."

# 2431

(When Moses was up on the Mount, Allah said:) "What made thee hasten in advance of thy people, O Moses?"

# 2432

He replied: "Behold, they are close on my footsteps: I hastened to thee, O my Lord, to please thee."

# 2433

(Allah) said: "We have tested thy people in thy absence: the Samiri has led them astray."

# 2434

So Moses returned to his people in a state of indignation and sorrow. He said: "O my people! did not your Lord make a handsome promise to you? Did then the promise seem to you long (in coming)? Or did ye desire that Wrath should descend from your Lord on you, and so ye broke your promise to me?"

# 2435

They said: "We broke not the promise to thee, as far as lay in our power: but we were made to carry the weight of the ornaments of the (whole) people, and we threw them (into the fire), and that was what the Samiri suggested.

# 2436

"Then he brought out (of the fire) before the (people) the image of a calf: It seemed to low: so they said: This is your god, and the god of Moses, but (Moses) has forgotten!"

# 2437

Could they not see that it could not return them a word (for answer), and that it had no power either to harm them or to do them good?

# 2438

Aaron had already, before this said to them: "O my people! ye are being tested in this: for verily your Lord is (Allah) Most Gracious; so follow me and obey my command."

# 2439

They had said: "We will not abandon this cult, but we will devote ourselves to it until Moses returns to us."

# 2440

(Moses) said: "O Aaron! what kept thee back, when thou sawest them going wrong,

# 2441

"From following me? Didst thou then disobey my order?"

# 2442

(Aaron) replied: "O son of my mother! Seize (me) not by my beard nor by (the hair of) my head! Truly I feared lest thou shouldst say, 'Thou has caused a division among the children of Israel, and thou didst not respect my word!'"

# 2443

(Moses) said: "What then is thy case, O Samiri?"

# 2444

He replied: "I saw what they saw not: so I took a handful (of dust) from the footprint of the Messenger, and threw it (into the calf): thus did my soul suggest to me."

# 2445

(Moses) said: "Get thee gone! but thy (punishment) in this life will be that thou wilt say, 'touch me not'; and moreover (for a future penalty) thou hast a promise that will not fail: Now look at thy god, of whom thou hast become a devoted worshipper: We will certainly (melt) it in a blazing fire and scatter it broadcast in the sea!"

# 2446

But the god of you all is the One Allah: there is no god but He: all things He comprehends in His knowledge.

# 2447

Thus do We relate to thee some stories of what happened before: for We have sent thee a Message from Our own Presence.

# 2448

If any do turn away therefrom, verily they will bear a burden on the Day of judgment;

# 2449

They will abide in this (state): and grievous will the burden be to them on that Day,-

# 2450

The Day when the Trumpet will be sounded: that Day, We shall gather the sinful, blear-eyed (with terror).

# 2451

In whispers will they consult each other: "Yet tarried not longer than ten (Days);

# 2452

We know best what they will say, when their leader most eminent in conduct will say: "Ye tarried not longer than a day!"

# 2453

They ask thee concerning the Mountains: say, "My Lord will uproot them and scatter them as dust;

# 2454

"He will leave them as plains smooth and level;

# 2455

"Nothing crooked or curved wilt thou see in their place."

# 2456

On that Day will they follow the Caller (straight): no crookedness (can they show) him: all sounds shall humble themselves in the Presence of (Allah) Most Gracious: nothing shalt thou hear but the tramp of their feet (as they march).

# 2457

On that Day shall no intercession avail except for those for whom permission has been granted by (Allah) Most Gracious and whose word is acceptable to Him.

# 2458

He knows what (appears to His creatures as) before or after or behind them: but they shall not compass it with their knowledge.

# 2459

(All) faces shall be humbled before (Him) - the Living, the Self-Subsisting, Eternal: hopeless indeed will be the man that carries iniquity (on his back).

# 2460

But he who works deeds of righteousness, and has faith, will have no fear of harm nor of any curtailment (of what is his due).

# 2461

Thus have We sent this down - an arabic Qur'an - and explained therein in detail some of the warnings, in order that they may fear Allah, or that it may cause their remembrance (of Him).

# 2462

High above all is Allah, the King, the Truth! Be not in haste with the Qur'an before its revelation to thee is completed, but say, "O my Lord! advance me in knowledge."

# 2463

We had already, beforehand, taken the covenant of Adam, but he forgot: and We found on his part no firm resolve.

# 2464

When We said to the angels, "Prostrate yourselves to Adam", they prostrated themselves, but not Iblis: he refused.

# 2465

Then We said: "O Adam! verily, this is an enemy to thee and thy wife: so let him not get you both out of the Garden, so that thou art landed in misery.

# 2466

"There is therein (enough provision) for thee not to go hungry nor to go naked,

# 2467

"Nor to suffer from thirst, nor from the sun's heat."

# 2468

But Satan whispered evil to him: he said, "O Adam! shall I lead thee to the Tree of Eternity and to a kingdom that never decays?"

# 2469

In the result, they both ate of the tree, and so their nakedness appeared to them: they began to sew together, for their covering, leaves from the Garden: thus did Adam disobey his Lord, and allow himself to be seduced.

# 2470

But his Lord chose him (for His Grace): He turned to him, and gave him Guidance.

# 2471

He said: "Get ye down, both of you,- all together, from the Garden, with enmity one to another: but if, as is sure, there comes to you Guidance from Me, whosoever follows My Guidance, will not lose his way, nor fall into misery.

# 2472

"But whosoever turns away from My Message, verily for him is a life narrowed down, and We shall raise him up blind on the Day of Judgment."

# 2473

He will say: "O my Lord! why hast Thou raised me up blind, while I had sight (before)?"

# 2474

(Allah) will say: "Thus didst Thou, when Our Signs came unto thee, disregard them: so wilt thou, this day, be disregarded."

# 2475

And thus do We recompense him who transgresses beyond bounds and believes not in the Signs of his Lord: and the Penalty of the Hereafter is far more grievous and more enduring.

# 2476

Is it not a warning to such men (to call to mind) how many generations before them We destroyed, in whose haunts they (now) move? Verily, in this are Signs for men endued with understanding.

# 2477

Had it not been for a Word that went forth before from thy Lord, (their punishment) must necessarily have come; but there is a Term appointed (for respite).

# 2478

Therefore be patient with what they say, and celebrate (constantly) the praises of thy Lord, before the rising of the sun, and before its setting; yea, celebrate them for part of the hours of the night, and at the sides of the day: that thou mayest have (spiritual) joy.

# 2479

Nor strain thine eyes in longing for the things We have given for enjoyment to parties of them, the splendour of the life of this world, through which We test them: but the provision of thy Lord is better and more enduring.

# 2480

Enjoin prayer on thy people, and be constant therein. We ask thee not to provide sustenance: We provide it for thee. But the (fruit of) the Hereafter is for righteousness.

# 2481

They say: "Why does he not bring us a sign from his Lord?" Has not a Clear Sign come to them of all that was in the former Books of revelation?

# 2482

And if We had inflicted on them a penalty before this, they would have said: "Our Lord! If only Thou hadst sent us a messenger, we should certainly have followed Thy Signs before we were humbled and put to shame."

# 2483

Say: "Each one (of us) is waiting: wait ye, therefore, and soon shall ye know who it is that is on the straight and even way, and who it is that has received Guidance."

# 2484

Closer and closer to mankind comes their Reckoning: yet they heed not and they turn away.

# 2485

Never comes (aught) to them of a renewed Message from their Lord, but they listen to it as in jest,-

# 2486

Their hearts toying as with trifles. The wrong-doers conceal their private counsels, (saying), "Is this (one) more than a man like yourselves? Will ye go to witchcraft with your eyes open?"

# 2487

Say: "My Lord knoweth (every) word (spoken) in the heavens and on earth: He is the One that heareth and knoweth (all things)."

# 2488

"Nay," they say, "(these are) medleys of dream! - Nay, He forged it! - Nay, He is (but) a poet! Let him then bring us a Sign like the ones that were sent to (Prophets) of old!"

# 2489

(As to those) before them, not one of the populations which We destroyed believed: will these believe?

# 2490

Before thee, also, the messengers We sent were but men, to whom We granted inspiration: If ye realise this not, ask of those who possess the Message.

# 2491

Nor did We give them bodies that ate no food, nor were they exempt from death.

# 2492

In the end We fulfilled to them Our Promise, and We saved them and those whom We pleased, but We destroyed those who transgressed beyond bounds.

# 2493

We have revealed for you (O men!) a book in which is a Message for you: will ye not then understand?

# 2494

How many were the populations We utterly destroyed because of their iniquities, setting up in their places other peoples?

# 2495

Yet, when they felt Our Punishment (coming), behold, they (tried to) flee from it.

# 2496

Flee not, but return to the good things of this life which were given you, and to your homes in order that ye may be called to account.

# 2497

They said: "Ah! woe to us! We were indeed wrong-doers!"

# 2498

And that cry of theirs ceased not, till We made them as a field that is mown, as ashes silent and quenched.

# 2499

Not for (idle) sport did We create the heavens and the earth and all that is between!

# 2500

If it had been Our wish to take (just) a pastime, We should surely have taken it from the things nearest to Us, if We would do (such a thing)!

# 2501

Nay, We hurl the Truth against falsehood, and it knocks out its brain, and behold, falsehood doth perish! Ah! woe be to you for the (false) things ye ascribe (to Us).

# 2502

To Him belong all (creatures) in the heavens and on earth: Even those who are in His (very) Presence are not too proud to serve Him, nor are they (ever) weary (of His service):

# 2503

They celebrate His praises night and day, nor do they ever flag or intermit.

# 2504

Or have they taken (for worship) gods from the earth who can raise (the dead)?

# 2505

If there were, in the heavens and the earth, other gods besides Allah, there would have been confusion in both! but glory to Allah, the Lord of the Throne: (High is He) above what they attribute to Him!

# 2506

He cannot be questioned for His acts, but they will be questioned (for theirs).

# 2507

Or have they taken for worship (other) gods besides him? Say, "Bring your convincing proof: this is the Message of those with me and the Message of those before me." But most of them know not the Truth, and so turn away.

# 2508

Not a messenger did We send before thee without this inspiration sent by Us to him: that there is no god but I; therefore worship and serve Me.

# 2509

And they say: "(Allah) Most Gracious has begotten offspring." Glory to Him! they are (but) servants raised to honour.

# 2510

They speak not before He speaks, and they act (in all things) by His Command.

# 2511

He knows what is before them, and what is behind them, and they offer no intercession except for those who are acceptable, and they stand in awe and reverence of His (Glory).

# 2512

If any of them should say, "I am a god besides Him", such a one We should reward with Hell: thus do We reward those who do wrong.

# 2513

Do not the Unbelievers see that the heavens and the earth were joined together (as one unit of creation), before we clove them asunder? We made from water every living thing. Will they not then believe?

# 2514

And We have set on the earth mountains standing firm, lest it should shake with them, and We have made therein broad highways (between mountains) for them to pass through: that they may receive Guidance.

# 2515

And We have made the heavens as a canopy well guarded: yet do they turn away from the Signs which these things (point to)!

# 2516

It is He Who created the Night and the Day, and the sun and the moon: all (the celestial bodies) swim along, each in its rounded course.

# 2517

We granted not to any man before thee permanent life (here): if then thou shouldst die, would they live permanently?

# 2518

Every soul shall have a taste of death: and We test you by evil and by good by way of trial. to Us must ye return.

# 2519

When the Unbelievers see thee, they treat thee not except with ridicule. "Is this," (they say), "the one who talks of your gods?" and they blaspheme at the mention of (Allah) Most Gracious!

# 2520

Man is a creature of haste: soon (enough) will I show you My Signs; then ye will not ask Me to hasten them!

# 2521

They say: "When will this promise come to pass, if ye are telling the truth?"

# 2522

If only the Unbelievers knew (the time) when they will not be able to ward off the fire from their faces, nor yet from their backs, and (when) no help can reach them!

# 2523

Nay, it may come to them all of a sudden and confound them: no power will they have then to avert it, nor will they (then) get respite.

# 2524

Mocked were (many) messenger before thee; But their scoffers were hemmed in by the thing that they mocked.

# 2525

Say: "Who can keep you safe by night and by day from (the Wrath of) (Allah) Most Gracious?" Yet they turn away from the mention of their Lord.

# 2526

Or have they gods that can guard them from Us? They have no power to aid themselves, nor can they be defended from Us.

# 2527

Nay, We gave the good things of this life to these men and their fathers until the period grew long for them; See they not that We gradually reduce the land (in their control) from its outlying borders? Is it then they who will win?

# 2528

Say, "I do but warn you according to revelation": But the deaf will not hear the call, (even) when they are warned!

# 2529

If but a breath of the Wrath of thy Lord do touch them, they will then say, "Woe to us! we did wrong indeed!"

# 2530

We shall set up scales of justice for the Day of Judgment, so that not a soul will be dealt with unjustly in the least, and if there be (no more than) the weight of a mustard seed, We will bring it (to account): and enough are We to take account.

# 2531

In the past We granted to Moses and Aaron the criterion (for judgment), and a Light and a Message for those who would do right,-

# 2532

Those who fear their Lord in their most secret thoughts, and who hold the Hour (of Judgment) in awe.

# 2533

And this is a blessed Message which We have sent down: will ye then reject it?

# 2534

We bestowed aforetime on Abraham his rectitude of conduct, and well were We acquainted with him.

# 2535

Behold! he said to his father and his people, "What are these images, to which ye are (so assiduously) devoted?"

# 2536

They said, "We found our fathers worshipping them."

# 2537

He said, "Indeed ye have been in manifest error - ye and your fathers."

# 2538

They said, "Have you brought us the Truth, or are you one of those who jest?"

# 2539

He said, "Nay, your Lord is the Lord of the heavens and the earth, He Who created them (from nothing): and I am a witness to this (Truth).

# 2540

"And by Allah, I have a plan for your idols - after ye go away and turn your backs"..

# 2541

So he broke them to pieces, (all) but the biggest of them, that they might turn (and address themselves) to it.

# 2542

They said, "Who has done this to our gods? He must indeed be some man of impiety!"

# 2543

They said, "We heard a youth talk of them: He is called Abraham."

# 2544

They said, "Then bring him before the eyes of the people, that they may bear witness."

# 2545

They said, "Art thou the one that did this with our gods, O Abraham?"

# 2546

He said: "Nay, this was done by - this is their biggest one! ask them, if they can speak intelligently!"

# 2547

So they turned to themselves and said, "Surely ye are the ones in the wrong!"

# 2548

Then were they confounded with shame: (they said), "Thou knowest full well that these (idols) do not speak!"

# 2549

(Abraham) said, "Do ye then worship, besides Allah, things that can neither be of any good to you nor do you harm?

# 2550

"Fie upon you, and upon the things that ye worship besides Allah! Have ye no sense?"..

# 2551

They said, "Burn him and protect your gods, If ye do (anything at all)!"

# 2552

We said, "O Fire! be thou cool, and (a means of) safety for Abraham!"

# 2553

Then they sought a stratagem against him: but We made them the ones that lost most!

# 2554

But We delivered him and (his nephew) Lut (and directed them) to the land which We have blessed for the nations.

# 2555

And We bestowed on him Isaac and, as an additional gift, (a grandson), Jacob, and We made righteous men of every one (of them).

# 2556

And We made them leaders, guiding (men) by Our Command, and We sent them inspiration to do good deeds, to establish regular prayers, and to practise regular charity; and they constantly served Us (and Us only).

# 2557

And to Lut, too, We gave Judgment and Knowledge, and We saved him from the town which practised abominations: truly they were a people given to Evil, a rebellious people.

# 2558

And We admitted him to Our Mercy: for he was one of the Righteous.

# 2559

(Remember) Noah, when he cried (to Us) aforetime: We listened to his (prayer) and delivered him and his family from great distress.

# 2560

We helped him against people who rejected Our Signs: truly they were a people given to Evil: so We drowned them (in the Flood) all together.

# 2561

And remember David and Solomon, when they gave judgment in the matter of the field into which the sheep of certain people had strayed by night: We did witness their judgment.

# 2562

To Solomon We inspired the (right) understanding of the matter: to each (of them) We gave Judgment and Knowledge; it was Our power that made the hills and the birds celebrate Our praises, with David: it was We Who did (all these things).

# 2563

It was We Who taught him the making of coats of mail for your benefit, to guard you from each other's violence: will ye then be grateful?

# 2564

(It was Our power that made) the violent (unruly) wind flow (tamely) for Solomon, to his order, to the land which We had blessed: for We do know all things.

# 2565

And of the evil ones, were some who dived for him, and did other work besides; and it was We Who guarded them.

# 2566

And (remember) Job, when He cried to his Lord, "Truly distress has seized me, but Thou art the Most Merciful of those that are merciful."

# 2567

So We listened to him: We removed the distress that was on him, and We restored his people to him, and doubled their number,- as a Grace from Ourselves, and a thing for commemoration, for all who serve Us.

# 2568

And (remember) Isma'il, Idris, and Zul-kifl, all (men) of constancy and patience;

# 2569

We admitted them to Our mercy: for they were of the righteous ones.

# 2570

And remember Zun-nun, when he departed in wrath: He imagined that We had no power over him! But he cried through the deptHs of darkness, "There is no god but thou: glory to thee: I was indeed wrong!"

# 2571

So We listened to him: and delivered him from distress: and thus do We deliver those who have faith.

# 2572

And (remember) Zakariya, when he cried to his Lord: "O my Lord! leave me not without offspring, though thou art the best of inheritors."

# 2573

So We listened to him: and We granted him Yahya: We cured his wife's (Barrenness) for him. These (three) were ever quick in emulation in good works; they used to call on Us with love and reverence, and humble themselves before Us.

# 2574

And (remember) her who guarded her chastity: We breathed into her of Our spirit, and We made her and her son a sign for all peoples.

# 2575

Verily, this brotherhood of yours is a single brotherhood, and I am your Lord and Cherisher: therefore serve Me (and no other).

# 2576

But (later generations) cut off their affair (of unity), one from another: (yet) will they all return to Us.

# 2577

Whoever works any act of righteousness and has faith,- His endeavour will not be rejected: We shall record it in his favour.

# 2578

But there is a ban on any population which We have destroyed: that they shall not return,

# 2579

Until the Gog and Magog (people) are let through (their barrier), and they swiftly swarm from every hill.

# 2580

Then will the true promise draw nigh (of fulfilment): then behold! the eyes of the Unbelievers will fixedly stare in horror: "Ah! Woe to us! we were indeed heedless of this; nay, we truly did wrong!"

# 2581

Verily ye, (unbelievers), and the (false) gods that ye worship besides Allah, are (but) fuel for Hell! to it will ye (surely) come!

# 2582

If these had been gods, they would not have got there! but each one will abide therein.

# 2583

There, sobbing will be their lot, nor will they there hear (aught else).

# 2584

Those for whom the good (record) from Us has gone before, will be removed far therefrom.

# 2585

Not the slightest sound will they hear of Hell: what their souls desired, in that will they dwell.

# 2586

The Great Terror will bring them no grief: but the angels will meet them (with mutual greetings): "This is your Day,- (the Day) that ye were promised."

# 2587

The Day that We roll up the heavens like a scroll rolled up for books (completed),- even as We produced the first creation, so shall We produce a new one: a promise We have undertaken: truly shall We fulfil it.

# 2588

Before this We wrote in the Psalms, after the Message (given to Moses): My servants the righteous, shall inherit the earth."

# 2589

Verily in this (Qur'an) is a Message for people who would (truly) worship Allah.

# 2590

We sent thee not, but as a Mercy for all creatures.

# 2591

Say: "What has come to me by inspiration is that your Allah is One Allah: will ye therefore bow to His Will (in Islam)?"

# 2592

But if they turn back, Say: "I have proclaimed the Message to you all alike and in truth; but I know not whether that which ye are promised is near or far.

# 2593

"It is He Who knows what is open in speech and what ye hide (in your hearts).

# 2594

"I know not but that it may be a trial for you, and a grant of (worldly) livelihood (to you) for a time."

# 2595

Say: "O my Lord! judge Thou in truth!" "Our Lord Most Gracious is the One Whose assistance should be sought against the blasphemies ye utter!"

# 2596

O mankind! fear your Lord! for the convulsion of the Hour (of Judgment) will be a thing terrible!

# 2597

The Day ye shall see it, every mother giving suck shall forget her suckling-babe, and every pregnant female shall drop her load (unformed): thou shalt see mankind as in a drunken riot, yet not drunk: but dreadful will be the Wrath of Allah.

# 2598

And yet among men there are such as dispute about Allah, without knowledge, and follow every evil one obstinate in rebellion!

# 2599

About the (Evil One) it is decreed that whoever turns to him for friendship, him will he lead astray, and he will guide him to the Penalty of the Fire.

# 2600

O mankind! if ye have a doubt about the Resurrection, (consider) that We created you out of dust, then out of sperm, then out of a leech-like clot, then out of a morsel of flesh, partly formed and partly unformed, in order that We may manifest (our power) to you; and We cause whom We will to rest in the wombs for an appointed term, then do We bring you out as babes, then (foster you) that ye may reach your age of full strength; and some of you are called to die, and some are sent back to the feeblest old age, so that they know nothing after having known (much), and (further), thou seest the earth barren and lifeless, but when We pour down rain on it, it is stirred (to life), it swells, and it puts forth every kind of beautiful growth (in pairs).

# 2601

This is so, because Allah is the Reality: it is He Who gives life to the dead, and it is He Who has power over all things.

# 2602

And verily the Hour will come: there can be no doubt about it, or about (the fact) that Allah will raise up all who are in the graves.

# 2603

Yet there is among men such a one as disputes about Allah, without Knowledge, without Guidance, and without a Book of Enlightenment,-

# 2604

(Disdainfully) bending his side, in order to lead (men) astray from the Path of Allah: for him there is disgrace in this life, and on the Day of Judgment We shall make him taste the Penalty of burning (Fire).

# 2605

(It will be said): "This is because of the deeds which thy hands sent forth, for verily Allah is not unjust to His servants.

# 2606

There are among men some who serve Allah, as it were, on the verge: if good befalls them, they are, therewith, well content; but if a trial comes to them, they turn on their faces: they lose both this world and the Hereafter: that is loss for all to see!

# 2607

They call on such deities, besides Allah, as can neither hurt nor profit them: that is straying far indeed (from the Way)!

# 2608

(Perhaps) they call on one whose hurt is nearer than his profit: evil, indeed, is the patron, and evil the companion (or help)!

# 2609

Verily Allah will admit those who believe and work righteous deeds, to Gardens, beneath which rivers flow: for Allah carries out all that He plans.

# 2610

If any think that Allah will not help him (His Messenger) in this world and the Hereafter, let him stretch out a rope to the ceiling and cut (himself) off: then let him see whether his plan will remove that which enrages (him)!

# 2611

Thus have We sent down Clear Signs; and verily Allah doth guide whom He will!

# 2612

Those who believe (in the Qur'an), those who follow the Jewish (scriptures), and the Sabians, Christians, Magians, and Polytheists,- Allah will judge between them on the Day of Judgment: for Allah is witness of all things.

# 2613

Seest thou not that to Allah bow down in worship all things that are in the heavens and on earth,- the sun, the moon, the stars; the hills, the trees, the animals; and a great number among mankind? But a great number are (also) such as are fit for Punishment: and such as Allah shall disgrace,- None can raise to honour: for Allah carries out all that He wills.

# 2614

These two antagonists dispute with each other about their Lord: But those who deny (their Lord),- for them will be cut out a garment of Fire: over their heads will be poured out boiling water.

# 2615

With it will be scalded what is within their bodies, as well as (their) skins.

# 2616

In addition there will be maces of iron (to punish) them.

# 2617

Every time they wish to get away therefrom, from anguish, they will be forced back therein, and (it will be said), "Taste ye the Penalty of Burning!"

# 2618

Allah will admit those who believe and work righteous deeds, to Gardens beneath which rivers flow: they shall be adorned therein with bracelets of gold and pearls; and their garments there will be of silk.

# 2619

For they have been guided (in this life) to the purest of speeches; they have been guided to the Path of Him Who is Worthy of (all) Praise.

# 2620

As to those who have rejected (Allah), and would keep back (men) from the Way of Allah, and from the Sacred Mosque, which We have made (open) to (all) men - equal is the dweller there and the visitor from the country - and any whose purpose therein is profanity or wrong-doing - them will We cause to taste of a most Grievous Penalty.

# 2621

Behold! We gave the site, to Abraham, of the (Sacred) House, (saying): "Associate not anything (in worship) with Me; and sanctify My House for those who compass it round, or stand up, or bow, or prostrate themselves (therein in prayer).

# 2622

"And proclaim the Pilgrimage among men: they will come to thee on foot and (mounted) on every kind of camel, lean on account of journeys through deep and distant mountain highways;

# 2623

"That they may witness the benefits (provided) for them, and celebrate the name of Allah, through the Days appointed, over the cattle which He has provided for them (for sacrifice): then eat ye thereof and feed the distressed ones in want.

# 2624

"Then let them complete the rites prescribed for them, perform their vows, and (again) circumambulate the Ancient House."

# 2625

Such (is the Pilgrimage): whoever honours the sacred rites of Allah, for him it is good in the Sight of his Lord. Lawful to you (for food in Pilgrimage) are cattle, except those mentioned to you (as exception): but shun the abomination of idols, and shun the word that is false,-

# 2626

Being true in faith to Allah, and never assigning partners to Him: if anyone assigns partners to Allah, is as if he had fallen from heaven and been snatched up by birds, or the wind had swooped (like a bird on its prey) and thrown him into a far-distant place.

# 2627

Such (is his state): and whoever holds in honour the symbols of Allah, (in the sacrifice of animals), such (honour) should come truly from piety of heart.

# 2628

In them ye have benefits for a term appointed: in the end their place of sacrifice is near the Ancient House.

# 2629

To every people did We appoint rites (of sacrifice), that they might celebrate the name of Allah over the sustenance He gave them from animals (fit for food). But your god is One God: submit then your wills to Him (in Islam): and give thou the good news to those who humble themselves,-

# 2630

To those whose hearts when Allah is mentioned, are filled with fear, who show patient perseverance over their afflictions, keep up regular prayer, and spend (in charity) out of what We have bestowed upon them.

# 2631

The sacrificial camels we have made for you as among the symbols from Allah: in them is (much) good for you: then pronounce the name of Allah over them as they line up (for sacrifice): when they are down on their sides (after slaughter), eat ye thereof, and feed such as (beg not but) live in contentment, and such as beg with due humility: thus have We made animals subject to you, that ye may be grateful.

# 2632

It is not their meat nor their blood, that reaches Allah: it is your piety that reaches Him: He has thus made them subject to you, that ye may glorify Allah for His Guidance to you and proclaim the good news to all who do right.

# 2633

Verily Allah will defend (from ill) those who believe: verily, Allah loveth not any that is a traitor to faith, or show ingratitude.

# 2634

To those against whom war is made, permission is given (to fight), because they are wronged;- and verily, Allah is most powerful for their aid;-

# 2635

(They are) those who have been expelled from their homes in defiance of right,- (for no cause) except that they say, "our Lord is Allah". Did not Allah check one set of people by means of another, there would surely have been pulled down monasteries, churches, synagogues, and mosques, in which the name of Allah is commemorated in abundant measure. Allah will certainly aid those who aid his (cause);- for verily Allah is full of Strength, Exalted in Might, (able to enforce His Will).

# 2636

(They are) those who, if We establish them in the land, establish regular prayer and give regular charity, enjoin the right and forbid wrong: with Allah rests the end (and decision) of (all) affairs.

# 2637

If they treat thy (mission) as false, so did the peoples before them (with their prophets),- the People of Noah, and 'Ad and Thamud;

# 2638

Those of Abraham and Lut;

# 2639

And the Companions of the Madyan People; and Moses was rejected (in the same way). But I granted respite to the Unbelievers, and (only) after that did I punish them: but how (terrible) was my rejection (of them)!

# 2640

How many populations have We destroyed, which were given to wrong-doing? They tumbled down on their roofs. And how many wells are lying idle and neglected, and castles lofty and well-built?

# 2641

Do they not travel through the land, so that their hearts (and minds) may thus learn wisdom and their ears may thus learn to hear? Truly it is not their eyes that are blind, but their hearts which are in their breasts.

# 2642

Yet they ask thee to hasten on the Punishment! But Allah will not fail in His Promise. Verily a Day in the sight of thy Lord is like a thousand years of your reckoning.

# 2643

And to how many populations did I give respite, which were given to wrong-doing? in the end I punished them. To me is the destination (of all).

# 2644

Say: "O men! I am (sent) to you only to give a Clear Warning:

# 2645

"Those who believe and work righteousness, for them is forgiveness and a sustenance most generous.

# 2646

"But those who strive against Our Signs, to frustrate them,- they will be Companions of the Fire."

# 2647

Never did We send a messenger or a prophet before thee, but, when he framed a desire, Satan threw some (vanity) into his desire: but Allah will cancel anything (vain) that Satan throws in, and Allah will confirm (and establish) His Signs: for Allah is full of Knowledge and Wisdom:

# 2648

That He may make the suggestions thrown in by Satan, but a trial for those in whose hearts is a disease and who are hardened of heart: verily the wrong-doers are in a schism far (from the Truth):

# 2649

And that those on whom knowledge has been bestowed may learn that the (Qur'an) is the Truth from thy Lord, and that they may believe therein, and their hearts may be made humbly (open) to it: for verily Allah is the Guide of those who believe, to the Straight Way.

# 2650

Those who reject Faith will not cease to be in doubt concerning (Revelation) until the Hour (of Judgment) comes suddenly upon them, or there comes to them the Penalty of a Day of Disaster.

# 2651

On that Day of Dominion will be that of Allah: He will judge between them: so those who believe and work righteous deeds will be in Gardens of Delight.

# 2652

And for those who reject Faith and deny our Signs, there will be a humiliating Punishment.

# 2653

Those who leave their homes in the cause of Allah, and are then slain or die,- On them will Allah bestow verily a goodly Provision: Truly Allah is He Who bestows the best provision.

# 2654

Verily He will admit them to a place with which they shall be well pleased: for Allah is All-Knowing, Most Forbearing.

# 2655

That (is so). And if one has retaliated to no greater extent than the injury he received, and is again set upon inordinately, Allah will help him: for Allah is One that blots out (sins) and forgives (again and again).

# 2656

That is because Allah merges night into day, and He merges day into night, and verily it is Allah Who hears and sees (all things).

# 2657

That is because Allah - He is the Reality; and those besides Him whom they invoke,- they are but vain Falsehood: verily Allah is He, Most High, Most Great.

# 2658

Seest thou not that Allah sends down rain from the sky, and forthwith the earth becomes clothed with green? for Allah is He Who understands the finest mysteries, and is well-acquainted (with them).

# 2659

To Him belongs all that is in the heavens and on earth: for verily Allah,- He is free of all wants, Worthy of all Praise.

# 2660

Seest thou not that Allah has made subject to you (men) all that is on the earth, and the ships that sail through the sea by His Command? He withholds the sky (rain) from failing on the earth except by His leave: for Allah is Most Kind and Most Merciful to man.

# 2661

It is He Who gave you life, will cause you to die, and will again give you life: Truly man is a most ungrateful creature!

# 2662

To every People have We appointed rites and ceremonies which they must follow: let them not then dispute with thee on the matter, but do thou invite (them) to thy Lord: for thou art assuredly on the Right Way.

# 2663

If they do wrangle with thee, say, "Allah knows best what it is ye are doing."

# 2664

"Allah will judge between you on the Day of Judgment concerning the matters in which ye differ."

# 2665

Knowest thou not that Allah knows all that is in heaven and on earth? Indeed it is all in a Record, and that is easy for Allah.

# 2666

Yet they worship, besides Allah, things for which no authority has been sent down to them, and of which they have (really) no knowledge: for those that do wrong there is no helper.

# 2667

When Our Clear Signs are rehearsed to them, thou wilt notice a denial on the faces of the Unbelievers! they nearly attack with violence those who rehearse Our Signs to them. Say, "Shall I tell you of something (far) worse than these Signs? It is the Fire (of Hell)! Allah has promised it to the Unbelievers! and evil is that destination!"

# 2668

O men! Here is a parable set forth! listen to it! Those on whom, besides Allah, ye call, cannot create (even) a fly, if they all met together for the purpose! and if the fly should snatch away anything from them, they would have no power to release it from the fly. Feeble are those who petition and those whom they petition!

# 2669

No just estimate have they made of Allah: for Allah is He Who is strong and able to Carry out His Will.

# 2670

Allah chooses messengers from angels and from men for Allah is He Who hears and sees (all things).

# 2671

He knows what is before them and what is behind them: and to Allah go back all questions (for decision).

# 2672

O ye who believe! bow down, prostrate yourselves, and adore your Lord; and do good; that ye may prosper.

# 2673

And strive in His cause as ye ought to strive, (with sincerity and under discipline). He has chosen you, and has imposed no difficulties on you in religion; it is the cult of your father Abraham. It is He Who has named you Muslims, both before and in this (Revelation); that the Messenger may be a witness for you, and ye be witnesses for mankind! So establish regular Prayer, give regular Charity, and hold fast to Allah! He is your Protector - the Best to protect and the Best to help!

# 2674

The believers must (eventually) win through,-

# 2675

Those who humble themselves in their prayers;

# 2676

Who avoid vain talk;

# 2677

Who are active in deeds of charity;

# 2678

Who abstain from sex,

# 2679

Except with those joined to them in the marriage bond, or (the captives) whom their right hands possess,- for (in their case) they are free from blame,

# 2680

But those whose desires exceed those limits are transgressors;-

# 2681

Those who faithfully observe their trusts and their covenants;

# 2682

And who (strictly) guard their prayers;-

# 2683

These will be the heirs,

# 2684

Who will inherit Paradise: they will dwell therein (for ever).

# 2685

Man We did create from a quintessence (of clay);

# 2686

Then We placed him as (a drop of) sperm in a place of rest, firmly fixed;

# 2687

Then We made the sperm into a clot of congealed blood; then of that clot We made a (foetus) lump; then we made out of that lump bones and clothed the bones with flesh; then we developed out of it another creature. So blessed be Allah, the best to create!

# 2688

After that, at length ye will die

# 2689

Again, on the Day of Judgment, will ye be raised up.

# 2690

And We have made, above you, seven tracts; and We are never unmindful of (our) Creation.

# 2691

And We send down water from the sky according to (due) measure, and We cause it to soak in the soil; and We certainly are able to drain it off (with ease).

# 2692

With it We grow for you gardens of date-palms and vines: in them have ye abundant fruits: and of them ye eat (and have enjoyment),-

# 2693

Also a tree springing out of Mount Sinai, which produces oil, and relish for those who use it for food.

# 2694

And in cattle (too) ye have an instructive example: from within their bodies We produce (milk) for you to drink; there are, in them, (besides), numerous (other) benefits for you; and of their (meat) ye eat;

# 2695

And on them, as well as in ships, ye ride.

# 2696

(Further, We sent a long line of prophets for your instruction). We sent Noah to his people: He said, "O my people! worship Allah! Ye have no other god but Him. Will ye not fear (Him)?"

# 2697

The chiefs of the Unbelievers among his people said: "He is no more than a man like yourselves: his wish is to assert his superiority over you: if Allah had wished (to send messengers), He could have sent down angels; never did we hear such a thing (as he says), among our ancestors of old."

# 2698

(And some said): "He is only a man possessed: wait (and have patience) with him for a time."

# 2699

(Noah) said: "O my Lord! help me: for that they accuse me of falsehood!"

# 2700

So We inspired him (with this message): "Construct the Ark within Our sight and under Our guidance: then when comes Our Command, and the fountains of the earth gush forth, take thou on board pairs of every species, male and female, and thy family- except those of them against whom the Word has already gone forth: And address Me not in favour of the wrong-doers; for they shall be drowned (in the Flood).

# 2701

And when thou hast embarked on the Ark - thou and those with thee,- say: "Praise be to Allah, Who has saved us from the people who do wrong."

# 2702

And say: "O my Lord! enable me to disembark with thy blessing: for Thou art the Best to enable (us) to disembark."

# 2703

Verily in this there are Signs (for men to understand); (thus) do We try (men).

# 2704

Then We raised after them another generation.

# 2705

And We sent to them a messenger from among themselves, (saying), "Worship Allah! ye have no other god but Him. Will ye not fear (Him)?"

# 2706

And the chiefs of his people, who disbelieved and denied the Meeting in the Hereafter, and on whom We had bestowed the good things of this life, said: "He is no more than a man like yourselves: he eats of that of which ye eat, and drinks of what ye drink.

# 2707

"If ye obey a man like yourselves, behold, it is certain ye will be lost.

# 2708

"Does he promise that when ye die and become dust and bones, ye shall be brought forth (again)?

# 2709

"Far, very far is that which ye are promised!

# 2710

"There is nothing but our life in this world! We shall die and we live! But we shall never be raised up again!

# 2711

"He is only a man who invents a lie against Allah, but we are not the ones to believe in him!"

# 2712

(The prophet) said: "O my Lord! help me: for that they accuse me of falsehood."

# 2713

(Allah) said: "In but a little while, they are sure to be sorry!"

# 2714

Then the Blast overtook them with justice, and We made them as rubbish of dead leaves (floating on the stream of Time)! So away with the people who do wrong!

# 2715

Then We raised after them other generations.

# 2716

No people can hasten their term, nor can they delay (it).

# 2717

Then sent We our messengers in succession: every time there came to a people their messenger, they accused him of falsehood: so We made them follow each other (in punishment): We made them as a tale (that is told): So away with a people that will not believe!

# 2718

Then We sent Moses and his brother Aaron, with Our Signs and authority manifest,

# 2719

To Pharaoh and his Chiefs: But these behaved insolently: they were an arrogant people.

# 2720

They said: "Shall we believe in two men like ourselves? And their people are subject to us!"

# 2721

So they accused them of falsehood, and they became of those who were destroyed.

# 2722

And We gave Moses the Book, in order that they might receive guidance.

# 2723

And We made the son of Mary and his mother as a Sign: We gave them both shelter on high ground, affording rest and security and furnished with springs.

# 2724

O ye messengers! enjoy (all) things good and pure, and work righteousness: for I am well-acquainted with (all) that ye do.

# 2725

And verily this Brotherhood of yours is a single Brotherhood, and I am your Lord and Cherisher: therefore fear Me (and no other).

# 2726

But people have cut off their affair (of unity), between them, into sects: each party rejoices in that which is with itself.

# 2727

But leave them in their confused ignorance for a time.

# 2728

Do they think that because We have granted them abundance of wealth and sons,

# 2729

We would hasten them on in every good? Nay, they do not understand.

# 2730

Verily those who live in awe for fear of their Lord;

# 2731

Those who believe in the Signs of their Lord;

# 2732

Those who join not (in worship) partners with their Lord;

# 2733

And those who dispense their charity with their hearts full of fear, because they will return to their Lord;-

# 2734

It is these who hasten in every good work, and these who are foremost in them.

# 2735

On no soul do We place a burden greater than it can bear: before Us is a record which clearly shows the truth: they will never be wronged.

# 2736

But their hearts are in confused ignorance of this; and there are, besides that, deeds of theirs, which they will (continue) to do,-

# 2737

Until, when We seize in Punishment those of them who received the good things of this world, behold, they will groan in supplication!

# 2738

(It will be said): "Groan not in supplication this day: for ye shall certainly not be helped by Us.

# 2739

"My Signs used to be rehearsed to you, but ye used to turn back on your heels-

# 2740

"In arrogance: talking nonsense about the (Qur'an), like one telling fables by night."

# 2741

Do they not ponder over the Word (of Allah), or has anything (new) come to them that did not come to their fathers of old?

# 2742

Or do they not recognise their Messenger, that they deny him?

# 2743

Or do they say, "He is possessed"? Nay, he has brought them the Truth, but most of them hate the Truth.

# 2744

If the Truth had been in accord with their desires, truly the heavens and the earth, and all beings therein would have been in confusion and corruption! Nay, We have sent them their admonition, but they turn away from their admonition.

# 2745

Or is it that thou askest them for some recompense? But the recompense of thy Lord is best: He is the Best of those who give sustenance.

# 2746

But verily thou callest them to the Straight Way;

# 2747

And verily those who believe not in the Hereafter are deviating from that Way.

# 2748

If We had mercy on them and removed the distress which is on them, they would obstinately persist in their transgression, wandering in distraction to and fro.

# 2749

We inflicted Punishment on them, but they humbled not themselves to their Lord, nor do they submissively entreat (Him)!-

# 2750

Until We open on them a gate leading to a severe Punishment: then Lo! they will be plunged in despair therein!

# 2751

It is He Who has created for you (the faculties of) hearing, sight, feeling and understanding: little thanks it is ye give!

# 2752

And He has multiplied you through the earth, and to Him shall ye be gathered back.

# 2753

It is He Who gives life and death, and to Him (is due) the alternation of Night and Day: will ye not then understand?

# 2754

On the contrary they say things similar to what the ancients said.

# 2755

They say: "What! when we die and become dust and bones, could we really be raised up again?

# 2756

"Such things have been promised to us and to our fathers before! they are nothing but tales of the ancients!"

# 2757

Say: "To whom belong the earth and all beings therein? (say) if ye know!"

# 2758

They will say, "To Allah!" say: "Yet will ye not receive admonition?"

# 2759

Say: "Who is the Lord of the seven heavens, and the Lord of the Throne (of Glory) Supreme?"

# 2760

They will say, "(They belong) to Allah." Say: "Will ye not then be filled with awe?"

# 2761

Say: "Who is it in whose hands is the governance of all things,- who protects (all), but is not protected (of any)? (say) if ye know."

# 2762

They will say, "(It belongs) to Allah." Say: "Then how are ye deluded?"

# 2763

We have sent them the Truth: but they indeed practise falsehood!

# 2764

No son did Allah beget, nor is there any god along with Him: (if there were many gods), behold, each god would have taken away what he had created, and some would have lorded it over others! Glory to Allah! (He is free) from the (sort of) things they attribute to Him!

# 2765

He knows what is hidden and what is open: too high is He for the partners they attribute to Him!

# 2766

Say: "O my Lord! if Thou wilt show me (in my lifetime) that which they are warned against,-

# 2767

"Then, O my Lord! put me not amongst the people who do wrong!"

# 2768

And We are certainly able to show thee (in fulfilment) that against which they are warned.

# 2769

Repel evil with that which is best: We are well acquainted with the things they say.

# 2770

And say "O my Lord! I seek refuge with Thee from the suggestions of the Evil Ones.

# 2771

"And I seek refuge with Thee O my Lord! lest they should come near me."

# 2772

(In Falsehood will they be) Until, when death comes to one of them, he says: "O my Lord! send me back (to life),-

# 2773

"In order that I may work righteousness in the things I neglected." - "By no means! It is but a word he says."- Before them is a Partition till the Day they are raised up.

# 2774

Then when the Trumpet is blown, there will be no more relationships between them that Day, nor will one ask after another!

# 2775

Then those whose balance (of good deeds) is heavy,- they will attain salvation:

# 2776

But those whose balance is light, will be those who have lost their souls, in Hell will they abide.

# 2777

The Fire will burn their faces, and they will therein grin, with their lips displaced.

# 2778

"Were not My Signs rehearsed to you, and ye did but treat them as falsehood?"

# 2779

They will say: "our Lord! Our misfortune overwhelmed us, and we became a people astray!

# 2780

"Our Lord! bring us out of this: if ever we return (to Evil), then shall we be wrong-doers indeed!"

# 2781

He will say: "Be ye driven into it (with ignominy)! And speak ye not to Me!

# 2782

"A part of My servants there was, who used to pray 'our Lord! we believe; then do Thou forgive us, and have mercy upon us: For Thou art the Best of those who show mercy!"

# 2783

"But ye treated them with ridicule, so much so that (ridicule of) them made you forget My Message while ye were laughing at them!

# 2784

"I have rewarded them this Day for their patience and constancy: they are indeed the ones that have achieved Bliss..."

# 2785

He will say: "What number of years did ye stay on earth?"

# 2786

They will say: "We stayed a day or part of a day: but ask those who keep account."

# 2787

He will say: "Ye stayed not but a little,- if ye had only known!

# 2788

"Did ye then think that We had created you in jest, and that ye would not be brought back to Us (for account)?"

# 2789

Therefore exalted be Allah, the King, the Reality: there is no god but He, the Lord of the Throne of Honour!

# 2790

If anyone invokes, besides Allah, Any other god, he has no authority therefor; and his reckoning will be only with his Lord! and verily the Unbelievers will fail to win through!

# 2791

So say: "O my Lord! grant Thou forgiveness and mercy for Thou art the Best of those who show mercy!"

# 2792

A sura which We have sent down and which We have ordained in it have We sent down Clear Signs, in order that ye may receive admonition.

# 2793

The woman and the man guilty of adultery or fornication,- flog each of them with a hundred stripes: Let not compassion move you in their case, in a matter prescribed by Allah, if ye believe in Allah and the Last Day: and let a party of the Believers witness their punishment.

# 2794

Let no man guilty of adultery or fornication marry and but a woman similarly guilty, or an Unbeliever: nor let any but such a man or an Unbeliever marry such a woman: to the Believers such a thing is forbidden.

# 2795

And those who launch a charge against chaste women, and produce not four witnesses (to support their allegations),- flog them with eighty stripes; and reject their evidence ever after: for such men are wicked transgressors;-

# 2796

Unless they repent thereafter and mend (their conduct); for Allah is Oft-Forgiving, Most Merciful.

# 2797

And for those who launch a charge against their spouses, and have (in support) no evidence but their own,- their solitary evidence (can be received) if they bear witness four times (with an oath) by Allah that they are solemnly telling the truth;

# 2798

And the fifth (oath) (should be) that they solemnly invoke the curse of Allah on themselves if they tell a lie.

# 2799

But it would avert the punishment from the wife, if she bears witness four times (with an oath) By Allah, that (her husband) is telling a lie;

# 2800

And the fifth (oath) should be that she solemnly invokes the wrath of Allah on herself if (her accuser) is telling the truth.

# 2801

If it were not for Allah's grace and mercy on you, and that Allah is Oft-Returning, full of Wisdom,- (Ye would be ruined indeed).

# 2802

Those who brought forward the lie are a body among yourselves: think it not to be an evil to you; On the contrary it is good for you: to every man among them (will come the punishment) of the sin that he earned, and to him who took on himself the lead among them, will be a penalty grievous.

# 2803

Why did not the believers - men and women - when ye heard of the affair,- put the best construction on it in their own minds and say, "This (charge) is an obvious lie"?

# 2804

Why did they not bring four witnesses to prove it? When they have not brought the witnesses, such men, in the sight of Allah, (stand forth) themselves as liars!

# 2805

Were it not for the grace and mercy of Allah on you, in this world and the Hereafter, a grievous penalty would have seized you in that ye rushed glibly into this affair.

# 2806

Behold, ye received it on your tongues, and said out of your mouths things of which ye had no knowledge; and ye thought it to be a light matter, while it was most serious in the sight of Allah.

# 2807

And why did ye not, when ye heard it, say? - "It is not right of us to speak of this: Glory to Allah! this is a most serious slander!"

# 2808

Allah doth admonish you, that ye may never repeat such (conduct), if ye are (true) Believers.

# 2809

And Allah makes the Signs plain to you: for Allah is full of knowledge and wisdom.

# 2810

Those who love (to see) scandal published broadcast among the Believers, will have a grievous Penalty in this life and in the Hereafter: Allah knows, and ye know not.

# 2811

Were it not for the grace and mercy of Allah on you, and that Allah is full of kindness and mercy, (ye would be ruined indeed).

# 2812

O ye who believe! follow not Satan's footsteps: if any will follow the footsteps of Satan, he will (but) command what is shameful and wrong: and were it not for the grace and mercy of Allah on you, not one of you would ever have been pure: but Allah doth purify whom He pleases: and Allah is One Who hears and knows (all things).

# 2813

Let not those among you who are endued with grace and amplitude of means resolve by oath against helping their kinsmen, those in want, and those who have left their homes in Allah's cause: let them forgive and overlook, do you not wish that Allah should forgive you? For Allah is Oft-Forgiving, Most Merciful.

# 2814

Those who slander chaste women, indiscreet but believing, are cursed in this life and in the Hereafter: for them is a grievous Penalty,-

# 2815

On the Day when their tongues, their hands, and their feet will bear witness against them as to their actions.

# 2816

On that Day Allah will pay them back (all) their just dues, and they will realise that Allah is the (very) Truth, that makes all things manifest.

# 2817

Women impure are for men impure, and men impure for women impure and women of purity are for men of purity, and men of purity are for women of purity: these are not affected by what people say: for them there is forgiveness, and a provision honourable.

# 2818

O ye who believe! enter not houses other than your own, until ye have asked permission and saluted those in them: that is best for you, in order that ye may heed (what is seemly).

# 2819

If ye find no one in the house, enter not until permission is given to you: if ye are asked to go back, go back: that makes for greater purity for yourselves: and Allah knows well all that ye do.

# 2820

It is no fault on your part to enter houses not used for living in, which serve some (other) use for you: And Allah has knowledge of what ye reveal and what ye conceal.

# 2821

Say to the believing men that they should lower their gaze and guard their modesty: that will make for greater purity for them: And Allah is well acquainted with all that they do.

# 2822

And say to the believing women that they should lower their gaze and guard their modesty; that they should not display their beauty and ornaments except what (must ordinarily) appear thereof; that they should draw their veils over their bosoms and not display their beauty except to their husbands, their fathers, their husband's fathers, their sons, their husbands' sons, their brothers or their brothers' sons, or their sisters' sons, or their women, or the slaves whom their right hands possess, or male servants free of physical needs, or small children who have no sense of the shame of sex; and that they should not strike their feet in order to draw attention to their hidden ornaments. And O ye Believers! turn ye all together towards Allah, that ye may attain Bliss.

# 2823

Marry those among you who are single, or the virtuous ones among yourselves, male or female: if they are in poverty, Allah will give them means out of His grace: for Allah encompasseth all, and he knoweth all things.

# 2824

Let those who find not the wherewithal for marriage keep themselves chaste, until Allah gives them means out of His grace. And if any of your slaves ask for a deed in writing (to enable them to earn their freedom for a certain sum), give them such a deed if ye know any good in them: yea, give them something yourselves out of the means which Allah has given to you. But force not your maids to prostitution when they desire chastity, in order that ye may make a gain in the goods of this life. But if anyone compels them, yet, after such compulsion, is Allah, Oft-Forgiving, Most Merciful (to them),

# 2825

We have already sent down to you verses making things clear, an illustration from (the story of) people who passed away before you, and an admonition for those who fear (Allah).

# 2826

Allah is the Light of the heavens and the earth. The Parable of His Light is as if there were a Niche and within it a Lamp: the Lamp enclosed in Glass: the glass as it were a brilliant star: Lit from a blessed Tree, an Olive, neither of the east nor of the west, whose oil is well-nigh luminous, though fire scarce touched it: Light upon Light! Allah doth guide whom He will to His Light: Allah doth set forth Parables for men: and Allah doth know all things.

# 2827

(Lit is such a Light) in houses, which Allah hath permitted to be raised to honour; for the celebration, in them, of His name: In them is He glorified in the mornings and in the evenings, (again and again),-

# 2828

By men whom neither traffic nor merchandise can divert from the Remembrance of Allah, nor from regular Prayer, nor from the practice of regular Charity: Their (only) fear is for the Day when hearts and eyes will be transformed (in a world wholly new),-

# 2829

That Allah may reward them according to the best of their deeds, and add even more for them out of His Grace: for Allah doth provide for those whom He will, without measure.

# 2830

But the Unbelievers,- their deeds are like a mirage in sandy deserts, which the man parched with thirst mistakes for water; until when he comes up to it, he finds it to be nothing: But he finds Allah (ever) with him, and Allah will pay him his account: and Allah is swift in taking account.

# 2831

Or (the Unbelievers' state) is like the depths of darkness in a vast deep ocean, overwhelmed with billow topped by billow, topped by (dark) clouds: depths of darkness, one above another: if a man stretches out his hands, he can hardly see it! for any to whom Allah giveth not light, there is no light!

# 2832

Seest thou not that it is Allah Whose praises all beings in the heavens and on earth do celebrate, and the birds (of the air) with wings outspread? Each one knows its own (mode of) prayer and praise. And Allah knows well all that they do.

# 2833

Yea, to Allah belongs the dominion of the heavens and the earth; and to Allah is the final goal (of all).

# 2834

Seest thou not that Allah makes the clouds move gently, then joins them together, then makes them into a heap? - then wilt thou see rain issue forth from their midst. And He sends down from the sky mountain masses (of clouds) wherein is hail: He strikes therewith whom He pleases and He turns it away from whom He pleases, the vivid flash of His lightning well-nigh blinds the sight.

# 2835

It is Allah Who alternates the Night and the Day: verily in these things is an instructive example for those who have vision!

# 2836

And Allah has created every animal from water: of them there are some that creep on their bellies; some that walk on two legs; and some that walk on four. Allah creates what He wills for verily Allah has power over all things.

# 2837

We have indeed sent down signs that make things manifest: and Allah guides whom He wills to a way that is straight.

# 2838

They say, "We believe in Allah and in the messenger, and we obey": but even after that, some of them turn away: they are not (really) Believers.

# 2839

When they are summoned to Allah and His messenger, in order that He may judge between them, behold some of them decline (to come).

# 2840

But if the right is on their side, they come to him with all submission.

# 2841

Is it that there is a disease in their hearts? or do they doubt, or are they in fear, that Allah and His Messenger will deal unjustly with them? Nay, it is they themselves who do wrong.

# 2842

The answer of the Believers, when summoned to Allah and His Messenger, in order that He may judge between them, is no other than this: they say, "We hear and we obey": it is such as these that will attain felicity.

# 2843

It is such as obey Allah and His Messenger, and fear Allah and do right, that will win (in the end),

# 2844

They swear their strongest oaths by Allah that, if only thou wouldst command them, they would leave (their homes). Say: "Swear ye not; Obedience is (more) reasonable; verily, Allah is well acquainted with all that ye do."

# 2845

Say: "Obey Allah, and obey the Messenger: but if ye turn away, he is only responsible for the duty placed on him and ye for that placed on you. If ye obey him, ye shall be on right guidance. The Messenger's duty is only to preach the clear (Message).

# 2846

Allah has promised, to those among you who believe and work righteous deeds, that He will, of a surety, grant them in the land, inheritance (of power), as He granted it to those before them; that He will establish in authority their religion - the one which He has chosen for them; and that He will change (their state), after the fear in which they (lived), to one of security and peace: 'They will worship Me (alone) and not associate aught with Me. 'If any do reject Faith after this, they are rebellious and wicked.

# 2847

So establish regular Prayer and give regular Charity; and obey the Messenger; that ye may receive mercy.

# 2848

Never think thou that the Unbelievers are going to frustrate (Allah's Plan) on earth: their abode is the Fire,- and it is indeed an evil refuge!

# 2849

O ye who believe! let those whom your right hands possess, and the (children) among you who have not come of age ask your permission (before they come to your presence), on three occasions: before morning prayer; the while ye doff your clothes for the noonday heat; and after the late-night prayer: these are your three times of undress: outside those times it is not wrong for you or for them to move about attending to each other: Thus does Allah make clear the Signs to you: for Allah is full of knowledge and wisdom.

# 2850

But when the children among you come of age, let them (also) ask for permission, as do those senior to them (in age): Thus does Allah make clear His Signs to you: for Allah is full of knowledge and wisdom.

# 2851

Such elderly women as are past the prospect of marriage,- there is no blame on them if they lay aside their (outer) garments, provided they make not a wanton display of their beauty: but it is best for them to be modest: and Allah is One Who sees and knows all things.

# 2852

It is no fault in the blind nor in one born lame, nor in one afflicted with illness, nor in yourselves, that ye should eat in your own houses, or those of your fathers, or your mothers, or your brothers, or your sisters, or your father's brothers or your father's sisters, or your mother's brothers, or your mother's sisters, or in houses of which the keys are in your possession, or in the house of a sincere friend of yours: there is no blame on you, whether ye eat in company or separately. But if ye enter houses, salute each other - a greeting of blessing and purity as from Allah. Thus does Allah make clear the signs to you: that ye may understand.

# 2853

Only those are believers, who believe in Allah and His Messenger: when they are with him on a matter requiring collective action, they do not depart until they have asked for his leave; those who ask for thy leave are those who believe in Allah and His Messenger; so when they ask for thy leave, for some business of theirs, give leave to those of them whom thou wilt, and ask Allah for their forgiveness: for Allah is Oft-Forgiving, Most Merciful.

# 2854

Deem not the summons of the Messenger among yourselves like the summons of one of you to another: Allah doth know those of you who slip away under shelter of some excuse: then let those beware who withstand the Messenger's order, lest some trial befall them, or a grievous penalty be inflicted on them.

# 2855

Be quite sure that to Allah doth belong whatever is in the heavens and on earth. Well doth He know what ye are intent upon: and one day they will be brought back to Him, and He will tell them the truth of what they did: for Allah doth know all things.

# 2856

Blessed is He who sent down the criterion to His servant, that it may be an admonition to all creatures;-

# 2857

He to whom belongs the dominion of the heavens and the earth: no son has He begotten, nor has He a partner in His dominion: it is He who created all things, and ordered them in due proportions.

# 2858

Yet have they taken, besides him, gods that can create nothing but are themselves created; that have no control of hurt or good to themselves; nor can they control death nor life nor resurrection.

# 2859

But the misbelievers say: "Naught is this but a lie which he has forged, and others have helped him at it." In truth it is they who have put forward an iniquity and a falsehood.

# 2860

And they say: "Tales of the ancients, which he has caused to be written: and they are dictated before him morning and evening."

# 2861

Say: "The (Qur'an) was sent down by Him who knows the mystery (that is) in the heavens and the earth: verily He is Oft-Forgiving, Most Merciful."

# 2862

And they say: "What sort of a messenger is this, who eats food, and walks through the streets? Why has not an angel been sent down to him to give admonition with him?

# 2863

"Or (Why) has not a treasure been bestowed on him, or why has he (not) a garden for enjoyment?" The wicked say: "Ye follow none other than a man bewitched."

# 2864

See what kinds of comparisons they make for thee! But they have gone astray, and never a way will they be able to find!

# 2865

Blessed is He who, if that were His will, could give thee better (things) than those,- Gardens beneath which rivers flow; and He could give thee palaces (secure to dwell in).

# 2866

Nay they deny the hour (of the judgment to come): but We have prepared a blazing fire for such as deny the hour:

# 2867

When it sees them from a place far off, they will hear its fury and its ranging sigh.

# 2868

And when they are cast, bound together into a constricted place therein, they will plead for destruction there and then!

# 2869

"This day plead not for a single destruction: plead for destruction oft-repeated!"

# 2870

Say: "Is that best, or the eternal garden, promised to the righteous? for them, that is a reward as well as a goal (of attainment).

# 2871

"For them there will be therein all that they wish for: they will dwell (there) for aye: A promise to be prayed for from thy Lord."

# 2872

The day He will gather them together as well as those whom they worship besides Allah, He will ask: "Was it ye who let these My servants astray, or did they stray from the Path themselves?"

# 2873

They will say: "Glory to Thee! not meet was it for us that we should take for protectors others besides Thee: But Thou didst bestow, on them and their fathers, good things (in life), until they forgot the Message: for they were a people (worthless and) lost."

# 2874

(Allah will say): "Now have they proved you liars in what ye say: so ye cannot avert (your penalty) nor (get) help." And whoever among you does wrong, him shall We cause to taste of a grievous Penalty.

# 2875

And the messengers whom We sent before thee were all (men) who ate food and walked through the streets: We have made some of you as a trial for others: will ye have patience? for Allah is One Who sees (all things).

# 2876

Such as fear not the meeting with Us (for Judgment) say: "Why are not the angels sent down to us, or (why) do we not see our Lord?" Indeed they have an arrogant conceit of themselves, and mighty is the insolence of their impiety!

# 2877

The Day they see the angels,- no joy will there be to the sinners that Day: The (angels) will say: "There is a barrier forbidden (to you) altogether!"

# 2878

And We shall turn to whatever deeds they did (in this life), and We shall make such deeds as floating dust scattered about.

# 2879

The Companions of the Garden will be well, that Day, in their abode, and have the fairest of places for repose.

# 2880

The Day the heaven shall be rent asunder with clouds, and angels shall be sent down, descending (in ranks),-

# 2881

That Day, the dominion as of right and truth, shall be (wholly) for (Allah) Most Merciful: it will be a Day of dire difficulty for the misbelievers.

# 2882

The Day that the wrong-doer will bite at his hands, he will say, "Oh! would that I had taken a (straight) path with the Messenger!

# 2883

"Ah! woe is me! Would that I had never taken such a one for a friend!

# 2884

"He did lead me astray from the Message (of Allah) after it had come to me! Ah! the Evil One is but a traitor to man!"

# 2885

Then the Messenger will say: "O my Lord! Truly my people took this Qur'an for just foolish nonsense."

# 2886

Thus have We made for every prophet an enemy among the sinners: but enough is thy Lord to guide and to help.

# 2887

Those who reject Faith say: "Why is not the Qur'an revealed to him all at once? Thus (is it revealed), that We may strengthen thy heart thereby, and We have rehearsed it to thee in slow, well-arranged stages, gradually.

# 2888

And no question do they bring to thee but We reveal to thee the truth and the best explanation (thereof).

# 2889

Those who will be gathered to Hell (prone) on their faces,- they will be in an evil plight, and, as to Path, most astray.

# 2890

(Before this,) We sent Moses The Book, and appointed his brother Aaron with him as minister;

# 2891

And We command: "Go ye both, to the people who have rejected our Signs:" And those (people) We destroyed with utter destruction.

# 2892

And the people of Noah,- when they rejected the messengers, We drowned them, and We made them as a Sign for mankind; and We have prepared for (all) wrong-doers a grievous Penalty;-

# 2893

As also 'Ad and Thamud, and the Companions of the Rass, and many a generation between them.

# 2894

To each one We set forth Parables and examples; and each one We broke to utter annihilation (for their sins).

# 2895

And the (Unbelievers) must indeed have passed by the town on which was rained a shower of evil: did they not then see it (with their own eyes)? But they fear not the Resurrection.

# 2896

When they see thee, they treat thee no otherwise than in mockery: "Is this the one whom Allah has sent as a messenger?"

# 2897

"He indeed would well-nigh have misled us from our gods, had it not been that we were constant to them!" - Soon will they know, when they see the Penalty, who it is that is most misled in Path!

# 2898

Seest thou such a one as taketh for his god his own passion (or impulse)? Couldst thou be a disposer of affairs for him?

# 2899

Or thinkest thou that most of them listen or understand? They are only like cattle;- nay, they are worse astray in Path.

# 2900

Hast thou not turned thy vision to thy Lord?- How He doth prolong the shadow! If He willed, He could make it stationary! then do We make the sun its guide;

# 2901

Then We draw it in towards Ourselves,- a contraction by easy stages.

# 2902

And He it is Who makes the Night as a Robe for you, and Sleep as Repose, and makes the Day (as it were) a Resurrection.

# 2903

And He it is Who sends the winds as heralds of glad tidings, going before His mercy, and We send down pure water from the sky,-

# 2904

That with it We may give life to a dead land, and slake the thirst of things We have created,- cattle and men in great numbers.

# 2905

And We have distributed the (water) amongst them, in order that they may celebrate (our) praises, but most men are averse (to aught) but (rank) ingratitude.

# 2906

Had it been Our Will, We could have sent a warner to every centre of population.

# 2907

Therefore listen not to the Unbelievers, but strive against them with the utmost strenuousness, with the (Qur'an).

# 2908

It is He Who has let free the two bodies of flowing water: One palatable and sweet, and the other salt and bitter; yet has He made a barrier between them, a partition that is forbidden to be passed.

# 2909

It is He Who has created man from water: then has He established relationships of lineage and marriage: for thy Lord has power (over all things).

# 2910

Yet do they worship, besides Allah, things that can neither profit them nor harm them: and the Misbeliever is a helper (of Evil), against his own Lord!

# 2911

But thee We only sent to give glad tidings and admonition.

# 2912

Say: "No reward do I ask of you for it but this: that each one who will may take a (straight) Path to his Lord."

# 2913

And put thy trust in Him Who lives and dies not; and celebrate his praise; and enough is He to be acquainted with the faults of His servants;-

# 2914

He Who created the heavens and the earth and all that is between, in six days, and is firmly established on the Throne (of Authority): Allah Most Gracious: ask thou, then, about Him of any acquainted (with such things).

# 2915

When it is said to them, "Prostrate to (Allah) Most Gracious!", they say, "And what is (Allah) Most Gracious? Shall we prostrate to that which thou commandest us?" And it increases their flight (from the Truth).

# 2916

Blessed is He Who made constellations in the skies, and placed therein a Lamp and a Moon giving light;

# 2917

And it is He Who made the Night and the Day to follow each other: for such as have the will to celebrate His praises or to show their gratitude.

# 2918

And the servants of (Allah) Most Gracious are those who walk on the earth in humility, and when the ignorant address them, they say, "Peace!";

# 2919

Those who spend the night in adoration of their Lord prostrate and standing;

# 2920

Those who say, "Our Lord! avert from us the Wrath of Hell, for its Wrath is indeed an affliction grievous,-

# 2921

"Evil indeed is it as an abode, and as a place to rest in";

# 2922

Those who, when they spend, are not extravagant and not niggardly, but hold a just (balance) between those (extremes);

# 2923

Those who invoke not, with Allah, any other god, nor slay such life as Allah has made sacred except for just cause, nor commit fornication; - and any that does this (not only) meets punishment.

# 2924

(But) the Penalty on the Day of Judgment will be doubled to him, and he will dwell therein in ignominy,-

# 2925

Unless he repents, believes, and works righteous deeds, for Allah will change the evil of such persons into good, and Allah is Oft-Forgiving, Most Merciful,

# 2926

And whoever repents and does good has truly turned to Allah with an (acceptable) conversion;-

# 2927

Those who witness no falsehood, and, if they pass by futility, they pass by it with honourable (avoidance);

# 2928

Those who, when they are admonished with the Signs of their Lord, droop not down at them as if they were deaf or blind;

# 2929

And those who pray, "Our Lord! Grant unto us wives and offspring who will be the comfort of our eyes, and give us (the grace) to lead the righteous."

# 2930

Those are the ones who will be rewarded with the highest place in heaven, because of their patient constancy: therein shall they be met with salutations and peace,

# 2931

Dwelling therein;- how beautiful an abode and place of rest!

# 2932

Say (to the Rejecters): "My Lord is not uneasy because of you if ye call not on Him: But ye have indeed rejected (Him), and soon will come the inevitable (punishment)!"

# 2933

Ta. Sin. Mim.

# 2934

These are verses of the Book that makes (things) clear.

# 2935

It may be thou frettest thy soul with grief, that they do not become Believers.

# 2936

If (such) were Our Will, We could send down to them from the sky a Sign, to which they would bend their necks in humility.

# 2937

But there comes not to them a newly-revealed Message from (Allah) Most Gracious, but they turn away therefrom.

# 2938

They have indeed rejected (the Message): so they will know soon (enough) the truth of what they mocked at!

# 2939

Do they not look at the earth,- how many noble things of all kinds We have produced therein?

# 2940

Verily, in this is a Sign: but most of them do not believe.

# 2941

And verily, thy Lord is He, the Exalted in Might, Most Merciful.

# 2942

Behold, thy Lord called Moses: "Go to the people of iniquity,-

# 2943

"The people of the Pharaoh: will they not fear Allah?"

# 2944

He said: "O my Lord! I do fear that they will charge me with falsehood:

# 2945

"My breast will be straitened. And my speech may not go (smoothly): so send unto Aaron.

# 2946

"And (further), they have a charge of crime against me; and I fear they may slay me."

# 2947

Allah said: "By no means! proceed then, both of you, with Our Signs; We are with you, and will listen (to your call).

# 2948

"So go forth, both of you, to Pharaoh, and say: 'We have been sent by the Lord and Cherisher of the worlds;

# 2949

"'Send thou with us the Children of Israel.'"

# 2950

(Pharaoh) said: "Did we not cherish thee as a child among us, and didst thou not stay in our midst many years of thy life?

# 2951

"And thou didst a deed of thine which (thou knowest) thou didst, and thou art an ungrateful (wretch)!"

# 2952

Moses said: "I did it then, when I was in error.

# 2953

"So I fled from you (all) when I feared you; but my Lord has (since) invested me with judgment (and wisdom) and appointed me as one of the messengers.

# 2954

"And this is the favour with which thou dost reproach me,- that thou hast enslaved the Children of Israel!"

# 2955

Pharaoh said: "And what is the 'Lord and Cherisher of the worlds'?"

# 2956

(Moses) said: "The Lord and Cherisher of the heavens and the earth, and all between,- if ye want to be quite sure."

# 2957

(Pharaoh) said to those around: "Did ye not listen (to what he says)?"

# 2958

(Moses) said: "Your Lord and the Lord of your fathers from the beginning!"

# 2959

(Pharaoh) said: "Truly your messenger who has been sent to you is a veritable madman!"

# 2960

(Moses) said: "Lord of the East and the West, and all between! if ye only had sense!"

# 2961

(Pharaoh) said: "If thou dost put forward any god other than me, I will certainly put thee in prison!"

# 2962

(Moses) said: "Even if I showed you something clear (and) convincing?"

# 2963

(Pharaoh) said: "Show it then, if thou tellest the truth!"

# 2964

So (Moses) threw his rod, and behold, it was a serpent, plain (for all to see)!

# 2965

And he drew out his hand, and behold, it was white to all beholders!

# 2966

(Pharaoh) said to the Chiefs around him: "This is indeed a sorcerer well-versed:

# 2967

"His plan is to get you out of your land by his sorcery; then what is it ye counsel?"

# 2968

They said: "Keep him and his brother in suspense (for a while), and dispatch to the Cities heralds to collect-

# 2969

"And bring up to thee all (our) sorcerers well-versed."

# 2970

So the sorcerers were got together for the appointment of a day well-known,

# 2971

And the people were told: "Are ye (now) assembled?-

# 2972

"That we may follow the sorcerers (in religion) if they win?"

# 2973

So when the sorcerers arrived, they said to Pharaoh: "Of course - shall we have a (suitable) reward if we win?

# 2974

He said: "Yea, (and more),- for ye shall in that case be (raised to posts) nearest (to my person)."

# 2975

Moses said to them: "Throw ye - that which ye are about to throw!"

# 2976

So they threw their ropes and their rods, and said: "By the might of Pharaoh, it is we who will certainly win!"

# 2977

Then Moses threw his rod, when, behold, it straightway swallows up all the falsehoods which they fake!

# 2978

Then did the sorcerers fall down, prostrate in adoration,

# 2979

Saying: "We believe in the Lord of the Worlds,

# 2980

"The Lord of Moses and Aaron."

# 2981

Said (Pharaoh): "Believe ye in Him before I give you permission? surely he is your leader, who has taught you sorcery! but soon shall ye know! Be sure I will cut off your hands and your feet on opposite sides, and I will cause you all to die on the cross!"

# 2982

They said: "No matter! for us, we shall but return to our Lord!

# 2983

"Only, our desire is that our Lord will forgive us our faults, that we may become foremost among the believers!"

# 2984

By inspiration we told Moses: "Travel by night with my servants; for surely ye shall be pursued."

# 2985

Then Pharaoh sent heralds to (all) the Cities,

# 2986

(Saying): "These (Israelites) are but a small band,

# 2987

"And they are raging furiously against us;

# 2988

"But we are a multitude amply fore-warned."

# 2989

So We expelled them from gardens, springs,

# 2990

Treasures, and every kind of honourable position;

# 2991

Thus it was, but We made the Children of Israel inheritors of such things.

# 2992

So they pursued them at sunrise.

# 2993

And when the two bodies saw each other, the people of Moses said: "We are sure to be overtaken."

# 2994

(Moses) said: "By no means! my Lord is with me! Soon will He guide me!"

# 2995

Then We told Moses by inspiration: "Strike the sea with thy rod." So it divided, and each separate part became like the huge, firm mass of a mountain.

# 2996

And We made the other party approach thither.

# 2997

We delivered Moses and all who were with him;

# 2998

But We drowned the others.

# 2999

Verily in this is a Sign: but most of them do not believe.

# 3000

And verily thy Lord is He, the Exalted in Might, Most Merciful.

# 3001

And rehearse to them (something of) Abraham's story.

# 3002

Behold, he said to his father and his people: "What worship ye?"

# 3003

They said: "We worship idols, and we remain constantly in attendance on them."

# 3004

He said: "Do they listen to you when ye call (on them)?"

# 3005

"Or do you good or harm?"

# 3006

They said: "Nay, but we found our fathers doing thus (what we do)."

# 3007

He said: "Do ye then see whom ye have been worshipping,-

# 3008

"Ye and your fathers before you?-

# 3009

"For they are enemies to me; not so the Lord and Cherisher of the Worlds;

# 3010

"Who created me, and it is He Who guides me;

# 3011

"Who gives me food and drink,

# 3012

"And when I am ill, it is He Who cures me;

# 3013

"Who will cause me to die, and then to life (again);

# 3014

"And who, I hope, will forgive me my faults on the day of Judgment.

# 3015

"O my Lord! bestow wisdom on me, and join me with the righteous;

# 3016

"Grant me honourable mention on the tongue of truth among the latest (generations);

# 3017

"Make me one of the inheritors of the Garden of Bliss;

# 3018

"Forgive my father, for that he is among those astray;

# 3019

"And let me not be in disgrace on the Day when (men) will be raised up;-

# 3020

"The Day whereon neither wealth nor sons will avail,

# 3021

"But only he (will prosper) that brings to Allah a sound heart;

# 3022

"To the righteous, the Garden will be brought near,

# 3023

"And to those straying in Evil, the Fire will be placed in full view;

# 3024

"And it shall be said to them: 'Where are the (gods) ye worshipped-

# 3025

"'Besides Allah? Can they help you or help themselves?'

# 3026

"Then they will be thrown headlong into the (Fire),- they and those straying in Evil,

# 3027

"And the whole hosts of Iblis together.

# 3028

"They will say there in their mutual bickerings:

# 3029

"'By Allah, we were truly in an error manifest,

# 3030

"'When we held you as equals with the Lord of the Worlds;

# 3031

"'And our seducers were only those who were steeped in guilt.

# 3032

"'Now, then, we have none to intercede (for us),

# 3033

"'Nor a single friend to feel (for us).

# 3034

"'Now if we only had a chance of return we shall truly be of those who believe!'"

# 3035

Verily in this is a Sign but most of them do not believe.

# 3036

And verily thy Lord is He, the Exalted in Might, Most Merciful.

# 3037

The people of Noah rejected the messengers.

# 3038

Behold, their brother Noah said to them: "Will ye not fear (Allah)?

# 3039

"I am to you a messenger worthy of all trust:

# 3040

"So fear Allah, and obey me.

# 3041

"No reward do I ask of you for it: my reward is only from the Lord of the Worlds:

# 3042

"So fear Allah, and obey me."

# 3043

They said: "Shall we believe in thee when it is the meanest that follow thee?"

# 3044

He said: "And what do I know as to what they do?

# 3045

"Their account is only with my Lord, if ye could (but) understand.

# 3046

"I am not one to drive away those who believe.

# 3047

"I am sent only to warn plainly in public."

# 3048

They said: "If thou desist not, O Noah! thou shalt be stoned (to death)."

# 3049

He said: "O my Lord! truly my people have rejected me.

# 3050

"Judge Thou, then, between me and them openly, and deliver me and those of the Believers who are with me."

# 3051

So We delivered him and those with him, in the Ark filled (with all creatures).

# 3052

Thereafter We drowned those who remained behind.

# 3053

Verily in this is a Sign: but most of them do not believe.

# 3054

And verily thy Lord is He, the Exalted in Might, Most Merciful.

# 3055

The 'Ad (people) rejected the messengers.

# 3056

Behold, their brother Hud said to them: "Will ye not fear (Allah)?

# 3057

"I am to you a messenger worthy of all trust:

# 3058

"So fear Allah and obey me.

# 3059

"No reward do I ask of you for it: my reward is only from the Lord of the Worlds.

# 3060

"Do ye build a landmark on every high place to amuse yourselves?

# 3061

"And do ye get for yourselves fine buildings in the hope of living therein (for ever)?

# 3062

"And when ye exert your strong hand, do ye do it like men of absolute power?

# 3063

"Now fear Allah, and obey me.

# 3064

"Yea, fear Him Who has bestowed on you freely all that ye know.

# 3065

"Freely has He bestowed on you cattle and sons,-

# 3066

"And Gardens and Springs.

# 3067

"Truly I fear for you the Penalty of a Great Day."

# 3068

They said: "It is the same to us whether thou admonish us or be not among (our) admonishers!

# 3069

"This is no other than a customary device of the ancients,

# 3070

"And we are not the ones to receive Pains and Penalties!"

# 3071

So they rejected him, and We destroyed them. Verily in this is a Sign: but most of them do not believe.

# 3072

And verily thy Lord is He, the Exalted in Might, Most Merciful.

# 3073

The Thamud (people) rejected the messengers.

# 3074

Behold, their brother Salih said to them: "Will you not fear (Allah)?

# 3075

"I am to you a messenger worthy of all trust.

# 3076

"So fear Allah, and obey me.

# 3077

"No reward do I ask of you for it: my reward is only from the Lord of the Worlds.

# 3078

"Will ye be left secure, in (the enjoyment of) all that ye have here?-

# 3079

"Gardens and Springs,

# 3080

"And corn-fields and date-palms with spathes near breaking (with the weight of fruit)?

# 3081

"And ye carve houses out of (rocky) mountains with great skill.

# 3082

"But fear Allah and obey me;

# 3083

"And follow not the bidding of those who are extravagant,-

# 3084

"Who make mischief in the land, and mend not (their ways)."

# 3085

They said: "Thou art only one of those bewitched!

# 3086

"Thou art no more than a mortal like us: then bring us a Sign, if thou tellest the truth!"

# 3087

He said: "Here is a she-camel: she has a right of watering, and ye have a right of watering, (severally) on a day appointed.

# 3088

"Touch her not with harm, lest the Penalty of a Great Day seize you."

# 3089

But they ham-strung her: then did they become full of regrets.

# 3090

But the Penalty seized them. Verily in this is a Sign: but most of them do not believe.

# 3091

And verily thy Lord is He, the Exalted in Might, Most Merciful.

# 3092

The people of Lut rejected the messengers.

# 3093

Behold, their brother Lut said to them: "Will ye not fear (Allah)?

# 3094

"I am to you a messenger worthy of all trust.

# 3095

"So fear Allah and obey me.

# 3096

"No reward do I ask of you for it: my reward is only from the lord of the Worlds.

# 3097

"Of all the creatures in the world, will ye approach males,

# 3098

"And leave those whom Allah has created for you to be your mates? Nay, ye are a people transgressing (all limits)!"

# 3099

They said: "If thou desist not, O Lut! thou wilt assuredly be cast out!"

# 3100

He said: "I do detest your doings."

# 3101

"O my Lord! deliver me and my family from such things as they do!"

# 3102

So We delivered him and his family,- all

# 3103

Except an old woman who lingered behind.

# 3104

But the rest We destroyed utterly.

# 3105

We rained down on them a shower (of brimstone): and evil was the shower on those who were admonished (but heeded not)!

# 3106

Verily in this is a Sign: but most of them do not believe.

# 3107

And verily thy Lord is He, the Exalted in Might Most Merciful.

# 3108

The Companions of the Wood rejected the messengers.

# 3109

Behold, Shu'aib said to them: "Will ye not fear (Allah)?

# 3110

"I am to you a messenger worthy of all trust.

# 3111

"So fear Allah and obey me.

# 3112

"No reward do I ask of you for it: my reward is only from the Lord of the Worlds.

# 3113

"Give just measure, and cause no loss (to others by fraud).

# 3114

"And weigh with scales true and upright.

# 3115

"And withhold not things justly due to men, nor do evil in the land, working mischief.

# 3116

"And fear Him Who created you and (who created) the generations before (you)"

# 3117

They said: "Thou art only one of those bewitched!

# 3118

"Thou art no more than a mortal like us, and indeed we think thou art a liar!

# 3119

"Now cause a piece of the sky to fall on us, if thou art truthful!"

# 3120

He said: "My Lord knows best what ye do."

# 3121

But they rejected him. Then the punishment of a day of overshadowing gloom seized them, and that was the Penalty of a Great Day.

# 3122

Verily in that is a Sign: but most of them do not believe.

# 3123

And verily thy Lord is He, the Exalted in Might, Most Merciful.

# 3124

Verily this is a Revelation from the Lord of the Worlds:

# 3125

With it came down the spirit of Faith and Truth-

# 3126

To thy heart and mind, that thou mayest admonish.

# 3127

In the perspicuous Arabic tongue.

# 3128

Without doubt it is (announced) in the mystic Books of former peoples.

# 3129

Is it not a Sign to them that the Learned of the Children of Israel knew it (as true)?

# 3130

Had We revealed it to any of the non-Arabs,

# 3131

And had he recited it to them, they would not have believed in it.

# 3132

Thus have We caused it to enter the hearts of the sinners.

# 3133

They will not believe in it until they see the grievous Penalty;

# 3134

But the (Penalty) will come to them of a sudden, while they perceive it not;

# 3135

Then they will say: "Shall we be respited?"

# 3136

Do they then ask for Our Penalty to be hastened on?

# 3137

Seest thou? If We do let them enjoy (this life) for a few years,

# 3138

Yet there comes to them at length the (Punishment) which they were promised!

# 3139

It will profit them not that they enjoyed (this life)!

# 3140

Never did We destroy a population, but had its warners -

# 3141

By way of reminder; and We never are unjust.

# 3142

No evil ones have brought down this (Revelation):

# 3143

It would neither suit them nor would they be able (to produce it).

# 3144

Indeed they have been removed far from even (a chance of) hearing it.

# 3145

So call not on any other god with Allah, or thou wilt be among those under the Penalty.

# 3146

And admonish thy nearest kinsmen,

# 3147

And lower thy wing to the Believers who follow thee.

# 3148

Then if they disobey thee, say: "I am free (of responsibility) for what ye do!"

# 3149

And put thy trust on the Exalted in Might, the Merciful,-

# 3150

Who seeth thee standing forth (in prayer),

# 3151

And thy movements among those who prostrate themselves,

# 3152

For it is He Who heareth and knoweth all things.

# 3153

Shall I inform you, (O people!), on whom it is that the evil ones descend?

# 3154

They descend on every lying, wicked person,

# 3155

(Into whose ears) they pour hearsay vanities, and most of them are liars.

# 3156

And the Poets,- It is those straying in Evil, who follow them:

# 3157

Seest thou not that they wander distracted in every valley?-

# 3158

And that they say what they practise not?-

# 3159

Except those who believe, work righteousness, engage much in the remembrance of Allah, and defend themselves only after they are unjustly attacked. And soon will the unjust assailants know what vicissitudes their affairs will take!

# 3160

These are verses of the Qur'an,-a book that makes (things) clear;

# 3161

A guide: and glad tidings for the believers,-

# 3162

Those who establish regular prayers and give in regular charity, and also have (full) assurance of the hereafter.

# 3163

As to those who believe not in the Hereafter, We have made their deeds pleasing in their eyes; and so they wander about in distraction.

# 3164

Such are they for whom a grievous Penalty is (waiting); and in the Hereafter theirs will be the greatest loss.

# 3165

As to thee, the Qur'an is bestowed upon thee from the presence of one who is wise and all-knowing.

# 3166

Behold! Moses said to his family: "I perceive a fire; soon will I bring you from there some information, or I will bring you a burning brand to light our fuel, that ye may warm yourselves.

# 3167

But when he came to the (fire), a voice was heard: "Blessed are those in the fire and those around: and glory to Allah, the Lord of the worlds.

# 3168

"O Moses! verily, I am Allah, the exalted in might, the wise!....

# 3169

"Now do thou throw thy rod!" But when he saw it moving (of its own accord) as if it had been a snake, he turned back in retreat, and retraced not his steps: "O Moses!" (it was said), "Fear not: truly, in My presence, those called as messengers have no fear,-

# 3170

"But if any have done wrong and have thereafter substituted good to take the place of evil, truly, I am Oft-Forgiving, Most Merciful.

# 3171

"Now put thy hand into thy bosom, and it will come forth white without stain (or harm): (these are) among the nine Signs (thou wilt take) to Pharaoh and his people: for they are a people rebellious in transgression."

# 3172

But when Our Signs came to them, that should have opened their eyes, they said: "This is sorcery manifest!"

# 3173

And they rejected those Signs in iniquity and arrogance, though their souls were convinced thereof: so see what was the end of those who acted corruptly!

# 3174

We gave (in the past) knowledge to David and Solomon: And they both said: "Praise be to Allah, Who has favoured us above many of his servants who believe!"

# 3175

And Solomon was David's heir. He said: "O ye people! We have been taught the speech of birds, and on us has been bestowed (a little) of all things: this is indeed Grace manifest (from Allah.)"

# 3176

And before Solomon were marshalled his hosts,- of Jinns and men and birds, and they were all kept in order and ranks.

# 3177

At length, when they came to a (lowly) valley of ants, one of the ants said: "O ye ants, get into your habitations, lest Solomon and his hosts crush you (under foot) without knowing it."

# 3178

So he smiled, amused at her speech; and he said: "O my Lord! so order me that I may be grateful for Thy favours, which thou hast bestowed on me and on my parents, and that I may work the righteousness that will please Thee: And admit me, by Thy Grace, to the ranks of Thy righteous Servants."

# 3179

And he took a muster of the Birds; and he said: "Why is it I see not the Hoopoe? Or is he among the absentees?

# 3180

"I will certainly punish him with a severe penalty, or execute him, unless he bring me a clear reason (for absence)."

# 3181

But the Hoopoe tarried not far: he (came up and) said: "I have compassed (territory) which thou hast not compassed, and I have come to thee from Saba with tidings true.

# 3182

"I found (there) a woman ruling over them and provided with every requisite; and she has a magnificent throne.

# 3183

"I found her and her people worshipping the sun besides Allah: Satan has made their deeds seem pleasing in their eyes, and has kept them away from the Path,- so they receive no guidance,-

# 3184

"(Kept them away from the Path), that they should not worship Allah, Who brings to light what is hidden in the heavens and the earth, and knows what ye hide and what ye reveal.

# 3185

"Allah!- there is no god but He!- Lord of the Throne Supreme!"

# 3186

(Solomon) said: "Soon shall we see whether thou hast told the truth or lied!

# 3187

"Go thou, with this letter of mine, and deliver it to them: then draw back from them, and (wait to) see what answer they return"...

# 3188

(The queen) said: "Ye chiefs! here is delivered to me - a letter worthy of respect.

# 3189

"It is from Solomon, and is (as follows): 'In the name of Allah, Most Gracious, Most Merciful:

# 3190

"'Be ye not arrogant against me, but come to me in submission (to the true Religion).'"

# 3191

She said: "Ye chiefs! advise me in (this) my affair: no affair have I decided except in your presence."

# 3192

They said: "We are endued with strength, and given to vehement war: but the command is with thee; so consider what thou wilt command."

# 3193

She said: "Kings, when they enter a country, despoil it, and make the noblest of its people its meanest thus do they behave.

# 3194

"But I am going to send him a present, and (wait) to see with what (answer) return (my) ambassadors."

# 3195

Now when (the embassy) came to Solomon, he said: "Will ye give me abundance in wealth? But that which Allah has given me is better than that which He has given you! Nay it is ye who rejoice in your gift!

# 3196

"Go back to them, and be sure we shall come to them with such hosts as they will never be able to meet: We shall expel them from there in disgrace, and they will feel humbled (indeed)."

# 3197

He said (to his own men): "Ye chiefs! which of you can bring me her throne before they come to me in submission?"

# 3198

Said an 'Ifrit, of the Jinns: "I will bring it to thee before thou rise from thy council: indeed I have full strength for the purpose, and may be trusted."

# 3199

Said one who had knowledge of the Book: "I will bring it to thee within the twinkling of an eye!" Then when (Solomon) saw it placed firmly before him, he said: "This is by the Grace of my Lord!- to test me whether I am grateful or ungrateful! and if any is grateful, truly his gratitude is (a gain) for his own soul; but if any is ungrateful, truly my Lord is Free of all Needs, Supreme in Honour!"

# 3200

He said: "Transform her throne out of all recognition by her: let us see whether she is guided (to the truth) or is one of those who receive no guidance."

# 3201

So when she arrived, she was asked, "Is this thy throne?" She said, "It was just like this; and knowledge was bestowed on us in advance of this, and we have submitted to Allah (in Islam)."

# 3202

And he diverted her from the worship of others besides Allah: for she was (sprung) of a people that had no faith.

# 3203

She was asked to enter the lofty Palace: but when she saw it, she thought it was a lake of water, and she (tucked up her skirts), uncovering her legs. He said: "This is but a palace paved smooth with slabs of glass." She said: "O my Lord! I have indeed wronged my soul: I do (now) submit (in Islam), with Solomon, to the Lord of the Worlds."

# 3204

We sent (aforetime), to the Thamud, their brother Salih, saying, "Serve Allah": But behold, they became two factions quarrelling with each other.

# 3205

He said: "O my people! why ask ye to hasten on the evil in preference to the good? If only ye ask Allah for forgiveness, ye may hope to receive mercy.

# 3206

They said: "Ill omen do we augur from thee and those that are with thee". He said: "Your ill omen is with Allah; yea, ye are a people under trial."

# 3207

There were in the city nine men of a family, who made mischief in the land, and would not reform.

# 3208

They said: "Swear a mutual oath by Allah that we shall make a secret night attack on him and his people, and that we shall then say to his heir (when he seeks vengeance): 'We were not present at the slaughter of his people, and we are positively telling the truth.'"

# 3209

They plotted and planned, but We too planned, even while they perceived it not.

# 3210

Then see what was the end of their plot!- this, that We destroyed them and their people, all (of them).

# 3211

Now such were their houses, - in utter ruin, - because they practised wrong-doing. Verily in this is a Sign for people of knowledge.

# 3212

And We saved those who believed and practised righteousness.

# 3213

(We also sent) Lut (as a messenger): behold, He said to his people, "Do ye do what is shameful though ye see (its iniquity)?

# 3214

Would ye really approach men in your lusts rather than women? Nay, ye are a people (grossly) ignorant!

# 3215

But his people gave no other answer but this: they said, "Drive out the followers of Lut from your city: these are indeed men who want to be clean and pure!"

# 3216

But We saved him and his family, except his wife; her We destined to be of those who lagged behind.

# 3217

And We rained down on them a shower (of brimstone): and evil was the shower on those who were admonished (but heeded not)!

# 3218

Say: Praise be to Allah, and Peace on his servants whom He has chosen (for his Message). (Who) is better?- Allah or the false gods they associate (with Him)?

# 3219

Or, Who has created the heavens and the earth, and Who sends you down rain from the sky? Yea, with it We cause to grow well-planted orchards full of beauty of delight: it is not in your power to cause the growth of the trees in them. (Can there be another) god besides Allah? Nay, they are a people who swerve from justice.

# 3220

Or, Who has made the earth firm to live in; made rivers in its midst; set thereon mountains immovable; and made a separating bar between the two bodies of flowing water? (can there be another) god besides Allah? Nay, most of them know not.

# 3221

Or, Who listens to the (soul) distressed when it calls on Him, and Who relieves its suffering, and makes you (mankind) inheritors of the earth? (Can there be another) god besides Allah? Little it is that ye heed!

# 3222

Or, Who guides you through the depths of darkness on land and sea, and Who sends the winds as heralds of glad tidings, going before His Mercy? (Can there be another) god besides Allah?- High is Allah above what they associate with Him!

# 3223

Or, Who originates creation, then repeats it, and who gives you sustenance from heaven and earth? (Can there be another) god besides Allah? Say, "Bring forth your argument, if ye are telling the truth!"

# 3224

Say: None in the heavens or on earth, except Allah, knows what is hidden: nor can they perceive when they shall be raised up (for Judgment).

# 3225

Still less can their knowledge comprehend the Hereafter: Nay, they are in doubt and uncertainty thereanent; nay, they are blind thereunto!

# 3226

The Unbelievers say: "What! when we become dust,- we and our fathers,- shall we really be raised (from the dead)?

# 3227

"It is true we were promised this,- we and our fathers before (us): these are nothing but tales of the ancients."

# 3228

Say: "Go ye through the earth and see what has been the end of those guilty (of sin)."

# 3229

But grieve not over them, nor distress thyself because of their plots.

# 3230

They also say: "When will this promise (come to pass)? (Say) if ye are truthful."

# 3231

Say: "It may be that some of the events which ye wish to hasten on may be (close) in your pursuit!"

# 3232

But verily thy Lord is full of grace to mankind: Yet most of them are ungrateful.

# 3233

And verily thy Lord knoweth all that their hearts do hide. As well as all that they reveal.

# 3234

Nor is there aught of the unseen, in heaven or earth, but is (recorded) in a clear record.

# 3235

Verily this Qur'an doth explain to the Children of Israel most of the matters in which they disagree.

# 3236

And it certainly is a Guide and a Mercy to those who believe.

# 3237

Verily thy Lord will decide between them by His Decree: and He is Exalted in Might, All-Knowing.

# 3238

So put thy trust in Allah: for thou art on (the path of) manifest Truth.

# 3239

Truly thou canst not cause the dead to listen, nor canst thou cause the deaf to hear the call, (especially) when they turn back in retreat.

# 3240

Nor canst thou be a guide to the blind, (to prevent them) from straying: only those wilt thou get to listen who believe in Our Signs, and they will bow in Islam.

# 3241

And when the Word is fulfilled against them (the unjust), we shall produce from the earth a beast to (face) them: He will speak to them, for that mankind did not believe with assurance in Our Signs.

# 3242

One day We shall gather together from every people a troop of those who reject our Signs, and they shall be kept in ranks,-

# 3243

Until, when they come (before the Judgment-seat), (Allah) will say: "Did ye reject My Signs, though ye comprehended them not in knowledge, or what was it ye did?"

# 3244

And the Word will be fulfilled against them, because of their wrong-doing, and they will be unable to speak (in plea).

# 3245

See they not that We have made the Night for them to rest in and the Day to give them light? Verily in this are Signs for any people that believe!

# 3246

And the Day that the Trumpet will be sounded - then will be smitten with terror those who are in the heavens, and those who are on earth, except such as Allah will please (to exempt): and all shall come to His (Presence) as beings conscious of their lowliness.

# 3247

Thou seest the mountains and thinkest them firmly fixed: but they shall pass away as the clouds pass away: (such is) the artistry of Allah, who disposes of all things in perfect order: for he is well acquainted with all that ye do.

# 3248

If any do good, good will (accrue) to them therefrom; and they will be secure from terror that Day.

# 3249

And if any do evil, their faces will be thrown headlong into the Fire: "Do ye receive a reward other than that which ye have earned by your deeds?"

# 3250

For me, I have been commanded to serve the Lord of this city, Him Who has sanctified it and to Whom (belong) all things: and I am commanded to be of those who bow in Islam to Allah's Will,-

# 3251

And to rehearse the Qur'an: and if any accept guidance, they do it for the good of their own souls, and if any stray, say: "I am only a Warner".

# 3252

And say: "Praise be to Allah, Who will soon show you His Signs, so that ye shall know them"; and thy Lord is not unmindful of all that ye do.

# 3253

Ta. Sin. Mim.

# 3254

These are Verses of the Book that makes (things) clear.

# 3255

We rehearse to thee some of the story of Moses and Pharaoh in Truth, for people who believe.

# 3256

Truly Pharaoh elated himself in the land and broke up its people into sections, depressing a small group among them: their sons he slew, but he kept alive their females: for he was indeed a maker of mischief.

# 3257

And We wished to be Gracious to those who were being depressed in the land, to make them leaders (in Faith) and make them heirs,

# 3258

To establish a firm place for them in the land, and to show Pharaoh, Haman, and their hosts, at their hands, the very things against which they were taking precautions.

# 3259

So We sent this inspiration to the mother of Moses: "Suckle (thy child), but when thou hast fears about him, cast him into the river, but fear not nor grieve: for We shall restore him to thee, and We shall make him one of Our messengers."

# 3260

Then the people of Pharaoh picked him up (from the river): (It was intended) that (Moses) should be to them an adversary and a cause of sorrow: for Pharaoh and Haman and (all) their hosts were men of sin.

# 3261

The wife of Pharaoh said: "(Here is) joy of the eye, for me and for thee: slay him not. It may be that he will be use to us, or we may adopt him as a son." And they perceived not (what they were doing)!

# 3262

But there came to be a void in the heart of the mother of Moses: She was going almost to disclose his (case), had We not strengthened her heart (with faith), so that she might remain a (firm) believer.

# 3263

And she said to the sister of (Moses), "Follow him" so she (the sister) watched him in the character of a stranger. And they knew not.

# 3264

And we ordained that he refused suck at first, until (His sister came up and) said: "Shall I point out to you the people of a house that will nourish and bring him up for you and be sincerely attached to him?"...

# 3265

Thus did We restore him to his mother, that her eye might be comforted, that she might not grieve, and that she might know that the promise of Allah is true: but most of them do not understand.

# 3266

When he reached full age, and was firmly established (in life), We bestowed on him wisdom and knowledge: for thus do We reward those who do good.

# 3267

And he entered the city at a time when its people were not watching: and he found there two men fighting,- one of his own religion, and the other, of his foes. Now the man of his own religion appealed to him against his foe, and Moses struck him with his fist and made an end of him. He said: "This is a work of Evil (Satan): for he is an enemy that manifestly misleads!"

# 3268

He prayed: "O my Lord! I have indeed wronged my soul! Do Thou then forgive me!" So (Allah) forgave him: for He is the Oft-Forgiving, Most Merciful.

# 3269

He said: "O my Lord! For that Thou hast bestowed Thy Grace on me, never shall I be a help to those who sin!"

# 3270

So he saw the morning in the city, looking about, in a state of fear, when behold, the man who had, the day before, sought his help called aloud for his help (again). Moses said to him: "Thou art truly, it is clear, a quarrelsome fellow!"

# 3271

Then, when he decided to lay hold of the man who was an enemy to both of them, that man said: "O Moses! Is it thy intention to slay me as thou slewest a man yesterday? Thy intention is none other than to become a powerful violent man in the land, and not to be one who sets things right!"

# 3272

And there came a man, running, from the furthest end of the City. He said: "O Moses! the Chiefs are taking counsel together about thee, to slay thee: so get thee away, for I do give thee sincere advice."

# 3273

He therefore got away therefrom, looking about, in a state of fear. He prayed "O my Lord! save me from people given to wrong-doing."

# 3274

Then, when he turned his face towards (the land of) Madyan, he said: "I do hope that my Lord will show me the smooth and straight Path."

# 3275

And when he arrived at the watering (place) in Madyan, he found there a group of men watering (their flocks), and besides them he found two women who were keeping back (their flocks). He said: "What is the matter with you?" They said: "We cannot water (our flocks) until the shepherds take back (their flocks): And our father is a very old man."

# 3276

So he watered (their flocks) for them; then he turned back to the shade, and said:"O my Lord! truly am I in (desperate) need of any good that Thou dost send me!"

# 3277

Afterwards one of the (damsels) came (back) to him, walking bashfully. She said: "My father invites thee that he may reward thee for having watered (our flocks) for us." So when he came to him and narrated the story, he said: "Fear thou not: (well) hast thou escaped from unjust people."

# 3278

Said one of the (damsels): "O my (dear) father! engage him on wages: truly the best of men for thee to employ is the (man) who is strong and trusty"....

# 3279

He said: "I intend to wed one of these my daughters to thee, on condition that thou serve me for eight years; but if thou complete ten years, it will be (grace) from thee. But I intend not to place thee under a difficulty: thou wilt find me, indeed, if Allah wills, one of the righteous."

# 3280

He said: "Be that (the agreement) between me and thee: whichever of the two terms I fulfil, let there be no ill-will to me. Be Allah a witness to what we say."

# 3281

Now when Moses had fulfilled the term, and was travelling with his family, he perceived a fire in the direction of Mount Tur. He said to his family: "Tarry ye; I perceive a fire; I hope to bring you from there some information, or a burning firebrand, that ye may warm yourselves."

# 3282

But when he came to the (fire), a voice was heard from the right bank of the valley, from a tree in hallowed ground: "O Moses! Verily I am Allah, the Lord of the Worlds....

# 3283

"Now do thou throw thy rod!" but when he saw it moving (of its own accord) as if it had been a snake, he turned back in retreat, and retraced not his steps: O Moses!" (It was said), "Draw near, and fear not: for thou art of those who are secure.

# 3284

"Move thy hand into thy bosom, and it will come forth white without stain (or harm), and draw thy hand close to thy side (to guard) against fear. Those are the two credentials from thy Lord to Pharaoh and his Chiefs: for truly they are a people rebellious and wicked."

# 3285

He said: "O my Lord! I have slain a man among them, and I fear lest they slay me.

# 3286

"And my brother Aaron - He is more eloquent in speech than I: so send him with me as a helper, to confirm (and strengthen) me: for I fear that they may accuse me of falsehood."

# 3287

He said: "We will certainly strengthen thy arm through thy brother, and invest you both with authority, so they shall not be able to touch you: with Our Sign shall ye triumph,- you two as well as those who follow you."

# 3288

When Moses came to them with Our clear signs, they said: "This is nothing but sorcery faked up: never did we head the like among our fathers of old!"

# 3289

Moses said: "My Lord knows best who it is that comes with guidance from Him and whose end will be best in the Hereafter: certain it is that the wrong-doers will not prosper."

# 3290

Pharaoh said: "O Chiefs! no god do I know for you but myself: therefore, O Haman! light me a (kiln to bake bricks) out of clay, and build me a lofty palace, that I may mount up to the god of Moses: but as far as I am concerned, I think (Moses) is a liar!"

# 3291

And he was arrogant and insolent in the land, beyond reason,- He and his hosts: they thought that they would not have to return to Us!

# 3292

So We seized him and his hosts, and We flung them into the sea: Now behold what was the end of those who did wrong!

# 3293

And we made them (but) leaders inviting to the Fire; and on the Day of Judgment no help shall they find.

# 3294

in this world We made a curse to follow them and on the Day of Judgment they will be among the loathed (and despised).

# 3295

We did reveal to Moses the Book after We had destroyed the earlier generations, (to give) Insight to men, and guidance and Mercy, that they might receive admonition.

# 3296

Thou wast not on the Western side when We decreed the Commission to Moses, nor wast thou a witness (of those events).

# 3297

But We raised up (new) generations, and long were the ages that passed over them; but thou wast not a dweller among the people of Madyan, rehearsing Our Signs to them; but it is We Who send messengers (with inspiration).

# 3298

Nor wast thou at the side of (the Mountain of) Tur when we called (to Moses). Yet (art thou sent) as Mercy from thy Lord, to give warning to a people to whom no warner had come before thee: in order that they may receive admonition.

# 3299

If (We had) not (sent thee to the Quraish),- in case a calamity should seize them for (the deeds) that their hands have sent forth, they might say: "Our Lord! why didst Thou not sent us a messenger? We should then have followed Thy Signs and been amongst those who believe!"

# 3300

But (now), when the Truth has come to them from Ourselves, they say, "Why are not (Signs) sent to him, like those which were sent to Moses?" Do they not then reject (the Signs) which were formerly sent to Moses? They say: "Two kinds of sorcery, each assisting the other!" And they say: "For us, we reject all (such things)!"

# 3301

Say: "Then bring ye a Book from Allah, which is a better guide than either of them, that I may follow it! (do), if ye are truthful!"

# 3302

But if they hearken not to thee, know that they only follow their own lusts: and who is more astray than one who follow his own lusts, devoid of guidance from Allah? for Allah guides not people given to wrong-doing.

# 3303

Now have We caused the Word to reach them themselves, in order that they may receive admonition.

# 3304

Those to whom We sent the Book before this,- they do believe in this (revelation):

# 3305

And when it is recited to them, they say: "We believe therein, for it is the Truth from our Lord: indeed we have been Muslims (bowing to Allah's Will) from before this.

# 3306

Twice will they be given their reward, for that they have persevered, that they avert Evil with Good, and that they spend (in charity) out of what We have given them.

# 3307

And when they hear vain talk, they turn away therefrom and say: "To us our deeds, and to you yours; peace be to you: we seek not the ignorant."

# 3308

It is true thou wilt not be able to guide every one, whom thou lovest; but Allah guides those whom He will and He knows best those who receive guidance.

# 3309

They say: "If we were to follow the guidance with thee, we should be snatched away from our land." Have We not established for them a secure sanctuary, to which are brought as tribute fruits of all kinds,- a provision from Ourselves? but most of them understand not.

# 3310

And how many populations We destroyed, which exulted in their life (of ease and plenty)! now those habitations of theirs, after them, are deserted,- All but a (miserable) few! and We are their heirs!

# 3311

Nor was thy Lord the one to destroy a population until He had sent to its centre a messenger, rehearsing to them Our Signs; nor are We going to destroy a population except when its members practise iniquity.

# 3312

The (material) things which ye are given are but the conveniences of this life and the glitter thereof; but that which is with Allah is better and more enduring: will ye not then be wise?

# 3313

Are (these two) alike?- one to whom We have made a goodly promise, and who is going to reach its (fulfilment), and one to whom We have given the good things of this life, but who, on the Day of Judgment, is to be among those brought up (for punishment)?

# 3314

That Day (Allah) will call to them, and say "Where are my 'partners'?- whom ye imagined (to be such)?"

# 3315

Those against whom the charge will be proved, will say: "Our Lord! These are the ones whom we led astray: we led them astray, as we were astray ourselves: we free ourselves (from them) in Thy presence: it was not us they worshipped."

# 3316

It will be said (to them): "Call upon your 'partners' (for help)": they will call upon them, but they will not listen to them; and they will see the Penalty (before them); (how they will wish) 'if only they had been open to guidance!'

# 3317

That Day (Allah) will call to them, and say: "What was the answer ye gave to the messengers?"

# 3318

Then the (whole) story that Day will seem obscure to them (like light to the blind) and they will not be able (even) to question each other.

# 3319

But any that (in this life) had repented, believed, and worked righteousness, will have hopes to be among those who achieve salvation.

# 3320

Thy Lord does create and choose as He pleases: no choice have they (in the matter): Glory to Allah! and far is He above the partners they ascribe (to Him)!

# 3321

And thy Lord knows all that their hearts conceal and all that they reveal.

# 3322

And He is Allah: There is no god but He. To Him be praise, at the first and at the last: for Him is the Command, and to Him shall ye (all) be brought back.

# 3323

Say: See ye? If Allah were to make the night perpetual over you to the Day of Judgment, what god is there other than Allah, who can give you enlightenment? Will ye not then hearken?

# 3324

Say: See ye? If Allah were to make the day perpetual over you to the Day of Judgment, what god is there other than Allah, who can give you a night in which ye can rest? Will ye not then see?

# 3325

It is out of His Mercy that He has made for you Night and Day,- that ye may rest therein, and that ye may seek of his Grace;- and in order that ye may be grateful.

# 3326

The Day that He will call on them, He will say: "Where are my 'partners'? whom ye imagined (to be such)?"

# 3327

And from each people shall We draw a witness, and We shall say: "Produce your Proof": then shall they know that the Truth is in Allah (alone), and the (lies) which they invented will leave them in lurch.

# 3328

Qarun was doubtless, of the people of Moses; but he acted insolently towards them: such were the treasures We had bestowed on him that their very keys would have been a burden to a body of strong men, behold, his people said to him: "Exult not, for Allah loveth not those who exult (in riches).

# 3329

"But seek, with the (wealth) which Allah has bestowed on thee, the Home of the Hereafter, nor forget thy portion in this world: but do thou good, as Allah has been good to thee, and seek not (occasions for) mischief in the land: for Allah loves not those who do mischief."

# 3330

He said: "This has been given to me because of a certain knowledge which I have." Did he not know that Allah had destroyed, before him, (whole) generations,- which were superior to him in strength and greater in the amount (of riches) they had collected? but the wicked are not called (immediately) to account for their sins.

# 3331

So he went forth among his people in the (pride of his wordly) glitter. Said those whose aim is the Life of this World: "Oh! that we had the like of what Qarun has got! for he is truly a lord of mighty good fortune!"

# 3332

But those who had been granted (true) knowledge said: "Alas for you! The reward of Allah (in the Hereafter) is best for those who believe and work righteousness: but this none shall attain, save those who steadfastly persevere (in good)."

# 3333

Then We caused the earth to swallow up him and his house; and he had not (the least little) party to help him against Allah, nor could he defend himself.

# 3334

And those who had envied his position the day before began to say on the morrow: "Ah! it is indeed Allah Who enlarges the provision or restricts it, to any of His servants He pleases! had it not been that Allah was gracious to us, He could have caused the earth to swallow us up! Ah! those who reject Allah will assuredly never prosper."

# 3335

That Home of the Hereafter We shall give to those who intend not high-handedness or mischief on earth: and the end is (best) for the righteous.

# 3336

If any does good, the reward to him is better than his deed; but if any does evil, the doers of evil are only punished (to the extent) of their deeds.

# 3337

Verily He Who ordained the Qur'an for thee, will bring thee back to the Place of Return. Say: "My Lord knows best who it is that brings true guidance, and who is in manifest error."

# 3338

And thou hadst not expected that the Book would be sent to thee except as a Mercy from thy Lord: Therefore lend not thou support in any way to those who reject (Allah's Message).

# 3339

And let nothing keep thee back from the Signs of Allah after they have been revealed to thee: and invite (men) to thy Lord, and be not of the company of those who join gods with Allah.

# 3340

And call not, besides Allah, on another god. There is no god but He. Everything (that exists) will perish except His own Face. To Him belongs the Command, and to Him will ye (all) be brought back.

# 3341

A. L. M.

# 3342

Do men think that they will be left alone on saying, "We believe", and that they will not be tested?

# 3343

We did test those before them, and Allah will certainly know those who are true from those who are false.

# 3344

Do those who practise evil think that they will get the better of Us? Evil is their judgment!

# 3345

For those whose hopes are in the meeting with Allah (in the Hereafter, let them strive); for the term (appointed) by Allah is surely coming and He hears and knows (all things).

# 3346

And if any strive (with might and main), they do so for their own souls: for Allah is free of all needs from all creation.

# 3347

Those who believe and work righteous deeds,- from them shall We blot out all evil (that may be) in them, and We shall reward them according to the best of their deeds.

# 3348

We have enjoined on man kindness to parents: but if they (either of them) strive (to force) thee to join with Me (in worship) anything of which thou hast no knowledge, obey them not. Ye have (all) to return to me, and I will tell you (the truth) of all that ye did.

# 3349

And those who believe and work righteous deeds,- them shall We admit to the company of the Righteous.

# 3350

Then there are among men such as say, "We believe in Allah"; but when they suffer affliction in (the cause of) Allah, they treat men's oppression as if it were the Wrath of Allah! And if help comes (to thee) from thy Lord, they are sure to say, "We have (always) been with you!" Does not Allah know best all that is in the hearts of all creation?

# 3351

And Allah most certainly knows those who believe, and as certainly those who are Hypocrites.

# 3352

And the Unbelievers say to those who believe: "Follow our path, and we will bear (the consequences) of your faults." Never in the least will they bear their faults: in fact they are liars!

# 3353

They will bear their own burdens, and (other) burdens along with their own, and on the Day of Judgments they will be called to account for their falsehoods.

# 3354

We (once) sent Noah to his people, and he tarried among them a thousand years less fifty: but the Deluge overwhelmed them while they (persisted in) sin.

# 3355

But We saved him and the companions of the Ark, and We made the (Ark) a Sign for all peoples!

# 3356

And (We also saved) Abraham: behold, he said to his people, "Serve Allah and fear Him: that will be best for you- If ye understand!

# 3357

"For ye do worship idols besides Allah, and ye invent falsehood. The things that ye worship besides Allah have no power to give you sustenance: then seek ye sustenance from Allah, serve Him, and be grateful to Him: to Him will be your return.

# 3358

"And if ye reject (the Message), so did generations before you: and the duty of the messenger is only to preach publicly (and clearly)."

# 3359

See they not how Allah originates creation, then repeats it: truly that is easy for Allah.

# 3360

Say: "Travel through the earth and see how Allah did originate creation; so will Allah produce a later creation: for Allah has power over all things.

# 3361

"He punishes whom He pleases, and He grants Mercy to whom He pleases, and towards Him are ye turned.

# 3362

"Not on earth nor in heaven will ye be able (fleeing) to frustrate (his Plan), nor have ye, besides Allah, any protector or helper."

# 3363

Those who reject the Signs of Allah and the Meeting with Him (in the Hereafter),- it is they who shall despair of My Mercy: it is they who will (suffer) a most grievous Penalty.

# 3364

So naught was the answer of (Abraham's) people except that they said: "Slay him or burn him." But Allah did save him from the Fire. Verily in this are Signs for people who believe.

# 3365

And he said: "For you, ye have taken (for worship) idols besides Allah, out of mutual love and regard between yourselves in this life; but on the Day of Judgment ye shall disown each other and curse each other: and your abode will be the Fire, and ye shall have none to help."

# 3366

But Lut had faith in Him: He said: "I will leave home for the sake of my Lord: for He is Exalted in Might, and Wise."

# 3367

And We gave (Abraham) Isaac and Jacob, and ordained among his progeny Prophethood and Revelation, and We granted him his reward in this life; and he was in the Hereafter (of the company) of the Righteous.

# 3368

And (remember) Lut: behold, he said to his people: "Ye do commit lewdness, such as no people in Creation (ever) committed before you.

# 3369

"Do ye indeed approach men, and cut off the highway?- and practise wickedness (even) in your councils?" But his people gave no answer but this: they said: "Bring us the Wrath of Allah if thou tellest the truth."

# 3370

He said: "O my Lord! help Thou me against people who do mischief!"

# 3371

When Our Messengers came to Abraham with the good news, they said: "We are indeed going to destroy the people of this township: for truly they are (addicted to) crime."

# 3372

He said: "But there is Lut there." They said: "Well do we know who is there: we will certainly save him and his following,- except his wife: she is of those who lag behind!"

# 3373

And when Our Messengers came to Lut, he was grieved on their account, and felt himself powerless (to protect) them: but they said: "Fear thou not, nor grieve: we are (here) to save thee and thy following, except thy wife: she is of those who lag behind.

# 3374

"For we are going to bring down on the people of this township a Punishment from heaven, because they have been wickedly rebellious."

# 3375

And We have left thereof an evident Sign, for any people who (care to) understand.

# 3376

To the Madyan (people) (We sent) their brother Shu'aib. Then he said: "O my people! serve Allah, and fear the Last Day: nor commit evil on the earth, with intent to do mischief."

# 3377

But they rejected him: Then the mighty Blast seized them, and they lay prostrate in their homes by the morning.

# 3378

(Remember also) the 'Ad and the Thamud (people): clearly will appear to you from (the traces) of their buildings (their fate): the Evil One made their deeds alluring to them, and kept them back from the Path, though they were gifted with intelligence and skill.

# 3379

(Remember also) Qarun, Pharaoh, and Haman: there came to them Moses with Clear Signs, but they behaved with insolence on the earth; yet they could not overreach (Us).

# 3380

Each one of them We seized for his crime: of them, against some We sent a violent tornado (with showers of stones); some were caught by a (mighty) Blast; some We caused the earth to swallow up; and some We drowned (in the waters): It was not Allah Who injured (or oppressed) them:" They injured (and oppressed) their own souls.

# 3381

The parable of those who take protectors other than Allah is that of the spider, who builds (to itself) a house; but truly the flimsiest of houses is the spider's house;- if they but knew.

# 3382

Verily Allah doth know of (every thing) whatever that they call upon besides Him: and He is Exalted (in power), Wise.

# 3383

And such are the Parables We set forth for mankind, but only those understand them who have knowledge.

# 3384

Allah created the heavens and the earth in true (proportions): verily in that is a Sign for those who believe.

# 3385

Recite what is sent of the Book by inspiration to thee, and establish regular Prayer: for Prayer restrains from shameful and unjust deeds; and remembrance of Allah is the greatest (thing in life) without doubt. And Allah knows the (deeds) that ye do.

# 3386

And dispute ye not with the People of the Book, except with means better (than mere disputation), unless it be with those of them who inflict wrong (and injury): but say, "We believe in the revelation which has come down to us and in that which came down to you; Our Allah and your Allah is one; and it is to Him we bow (in Islam)."

# 3387

And thus (it is) that We have sent down the Book to thee. So the People of the Book believe therein, as also do some of these (pagan Arabs): and none but Unbelievers reject our signs.

# 3388

And thou wast not (able) to recite a Book before this (Book came), nor art thou (able) to transcribe it with thy right hand: In that case, indeed, would the talkers of vanities have doubted.

# 3389

Nay, here are Signs self-evident in the hearts of those endowed with knowledge: and none but the unjust reject Our Signs.

# 3390

Ye they say: "Why are not Signs sent down to him from his Lord?" Say: "The signs are indeed with Allah: and I am indeed a clear Warner."

# 3391

And is it not enough for them that we have sent down to thee the Book which is rehearsed to them? Verily, in it is Mercy and a Reminder to those who believe.

# 3392

Say: "Enough is Allah for a witness between me and you: He knows what is in the heavens and on earth. And it is those who believe in vanities and reject Allah, that will perish (in the end).

# 3393

They ask thee to hasten on the Punishment (for them): had it not been for a term (of respite) appointed, the Punishment would certainly have come to them: and it will certainly reach them,- of a sudden, while they perceive not!

# 3394

They ask thee to hasten on the Punishment: but, of a surety, Hell will encompass the Rejecters of Faith!-

# 3395

On the Day that the Punishment shall cover them from above them and from below them, and (a Voice) shall say: "Taste ye (the fruits) of your deeds!"

# 3396

O My servants who believe! truly, spacious is My Earth: therefore serve ye Me - (and Me alone)!

# 3397

Every soul shall have a taste of death in the end to Us shall ye be brought back.

# 3398

But those who believe and work deeds of righteousness - to them shall We give a Home in Heaven,- lofty mansions beneath which flow rivers,- to dwell therein for aye;- an excellent reward for those who do (good)!-

# 3399

Those who persevere in patience, and put their trust, in their Lord and Cherisher.

# 3400

How many are the creatures that carry not their own sustenance? It is Allah who feeds (both) them and you: for He hears and knows (all things).

# 3401

If indeed thou ask them who has created the heavens and the earth and subjected the sun and the moon (to his Law), they will certainly reply, "Allah". How are they then deluded away (from the truth)?

# 3402

Allah enlarges the sustenance (which He gives) to whichever of His servants He pleases; and He (similarly) grants by (strict) measure, (as He pleases): for Allah has full knowledge of all things.

# 3403

And if indeed thou ask them who it is that sends down rain from the sky, and gives life therewith to the earth after its death, they will certainly reply, "Allah!" Say, "Praise be to Allah!" But most of them understand not.

# 3404

What is the life of this world but amusement and play? but verily the Home in the Hereafter,- that is life indeed, if they but knew.

# 3405

Now, if they embark on a boat, they call on Allah, making their devotion sincerely (and exclusively) to Him; but when He has delivered them safely to (dry) land, behold, they give a share (of their worship to others)!-

# 3406

Disdaining ungratefully Our gifts, and giving themselves up to (worldly) enjoyment! But soon will they know.

# 3407

Do they not then see that We have made a sanctuary secure, and that men are being snatched away from all around them? Then, do they believe in that which is vain, and reject the Grace of Allah?

# 3408

And who does more wrong than he who invents a lie against Allah or rejects the Truth when it reaches him? Is there not a home in Hell for those who reject Faith?

# 3409

And those who strive in Our (cause),- We will certainly guide them to our Paths: For verily Allah is with those who do right.

# 3410

A. L. M.

# 3411

The Roman Empire has been defeated-

# 3412

In a land close by; but they, (even) after (this) defeat of theirs, will soon be victorious-

# 3413

Within a few years. With Allah is the Decision, in the past and in the Future: on that Day shall the Believers rejoice-

# 3414

With the help of Allah. He helps whom He will, and He is exalted in might, most merciful.

# 3415

(It is) the promise of Allah. Never does Allah depart from His promise: but most men understand not.

# 3416

They know but the outer (things) in the life of this world: but of the End of things they are heedless.

# 3417

Do they not reflect in their own minds? Not but for just ends and for a term appointed, did Allah create the heavens and the earth, and all between them: yet are there truly many among men who deny the meeting with their Lord (at the Resurrection)!

# 3418

Do they not travel through the earth, and see what was the end of those before them? They were superior to them in strength: they tilled the soil and populated it in greater numbers than these have done: there came to them their messengers with Clear (Signs). (Which they rejected, to their own destruction): It was not Allah Who wronged them, but they wronged their own souls.

# 3419

In the long run evil in the extreme will be the End of those who do evil; for that they rejected the Signs of Allah, and held them up to ridicule.

# 3420

It is Allah Who begins (the process of) creation; then repeats it; then shall ye be brought back to Him.

# 3421

On the Day that the Hour will be established, the guilty will be struck dumb with despair.

# 3422

No intercessor will they have among their "Partners" and they will (themselves) reject their "Partners".

# 3423

On the Day that the Hour will be established,- that Day shall (all men) be sorted out.

# 3424

Then those who have believed and worked righteous deeds, shall be made happy in a Mead of Delight.

# 3425

And those who have rejected Faith and falsely denied our Signs and the meeting of the Hereafter,- such shall be brought forth to Punishment.

# 3426

So (give) glory to Allah, when ye reach eventide and when ye rise in the morning;

# 3427

Yea, to Him be praise, in the heavens and on earth; and in the late afternoon and when the day begins to decline.

# 3428

It is He Who brings out the living from the dead, and brings out the dead from the living, and Who gives life to the earth after it is dead: and thus shall ye be brought out (from the dead).

# 3429

Among His Signs in this, that He created you from dust; and then,- behold, ye are men scattered (far and wide)!

# 3430

And among His Signs is this, that He created for you mates from among yourselves, that ye may dwell in tranquillity with them, and He has put love and mercy between your (hearts): verily in that are Signs for those who reflect.

# 3431

And among His Signs is the creation of the heavens and the earth, and the variations in your languages and your colours: verily in that are Signs for those who know.

# 3432

And among His Signs is the sleep that ye take by night and by day, and the quest that ye (make for livelihood) out of His Bounty: verily in that are signs for those who hearken.

# 3433

And among His Signs, He shows you the lightning, by way both of fear and of hope, and He sends down rain from the sky and with it gives life to the earth after it is dead: verily in that are Signs for those who are wise.

# 3434

And among His Signs is this, that heaven and earth stand by His Command: then when He calls you, by a single call, from the earth, behold, ye (straightway) come forth.

# 3435

To Him belongs every being that is in the heavens and on earth: all are devoutly obedient to Him.

# 3436

It is He Who begins (the process of) creation; then repeats it; and for Him it is most easy. To Him belongs the loftiest similitude (we can think of) in the heavens and the earth: for He is Exalted in Might, full of wisdom.

# 3437

He does propound to you a similitude from your own (experience): do ye have partners among those whom your right hands possess, to share as equals in the wealth We have bestowed on you? Do ye fear them as ye fear each other? Thus do we explain the Signs in detail to a people that understand.

# 3438

Nay, the wrong-doers (merely) follow their own lusts, being devoid of knowledge. But who will guide those whom Allah leaves astray? To them there will be no helpers.

# 3439

So set thou thy face steadily and truly to the Faith: (establish) Allah's handiwork according to the pattern on which He has made mankind: no change (let there be) in the work (wrought) by Allah: that is the standard Religion: but most among mankind understand not.

# 3440

Turn ye back in repentance to Him, and fear Him: establish regular prayers, and be not ye among those who join gods with Allah,-

# 3441

Those who split up their Religion, and become (mere) Sects,- each party rejoicing in that which is with itself!

# 3442

When trouble touches men, they cry to their Lord, turning back to Him in repentance: but when He gives them a taste of Mercy as from Himself, behold, some of them pay part-worship to other god's besides their Lord,-

# 3443

(As if) to show their ingratitude for the (favours) We have bestowed on them! Then enjoy (your brief day); but soon will ye know (your folly).

# 3444

Or have We sent down authority to them, which points out to them the things to which they pay part-worship?

# 3445

When We give men a taste of Mercy, they exult thereat: and when some evil afflicts them because of what their (own) hands have sent forth, behold, they are in despair!

# 3446

See they not that Allah enlarges the provision and restricts it, to whomsoever He pleases? Verily in that are Signs for those who believe.

# 3447

So give what is due to kindred, the needy, and the wayfarer. That is best for those who seek the Countenance, of Allah, and it is they who will prosper.

# 3448

That which ye lay out for increase through the property of (other) people, will have no increase with Allah: but that which ye lay out for charity, seeking the Countenance of Allah, (will increase): it is these who will get a recompense multiplied.

# 3449

It is Allah Who has created you: further, He has provided for your sustenance; then He will cause you to die; and again He will give you life. Are there any of your (false) "Partners" who can do any single one of these things? Glory to Him! and high is He above the partners they attribute (to him)!

# 3450

Mischief has appeared on land and sea because of (the meed) that the hands of men have earned, that (Allah) may give them a taste of some of their deeds: in order that they may turn back (from Evil).

# 3451

Say: "Travel through the earth and see what was the end of those before (you): Most of them worshipped others besides Allah."

# 3452

But set thou thy face to the right Religion before there come from Allah the Day which there is no chance of averting: on that Day shall men be divided (in two).

# 3453

Those who reject Faith will suffer from that rejection: and those who work righteousness will spread their couch (of repose) for themselves (in heaven):

# 3454

That He may reward those who believe and work righteous deeds, out of his Bounty. For He loves not those who reject Faith.

# 3455

Among His Signs is this, that He sends the Winds, as heralds of Glad Tidings, giving you a taste of His (Grace and) Mercy,- that the ships may sail (majestically) by His Command and that ye may seek of His Bounty: in order that ye may be grateful.

# 3456

We did indeed send, before thee, messengers to their (respective) peoples, and they came to them with Clear Signs: then, to those who transgressed, We meted out Retribution: and it was due from Us to aid those who believed.

# 3457

It is Allah Who sends the Winds, and they raise the Clouds: then does He spread them in the sky as He wills, and break them into fragments, until thou seest rain-drops issue from the midst thereof: then when He has made them reach such of his servants as He wills behold, they do rejoice!-

# 3458

Even though, before they received (the rain) - just before this - they were dumb with despair!

# 3459

Then contemplate (O man!) the memorials of Allah's Mercy!- how He gives life to the earth after its death: verily the same will give life to the men who are dead: for He has power over all things.

# 3460

And if We (but) send a Wind from which they see (their tilth) turn yellow,- behold, they become, thereafter, Ungrateful (Unbelievers)!

# 3461

So verily thou canst not make the dead to hear, nor canst thou make the deaf to hear the call, when they show their backs and turn away.

# 3462

Nor canst thou lead back the blind from their straying: only those wilt thou make to hear, who believe in Our signs and submit (their wills in Islam).

# 3463

It is Allah Who created you in a state of (helpless) weakness, then gave (you) strength after weakness, then, after strength, gave (you weakness and a hoary head: He creates as He wills, and it is He Who has all knowledge and power.

# 3464

On the Day that the Hour (of Reckoning) will be established, the transgressors will swear that they tarried not but an hour: thus were they used to being deluded!

# 3465

But those endued with knowledge and faith will say: "Indeed ye did tarry, within Allah's Decree, to the Day of Resurrection, and this is the Day of Resurrection: but ye - ye were not aware!"

# 3466

So on that Day no excuse of theirs will avail the transgressors, nor will they be invited (then) to seek grace (by repentance).

# 3467

verily We have propounded for men, in this Qur'an every kind of Parable: But if thou bring to them any Sign, the Unbelievers are sure to say, "Ye do nothing but talk vanities."

# 3468

Thus does Allah seal up the hearts of those who understand not.

# 3469

So patiently persevere: for verily the promise of Allah is true: nor let those shake thy firmness, who have (themselves) no certainty of faith.

# 3470

A. L. M.

# 3471

These are Verses of the Wise Book,-

# 3472

A Guide and a Mercy to the Doers of Good,-

# 3473

Those who establish regular Prayer, and give regular Charity, and have (in their hearts) the assurance of the Hereafter.

# 3474

These are on (true) guidance from their Lord: and these are the ones who will prosper.

# 3475

But there are, among men, those who purchase idle tales, without knowledge (or meaning), to mislead (men) from the Path of Allah and throw ridicule (on the Path): for such there will be a Humiliating Penalty.

# 3476

When Our Signs are rehearsed to such a one, he turns away in arrogance, as if he heard them not, as if there were deafness in both his ears: announce to him a grievous Penalty.

# 3477

For those who believe and work righteous deeds, there will be Gardens of Bliss,-

# 3478

To dwell therein. The promise of Allah is true: and He is Exalted in Power, Wise.

# 3479

He created the heavens without any pillars that ye can see; He set on the earth mountains standing firm, lest it should shake with you; and He scattered through it beasts of all kinds. We send down rain from the sky, and produce on the earth every kind of noble creature, in pairs.

# 3480

Such is the Creation of Allah: now show Me what is there that others besides Him have created: nay, but the Transgressors are in manifest error.

# 3481

we bestowed (in the past) Wisdom on Luqman: "Show (thy) gratitude to Allah." Any who is (so) grateful does so to the profit of his own soul: but if any is ungrateful, verily Allah is free of all wants, Worthy of all praise.

# 3482

Behold, Luqman said to his son by way of instruction: "O my son! join not in worship (others) with Allah: for false worship is indeed the highest wrong-doing."

# 3483

And We have enjoined on man (to be good) to his parents: in travail upon travail did his mother bear him, and in years twain was his weaning: (hear the command), "Show gratitude to Me and to thy parents: to Me is (thy final) Goal.

# 3484

"But if they strive to make thee join in worship with Me things of which thou hast no knowledge, obey them not; yet bear them company in this life with justice (and consideration), and follow the way of those who turn to me (in love): in the end the return of you all is to Me, and I will tell you the truth (and meaning) of all that ye did."

# 3485

"O my son!" (said Luqman), "If there be (but) the weight of a mustard-seed and it were (hidden) in a rock, or (anywhere) in the heavens or on earth, Allah will bring it forth: for Allah understands the finest mysteries, (and) is well-acquainted (with them).

# 3486

"O my son! establish regular prayer, enjoin what is just, and forbid what is wrong: and bear with patient constancy whatever betide thee; for this is firmness (of purpose) in (the conduct of) affairs.

# 3487

"And swell not thy cheek (for pride) at men, nor walk in insolence through the earth; for Allah loveth not any arrogant boaster.

# 3488

"And be moderate in thy pace, and lower thy voice; for the harshest of sounds without doubt is the braying of the ass."

# 3489

Do ye not see that Allah has subjected to your (use) all things in the heavens and on earth, and has made his bounties flow to you in exceeding measure, (both) seen and unseen? Yet there are among men those who dispute about Allah, without knowledge and without guidance, and without a Book to enlighten them!

# 3490

When they are told to follow the (Revelation) that Allah has sent down, they say: "Nay, we shall follow the ways that we found our fathers (following). "What! even if it is Satan beckoning them to the Penalty of the (Blazing) Fire?

# 3491

Whoever submits his whole self to Allah, and is a doer of good, has grasped indeed the most trustworthy hand-hold: and with Allah rests the End and Decision of (all) affairs.

# 3492

But if any reject Faith, let not his rejection grieve thee: to Us is their return, and We shall tell them the truth of their deeds: for Allah knows well all that is in (men's) hearts.

# 3493

We grant them their pleasure for a little while: in the end shall We drive them to a chastisement unrelenting.

# 3494

If thou ask them, who it is that created the heavens and the earth. They will certainly say, "Allah". Say: "Praise be to Allah!" But most of them understand not.

# 3495

To Allah belong all things in heaven and earth: verily Allah is He (that is) free of all wants, worthy of all praise.

# 3496

And if all the trees on earth were pens and the ocean (were ink), with seven oceans behind it to add to its (supply), yet would not the words of Allah be exhausted (in the writing): for Allah is Exalted in Power, full of Wisdom.

# 3497

And your creation or your resurrection is in no wise but as an individual soul: for Allah is He Who hears and sees (all things).

# 3498

Seest thou not that Allah merges Night into Day and he merges Day into Night; that He has subjected the sun, and the moon (to his Law), each running its course for a term appointed; and that Allah is well-acquainted with all that ye do?

# 3499

That is because Allah is the (only) Reality, and because whatever else they invoke besides Him is Falsehood; and because Allah,- He is the Most High, Most Great.

# 3500

Seest thou not that the ships sail through the ocean by the Grace of Allah?- that He may show you of His Signs? Verily in this are Signs for all who constantly persevere and give thanks.

# 3501

When a wave covers them like the canopy (of clouds), they call to Allah, offering Him sincere devotion. But when He has delivered them safely to land, there are among them those that halt between (right and wrong). But none reject Our Signs except only a perfidious ungrateful (wretch)!

# 3502

O mankind! do your duty to your Lord, and fear (the coming of) a Day when no father can avail aught for his son, nor a son avail aught for his father. Verily, the promise of Allah is true: let not then this present life deceive you, nor let the chief Deceiver deceive you about Allah.

# 3503

Verily the knowledge of the Hour is with Allah (alone). It is He Who sends down rain, and He Who knows what is in the wombs. Nor does any one know what it is that he will earn on the morrow: Nor does any one know in what land he is to die. Verily with Allah is full knowledge and He is acquainted (with all things).

# 3504

A. L. M.

# 3505

(This is) the Revelation of the Book in which there is no doubt,- from the Lord of the Worlds.

# 3506

Or do they say, "He has forged it"? Nay, it is the Truth from thy Lord, that thou mayest admonish a people to whom no warner has come before thee: in order that they may receive guidance.

# 3507

It is Allah Who has created the heavens and the earth, and all between them, in six Days, and is firmly established on the Throne (of Authority): ye have none, besides Him, to protect or intercede (for you): will ye not then receive admonition?

# 3508

He rules (all) affairs from the heavens to the earth: in the end will (all affairs) go up to Him, on a Day, the space whereof will be (as) a thousand years of your reckoning.

# 3509

Such is He, the Knower of all things, hidden and open, the Exalted (in power), the Merciful;-

# 3510

He Who has made everything which He has created most good: He began the creation of man with (nothing more than) clay,

# 3511

And made his progeny from a quintessence of the nature of a fluid despised:

# 3512

But He fashioned him in due proportion, and breathed into him something of His spirit. And He gave you (the faculties of) hearing and sight and feeling (and understanding): little thanks do ye give!

# 3513

And they say: "What! when we lie, hidden and lost, in the earth, shall we indeed be in a Creation renewed? Nay, they deny the Meeting with their Lord.

# 3514

Say: "The Angel of Death, put in charge of you, will (duly) take your souls: then shall ye be brought back to your Lord."

# 3515

If only thou couldst see when the guilty ones will bend low their heads before their Lord, (saying:) "Our Lord! We have seen and we have heard: Now then send us back (to the world): we will work righteousness: for we do indeed (now) believe."

# 3516

If We had so willed, We could certainly have brought every soul its true guidance: but the Word from Me will come true, "I will fill Hell with Jinns and men all together."

# 3517

"Taste ye then - for ye forgot the Meeting of this Day of yours, and We too will forget you - taste ye the Penalty of Eternity for your (evil) deeds!"

# 3518

Only those believe in Our Signs, who, when they are recited to them, fall down in prostration, and celebrate the praises of their Lord, nor are they (ever) puffed up with pride.

# 3519

Their limbs do forsake their beds of sleep, the while they call on their Lord, in Fear and Hope: and they spend (in charity) out of the sustenance which We have bestowed on them.

# 3520

Now no person knows what delights of the eye are kept hidden (in reserve) for them - as a reward for their (good) deeds.

# 3521

Is then the man who believes no better than the man who is rebellious and wicked? Not equal are they.

# 3522

For those who believe and do righteous deeds are Gardens as hospitable homes, for their (good) deeds.

# 3523

As to those who are rebellious and wicked, their abode will be the Fire: every time they wish to get away therefrom, they will be forced thereinto, and it will be said to them: "Taste ye the Penalty of the Fire, the which ye were wont to reject as false."

# 3524

And indeed We will make them taste of the Penalty of this (life) prior to the supreme Penalty, in order that they may (repent and) return.

# 3525

And who does more wrong than one to whom are recited the Signs of his Lord, and who then turns away therefrom? Verily from those who transgress We shall exact (due) Retribution.

# 3526

We did indeed aforetime give the Book to Moses: be not then in doubt of its reaching (thee): and We made it a guide to the Children of Israel.

# 3527

And We appointed, from among them, leaders, giving guidance under Our command, so long as they persevered with patience and continued to have faith in Our Signs.

# 3528

Verily thy Lord will judge between them on the Day of Judgment, in the matters wherein they differ (among themselves)

# 3529

Does it not teach them a lesson, how many generations We destroyed before them, in whose dwellings they (now) go to and fro? Verily in that are Signs: Do they not then listen?

# 3530

And do they not see that We do drive rain to parched soil (bare of herbage), and produce therewith crops, providing food for their cattle and themselves? Have they not the vision?

# 3531

They say: "When will this decision be, if ye are telling the truth?"

# 3532

Say: "On the Day of Decision, no profit will it be to Unbelievers if they (then) believe! nor will they be granted a respite."

# 3533

So turn away from them, and wait: they too are waiting.

# 3534

O Prophet! Fear Allah, and hearken not to the Unbelievers and the Hypocrites: verily Allah is full of Knowledge and Wisdom.

# 3535

But follow that which comes to thee by inspiration from thy Lord: for Allah is well acquainted with (all) that ye do.

# 3536

And put thy trust in Allah, and enough is Allah as a disposer of affairs.

# 3537

Allah has not made for any man two hearts in his (one) body: nor has He made your wives whom ye divorce by Zihar your mothers: nor has He made your adopted sons your sons. Such is (only) your (manner of) speech by your mouths. But Allah tells (you) the Truth, and He shows the (right) Way.

# 3538

Call them by (the names of) their fathers: that is juster in the sight of Allah. But if ye know not their father's (names, call them) your Brothers in faith, or your maulas. But there is no blame on you if ye make a mistake therein: (what counts is) the intention of your hearts: and Allah is Oft-Returning, Most Merciful.

# 3539

The Prophet is closer to the Believers than their own selves, and his wives are their mothers. Blood-relations among each other have closer personal ties, in the Decree of Allah. Than (the Brotherhood of) Believers and Muhajirs: nevertheless do ye what is just to your closest friends: such is the writing in the Decree (of Allah).

# 3540

And remember We took from the prophets their covenant: As (We did) from thee: from Noah, Abraham, Moses, and Jesus the son of Mary: We took from them a solemn covenant:

# 3541

That (Allah) may question the (custodians) of Truth concerning the Truth they (were charged with): And He has prepared for the Unbelievers a grievous Penalty.

# 3542

O ye who believe! Remember the Grace of Allah, (bestowed) on you, when there came down on you hosts (to overwhelm you): But We sent against them a hurricane and forces that ye saw not: but Allah sees (clearly) all that ye do.

# 3543

Behold! they came on you from above you and from below you, and behold, the eyes became dim and the hearts gaped up to the throats, and ye imagined various (vain) thoughts about Allah!

# 3544

In that situation were the Believers tried: they were shaken as by a tremendous shaking.

# 3545

And behold! The Hypocrites and those in whose hearts is a disease (even) say: "Allah and His Messenger promised us nothing but delusion!"

# 3546

Behold! A party among them said: "Ye men of Yathrib! ye cannot stand (the attack)! therefore go back!" And a band of them ask for leave of the Prophet, saying, "Truly our houses are bare and exposed," though they were not exposed they intended nothing but to run away.

# 3547

And if an entry had been effected to them from the sides of the (city), and they had been incited to sedition, they would certainly have brought it to pass, with none but a brief delay!

# 3548

And yet they had already covenanted with Allah not to turn their backs, and a covenant with Allah must (surely) be answered for.

# 3549

Say: "Running away will not profit you if ye are running away from death or slaughter; and even if (ye do escape), no more than a brief (respite) will ye be allowed to enjoy!"

# 3550

Say: "Who is it that can screen you from Allah if it be His wish to give you punishment or to give you Mercy?" Nor will they find for themselves, besides Allah, any protector or helper.

# 3551

Verily Allah knows those among you who keep back (men) and those who say to their brethren, "Come along to us", but come not to the fight except for just a little while.

# 3552

Covetous over you. Then when fear comes, thou wilt see them looking to thee, their eyes revolving, like (those of) one over whom hovers death: but when the fear is past, they will smite you with sharp tongues, covetous of goods. Such men have no faith, and so Allah has made their deeds of none effect: and that is easy for Allah.

# 3553

They think that the Confederates have not withdrawn; and if the Confederates should come (again), they would wish they were in the deserts (wandering) among the Bedouins, and seeking news about you (from a safe distance); and if they were in your midst, they would fight but little.

# 3554

Ye have indeed in the Messenger of Allah a beautiful pattern (of conduct) for any one whose hope is in Allah and the Final Day, and who engages much in the Praise of Allah.

# 3555

When the Believers saw the Confederate forces, they said: "This is what Allah and his Messenger had promised us, and Allah and His Messenger told us what was true." And it only added to their faith and their zeal in obedience.

# 3556

Among the Believers are men who have been true to their covenant with Allah: of them some have completed their vow (to the extreme), and some (still) wait: but they have never changed (their determination) in the least:

# 3557

That Allah may reward the men of Truth for their Truth, and punish the Hypocrites if that be His Will, or turn to them in Mercy: for Allah is Oft-Forgiving, Most Merciful.

# 3558

And Allah turned back the Unbelievers for (all) their fury: no advantage did they gain; and enough is Allah for the believers in their fight. And Allah is full of Strength, able to enforce His Will.

# 3559

And those of the People of the Book who aided them - Allah did take them down from their strongholds and cast terror into their hearts. (So that) some ye slew, and some ye made prisoners.

# 3560

And He made you heirs of their lands, their houses, and their goods, and of a land which ye had not frequented (before). And Allah has power over all things.

# 3561

O Prophet! Say to thy Consorts: "If it be that ye desire the life of this World, and its glitter,- then come! I will provide for your enjoyment and set you free in a handsome manner.

# 3562

But if ye seek Allah and His Messenger, and the Home of the Hereafter, verily Allah has prepared for the well-doers amongst you a great reward.

# 3563

O Consorts of the Prophet! If any of you were guilty of evident unseemly conduct, the Punishment would be doubled to her, and that is easy for Allah.

# 3564

But any of you that is devout in the service of Allah and His Messenger, and works righteousness,- to her shall We grant her reward twice: and We have prepared for her a generous Sustenance.

# 3565

O Consorts of the Prophet! Ye are not like any of the (other) women: if ye do fear (Allah), be not too complacent of speech, lest one in whose heart is a disease should be moved with desire: but speak ye a speech (that is) just.

# 3566

And stay quietly in your houses, and make not a dazzling display, like that of the former Times of Ignorance; and establish regular Prayer, and give regular Charity; and obey Allah and His Messenger. And Allah only wishes to remove all abomination from you, ye members of the Family, and to make you pure and spotless.

# 3567

And recite what is rehearsed to you in your homes, of the Signs of Allah and His Wisdom: for Allah understands the finest mysteries and is well-acquainted (with them).

# 3568

For Muslim men and women,- for believing men and women, for devout men and women, for true men and women, for men and women who are patient and constant, for men and women who humble themselves, for men and women who give in Charity, for men and women who fast (and deny themselves), for men and women who guard their chastity, and for men and women who engage much in Allah's praise,- for them has Allah prepared forgiveness and great reward.

# 3569

It is not fitting for a Believer, man or woman, when a matter has been decided by Allah and His Messenger to have any option about their decision: if any one disobeys Allah and His Messenger, he is indeed on a clearly wrong Path.

# 3570

Behold! Thou didst say to one who had received the grace of Allah and thy favour: "Retain thou (in wedlock) thy wife, and fear Allah." But thou didst hide in thy heart that which Allah was about to make manifest: thou didst fear the people, but it is more fitting that thou shouldst fear Allah. Then when Zaid had dissolved (his marriage) with her, with the necessary (formality), We joined her in marriage to thee: in order that (in future) there may be no difficulty to the Believers in (the matter of) marriage with the wives of their adopted sons, when the latter have dissolved with the necessary (formality) (their marriage) with them. And Allah's command must be fulfilled.

# 3571

There can be no difficulty to the Prophet in what Allah has indicated to him as a duty. It was the practice (approved) of Allah amongst those of old that have passed away. And the command of Allah is a decree determined.

# 3572

(It is the practice of those) who preach the Messages of Allah, and fear Him, and fear none but Allah. And enough is Allah to call (men) to account.

# 3573

Muhammad is not the father of any of your men, but (he is) the Messenger of Allah, and the Seal of the Prophets: and Allah has full knowledge of all things.

# 3574

O ye who believe! Celebrate the praises of Allah, and do this often;

# 3575

And glorify Him morning and evening.

# 3576

He it is Who sends blessings on you, as do His angels, that He may bring you out from the depths of Darkness into Light: and He is Full of Mercy to the Believers.

# 3577

Their salutation on the Day they meet Him will be "Peace!"; and He has prepared for them a generous Reward.

# 3578

O Prophet! Truly We have sent thee as a Witness, a Bearer of Glad Tidings, and Warner,-

# 3579

And as one who invites to Allah's (grace) by His leave, and as a lamp spreading light.

# 3580

Then give the Glad Tidings to the Believers, that they shall have from Allah a very great Bounty.

# 3581

And obey not (the behests) of the Unbelievers and the Hypocrites, and heed not their annoyances, but put thy Trust in Allah. For enough is Allah as a Disposer of affairs.

# 3582

O ye who believe! When ye marry believing women, and then divorce them before ye have touched them, no period of 'Iddat have ye to count in respect of them: so give them a present. And set them free in a handsome manner.

# 3583

O Prophet! We have made lawful to thee thy wives to whom thou hast paid their dowers; and those whom thy right hand possesses out of the prisoners of war whom Allah has assigned to thee; and daughters of thy paternal uncles and aunts, and daughters of thy maternal uncles and aunts, who migrated (from Makka) with thee; and any believing woman who dedicates her soul to the Prophet if the Prophet wishes to wed her;- this only for thee, and not for the Believers (at large); We know what We have appointed for them as to their wives and the captives whom their right hands possess;- in order that there should be no difficulty for thee. And Allah is Oft-Forgiving, Most Merciful.

# 3584

Thou mayest defer (the turn of) any of them that thou pleasest, and thou mayest receive any thou pleasest: and there is no blame on thee if thou invite one whose (turn) thou hadst set aside. This were nigher to the cooling of their eyes, the prevention of their grief, and their satisfaction - that of all of them - with that which thou hast to give them: and Allah knows (all) that is in your hearts: and Allah is All-Knowing, Most Forbearing.

# 3585

It is not lawful for thee (to marry more) women after this, nor to change them for (other) wives, even though their beauty attract thee, except any thy right hand should possess (as handmaidens): and Allah doth watch over all things.

# 3586

O ye who believe! Enter not the Prophet's houses,- until leave is given you,- for a meal, (and then) not (so early as) to wait for its preparation: but when ye are invited, enter; and when ye have taken your meal, disperse, without seeking familiar talk. Such (behaviour) annoys the Prophet: he is ashamed to dismiss you, but Allah is not ashamed (to tell you) the truth. And when ye ask (his ladies) for anything ye want, ask them from before a screen: that makes for greater purity for your hearts and for theirs. Nor is it right for you that ye should annoy Allah's Messenger, or that ye should marry his widows after him at any time. Truly such a thing is in Allah's sight an enormity.

# 3587

Whether ye reveal anything or conceal it, verily Allah has full knowledge of all things.

# 3588

There is no blame (on these ladies if they appear) before their fathers or their sons, their brothers, or their brother's sons, or their sisters' sons, or their women, or the (slaves) whom their right hands possess. And, (ladies), fear Allah; for Allah is Witness to all things.

# 3589

Allah and His angels send blessings on the Prophet: O ye that believe! Send ye blessings on him, and salute him with all respect.

# 3590

Those who annoy Allah and His Messenger - Allah has cursed them in this World and in the Hereafter, and has prepared for them a humiliating Punishment.

# 3591

And those who annoy believing men and women undeservedly, bear (on themselves) a calumny and a glaring sin.

# 3592

O Prophet! Tell thy wives and daughters, and the believing women, that they should cast their outer garments over their persons (when abroad): that is most convenient, that they should be known (as such) and not molested. And Allah is Oft-Forgiving, Most Merciful.

# 3593

Truly, if the Hypocrites, and those in whose hearts is a disease, and those who stir up sedition in the City, desist not, We shall certainly stir thee up against them: Then will they not be able to stay in it as thy neighbours for any length of time:

# 3594

They shall have a curse on them: whenever they are found, they shall be seized and slain (without mercy).

# 3595

(Such was) the practice (approved) of Allah among those who lived aforetime: No change wilt thou find in the practice (approved) of Allah.

# 3596

Men ask thee concerning the Hour: Say, "The knowledge thereof is with Allah (alone)": and what will make thee understand?- perchance the Hour is nigh!

# 3597

Verily Allah has cursed the Unbelievers and prepared for them a Blazing Fire,-

# 3598

To dwell therein for ever: no protector will they find, nor helper.

# 3599

The Day that their faces will be turned upside down in the Fire, they will say: "Woe to us! Would that we had obeyed Allah and obeyed the Messenger!"

# 3600

And they would say: "Our Lord! We obeyed our chiefs and our great ones, and they misled us as to the (right) Path.

# 3601

"Our Lord! Give them double Penalty and curse them with a very great Curse!"

# 3602

O ye who believe! Be ye not like those who vexed and insulted Moses, but Allah cleared him of the (calumnies) they had uttered: and he was honourable in Allah's sight.

# 3603

O ye who believe! Fear Allah, and (always) say a word directed to the Right:

# 3604

That He may make your conduct whole and sound and forgive you your sins: He that obeys Allah and His Messenger, has already attained the highest achievement.

# 3605

We did indeed offer the Trust to the Heavens and the Earth and the Mountains; but they refused to undertake it, being afraid thereof: but man undertook it;- He was indeed unjust and foolish;-

# 3606

(With the result) that Allah has to punish the Hypocrites, men and women, and the Unbelievers, men and women, and Allah turns in Mercy to the Believers, men and women: for Allah is Oft-Forgiving, Most Merciful.

# 3607

Praise be to Allah, to Whom belong all things in the heavens and on earth: to Him be Praise in the Hereafter: and He is Full of Wisdom, acquainted with all things.

# 3608

He knows all that goes into the earth, and all that comes out thereof; all that comes down from the sky and all that ascends thereto and He is the Most Merciful, the Oft-Forgiving.

# 3609

The Unbelievers say, "Never to us will come the Hour": Say, "Nay! but most surely, by my Lord, it will come upon you;- by Him Who knows the unseen,- from Whom is not hidden the least little atom in the heavens or on earth: Nor is there anything less than that, or greater, but is in the Record Perspicuous:

# 3610

That He may reward those who believe and work deeds of righteousness: for such is Forgiveness and a Sustenance Most Generous."

# 3611

But those who strive against Our Signs, to frustrate them,- for such will be a Penalty,- a Punishment most humiliating.

# 3612

And those to whom knowledge has come see that the (Revelation) sent down to thee from thy Lord - that is the Truth, and that it guides to the Path of the Exalted (in might), Worthy of all praise.

# 3613

The Unbelievers say (in ridicule): "Shall we point out to you a man that will tell you, when ye are all scattered to pieces in disintegration, that ye shall (then be raised) in a New Creation?

# 3614

"Has he invented a falsehood against Allah, or has a spirit (seized) him?"- Nay, it is those who believe not in the Hereafter, that are in (real) Penalty, and in farthest error.

# 3615

See they not what is before them and behind them, of the sky and the earth? If We wished, We could cause the earth to swallow them up, or cause a piece of the sky to fall upon them. Verily in this is a Sign for every devotee that turns to Allah (in repentance).

# 3616

We bestowed Grace aforetime on David from ourselves: "O ye Mountains! Sing ye back the Praises of Allah with him! and ye birds (also)! And We made the iron soft for him;-

# 3617

(Commanding), "Make thou coast of mail, balancing well the rings of chain armour, and work ye righteousness; for be sure I see (clearly) all that ye do."

# 3618

And to Solomon (We made) the Wind (obedient): Its early morning (stride) was a month's (journey), and its evening (stride) was a month's (journey); and We made a Font of molten brass to flow for him; and there were Jinns that worked in front of him, by the leave of his Lord, and if any of them turned aside from our command, We made him taste of the Penalty of the Blazing Fire.

# 3619

They worked for him as he desired, (making) arches, images, basons as large as reservoirs, and (cooking) cauldrons fixed (in their places): "Work ye, sons of David, with thanks! but few of My servants are grateful!"

# 3620

Then, when We decreed (Solomon's) death, nothing showed them his death except a little worm of the earth, which kept (slowly) gnawing away at his staff: so when he fell down, the Jinns saw plainly that if they had known the unseen, they would not have tarried in the humiliating Penalty (of their Task).

# 3621

There was, for Saba, aforetime, a Sign in their home-land - two Gardens to the right and to the left. "Eat of the Sustenance (provided) by your Lord, and be grateful to Him: a territory fair and happy, and a Lord Oft-Forgiving!

# 3622

But they turned away (from Allah), and We sent against them the Flood (released) from the dams, and We converted their two garden (rows) into "gardens" producing bitter fruit, and tamarisks, and some few (stunted) Lote-trees.

# 3623

That was the Requital We gave them because they ungratefully rejected Faith: and never do We give (such) requital except to such as are ungrateful rejecters.

# 3624

Between them and the Cities on which We had poured our blessings, We had placed Cities in prominent positions, and between them We had appointed stages of journey in due proportion: "Travel therein, secure, by night and by day."

# 3625

But they said: "Our Lord! Place longer distances between our journey-stages": but they wronged themselves (therein). At length We made them as a tale (that is told), and We dispersed them all in scattered fragments. Verily in this are Signs for every (soul that is) patiently constant and grateful.

# 3626

And on them did Satan prove true his idea, and they followed him, all but a party that believed.

# 3627

But he had no authority over them,- except that We might test the man who believes in the Hereafter from him who is in doubt concerning it: and thy Lord doth watch over all things.

# 3628

Say: "Call upon other (gods) whom ye fancy, besides Allah: They have no power,- not the weight of an atom,- in the heavens or on earth: No (sort of) share have they therein, nor is any of them a helper to Allah.

# 3629

"No intercession can avail in His Presence, except for those for whom He has granted permission. So far (is this the case) that, when terror is removed from their hearts (at the Day of Judgment, then) will they say, 'what is it that your Lord commanded?' they will say, 'That which is true and just; and He is the Most High Most Great'."

# 3630

Say: "Who gives you sustenance, from the heavens and the earth?" Say: "It is Allah; and certain it is that either we or ye are on right guidance or in manifest error!"

# 3631

Say: "Ye shall not be questioned as to our sins, nor shall we be questioned as to what ye do."

# 3632

Say: "Our Lord will gather us together and will in the end decide the matter between us (and you) in truth and justice: and He is the one to decide, the One Who knows all."

# 3633

Say: "Show me those whom ye have joined with Him as partners: by no means (can ye). Nay, He is Allah, the Exalted in Power, the Wise."

# 3634

We have not sent thee but as a universal (Messenger) to men, giving them glad tidings, and warning them (against sin), but most men understand not.

# 3635

They say: "When will this promise (come to pass) if ye are telling the truth?"

# 3636

Say: "The appointment to you is for a Day, which ye cannot put back for an hour nor put forward."

# 3637

The Unbelievers say: "We shall neither believe in this scripture nor in (any) that (came) before it." Couldst thou but see when the wrong-doers will be made to stand before their Lord, throwing back the word (of blame) on one another! Those who had been despised will say to the arrogant ones: "Had it not been for you, we should certainly have been believers!"

# 3638

The arrogant ones will say to those who had been despised: "Was it we who kept you back from Guidance after it reached you? Nay, rather, it was ye who transgressed.

# 3639

Those who had been despised will say to the arrogant ones: "Nay! it was a plot (of yours) by day and by night: Behold! Ye (constantly) ordered us to be ungrateful to Allah and to attribute equals to Him!" They will declare (their) repentance when they see the Penalty: We shall put yokes on the necks of the Unbelievers: It would only be a requital for their (ill) Deeds.

# 3640

Never did We send a warner to a population, but the wealthy ones among them said: "We believe not in the (Message) with which ye have been sent."

# 3641

They said: "We have more in wealth and in sons, and we cannot be punished."

# 3642

Say: "Verily my Lord enlarges and restricts the Provision to whom He pleases, but most men understand not."

# 3643

It is not your wealth nor your sons, that will bring you nearer to Us in degree: but only those who believe and work righteousness - these are the ones for whom there is a multiplied Reward for their deeds, while secure they (reside) in the dwellings on high!

# 3644

Those who strive against Our Signs, to frustrate them, will be given over into Punishment.

# 3645

Say: "Verily my Lord enlarges and restricts the Sustenance to such of his servants as He pleases: and nothing do ye spend in the least (in His cause) but He replaces it: for He is the Best of those who grant Sustenance.

# 3646

One Day He will gather them all together, and say to the angels, "Was it you that these men used to worship?"

# 3647

They will say, "Glory to Thee! our (tie) is with Thee - as Protector - not with them. Nay, but they worshipped the Jinns: most of them believed in them."

# 3648

So on that Day no power shall they have over each other, for profit or harm: and We shall say to the wrong-doers, "Taste ye the Penalty of the Fire,- the which ye were wont to deny!"

# 3649

When Our Clear Signs are rehearsed to them, they say, "This is only a man who wishes to hinder you from the (worship) which your fathers practised." And they say, "This is only a falsehood invented!" and the Unbelievers say of the Truth when it comes to them, "This is nothing but evident magic!"

# 3650

But We had not given them Books which they could study, nor sent messengers to them before thee as Warners.

# 3651

And their predecessors rejected (the Truth); these have not received a tenth of what We had granted to those: yet when they rejected My messengers, how (terrible) was My rejection (of them)!

# 3652

Say: "I do admonish you on one point: that ye do stand up before Allah,- (It may be) in pairs, or (it may be) singly,- and reflect (within yourselves): your Companion is not possessed: he is no less than a warner to you, in face of a terrible Penalty."

# 3653

Say: "No reward do I ask of you: it is (all) in your interest: my reward is only due from Allah: And He is witness to all things."

# 3654

Say: "Verily my Lord doth cast the (mantle of) Truth (over His servants),- He that has full knowledge of (all) that is hidden."

# 3655

Say: "The Truth has arrived, and Falsehood neither creates anything new, nor restores anything."

# 3656

Say: "If I am astray, I only stray to the loss of my own soul: but if I receive guidance, it is because of the inspiration of my Lord to me: it is He Who hears all things, and is (ever) near."

# 3657

If thou couldst but see when they will quake with terror; but then there will be no escape (for them), and they will be seized from a position (quite) near.

# 3658

And they will say, "We do believe (now) in the (Truth)"; but how could they receive (Faith) from a position (so far off,-

# 3659

Seeing that they did reject Faith (entirely) before, and that they (continually) cast (slanders) on the unseen from a position far off?

# 3660

And between them and their desires, is placed a barrier, as was done in the past with their partisans: for they were indeed in suspicious (disquieting) doubt.

# 3661

Praise be to Allah, Who created (out of nothing) the heavens and the earth, Who made the angels, messengers with wings,- two, or three, or four (pairs): He adds to Creation as He pleases: for Allah has power over all things.

# 3662

What Allah out of his Mercy doth bestow on mankind there is none can withhold: what He doth withhold, there is none can grant, apart from Him: and He is the Exalted in Power, full of Wisdom.

# 3663

O men! Call to mind the grace of Allah unto you! is there a creator, other than Allah, to give you sustenance from heaven or earth? There is no god but He: how then are ye deluded away from the Truth?

# 3664

And if they reject thee, so were messengers rejected before thee: to Allah back for decision all affairs.

# 3665

O men! Certainly the promise of Allah is true. Let not then this present life deceive you, nor let the Chief Deceiver deceive you about Allah.

# 3666

Verily Satan is an enemy to you: so treat him as an enemy. He only invites his adherents, that they may become Companions of the Blazing Fire.

# 3667

For those who reject Allah, is a terrible Penalty: but for those who believe and work righteous deeds, is Forgiveness, and a magnificent Reward.

# 3668

Is he, then, to whom the evil of his conduct is made alluring, so that he looks upon it as good, (equal to one who is rightly guided)? For Allah leaves to stray whom He wills, and guides whom He wills. So let not thy soul go out in (vainly) sighing after them: for Allah knows well all that they do!

# 3669

It is Allah Who sends forth the Winds, so that they raise up the Clouds, and We drive them to a land that is dead, and revive the earth therewith after its death: even so (will be) the Resurrection!

# 3670

If any do seek for glory and power,- to Allah belong all glory and power. To Him mount up (all) Words of Purity: It is He Who exalts each Deed of Righteousness. Those that lay Plots of Evil,- for them is a Penalty terrible; and the plotting of such will be void (of result).

# 3671

And Allah did create you from dust; then from a sperm-drop; then He made you in pairs. And no female conceives, or lays down (her load), but with His knowledge. Nor is a man long-lived granted length of days, nor is a part cut off from his life, but is in a Decree (ordained). All this is easy to Allah.

# 3672

Nor are the two bodies of flowing water alike,- the one palatable, sweet, and pleasant to drink, and the other, salt and bitter. Yet from each (kind of water) do ye eat flesh fresh and tender, and ye extract ornaments to wear; and thou seest the ships therein that plough the waves, that ye may seek (thus) of the Bounty of Allah that ye may be grateful.

# 3673

He merges Night into Day, and he merges Day into Night, and he has subjected the sun and the moon (to his Law): each one runs its course for a term appointed. Such is Allah your Lord: to Him belongs all Dominion. And those whom ye invoke besides Him have not the least power.

# 3674

If ye invoke them, they will not listen to your call, and if they were to listen, they cannot answer your (prayer). On the Day of Judgment they will reject your "Partnership". and none, (O man!) can tell thee (the Truth) like the One Who is acquainted with all things.

# 3675

O ye men! It is ye that have need of Allah: but Allah is the One Free of all wants, worthy of all praise.

# 3676

If He so pleased, He could blot you out and bring in a New Creation.

# 3677

Nor is that (at all) difficult for Allah.

# 3678

Nor can a bearer of burdens bear another's burdens if one heavily laden should call another to (bear) his load. Not the least portion of it can be carried (by the other). Even though he be nearly related. Thou canst but admonish such as fear their Lord unseen and establish regular Prayer. And whoever purifies himself does so for the benefit of his own soul; and the destination (of all) is to Allah.

# 3679

The blind and the seeing are not alike;

# 3680

Nor are the depths of Darkness and the Light;

# 3681

Nor are the (chilly) shade and the (genial) heat of the sun:

# 3682

Nor are alike those that are living and those that are dead. Allah can make any that He wills to hear; but thou canst not make those to hear who are (buried) in graves.

# 3683

Thou art no other than a warner.

# 3684

Verily We have sent thee in truth, as a bearer of glad tidings, and as a warner: and there never was a people, without a warner having lived among them (in the past).

# 3685

And if they reject thee, so did their predecessors, to whom came their messengers with Clear Signs, Books of dark prophecies, and the Book of Enlightenment.

# 3686

In the end did I punish those who rejected Faith: and how (terrible) was My rejection (of them)!

# 3687

Seest thou not that Allah sends down rain from the sky? With it We then bring out produce of various colours. And in the mountains are tracts white and red, of various shades of colour, and black intense in hue.

# 3688

And so amongst men and crawling creatures and cattle, are they of various colours. Those truly fear Allah, among His Servants, who have knowledge: for Allah is Exalted in Might, Oft-Forgiving.

# 3689

Those who rehearse the Book of Allah, establish regular Prayer, and spend (in Charity) out of what We have provided for them, secretly and openly, hope for a commerce that will never fail:

# 3690

For He will pay them their meed, nay, He will give them (even) more out of His Bounty: for He is Oft-Forgiving, Most Ready to appreciate (service).

# 3691

That which We have revealed to thee of the Book is the Truth,- confirming what was (revealed) before it: for Allah is assuredly- with respect to His Servants - well acquainted and Fully Observant.

# 3692

Then We have given the Book for inheritance to such of Our Servants as We have chosen: but there are among them some who wrong their own souls; some who follow a middle course; and some who are, by Allah's leave, foremost in good deeds; that is the highest Grace.

# 3693

Gardens of Eternity will they enter: therein will they be adorned with bracelets of gold and pearls; and their garments there will be of silk.

# 3694

And they will say: "Praise be to Allah, Who has removed from us (all) sorrow: for our Lord is indeed Oft-Forgiving Ready to appreciate (service):

# 3695

"Who has, out of His Bounty, settled us in a Home that will last: no toil nor sense of weariness shall touch us therein."

# 3696

But those who reject (Allah) - for them will be the Fire of Hell: No term shall be determined for them, so they should die, nor shall its Penalty be lightened for them. Thus do We reward every ungrateful one!

# 3697

Therein will they cry aloud (for assistance): "Our Lord! Bring us out: we shall work righteousness, not the (deeds) we used to do!" - "Did We not give you long enough life so that he that would should receive admonition? and (moreover) the warner came to you. So taste ye (the fruits of your deeds): for the wrong-doers there is no helper."

# 3698

Verily Allah knows (all) the hidden things of the heavens and the earth: verily He has full knowledge of all that is in (men's) hearts.

# 3699

He it is That has made you inheritors in the earth: if, then, any do reject (Allah), their rejection (works) against themselves: their rejection but adds to the odium for the Unbelievers in the sight of their Lord: their rejection but adds to (their own) undoing.

# 3700

Say: "Have ye seen (these) 'Partners' of yours whom ye call upon besides Allah? Show Me what it is they have created in the (wide) earth. Or have they a share in the heavens? Or have We given them a Book from which they (can derive) clear (evidence)?- Nay, the wrong-doers promise each other nothing but delusions.

# 3701

It is Allah Who sustains the heavens and the earth, lest they cease (to function): and if they should fail, there is none - not one - can sustain them thereafter: Verily He is Most Forbearing, Oft-Forgiving.

# 3702

They swore their strongest oaths by Allah that if a warner came to them, they would follow his guidance better than any (other) of the Peoples: But when a warner came to them, it has only increased their flight (from righteousness),-

# 3703

On account of their arrogance in the land and their plotting of Evil, but the plotting of Evil will hem in only the authors thereof. Now are they but looking for the way the ancients were dealt with? But no change wilt thou find in Allah's way (of dealing): no turning off wilt thou find in Allah's way (of dealing).

# 3704

Do they not travel through the earth, and see what was the End of those before them,- though they were superior to them in strength? Nor is Allah to be frustrated by anything whatever in the heavens or on earth: for He is All-Knowing. All-Powerful.

# 3705

If Allah were to punish men according to what they deserve. He would not leave on the back of the (earth) a single living creature: but He gives them respite for a stated Term: when their Term expires, verily Allah has in His sight all His Servants.

# 3706

Ya Sin.

# 3707

By the Qur'an, full of Wisdom,-

# 3708

Thou art indeed one of the messengers,

# 3709

On a Straight Way.

# 3710

It is a Revelation sent down by (Him), the Exalted in Might, Most Merciful.

# 3711

In order that thou mayest admonish a people, whose fathers had received no admonition, and who therefore remain heedless (of the Signs of Allah).

# 3712

The Word is proved true against the greater part of them: for they do not believe.

# 3713

We have put yokes round their necks right up to their chins, so that their heads are forced up (and they cannot see).

# 3714

And We have put a bar in front of them and a bar behind them, and further, We have covered them up; so that they cannot see.

# 3715

The same is it to them whether thou admonish them or thou do not admonish them: they will not believe.

# 3716

Thou canst but admonish such a one as follows the Message and fears the (Lord) Most Gracious, unseen: give such a one, therefore, good tidings, of Forgiveness and a Reward most generous.

# 3717

Verily We shall give life to the dead, and We record that which they send before and that which they leave behind, and of all things have We taken account in a clear Book (of evidence).

# 3718

Set forth to them, by way of a parable, the (story of) the Companions of the City. Behold!, there came messengers to it.

# 3719

When We (first) sent to them two messengers, they rejected them: But We strengthened them with a third: they said, "Truly, we have been sent on a mission to you."

# 3720

The (people) said: "Ye are only men like ourselves; and (Allah) Most Gracious sends no sort of revelation: ye do nothing but lie."

# 3721

They said: "Our Lord doth know that we have been sent on a mission to you:

# 3722

"And our duty is only to proclaim the clear Message."

# 3723

The (people) said: "for us, we augur an evil omen from you: if ye desist not, we will certainly stone you. And a grievous punishment indeed will be inflicted on you by us."

# 3724

They said: "Your evil omens are with yourselves: (deem ye this an evil omen). If ye are admonished? Nay, but ye are a people transgressing all bounds!"

# 3725

Then there came running, from the farthest part of the City, a man, saying, "O my people! Obey the messengers:

# 3726

"Obey those who ask no reward of you (for themselves), and who have themselves received Guidance.

# 3727

"It would not be reasonable in me if I did not serve Him Who created me, and to Whom ye shall (all) be brought back.

# 3728

"Shall I take (other) gods besides Him? If (Allah) Most Gracious should intend some adversity for me, of no use whatever will be their intercession for me, nor can they deliver me.

# 3729

"I would indeed, if I were to do so, be in manifest Error.

# 3730

"For me, I have faith in the Lord of you (all): listen, then, to me!"

# 3731

It was said: "Enter thou the Garden." He said: "Ah me! Would that my People knew (what I know)!-

# 3732

"For that my Lord has granted me Forgiveness and has enrolled me among those held in honour!"

# 3733

And We sent not down against his People, after him, any hosts from heaven, nor was it needful for Us so to do.

# 3734

It was no more than a single mighty Blast, and behold! they were (like ashes) quenched and silent.

# 3735

Ah! Alas for (My) Servants! There comes not a messenger to them but they mock him!

# 3736

See they not how many generations before them we destroyed? Not to them will they return:

# 3737

But each one of them all - will be brought before Us (for judgment).

# 3738

A Sign for them is the earth that is dead: We do give it life, and produce grain therefrom, of which ye do eat.

# 3739

And We produce therein orchard with date-palms and vines, and We cause springs to gush forth therein:

# 3740

That they may enjoy the fruits of this (artistry): It was not their hands that made this: will they not then give thanks?

# 3741

Glory to Allah, Who created in pairs all things that the earth produces, as well as their own (human) kind and (other) things of which they have no knowledge.

# 3742

And a Sign for them is the Night: We withdraw therefrom the Day, and behold they are plunged in darkness;

# 3743

And the sun runs his course for a period determined for him: that is the decree of (Him), the Exalted in Might, the All-Knowing.

# 3744

And the Moon,- We have measured for her mansions (to traverse) till she returns like the old (and withered) lower part of a date-stalk.

# 3745

It is not permitted to the Sun to catch up the Moon, nor can the Night outstrip the Day: Each (just) swims along in (its own) orbit (according to Law).

# 3746

And a Sign for them is that We bore their race (through the Flood) in the loaded Ark;

# 3747

And We have created for them similar (vessels) on which they ride.

# 3748

If it were Our Will, We could drown them: then would there be no helper (to hear their cry), nor could they be delivered,

# 3749

Except by way of Mercy from Us, and by way of (world) convenience (to serve them) for a time.

# 3750

When they are told, "Fear ye that which is before you and that which will be after you, in order that ye may receive Mercy," (they turn back).

# 3751

Not a Sign comes to them from among the Signs of their Lord, but they turn away therefrom.

# 3752

And when they are told, "Spend ye of (the bounties) with which Allah has provided you," the Unbelievers say to those who believe: "Shall we then feed those whom, if Allah had so willed, He would have fed, (Himself)?- Ye are in nothing but manifest error."

# 3753

Further, they say, "When will this promise (come to pass), if what ye say is true?"

# 3754

They will not (have to) wait for aught but a single Blast: it will seize them while they are yet disputing among themselves!

# 3755

No (chance) will they then have, by will, to dispose (of their affairs), nor to return to their own people!

# 3756

The trumpet shall be sounded, when behold! from the sepulchres (men) will rush forth to their Lord!

# 3757

They will say: "Ah! Woe unto us! Who hath raised us up from our beds of repose?"... (A voice will say:) "This is what (Allah) Most Gracious had promised. And true was the word of the messengers!"

# 3758

It will be no more than a single Blast, when lo! they will all be brought up before Us!

# 3759

Then, on that Day, not a soul will be wronged in the least, and ye shall but be repaid the meeds of your past Deeds.

# 3760

Verily the Companions of the Garden shall that Day have joy in all that they do;

# 3761

They and their associates will be in groves of (cool) shade, reclining on Thrones (of dignity);

# 3762

(Every) fruit (enjoyment) will be there for them; they shall have whatever they call for;

# 3763

"Peace!" - a word (of salutation) from a Lord Most Merciful!

# 3764

"And O ye in sin! Get ye apart this Day!

# 3765

"Did I not enjoin on you, O ye Children of Adam, that ye should not worship Satan; for that he was to you an enemy avowed?-

# 3766

"And that ye should worship Me, (for that) this was the Straight Way?

# 3767

"But he did lead astray a great multitude of you. Did ye not, then, understand?

# 3768

"This is the Hell of which ye were (repeatedly) warned!

# 3769

"Embrace ye the (fire) this Day, for that ye (persistently) rejected (Truth)."

# 3770

That Day shall We set a seal on their mouths. But their hands will speak to us, and their feet bear witness, to all that they did.

# 3771

If it had been our Will, We could surely have blotted out their eyes; then should they have run about groping for the Path, but how could they have seen?

# 3772

And if it had been Our Will, We could have transformed them (to remain) in their places; then should they have been unable to move about, nor could they have returned (after error).

# 3773

If We grant long life to any, We cause him to be reversed in nature: Will they not then understand?

# 3774

We have not instructed the (Prophet) in Poetry, nor is it meet for him: this is no less than a Message and a Qur'an making things clear:

# 3775

That it may give admonition to any (who are) alive, and that the charge may be proved against those who reject (Truth).

# 3776

See they not that it is We Who have created for them - among the things which Our hands have fashioned - cattle, which are under their dominion?-

# 3777

And that We have subjected them to their (use)? of them some do carry them and some they eat:

# 3778

And they have (other) profits from them (besides), and they get (milk) to drink. Will they not then be grateful?

# 3779

Yet they take (for worship) gods other than Allah, (hoping) that they might be helped!

# 3780

They have not the power to help them: but they will be brought up (before Our Judgment-seat) as a troop (to be condemned).

# 3781

Let not their speech, then, grieve thee. Verily We know what they hide as well as what they disclose.

# 3782

Doth not man see that it is We Who created him from sperm? yet behold! he (stands forth) as an open adversary!

# 3783

And he makes comparisons for Us, and forgets his own (origin and) Creation: He says, "Who can give life to (dry) bones and decomposed ones (at that)?"

# 3784

Say, "He will give them life Who created them for the first time! for He is Well-versed in every kind of creation!-

# 3785

"The same Who produces for you fire out of the green tree, when behold! ye kindle therewith (your own fires)!

# 3786

"Is not He Who created the heavens and the earth able to create the like thereof?" - Yea, indeed! for He is the Creator Supreme, of skill and knowledge (infinite)!

# 3787

Verily, when He intends a thing, His Command is, "be", and it is!

# 3788

So glory to Him in Whose hands is the dominion of all things: and to Him will ye be all brought back.

# 3789

By those who range themselves in ranks,

# 3790

And so are strong in repelling (evil),

# 3791

And thus proclaim the Message (of Allah)!

# 3792

Verily, verily, your Allah is one!-

# 3793

Lord of the heavens and of the earth and all between them, and Lord of every point at the rising of the sun!

# 3794

We have indeed decked the lower heaven with beauty (in) the stars,-

# 3795

(For beauty) and for guard against all obstinate rebellious evil spirits,

# 3796

(So) they should not strain their ears in the direction of the Exalted Assembly but be cast away from every side,

# 3797

Repulsed, for they are under a perpetual penalty,

# 3798

Except such as snatch away something by stealth, and they are pursued by a flaming fire, of piercing brightness.

# 3799

Just ask their opinion: are they the more difficult to create, or the (other) beings We have created? Them have We created out of a sticky clay!

# 3800

Truly dost thou marvel, while they ridicule,

# 3801

And, when they are admonished, pay no heed,-

# 3802

And, when they see a Sign, turn it to mockery,

# 3803

And say, "This is nothing but evident sorcery!

# 3804

"What! when we die, and become dust and bones, shall we (then) be raised up (again)

# 3805

"And also our fathers of old?"

# 3806

Say thou: "Yea, and ye shall then be humiliated (on account of your evil)."

# 3807

Then it will be a single (compelling) cry; and behold, they will begin to see!

# 3808

They will say, "Ah! Woe to us! This is the Day of Judgment!"

# 3809

(A voice will say,) "This is the Day of Sorting Out, whose truth ye (once) denied!"

# 3810

"Bring ye up", it shall be said, "The wrong-doers and their wives, and the things they worshipped-

# 3811

"Besides Allah, and lead them to the Way to the (Fierce) Fire!

# 3812

"But stop them, for they must be asked:

# 3813

"'What is the matter with you that ye help not each other?'"

# 3814

Nay, but that day they shall submit (to Judgment);

# 3815

And they will turn to one another, and question one another.

# 3816

They will say: "It was ye who used to come to us from the right hand (of power and authority)!"

# 3817

They will reply: "Nay, ye yourselves had no Faith!

# 3818

"Nor had we any authority over you. Nay, it was ye who were a people in obstinate rebellion!

# 3819

"So now has been proved true, against us, the word of our Lord that we shall indeed (have to) taste (the punishment of our sins).

# 3820

"We led you astray: for truly we were ourselves astray."

# 3821

Truly, that Day, they will (all) share in the Penalty.

# 3822

Verily that is how We shall deal with Sinners.

# 3823

For they, when they were told that there is no god except Allah, would puff themselves up with Pride,

# 3824

And say: "What! shall we give up our gods for the sake of a Poet possessed?"

# 3825

Nay! he has come with the (very) Truth, and he confirms (the Message of) the messengers (before him).

# 3826

Ye shall indeed taste of the Grievous Penalty;-

# 3827

But it will be no more than the retribution of (the Evil) that ye have wrought;-

# 3828

But the sincere (and devoted) Servants of Allah,-

# 3829

For them is a Sustenance determined,

# 3830

Fruits (Delights); and they (shall enjoy) honour and dignity,

# 3831

In Gardens of Felicity,

# 3832

Facing each other on Thrones (of Dignity):

# 3833

Round will be passed to them a Cup from a clear-flowing fountain,

# 3834

Crystal-white, of a taste delicious to those who drink (thereof),

# 3835

Free from headiness; nor will they suffer intoxication therefrom.

# 3836

And besides them will be chaste women, restraining their glances, with big eyes (of wonder and beauty).

# 3837

As if they were (delicate) eggs closely guarded.

# 3838

Then they will turn to one another and question one another.

# 3839

One of them will start the talk and say: "I had an intimate companion (on the earth),

# 3840

"Who used to say, 'what! art thou amongst those who bear witness to the Truth (of the Message)?

# 3841

"'When we die and become dust and bones, shall we indeed receive rewards and punishments?'"

# 3842

(A voice) said: "Would ye like to look down?"

# 3843

He looked down and saw him in the midst of the Fire.

# 3844

He said: "By Allah! thou wast little short of bringing me to perdition!

# 3845

"Had it not been for the Grace of my Lord, I should certainly have been among those brought (there)!

# 3846

"Is it (the case) that we shall not die,

# 3847

"Except our first death, and that we shall not be punished?"

# 3848

Verily this is the supreme achievement!

# 3849

For the like of this let all strive, who wish to strive.

# 3850

Is that the better entertainment or the Tree of Zaqqum?

# 3851

For We have truly made it (as) a trial for the wrong-doers.

# 3852

For it is a tree that springs out of the bottom of Hell-Fire:

# 3853

The shoots of its fruit-stalks are like the heads of devils:

# 3854

Truly they will eat thereof and fill their bellies therewith.

# 3855

Then on top of that they will be given a mixture made of boiling water.

# 3856

Then shall their return be to the (Blazing) Fire.

# 3857

Truly they found their fathers on the wrong Path;

# 3858

So they (too) were rushed down on their footsteps!

# 3859

And truly before them, many of the ancients went astray;-

# 3860

But We sent aforetime, among them, (messengers) to admonish them;-

# 3861

Then see what was the end of those who were admonished (but heeded not),-

# 3862

Except the sincere (and devoted) Servants of Allah.

# 3863

(In the days of old), Noah cried to Us, and We are the best to hear prayer.

# 3864

And We delivered him and his people from the Great Calamity,

# 3865

And made his progeny to endure (on this earth);

# 3866

And We left (this blessing) for him among generations to come in later times:

# 3867

"Peace and salutation to Noah among the nations!"

# 3868

Thus indeed do we reward those who do right.

# 3869

For he was one of our believing Servants.

# 3870

Then the rest we overwhelmed in the Flood.

# 3871

Verily among those who followed his Way was Abraham.

# 3872

Behold! he approached his Lord with a sound heart.

# 3873

Behold! he said to his father and to his people, "What is that which ye worship?

# 3874

"Is it a falsehood- gods other than Allah- that ye desire?

# 3875

"Then what is your idea about the Lord of the worlds?"

# 3876

Then did he cast a glance at the Stars.

# 3877

And he said, "I am indeed sick (at heart)!"

# 3878

So they turned away from him, and departed.

# 3879

Then did he turn to their gods and said, "will ye not eat (of the offerings before you)?...

# 3880

"What is the matter with you that ye speak not (intelligently)?"

# 3881

Then did he turn upon them, striking (them) with the right hand.

# 3882

Then came (the worshippers) with hurried steps, and faced (him).

# 3883

He said: "Worship ye that which ye have (yourselves) carved?

# 3884

"But Allah has created you and your handwork!"

# 3885

They said, "Build him a furnace, and throw him into the blazing fire!"

# 3886

(This failing), they then sought a stratagem against him, but We made them the ones most humiliated!

# 3887

He said: "I will go to my Lord! He will surely guide me!

# 3888

"O my Lord! Grant me a righteous (son)!"

# 3889

So We gave him the good news of a boy ready to suffer and forbear.

# 3890

Then, when (the son) reached (the age of) (serious) work with him, he said: "O my son! I see in vision that I offer thee in sacrifice: Now see what is thy view!" (The son) said: "O my father! Do as thou art commanded: thou will find me, if Allah so wills one practising Patience and Constancy!"

# 3891

So when they had both submitted their wills (to Allah), and he had laid him prostrate on his forehead (for sacrifice),

# 3892

We called out to him "O Abraham!

# 3893

"Thou hast already fulfilled the vision!" - thus indeed do We reward those who do right.

# 3894

For this was obviously a trial-

# 3895

And We ransomed him with a momentous sacrifice:

# 3896

And We left (this blessing) for him among generations (to come) in later times:

# 3897

"Peace and salutation to Abraham!"

# 3898

Thus indeed do We reward those who do right.

# 3899

For he was one of our believing Servants.

# 3900

And We gave him the good news of Isaac - a prophet,- one of the Righteous.

# 3901

We blessed him and Isaac: but of their progeny are (some) that do right, and (some) that obviously do wrong, to their own souls.

# 3902

Again (of old) We bestowed Our favour on Moses and Aaron,

# 3903

And We delivered them and their people from (their) Great Calamity;

# 3904

And We helped them, so they overcame (their troubles);

# 3905

And We gave them the Book which helps to make things clear;

# 3906

And We guided them to the Straight Way.

# 3907

And We left (this blessing) for them among generations (to come) in later times:

# 3908

"Peace and salutation to Moses and Aaron!"

# 3909

Thus indeed do We reward those who do right.

# 3910

For they were two of our believing Servants.

# 3911

So also was Elias among those sent (by Us).

# 3912

Behold, he said to his people, "Will ye not fear (Allah)?

# 3913

"Will ye call upon Baal and forsake the Best of Creators,-

# 3914

"Allah, your Lord and Cherisher and the Lord and Cherisher of your fathers of old?"

# 3915

But they rejected him, and they will certainly be called up (for punishment),-

# 3916

Except the sincere and devoted Servants of Allah (among them).

# 3917

And We left (this blessing) for him among generations (to come) in later times:

# 3918

"Peace and salutation to such as Elias!"

# 3919

Thus indeed do We reward those who do right.

# 3920

For he was one of our believing Servants.

# 3921

So also was Lut among those sent (by Us).

# 3922

Behold, We delivered him and his adherents, all

# 3923

Except an old woman who was among those who lagged behind:

# 3924

Then We destroyed the rest.

# 3925

Verily, ye pass by their (sites), by day-

# 3926

And by night: will ye not understand?

# 3927

So also was Jonah among those sent (by Us).

# 3928

When he ran away (like a slave from captivity) to the ship (fully) laden,

# 3929

He (agreed to) cast lots, and he was condemned:

# 3930

Then the big Fish did swallow him, and he had done acts worthy of blame.

# 3931

Had it not been that he (repented and) glorified Allah,

# 3932

He would certainly have remained inside the Fish till the Day of Resurrection.

# 3933

But We cast him forth on the naked shore in a state of sickness,

# 3934

And We caused to grow, over him, a spreading plant of the gourd kind.

# 3935

And We sent him (on a mission) to a hundred thousand (men) or more.

# 3936

And they believed; so We permitted them to enjoy (their life) for a while.

# 3937

Now ask them their opinion: Is it that thy Lord has (only) daughters, and they have sons?-

# 3938

Or that We created the angels female, and they are witnesses (thereto)?

# 3939

Is it not that they say, from their own invention,

# 3940

"Allah has begotten children"? but they are liars!

# 3941

Did He (then) choose daughters rather than sons?

# 3942

What is the matter with you? How judge ye?

# 3943

Will ye not then receive admonition?

# 3944

Or have ye an authority manifest?

# 3945

Then bring ye your Book (of authority) if ye be truthful!

# 3946

And they have invented a blood-relationship between Him and the Jinns: but the Jinns know (quite well) that they have indeed to appear (before his Judgment-Seat)!

# 3947

Glory to Allah! (He is free) from the things they ascribe (to Him)!

# 3948

Not (so do) the Servants of Allah, sincere and devoted.

# 3949

For, verily, neither ye nor those ye worship-

# 3950

Can lead (any) into temptation concerning Allah,

# 3951

Except such as are (themselves) going to the blazing Fire!

# 3952

(Those ranged in ranks say): "Not one of us but has a place appointed;

# 3953

"And we are verily ranged in ranks (for service);

# 3954

"And we are verily those who declare (Allah's) glory!"

# 3955

And there were those who said,

# 3956

"If only we had had before us a Message from those of old,

# 3957

"We should certainly have been Servants of Allah, sincere (and devoted)!"

# 3958

But (now that the Qur'an has come), they reject it: But soon will they know!

# 3959

Already has Our Word been passed before (this) to our Servants sent (by Us),

# 3960

That they would certainly be assisted,

# 3961

And that Our forces,- they surely must conquer.

# 3962

So turn thou away from them for a little while,

# 3963

And watch them (how they fare), and they soon shall see (how thou farest)!

# 3964

Do they wish (indeed) to hurry on our Punishment?

# 3965

But when it descends into the open space before them, evil will be the morning for those who were warned (and heeded not)!

# 3966

So turn thou away from them for a little while,

# 3967

And watch (how they fare) and they soon shall see (how thou farest)!

# 3968

Glory to thy Lord, the Lord of Honour and Power! (He is free) from what they ascribe (to Him)!

# 3969

And Peace on the messengers!

# 3970

And Praise to Allah, the Lord and Cherisher of the Worlds.

# 3971

Sad: By the Qur'an, Full of Admonition: (This is the Truth).

# 3972

But the Unbelievers (are steeped) in self-glory and Separatism.

# 3973

How many generations before them did We destroy? In the end they cried (for mercy)- when there was no longer time for being saved!

# 3974

So they wonder that a Warner has come to them from among themselves! and the Unbelievers say, "This is a sorcerer telling lies!

# 3975

"Has he made the gods (all) into one Allah? Truly this is a wonderful thing!"

# 3976

And the leader among them go away (impatiently), (saying), "Walk ye away, and remain constant to your gods! For this is truly a thing designed (against you)!

# 3977

"We never heard (the like) of this among the people of these latter days: this is nothing but a made-up tale!"

# 3978

"What! has the Message been sent to him - (Of all persons) among us?"... but they are in doubt concerning My (Own) Message! Nay, they have not yet tasted My Punishment!

# 3979

Or have they the treasures of the mercy of thy Lord,- the Exalted in Power, the Grantor of Bounties without measure?

# 3980

Or have they the dominion of the heavens and the earth and all between? If so, let them mount up with the ropes and means (to reach that end)!

# 3981

But there - will be put to flight even a host of confederates.

# 3982

Before them (were many who) rejected messengers,- the people of Noah, and 'Ad, and Pharaoh, the Lord of Stakes,

# 3983

And Thamud, and the people of Lut, and the Companions of the Wood; - such were the Confederates.

# 3984

Not one (of them) but rejected the messengers, but My punishment came justly and inevitably (on them).

# 3985

These (today) only wait for a single mighty Blast, which (when it comes) will brook no delay.

# 3986

They say: "Our Lord! hasten to us our sentence (even) before the Day of Account!"

# 3987

Have patience at what they say, and remember our servant David, the man of strength: for he ever turned (to Allah).

# 3988

It was We that made the hills declare, in unison with him, Our Praises, at eventide and at break of day,

# 3989

And the birds gathered (in assemblies): all with him did turn (to Allah).

# 3990

We strengthened his kingdom, and gave him wisdom and sound judgment in speech and decision.

# 3991

Has the Story of the Disputants reached thee? Behold, they climbed over the wall of the private chamber;

# 3992

When they entered the presence of David, and he was terrified of them, they said: "Fear not: we are two disputants, one of whom has wronged the other: Decide now between us with truth, and treat us not with injustice, but guide us to the even Path..

# 3993

"This man is my brother: He has nine and ninety ewes, and I have (but) one: Yet he says, 'commit her to my care,' and is (moreover) harsh to me in speech."

# 3994

(David) said: "He has undoubtedly wronged thee in demanding thy (single) ewe to be added to his (flock of) ewes: truly many are the partners (in business) who wrong each other: Not so do those who believe and work deeds of righteousness, and how few are they?"... and David gathered that We had tried him: he asked forgiveness of his Lord, fell down, bowing (in prostration), and turned (to Allah in repentance).

# 3995

So We forgave him this (lapse): he enjoyed, indeed, a Near Approach to Us, and a beautiful place of (Final) Return.

# 3996

O David! We did indeed make thee a vicegerent on earth: so judge thou between men in truth (and justice): Nor follow thou the lusts (of thy heart), for they will mislead thee from the Path of Allah: for those who wander astray from the Path of Allah, is a Penalty Grievous, for that they forget the Day of Account.

# 3997

Not without purpose did We create heaven and earth and all between! that were the thought of Unbelievers! but woe to the Unbelievers because of the Fire (of Hell)!

# 3998

Shall We treat those who believe and work deeds of righteousness, the same as those who do mischief on earth? Shall We treat those who guard against evil, the same as those who turn aside from the right?

# 3999

(Here is) a Book which We have sent down unto thee, full of blessings, that they may mediate on its Signs, and that men of understanding may receive admonition.

# 4000

To David We gave Solomon (for a son),- How excellent in Our service! Ever did he turn (to Us)!

# 4001

Behold, there were brought before him, at eventide coursers of the highest breeding, and swift of foot;

# 4002

And he said, "Truly do I love the love of good, with a view to the glory of my Lord,"- until (the sun) was hidden in the veil (of night):

# 4003

"Bring them back to me." then began he to pass his hand over (their) legs and their necks.

# 4004

And We did try Solomon: We placed on his throne a body (without life); but he did turn (to Us in true devotion):

# 4005

He said, "O my Lord! Forgive me, and grant me a kingdom which, (it may be), suits not another after me: for Thou art the Grantor of Bounties (without measure).

# 4006

Then We subjected the wind to his power, to flow gently to his order, Whithersoever he willed,-

# 4007

As also the evil ones, (including) every kind of builder and diver,-

# 4008

As also others bound together in fetters.

# 4009

"Such are Our Bounties: whether thou bestow them (on others) or withhold them, no account will be asked."

# 4010

And he enjoyed, indeed, a Near Approach to Us, and a beautiful Place of (Final) Return.

# 4011

Commemorate Our Servant Job. Behold he cried to his Lord: "The Evil One has afflicted me with distress and suffering!"

# 4012

(The command was given:) "Strike with thy foot: here is (water) wherein to wash, cool and refreshing, and (water) to drink."

# 4013

And We gave him (back) his people, and doubled their number,- as a Grace from Ourselves, and a thing for commemoration, for all who have Understanding.

# 4014

"And take in thy hand a little grass, and strike therewith: and break not (thy oath)." Truly We found him full of patience and constancy. How excellent in Our service! ever did he turn (to Us)!

# 4015

And commemorate Our Servants Abraham, Isaac, and Jacob, possessors of Power and Vision.

# 4016

Verily We did choose them for a special (purpose)- proclaiming the Message of the Hereafter.

# 4017

They were, in Our sight, truly, of the company of the Elect and the Good.

# 4018

And commemorate Isma'il, Elisha, and Zul-Kifl: Each of them was of the Company of the Good.

# 4019

This is a Message (of admonition): and verily, for the righteous, is a beautiful Place of (Final) Return,-

# 4020

Gardens of Eternity, whose doors will (ever) be open to them;

# 4021

Therein will they recline (at ease): Therein can they call (at pleasure) for fruit in abundance, and (delicious) drink;

# 4022

And beside them will be chaste women restraining their glances, (companions) of equal age.

# 4023

Such is the Promise made, to you for the Day of Account!

# 4024

Truly such will be Our Bounty (to you); it will never fail;-

# 4025

Yea, such! but - for the wrong-doers will be an evil place of (Final) Return!-

# 4026

Hell!- they will burn therein, - an evil bed (indeed, to lie on)!-

# 4027

Yea, such! - then shall they taste it,- a boiling fluid, and a fluid dark, murky, intensely cold!-

# 4028

And other Penalties of a similar kind, to match them!

# 4029

Here is a troop rushing headlong with you! No welcome for them! truly, they shall burn in the Fire!

# 4030

(The followers shall cry to the misleaders:) "Nay, ye (too)! No welcome for you! It is ye who have brought this upon us! Now evil is (this) place to stay in!"

# 4031

They will say: "Our Lord! whoever brought this upon us,- Add to him a double Penalty in the Fire!"

# 4032

And they will say: "What has happened to us that we see not men whom we used to number among the bad ones?

# 4033

"Did we treat them (as such) in ridicule, or have (our) eyes failed to perceive them?"

# 4034

Truly that is just and fitting,- the mutual recriminations of the People of the Fire!

# 4035

Say: "Truly am I a Warner: no god is there but the one Allah, Supreme and Irresistible,-

# 4036

"The Lord of the heavens and the earth, and all between,- Exalted in Might, able to enforce His Will, forgiving again and again."

# 4037

Say: "That is a Message Supreme (above all),-

# 4038

"From which ye do turn away!

# 4039

"No knowledge have I of the Chiefs on high, when they discuss (matters) among themselves.

# 4040

'Only this has been revealed to me: that I am to give warning plainly and publicly."

# 4041

Behold, thy Lord said to the angels: "I am about to create man from clay:

# 4042

"When I have fashioned him (in due proportion) and breathed into him of My spirit, fall ye down in obeisance unto him."

# 4043

So the angels prostrated themselves, all of them together:

# 4044

Not so Iblis: he was haughty, and became one of those who reject Faith.

# 4045

(Allah) said: "O Iblis! What prevents thee from prostrating thyself to one whom I have created with my hands? Art thou haughty? Or art thou one of the high (and mighty) ones?"

# 4046

(Iblis) said: "I am better than he: thou createdst me from fire, and him thou createdst from clay."

# 4047

(Allah) said: "Then get thee out from here: for thou art rejected, accursed.

# 4048

"And My curse shall be on thee till the Day of Judgment."

# 4049

(Iblis) said: "O my Lord! Give me then respite till the Day the (dead) are raised."

# 4050

(Allah) said: "Respite then is granted thee-

# 4051

"Till the Day of the Time Appointed."

# 4052

(Iblis) said: "Then, by Thy power, I will put them all in the wrong,-

# 4053

"Except Thy Servants amongst them, sincere and purified (by Thy Grace)."

# 4054

(Allah) said: "Then it is just and fitting- and I say what is just and fitting-

# 4055

"That I will certainly fill Hell with thee and those that follow thee,- every one."

# 4056

Say: "No reward do I ask of you for this (Qur'an), nor am I a pretender.

# 4057

"This is no less than a Message to (all) the Worlds.

# 4058

"And ye shall certainly know the truth of it (all) after a while."

# 4059

The revelation of this Book is from Allah, the Exalted in Power, full of Wisdom.

# 4060

Verily it is We Who have revealed the Book to thee in Truth: so serve Allah, offering Him sincere devotion.

# 4061

Is it not to Allah that sincere devotion is due? But those who take for protectors other than Allah (say): "We only serve them in order that they may bring us nearer to Allah." Truly Allah will judge between them in that wherein they differ. But Allah guides not such as are false and ungrateful.

# 4062

Had Allah wished to take to Himself a son, He could have chosen whom He pleased out of those whom He doth create: but Glory be to Him! (He is above such things.) He is Allah, the One, the Irresistible.

# 4063

He created the heavens and the earth in true (proportions): He makes the Night overlap the Day, and the Day overlap the Night: He has subjected the sun and the moon (to His law): Each one follows a course for a time appointed. Is not He the Exalted in Power - He Who forgives again and again?

# 4064

He created you (all) from a single person: then created, of like nature, his mate; and he sent down for you eight head of cattle in pairs: He makes you, in the wombs of your mothers, in stages, one after another, in three veils of darkness. such is Allah, your Lord and Cherisher: to Him belongs (all) dominion. There is no god but He: then how are ye turned away (from your true Centre)?

# 4065

If ye reject (Allah), Truly Allah hath no need of you; but He liketh not ingratitude from His servants: if ye are grateful, He is pleased with you. No bearer of burdens can bear the burden of another. In the end, to your Lord is your Return, when He will tell you the truth of all that ye did (in this life). for He knoweth well all that is in (men's) hearts.

# 4066

When some trouble toucheth man, he crieth unto his Lord, turning to Him in repentance: but when He bestoweth a favour upon him as from Himself, (man) doth forget what he cried and prayed for before, and he doth set up rivals unto Allah, thus misleading others from Allah's Path. Say, "Enjoy thy blasphemy for a little while: verily thou art (one) of the Companions of the Fire!"

# 4067

Is one who worships devoutly during the hour of the night prostrating himself or standing (in adoration), who takes heed of the Hereafter, and who places his hope in the Mercy of his Lord - (like one who does not)? Say: "Are those equal, those who know and those who do not know? It is those who are endued with understanding that receive admonition.

# 4068

Say: "O ye my servants who believe! Fear your Lord, good is (the reward) for those who do good in this world. Spacious is Allah's earth! those who patiently persevere will truly receive a reward without measure!"

# 4069

Say: "Verily, I am commanded to serve Allah with sincere devotion;

# 4070

"And I am commanded to be the first of those who bow to Allah in Islam."

# 4071

Say: "I would, if I disobeyed my Lord, indeed have fear of the Penalty of a Mighty Day."

# 4072

Say: "It is Allah I serve, with my sincere (and exclusive) devotion:

# 4073

"Serve ye what ye will besides him." Say: "Truly, those in loss are those who lose their own souls and their People on the Day of Judgment: Ah! that is indeed the (real and) evident Loss!

# 4074

They shall have Layers of Fire above them, and Layers (of Fire) below them: with this doth Allah warn off his servants: "O My Servants! then fear ye Me!"

# 4075

Those who eschew Evil,- and fall not into its worship,- and turn to Allah (in repentance),- for them is Good News: so announce the Good News to My Servants,-

# 4076

Those who listen to the Word, and follow the best (meaning) in it: those are the ones whom Allah has guided, and those are the ones endued with understanding.

# 4077

Is, then, one against whom the decree of Punishment is justly due (equal to one who eschews Evil)? Wouldst thou, then, deliver one (who is) in the Fire?

# 4078

But it is for those who fear their Lord. That lofty mansions, one above another, have been built: beneath them flow rivers (of delight): (such is) the Promise of Allah: never doth Allah fail in (His) promise.

# 4079

Seest thou not that Allah sends down rain from the sky, and leads it through springs in the earth? Then He causes to grow, therewith, produce of various colours: then it withers; thou wilt see it grow yellow; then He makes it dry up and crumble away. Truly, in this, is a Message of remembrance to men of understanding.

# 4080

Is one whose heart Allah has opened to Islam, so that he has received Enlightenment from Allah, (no better than one hard-hearted)? Woe to those whose hearts are hardened against celebrating the praises of Allah! they are manifestly wandering (in error)!

# 4081

Allah has revealed (from time to time) the most beautiful Message in the form of a Book, consistent with itself, (yet) repeating (its teaching in various aspects): the skins of those who fear their Lord tremble thereat; then their skins and their hearts do soften to the celebration of Allah's praises. Such is the guidance of Allah: He guides therewith whom He pleases, but such as Allah leaves to stray, can have none to guide.

# 4082

Is, then, one who has to fear the brunt of the Penalty on the Day of Judgment (and receive it) on his face, (like one guarded therefrom)? It will be said to the wrong-doers: "Taste ye (the fruits of) what ye earned!"

# 4083

Those before them (also) rejected (revelation), and so the Punishment came to them from directions they did not perceive.

# 4084

So Allah gave them a taste of humiliation in the present life, but greater is the punishment of the Hereafter, if they only knew!

# 4085

We have put forth for men, in this Qur'an every kind of Parable, in order that they may receive admonition.

# 4086

(It is) a Qur'an in Arabic, without any crookedness (therein): in order that they may guard against Evil.

# 4087

Allah puts forth a Parable a man belonging to many partners at variance with each other, and a man belonging entirely to one master: are those two equal in comparison? Praise be to Allah! but most of them have no knowledge.

# 4088

Truly thou wilt die (one day), and truly they (too) will die (one day).

# 4089

In the end will ye (all), on the Day of Judgment, settle your disputes in the presence of your Lord.

# 4090

Who, then, doth more wrong than one who utters a lie concerning Allah, and rejects the Truth when it comes to him; is there not in Hell an abode for blasphemers?

# 4091

And he who brings the Truth and he who confirms (and supports) it - such are the men who do right.

# 4092

They shall have all that they wish for, in the presence of their Lord: such is the reward of those who do good:

# 4093

So that Allah will turn off from them (even) the worst in their deeds and give them their reward according to the best of what they have done.

# 4094

Is not Allah enough for his Servant? But they try to frighten thee with other (gods) besides Him! for such as Allah leaves to stray, there can be no guide.

# 4095

And such as Allah doth guide there can be none to lead astray. Is not Allah Exalted in Power, (Able to enforce His Will), Lord of Retribution?

# 4096

If indeed thou ask them who it is that created the heavens and the earth, they would be sure to say, "Allah". Say: "See ye then? the things that ye invoke besides Allah,- can they, if Allah wills some Penalty for me, remove His Penalty?- Or if He wills some Grace for me, can they keep back his Grace?" Say: "Sufficient is Allah for me! In Him trust those who put their trust."

# 4097

Say: "O my People! Do whatever ye can: I will do (my part): but soon will ye know-

# 4098

"Who it is to whom comes a Penalty of ignominy, and on whom descends a Penalty that abides."

# 4099

Verily We have revealed the Book to thee in Truth, for (instructing) mankind. He, then, that receives guidance benefits his own soul: but he that strays injures his own soul. Nor art thou set over them to dispose of their affairs.

# 4100

It is Allah that takes the souls (of men) at death; and those that die not (He takes) during their sleep: those on whom He has passed the decree of death, He keeps back (from returning to life), but the rest He sends (to their bodies) for a term appointed verily in this are Signs for those who reflect.

# 4101

What! Do they take for intercessors others besides Allah? Say: "Even if they have no power whatever and no intelligence?"

# 4102

Say: "To Allah belongs exclusively (the right to grant) intercession: to Him belongs the dominion of the heavens and the earth: In the End, it is to Him that ye shall be brought back."

# 4103

When Allah, the One and Only, is mentioned, the hearts of those who believe not in the Hereafter are filled with disgust and horror; but when (gods) other than He are mentioned, behold, they are filled with joy!

# 4104

Say: "O Allah! Creator of the heavens and the earth! Knower of all that is hidden and open! it is Thou that wilt judge between Thy Servants in those matters about which they have differed."

# 4105

Even if the wrong-doers had all that there is on earth, and as much more, (in vain) would they offer it for ransom from the pain of the Penalty on the Day of Judgment: but something will confront them from Allah, which they could never have counted upon!

# 4106

For the evils of their Deeds will confront them, and they will be (completely) encircled by that which they used to mock at!

# 4107

Now, when trouble touches man, he cries to Us: But when We bestow a favour upon him as from Ourselves, he says, "This has been given to me because of a certain knowledge (I have)!" Nay, but this is but a trial, but most of them understand not!

# 4108

Thus did the (generations) before them say! But all that they did was of no profit to them.

# 4109

Nay, the evil results of their Deeds overtook them. And the wrong-doers of this (generation)- the evil results of their Deeds will soon overtake them (too), and they will never be able to frustrate (Our Plan)!

# 4110

Know they not that Allah enlarges the provision or restricts it, for any He pleases? Verily, in this are Signs for those who believe!

# 4111

Say: "O my Servants who have transgressed against their souls! Despair not of the Mercy of Allah: for Allah forgives all sins: for He is Oft-Forgiving, Most Merciful.

# 4112

"Turn ye to our Lord (in repentance) and bow to His (Will), before the Penalty comes on you: after that ye shall not be helped.

# 4113

"And follow the best of (the courses) revealed to you from your Lord, before the Penalty comes on you - of a sudden while ye perceive not!-

# 4114

"Lest the soul should (then) say: 'Ah! Woe is me!- In that I neglected (my duty) towards Allah, and was but among those who mocked!'-

# 4115

"Or (lest) it should say: 'If only Allah had guided me, I should certainly have been among the righteous!'-

# 4116

"Or (lest) it should say when it (actually) sees the penalty: 'If only I had another chance, I should certainly be among those who do good!'

# 4117

"(The reply will be:) 'Nay, but there came to thee my Signs, and thou didst reject them: thou wast Haughty, and became one of those who reject faith!'"

# 4118

On the Day of Judgment wilt thou see those who told lies against Allah;- their faces will be turned black; Is there not in Hell an abode for the Haughty?

# 4119

But Allah will deliver the righteous to their place of salvation: no evil shall touch them, nor shall they grieve.

# 4120

Allah is the Creator of all things, and He is the Guardian and Disposer of all affairs.

# 4121

To Him belong the keys of the heavens and the earth: and those who reject the Signs of Allah,- it is they who will be in loss.

# 4122

Say: "Is it some one other than Allah that ye order me to worship, O ye ignorant ones?"

# 4123

But it has already been revealed to thee,- as it was to those before thee,- "If thou wert to join (gods with Allah), truly fruitless will be thy work (in life), and thou wilt surely be in the ranks of those who lose (all spiritual good)".

# 4124

Nay, but worship Allah, and be of those who give thanks.

# 4125

No just estimate have they made of Allah, such as is due to Him: On the Day of Judgment the whole of the earth will be but His handful, and the heavens will be rolled up in His right hand: Glory to Him! High is He above the Partners they attribute to Him!

# 4126

The Trumpet will (just) be sounded, when all that are in the heavens and on earth will swoon, except such as it will please Allah (to exempt). Then will a second one be sounded, when, behold, they will be standing and looking on!

# 4127

And the Earth will shine with the Glory of its Lord: the Record (of Deeds) will be placed (open); the prophets and the witnesses will be brought forward and a just decision pronounced between them; and they will not be wronged (in the least).

# 4128

And to every soul will be paid in full (the fruit) of its Deeds; and (Allah) knoweth best all that they do.

# 4129

The Unbelievers will be led to Hell in crowd: until, when they arrive, there, its gates will be opened. And its keepers will say, "Did not messengers come to you from among yourselves, rehearsing to you the Signs of your Lord, and warning you of the Meeting of This Day of yours?" The answer will be: "True: but the Decree of Punishment has been proved true against the Unbelievers!"

# 4130

(To them) will be said: "Enter ye the gates of Hell, to dwell therein: and evil is (this) Abode of the Arrogant!"

# 4131

And those who feared their Lord will be led to the Garden in crowds: until behold, they arrive there; its gates will be opened; and its keepers will say: "Peace be upon you! well have ye done! enter ye here, to dwell therein."

# 4132

They will say: "Praise be to Allah, Who has truly fulfilled His Promise to us, and has given us (this) land in heritage: We can dwell in the Garden as we will: how excellent a reward for those who work (righteousness)!"

# 4133

And thou wilt see the angels surrounding the Throne (Divine) on all sides, singing Glory and Praise to their Lord. The Decision between them (at Judgment) will be in (perfect) justice, and the cry (on all sides) will be, "Praise be to Allah, the Lord of the Worlds!"

# 4134

Ha Mim

# 4135

The revelation of this Book is from Allah, Exalted in Power, Full of Knowledge,-

# 4136

Who forgiveth sin, accepteth repentance, is strict in punishment, and hath a long reach (in all things). there is no god but He: to Him is the final goal.

# 4137

None can dispute about the Signs of Allah but the Unbelievers. Let not, then, their strutting about through the land deceive thee!

# 4138

But (there were people) before them, who denied (the Signs),- the People of Noah, and the Confederates (of Evil) after them; and every People plotted against their prophet, to seize him, and disputed by means of vanities, therewith to condemn the Truth; but it was I that seized them! and how (terrible) was My Requital!

# 4139

Thus was the Decree of thy Lord proved true against the Unbelievers; that truly they are Companions of the Fire!

# 4140

Those who sustain the Throne (of Allah) and those around it Sing Glory and Praise to their Lord; believe in Him; and implore Forgiveness for those who believe: "Our Lord! Thy Reach is over all things, in Mercy and Knowledge. Forgive, then, those who turn in Repentance, and follow Thy Path; and preserve them from the Penalty of the Blazing Fire!

# 4141

"And grant, our Lord! that they enter the Gardens of Eternity, which Thou hast promised to them, and to the righteous among their fathers, their wives, and their posterity! For Thou art (He), the Exalted in Might, Full of Wisdom.

# 4142

"And preserve them from (all) ills; and any whom Thou dost preserve from ills that Day,- on them wilt Thou have bestowed Mercy indeed: and that will be truly (for them) the highest Achievement".

# 4143

The Unbelievers will be addressed: "Greater was the aversion of Allah to you than (is) your aversion to yourselves, seeing that ye were called to the Faith and ye used to refuse."

# 4144

They will say: "Our Lord! twice hast Thou made us without life, and twice hast Thou given us Life! Now have we recognised our sins: Is there any way out (of this)?"

# 4145

(The answer will be:) "This is because, when Allah was invoked as the Only (object of worship), ye did reject Faith, but when partners were joined to Him, ye believed! the Command is with Allah, Most High, Most Great!"

# 4146

He it is Who showeth you his Signs, and sendeth down sustenance for you from the sky: but only those receive admonition who turn (to Allah).

# 4147

Call ye, then, upon Allah with sincere devotion to Him, even though the Unbelievers may detest it.

# 4148

Raised high above ranks (or degrees), (He is) the Lord of the Throne (of Authority): by His Command doth He send the Spirit (of inspiration) to any of His servants he pleases, that it may warn (men) of the Day of Mutual Meeting,-

# 4149

The Day whereon they will (all) come forth: not a single thing concerning them is hidden from Allah. Whose will be the dominion that Day?" That of Allah, the One the Irresistible!

# 4150

That Day will every soul be requited for what it earned; no injustice will there be that Day, for Allah is Swift in taking account.

# 4151

Warn them of the Day that is (ever) drawing near, when the hearts will (come) right up to the throats to choke (them); No intimate friend nor intercessor will the wrong-doers have, who could be listened to.

# 4152

(Allah) knows of (the tricks) that deceive with the eyes, and all that the hearts (of men) conceal.

# 4153

And Allah will judge with (justice and) Truth: but those whom (men) invoke besides Him, will not (be in a position) to judge at all. Verily it is Allah (alone) Who hears and sees (all things).

# 4154

Do they not travel through the earth and see what was the End of those before them? They were even superior to them in strength, and in the traces (they have left) in the land: but Allah did call them to account for their sins, and none had they to defend them against Allah.

# 4155

That was because there came to them their messengers with Clear (Signs), but they rejected them: So Allah called them to account: for He is Full of Strength, Strict in Punishment.

# 4156

Of old We sent Moses, with Our Signs and an authority manifest,

# 4157

To Pharaoh, Haman, and Qarun; but they called (him)" a sorcerer telling lies!"...

# 4158

Now, when he came to them in Truth, from Us, they said, "Slay the sons of those who believe with him, and keep alive their females," but the plots of Unbelievers (end) in nothing but errors (and delusions)!...

# 4159

Said Pharaoh: "Leave me to slay Moses; and let him call on his Lord! What I fear is lest he should change your religion, or lest he should cause mischief to appear in the land!"

# 4160

Moses said: "I have indeed called upon my Lord and your Lord (for protection) from every arrogant one who believes not in the Day of Account!"

# 4161

A believer, a man from among the people of Pharaoh, who had concealed his faith, said: "Will ye slay a man because he says, 'My Lord is Allah'?- when he has indeed come to you with Clear (Signs) from your Lord? and if he be a liar, on him is (the sin of) his lie: but, if he is telling the Truth, then will fall on you something of the (calamity) of which he warns you: Truly Allah guides not one who transgresses and lies!

# 4162

"O my People! Yours is the dominion this day: Ye have the upper hand in the land: but who will help us from the Punishment of Allah, should it befall us?" Pharaoh said: "I but point out to you that which I see (myself); Nor do I guide you but to the Path of Right!"

# 4163

Then said the man who believed: "O my people! Truly I do fear for you something like the Day (of disaster) of the Confederates (in sin)!-

# 4164

"Something like the fate of the People of Noah, the 'Ad, and the Thamud, and those who came after them: but Allah never wishes injustice to his Servants.

# 4165

"And O my people! I fear for you a Day when there will be Mutual calling (and wailing),-

# 4166

"A Day when ye shall turn your backs and flee: No defender shall ye have from Allah: Any whom Allah leaves to stray, there is none to guide...

# 4167

"And to you there came Joseph in times gone by, with Clear Signs, but ye ceased not to doubt of the (Mission) for which he had come: At length, when he died, ye said: 'No messenger will Allah send after him.' thus doth Allah leave to stray such as transgress and live in doubt,-

# 4168

"(Such) as dispute about the Signs of Allah, without any authority that hath reached them, grievous and odious (is such conduct) in the sight of Allah and of the Believers. Thus doth Allah, seal up every heart - of arrogant and obstinate Transgressors."

# 4169

Pharaoh said: "O Haman! Build me a lofty palace, that I may attain the ways and means-

# 4170

"The ways and means of (reaching) the heavens, and that I may mount up to the god of Moses: But as far as I am concerned, I think (Moses) is a liar!" Thus was made alluring, in Pharaoh's eyes, the evil of his deeds, and he was hindered from the Path; and the plot of Pharaoh led to nothing but perdition (for him).

# 4171

The man who believed said further: "O my people! Follow me: I will lead you to the Path of Right.

# 4172

"O my people! This life of the present is nothing but (temporary) convenience: It is the Hereafter that is the Home that will last.

# 4173

"He that works evil will not be requited but by the like thereof: and he that works a righteous deed - whether man or woman - and is a Believer- such will enter the Garden (of Bliss): Therein will they have abundance without measure.

# 4174

"And O my people! How (strange) it is for me to call you to Salvation while ye call me to the Fire!

# 4175

"Ye do call upon me to blaspheme against Allah, and to join with Him partners of whom I have no knowledge; and I call you to the Exalted in Power, Who forgives again and again!"

# 4176

"Without doubt ye do call me to one who is not fit to be called to, whether in this world, or in the Hereafter; our return will be to Allah; and the Transgressors will be Companions of the Fire!

# 4177

"Soon will ye remember what I say to you (now), My (own) affair I commit to Allah: for Allah (ever) watches over His Servants."

# 4178

Then Allah saved him from (every) ill that they plotted (against him), but the burnt of the Penalty encompassed on all sides the People of Pharaoh.

# 4179

In front of the Fire will they be brought, morning and evening: And (the sentence will be) on the Day that Judgment will be established: "Cast ye the People of Pharaoh into the severest Penalty!"

# 4180

Behold, they will dispute with each other in the Fire! The weak ones (who followed) will say to those who had been arrogant, "We but followed you: Can ye then take (on yourselves) from us some share of the Fire?

# 4181

Those who had been arrogant will say: "We are all in this (Fire)! Truly, Allah has judged between (his) Servants!"

# 4182

Those in the Fire will say to the Keepers of Hell: "Pray to your Lord to lighten us the Penalty for a day (at least)!"

# 4183

They will say: "Did there not come to you your messengers with Clear Signs?" They will say, "Yes". They will reply, "Then pray (as ye like)! But the prayer of those without Faith is nothing but (futile wandering) in (mazes of) error!"

# 4184

We will, without doubt, help our messengers and those who believe, (both) in this world's life and on the Day when the Witnesses will stand forth,-

# 4185

The Day when no profit will it be to Wrong-doers to present their excuses, but they will (only) have the Curse and the Home of Misery.

# 4186

We did aforetime give Moses the (Book of) Guidance, and We gave the book in inheritance to the Children of Israel,-

# 4187

A Guide and a Message to men of Understanding.

# 4188

Patiently, then, persevere: for the Promise of Allah is true: and ask forgiveness for thy fault, and celebrate the Praises of thy Lord in the evening and in the morning.

# 4189

Those who dispute about the signs of Allah without any authority bestowed on them,- there is nothing in their breasts but (the quest of) greatness, which they shall never attain to: seek refuge, then, in Allah: It is He Who hears and sees (all things).

# 4190

Assuredly the creation of the heavens and the earth is a greater (matter) than the creation of men: Yet most men understand not.

# 4191

Not equal are the blind and those who (clearly) see: Nor are (equal) those who believe and work deeds of righteousness, and those who do evil. Little do ye learn by admonition!

# 4192

The Hour will certainly come: Therein is no doubt: Yet most men believe not.

# 4193

And your Lord says: "Call on Me; I will answer your (Prayer): but those who are too arrogant to serve Me will surely find themselves in Hell - in humiliation!"

# 4194

It is Allah Who has made the Night for you, that ye may rest therein, and the days as that which helps (you) to see. Verily Allah is full of Grace and Bounty to men: yet most men give no thanks.

# 4195

Such is Allah, your Lord, the Creator of all things, there is no god but He: Then how ye are deluded away from the Truth!

# 4196

Thus are deluded those who are wont to reject the Signs of Allah.

# 4197

It is Allah Who has made for you the earth as a resting place, and the sky as a canopy, and has given you shape- and made your shapes beautiful,- and has provided for you Sustenance, of things pure and good;- such is Allah your Lord. So Glory to Allah, the Lord of the Worlds!

# 4198

He is the Living (One): There is no god but He: Call upon Him, giving Him sincere devotion. Praise be to Allah, Lord of the Worlds!

# 4199

Say: "I have been forbidden to invoke those whom ye invoke besides Allah,- seeing that the Clear Signs have come to me from my Lord; and I have been commanded to bow (in Islam) to the Lord of the Worlds."

# 4200

It is He Who has created you from dust then from a sperm-drop, then from a leech-like clot; then does he get you out (into the light) as a child: then lets you (grow and) reach your age of full strength; then lets you become old,- though of you there are some who die before;- and lets you reach a Term appointed; in order that ye may learn wisdom.

# 4201

It is He Who gives Life and Death; and when He decides upon an affair, He says to it, "Be", and it is.

# 4202

Seest thou not those that dispute concerning the Signs of Allah? How are they turned away (from Reality)?-

# 4203

Those who reject the Book and the (revelations) with which We sent our messengers: but soon shall they know,-

# 4204

When the yokes (shall be) round their necks, and the chains; they shall be dragged along-

# 4205

In the boiling fetid fluid: then in the Fire shall they be burned;

# 4206

Then shall it be said to them: "Where are the (deities) to which ye gave part-worship-

# 4207

"In derogation of Allah?" They will reply: "They have left us in the lurch: Nay, we invoked not, of old, anything (that had real existence)." Thus does Allah leave the Unbelievers to stray.

# 4208

"That was because ye were wont to rejoice on the earth in things other than the Truth, and that ye were wont to be insolent.

# 4209

"Enter ye the gates of Hell, to dwell therein: and evil is (this) abode of the arrogant!"

# 4210

So persevere in patience; for the Promise of Allah is true: and whether We show thee (in this life) some part of what We promise them,- or We take thy soul (to Our Mercy) (before that),-(in any case) it is to Us that they shall (all) return.

# 4211

We did aforetime send messengers before thee: of them there are some whose story We have related to thee, and some whose story We have not related to thee. It was not (possible) for any messenger to bring a sign except by the leave of Allah: but when the Command of Allah issued, the matter was decided in truth and justice, and there perished, there and then those who stood on Falsehoods.

# 4212

It is Allah Who made cattle for you, that ye may use some for riding and some for food;

# 4213

And there are (other) advantages in them for you (besides); that ye may through them attain to any need (there may be) in your hearts; and on them and on ships ye are carried.

# 4214

And He shows you (always) His Signs: then which of the Signs of Allah will ye deny?

# 4215

Do they not travel through the earth and see what was the End of those before them? They were more numerous than these and superior in strength and in the traces (they have left) in the land: Yet all that they accomplished was of no profit to them.

# 4216

For when their messengers came to them with Clear Signs, they exulted in such knowledge (and skill) as they had; but that very (Wrath) at which they were wont to scoff hemmed them in.

# 4217

But when they saw Our Punishment, they said: "We believe in Allah,- the one Allah - and we reject the partners we used to join with Him."

# 4218

But their professing the Faith when they (actually) saw Our Punishment was not going to profit them. (Such has been) Allah's Way of dealing with His Servants (from the most ancient times). And even thus did the Rejecters of Allah perish (utterly)!

# 4219

Ha Mim:

# 4220

A Revelation from (Allah), Most Gracious, Most Merciful;-

# 4221

A Book, whereof the verses are explained in detail;- a Qur'an in Arabic, for people who understand;-

# 4222

Giving good news and admonition: yet most of them turn away, and so they hear not.

# 4223

They say: "Our hearts are under veils, (concealed) from that to which thou dost invite us, and in our ears in a deafness, and between us and thee is a screen: so do thou (what thou wilt); for us, we shall do (what we will!)"

# 4224

Say thou: "I am but a man like you: It is revealed to me by Inspiration, that your Allah is one Allah: so stand true to Him, and ask for His Forgiveness." And woe to those who join gods with Allah,-

# 4225

Those who practise not regular Charity, and who even deny the Hereafter.

# 4226

For those who believe and work deeds of righteousness is a reward that will never fail.

# 4227

Say: Is it that ye deny Him Who created the earth in two Days? And do ye join equals with Him? He is the Lord of (all) the Worlds.

# 4228

He set on the (earth), mountains standing firm, high above it, and bestowed blessings on the earth, and measure therein all things to give them nourishment in due proportion, in four Days, in accordance with (the needs of) those who seek (Sustenance).

# 4229

Moreover He comprehended in His design the sky, and it had been (as) smoke: He said to it and to the earth: "Come ye together, willingly or unwillingly." They said: "We do come (together), in willing obedience."

# 4230

So He completed them as seven firmaments in two Days, and He assigned to each heaven its duty and command. And We adorned the lower heaven with lights, and (provided it) with guard. Such is the Decree of (Him) the Exalted in Might, Full of Knowledge.

# 4231

But if they turn away, say thou: "I have warned you of a stunning Punishment (as of thunder and lightning) like that which (overtook) the 'Ad and the Thamud!"

# 4232

Behold, the messengers came to them, from before them and behind them, (preaching): "Serve none but Allah." They said, "If our Lord had so pleased, He would certainly have sent down angels (to preach). Now we reject your mission (altogether)."

# 4233

Now the 'Ad behaved arrogantly through the land, against (all) truth and reason, and said: "Who is superior to us in strength?" What! did they not see that Allah, Who created them, was superior to them in strength? But they continued to reject Our Signs!

# 4234

So We sent against them a furious Wind through days of disaster, that We might give them a taste of a Penalty of humiliation in this life; but the Penalty of a Hereafter will be more humiliating still: and they will find no help.

# 4235

As to the Thamud, We gave them Guidance, but they preferred blindness (of heart) to Guidance: so the stunning Punishment of humiliation seized them, because of what they had earned.

# 4236

But We delivered those who believed and practised righteousness.

# 4237

On the Day that the enemies of Allah will be gathered together to the Fire, they will be marched in ranks.

# 4238

At length, when they reach the (Fire), their hearing, their sight, and their skins will bear witness against them, as to (all) their deeds.

# 4239

They will say to their skins: "Why bear ye witness against us?" They will say: "Allah hath given us speech,- (He) Who giveth speech to everything: He created you for the first time, and unto Him were ye to return.

# 4240

"Ye did not seek to hide yourselves, lest your hearing, your sight, and your skins should bear witness against you! But ye did think that Allah knew not many of the things that ye used to do!

# 4241

"But this thought of yours which ye did entertain concerning your Lord, hath brought you to destruction, and (now) have ye become of those utterly lost!"

# 4242

If, then, they have patience, the Fire will be a home for them! and if they beg to be received into favour, into favour will they not (then) be received.

# 4243

And We have destined for them intimate companions (of like nature), who made alluring to them what was before them and behind them; and the sentence among the previous generations of Jinns and men, who have passed away, is proved against them; for they are utterly lost.

# 4244

The Unbelievers say: "Listen not to this Qur'an, but talk at random in the midst of its (reading), that ye may gain the upper hand!"

# 4245

But We will certainly give the Unbelievers a taste of a severe Penalty, and We will requite them for the worst of their deeds.

# 4246

Such is the requital of the enemies of Allah,- the Fire: therein will be for them the Eternal Home: a (fit) requital, for that they were wont to reject Our Signs.

# 4247

And the Unbelievers will say: "Our Lord! Show us those, among Jinns and men, who misled us: We shall crush them beneath our feet, so that they become the vilest (before all)."

# 4248

In the case of those who say, "Our Lord is Allah", and, further, stand straight and steadfast, the angels descend on them (from time to time): "Fear ye not!" (they suggest), "Nor grieve! but receive the Glad Tidings of the Garden (of Bliss), the which ye were promised!

# 4249

"We are your protectors in this life and in the Hereafter: therein shall ye have all that your souls shall desire; therein shall ye have all that ye ask for!-

# 4250

"A hospitable gift from one Oft-Forgiving, Most Merciful!"

# 4251

Who is better in speech than one who calls (men) to Allah, works righteousness, and says, "I am of those who bow in Islam"?

# 4252

Nor can goodness and Evil be equal. Repel (Evil) with what is better: Then will he between whom and thee was hatred become as it were thy friend and intimate!

# 4253

And no one will be granted such goodness except those who exercise patience and self-restraint,- none but persons of the greatest good fortune.

# 4254

And if (at any time) an incitement to discord is made to thee by the Evil One, seek refuge in Allah. He is the One Who hears and knows all things.

# 4255

Among His Signs are the Night and the Day, and the Sun and the Moon. Do not prostrate to the sun and the moon, but prostrate to Allah, Who created them, if it is Him ye wish to serve.

# 4256

But is the (Unbelievers) are arrogant, (no matter): for in the presence of thy Lord are those who celebrate His praises by night and by day. And they never flag (nor feel themselves above it).

# 4257

And among His Signs in this: thou seest the earth barren and desolate; but when We send down rain to it, it is stirred to life and yields increase. Truly, He Who gives life to the (dead) earth can surely give life to (men) who are dead. For He has power over all things.

# 4258

Those who pervert the Truth in Our Signs are not hidden from Us. Which is better?- he that is cast into the Fire, or he that comes safe through, on the Day of Judgment? Do what ye will: verily He seeth (clearly) all that ye do.

# 4259

Those who reject the Message when it comes to them (are not hidden from Us). And indeed it is a Book of exalted power.

# 4260

No falsehood can approach it from before or behind it: It is sent down by One Full of Wisdom, Worthy of all Praise.

# 4261

Nothing is said to thee that was not said to the messengers before thee: that thy lord has at his Command (all) forgiveness as well as a most Grievous Penalty.

# 4262

Had We sent this as a Qur'an (in the language) other than Arabic, they would have said: "Why are not its verses explained in detail? What! (a Book) not in Arabic and (a Messenger an Arab?" Say: "It is a Guide and a Healing to those who believe; and for those who believe not, there is a deafness in their ears, and it is blindness in their (eyes): They are (as it were) being called from a place far distant!"

# 4263

We certainly gave Moses the Book aforetime: but disputes arose therein. Had it not been for a Word that went forth before from thy Lord, (their differences) would have been settled between them: but they remained in suspicious disquieting doubt thereon.

# 4264

Whoever works righteousness benefits his own soul; whoever works evil, it is against his own soul: nor is thy Lord ever unjust (in the least) to His Servants.

# 4265

To Him is referred the Knowledge of the Hour (of Judgment: He knows all): No date-fruit comes out of its sheath, nor does a female conceive (within her womb) nor bring forth the Day that (Allah) will propound to them the (question), "Where are the partners (ye attributed to Me?" They will say, "We do assure thee not one of us can bear witness!"

# 4266

The (deities) they used to invoke aforetime will leave them in the lurch, and they will perceive that they have no way of escape.

# 4267

Man does not weary of asking for good (things), but if ill touches him, he gives up all hope (and) is lost in despair.

# 4268

When we give him a taste of some Mercy from Ourselves, after some adversity has touched him, he is sure to say, "This is due to my (merit): I think not that the Hour (of Judgment) will (ever) be established; but if I am brought back to my Lord, I have (much) good (stored) in His sight!" But We will show the Unbelievers the truth of all that they did, and We shall give them the taste of a severe Penalty.

# 4269

When We bestow favours on man, he turns away, and gets himself remote on his side (instead of coming to Us); and when evil seizes him, (he comes) full of prolonged prayer!

# 4270

Say: "See ye if the (Revelation) is (really) from Allah, and yet do ye reject it? Who is more astray than one who is in a schism far (from any purpose)?"

# 4271

Soon will We show them our Signs in the (furthest) regions (of the earth), and in their own souls, until it becomes manifest to them that this is the Truth. Is it not enough that thy Lord doth witness all things?

# 4272

Ah indeed! Are they in doubt concerning the Meeting with their Lord? Ah indeed! It is He that doth encompass all things!

# 4273

Ha-Mim

# 4274

'Ain. Sin. Qaf.

# 4275

Thus doth (He) send inspiration to thee as (He did) to those before thee,- Allah, Exalted in Power, Full of Wisdom.

# 4276

To Him belongs all that is in the heavens and on earth: and He is Most High, Most Great.

# 4277

The heavens are almost rent asunder from above them (by Him Glory): and the angels celebrate the Praises of their Lord, and pray for forgiveness for (all) beings on earth: Behold! Verily Allah is He, the Oft-Forgiving, Most Merciful.

# 4278

And those who take as protectors others besides Him,- Allah doth watch over them; and thou art not the disposer of their affairs.

# 4279

Thus have We sent by inspiration to thee an Arabic Qur'an: that thou mayest warn the Mother of Cities and all around her,- and warn (them) of the Day of Assembly, of which there is no doubt: (when) some will be in the Garden, and some in the Blazing Fire.

# 4280

If Allah had so willed, He could have made them a single people; but He admits whom He will to His Mercy; and the Wrong-doers will have no protector nor helper.

# 4281

What! Have they taken (for worship) protectors besides Him? But it is Allah,- He is the Protector, and it is He Who gives life to the dead: It is He Who has power over all things,

# 4282

Whatever it be wherein ye differ, the decision thereof is with Allah: such is Allah my Lord: In Him I trust, and to Him I turn.

# 4283

(He is) the Creator of the heavens and the earth: He has made for you pairs from among yourselves, and pairs among cattle: by this means does He multiply you: there is nothing whatever like unto Him, and He is the One that hears and sees (all things).

# 4284

To Him belong the keys of the heavens and the earth: He enlarges and restricts. The Sustenance to whom He will: for He knows full well all things.

# 4285

The same religion has He established for you as that which He enjoined on Noah - the which We have sent by inspiration to thee - and that which We enjoined on Abraham, Moses, and Jesus: Namely, that ye should remain steadfast in religion, and make no divisions therein: to those who worship other things than Allah, hard is the (way) to which thou callest them. Allah chooses to Himself those whom He pleases, and guides to Himself those who turn (to Him).

# 4286

And they became divided only after Knowledge reached them,- through selfish envy as between themselves. Had it not been for a Word that went forth before from thy Lord, (tending) to a Term appointed, the matter would have been settled between them: But truly those who have inherited the Book after them are in suspicious (disquieting) doubt concerning it.

# 4287

Now then, for that (reason), call (them to the Faith), and stand steadfast as thou art commanded, nor follow thou their vain desires; but say: "I believe in the Book which Allah has sent down; and I am commanded to judge justly between you. Allah is our Lord and your Lord: for us (is the responsibility for) our deeds, and for you for your deeds. There is no contention between us and you. Allah will bring us together, and to Him is (our) Final Goal.

# 4288

But those who dispute concerning Allah after He has been accepted,- futile is their dispute in the Sight of their Lord: on them will be a Penalty terrible.

# 4289

It is Allah Who has sent down the Book in Truth, and the Balance (by which to weigh conduct). And what will make thee realise that perhaps the Hour is close at hand?

# 4290

Only those wish to hasten it who believe not in it: those who believe hold it in awe, and know that it is the Truth. Behold, verily those that dispute concerning the Hour are far astray.

# 4291

Gracious is Allah to His servants: He gives Sustenance to whom He pleases: and He has power and can carry out His Will.

# 4292

To any that desires the tilth of the Hereafter, We give increase in his tilth, and to any that desires the tilth of this world, We grant somewhat thereof, but he has no share or lot in the Hereafter.

# 4293

What! have they partners (in godhead), who have established for them some religion without the permission of Allah? Had it not been for the Decree of Judgment, the matter would have been decided between them (at once). But verily the Wrong-doers will have a grievous Penalty.

# 4294

Thou wilt see the Wrong-doers in fear on account of what they have earned, and (the burden of) that must (necessarily) fall on them. But those who believe and work righteous deeds will be in the luxuriant meads of the Gardens: they shall have, before their Lord, all that they wish for. That will indeed be the magnificent Bounty (of Allah).

# 4295

That is (the Bounty) whereof Allah gives Glad Tidings to His Servants who believe and do righteous deeds. Say: "No reward do I ask of you for this except the love of those near of kin." And if any one earns any good, We shall give him an increase of good in respect thereof: for Allah is Oft-Forgiving, Most Ready to appreciate (service).

# 4296

What! Do they say, "He has forged a falsehood against Allah"? But if Allah willed, He could seal up thy heart. And Allah blots out Vanity, and proves the Truth by His Words. For He knows well the secrets of all hearts.

# 4297

He is the One that accepts repentance from His Servants and forgives sins: and He knows all that ye do.

# 4298

And He listens to those who believe and do deeds of righteousness, and gives them increase of His Bounty: but for the Unbelievers their is a terrible Penalty.

# 4299

If Allah were to enlarge the provision for His Servants, they would indeed transgress beyond all bounds through the earth; but he sends (it) down in due measure as He pleases. For He is with His Servants Well-acquainted, Watchful.

# 4300

He is the One that sends down rain (even) after (men) have given up all hope, and scatters His Mercy (far and wide). And He is the Protector, Worthy of all Praise.

# 4301

And among His Signs is the creation of the heavens and the earth, and the living creatures that He has scattered through them: and He has power to gather them together when He wills.

# 4302

Whatever misfortune happens to you, is because on the things your hands have wrought, and for many (of them) He grants forgiveness.

# 4303

Nor can ye frustrate (aught), (fleeing) through the earth; nor have ye, besides Allah, any one to protect or to help.

# 4304

And among His Signs are the ships, smooth-running through the ocean, (tall) as mountains.

# 4305

If it be His Will He can still the Wind: then would they become motionless on the back of the (ocean). Verily in this are Signs for everyone who patiently perseveres and is grateful.

# 4306

Or He can cause them to perish because of the (evil) which (the men) have earned; but much doth He forgive.

# 4307

But let those know, who dispute about Our Signs, that there is for them no way of escape.

# 4308

Whatever ye are given (here) is (but) a convenience of this life: but that which is with Allah is better and more lasting: (it is) for those who believe and put their trust in their Lord:

# 4309

Those who avoid the greater crimes and shameful deeds, and, when they are angry even then forgive;

# 4310

Those who hearken to their Lord, and establish regular Prayer; who (conduct) their affairs by mutual Consultation; who spend out of what We bestow on them for Sustenance;

# 4311

And those who, when an oppressive wrong is inflicted on them, (are not cowed but) help and defend themselves.

# 4312

The recompense for an injury is an injury equal thereto (in degree): but if a person forgives and makes reconciliation, his reward is due from Allah: for (Allah) loveth not those who do wrong.

# 4313

But indeed if any do help and defend themselves after a wrong (done) to them, against such there is no cause of blame.

# 4314

The blame is only against those who oppress men and wrong-doing and insolently transgress beyond bounds through the land, defying right and justice: for such there will be a penalty grievous.

# 4315

But indeed if any show patience and forgive, that would truly be an exercise of courageous will and resolution in the conduct of affairs.

# 4316

For any whom Allah leaves astray, there is no protector thereafter. And thou wilt see the Wrong-doers, when in sight of the Penalty, Say: "Is there any way (to effect) a return?"

# 4317

And thou wilt see them brought forward to the (Penalty), in a humble frame of mind because of (their) disgrace, (and) looking with a stealthy glance. And the Believers will say: "Those are indeed in loss, who have given to perdition their own selves and those belonging to them on the Day of Judgment. Behold! Truly the Wrong-doers are in a lasting Penalty!"

# 4318

And no protectors have they to help them, other than Allah. And for any whom Allah leaves to stray, there is no way (to the Goal).

# 4319

Hearken ye to your Lord, before there come a Day which there will be no putting back, because of (the Ordainment of) Allah! that Day there will be for you no place of refuge nor will there be for you any room for denial (of your sins)!

# 4320

If then they run away, We have not sent thee as a guard over them. Thy duty is but to convey (the Message). And truly, when We give man a taste of a Mercy from Ourselves, he doth exult thereat, but when some ill happens to him, on account of the deeds which his hands have sent forth, truly then is man ungrateful!

# 4321

To Allah belongs the dominion of the heavens and the earth. He creates what He wills (and plans). He bestows (children) male or female according to His Will (and Plan),

# 4322

Or He bestows both males and females, and He leaves barren whom He will: for He is full of Knowledge and Power.

# 4323

It is not fitting for a man that Allah should speak to him except by inspiration, or from behind a veil, or by the sending of a messenger to reveal, with Allah's permission, what Allah wills: for He is Most High, Most Wise.

# 4324

And thus have We, by Our Command, sent inspiration to thee: thou knewest not (before) what was Revelation, and what was Faith; but We have made the (Qur'an) a Light, wherewith We guide such of Our servants as We will; and verily thou dost guide (men) to the Straight Way,-

# 4325

The Way of Allah, to Whom belongs whatever is in the heavens and whatever is on earth. Behold (how) all affairs tend towards Allah!

# 4326

Ha-Mim

# 4327

By the Book that makes things clear,-

# 4328

We have made it a Qur'an in Arabic, that ye may be able to understand (and learn wisdom).

# 4329

And verily, it is in the Mother of the Book, in Our Presence, high (in dignity), full of wisdom.

# 4330

Shall We then take away the Message from you and repel (you), for that ye are a people transgressing beyond bounds?

# 4331

But how many were the prophets We sent amongst the peoples of old?

# 4332

And never came there a prophet to them but they mocked him.

# 4333

So We destroyed (them)- stronger in power than these;- and (thus) has passed on the Parable of the peoples of old.

# 4334

If thou wert to question them, 'Who created the heavens and the earth?' They would be sure to reply, 'they were created by (Him), the Exalted in Power, Full of Knowledge';-

# 4335

(Yea, the same that) has made for you the earth (like a carpet) spread out, and has made for you roads (and channels) therein, in order that ye may find guidance (on the way);

# 4336

That sends down (from time to time) rain from the sky in due measure;- and We raise to life therewith a land that is dead; even so will ye be raised (from the dead);-

# 4337

That has created pairs in all things, and has made for you ships and cattle on which ye ride,

# 4338

In order that ye may sit firm and square on their backs, and when so seated, ye may celebrate the (kind) favour of your Lord, and say, "Glory to Him Who has subjected these to our (use), for we could never have accomplished this (by ourselves),

# 4339

"And to our Lord, surely, must we turn back!"

# 4340

Yet they attribute to some of His servants a share with Him (in his godhead)! truly is man a blasphemous ingrate avowed!

# 4341

What! has He taken daughters out of what He himself creates, and granted to you sons for choice?

# 4342

When news is brought to one of them of (the birth of) what he sets up as a likeness to (Allah) Most Gracious, his face darkens, and he is filled with inward grief!

# 4343

Is then one brought up among trinkets, and unable to give a clear account in a dispute (to be associated with Allah)?

# 4344

And they make into females angels who themselves serve Allah. Did they witness their creation? Their evidence will be recorded, and they will be called to account!

# 4345

("Ah!") they say, "If it had been the will of (Allah) Most Gracious, we should not have worshipped such (deities)!" Of that they have no knowledge! they do nothing but lie!

# 4346

What! have We given them a Book before this, to which they are holding fast?

# 4347

Nay! they say: "We found our fathers following a certain religion, and we do guide ourselves by their footsteps."

# 4348

Just in the same way, whenever We sent a Warner before thee to any people, the wealthy ones among them said: "We found our fathers following a certain religion, and we will certainly follow in their footsteps."

# 4349

He said: "What! Even if I brought you better guidance than that which ye found your fathers following?" They said: "For us, we deny that ye (prophets) are sent (on a mission at all)."

# 4350

So We exacted retribution from them: now see what was the end of those who rejected (Truth)!

# 4351

Behold! Abraham said to his father and his people: "I do indeed clear myself of what ye worship:

# 4352

"(I worship) only Him Who made me, and He will certainly guide me."

# 4353

And he left it as a Word to endure among those who came after him, that they may turn back (to Allah).

# 4354

Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.

# 4355

But when the Truth came to them, they said: "This is sorcery, and we do reject it."

# 4356

Also, they say: "Why is not this Qur'an sent down to some leading man in either of the two (chief) cities?"

# 4357

Is it they who would portion out the Mercy of thy Lord? It is We Who portion out between them their livelihood in the life of this world: and We raise some of them above others in ranks, so that some may command work from others. But the Mercy of thy Lord is better than the (wealth) which they amass.

# 4358

And were it not that (all) men might become of one (evil) way of life, We would provide, for everyone that blasphemes against (Allah) Most Gracious, silver roofs for their houses and (silver) stair-ways on which to go up,

# 4359

And (silver) doors to their houses, and thrones (of silver) on which they could recline,

# 4360

And also adornments of gold. But all this were nothing but conveniences of the present life: The Hereafter, in the sight of thy Lord is for the Righteous.

# 4361

If anyone withdraws himself from remembrance of (Allah) Most Gracious, We appoint for him an evil one, to be an intimate companion to him.

# 4362

Such (evil ones) really hinder them from the Path, but they think that they are being guided aright!

# 4363

At length, when (such a one) comes to Us, he says (to his evil companion): "Would that between me and thee were the distance of East and West!" Ah! evil is the companion (indeed)!

# 4364

When ye have done wrong, it will avail you nothing, that Day, that ye shall be partners in Punishment!

# 4365

Canst thou then make the deaf to hear, or give direction to the blind or to such as (wander) in manifest error?

# 4366

Even if We take thee away, We shall be sure to exact retribution from them,

# 4367

Or We shall show thee that (accomplished) which We have promised them: for verily We shall prevail over them.

# 4368

So hold thou fast to the Revelation sent down to thee; verily thou art on a Straight Way.

# 4369

The (Qur'an) is indeed the message, for thee and for thy people; and soon shall ye (all) be brought to account.

# 4370

And question thou our messengers whom We sent before thee; did We appoint any deities other than (Allah) Most Gracious, to be worshipped?

# 4371

We did send Moses aforetime, with Our Signs, to Pharaoh and his Chiefs: He said, "I am a messenger of the Lord of the Worlds."

# 4372

But when he came to them with Our Signs, behold they ridiculed them.

# 4373

We showed them Sign after Sign, each greater than its fellow, and We seized them with Punishment, in order that they might turn (to Us).

# 4374

And they said, "O thou sorcerer! Invoke thy Lord for us according to His covenant with thee; for we shall truly accept guidance."

# 4375

But when We removed the Penalty from them, behold, they broke their word.

# 4376

And Pharaoh proclaimed among his people, saying: "O my people! Does not the dominion of Egypt belong to me, (witness) these streams flowing underneath my (palace)? What! see ye not then?

# 4377

"Am I not better than this (Moses), who is a contemptible wretch and can scarcely express himself clearly?

# 4378

"Then why are not gold bracelets bestowed on him, or (why) come (not) with him angels accompanying him in procession?"

# 4379

Thus did he make fools of his people, and they obeyed him: truly were they a people rebellious (against Allah).

# 4380

When at length they provoked Us, We exacted retribution from them, and We drowned them all.

# 4381

And We made them (a people) of the Past and an Example to later ages.

# 4382

When (Jesus) the son of Mary is held up as an example, behold, thy people raise a clamour thereat (in ridicule)!

# 4383

And they say, "Are our gods best, or he?" This they set forth to thee, only by way of disputation: yea, they are a contentious people.

# 4384

He was no more than a servant: We granted Our favour to him, and We made him an example to the Children of Israel.

# 4385

And if it were Our Will, We could make angels from amongst you, succeeding each other on the earth.

# 4386

And (Jesus) shall be a Sign (for the coming of) the Hour (of Judgment): therefore have no doubt about the (Hour), but follow ye Me: this is a Straight Way.

# 4387

Let not the Evil One hinder you: for he is to you an enemy avowed.

# 4388

When Jesus came with Clear Signs, he said: "Now have I come to you with Wisdom, and in order to make clear to you some of the (points) on which ye dispute: therefore fear Allah and obey me.

# 4389

"For Allah, He is my Lord and your Lord: so worship ye Him: this is a Straight Way."

# 4390

But sects from among themselves fell into disagreement: then woe to the wrong-doers, from the Penalty of a Grievous Day!

# 4391

Do they only wait for the Hour - that it should come on them all of a sudden, while they perceive not?

# 4392

Friends on that day will be foes, one to another,- except the Righteous.

# 4393

My devotees! no fear shall be on you that Day, nor shall ye grieve,-

# 4394

(Being) those who have believed in Our Signs and bowed (their wills to Ours) in Islam.

# 4395

Enter ye the Garden, ye and your wives, in (beauty and) rejoicing.

# 4396

To them will be passed round, dishes and goblets of gold: there will be there all that the souls could desire, all that their eyes could delight in: and ye shall abide therein (for eye).

# 4397

Such will be the Garden of which ye are made heirs for your (good) deeds (in life).

# 4398

Ye shall have therein abundance of fruit, from which ye shall have satisfaction.

# 4399

The sinners will be in the Punishment of Hell, to dwell therein (for aye):

# 4400

Nowise will the (Punishment) be lightened for them, and in despair will they be there overwhelmed.

# 4401

Nowise shall We be unjust to them: but it is they who have been unjust themselves.

# 4402

They will cry: "O Malik! would that thy Lord put an end to us!" He will say, "Nay, but ye shall abide!"

# 4403

Verily We have brought the Truth to you: but most of you have a hatred for Truth.

# 4404

What! have they settled some plan (among themselves)? But it is We Who settle things.

# 4405

Or do they think that We hear not their secrets and their private counsels? Indeed (We do), and Our messengers are by them, to record.

# 4406

Say: "If (Allah) Most Gracious had a son, I would be the first to worship."

# 4407

Glory to the Lord of the heavens and the earth, the Lord of the Throne (of Authority)! (He is free) from the things they attribute (to him)!

# 4408

So leave them to babble and play (with vanities) until they meet that Day of theirs, which they have been promised.

# 4409

It is He Who is Allah in heaven and Allah on earth; and He is full of Wisdom and Knowledge.

# 4410

And blessed is He to Whom belongs the dominion of the heavens and the earth, and all between them: with Him is the Knowledge of the Hour (of Judgment): and to Him shall ye be brought back.

# 4411

And those whom they invoke besides Allah have no power of intercession;- only he who bears witness to the Truth, and they know (him).

# 4412

If thou ask them, who created them, they will certainly say, Allah: How then are they deluded away (from the Truth)?

# 4413

(Allah has knowledge) of the (Prophet's) cry, "O my Lord! Truly these are people who will not believe!"

# 4414

But turn away from them, and say "Peace!" But soon shall they know!

# 4415

Ha-Mim.

# 4416

By the Book that makes things clear;-

# 4417

We sent it down during a Blessed Night: for We (ever) wish to warn (against Evil).

# 4418

In the (Night) is made distinct every affair of wisdom,

# 4419

By command, from Our Presence. For We (ever) send (revelations),

# 4420

As Mercy from thy Lord: for He hears and knows (all things);

# 4421

The Lord of the heavens and the earth and all between them, if ye (but) have an assured faith.

# 4422

There is no god but He: It is He Who gives life and gives death,- The Lord and Cherisher to you and your earliest ancestors.

# 4423

Yet they play about in doubt.

# 4424

Then watch thou for the Day that the sky will bring forth a kind of smoke (or mist) plainly visible,

# 4425

Enveloping the people: this will be a Penalty Grievous.

# 4426

(They will say:) "Our Lord! remove the Penalty from us, for we do really believe!"

# 4427

How shall the message be (effectual) for them, seeing that an Messenger explaining things clearly has (already) come to them,-

# 4428

Yet they turn away from him and say: "Tutored (by others), a man possessed!"

# 4429

We shall indeed remove the Penalty for a while, (but) truly ye will revert (to your ways).

# 4430

One day We shall seize you with a mighty onslaught: We will indeed (then) exact Retribution!

# 4431

We did, before them, try the people of Pharaoh: there came to them a messenger most honourable,

# 4432

Saying: "Restore to me the Servants of Allah: I am to you an messenger worthy of all trust;

# 4433

"And be not arrogant as against Allah: for I come to you with authority manifest.

# 4434

"For me, I have sought safety with my Lord and your Lord, against your injuring me.

# 4435

"If ye believe me not, at least keep yourselves away from me."

# 4436

(But they were aggressive:) then he cried to his Lord: "These are indeed a people given to sin."

# 4437

(The reply came:) "March forth with My Servants by night: for ye are sure to be pursued.

# 4438

"And leave the sea as a furrow (divided): for they are a host (destined) to be drowned."

# 4439

How many were the gardens and springs they left behind,

# 4440

And corn-fields and noble buildings,

# 4441

And wealth (and conveniences of life), wherein they had taken such delight!

# 4442

Thus (was their end)! And We made other people inherit (those things)!

# 4443

And neither heaven nor earth shed a tear over them: nor were they given a respite (again).

# 4444

We did deliver aforetime the Children of Israel from humiliating Punishment,

# 4445

Inflicted by Pharaoh, for he was arrogant (even) among inordinate transgressors.

# 4446

And We chose them aforetime above the nations, knowingly,

# 4447

And granted them Signs in which there was a manifest trial

# 4448

As to these (Quraish), they say forsooth:

# 4449

"There is nothing beyond our first death, and we shall not be raised again.

# 4450

"Then bring (back) our forefathers, if what ye say is true!"

# 4451

What! Are they better than the people of Tubba and those who were before them? We destroyed them because they were guilty of sin.

# 4452

We created not the heavens, the earth, and all between them, merely in (idle) sport:

# 4453

We created them not except for just ends: but most of them do not understand.

# 4454

Verily the Day of sorting out is the time appointed for all of them,-

# 4455

The Day when no protector can avail his client in aught, and no help can they receive,

# 4456

Except such as receive Allah's Mercy: for He is Exalted in Might, Most Merciful.

# 4457

Verily the tree of Zaqqum

# 4458

Will be the food of the Sinful,-

# 4459

Like molten brass; it will boil in their insides.

# 4460

Like the boiling of scalding water.

# 4461

(A voice will cry: "Seize ye him and drag him into the midst of the Blazing Fire!

# 4462

"Then pour over his head the Penalty of Boiling Water,

# 4463

"Taste thou (this)! Truly wast thou mighty, full of honour!

# 4464

"Truly this is what ye used to doubt!"

# 4465

As to the Righteous (they will be) in a position of Security,

# 4466

Among Gardens and Springs;

# 4467

Dressed in fine silk and in rich brocade, they will face each other;

# 4468

So; and We shall join them to fair women with beautiful, big, and lustrous eyes.

# 4469

There can they call for every kind of fruit in peace and security;

# 4470

Nor will they there taste Death, except the first death; and He will preserve them from the Penalty of the Blazing Fire,-

# 4471

As a Bounty from thy Lord! that will be the supreme achievement!

# 4472

Verily, We have made this (Qur'an) easy, in thy tongue, in order that they may give heed.

# 4473

So wait thou and watch; for they (too) are waiting.

# 4474

Ha-Mim.

# 4475

The revelation of the Book is from Allah the Exalted in Power, Full of Wisdom.

# 4476

Verily in the heavens and the earth, are Signs for those who believe.

# 4477

And in the creation of yourselves and the fact that animals are scattered (through the earth), are Signs for those of assured Faith.

# 4478

And in the alternation of Night and Day, and the fact that Allah sends down Sustenance from the sky, and revives therewith the earth after its death, and in the change of the winds,- are Signs for those that are wise.

# 4479

Such are the Signs of Allah, which We rehearse to thee in Truth; then in what exposition will they believe after (rejecting) Allah and His Signs?

# 4480

Woe to each sinful dealer in Falsehoods:

# 4481

He hears the Signs of Allah rehearsed to him, yet is obstinate and lofty, as if he had not heard them: then announce to him a Penalty Grievous!

# 4482

And when he learns something of Our Signs, he takes them in jest: for such there will be a humiliating Penalty.

# 4483

In front of them is Hell: and of no profit to them is anything they may have earned, nor any protectors they may have taken to themselves besides Allah: for them is a tremendous Penalty.

# 4484

This is (true) Guidance and for those who reject the Signs of their Lord, is a grievous Penalty of abomination.

# 4485

It is Allah Who has subjected the sea to you, that ships may sail through it by His command, that ye may seek of his Bounty, and that ye may be grateful.

# 4486

And He has subjected to you, as from Him, all that is in the heavens and on earth: Behold, in that are Signs indeed for those who reflect.

# 4487

Tell those who believe, to forgive those who do not look forward to the Days of Allah: It is for Him to recompense (for good or ill) each People according to what they have earned.

# 4488

If any one does a righteous deed, it ensures to the benefit of his own soul; if he does evil, it works against (his own soul). In the end will ye (all) be brought back to your Lord.

# 4489

We did aforetime grant to the Children of Israel the Book the Power of Command, and Prophethood; We gave them, for Sustenance, things good and pure; and We favoured them above the nations.

# 4490

And We granted them Clear Signs in affairs (of Religion): it was only after knowledge had been granted to them that they fell into schisms, through insolent envy among themselves. Verily thy Lord will judge between them on the Day of Judgment as to those matters in which they set up differences.

# 4491

Then We put thee on the (right) Way of Religion: so follow thou that (Way), and follow not the desires of those who know not.

# 4492

They will be of no use to thee in the sight of Allah: it is only Wrong-doers (that stand as) protectors, one to another: but Allah is the Protector of the Righteous.

# 4493

These are clear evidences to men and a Guidance and Mercy to those of assured Faith.

# 4494

What! Do those who seek after evil ways think that We shall hold them equal with those who believe and do righteous deeds,- that equal will be their life and their death? Ill is the judgment that they make.

# 4495

Allah created the heavens and the earth for just ends, and in order that each soul may find the recompense of what it has earned, and none of them be wronged.

# 4496

Then seest thou such a one as takes as his god his own vain desire? Allah has, knowing (him as such), left him astray, and sealed his hearing and his heart (and understanding), and put a cover on his sight. Who, then, will guide him after Allah (has withdrawn Guidance)? Will ye not then receive admonition?

# 4497

And they say: "What is there but our life in this world? We shall die and we live, and nothing but time can destroy us." But of that they have no knowledge: they merely conjecture:

# 4498

And when Our Clear Signs are rehearsed to them their argument is nothing but this: They say, "Bring (back) our forefathers, if what ye say is true!"

# 4499

Say: "It is Allah Who gives you life, then gives you death; then He will gather you together for the Day of Judgment about which there is no doubt": But most men do not understand.

# 4500

To Allah belongs the dominion of the heavens and the earth, and the Day that the Hour of Judgment is established,- that Day will the dealers in Falsehood perish!

# 4501

And thou wilt see every sect bowing the knee: Every sect will be called to its Record: "This Day shall ye be recompensed for all that ye did!

# 4502

"This Our Record speaks about you with truth: For We were wont to put on Record all that ye did."

# 4503

Then, as to those who believed and did righteous deeds, their Lord will admit them to His Mercy that will be the achievement for all to see.

# 4504

But as to those who rejected Allah, (to them will be said): "Were not Our Signs rehearsed to you? But ye were arrogant, and were a people given to sin!

# 4505

"And when it was said that the promise of Allah was true, and that the Hour- there was no doubt about its (coming), ye used to say, 'We know not what is the hour: we only think it is an idea, and we have no firm assurance.'"

# 4506

Then will appear to them the evil (fruits) of what they did, and they will be completely encircled by that which they used to mock at!

# 4507

It will also be said: "This Day We will forget you as ye forgot the meeting of this Day of yours! and your abode is the Fire, and no helpers have ye!

# 4508

"This, because ye used to take the Signs of Allah in jest, and the life of the world deceived you:" (From) that Day, therefore, they shall not be taken out thence, nor shall they be received into Grace.

# 4509

Then Praise be to Allah, Lord of the heavens and Lord of the earth,- Lord and Cherisher of all the Worlds!

# 4510

To Him be glory throughout the heavens and the earth: and He is Exalted in Power, Full of Wisdom!

# 4511

Ha-Mim.

# 4512

The Revelation of the Book is from Allah the Exalted in Power, Full of Wisdom.

# 4513

We created not the heavens and the earth and all between them but for just ends, and for a Term Appointed: But those who reject Faith turn away from that whereof they are warned.

# 4514

Say: "Do ye see what it is ye invoke besides Allah? Show me what it is they have created on earth, or have they a share in the heavens bring me a book (revealed) before this, or any remnant of knowledge (ye may have), if ye are telling the truth!

# 4515

And who is more astray than one who invokes besides Allah, such as will not answer him to the Day of Judgment, and who (in fact) are unconscious of their call (to them)?

# 4516

And when mankind are gathered together (at the Resurrection), they will be hostile to them and reject their worship (altogether)!

# 4517

When Our Clear Signs are rehearsed to them, the Unbelievers say, of the Truth when it comes to them: "This is evident sorcery!"

# 4518

Or do they say, "He has forged it"? Say: "Had I forged it, then can ye obtain no single (blessing) for me from Allah. He knows best of that whereof ye talk (so glibly)! Enough is He for a witness between me and you! And he is Oft-Forgiving, Most Merciful."

# 4519

Say: "I am no bringer of new-fangled doctrine among the messengers, nor do I know what will be done with me or with you. I follow but that which is revealed to me by inspiration; I am but a Warner open and clear."

# 4520

Say: "See ye? If (this teaching) be from Allah, and ye reject it, and a witness from among the Children of Israel testifies to its similarity (with earlier scripture), and has believed while ye are arrogant, (how unjust ye are!) truly, Allah guides not a people unjust."

# 4521

The Unbelievers say of those who believe: "If (this Message) were a good thing, (such men) would not have gone to it first, before us!" And seeing that they guide not themselves thereby, they will say, "this is an (old,) falsehood!"

# 4522

And before this, was the Book of Moses as a guide and a mercy: And this Book confirms (it) in the Arabic tongue; to admonish the unjust, and as Glad Tidings to those who do right.

# 4523

Verily those who say, "Our Lord is Allah," and remain firm (on that Path),- on them shall be no fear, nor shall they grieve.

# 4524

Such shall be Companions of the Gardens, dwelling therein (for aye): a recompense for their (good) deeds.

# 4525

We have enjoined on man kindness to his parents: In pain did his mother bear him, and in pain did she give him birth. The carrying of the (child) to his weaning is (a period of) thirty months. At length, when he reaches the age of full strength and attains forty years, he says, "O my Lord! Grant me that I may be grateful for Thy favour which Thou has bestowed upon me, and upon both my parents, and that I may work righteousness such as Thou mayest approve; and be gracious to me in my issue. Truly have I turned to Thee and truly do I bow (to Thee) in Islam."

# 4526

Such are they from whom We shall accept the best of their deeds and pass by their ill deeds: (They shall be) among the Companions of the Garden: a promise! of truth, which was made to them (in this life).

# 4527

But (there is one) who says to his parents, "Fie on you! Do ye hold out the promise to me that I shall be raised up, even though generations have passed before me (without rising again)?" And they two seek Allah's aid, (and rebuke the son): "Woe to thee! Have faith! for the promise of Allah is true." But he says, "This is nothing but tales of the ancients!"

# 4528

Such are they against whom is proved the sentence among the previous generations of Jinns and men, that have passed away; for they will be (utterly) lost.

# 4529

And to all are (assigned) degrees according to the deeds which they (have done), and in order that (Allah) may recompense their deeds, and no injustice be done to them.

# 4530

And on the Day that the Unbelievers will be placed before the Fire, (It will be said to them): "Ye received your good things in the life of the world, and ye took your pleasure out of them: but today shall ye be recompensed with a Penalty of humiliation: for that ye were arrogant on earth without just cause, and that ye (ever) transgressed."

# 4531

Mention (Hud) one of 'Ad's (own) brethren: Behold, he warned his people about the winding Sand-tracts: but there have been warners before him and after him: "Worship ye none other than Allah: Truly I fear for you the Penalty of a Mighty Day."

# 4532

They said: "Hast thou come in order to turn us aside from our gods? Then bring upon us the (calamity) with which thou dost threaten us, if thou art telling the truth?"

# 4533

He said: "The Knowledge (of when it will come) is only with Allah: I proclaim to you the mission on which I have been sent: But I see that ye are a people in ignorance!"..

# 4534

Then, when they saw the (Penalty in the shape of) a cloud traversing the sky, coming to meet their valleys, they said, "This cloud will give us rain!" "Nay, it is the (Calamity) ye were asking to be hastened!- A wind wherein is a Grievous Penalty!

# 4535

"Everything will it destroy by the command of its Lord!" Then by the morning they - nothing was to be seen but (the ruins of) their houses! thus do We recompense those given to sin!

# 4536

And We had firmly established them in a (prosperity and) power which We have not given to you (ye Quraish!) and We had endowed them with (faculties of) hearing, seeing, heart and intellect: but of no profit to them were their (faculties of) hearing, sight, and heart and intellect, when they went on rejecting the Signs of Allah; and they were (completely) encircled by that which they used to mock at!

# 4537

We destroyed aforetime populations round about you; and We have shown the Signs in various ways, that they may turn (to Us).

# 4538

Why then was no help forthcoming to them from those whom they worshipped as gods, besides Allah, as a means of access (to Allah)? Nay, they left them in the lurch: but that was their falsehood and their invention.

# 4539

Behold, We turned towards thee a company of Jinns (quietly) listening to the Qur'an: when they stood in the presence thereof, they said, "Listen in silence!" When the (reading) was finished, they returned to their people, to warn (them of their sins).

# 4540

They said, "O our people! We have heard a Book revealed after Moses, confirming what came before it: it guides (men) to the Truth and to a Straight Path.

# 4541

"O our people, hearken to the one who invites (you) to Allah, and believe in him: He will forgive you your faults, and deliver you from a Penalty Grievous.

# 4542

"If any does not hearken to the one who invites (us) to Allah, he cannot frustrate (Allah's Plan) on earth, and no protectors can he have besides Allah: such men (wander) in manifest error."

# 4543

See they not that Allah, Who created the heavens and the earth, and never wearied with their creation, is able to give life to the dead? Yea, verily He has power over all things.

# 4544

And on the Day that the Unbelievers will be placed before the Fire, (they will be asked,) "Is this not the Truth?" they will say, "Yea, by our Lord!" (One will say:) "Then taste ye the Penalty, for that ye were wont to deny (Truth)!"

# 4545

Therefore patiently persevere, as did (all) messengers of inflexible purpose; and be in no haste about the (Unbelievers). On the Day that they see the (Punishment) promised them, (it will be) as if they had not tarried more than an hour in a single day. (Thine but) to proclaim the Message: but shall any be destroyed except those who transgress?

# 4546

Those who reject Allah and hinder (men) from the Path of Allah,- their deeds will Allah render astray (from their mark).

# 4547

But those who believe and work deeds of righteousness, and believe in the (Revelation) sent down to Muhammad - for it is the Truth from their Lord,- He will remove from them their ills and improve their condition.

# 4548

This because those who reject Allah follow vanities, while those who believe follow the Truth from their Lord: Thus does Allah set forth for men their lessons by similitudes.

# 4549

Therefore, when ye meet the Unbelievers (in fight), smite at their necks; At length, when ye have thoroughly subdued them, bind a bond firmly (on them): thereafter (is the time for) either generosity or ransom: Until the war lays down its burdens. Thus (are ye commanded): but if it had been Allah's Will, He could certainly have exacted retribution from them (Himself); but (He lets you fight) in order to test you, some with others. But those who are slain in the Way of Allah,- He will never let their deeds be lost.

# 4550

Soon will He guide them and improve their condition,

# 4551

And admit them to the Garden which He has announced for them.

# 4552

O ye who believe! If ye will aid (the cause of) Allah, He will aid you, and plant your feet firmly.

# 4553

But those who reject (Allah),- for them is destruction, and (Allah) will render their deeds astray (from their mark).

# 4554

That is because they hate the Revelation of Allah; so He has made their deeds fruitless.

# 4555

Do they not travel through the earth, and see what was the End of those before them (who did evil)? Allah brought utter destruction on them, and similar (fates await) those who reject Allah.

# 4556

That is because Allah is the Protector of those who believe, but those who reject Allah have no protector.

# 4557

Verily Allah will admit those who believe and do righteous deeds, to Gardens beneath which rivers flow; while those who reject Allah will enjoy (this world) and eat as cattle eat; and the Fire will be their abode.

# 4558

And how many cities, with more power than thy city which has driven thee out, have We destroyed (for their sins)? and there was none to aid them.

# 4559

Is then one who is on a clear (Path) from his Lord, no better than one to whom the evil of his conduct seems pleasing, and such as follow their own lusts?

# 4560

(Here is) a Parable of the Garden which the righteous are promised: in it are rivers of water incorruptible; rivers of milk of which the taste never changes; rivers of wine, a joy to those who drink; and rivers of honey pure and clear. In it there are for them all kinds of fruits; and Grace from their Lord. (Can those in such Bliss) be compared to such as shall dwell for ever in the Fire, and be given, to drink, boiling water, so that it cuts up their bowels (to pieces)?

# 4561

And among them are men who listen to thee, but in the end, when they go out from thee, they say to those who have received Knowledge, "What is it he said just then?" Such are men whose hearts Allah has sealed, and who follow their own lusts.

# 4562

But to those who receive Guidance, He increases the (light of) Guidance, and bestows on them their Piety and Restraint (from evil).

# 4563

Do they then only wait for the Hour,- that it should come on them of a sudden? But already have come some tokens thereof, and when it (actually) is on them, how can they benefit then by their admonition?

# 4564

Know, therefore, that there is no god but Allah, and ask forgiveness for thy fault, and for the men and women who believe: for Allah knows how ye move about and how ye dwell in your homes.

# 4565

Those who believe say, "Why is not a sura sent down (for us)?" But when a sura of basic or categorical meaning is revealed, and fighting is mentioned therein, thou wilt see those in whose hearts is a disease looking at thee with a look of one in swoon at the approach of death. But more fitting for them-

# 4566

Were it to obey and say what is just, and when a matter is resolved on, it were best for them if they were true to Allah.

# 4567

Then, is it to be expected of you, if ye were put in authority, that ye will do mischief in the land, and break your ties of kith and kin?

# 4568

Such are the men whom Allah has cursed for He has made them deaf and blinded their sight.

# 4569

Do they not then earnestly seek to understand the Qur'an, or are their hearts locked up by them?

# 4570

Those who turn back as apostates after Guidance was clearly shown to them,- the Evil One has instigated them and busied them up with false hopes.

# 4571

This, because they said to those who hate what Allah has revealed, "We will obey you in part of (this) matter"; but Allah knows their (inner) secrets.

# 4572

But how (will it be) when the angels take their souls at death, and smite their faces and their backs?

# 4573

This because they followed that which called forth the Wrath of Allah, and they hated Allah's good pleasure; so He made their deeds of no effect.

# 4574

Or do those in whose hearts is a disease, think that Allah will not bring to light all their rancour?

# 4575

Had We so wiled, We could have shown them up to thee, and thou shouldst have known them by their marks: but surely thou wilt know them by the tone of their speech! And Allah knows all that ye do.

# 4576

And We shall try you until We test those among you who strive their utmost and persevere in patience; and We shall try your reported (mettle).

# 4577

Those who reject Allah, hinder (men) from the Path of Allah, and resist the Messenger, after Guidance has been clearly shown to them, will not injure Allah in the least, but He will make their deeds of no effect.

# 4578

O ye who believe! Obey Allah, and obey the messenger, and make not vain your deeds!

# 4579

Those who reject Allah, and hinder (men) from the Path of Allah, then die rejecting Allah,- Allah will not forgive them.

# 4580

Be not weary and faint-hearted, crying for peace, when ye should be uppermost: for Allah is with you, and will never put you in loss for your (good) deeds.

# 4581

The life of this world is but play and amusement: and if ye believe and guard against Evil, He will grant you your recompense, and will not ask you (to give up) your possessions.

# 4582

If He were to ask you for all of them, and press you, ye would covetously withhold, and He would bring out all your ill-feeling.

# 4583

Behold, ye are those invited to spend (of your substance) in the Way of Allah: But among you are some that are niggardly. But any who are niggardly are so at the expense of their own souls. But Allah is free of all wants, and it is ye that are needy. If ye turn back (from the Path), He will substitute in your stead another people; then they would not be like you!

# 4584

Verily We have granted thee a manifest Victory:

# 4585

That Allah may forgive thee thy faults of the past and those to follow; fulfil His favour to thee; and guide thee on the Straight Way;

# 4586

And that Allah may help thee with powerful help.

# 4587

It is He Who sent down tranquillity into the hearts of the Believers, that they may add faith to their faith;- for to Allah belong the Forces of the heavens and the earth; and Allah is Full of Knowledge and Wisdom;-

# 4588

That He may admit the men and women who believe, to Gardens beneath which rivers flow, to dwell therein for aye, and remove their ills from them;- and that is, in the sight of Allah, the highest achievement (for man),-

# 4589

And that He may punish the Hypocrites, men and women, and the Polytheists men and women, who imagine an evil opinion of Allah. On them is a round of Evil: the Wrath of Allah is on them: He has cursed them and got Hell ready for them: and evil is it for a destination.

# 4590

For to Allah belong the Forces of the heavens and the earth; and Allah is Exalted in Power, Full of Wisdom.

# 4591

We have truly sent thee as a witness, as a bringer of Glad Tidings, and as a Warner:

# 4592

In order that ye (O men) may believe in Allah and His Messenger, that ye may assist and honour Him, and celebrate His praise morning and evening.

# 4593

Verily those who plight their fealty to thee do no less than plight their fealty to Allah: the Hand of Allah is over their hands: then any one who violates his oath, does so to the harm of his own soul, and any one who fulfils what he has covenanted with Allah,- Allah will soon grant him a great Reward.

# 4594

The desert Arabs who lagged behind will say to thee: "We were engaged in (looking after) our flocks and herds, and our families: do thou then ask forgiveness for us." They say with their tongues what is not in their hearts. Say: "Who then has any power at all (to intervene) on your behalf with Allah, if His Will is to give you some loss or to give you some profit? But Allah is well acquainted with all that ye do.

# 4595

"Nay, ye thought that the Messenger and the Believers would never return to their families; this seemed pleasing in your hearts, and ye conceived an evil thought, for ye are a people lost (in wickedness)."

# 4596

And if any believe not in Allah and His Messenger, We have prepared, for those who reject Allah, a Blazing Fire!

# 4597

To Allah belongs the dominion of the heavens and the earth: He forgives whom He wills, and He punishes whom He wills: but Allah is Oft-Forgiving, Most Merciful.

# 4598

Those who lagged behind (will say), when ye (are free to) march and take booty (in war): "Permit us to follow you." They wish to change Allah's decree: Say: "Not thus will ye follow us: Allah has already declared (this) beforehand": then they will say, "But ye are jealous of us." Nay, but little do they understand (such things).

# 4599

Say to the desert Arabs who lagged behind: "Ye shall be summoned (to fight) against a people given to vehement war: then shall ye fight, or they shall submit. Then if ye show obedience, Allah will grant you a goodly reward, but if ye turn back as ye did before, He will punish you with a grievous Penalty."

# 4600

No blame is there on the blind, nor is there blame on the lame, nor on one ill (if he joins not the war): But he that obeys Allah and his Messenger,- (Allah) will admit him to Gardens beneath which rivers flow; and he who turns back, (Allah) will punish him with a grievous Penalty.

# 4601

Allah's Good Pleasure was on the Believers when they swore Fealty to thee under the Tree: He knew what was in their hearts, and He sent down Tranquillity to them; and He rewarded them with a speedy Victory;

# 4602

And many gains will they acquire (besides): and Allah is Exalted in Power, Full of Wisdom.

# 4603

Allah has promised you many gains that ye shall acquire, and He has given you these beforehand; and He has restrained the hands of men from you; that it may be a Sign for the Believers, and that He may guide you to a Straight Path;

# 4604

And other gains (there are), which are not within your power, but which Allah has compassed: and Allah has power over all things.

# 4605

If the Unbelievers should fight you, they would certainly turn their backs; then would they find neither protector nor helper.

# 4606

(Such has been) the practice (approved) of Allah already in the past: no change wilt thou find in the practice (approved) of Allah.

# 4607

And it is He Who has restrained their hands from you and your hands from them in the midst of Makka, after that He gave you the victory over them. And Allah sees well all that ye do.

# 4608

They are the ones who denied Revelation and hindered you from the Sacred Mosque and the sacrificial animals, detained from reaching their place of sacrifice. Had there not been believing men and believing women whom ye did not know that ye were trampling down and on whose account a crime would have accrued to you without (your) knowledge, (Allah would have allowed you to force your way, but He held back your hands) that He may admit to His Mercy whom He will. If they had been apart, We should certainly have punished the Unbelievers among them with a grievous Punishment.

# 4609

While the Unbelievers got up in their hearts heat and cant - the heat and cant of ignorance,- Allah sent down His Tranquillity to his Messenger and to the Believers, and made them stick close to the command of self-restraint; and well were they entitled to it and worthy of it. And Allah has full knowledge of all things.

# 4610

Truly did Allah fulfil the vision for His Messenger: ye shall enter the Sacred Mosque, if Allah wills, with minds secure, heads shaved, hair cut short, and without fear. For He knew what ye knew not, and He granted, besides this, a speedy victory.

# 4611

It is He Who has sent His Messenger with Guidance and the Religion of Truth, to proclaim it over all religion: and enough is Allah for a Witness.

# 4612

Muhammad is the messenger of Allah; and those who are with him are strong against Unbelievers, (but) compassionate amongst each other. Thou wilt see them bow and prostrate themselves (in prayer), seeking Grace from Allah and (His) Good Pleasure. On their faces are their marks, (being) the traces of their prostration. This is their similitude in the Taurat; and their similitude in the Gospel is: like a seed which sends forth its blade, then makes it strong; it then becomes thick, and it stands on its own stem, (filling) the sowers with wonder and delight. As a result, it fills the Unbelievers with rage at them. Allah has promised those among them who believe and do righteous deeds forgiveness, and a great Reward.

# 4613

O Ye who believe! Put not yourselves forward before Allah and His Messenger; but fear Allah: for Allah is He Who hears and knows all things.

# 4614

O ye who believe! Raise not your voices above the voice of the Prophet, nor speak aloud to him in talk, as ye may speak aloud to one another, lest your deeds become vain and ye perceive not.

# 4615

Those that lower their voices in the presence of Allah's Messenger,- their hearts has Allah tested for piety: for them is Forgiveness and a great Reward.

# 4616

Those who shout out to thee from without the inner apartments - most of them lack understanding.

# 4617

If only they had patience until thou couldst come out to them, it would be best for them: but Allah is Oft-Forgiving, Most Merciful.

# 4618

O ye who believe! If a wicked person comes to you with any news, ascertain the truth, lest ye harm people unwittingly, and afterwards become full of repentance for what ye have done.

# 4619

And know that among you is Allah's Messenger: were he, in many matters, to follow your (wishes), ye would certainly fall into misfortune: But Allah has endeared the Faith to you, and has made it beautiful in your hearts, and He has made hateful to you Unbelief, wickedness, and rebellion: such indeed are those who walk in righteousness;-

# 4620

A Grace and Favour from Allah; and Allah is full of Knowledge and Wisdom.

# 4621

If two parties among the Believers fall into a quarrel, make ye peace between them: but if one of them transgresses beyond bounds against the other, then fight ye (all) against the one that transgresses until it complies with the command of Allah; but if it complies, then make peace between them with justice, and be fair: for Allah loves those who are fair (and just).

# 4622

The Believers are but a single Brotherhood: So make peace and reconciliation between your two (contending) brothers; and fear Allah, that ye may receive Mercy.

# 4623

O ye who believe! Let not some men among you laugh at others: It may be that the (latter) are better than the (former): Nor let some women laugh at others: It may be that the (latter are better than the (former): Nor defame nor be sarcastic to each other, nor call each other by (offensive) nicknames: Ill-seeming is a name connoting wickedness, (to be used of one) after he has believed: And those who do not desist are (indeed) doing wrong.

# 4624

O ye who believe! Avoid suspicion as much (as possible): for suspicion in some cases is a sin: And spy not on each other behind their backs. Would any of you like to eat the flesh of his dead brother? Nay, ye would abhor it... But fear Allah: For Allah is Oft-Returning, Most Merciful.

# 4625

O mankind! We created you from a single (pair) of a male and a female, and made you into nations and tribes, that ye may know each other (not that ye may despise (each other). Verily the most honoured of you in the sight of Allah is (he who is) the most righteous of you. And Allah has full knowledge and is well acquainted (with all things).

# 4626

The desert Arabs say, "We believe." Say, "Ye have no faith; but ye (only) say, 'We have submitted our wills to Allah,' For not yet has Faith entered your hearts. But if ye obey Allah and His Messenger, He will not belittle aught of your deeds: for Allah is Oft-Forgiving, Most Merciful."

# 4627

Only those are Believers who have believed in Allah and His Messenger, and have never since doubted, but have striven with their belongings and their persons in the Cause of Allah: Such are the sincere ones.

# 4628

Say: "What! Will ye instruct Allah about your religion? But Allah knows all that is in the heavens and on earth: He has full knowledge of all things.

# 4629

They impress on thee as a favour that they have embraced Islam. Say, "Count not your Islam as a favour upon me: Nay, Allah has conferred a favour upon you that He has guided you to the faith, if ye be true and sincere.

# 4630

"Verily Allah knows the secrets of the heavens and the earth: and Allah Sees well all that ye do."

# 4631

Qaf: By the Glorious Qur'an (Thou art Allah's Messenger).

# 4632

But they wonder that there has come to them a Warner from among themselves. So the Unbelievers say: "This is a wonderful thing!

# 4633

"What! When we die and become dust, (shall we live again?) That is a (sort of) return far (from our understanding)."

# 4634

We already know how much of them the earth takes away: With Us is a record guarding (the full account).

# 4635

But they deny the Truth when it comes to them: so they are in a confused state.

# 4636

Do they not look at the sky above them?- How We have made it and adorned it, and there are no flaws in it?

# 4637

And the earth- We have spread it out, and set thereon mountains standing firm, and produced therein every kind of beautiful growth (in pairs)-

# 4638

To be observed and commemorated by every devotee turning (to Allah).

# 4639

And We send down from the sky rain charted with blessing, and We produce therewith gardens and Grain for harvests;

# 4640

And tall (and stately) palm-trees, with shoots of fruit-stalks, piled one over another;-

# 4641

As sustenance for (Allah's) Servants;- and We give (new) life therewith to land that is dead: Thus will be the Resurrection.

# 4642

Before them was denied (the Hereafter) by the People of Noah, the Companions of the Rass, the Thamud,

# 4643

The 'Ad, Pharaoh, the brethren of Lut,

# 4644

The Companions of the Wood, and the People of Tubba'; each one (of them) rejected the messengers, and My warning was duly fulfilled (in them).

# 4645

Were We then weary with the first Creation, that they should be in confused doubt about a new Creation?

# 4646

It was We Who created man, and We know what dark suggestions his soul makes to him: for We are nearer to him than (his) jugular vein.

# 4647

Behold, two (guardian angels) appointed to learn (his doings) learn (and noted them), one sitting on the right and one on the left.

# 4648

Not a word does he utter but there is a sentinel by him, ready (to note it).

# 4649

And the stupor of death will bring Truth (before his eyes): "This was the thing which thou wast trying to escape!"

# 4650

And the Trumpet shall be blown: that will be the Day whereof Warning (had been given).

# 4651

And there will come forth every soul: with each will be an (angel) to drive, and an (angel) to bear witness.

# 4652

(It will be said:) "Thou wast heedless of this; now have We removed thy veil, and sharp is thy sight this Day!"

# 4653

And his Companion will say: "Here is (his Record) ready with me!"

# 4654

(The sentence will be:) "Throw, throw into Hell every contumacious Rejecter (of Allah)!-

# 4655

"Who forbade what was good, transgressed all bounds, cast doubts and suspicions;

# 4656

"Who set up another god beside Allah: Throw him into a severe penalty."

# 4657

His Companion will say: "Our Lord! I did not make him transgress, but he was (himself) far astray."

# 4658

He will say: "Dispute not with each other in My Presence: I had already in advance sent you Warning.

# 4659

"The Word changes not before Me, and I do not the least injustice to My Servants."

# 4660

One Day We will ask Hell, "Art thou filled to the full?" It will say, "Are there any more (to come)?"

# 4661

And the Garden will be brought nigh to the Righteous,- no more a thing distant.

# 4662

(A voice will say:) "This is what was promised for you,- for every one who turned (to Allah) in sincere repentance, who kept (His Law),

# 4663

"Who feared (Allah) Most Gracious Unseen, and brought a heart turned in devotion (to Him):

# 4664

"Enter ye therein in Peace and Security; this is a Day of Eternal Life!"

# 4665

There will be for them therein all that they wish,- and more besides in Our Presence.

# 4666

But how many generations before them did We destroy (for their sins),- stronger in power than they? Then did they wander through the land: was there any place of escape (for them)?

# 4667

Verily in this is a Message for any that has a heart and understanding or who gives ear and earnestly witnesses (the truth).

# 4668

We created the heavens and the earth and all between them in Six Days, nor did any sense of weariness touch Us.

# 4669

Bear, then, with patience, all that they say, and celebrate the praises of thy Lord, before the rising of the sun and before (its) setting.

# 4670

And during part of the night, (also,) celebrate His praises, and (so likewise) after the postures of adoration.

# 4671

And listen for the Day when the Caller will call out from a place quiet near,-

# 4672

The Day when they will hear a (mighty) Blast in (very) truth: that will be the Day of Resurrection.

# 4673

Verily it is We Who give Life and Death; and to Us is the Final Goal-

# 4674

The Day when the Earth will be rent asunder, from (men) hurrying out: that will be a gathering together,- quite easy for Us.

# 4675

We know best what they say; and thou art not one to overawe them by force. So admonish with the Qur'an such as fear My Warning!

# 4676

By the (Winds) that scatter broadcast;

# 4677

And those that lift and bear away heavy weights;

# 4678

And those that flow with ease and gentleness;

# 4679

And those that distribute and apportion by Command;-

# 4680

Verily that which ye are promised is true;

# 4681

And verily Judgment and Justice must indeed come to pass.

# 4682

By the Sky with (its) numerous Paths,

# 4683

Truly ye are in a doctrine discordant,

# 4684

Through which are deluded (away from the Truth) such as would be deluded.

# 4685

Woe to the falsehood-mongers,-

# 4686

Those who (flounder) heedless in a flood of confusion:

# 4687

They ask, "When will be the Day of Judgment and Justice?"

# 4688

(It will be) a Day when they will be tried (and tested) over the Fire!

# 4689

"Taste ye your trial! This is what ye used to ask to be hastened!"

# 4690

As to the Righteous, they will be in the midst of Gardens and Springs,

# 4691

Taking joy in the things which their Lord gives them, because, before then, they lived a good life.

# 4692

They were in the habit of sleeping but little by night,

# 4693

And in the hour of early dawn, they (were found) praying for Forgiveness;

# 4694

And in their wealth and possessions (was remembered) the right of the (needy,) him who asked, and him who (for some reason) was prevented (from asking).

# 4695

On the earth are signs for those of assured Faith,

# 4696

As also in your own selves: Will ye not then see?

# 4697

And in heaven is your Sustenance, as (also) that which ye are promised.

# 4698

Then, by the Lord of heaven and earth, this is the very Truth, as much as the fact that ye can speak intelligently to each other.

# 4699

Has the story reached thee, of the honoured guests of Abraham?

# 4700

Behold, they entered his presence, and said: "Peace!" He said, "Peace!" (and thought, "These seem) unusual people."

# 4701

Then he turned quickly to his household, brought out a fatted calf,

# 4702

And placed it before them.. he said, "Will ye not eat?"

# 4703

(When they did not eat), He conceived a fear of them. They said, "Fear not," and they gave him glad tidings of a son endowed with knowledge.

# 4704

But his wife came forward (laughing) aloud: she smote her forehead and said: "A barren old woman!"

# 4705

They said, "Even so has thy Lord spoken: and He is full of Wisdom and Knowledge."

# 4706

(Abraham) said: "And what, O ye Messengers, is your errand (now)?"

# 4707

They said, "We have been sent to a people (deep) in sin;-

# 4708

"To bring on, on them, (a shower of) stones of clay (brimstone),

# 4709

"Marked as from thy Lord for those who trespass beyond bounds."

# 4710

Then We evacuated those of the Believers who were there,

# 4711

But We found not there any just (Muslim) persons except in one house:

# 4712

And We left there a Sign for such as fear the Grievous Penalty.

# 4713

And in Moses (was another Sign): Behold, We sent him to Pharaoh, with authority manifest.

# 4714

But (Pharaoh) turned back with his Chiefs, and said, "A sorcerer, or one possessed!"

# 4715

So We took him and his forces, and threw them into the sea; and his was the blame.

# 4716

And in the 'Ad (people) (was another Sign): Behold, We sent against them the devastating Wind:

# 4717

It left nothing whatever that it came up against, but reduced it to ruin and rottenness.

# 4718

And in the Thamud (was another Sign): Behold, they were told, "Enjoy (your brief day) for a little while!"

# 4719

But they insolently defied the Command of their Lord: So the stunning noise (of an earthquake) seized them, even while they were looking on.

# 4720

Then they could not even stand (on their feet), nor could they help themselves.

# 4721

So were the People of Noah before them for they wickedly transgressed.

# 4722

With power and skill did We construct the Firmament: for it is We Who create the vastness of pace.

# 4723

And We have spread out the (spacious) earth: How excellently We do spread out!

# 4724

And of every thing We have created pairs: That ye may receive instruction.

# 4725

Hasten ye then (at once) to Allah: I am from Him a Warner to you, clear and open!

# 4726

And make not another an object of worship with Allah: I am from Him a Warner to you, clear and open!

# 4727

Similarly, no messenger came to the Peoples before them, but they said (of him) in like manner, "A sorcerer, or one possessed"!

# 4728

Is this the legacy they have transmitted, one to another? Nay, they are themselves a people transgressing beyond bounds!

# 4729

So turn away from them: not thine is the blame.

# 4730

But teach (thy Message) for teaching benefits the Believers.

# 4731

I have only created Jinns and men, that they may serve Me.

# 4732

No Sustenance do I require of them, nor do I require that they should feed Me.

# 4733

For Allah is He Who gives (all) Sustenance,- Lord of Power,- Steadfast (for ever).

# 4734

For the Wrong-doers, their portion is like unto the portion of their fellows (of earlier generations): then let them not ask Me to hasten (that portion)!

# 4735

Woe, then, to the Unbelievers, on account of that Day of theirs which they have been promised!

# 4736

By the Mount (of Revelation);

# 4737

By a Decree inscribed

# 4738

In a Scroll unfolded;

# 4739

By the much-frequented Fane;

# 4740

By the Canopy Raised High;

# 4741

And by the Ocean filled with Swell;-

# 4742

Verily, the Doom of thy Lord will indeed come to pass;-

# 4743

There is none can avert it;-

# 4744

On the Day when the firmament will be in dreadful commotion.

# 4745

And the mountains will fly hither and thither.

# 4746

Then woe that Day to those that treat (Truth) as Falsehood;-

# 4747

That play (and paddle) in shallow trifles.

# 4748

That Day shall they be thrust down to the Fire of Hell, irresistibly.

# 4749

"This:, it will be said, "Is the Fire,- which ye were wont to deny!

# 4750

"Is this then a fake, or is it ye that do not see?

# 4751

"Burn ye therein: the same is it to you whether ye bear it with patience, or not: Ye but receive the recompense of your (own) deeds."

# 4752

As to the Righteous, they will be in Gardens, and in Happiness,-

# 4753

Enjoying the (Bliss) which their Lord hath bestowed on them, and their Lord shall deliver them from the Penalty of the Fire.

# 4754

(To them will be said:) "Eat and drink ye, with profit and health, because of your (good) deeds."

# 4755

They will recline (with ease) on Thrones (of dignity) arranged in ranks; and We shall join them to Companions, with beautiful big and lustrous eyes.

# 4756

And those who believe and whose families follow them in Faith,- to them shall We join their families: Nor shall We deprive them (of the fruit) of aught of their works: (Yet) is each individual in pledge for his deeds.

# 4757

And We shall bestow on them, of fruit and meat, anything they shall desire.

# 4758

They shall there exchange, one with another, a (loving) cup free of frivolity, free of all taint of ill.

# 4759

Round about them will serve, (devoted) to them, young male servants (handsome) as Pearls well-guarded.

# 4760

They will advance to each other, engaging in mutual enquiry.

# 4761

They will say: "Aforetime, we were not without fear for the sake of our people.

# 4762

"But Allah has been good to us, and has delivered us from the Penalty of the Scorching Wind.

# 4763

"Truly, we did call unto Him from of old: truly it is He, the Beneficent, the Merciful!"

# 4764

Therefore proclaim thou the praises (of thy Lord): for by the Grace of thy Lord, thou art no (vulgar) soothsayer, nor art thou one possessed.

# 4765

Or do they say:- "A Poet! we await for him some calamity (hatched) by Time!"

# 4766

Say thou: "Await ye!- I too will wait along with you!"

# 4767

Is it that their faculties of understanding urge them to this, or are they but a people transgressing beyond bounds?

# 4768

Or do they say, "He fabricated the (Message)"? Nay, they have no faith!

# 4769

Let them then produce a recital like unto it,- If (it be) they speak the truth!

# 4770

Were they created of nothing, or were they themselves the creators?

# 4771

Or did they create the heavens and the earth? Nay, they have no firm belief.

# 4772

Or are the Treasures of thy Lord with them, or are they the managers (of affairs)?

# 4773

Or have they a ladder, by which they can (climb up to heaven and) listen (to its secrets)? Then let (such a) listener of theirs produce a manifest proof.

# 4774

Or has He only daughters and ye have sons?

# 4775

Or is it that thou dost ask for a reward, so that they are burdened with a load of debt?-

# 4776

Or that the Unseen in it their hands, and they write it down?

# 4777

Or do they intend a plot (against thee)? But those who defy Allah are themselves involved in a Plot!

# 4778

Or have they a god other than Allah? Exalted is Allah far above the things they associate with Him!

# 4779

Were they to see a piece of the sky falling (on them), they would (only) say: "Clouds gathered in heaps!"

# 4780

So leave them alone until they encounter that Day of theirs, wherein they shall (perforce) swoon (with terror),-

# 4781

The Day when their plotting will avail them nothing and no help shall be given them.

# 4782

And verily, for those who do wrong, there is another punishment besides this: But most of them understand not.

# 4783

Now await in patience the command of thy Lord: for verily thou art in Our eyes: and celebrate the praises of thy Lord the while thou standest forth,

# 4784

And for part of the night also praise thou Him,- and at the retreat of the stars!

# 4785

By the Star when it goes down,-

# 4786

Your Companion is neither astray nor being misled.

# 4787

Nor does he say (aught) of (his own) Desire.

# 4788

It is no less than inspiration sent down to him:

# 4789

He was taught by one Mighty in Power,

# 4790

Endued with Wisdom: for he appeared (in stately form);

# 4791

While he was in the highest part of the horizon:

# 4792

Then he approached and came closer,

# 4793

And was at a distance of but two bow-lengths or (even) nearer;

# 4794

So did (Allah) convey the inspiration to His Servant- (conveyed) what He (meant) to convey.

# 4795

The (Prophet's) (mind and) heart in no way falsified that which he saw.

# 4796

Will ye then dispute with him concerning what he saw?

# 4797

For indeed he saw him at a second descent,

# 4798

Near the Lote-tree beyond which none may pass:

# 4799

Near it is the Garden of Abode.

# 4800

Behold, the Lote-tree was shrouded (in mystery unspeakable!)

# 4801

(His) sight never swerved, nor did it go wrong!

# 4802

For truly did he see, of the Signs of his Lord, the Greatest!

# 4803

Have ye seen Lat. and 'Uzza,

# 4804

And another, the third (goddess), Manat?

# 4805

What! for you the male sex, and for Him, the female?

# 4806

Behold, such would be indeed a division most unfair!

# 4807

These are nothing but names which ye have devised,- ye and your fathers,- for which Allah has sent down no authority (whatever). They follow nothing but conjecture and what their own souls desire!- Even though there has already come to them Guidance from their Lord!

# 4808

Nay, shall man have (just) anything he hankers after?

# 4809

But it is to Allah that the End and the Beginning (of all things) belong.

# 4810

How many-so-ever be the angels in the heavens, their intercession will avail nothing except after Allah has given leave for whom He pleases and that he is acceptable to Him.

# 4811

Those who believe not in the Hereafter, name the angels with female names.

# 4812

But they have no knowledge therein. They follow nothing but conjecture; and conjecture avails nothing against Truth.

# 4813

Therefore shun those who turn away from Our Message and desire nothing but the life of this world.

# 4814

That is as far as knowledge will reach them. Verily thy Lord knoweth best those who stray from His Path, and He knoweth best those who receive guidance.

# 4815

Yea, to Allah belongs all that is in the heavens and on earth: so that He rewards those who do evil, according to their deeds, and He rewards those who do good, with what is best.

# 4816

Those who avoid great sins and shameful deeds, only (falling into) small faults,- verily thy Lord is ample in forgiveness. He knows you well when He brings you out of the earth, And when ye are hidden in your mothers' wombs. Therefore justify not yourselves: He knows best who it is that guards against evil.

# 4817

Seest thou one who turns back,

# 4818

Gives a little, then hardens (his heart)?

# 4819

What! Has he knowledge of the Unseen so that he can see?

# 4820

Nay, is he not acquainted with what is in the Books of Moses-

# 4821

And of Abraham who fulfilled his engagements?-

# 4822

Namely, that no bearer of burdens can bear the burden of another;

# 4823

That man can have nothing but what he strives for;

# 4824

That (the fruit of) his striving will soon come in sight:

# 4825

Then will he be rewarded with a reward complete;

# 4826

That to thy Lord is the final Goal;

# 4827

That it is He Who granteth Laughter and Tears;

# 4828

That it is He Who granteth Death and Life;

# 4829

That He did create in pairs,- male and female,

# 4830

From a seed when lodged (in its place);

# 4831

That He hath promised a Second Creation (Raising of the Dead);

# 4832

That it is He Who giveth wealth and satisfaction;

# 4833

That He is the Lord of Sirius (the Mighty Star);

# 4834

And that it is He Who destroyed the (powerful) ancient 'Ad (people),

# 4835

And the Thamud nor gave them a lease of perpetual life.

# 4836

And before them, the people of Noah, for that they were (all) most unjust and most insolent transgressors,

# 4837

And He destroyed the Overthrown Cities (of Sodom and Gomorrah).

# 4838

So that (ruins unknown) have covered them up.

# 4839

Then which of the gifts of thy Lord, (O man,) wilt thou dispute about?

# 4840

This is a Warner, of the (series of) Warners of old!

# 4841

The (Judgment) ever approaching draws nigh:

# 4842

No (soul) but Allah can lay it bare.

# 4843

Do ye then wonder at this recital?

# 4844

And will ye laugh and not weep,-

# 4845

Wasting your time in vanities?

# 4846

But fall ye down in prostration to Allah, and adore (Him)!

# 4847

The Hour (of Judgment) is nigh, and the moon is cleft asunder.

# 4848

But if they see a Sign, they turn away, and say, "This is (but) transient magic."

# 4849

They reject (the warning) and follow their (own) lusts but every matter has its appointed time.

# 4850

There have already come to them Recitals wherein there is (enough) to check (them),

# 4851

Mature wisdom;- but (the preaching of) Warners profits them not.

# 4852

Therefore, (O Prophet,) turn away from them. The Day that the Caller will call (them) to a terrible affair,

# 4853

They will come forth,- their eyes humbled - from (their) graves, (torpid) like locusts scattered abroad,

# 4854

Hastening, with eyes transfixed, towards the Caller!- "Hard is this Day!", the Unbelievers will say.

# 4855

Before them the People of Noah rejected (their messenger): they rejected Our servant, and said, "Here is one possessed!", and he was driven out.

# 4856

Then he called on his Lord: "I am one overcome: do Thou then help (me)!"

# 4857

So We opened the gates of heaven, with water pouring forth.

# 4858

And We caused the earth to gush forth with springs, so the waters met (and rose) to the extent decreed.

# 4859

But We bore him on an (Ark) made of broad planks and caulked with palm-fibre:

# 4860

She floats under our eyes (and care): a recompense to one who had been rejected (with scorn)!

# 4861

And We have left this as a Sign (for all time): then is there any that will receive admonition?

# 4862

But how (terrible) was My Penalty and My Warning?

# 4863

And We have indeed made the Qur'an easy to understand and remember: then is there any that will receive admonition?

# 4864

The 'Ad (people) (too) rejected (Truth): then how terrible was My Penalty and My Warning?

# 4865

For We sent against them a furious wind, on a Day of violent Disaster,

# 4866

Plucking out men as if they were roots of palm-trees torn up (from the ground).

# 4867

Yea, how (terrible) was My Penalty and My Warning!

# 4868

But We have indeed made the Qur'an easy to understand and remember: then is there any that will receive admonition?

# 4869

The Thamud (also) rejected (their) Warners.

# 4870

For they said: "What! a man! a Solitary one from among ourselves! shall we follow such a one? Truly should we then be straying in mind, and mad!

# 4871

"Is it that the Message is sent to him, of all people amongst us? Nay, he is a liar, an insolent one!"

# 4872

Ah! they will know on the morrow, which is the liar, the insolent one!

# 4873

For We will send the she-camel by way of trial for them. So watch them, (O Salih), and possess thyself in patience!

# 4874

And tell them that the water is to be divided between them: Each one's right to drink being brought forward (by suitable turns).

# 4875

But they called to their companion, and he took a sword in hand, and hamstrung (her).

# 4876

Ah! how (terrible) was My Penalty and My Warning!

# 4877

For We sent against them a single Mighty Blast, and they became like the dry stubble used by one who pens cattle.

# 4878

And We have indeed made the Qur'an easy to understand and remember: then is there any that will receive admonition?

# 4879

The people of Lut rejected (his) warning.

# 4880

We sent against them a violent Tornado with showers of stones, (which destroyed them), except Lut's household: them We delivered by early Dawn,-

# 4881

As a Grace from Us: thus do We reward those who give thanks.

# 4882

And (Lut) did warn them of Our Punishment, but they disputed about the Warning.

# 4883

And they even sought to snatch away his guests from him, but We blinded their eyes. (They heard:) "Now taste ye My Wrath and My Warning."

# 4884

Early on the morrow an abiding Punishment seized them:

# 4885

"So taste ye My Wrath and My Warning."

# 4886

And We have indeed made the Qur'an easy to understand and remember: then is there any that will receive admonition?

# 4887

To the People of Pharaoh, too, aforetime, came Warners (from Allah).

# 4888

The (people) rejected all Our Signs; but We seized them with such Penalty (as comes) from One Exalted in Power, able to carry out His Will.

# 4889

Are your Unbelievers, (O Quraish), better than they? Or have ye an immunity in the Sacred Books?

# 4890

Or do they say: "We acting together can defend ourselves"?

# 4891

Soon will their multitude be put to flight, and they will show their backs.

# 4892

Nay, the Hour (of Judgment) is the time promised them (for their full recompense): And that Hour will be most grievous and most bitter.

# 4893

Truly those in sin are the ones straying in mind, and mad.

# 4894

The Day they will be dragged through the Fire on their faces, (they will hear:) "Taste ye the touch of Hell!"

# 4895

Verily, all things have We created in proportion and measure.

# 4896

And Our Command is but a single (Act),- like the twinkling of an eye.

# 4897

And (oft) in the past, have We destroyed gangs like unto you: then is there any that will receive admonition?

# 4898

All that they do is noted in (their) Books (of Deeds):

# 4899

Every matter, small and great, is on record.

# 4900

As to the Righteous, they will be in the midst of Gardens and Rivers,

# 4901

In an Assembly of Truth, in the Presence of a Sovereign Omnipotent.

# 4902

(Allah) Most Gracious!

# 4903

It is He Who has taught the Qur'an.

# 4904

He has created man:

# 4905

He has taught him speech (and intelligence).

# 4906

The sun and the moon follow courses (exactly) computed;

# 4907

And the herbs and the trees - both (alike) prostrate in adoration.

# 4908

And the Firmament has He raised high, and He has set up the Balance (of Justice),

# 4909

In order that ye may not transgress (due) balance.

# 4910

So establish weight with justice and fall not short in the balance.

# 4911

It is He Who has spread out the earth for (His) creatures:

# 4912

Therein is fruit and date-palms, producing spathes (enclosing dates);

# 4913

Also corn, with (its) leaves and stalk for fodder, and sweet-smelling plants.

# 4914

Then which of the favours of your Lord will ye deny?

# 4915

He created man from sounding clay like unto pottery,

# 4916

And He created Jinns from fire free of smoke:

# 4917

Then which of the favours of your Lord will ye deny?

# 4918

(He is) Lord of the two Easts and Lord of the two Wests:

# 4919

Then which of the favours of your Lord will ye deny?

# 4920

He has let free the two bodies of flowing water, meeting together:

# 4921

Between them is a Barrier which they do not transgress:

# 4922

Then which of the favours of your Lord will ye deny?

# 4923

Out of them come Pearls and Coral:

# 4924

Then which of the favours of your Lord will ye deny?

# 4925

And His are the Ships sailing smoothly through the seas, lofty as mountains:

# 4926

Then which of the favours of your Lord will ye deny?

# 4927

All that is on earth will perish:

# 4928

But will abide (for ever) the Face of thy Lord,- full of Majesty, Bounty and Honour.

# 4929

Then which of the favours of your Lord will ye deny?

# 4930

Of Him seeks (its need) every creature in the heavens and on earth: every day in (new) Splendour doth He (shine)!

# 4931

Then which of the favours of your Lord will ye deny?

# 4932

Soon shall We settle your affairs, O both ye worlds!

# 4933

Then which of the favours of your Lord will ye deny?

# 4934

O ye assembly of Jinns and men! If it be ye can pass beyond the zones of the heavens and the earth, pass ye! not without authority shall ye be able to pass!

# 4935

Then which of the favours of your Lord will ye deny?

# 4936

On you will be sent (O ye evil ones twain!) a flame of fire (to burn) and a smoke (to choke): no defence will ye have:

# 4937

Then which of the favours of your Lord will ye deny?

# 4938

When the sky is rent asunder, and it becomes red like ointment:

# 4939

Then which of the favours of your Lord will ye deny?

# 4940

On that Day no question will be asked of man or Jinn as to his sin.

# 4941

Then which of the favours of your Lord will ye deny?

# 4942

(For) the sinners will be known by their marks: and they will be seized by their forelocks and their feet.

# 4943

Then which of the favours of your Lord will ye deny?

# 4944

This is the Hell which the Sinners deny:

# 4945

In its midst and in the midst of boiling hot water will they wander round!

# 4946

Then which of the favours of your Lord will ye deny?

# 4947

But for such as fear the time when they will stand before (the Judgment Seat of) their Lord, there will be two Gardens-

# 4948

Then which of the favours of your Lord will ye deny?-

# 4949

Containing all kinds (of trees and delights);-

# 4950

Then which of the favours of your Lord will ye deny?-

# 4951

In them (each) will be two Springs flowing (free);

# 4952

Then which of the favours of your Lord will ye deny?-

# 4953

In them will be Fruits of every kind, two and two.

# 4954

Then which of the favours of your Lord will ye deny?

# 4955

They will recline on Carpets, whose inner linings will be of rich brocade: the Fruit of the Gardens will be near (and easy of reach).

# 4956

Then which of the favours of your Lord will ye deny?

# 4957

In them will be (Maidens), chaste, restraining their glances, whom no man or Jinn before them has touched;-

# 4958

Then which of the favours of your Lord will ye deny?-

# 4959

Like unto Rubies and coral.

# 4960

Then which of the favours of your Lord will ye deny?

# 4961

Is there any Reward for Good - other than Good?

# 4962

Then which of the favours of your Lord will ye deny?

# 4963

And besides these two, there are two other Gardens,-

# 4964

Then which of the favours of your Lord will ye deny?-

# 4965

Dark-green in colour (from plentiful watering).

# 4966

Then which of the favours of your Lord will ye deny?

# 4967

In them (each) will be two Springs pouring forth water in continuous abundance:

# 4968

Then which of the favours of your Lord will ye deny?

# 4969

In them will be Fruits, and dates and pomegranates:

# 4970

Then which of the favours of your Lord will ye deny?

# 4971

In them will be fair (Companions), good, beautiful;-

# 4972

Then which of the favours of your Lord will ye deny?-

# 4973

Companions restrained (as to their glances), in (goodly) pavilions;-

# 4974

Then which of the favours of your Lord will ye deny?-

# 4975

Whom no man or Jinn before them has touched;-

# 4976

Then which of the favours of your Lord will ye deny?-

# 4977

Reclining on green Cushions and rich Carpets of beauty.

# 4978

Then which of the favours of your Lord will ye deny?

# 4979

Blessed be the name of thy Lord, full of Majesty, Bounty and Honour.

# 4980

When the Event inevitable cometh to pass,

# 4981

Then will no (soul) entertain falsehood concerning its coming.

# 4982

(Many) will it bring low; (many) will it exalt;

# 4983

When the earth shall be shaken to its depths,

# 4984

And the mountains shall be crumbled to atoms,

# 4985

Becoming dust scattered abroad,

# 4986

And ye shall be sorted out into three classes.

# 4987

Then (there will be) the Companions of the Right Hand;- What will be the Companions of the Right Hand?

# 4988

And the Companions of the Left Hand,- what will be the Companions of the Left Hand?

# 4989

And those Foremost (in Faith) will be Foremost (in the Hereafter).

# 4990

These will be those Nearest to Allah:

# 4991

In Gardens of Bliss:

# 4992

A number of people from those of old,

# 4993

And a few from those of later times.

# 4994

(They will be) on Thrones encrusted (with gold and precious stones),

# 4995

Reclining on them, facing each other.

# 4996

Round about them will (serve) youths of perpetual (freshness),

# 4997

With goblets, (shining) beakers, and cups (filled) out of clear-flowing fountains:

# 4998

No after-ache will they receive therefrom, nor will they suffer intoxication:

# 4999

And with fruits, any that they may select:

# 5000

And the flesh of fowls, any that they may desire.

# 5001

And (there will be) Companions with beautiful, big, and lustrous eyes,-

# 5002

Like unto Pearls well-guarded.

# 5003

A Reward for the deeds of their past (life).

# 5004

Not frivolity will they hear therein, nor any taint of ill,-

# 5005

Only the saying, "Peace! Peace".

# 5006

The Companions of the Right Hand,- what will be the Companions of the Right Hand?

# 5007

(They will be) among Lote-trees without thorns,

# 5008

Among Talh trees with flowers (or fruits) piled one above another,-

# 5009

In shade long-extended,

# 5010

By water flowing constantly,

# 5011

And fruit in abundance.

# 5012

Whose season is not limited, nor (supply) forbidden,

# 5013

And on Thrones (of Dignity), raised high.

# 5014

We have created (their Companions) of special creation.

# 5015

And made them virgin - pure (and undefiled), -

# 5016

Beloved (by nature), equal in age,-

# 5017

For the Companions of the Right Hand.

# 5018

A (goodly) number from those of old,

# 5019

And a (goodly) number from those of later times.

# 5020

The Companions of the Left Hand,- what will be the Companions of the Left Hand?

# 5021

(They will be) in the midst of a Fierce Blast of Fire and in Boiling Water,

# 5022

And in the shades of Black Smoke:

# 5023

Nothing (will there be) to refresh, nor to please:

# 5024

For that they were wont to be indulged, before that, in wealth (and luxury),

# 5025

And persisted obstinately in wickedness supreme!

# 5026

And they used to say, "What! when we die and become dust and bones, shall we then indeed be raised up again?-

# 5027

"(We) and our fathers of old?"

# 5028

Say: "Yea, those of old and those of later times,

# 5029

"All will certainly be gathered together for the meeting appointed for a Day well-known.

# 5030

"Then will ye truly,- O ye that go wrong, and treat (Truth) as Falsehood!-

# 5031

"Ye will surely taste of the Tree of Zaqqum.

# 5032

"Then will ye fill your insides therewith,

# 5033

"And drink Boiling Water on top of it:

# 5034

"Indeed ye shall drink like diseased camels raging with thirst!"

# 5035

Such will be their entertainment on the Day of Requital!

# 5036

It is We Who have created you: why will ye not witness the Truth?

# 5037

Do ye then see?- The (human Seed) that ye throw out,-

# 5038

Is it ye who create it, or are We the Creators?

# 5039

We have decreed Death to be your common lot, and We are not to be frustrated

# 5040

from changing your Forms and creating you (again) in (forms) that ye know not.

# 5041

And ye certainly know already the first form of creation: why then do ye not celebrate His praises?

# 5042

See ye the seed that ye sow in the ground?

# 5043

Is it ye that cause it to grow, or are We the Cause?

# 5044

Were it Our Will, We could crumble it to dry powder, and ye would be left in wonderment,

# 5045

(Saying), "We are indeed left with debts (for nothing):

# 5046

"Indeed are we shut out (of the fruits of our labour)"

# 5047

See ye the water which ye drink?

# 5048

Do ye bring it down (in rain) from the cloud or do We?

# 5049

Were it Our Will, We could make it salt (and unpalatable): then why do ye not give thanks?

# 5050

See ye the Fire which ye kindle?

# 5051

Is it ye who grow the tree which feeds the fire, or do We grow it?

# 5052

We have made it a memorial (of Our handiwork), and an article of comfort and convenience for the denizens of deserts.

# 5053

Then celebrate with praises the name of thy Lord, the Supreme!

# 5054

Furthermore I call to witness the setting of the Stars,-

# 5055

And that is indeed a mighty adjuration if ye but knew,-

# 5056

That this is indeed a qur'an Most Honourable,

# 5057

In Book well-guarded,

# 5058

Which none shall touch but those who are clean:

# 5059

A Revelation from the Lord of the Worlds.

# 5060

Is it such a Message that ye would hold in light esteem?

# 5061

And have ye made it your livelihood that ye should declare it false?

# 5062

Then why do ye not (intervene) when (the soul of the dying man) reaches the throat,-

# 5063

And ye the while (sit) looking on,-

# 5064

But We are nearer to him than ye, and yet see not,-

# 5065

Then why do ye not,- If you are exempt from (future) account,-

# 5066

Call back the soul, if ye are true (in the claim of independence)?

# 5067

Thus, then, if he be of those Nearest to Allah,

# 5068

(There is for him) Rest and Satisfaction, and a Garden of Delights.

# 5069

And if he be of the Companions of the Right Hand,

# 5070

(For him is the salutation), "Peace be unto thee", from the Companions of the Right Hand.

# 5071

And if he be of those who treat (Truth) as Falsehood, who go wrong,

# 5072

For him is Entertainment with Boiling Water.

# 5073

And burning in Hell-Fire.

# 5074

Verily, this is the Very Truth and Certainly.

# 5075

So celebrate with praises the name of thy Lord, the Supreme.

# 5076

Whatever is in the heavens and on earth,- let it declare the Praises and Glory of Allah: for He is the Exalted in Might, the Wise.

# 5077

To Him belongs the dominion of the heavens and the earth: It is He Who gives Life and Death; and He has Power over all things.

# 5078

He is the First and the Last, the Evident and the Immanent: and He has full knowledge of all things.

# 5079

He it is Who created the heavens and the earth in Six Days, and is moreover firmly established on the Throne (of Authority). He knows what enters within the earth and what comes forth out of it, what comes down from heaven and what mounts up to it. And He is with you wheresoever ye may be. And Allah sees well all that ye do.

# 5080

To Him belongs the dominion of the heavens and the earth: and all affairs are referred back to Allah.

# 5081

He merges Night into Day, and He merges Day into Night; and He has full knowledge of the secrets of (all) hearts.

# 5082

Believe in Allah and His messenger, and spend (in charity) out of the (substance) whereof He has made you heirs. For, those of you who believe and spend (in charity),- for them is a great Reward.

# 5083

What cause have ye why ye should not believe in Allah?- and the Messenger invites you to believe in your Lord, and has indeed taken your Covenant, if ye are men of Faith.

# 5084

He is the One Who sends to His Servant Manifest Signs, that He may lead you from the depths of Darkness into the Light and verily Allah is to you most kind and Merciful.

# 5085

And what cause have ye why ye should not spend in the cause of Allah?- For to Allah belongs the heritage of the heavens and the earth. Not equal among you are those who spent (freely) and fought, before the Victory, (with those who did so later). Those are higher in rank than those who spent (freely) and fought afterwards. But to all has Allah promised a goodly (reward). And Allah is well acquainted with all that ye do.

# 5086

Who is he that will Loan to Allah a beautiful loan? for (Allah) will increase it manifold to his credit, and he will have (besides) a liberal Reward.

# 5087

One Day shalt thou see the believing men and the believing women- how their Light runs forward before them and by their right hands: (their greeting will be): "Good News for you this Day! Gardens beneath which flow rivers! to dwell therein for aye! This is indeed the highest Achievement!"

# 5088

One Day will the Hypocrites- men and women - say to the Believers: "Wait for us! Let us borrow (a Light) from your Light!" It will be said: "Turn ye back to your rear! then seek a Light (where ye can)!" So a wall will be put up betwixt them, with a gate therein. Within it will be Mercy throughout, and without it, all alongside, will be (Wrath and) Punishment!

# 5089

(Those without) will call out, "Were we not with you?" (The others) will reply, "True! but ye led yourselves into temptation; ye looked forward (to our ruin); ye doubted (Allah's Promise); and (your false) desires deceived you; until there issued the Command of Allah. And the Deceiver deceived you in respect of Allah.

# 5090

"This Day shall no ransom be accepted of you, nor of those who rejected Allah." Your abode is the Fire: that is the proper place to claim you: and an evil refuge it is!"

# 5091

Has not the Time arrived for the Believers that their hearts in all humility should engage in the remembrance of Allah and of the Truth which has been revealed (to them), and that they should not become like those to whom was given Revelation aforetime, but long ages passed over them and their hearts grew hard? For many among them are rebellious transgressors.

# 5092

Know ye (all) that Allah giveth life to the earth after its death! already have We shown the Signs plainly to you, that ye may learn wisdom.

# 5093

For those who give in Charity, men and women, and loan to Allah a Beautiful Loan, it shall be increased manifold (to their credit), and they shall have (besides) a liberal reward.

# 5094

And those who believe in Allah and His messengers- they are the Sincere (lovers of Truth), and the witnesses (who testify), in the eyes of their Lord: They shall have their Reward and their Light. But those who reject Allah and deny Our Signs,- they are the Companions of Hell-Fire.

# 5095

Know ye (all), that the life of this world is but play and amusement, pomp and mutual boasting and multiplying, (in rivalry) among yourselves, riches and children. Here is a similitude: How rain and the growth which it brings forth, delight (the hearts of) the tillers; soon it withers; thou wilt see it grow yellow; then it becomes dry and crumbles away. But in the Hereafter is a Penalty severe (for the devotees of wrong). And Forgiveness from Allah and (His) Good Pleasure (for the devotees of Allah). And what is the life of this world, but goods and chattels of deception?

# 5096

Be ye foremost (in seeking) Forgiveness from your Lord, and a Garden (of Bliss), the width whereof is as the width of heaven and earth, prepared for those who believe in Allah and His messengers: that is the Grace of Allah, which He bestows on whom he pleases: and Allah is the Lord of Grace abounding.

# 5097

No misfortune can happen on earth or in your souls but is recorded in a decree before We bring it into existence: That is truly easy for Allah:

# 5098

In order that ye may not despair over matters that pass you by, nor exult over favours bestowed upon you. For Allah loveth not any vainglorious boaster,-

# 5099

Such persons as are covetous and commend covetousness to men. And if any turn back (from Allah's Way), verily Allah is Free of all Needs, Worthy of all Praise.

# 5100

We sent aforetime our messengers with Clear Signs and sent down with them the Book and the Balance (of Right and Wrong), that men may stand forth in justice; and We sent down Iron, in which is (material for) mighty war, as well as many benefits for mankind, that Allah may test who it is that will help, Unseen, Him and His messengers: For Allah is Full of Strength, Exalted in Might (and able to enforce His Will).

# 5101

And We sent Noah and Abraham, and established in their line Prophethood and Revelation: and some of them were on right guidance. But many of them became rebellious transgressors.

# 5102

Then, in their wake, We followed them up with (others of) Our messengers: We sent after them Jesus the son of Mary, and bestowed on him the Gospel; and We ordained in the hearts of those who followed him Compassion and Mercy. But the Monasticism which they invented for themselves, We did not prescribe for them: (We commanded) only the seeking for the Good Pleasure of Allah; but that they did not foster as they should have done. Yet We bestowed, on those among them who believed, their (due) reward, but many of them are rebellious transgressors.

# 5103

O ye that believe! Fear Allah, and believe in His Messenger, and He will bestow on you a double portion of His Mercy: He will provide for you a Light by which ye shall walk (straight in your path), and He will forgive you (your past): for Allah is Oft-Forgiving, Most Merciful.

# 5104

That the People of the Book may know that they have no power whatever over the Grace of Allah, that (His) Grace is (entirely) in His Hand, to bestow it on whomsoever He wills. For Allah is the Lord of Grace abounding.

# 5105

Allah has indeed heard (and accepted) the statement of the woman who pleads with thee concerning her husband and carries her complaint (in prayer) to Allah: and Allah (always) hears the arguments between both sides among you: for Allah hears and sees (all things).

# 5106

If any men among you divorce their wives by Zihar (calling them mothers), they cannot be their mothers: None can be their mothers except those who gave them birth. And in fact they use words (both) iniquitous and false: but truly Allah is one that blots out (sins), and forgives (again and again).

# 5107

But those who divorce their wives by Zihar, then wish to go back on the words they uttered,- (It is ordained that such a one) should free a slave before they touch each other: Thus are ye admonished to perform: and Allah is well-acquainted with (all) that ye do.

# 5108

And if any has not (the wherewithal), he should fast for two months consecutively before they touch each other. But if any is unable to do so, he should feed sixty indigent ones, this, that ye may show your faith in Allah and His Messenger. Those are limits (set by) Allah. For those who reject (Him), there is a grievous Penalty.

# 5109

Those who resist Allah and His Messenger will be humbled to dust, as were those before them: for We have already sent down Clear Signs. And the Unbelievers (will have) a humiliating Penalty,-

# 5110

On the Day that Allah will raise them all up (again) and show them the Truth (and meaning) of their conduct. Allah has reckoned its (value), though they may have forgotten it, for Allah is Witness to all things.

# 5111

Seest thou not that Allah doth know (all) that is in the heavens and on earth? There is not a secret consultation between three, but He makes the fourth among them, - Nor between five but He makes the sixth,- nor between fewer nor more, but He is in their midst, wheresoever they be: In the end will He tell them the truth of their conduct, on the Day of Judgment. For Allah has full knowledge of all things.

# 5112

Turnest thou not thy sight towards those who were forbidden secret counsels yet revert to that which they were forbidden (to do)? And they hold secret counsels among themselves for iniquity and hostility, and disobedience to the Messenger. And when they come to thee, they salute thee, not as Allah salutes thee, (but in crooked ways): And they say to themselves, "Why does not Allah punish us for our words?" Enough for them is Hell: In it will they burn, and evil is that destination!

# 5113

O ye who believe! When ye hold secret counsel, do it not for iniquity and hostility, and disobedience to the Prophet; but do it for righteousness and self-restraint; and fear Allah, to Whom ye shall be brought back.

# 5114

Secret counsels are only (inspired) by the Evil One, in order that he may cause grief to the Believers; but he cannot harm them in the least, except as Allah permits; and on Allah let the Believers put their trust.

# 5115

O ye who believe! When ye are told to make room in the assemblies, (spread out and) make room: (ample) room will Allah provide for you. And when ye are told to rise up, rise up Allah will rise up, to (suitable) ranks (and degrees), those of you who believe and who have been granted (mystic) Knowledge. And Allah is well-acquainted with all ye do.

# 5116

O ye who believe! When ye consult the Messenger in private, spend something in charity before your private consultation. That will be best for you, and most conducive to purity (of conduct). But if ye find not (the wherewithal), Allah is Oft-Forgiving, Most Merciful.

# 5117

Is it that ye are afraid of spending sums in charity before your private consultation (with him)? If, then, ye do not so, and Allah forgives you, then (at least) establish regular prayer; practise regular charity; and obey Allah and His Messenger. And Allah is well-acquainted with all that ye do.

# 5118

Turnest thou not thy attention to those who turn (in friendship) to such as have the Wrath of Allah upon them? They are neither of you nor of them, and they swear to falsehood knowingly.

# 5119

Allah has prepared for them a severe Penalty: evil indeed are their deeds.

# 5120

They have made their oaths a screen (for their misdeeds): thus they obstruct (men) from the Path of Allah: therefore shall they have a humiliating Penalty.

# 5121

Of no profit whatever to them, against Allah, will be their riches nor their sons: they will be Companions of the Fire, to dwell therein (for aye)!

# 5122

One day will Allah raise them all up (for Judgment): then will they swear to Him as they swear to you: And they think that they have something (to stand upon). No, indeed! they are but liars!

# 5123

The Evil One has got the better of them: so he has made them lose the remembrance of Allah. They are the Party of the Evil One. Truly, it is the Party of the Evil One that will perish!

# 5124

Those who resist Allah and His Messenger will be among those most humiliated.

# 5125

Allah has decreed: "It is I and My messengers who must prevail": For Allah is One full of strength, able to enforce His Will.

# 5126

Thou wilt not find any people who believe in Allah and the Last Day, loving those who resist Allah and His Messenger, even though they were their fathers or their sons, or their brothers, or their kindred. For such He has written Faith in their hearts, and strengthened them with a spirit from Himself. And He will admit them to Gardens beneath which Rivers flow, to dwell therein (for ever). Allah will be well pleased with them, and they with Him. They are the Party of Allah. Truly it is the Party of Allah that will achieve Felicity.

# 5127

Whatever is in the heavens and on earth, let it declare the Praises and Glory of Allah: for He is the Exalted in Might, the Wise.

# 5128

It is He Who got out the Unbelievers among the People of the Book from their homes at the first gathering (of the forces). Little did ye think that they would get out: And they thought that their fortresses would defend them from Allah! But the (Wrath of) Allah came to them from quarters from which they little expected (it), and cast terror into their hearts, so that they destroyed their dwellings by their own hands and the hands of the Believers, take warning, then, O ye with eyes (to see)!

# 5129

And had it not been that Allah had decreed banishment for them, He would certainly have punished them in this world: And in the Hereafter they shall (certainly) have the Punishment of the Fire.

# 5130

That is because they resisted Allah and His Messenger: and if any one resists Allah, verily Allah is severe in Punishment.

# 5131

Whether ye cut down (O ye Muslim!) The tender palm-trees, or ye left them standing on their roots, it was by leave of Allah, and in order that He might cover with shame the rebellious transgresses.

# 5132

What Allah has bestowed on His Messenger (and taken away) from them - for this ye made no expedition with either cavalry or camelry: but Allah gives power to His messengers over any He pleases: and Allah has power over all things.

# 5133

What Allah has bestowed on His Messenger (and taken away) from the people of the townships,- belongs to Allah,- to His Messenger and to kindred and orphans, the needy and the wayfarer; In order that it may not (merely) make a circuit between the wealthy among you. So take what the Messenger assigns to you, and deny yourselves that which he withholds from you. And fear Allah; for Allah is strict in Punishment.

# 5134

(Some part is due) to the indigent Muhajirs, those who were expelled from their homes and their property, while seeking Grace from Allah and (His) Good Pleasure, and aiding Allah and His Messenger: such are indeed the sincere ones:-

# 5135

But those who before them, had homes (in Medina) and had adopted the Faith,- show their affection to such as came to them for refuge, and entertain no desire in their hearts for things given to the (latter), but give them preference over themselves, even though poverty was their (own lot). And those saved from the covetousness of their own souls,- they are the ones that achieve prosperity.

# 5136

And those who came after them say: "Our Lord! Forgive us, and our brethren who came before us into the Faith, and leave not, in our hearts, rancour (or sense of injury) against those who have believed. Our Lord! Thou art indeed Full of Kindness, Most Merciful."

# 5137

Hast thou not observed the Hypocrites say to their misbelieving brethren among the People of the Book? - "If ye are expelled, we too will go out with you, and we will never hearken to any one in your affair; and if ye are attacked (in fight) we will help you". But Allah is witness that they are indeed liars.

# 5138

If they are expelled, never will they go out with them; and if they are attacked (in fight), they will never help them; and if they do help them, they will turn their backs; so they will receive no help.

# 5139

Of a truth ye are stronger (than they) because of the terror in their hearts, (sent) by Allah. This is because they are men devoid of understanding.

# 5140

They will not fight you (even) together, except in fortified townships, or from behind walls. Strong is their fighting (spirit) amongst themselves: thou wouldst think they were united, but their hearts are divided: that is because they are a people devoid of wisdom.

# 5141

Like those who lately preceded them, they have tasted the evil result of their conduct; and (in the Hereafter there is) for them a grievous Penalty;-

# 5142

(Their allies deceived them), like the Evil One, when he says to man, "Deny Allah": but when (man) denies Allah, (the Evil One) says, "I am free of thee: I do fear Allah, the Lord of the Worlds!"

# 5143

The end of both will be that they will go into the Fire, dwelling therein for ever. Such is the reward of the wrong-doers.

# 5144

O ye who believe! Fear Allah, and let every soul look to what (provision) He has sent forth for the morrow. Yea, fear Allah: for Allah is well-acquainted with (all) that ye do.

# 5145

And be ye not like those who forgot Allah; and He made them forget their own souls! Such are the rebellious transgressors!

# 5146

Not equal are the Companions of the Fire and the Companions of the Garden: it is the Companions of the Garden, that will achieve Felicity.

# 5147

Had We sent down this Qur'an on a mountain, verily, thou wouldst have seen it humble itself and cleave asunder for fear of Allah. Such are the similitudes which We propound to men, that they may reflect.

# 5148

Allah is He, than Whom there is no other god;- Who knows (all things) both secret and open; He, Most Gracious, Most Merciful.

# 5149

Allah is He, than Whom there is no other god;- the Sovereign, the Holy One, the Source of Peace (and Perfection), the Guardian of Faith, the Preserver of Safety, the Exalted in Might, the Irresistible, the Supreme: Glory to Allah! (High is He) above the partners they attribute to Him.

# 5150

He is Allah, the Creator, the Evolver, the Bestower of Forms (or Colours). To Him belong the Most Beautiful Names: whatever is in the heavens and on earth, doth declare His Praises and Glory: and He is the Exalted in Might, the Wise.

# 5151

O ye who believe! Take not my enemies and yours as friends (or protectors),- offering them (your) love, even though they have rejected the Truth that has come to you, and have (on the contrary) driven out the Prophet and yourselves (from your homes), (simply) because ye believe in Allah your Lord! If ye have come out to strive in My Way and to seek My Good Pleasure, (take them not as friends), holding secret converse of love (and friendship) with them: for I know full well all that ye conceal and all that ye reveal. And any of you that does this has strayed from the Straight Path.

# 5152

If they were to get the better of you, they would behave to you as enemies, and stretch forth their hands and their tongues against you for evil: and they desire that ye should reject the Truth.

# 5153

Of no profit to you will be your relatives and your children on the Day of Judgment: He will judge between you: for Allah sees well all that ye do.

# 5154

There is for you an excellent example (to follow) in Abraham and those with him, when they said to their people: "We are clear of you and of whatever ye worship besides Allah: we have rejected you, and there has arisen, between us and you, enmity and hatred for ever,- unless ye believe in Allah and Him alone": But not when Abraham said to his father: "I will pray for forgiveness for thee, though I have no power (to get) aught on thy behalf from Allah." (They prayed): "Our Lord! in Thee do we trust, and to Thee do we turn in repentance: to Thee is (our) Final Goal.

# 5155

"Our Lord! Make us not a (test and) trial for the Unbelievers, but forgive us, our Lord! for Thou art the Exalted in Might, the Wise."

# 5156

There was indeed in them an excellent example for you to follow,- for those whose hope is in Allah and in the Last Day. But if any turn away, truly Allah is Free of all Wants, Worthy of all Praise.

# 5157

It may be that Allah will grant love (and friendship) between you and those whom ye (now) hold as enemies. For Allah has power (over all things); And Allah is Oft-Forgiving, Most Merciful.

# 5158

Allah forbids you not, with regard to those who fight you not for (your) Faith nor drive you out of your homes, from dealing kindly and justly with them: for Allah loveth those who are just.

# 5159

Allah only forbids you, with regard to those who fight you for (your) Faith, and drive you out of your homes, and support (others) in driving you out, from turning to them (for friendship and protection). It is such as turn to them (in these circumstances), that do wrong.

# 5160

O ye who believe! When there come to you believing women refugees, examine (and test) them: Allah knows best as to their Faith: if ye ascertain that they are Believers, then send them not back to the Unbelievers. They are not lawful (wives) for the Unbelievers, nor are the (Unbelievers) lawful (husbands) for them. But pay the Unbelievers what they have spent (on their dower), and there will be no blame on you if ye marry them on payment of their dower to them. But hold not to the guardianship of unbelieving women: ask for what ye have spent on their dowers, and let the (Unbelievers) ask for what they have spent (on the dowers of women who come over to you). Such is the command of Allah: He judges (with justice) between you. And Allah is Full of Knowledge and Wisdom.

# 5161

And if any of your wives deserts you to the Unbelievers, and ye have an accession (by the coming over of a woman from the other side), then pay to those whose wives have deserted the equivalent of what they had spent (on their dower). And fear Allah, in Whom ye believe.

# 5162

O Prophet! When believing women come to thee to take the oath of fealty to thee, that they will not associate in worship any other thing whatever with Allah, that they will not steal, that they will not commit adultery (or fornication), that they will not kill their children, that they will not utter slander, intentionally forging falsehood, and that they will not disobey thee in any just matter,- then do thou receive their fealty, and pray to Allah for the forgiveness (of their sins): for Allah is Oft-Forgiving, Most Merciful.

# 5163

O ye who believe! Turn not (for friendship) to people on whom is the Wrath of Allah, of the Hereafter they are already in despair, just as the Unbelievers are in despair about those (buried) in graves.

# 5164

Whatever is in the heavens and on earth, let it declare the Praises and Glory of Allah: for He is the Exalted in Might, the Wise.

# 5165

O ye who believe! Why say ye that which ye do not?

# 5166

Grievously odious is it in the sight of Allah that ye say that which ye do not.

# 5167

Truly Allah loves those who fight in His Cause in battle array, as if they were a solid cemented structure.

# 5168

And remember, Moses said to his people: "O my people! why do ye vex and insult me, though ye know that I am the messenger of Allah (sent) to you?" Then when they went wrong, Allah let their hearts go wrong. For Allah guides not those who are rebellious transgressors.

# 5169

And remember, Jesus, the son of Mary, said: "O Children of Israel! I am the messenger of Allah (sent) to you, confirming the Law (which came) before me, and giving Glad Tidings of a Messenger to come after me, whose name shall be Ahmad." But when he came to them with Clear Signs, they said, "this is evident sorcery!"

# 5170

Who doth greater wrong than one who invents falsehood against Allah, even as he is being invited to Islam? And Allah guides not those who do wrong.

# 5171

Their intention is to extinguish Allah's Light (by blowing) with their mouths: But Allah will complete (the revelation of) His Light, even though the Unbelievers may detest (it).

# 5172

It is He Who has sent His Messenger with Guidance and the Religion of Truth, that he may proclaim it over all religion, even though the Pagans may detest (it).

# 5173

O ye who believe! Shall I lead you to a bargain that will save you from a grievous Penalty?-

# 5174

That ye believe in Allah and His Messenger, and that ye strive (your utmost) in the Cause of Allah, with your property and your persons: That will be best for you, if ye but knew!

# 5175

He will forgive you your sins, and admit you to Gardens beneath which Rivers flow, and to beautiful mansions in Gardens of Eternity: that is indeed the Supreme Achievement.

# 5176

And another (favour will He bestow,) which ye do love,- help from Allah and a speedy victory. So give the Glad Tidings to the Believers.

# 5177

O ye who believe! Be ye helpers of Allah: As said Jesus the son of Mary to the Disciples, "Who will be my helpers to (the work of) Allah?" Said the disciples, "We are Allah's helpers!" then a portion of the Children of Israel believed, and a portion disbelieved: But We gave power to those who believed, against their enemies, and they became the ones that prevailed.

# 5178

Whatever is in the heavens and on earth, doth declare the Praises and Glory of Allah,- the Sovereign, the Holy One, the Exalted in Might, the Wise.

# 5179

It is He Who has sent amongst the Unlettered a messenger from among themselves, to rehearse to them His Signs, to sanctify them, and to instruct them in Scripture and Wisdom,- although they had been, before, in manifest error;-

# 5180

As well as (to confer all these benefits upon) others of them, who have not already joined them: And He is exalted in Might, Wise.

# 5181

Such is the Bounty of Allah, which He bestows on whom He will: and Allah is the Lord of the highest bounty.

# 5182

The similitude of those who were charged with the (obligations of the) Mosaic Law, but who subsequently failed in those (obligations), is that of a donkey which carries huge tomes (but understands them not). Evil is the similitude of people who falsify the Signs of Allah: and Allah guides not people who do wrong.

# 5183

Say: "O ye that stand on Judaism! If ye think that ye are friends to Allah, to the exclusion of (other) men, then express your desire for Death, if ye are truthful!"

# 5184

But never will they express their desire (for Death), because of the (deeds) their hands have sent on before them! and Allah knows well those that do wrong!

# 5185

Say: "The Death from which ye flee will truly overtake you: then will ye be sent back to the Knower of things secret and open: and He will tell you (the truth of) the things that ye did!"

# 5186

O ye who believe! When the call is proclaimed to prayer on Friday (the Day of Assembly), hasten earnestly to the Remembrance of Allah, and leave off business (and traffic): That is best for you if ye but knew!

# 5187

And when the Prayer is finished, then may ye disperse through the land, and seek of the Bounty of Allah: and celebrate the Praises of Allah often (and without stint): that ye may prosper.

# 5188

But when they see some bargain or some amusement, they disperse headlong to it, and leave thee standing. Say: "The (blessing) from the Presence of Allah is better than any amusement or bargain! and Allah is the Best to provide (for all needs)."

# 5189

When the Hypocrites come to thee, they say, "We bear witness that thou art indeed the Messenger of Allah." Yea, Allah knoweth that thou art indeed His Messenger, and Allah beareth witness that the Hypocrites are indeed liars.

# 5190

They have made their oaths a screen (for their misdeeds): thus they obstruct (men) from the Path of Allah: truly evil are their deeds.

# 5191

That is because they believed, then they rejected Faith: So a seal was set on their hearts: therefore they understand not.

# 5192

When thou lookest at them, their exteriors please thee; and when they speak, thou listenest to their words. They are as (worthless as hollow) pieces of timber propped up, (unable to stand on their own). They think that every cry is against them. They are the enemies; so beware of them. The curse of Allah be on them! How are they deluded (away from the Truth)!

# 5193

And when it is said to them, "Come, the Messenger of Allah will pray for your forgiveness", they turn aside their heads, and thou wouldst see them turning away their faces in arrogance.

# 5194

It is equal to them whether thou pray for their forgiveness or not. Allah will not forgive them. Truly Allah guides not rebellious transgressors.

# 5195

They are the ones who say, "Spend nothing on those who are with Allah's Messenger, to the end that they may disperse (and quit Medina)." But to Allah belong the treasures of the heavens and the earth; but the Hypocrites understand not.

# 5196

They say, "If we return to Medina, surely the more honourable (element) will expel therefrom the meaner." But honour belongs to Allah and His Messenger, and to the Believers; but the Hypocrites know not.

# 5197

O ye who believe! Let not your riches or your children divert you from the remembrance of Allah. If any act thus, the loss is their own.

# 5198

and spend something (in charity) out of the substance which We have bestowed on you, before Death should come to any of you and he should say, "O my Lord! why didst Thou not give me respite for a little while? I should then have given (largely) in charity, and I should have been one of the doers of good".

# 5199

But to no soul will Allah grant respite when the time appointed (for it) has come; and Allah is well acquainted with (all) that ye do.

# 5200

Whatever is in the heavens and on earth, doth declare the Praises and Glory of Allah: to Him belongs dominion, and to Him belongs praise: and He has power over all things.

# 5201

It is He Who has created you; and of you are some that are Unbelievers, and some that are Believers: and Allah sees well all that ye do.

# 5202

He has created the heavens and the earth in just proportions, and has given you shape, and made your shapes beautiful: and to Him is the final Goal.

# 5203

He knows what is in the heavens and on earth; and He knows what ye conceal and what ye reveal: yea, Allah knows well the (secrets) of (all) hearts.

# 5204

Has not the story reached you, of those who rejected Faith aforetime? So they tasted the evil result of their conduct; and they had a grievous Penalty.

# 5205

That was because there came to them messengers with Clear Signs, but they said: "Shall (mere) human beings direct us?" So they rejected (the Message) and turned away. But Allah can do without (them): and Allah is free of all needs, worthy of all praise.

# 5206

The Unbelievers think that they will not be raised up (for Judgment). Say: "Yea, By my Lord, Ye shall surely be raised up: then shall ye be told (the truth) of all that ye did. And that is easy for Allah."

# 5207

Believe, therefore, in Allah and His Messenger, and in the Light which we have sent down. And Allah is well acquainted with all that ye do.

# 5208

The Day that He assembles you (all) for a Day of Assembly,- that will be a Day of mutual loss and gain (among you), and those who believe in Allah and work righteousness,- He will remove from them their ills, and He will admit them to Gardens beneath which Rivers flow, to dwell therein for ever: that will be the Supreme Achievement.

# 5209

But those who reject Faith and treat Our Signs as falsehoods, they will be Companions of the Fire, to dwell therein for aye: and evil is that Goal.

# 5210

No kind of calamity can occur, except by the leave of Allah: and if any one believes in Allah, (Allah) guides his heart (aright): for Allah knows all things.

# 5211

So obey Allah, and obey His Messenger: but if ye turn back, the duty of Our Messenger is but to proclaim (the Message) clearly and openly.

# 5212

Allah! There is no god but He: and on Allah, therefore, let the Believers put their trust.

# 5213

O ye who believe! Truly, among your wives and your children are (some that are) enemies to yourselves: so beware of them! But if ye forgive and overlook, and cover up (their faults), verily Allah is Oft-Forgiving, Most Merciful.

# 5214

Your riches and your children may be but a trial: but in the Presence of Allah, is the highest, Reward.

# 5215

So fear Allah as much as ye can; listen and obey and spend in charity for the benefit of your own soul and those saved from the covetousness of their own souls,- they are the ones that achieve prosperity.

# 5216

If ye loan to Allah, a beautiful loan, He will double it to your (credit), and He will grant you Forgiveness: for Allah is most Ready to appreciate (service), Most Forbearing,-

# 5217

Knower of what is open, Exalted in Might, Full of Wisdom.

# 5218

O Prophet! When ye do divorce women, divorce them at their prescribed periods, and count (accurately), their prescribed periods: And fear Allah your Lord: and turn them not out of their houses, nor shall they (themselves) leave, except in case they are guilty of some open lewdness, those are limits set by Allah: and any who transgresses the limits of Allah, does verily wrong his (own) soul: thou knowest not if perchance Allah will bring about thereafter some new situation.

# 5219

Thus when they fulfil their term appointed, either take them back on equitable terms or part with them on equitable terms; and take for witness two persons from among you, endued with justice, and establish the evidence (as) before Allah. Such is the admonition given to him who believes in Allah and the Last Day. And for those who fear Allah, He (ever) prepares a way out,

# 5220

And He provides for him from (sources) he never could imagine. And if any one puts his trust in Allah, sufficient is (Allah) for him. For Allah will surely accomplish his purpose: verily, for all things has Allah appointed a due proportion.

# 5221

Such of your women as have passed the age of monthly courses, for them the prescribed period, if ye have any doubts, is three months, and for those who have no courses (it is the same): for those who carry (life within their wombs), their period is until they deliver their burdens: and for those who fear Allah, He will make their path easy.

# 5222

That is the Command of Allah, which He has sent down to you: and if any one fears Allah, He will remove his ills, from him, and will enlarge his reward.

# 5223

Let the women live (in 'iddat) in the same style as ye live, according to your means: Annoy them not, so as to restrict them. And if they carry (life in their wombs), then spend (your substance) on them until they deliver their burden: and if they suckle your (offspring), give them their recompense: and take mutual counsel together, according to what is just and reasonable. And if ye find yourselves in difficulties, let another woman suckle (the child) on the (father's) behalf.

# 5224

Let the man of means spend according to his means: and the man whose resources are restricted, let him spend according to what Allah has given him. Allah puts no burden on any person beyond what He has given him. After a difficulty, Allah will soon grant relief.

# 5225

How many populations that insolently opposed the Command of their Lord and of His messengers, did We not then call to account,- to severe account?- and We imposed on them an exemplary Punishment.

# 5226

Then did they taste the evil result of their conduct, and the End of their conduct was Perdition.

# 5227

Allah has prepared for them a severe Punishment (in the Hereafter). Therefore fear Allah, O ye men of understanding - who have believed!- for Allah hath indeed sent down to you a Message,-

# 5228

An Messenger, who rehearses to you the Signs of Allah containing clear explanations, that he may lead forth those who believe and do righteous deeds from the depths of Darkness into Light. And those who believe in Allah and work righteousness, He will admit to Gardens beneath which Rivers flow, to dwell therein for ever: Allah has indeed granted for them a most excellent Provision.

# 5229

Allah is He Who created seven Firmaments and of the earth a similar number. Through the midst of them (all) descends His Command: that ye may know that Allah has power over all things, and that Allah comprehends, all things in (His) Knowledge.

# 5230

O Prophet! Why holdest thou to be forbidden that which Allah has made lawful to thee? Thou seekest to please thy consorts. But Allah is Oft-Forgiving, Most Merciful.

# 5231

Allah has already ordained for you, (O men), the dissolution of your oaths (in some cases): and Allah is your Protector, and He is Full of Knowledge and Wisdom.

# 5232

When the Prophet disclosed a matter in confidence to one of his consorts, and she then divulged it (to another), and Allah made it known to him, he confirmed part thereof and repudiated a part. Then when he told her thereof, she said, "Who told thee this? "He said, "He told me Who knows and is well-acquainted (with all things)."

# 5233

If ye two turn in repentance to Him, your hearts are indeed so inclined; But if ye back up each other against him, truly Allah is his Protector, and Gabriel, and (every) righteous one among those who believe,- and furthermore, the angels - will back (him) up.

# 5234

It may be, if he divorced you (all), that Allah will give him in exchange consorts better than you,- who submit (their wills), who believe, who are devout, who turn to Allah in repentance, who worship (in humility), who travel (for Faith) and fast,- previously married or virgins.

# 5235

O ye who believe! save yourselves and your families from a Fire whose fuel is Men and Stones, over which are (appointed) angels stern (and) severe, who flinch not (from executing) the Commands they receive from Allah, but do (precisely) what they are commanded.

# 5236

(They will say), "O ye Unbelievers! Make no excuses this Day! Ye are being but requited for all that ye did!"

# 5237

O ye who believe! Turn to Allah with sincere repentance: In the hope that your Lord will remove from you your ills and admit you to Gardens beneath which Rivers flow,- the Day that Allah will not permit to be humiliated the Prophet and those who believe with him. Their Light will run forward before them and by their right hands, while they say, "Our Lord! Perfect our Light for us, and grant us Forgiveness: for Thou hast power over all things."

# 5238

O Prophet! Strive hard against the Unbelievers and the Hypocrites, and be firm against them. Their abode is Hell,- an evil refuge (indeed).

# 5239

Allah sets forth, for an example to the Unbelievers, the wife of Noah and the wife of Lut: they were (respectively) under two of our righteous servants, but they were false to their (husbands), and they profited nothing before Allah on their account, but were told: "Enter ye the Fire along with (others) that enter!"

# 5240

And Allah sets forth, as an example to those who believe the wife of Pharaoh: Behold she said: "O my Lord! Build for me, in nearness to Thee, a mansion in the Garden, and save me from Pharaoh and his doings, and save me from those that do wrong";

# 5241

And Mary the daughter of 'Imran, who guarded her chastity; and We breathed into (her body) of Our spirit; and she testified to the truth of the words of her Lord and of His Revelations, and was one of the devout (servants).

# 5242

Blessed be He in Whose hands is Dominion; and He over all things hath Power;-

# 5243

He Who created Death and Life, that He may try which of you is best in deed: and He is the Exalted in Might, Oft-Forgiving;-

# 5244

He Who created the seven heavens one above another: No want of proportion wilt thou see in the Creation of (Allah) Most Gracious. So turn thy vision again: seest thou any flaw?

# 5245

Again turn thy vision a second time: (thy) vision will come back to thee dull and discomfited, in a state worn out.

# 5246

And we have, (from of old), adorned the lowest heaven with Lamps, and We have made such (Lamps) (as) missiles to drive away the Evil Ones, and have prepared for them the Penalty of the Blazing Fire.

# 5247

For those who reject their Lord (and Cherisher) is the Penalty of Hell: and evil is (such), Destination.

# 5248

When they are cast therein, they will hear the (terrible) drawing in of its breath even as it blazes forth,

# 5249

Almost bursting with fury: Every time a Group is cast therein, its Keepers will ask, "Did no Warner come to you?"

# 5250

They will say: "Yes indeed; a Warner did come to us, but we rejected him and said, 'Allah never sent down any (Message): ye are nothing but an egregious delusion!'"

# 5251

They will further say: "Had we but listened or used our intelligence, we should not (now) be among the Companions of the Blazing Fire!"

# 5252

They will then confess their sins: but far will be (Forgiveness) from the Companions of the Blazing Fire!

# 5253

As for those who fear their Lord unseen, for them is Forgiveness and a great Reward.

# 5254

And whether ye hide your word or publish it, He certainly has (full) knowledge, of the secrets of (all) hearts.

# 5255

Should He not know,- He that created? and He is the One that understands the finest mysteries (and) is well-acquainted (with them).

# 5256

It is He Who has made the earth manageable for you, so traverse ye through its tracts and enjoy of the Sustenance which He furnishes: but unto Him is the Resurrection.

# 5257

Do ye feel secure that He Who is in heaven will not cause you to be swallowed up by the earth when it shakes (as in an earthquake)?

# 5258

Or do ye feel secure that He Who is in Heaven will not send against you a violent tornado (with showers of stones), so that ye shall know how (terrible) was My warning?

# 5259

But indeed men before them rejected (My warning): then how (terrible) was My rejection (of them)?

# 5260

Do they not observe the birds above them, spreading their wings and folding them in? None can uphold them except (Allah) Most Gracious: Truly (Allah) Most Gracious: Truly it is He that watches over all things.

# 5261

Nay, who is there that can help you, (even as) an army, besides (Allah) Most Merciful? In nothing but delusion are the Unbelievers.

# 5262

Or who is there that can provide you with Sustenance if He were to withhold His provision? Nay, they obstinately persist in insolent impiety and flight (from the Truth).

# 5263

Is then one who walks headlong, with his face grovelling, better guided,- or one who walks evenly on a Straight Way?

# 5264

Say: "It is He Who has created you (and made you grow), and made for you the faculties of hearing, seeing, feeling and understanding: little thanks it is ye give.

# 5265

Say: "It is He Who has multiplied you through the earth, and to Him shall ye be gathered together."

# 5266

They ask: When will this promise be (fulfilled)? - If ye are telling the truth.

# 5267

Say: "As to the knowledge of the time, it is with Allah alone: I am (sent) only to warn plainly in public."

# 5268

At length, when they see it close at hand, grieved will be the faces of the Unbelievers, and it will be said (to them): "This is (the promise fulfilled), which ye were calling for!"

# 5269

Say: "See ye?- If Allah were to destroy me, and those with me, or if He bestows His Mercy on us,- yet who can deliver the Unbelievers from a grievous Penalty?"

# 5270

Say: "He is (Allah) Most Gracious: We have believed in Him, and on Him have we put our trust: So, soon will ye know which (of us) it is that is in manifest error."

# 5271

Say: "See ye?- If your stream be some morning lost (in the underground earth), who then can supply you with clear-flowing water?"

# 5272

Nun. By the Pen and the (Record) which (men) write,-

# 5273

Thou art not, by the Grace of thy Lord, mad or possessed.

# 5274

Nay, verily for thee is a Reward unfailing:

# 5275

And thou (standest) on an exalted standard of character.

# 5276

Soon wilt thou see, and they will see,

# 5277

Which of you is afflicted with madness.

# 5278

Verily it is thy Lord that knoweth best, which (among men) hath strayed from His Path: and He knoweth best those who receive (true) Guidance.

# 5279

So hearken not to those who deny (the Truth).

# 5280

Their desire is that thou shouldst be pliant: so would they be pliant.

# 5281

Heed not the type of despicable men,- ready with oaths,

# 5282

A slanderer, going about with calumnies,

# 5283

(Habitually) hindering (all) good, transgressing beyond bounds, deep in sin,

# 5284

Violent (and cruel),- with all that, base-born,-

# 5285

Because he possesses wealth and (numerous) sons.

# 5286

When to him are rehearsed Our Signs, "Tales of the ancients", he cries!

# 5287

Soon shall We brand (the beast) on the snout!

# 5288

Verily We have tried them as We tried the People of the Garden, when they resolved to gather the fruits of the (garden) in the morning.

# 5289

But made no reservation, ("If it be Allah's Will").

# 5290

Then there came on the (garden) a visitation from thy Lord, (which swept away) all around, while they were asleep.

# 5291

So the (garden) became, by the morning, like a dark and desolate spot, (whose fruit had been gathered).

# 5292

As the morning broke, they called out, one to another,-

# 5293

"Go ye to your tilth (betimes) in the morning, if ye would gather the fruits."

# 5294

So they departed, conversing in secret low tones, (saying)-

# 5295

"Let not a single indigent person break in upon you into the (garden) this day."

# 5296

And they opened the morning, strong in an (unjust) resolve.

# 5297

But when they saw the (garden), they said: "We have surely lost our way:

# 5298

"Indeed we are shut out (of the fruits of our labour)!"

# 5299

Said one of them, more just (than the rest): "Did I not say to you, 'Why not glorify (Allah)?'"

# 5300

They said: "Glory to our Lord! Verily we have been doing wrong!"

# 5301

Then they turned, one against another, in reproach.

# 5302

They said: "Alas for us! We have indeed transgressed!

# 5303

"It may be that our Lord will give us in exchange a better (garden) than this: for we do turn to Him (in repentance)!"

# 5304

Such is the Punishment (in this life); but greater is the Punishment in the Hereafter,- if only they knew!

# 5305

Verily, for the Righteous, are Gardens of Delight, in the Presence of their Lord.

# 5306

Shall We then treat the People of Faith like the People of Sin?

# 5307

What is the matter with you? How judge ye?

# 5308

Or have ye a book through which ye learn-

# 5309

That ye shall have, through it whatever ye choose?

# 5310

Or have ye Covenants with Us to oath, reaching to the Day of Judgment, (providing) that ye shall have whatever ye shall demand?

# 5311

Ask thou of them, which of them will stand surety for that!

# 5312

Or have they some "Partners" (in Allahhead)? Then let them produce their "partners", if they are truthful!

# 5313

The Day that the shin shall be laid bare, and they shall be summoned to bow in adoration, but they shall not be able,-

# 5314

Their eyes will be cast down,- ignominy will cover them; seeing that they had been summoned aforetime to bow in adoration, while they were whole, (and had refused).

# 5315

Then leave Me alone with such as reject this Message: by degrees shall We punish them from directions they perceive not.

# 5316

A (long) respite will I grant them: truly powerful is My Plan.

# 5317

Or is it that thou dost ask them for a reward, so that they are burdened with a load of debt?-

# 5318

Or that the Unseen is in their hands, so that they can write it down?

# 5319

So wait with patience for the Command of thy Lord, and be not like the Companion of the Fish,- when he cried out in agony.

# 5320

Had not Grace from his Lord reached him, he would indeed have been cast off on the naked shore, in disgrace.

# 5321

Thus did his Lord choose him and make him of the Company of the Righteous.

# 5322

And the Unbelievers would almost trip thee up with their eyes when they hear the Message; and they say: "Surely he is possessed!"

# 5323

But it is nothing less than a Message to all the worlds.

# 5324

The Sure Reality!

# 5325

What is the Sure Reality?

# 5326

And what will make thee realise what the Sure Reality is?

# 5327

The Thamud and the 'Ad People (branded) as false the Stunning Calamity!

# 5328

But the Thamud,- they were destroyed by a terrible Storm of thunder and lightning!

# 5329

And the 'Ad, they were destroyed by a furious Wind, exceedingly violent;

# 5330

He made it rage against them seven nights and eight days in succession: so that thou couldst see the (whole) people lying prostrate in its (path), as they had been roots of hollow palm-trees tumbled down!

# 5331

Then seest thou any of them left surviving?

# 5332

And Pharaoh, and those before him, and the Cities Overthrown, committed habitual Sin.

# 5333

And disobeyed (each) the messenger of their Lord; so He punished them with an abundant Penalty.

# 5334

We, when the water (of Noah's Flood) overflowed beyond its limits, carried you (mankind), in the floating (Ark),

# 5335

That We might make it a Message unto you, and that ears (that should hear the tale and) retain its memory should bear its (lessons) in remembrance.

# 5336

Then, when one blast is sounded on the Trumpet,

# 5337

And the earth is moved, and its mountains, and they are crushed to powder at one stroke,-

# 5338

On that Day shall the (Great) Event come to pass.

# 5339

And the sky will be rent asunder, for it will that Day be flimsy,

# 5340

And the angels will be on its sides, and eight will, that Day, bear the Throne of thy Lord above them.

# 5341

That Day shall ye be brought to Judgment: not an act of yours that ye hide will be hidden.

# 5342

Then he that will be given his Record in his right hand will say: "Ah here! Read ye my Record!

# 5343

"I did really understand that my Account would (One Day) reach me!"

# 5344

And he will be in a life of Bliss,

# 5345

In a Garden on high,

# 5346

The Fruits whereof (will hang in bunches) low and near.

# 5347

"Eat ye and drink ye, with full satisfaction; because of the (good) that ye sent before you, in the days that are gone!"

# 5348

And he that will be given his Record in his left hand, will say: "Ah! Would that my Record had not been given to me!

# 5349

"And that I had never realised how my account (stood)!

# 5350

"Ah! Would that (Death) had made an end of me!

# 5351

"Of no profit to me has been my wealth!

# 5352

"My power has perished from me!"...

# 5353

(The stern command will say): "Seize ye him, and bind ye him,

# 5354

"And burn ye him in the Blazing Fire.

# 5355

"Further, make him march in a chain, whereof the length is seventy cubits!

# 5356

"This was he that would not believe in Allah Most High.

# 5357

"And would not encourage the feeding of the indigent!

# 5358

"So no friend hath he here this Day.

# 5359

"Nor hath he any food except the corruption from the washing of wounds,

# 5360

"Which none do eat but those in sin."

# 5361

So I do call to witness what ye see,

# 5362

And what ye see not,

# 5363

That this is verily the word of an honoured messenger;

# 5364

It is not the word of a poet: little it is ye believe!

# 5365

Nor is it the word of a soothsayer: little admonition it is ye receive.

# 5366

(This is) a Message sent down from the Lord of the Worlds.

# 5367

And if the messenger were to invent any sayings in Our name,

# 5368

We should certainly seize him by his right hand,

# 5369

And We should certainly then cut off the artery of his heart:

# 5370

Nor could any of you withhold him (from Our wrath).

# 5371

But verily this is a Message for the Allah-fearing.

# 5372

And We certainly know that there are amongst you those that reject (it).

# 5373

But truly (Revelation) is a cause of sorrow for the Unbelievers.

# 5374

But verily it is Truth of assured certainty.

# 5375

So glorify the name of thy Lord Most High.

# 5376

A questioner asked about a Penalty to befall-

# 5377

The Unbelievers, the which there is none to ward off,-

# 5378

(A Penalty) from Allah, Lord of the Ways of Ascent.

# 5379

The angels and the spirit ascend unto him in a Day the measure whereof is (as) fifty thousand years:

# 5380

Therefore do thou hold Patience,- a Patience of beautiful (contentment).

# 5381

They see the (Day) indeed as a far-off (event):

# 5382

But We see it (quite) near.

# 5383

The Day that the sky will be like molten brass,

# 5384

And the mountains will be like wool,

# 5385

And no friend will ask after a friend,

# 5386

Though they will be put in sight of each other,- the sinner's desire will be: Would that he could redeem himself from the Penalty of that Day by (sacrificing) his children,

# 5387

His wife and his brother,

# 5388

His kindred who sheltered him,

# 5389

And all, all that is on earth,- so it could deliver him:

# 5390

By no means! for it would be the Fire of Hell!-

# 5391

Plucking out (his being) right to the skull!-

# 5392

Inviting (all) such as turn their backs and turn away their faces (from the Right).

# 5393

And collect (wealth) and hide it (from use)!

# 5394

Truly man was created very impatient;-

# 5395

Fretful when evil touches him;

# 5396

And niggardly when good reaches him;-

# 5397

Not so those devoted to Prayer;-

# 5398

Those who remain steadfast to their prayer;

# 5399

And those in whose wealth is a recognised right.

# 5400

For the (needy) who asks and him who is prevented (for some reason from asking);

# 5401

And those who hold to the truth of the Day of Judgment;

# 5402

And those who fear the displeasure of their Lord,-

# 5403

For their Lord's displeasure is the opposite of Peace and Tranquillity;-

# 5404

And those who guard their chastity,

# 5405

Except with their wives and the (captives) whom their right hands possess,- for (then) they are not to be blamed,

# 5406

But those who trespass beyond this are transgressors;-

# 5407

And those who respect their trusts and covenants;

# 5408

And those who stand firm in their testimonies;

# 5409

And those who guard (the sacredness) of their worship;-

# 5410

Such will be the honoured ones in the Gardens (of Bliss).

# 5411

Now what is the matter with the Unbelievers that they rush madly before thee-

# 5412

From the right and from the left, in crowds?

# 5413

Does every man of them long to enter the Garden of Bliss?

# 5414

By no means! For We have created them out of the (base matter) they know!

# 5415

Now I do call to witness the Lord of all points in the East and the West that We can certainly-

# 5416

Substitute for them better (men) than they; And We are not to be defeated (in Our Plan).

# 5417

So leave them to plunge in vain talk and play about, until they encounter that Day of theirs which they have been promised!-

# 5418

The Day whereon they will issue from their sepulchres in sudden haste as if they were rushing to a goal-post (fixed for them),-

# 5419

Their eyes lowered in dejection,- ignominy covering them (all over)! such is the Day the which they are promised!

# 5420

We sent Noah to his People (with the Command): "Do thou warn thy People before there comes to them a grievous Penalty."

# 5421

He said: "O my People! I am to you a Warner, clear and open:

# 5422

"That ye should worship Allah, fear Him and obey me:

# 5423

"So He may forgive you your sins and give you respite for a stated Term: for when the Term given by Allah is accomplished, it cannot be put forward: if ye only knew."

# 5424

He said: "O my Lord! I have called to my People night and day:

# 5425

"But my call only increases (their) flight (from the Right).

# 5426

"And every time I have called to them, that Thou mightest forgive them, they have (only) thrust their fingers into their ears, covered themselves up with their garments, grown obstinate, and given themselves up to arrogance.

# 5427

"So I have called to them aloud;

# 5428

"Further I have spoken to them in public and secretly in private,

# 5429

"Saying, 'Ask forgiveness from your Lord; for He is Oft-Forgiving;

# 5430

"'He will send rain to you in abundance;

# 5431

"'Give you increase in wealth and sons; and bestow on you gardens and bestow on you rivers (of flowing water).

# 5432

"'What is the matter with you, that ye place not your hope for kindness and long-suffering in Allah,-

# 5433

"'Seeing that it is He that has created you in diverse stages?

# 5434

"'See ye not how Allah has created the seven heavens one above another,

# 5435

"'And made the moon a light in their midst, and made the sun as a (Glorious) Lamp?

# 5436

"'And Allah has produced you from the earth growing (gradually),

# 5437

"'And in the End He will return you into the (earth), and raise you forth (again at the Resurrection)?

# 5438

"'And Allah has made the earth for you as a carpet (spread out),

# 5439

"'That ye may go about therein, in spacious roads.'"

# 5440

Noah said: "O my Lord! They have disobeyed me, but they follow (men) whose wealth and children give them no increase but only Loss.

# 5441

"And they have devised a tremendous Plot.

# 5442

"And they have said (to each other), 'Abandon not your gods: Abandon neither Wadd nor Suwa', neither Yaguth nor Ya'uq, nor Nasr';-

# 5443

"They have already misled many; and grant Thou no increase to the wrong-doers but in straying (from their mark)."

# 5444

Because of their sins they were drowned (in the flood), and were made to enter the Fire (of Punishment): and they found- in lieu of Allah- none to help them.

# 5445

And Noah, said: "O my Lord! Leave not of the Unbelievers, a single one on earth!

# 5446

"For, if Thou dost leave (any of) them, they will but mislead Thy devotees, and they will breed none but wicked ungrateful ones.

# 5447

"O my Lord! Forgive me, my parents, all who enter my house in Faith, and (all) believing men and believing women: and to the wrong-doers grant Thou no increase but in perdition!"

# 5448

Say: It has been revealed to me that a company of Jinns listened (to the Qur'an). They said, 'We have really heard a wonderful Recital!

# 5449

'It gives guidance to the Right, and we have believed therein: we shall not join (in worship) any (gods) with our Lord.

# 5450

'And Exalted is the Majesty of our Lord: He has taken neither a wife nor a son.

# 5451

'There were some foolish ones among us, who used to utter extravagant lies against Allah;

# 5452

'But we do think that no man or spirit should say aught that untrue against Allah.

# 5453

'True, there were persons among mankind who took shelter with persons among the Jinns, but they increased them in folly.

# 5454

'And they (came to) think as ye thought, that Allah would not raise up any one (to Judgment).

# 5455

'And we pried into the secrets of heaven; but we found it filled with stern guards and flaming fires.

# 5456

'We used, indeed, to sit there in (hidden) stations, to (steal) a hearing; but any who listen now will find a flaming fire watching him in ambush.

# 5457

'And we understand not whether ill is intended to those on earth, or whether their Lord (really) intends to guide them to right conduct.

# 5458

'There are among us some that are righteous, and some the contrary: we follow divergent paths.

# 5459

'But we think that we can by no means frustrate Allah throughout the earth, nor can we frustrate Him by flight.

# 5460

'And as for us, since we have listened to the Guidance, we have accepted it: and any who believes in his Lord has no fear, either of a short (account) or of any injustice.

# 5461

'Amongst us are some that submit their wills (to Allah), and some that swerve from justice. Now those who submit their wills - they have sought out (the path) of right conduct:

# 5462

'But those who swerve,- they are (but) fuel for Hell-fire'-

# 5463

(And Allah's Message is): "If they (the Pagans) had (only) remained on the (right) Way, We should certainly have bestowed on them Rain in abundance.

# 5464

"That We might try them by that (means). But if any turns away from the remembrance of his Lord, He will cause him to undergo a severe Penalty.

# 5465

"And the places of worship are for Allah (alone): So invoke not any one along with Allah;

# 5466

"Yet when the Devotee of Allah stands forth to invoke Him, they just make round him a dense crowd."

# 5467

Say: "I do no more than invoke my Lord, and I join not with Him any (false god)."

# 5468

Say: "It is not in my power to cause you harm, or to bring you to right conduct."

# 5469

Say: "No one can deliver me from Allah (If I were to disobey Him), nor should I find refuge except in Him,

# 5470

"Unless I proclaim what I receive from Allah and His Messages: for any that disobey Allah and His Messenger,- for them is Hell: they shall dwell therein for ever."

# 5471

At length, when they see (with their own eyes) that which they are promised,- then will they know who it is that is weakest in (his) helper and least important in point of numbers.

# 5472

Say: "I know not whether the (Punishment) which ye are promised is near, or whether my Lord will appoint for it a distant term.

# 5473

"He (alone) knows the Unseen, nor does He make any one acquainted with His Mysteries,-

# 5474

"Except a messenger whom He has chosen: and then He makes a band of watchers march before him and behind him,

# 5475

"That He may know that they have (truly) brought and delivered the Messages of their Lord: and He surrounds (all the mysteries) that are with them, and takes account of every single thing."

# 5476

O thou folded in garments!

# 5477

Stand (to prayer) by night, but not all night,-

# 5478

Half of it,- or a little less,

# 5479

Or a little more; and recite the Qur'an in slow, measured rhythmic tones.

# 5480

Soon shall We send down to thee a weighty Message.

# 5481

Truly the rising by night is most potent for governing (the soul), and most suitable for (framing) the Word (of Prayer and Praise).

# 5482

True, there is for thee by day prolonged occupation with ordinary duties:

# 5483

But keep in remembrance the name of thy Lord and devote thyself to Him whole-heartedly.

# 5484

(He is) Lord of the East and the West: there is no god but He: take Him therefore for (thy) Disposer of Affairs.

# 5485

And have patience with what they say, and leave them with noble (dignity).

# 5486

And leave Me (alone to deal with) those in possession of the good things of life, who (yet) deny the Truth; and bear with them for a little while.

# 5487

With Us are Fetters (to bind them), and a Fire (to burn them),

# 5488

And a Food that chokes, and a Penalty Grievous.

# 5489

One Day the earth and the mountains will be in violent commotion. And the mountains will be as a heap of sand poured out and flowing down.

# 5490

We have sent to you, (O men!) a messenger, to be a witness concerning you, even as We sent a messenger to Pharaoh.

# 5491

But Pharaoh disobeyed the messenger; so We seized him with a heavy Punishment.

# 5492

Then how shall ye, if ye deny (Allah), guard yourselves against a Day that will make children hoary-headed?-

# 5493

Whereon the sky will be cleft asunder? His Promise needs must be accomplished.

# 5494

Verily this is an Admonition: therefore, whoso will, let him take a (straight) path to his Lord!

# 5495

Thy Lord doth know that thou standest forth (to prayer) nigh two-thirds of the night, or half the night, or a third of the night, and so doth a party of those with thee. But Allah doth appoint night and day in due measure He knoweth that ye are unable to keep count thereof. So He hath turned to you (in mercy): read ye, therefore, of the Qur'an as much as may be easy for you. He knoweth that there may be (some) among you in ill-health; others travelling through the land, seeking of Allah's bounty; yet others fighting in Allah's Cause, read ye, therefore, as much of the Qur'an as may be easy (for you); and establish regular Prayer and give regular Charity; and loan to Allah a Beautiful Loan. And whatever good ye send forth for your souls ye shall find it in Allah's Presence,- yea, better and greater, in Reward and seek ye the Grace of Allah: for Allah is Oft-Forgiving, Most Merciful.

# 5496

O thou wrapped up (in the mantle)!

# 5497

Arise and deliver thy warning!

# 5498

And thy Lord do thou magnify!

# 5499

And thy garments keep free from stain!

# 5500

And all abomination shun!

# 5501

Nor expect, in giving, any increase (for thyself)!

# 5502

But, for thy Lord's (Cause), be patient and constant!

# 5503

Finally, when the Trumpet is sounded,

# 5504

That will be- that Day - a Day of Distress,-

# 5505

Far from easy for those without Faith.

# 5506

Leave Me alone, (to deal) with the (creature) whom I created (bare and) alone!-

# 5507

To whom I granted resources in abundance,

# 5508

And sons to be by his side!-

# 5509

To whom I made (life) smooth and comfortable!

# 5510

Yet is he greedy-that I should add (yet more);-

# 5511

By no means! For to Our Signs he has been refractory!

# 5512

Soon will I visit him with a mount of calamities!

# 5513

For he thought and he plotted;-

# 5514

And woe to him! How he plotted!-

# 5515

Yea, Woe to him; How he plotted!-

# 5516

Then he looked round;

# 5517

Then he frowned and he scowled;

# 5518

Then he turned back and was haughty;

# 5519

Then said he: "This is nothing but magic, derived from of old;

# 5520

"This is nothing but the word of a mortal!"

# 5521

Soon will I cast him into Hell-Fire!

# 5522

And what will explain to thee what Hell-Fire is?

# 5523

Naught doth it permit to endure, and naught doth it leave alone!-

# 5524

Darkening and changing the colour of man!

# 5525

Over it are Nineteen.

# 5526

And We have set none but angels as Guardians of the Fire; and We have fixed their number only as a trial for Unbelievers,- in order that the People of the Book may arrive at certainty, and the Believers may increase in Faith,- and that no doubts may be left for the People of the Book and the Believers, and that those in whose hearts is a disease and the Unbelievers may say, "What symbol doth Allah intend by this?" Thus doth Allah leave to stray whom He pleaseth, and guide whom He pleaseth: and none can know the forces of thy Lord, except He and this is no other than a warning to mankind.

# 5527

Nay, verily: By the Moon,

# 5528

And by the Night as it retreateth,

# 5529

And by the Dawn as it shineth forth,-

# 5530

This is but one of the mighty (portents),

# 5531

A warning to mankind,-

# 5532

To any of you that chooses to press forward, or to follow behind;-

# 5533

Every soul will be (held) in pledge for its deeds.

# 5534

Except the Companions of the Right Hand.

# 5535

(They will be) in Gardens (of Delight): they will question each other,

# 5536

And (ask) of the Sinners:

# 5537

"What led you into Hell Fire?"

# 5538

They will say: "We were not of those who prayed;

# 5539

"Nor were we of those who fed the indigent;

# 5540

"But we used to talk vanities with vain talkers;

# 5541

"And we used to deny the Day of Judgment,

# 5542

"Until there came to us (the Hour) that is certain."

# 5543

Then will no intercession of (any) intercessors profit them.

# 5544

Then what is the matter with them that they turn away from admonition?-

# 5545

As if they were affrighted asses,

# 5546

Fleeing from a lion!

# 5547

Forsooth, each one of them wants to be given scrolls (of revelation) spread out!

# 5548

By no means! But they fear not the Hereafter,

# 5549

Nay, this surely is an admonition:

# 5550

Let any who will, keep it in remembrance!

# 5551

But none will keep it in remembrance except as Allah wills: He is the Lord of Righteousness, and the Lord of Forgiveness.

# 5552

I do call to witness the Resurrection Day;

# 5553

And I do call to witness the self-reproaching spirit: (Eschew Evil).

# 5554

Does man think that We cannot assemble his bones?

# 5555

Nay, We are able to put together in perfect order the very tips of his fingers.

# 5556

But man wishes to do wrong (even) in the time in front of him.

# 5557

He questions: "When is the Day of Resurrection?"

# 5558

At length, when the sight is dazed,

# 5559

And the moon is buried in darkness.

# 5560

And the sun and moon are joined together,-

# 5561

That Day will Man say: "Where is the refuge?"

# 5562

By no means! No place of safety!

# 5563

Before thy Lord (alone), that Day will be the place of rest.

# 5564

That Day will Man be told (all) that he put forward, and all that he put back.

# 5565

Nay, man will be evidence against himself,

# 5566

Even though he were to put up his excuses.

# 5567

Move not thy tongue concerning the (Qur'an) to make haste therewith.

# 5568

It is for Us to collect it and to promulgate it:

# 5569

But when We have promulgated it, follow thou its recital (as promulgated):

# 5570

Nay more, it is for Us to explain it (and make it clear):

# 5571

Nay, (ye men!) but ye love the fleeting life,

# 5572

And leave alone the Hereafter.

# 5573

Some faces, that Day, will beam (in brightness and beauty);-

# 5574

Looking towards their Lord;

# 5575

And some faces, that Day, will be sad and dismal,

# 5576

In the thought that some back-breaking calamity was about to be inflicted on them;

# 5577

Yea, when (the soul) reaches to the collar-bone (in its exit),

# 5578

And there will be a cry, "Who is a magician (to restore him)?"

# 5579

And he will conclude that it was (the Time) of Parting;

# 5580

And one leg will be joined with another:

# 5581

That Day the Drive will be (all) to thy Lord!

# 5582

So he gave nothing in charity, nor did he pray!-

# 5583

But on the contrary, he rejected Truth and turned away!

# 5584

Then did he stalk to his family in full conceit!

# 5585

Woe to thee, (O men!), yea, woe!

# 5586

Again, Woe to thee, (O men!), yea, woe!

# 5587

Does man think that he will be left uncontrolled, (without purpose)?

# 5588

Was he not a drop of sperm emitted (in lowly form)?

# 5589

Then did he become a leech-like clot; then did (Allah) make and fashion (him) in due proportion.

# 5590

And of him He made two sexes, male and female.

# 5591

Has not He, (the same), the power to give life to the dead?

# 5592

Has there not been over Man a long period of Time, when he was nothing - (not even) mentioned?

# 5593

Verily We created Man from a drop of mingled sperm, in order to try him: So We gave him (the gifts), of Hearing and Sight.

# 5594

We showed him the Way: whether he be grateful or ungrateful (rests on his will).

# 5595

For the Rejecters we have prepared chains, yokes, and a blazing Fire.

# 5596

As to the Righteous, they shall drink of a Cup (of Wine) mixed with Kafur,-

# 5597

A Fountain where the Devotees of Allah do drink, making it flow in unstinted abundance.

# 5598

They perform (their) vows, and they fear a Day whose evil flies far and wide.

# 5599

And they feed, for the love of Allah, the indigent, the orphan, and the captive,-

# 5600

(Saying),"We feed you for the sake of Allah alone: no reward do we desire from you, nor thanks.

# 5601

"We only fear a Day of distressful Wrath from the side of our Lord."

# 5602

But Allah will deliver them from the evil of that Day, and will shed over them a Light of Beauty and (blissful) Joy.

# 5603

And because they were patient and constant, He will reward them with a Garden and (garments of) silk.

# 5604

Reclining in the (Garden) on raised thrones, they will see there neither the sun's (excessive heat) nor (the moon's) excessive cold.

# 5605

And the shades of the (Garden) will come low over them, and the bunches (of fruit), there, will hang low in humility.

# 5606

And amongst them will be passed round vessels of silver and goblets of crystal,-

# 5607

Crystal-clear, made of silver: they will determine the measure thereof (according to their wishes).

# 5608

And they will be given to drink there of a Cup (of Wine) mixed with Zanjabil,-

# 5609

A fountain there, called Salsabil.

# 5610

And round about them will (serve) youths of perpetual (freshness): If thou seest them, thou wouldst think them scattered Pearls.

# 5611

And when thou lookest, it is there thou wilt see a Bliss and a Realm Magnificent.

# 5612

Upon them will be green Garments of fine silk and heavy brocade, and they will be adorned with Bracelets of silver; and their Lord will give to them to drink of a Wine Pure and Holy.

# 5613

"Verily this is a Reward for you, and your Endeavour is accepted and recognised."

# 5614

It is We Who have sent down the Qur'an to thee by stages.

# 5615

Therefore be patient with constancy to the Command of thy Lord, and hearken not to the sinner or the ingrate among them.

# 5616

And celebrate the name of thy Lord morning and evening,

# 5617

And part of the night, prostrate thyself to Him; and glorify Him a long night through.

# 5618

As to these, they love the fleeting life, and put away behind them a Day (that will be) hard.

# 5619

It is We Who created them, and We have made their joints strong; but, when We will, We can substitute the like of them by a complete change.

# 5620

This is an admonition: Whosoever will, let him take a (straight) Path to his Lord.

# 5621

But ye will not, except as Allah wills; for Allah is full of Knowledge and Wisdom.

# 5622

He will admit to His Mercy whom He will; But the wrong-doers,- for them has He prepared a grievous Penalty.

# 5623

By the (Winds) sent forth one after another (to man's profit);

# 5624

Which then blow violently in tempestuous Gusts,

# 5625

And scatter (things) far and wide;

# 5626

Then separate them, one from another,

# 5627

Then spread abroad a Message,

# 5628

Whether of Justification or of Warning;-

# 5629

Assuredly, what ye are promised must come to pass.

# 5630

Then when the stars become dim;

# 5631

When the heaven is cleft asunder;

# 5632

When the mountains are scattered (to the winds) as dust;

# 5633

And when the messengers are (all) appointed a time (to collect);-

# 5634

For what Day are these (portents) deferred?

# 5635

For the Day of Sorting out.

# 5636

And what will explain to thee what is the Day of Sorting out?

# 5637

Ah woe, that Day, to the Rejecters of Truth!

# 5638

Did We not destroy the men of old (for their evil)?

# 5639

So shall We make later (generations) follow them.

# 5640

Thus do We deal with men of sin.

# 5641

Ah woe, that Day, to the Rejecters of Truth!

# 5642

Have We not created you from a fluid (held) despicable?-

# 5643

The which We placed in a place of rest, firmly fixed,

# 5644

For a period (of gestation), determined (according to need)?

# 5645

For We do determine (according to need); for We are the best to determine (things).

# 5646

Ah woe, that Day! to the Rejecters of Truth!

# 5647

Have We not made the earth (as a place) to draw together.

# 5648

The living and the dead,

# 5649

And made therein mountains standing firm, lofty (in stature); and provided for you water sweet (and wholesome)?

# 5650

Ah woe, that Day, to the Rejecters of Truth!

# 5651

(It will be said:) "Depart ye to that which ye used to reject as false!

# 5652

"Depart ye to a Shadow (of smoke ascending) in three columns,

# 5653

"(Which yields) no shade of coolness, and is of no use against the fierce Blaze.

# 5654

"Indeed it throws about sparks (huge) as Forts,

# 5655

"As if there were (a string of) yellow camels (marching swiftly)."

# 5656

Ah woe, that Day, to the Rejecters of Truth!

# 5657

That will be a Day when they shall not be able to speak.

# 5658

Nor will it be open to them to put forth pleas.

# 5659

Ah woe, that Day, to the Rejecters of Truth!

# 5660

That will be a Day of Sorting out! We shall gather you together and those before (you)!

# 5661

Now, if ye have a trick (or plot), use it against Me!

# 5662

Ah woe, that Day, to the Rejecters of Truth!

# 5663

As to the Righteous, they shall be amidst (cool) shades and springs (of water).

# 5664

And (they shall have) fruits,- all they desire.

# 5665

"Eat ye and drink ye to your heart's content: for that ye worked (Righteousness).

# 5666

Thus do We certainly reward the Doers of Good.

# 5667

Ah woe, that Day, to the Rejecters of Truth!

# 5668

(O ye unjust!) Eat ye and enjoy yourselves (but) a little while, for that ye are Sinners.

# 5669

Ah woe, that Day, to the Rejecters of Truth!

# 5670

And when it is said to them, "Prostrate yourselves!" they do not so.

# 5671

Ah woe, that Day, to the Rejecters of Truth!

# 5672

Then what Message, after that, will they believe in?

# 5673

Concerning what are they disputing?

# 5674

Concerning the Great News,

# 5675

About which they cannot agree.

# 5676

Verily, they shall soon (come to) know!

# 5677

Verily, verily they shall soon (come to) know!

# 5678

Have We not made the earth as a wide expanse,

# 5679

And the mountains as pegs?

# 5680

And (have We not) created you in pairs,

# 5681

And made your sleep for rest,

# 5682

And made the night as a covering,

# 5683

And made the day as a means of subsistence?

# 5684

And (have We not) built over you the seven firmaments,

# 5685

And placed (therein) a Light of Splendour?

# 5686

And do We not send down from the clouds water in abundance,

# 5687

That We may produce therewith corn and vegetables,

# 5688

And gardens of luxurious growth?

# 5689

Verily the Day of Sorting out is a thing appointed,

# 5690

The Day that the Trumpet shall be sounded, and ye shall come forth in crowds;

# 5691

And the heavens shall be opened as if there were doors,

# 5692

And the mountains shall vanish, as if they were a mirage.

# 5693

Truly Hell is as a place of ambush,

# 5694

For the transgressors a place of destination:

# 5695

They will dwell therein for ages.

# 5696

Nothing cool shall they taste therein, nor any drink,

# 5697

Save a boiling fluid and a fluid, dark, murky, intensely cold,

# 5698

A fitting recompense (for them).

# 5699

For that they used not to fear any account (for their deeds),

# 5700

But they (impudently) treated Our Signs as false.

# 5701

And all things have We preserved on record.

# 5702

"So taste ye (the fruits of your deeds); for no increase shall We grant you, except in Punishment."

# 5703

Verily for the Righteous there will be a fulfilment of (the heart's) desires;

# 5704

Gardens enclosed, and grapevines;

# 5705

And voluptuous women of equal age;

# 5706

And a cup full (to the brim).

# 5707

No vanity shall they hear therein, nor Untruth:-

# 5708

Recompense from thy Lord, a gift, (amply) sufficient,

# 5709

(From) the Lord of the heavens and the earth, and all between, (Allah) Most Gracious: None shall have power to argue with Him.

# 5710

The Day that the Spirit and the angels will stand forth in ranks, none shall speak except any who is permitted by (Allah) Most Gracious, and He will say what is right.

# 5711

That Day will be the sure Reality: Therefore, whoso will, let him take a (straight) return to his Lord!

# 5712

Verily, We have warned you of a Penalty near, the Day when man will see (the deeds) which his hands have sent forth, and the Unbeliever will say, "Woe unto me! Would that I were (metre) dust!"

# 5713

By the (angels) who tear out (the souls of the wicked) with violence;

# 5714

By those who gently draw out (the souls of the blessed);

# 5715

And by those who glide along (on errands of mercy),

# 5716

Then press forward as in a race,

# 5717

Then arrange to do (the Commands of their Lord),

# 5718

One Day everything that can be in commotion will be in violent commotion,

# 5719

Followed by oft-repeated (commotions):

# 5720

Hearts that Day will be in agitation;

# 5721

Cast down will be (their owners') eyes.

# 5722

They say (now): "What! shall we indeed be returned to (our) former state?

# 5723

"What! - when we shall have become rotten bones?"

# 5724

They say: "It would, in that case, be a return with loss!"

# 5725

But verily, it will be but a single (Compelling) Cry,

# 5726

When, behold, they will be in the (full) awakening (to Judgment).

# 5727

Has the story of Moses reached thee?

# 5728

Behold, thy Lord did call to him in the sacred valley of Tuwa:-

# 5729

"Go thou to Pharaoh for he has indeed transgressed all bounds:

# 5730

"And say to him, 'Wouldst thou that thou shouldst be purified (from sin)?-

# 5731

"'And that I guide thee to thy Lord, so thou shouldst fear Him?'"

# 5732

Then did (Moses) show him the Great Sign.

# 5733

But (Pharaoh) rejected it and disobeyed (guidance);

# 5734

Further, he turned his back, striving hard (against Allah).

# 5735

Then he collected (his men) and made a proclamation,

# 5736

Saying, "I am your Lord, Most High".

# 5737

But Allah did punish him, (and made an) example of him, - in the Hereafter, as in this life.

# 5738

Verily in this is an instructive warning for whosoever feareth (Allah).

# 5739

What! Are ye the more difficult to create or the heaven (above)? (Allah) hath constructed it:

# 5740

On high hath He raised its canopy, and He hath given it order and perfection.

# 5741

Its night doth He endow with darkness, and its splendour doth He bring out (with light).

# 5742

And the earth, moreover, hath He extended (to a wide expanse);

# 5743

He draweth out therefrom its moisture and its pasture;

# 5744

And the mountains hath He firmly fixed;-

# 5745

For use and convenience to you and your cattle.

# 5746

Therefore, when there comes the great, overwhelming (Event),-

# 5747

The Day when man shall remember (all) that he strove for,

# 5748

And Hell-Fire shall be placed in full view for (all) to see,-

# 5749

Then, for such as had transgressed all bounds,

# 5750

And had preferred the life of this world,

# 5751

The Abode will be Hell-Fire;

# 5752

And for such as had entertained the fear of standing before their Lord's (tribunal) and had restrained (their) soul from lower desires,

# 5753

Their abode will be the Garden.

# 5754

They ask thee about the Hour,-'When will be its appointed time?

# 5755

Wherein art thou (concerned) with the declaration thereof?

# 5756

With thy Lord in the Limit fixed therefor.

# 5757

Thou art but a Warner for such as fear it.

# 5758

The Day they see it, (It will be) as if they had tarried but a single evening, or (at most till) the following morn!

# 5759

(The Prophet) frowned and turned away,

# 5760

Because there came to him the blind man (interrupting).

# 5761

But what could tell thee but that perchance he might grow (in spiritual understanding)?-

# 5762

Or that he might receive admonition, and the teaching might profit him?

# 5763

As to one who regards Himself as self-sufficient,

# 5764

To him dost thou attend;

# 5765

Though it is no blame to thee if he grow not (in spiritual understanding).

# 5766

But as to him who came to thee striving earnestly,

# 5767

And with fear (in his heart),

# 5768

Of him wast thou unmindful.

# 5769

By no means (should it be so)! For it is indeed a Message of instruction:

# 5770

Therefore let whoso will, keep it in remembrance.

# 5771

(It is) in Books held (greatly) in honour,

# 5772

Exalted (in dignity), kept pure and holy,

# 5773

(Written) by the hands of scribes-

# 5774

Honourable and Pious and Just.

# 5775

Woe to man! What hath made him reject Allah;

# 5776

From what stuff hath He created him?

# 5777

From a sperm-drop: He hath created him, and then mouldeth him in due proportions;

# 5778

Then doth He make His path smooth for him;

# 5779

Then He causeth him to die, and putteth him in his grave;

# 5780

Then, when it is His Will, He will raise him up (again).

# 5781

By no means hath he fulfilled what Allah hath commanded him.

# 5782

Then let man look at his food, (and how We provide it):

# 5783

For that We pour forth water in abundance,

# 5784

And We split the earth in fragments,

# 5785

And produce therein corn,

# 5786

And Grapes and nutritious plants,

# 5787

And Olives and Dates,

# 5788

And enclosed Gardens, dense with lofty trees,

# 5789

And fruits and fodder,-

# 5790

For use and convenience to you and your cattle.

# 5791

At length, when there comes the Deafening Noise,-

# 5792

That Day shall a man flee from his own brother,

# 5793

And from his mother and his father,

# 5794

And from his wife and his children.

# 5795

Each one of them, that Day, will have enough concern (of his own) to make him indifferent to the others.

# 5796

Some faces that Day will be beaming,

# 5797

Laughing, rejoicing.

# 5798

And other faces that Day will be dust-stained,

# 5799

Blackness will cover them:

# 5800

Such will be the Rejecters of Allah, the doers of iniquity.

# 5801

When the sun (with its spacious light) is folded up;

# 5802

When the stars fall, losing their lustre;

# 5803

When the mountains vanish (like a mirage);

# 5804

When the she-camels, ten months with young, are left untended;

# 5805

When the wild beasts are herded together (in the human habitations);

# 5806

When the oceans boil over with a swell;

# 5807

When the souls are sorted out, (being joined, like with like);

# 5808

When the female (infant), buried alive, is questioned -

# 5809

For what crime she was killed;

# 5810

When the scrolls are laid open;

# 5811

When the world on High is unveiled;

# 5812

When the Blazing Fire is kindled to fierce heat;

# 5813

And when the Garden is brought near;-

# 5814

(Then) shall each soul know what it has put forward.

# 5815

So verily I call to witness the planets - that recede,

# 5816

Go straight, or hide;

# 5817

And the Night as it dissipates;

# 5818

And the Dawn as it breathes away the darkness;-

# 5819

Verily this is the word of a most honourable Messenger,

# 5820

Endued with Power, with rank before the Lord of the Throne,

# 5821

With authority there, (and) faithful to his trust.

# 5822

And (O people!) your companion is not one possessed;

# 5823

And without doubt he saw him in the clear horizon.

# 5824

Neither doth he withhold grudgingly a knowledge of the Unseen.

# 5825

Nor is it the word of an evil spirit accursed.

# 5826

When whither go ye?

# 5827

Verily this is no less than a Message to (all) the Worlds:

# 5828

(With profit) to whoever among you wills to go straight:

# 5829

But ye shall not will except as Allah wills,- the Cherisher of the Worlds.

# 5830

When the Sky is cleft asunder;

# 5831

When the Stars are scattered;

# 5832

When the Oceans are suffered to burst forth;

# 5833

And when the Graves are turned upside down;-

# 5834

(Then) shall each soul know what it hath sent forward and (what it hath) kept back.

# 5835

O man! What has seduced thee from thy Lord Most Beneficent?-

# 5836

Him Who created thee. Fashioned thee in due proportion, and gave thee a just bias;

# 5837

In whatever Form He wills, does He put thee together.

# 5838

Nay! But ye do reject Right and Judgment!

# 5839

But verily over you (are appointed angels) to protect you,-

# 5840

Kind and honourable,- Writing down (your deeds):

# 5841

They know (and understand) all that ye do.

# 5842

As for the Righteous, they will be in bliss;

# 5843

And the Wicked - they will be in the Fire,

# 5844

Which they will enter on the Day of Judgment,

# 5845

And they will not be able to keep away therefrom.

# 5846

And what will explain to thee what the Day of Judgment is?

# 5847

Again, what will explain to thee what the Day of Judgment is?

# 5848

(It will be) the Day when no soul shall have power (to do) aught for another: For the command, that Day, will be (wholly) with Allah.

# 5849

Woe to those that deal in fraud,-

# 5850

Those who, when they have to receive by measure from men, exact full measure,

# 5851

But when they have to give by measure or weight to men, give less than due.

# 5852

Do they not think that they will be called to account?-

# 5853

On a Mighty Day,

# 5854

A Day when (all) mankind will stand before the Lord of the Worlds?

# 5855

Nay! Surely the record of the wicked is (preserved) in Sijjin.

# 5856

And what will explain to thee what Sijjin is?

# 5857

(There is) a Register (fully) inscribed.

# 5858

Woe, that Day, to those that deny-

# 5859

Those that deny the Day of Judgment.

# 5860

And none can deny it but the Transgressor beyond bounds the Sinner!

# 5861

When Our Signs are rehearsed to him, he says, "Tales of the ancients!"

# 5862

By no means! but on their hearts is the stain of the (ill) which they do!

# 5863

Verily, from (the Light of) their Lord, that Day, will they be veiled.

# 5864

Further, they will enter the Fire of Hell.

# 5865

Further, it will be said to them: "This is the (reality) which ye rejected as false!

# 5866

Nay, verily the record of the Righteous is (preserved) in 'Illiyin.

# 5867

And what will explain to thee what 'Illiyun is?

# 5868

(There is) a Register (fully) inscribed,

# 5869

To which bear witness those Nearest (to Allah).

# 5870

Truly the Righteous will be in Bliss:

# 5871

On Thrones (of Dignity) will they command a sight (of all things):

# 5872

Thou wilt recognise in their faces the beaming brightness of Bliss.

# 5873

Their thirst will be slaked with Pure Wine sealed:

# 5874

The seal thereof will be Musk: And for this let those aspire, who have aspirations:

# 5875

With it will be (given) a mixture of Tasnim:

# 5876

A spring, from (the waters) whereof drink those Nearest to Allah.

# 5877

Those in sin used to laugh at those who believed,

# 5878

And whenever they passed by them, used to wink at each other (in mockery);

# 5879

And when they returned to their own people, they would return jesting;

# 5880

And whenever they saw them, they would say, "Behold! These are the people truly astray!"

# 5881

But they had not been sent as keepers over them!

# 5882

But on this Day the Believers will laugh at the Unbelievers:

# 5883

On Thrones (of Dignity) they will command (a sight) (of all things).

# 5884

Will not the Unbelievers have been paid back for what they did?

# 5885

When the sky is rent asunder,

# 5886

And hearkens to (the Command of) its Lord, and it must needs (do so);-

# 5887

And when the earth is flattened out,

# 5888

And casts forth what is within it and becomes (clean) empty,

# 5889

And hearkens to (the Command of) its Lord,- and it must needs (do so);- (then will come Home the full reality).

# 5890

O thou man! Verily thou art ever toiling on towards thy Lord- painfully toiling,- but thou shalt meet Him.

# 5891

Then he who is given his Record in his right hand,

# 5892

Soon will his account be taken by an easy reckoning,

# 5893

And he will turn to his people, rejoicing!

# 5894

But he who is given his Record behind his back,-

# 5895

Soon will he cry for perdition,

# 5896

And he will enter a Blazing Fire.

# 5897

Truly, did he go about among his people, rejoicing!

# 5898

Truly, did he think that he would not have to return (to Us)!

# 5899

Nay, nay! for his Lord was (ever) watchful of him!

# 5900

So I do call to witness the ruddy glow of Sunset;

# 5901

The Night and its Homing;

# 5902

And the Moon in her fullness:

# 5903

Ye shall surely travel from stage to stage.

# 5904

What then is the matter with them, that they believe not?-

# 5905

And when the Qur'an is read to them, they fall not prostrate,

# 5906

But on the contrary the Unbelievers reject (it).

# 5907

But Allah has full knowledge of what they secrete (in their breasts)

# 5908

So announce to them a Penalty Grievous,

# 5909

Except to those who believe and work righteous deeds: For them is a Reward that will never fail.

# 5910

By the sky, (displaying) the Zodiacal Signs;

# 5911

By the promised Day (of Judgment);

# 5912

By one that witnesses, and the subject of the witness;-

# 5913

Woe to the makers of the pit (of fire),

# 5914

Fire supplied (abundantly) with fuel:

# 5915

Behold! they sat over against the (fire),

# 5916

And they witnessed (all) that they were doing against the Believers.

# 5917

And they ill-treated them for no other reason than that they believed in Allah, Exalted in Power, Worthy of all Praise!-

# 5918

Him to Whom belongs the dominion of the heavens and the earth! And Allah is Witness to all things.

# 5919

Those who persecute (or draw into temptation) the Believers, men and women, and do not turn in repentance, will have the Penalty of Hell: They will have the Penalty of the Burning Fire.

# 5920

For those who believe and do righteous deeds, will be Gardens; beneath which rivers flow: That is the great Salvation, (the fulfilment of all desires),

# 5921

Truly strong is the Grip (and Power) of thy Lord.

# 5922

It is He Who creates from the very beginning, and He can restore (life).

# 5923

And He is the Oft-Forgiving, Full of Loving-Kindness,

# 5924

Lord of the Throne of Glory,

# 5925

Doer (without let) of all that He intends.

# 5926

Has the story reached thee, of the forces-

# 5927

Of Pharaoh and the Thamud?

# 5928

And yet the Unbelievers (persist) in rejecting (the Truth)!

# 5929

But Allah doth encompass them from behind!

# 5930

Nay, this is a Glorious Qur'an,

# 5931

(Inscribed) in a Tablet Preserved!

# 5932

By the Sky and the Night-Visitant (therein);-

# 5933

And what will explain to thee what the Night-Visitant is?-

# 5934

(It is) the Star of piercing brightness;-

# 5935

There is no soul but has a protector over it.

# 5936

Now let man but think from what he is created!

# 5937

He is created from a drop emitted-

# 5938

Proceeding from between the backbone and the ribs:

# 5939

Surely (Allah) is able to bring him back (to life)!

# 5940

The Day that (all) things secret will be tested,

# 5941

(Man) will have no power, and no helper.

# 5942

By the Firmament which returns (in its round),

# 5943

And by the Earth which opens out (for the gushing of springs or the sprouting of vegetation),-

# 5944

Behold this is the Word that distinguishes (Good from Evil):

# 5945

It is not a thing for amusement.

# 5946

As for them, they are but plotting a scheme,

# 5947

And I am planning a scheme.

# 5948

Therefore grant a delay to the Unbelievers: Give respite to them gently (for awhile).

# 5949

Glorify the name of thy Guardian-Lord Most High,

# 5950

Who hath created, and further, given order and proportion;

# 5951

Who hath ordained laws. And granted guidance;

# 5952

And Who bringeth out the (green and luscious) pasture,

# 5953

And then doth make it (but) swarthy stubble.

# 5954

By degrees shall We teach thee to declare (the Message), so thou shalt not forget,

# 5955

Except as Allah wills: For He knoweth what is manifest and what is hidden.

# 5956

And We will make it easy for thee (to follow) the simple (Path).

# 5957

Therefore give admonition in case the admonition profits (the hearer).

# 5958

The admonition will be received by those who fear (Allah):

# 5959

But it will be avoided by those most unfortunate ones,

# 5960

Who will enter the Great Fire,

# 5961

In which they will then neither die nor live.

# 5962

But those will prosper who purify themselves,

# 5963

And glorify the name of their Guardian-Lord, and (lift their hearts) in prayer.

# 5964

Nay (behold), ye prefer the life of this world;

# 5965

But the Hereafter is better and more enduring.

# 5966

And this is in the Books of the earliest (Revelation),-

# 5967

The Books of Abraham and Moses.

# 5968

Has the story reached thee of the overwhelming (Event)?

# 5969

Some faces, that Day, will be humiliated,

# 5970

Labouring (hard), weary,-

# 5971

The while they enter the Blazing Fire,-

# 5972

The while they are given, to drink, of a boiling hot spring,

# 5973

No food will there be for them but a bitter Dhari'

# 5974

Which will neither nourish nor satisfy hunger.

# 5975

(Other) faces that Day will be joyful,

# 5976

Pleased with their striving,-

# 5977

In a Garden on high,

# 5978

Where they shall hear no (word) of vanity:

# 5979

Therein will be a bubbling spring:

# 5980

Therein will be Thrones (of dignity), raised on high,

# 5981

Goblets placed (ready),

# 5982

And cushions set in rows,

# 5983

And rich carpets (all) spread out.

# 5984

Do they not look at the Camels, how they are made?-

# 5985

And at the Sky, how it is raised high?-

# 5986

And at the Mountains, how they are fixed firm?-

# 5987

And at the Earth, how it is spread out?

# 5988

Therefore do thou give admonition, for thou art one to admonish.

# 5989

Thou art not one to manage (men's) affairs.

# 5990

But if any turn away and reject Allah,-

# 5991

Allah will punish him with a mighty Punishment,

# 5992

For to Us will be their return;

# 5993

Then it will be for Us to call them to account.

# 5994

By the break of Day

# 5995

By the Nights twice five;

# 5996

By the even and odd (contrasted);

# 5997

And by the Night when it passeth away;-

# 5998

Is there (not) in these an adjuration (or evidence) for those who understand?

# 5999

Seest thou not how thy Lord dealt with the 'Ad (people),-

# 6000

Of the (city of) Iram, with lofty pillars,

# 6001

The like of which were not produced in (all) the land?

# 6002

And with the Thamud (people), who cut out (huge) rocks in the valley?-

# 6003

And with Pharaoh, lord of stakes?

# 6004

(All) these transgressed beyond bounds in the lands,

# 6005

And heaped therein mischief (on mischief).

# 6006

Therefore did thy Lord pour on them a scourge of diverse chastisements:

# 6007

For thy Lord is (as a Guardian) on a watch-tower.

# 6008

Now, as for man, when his Lord trieth him, giving him honour and gifts, then saith he, (puffed up), "My Lord hath honoured me."

# 6009

But when He trieth him, restricting his subsistence for him, then saith he (in despair), "My Lord hath humiliated me!"

# 6010

Nay, nay! but ye honour not the orphans!

# 6011

Nor do ye encourage one another to feed the poor!-

# 6012

And ye devour inheritance - all with greed,

# 6013

And ye love wealth with inordinate love!

# 6014

Nay! When the earth is pounded to powder,

# 6015

And thy Lord cometh, and His angels, rank upon rank,

# 6016

And Hell, that Day, is brought (face to face),- on that Day will man remember, but how will that remembrance profit him?

# 6017

He will say: "Ah! Would that I had sent forth (good deeds) for (this) my (Future) Life!"

# 6018

For, that Day, His Chastisement will be such as none (else) can inflict,

# 6019

And His bonds will be such as none (other) can bind.

# 6020

(To the righteous soul will be said:) "O (thou) soul, in (complete) rest and satisfaction!

# 6021

"Come back thou to thy Lord,- well pleased (thyself), and well-pleasing unto Him!

# 6022

"Enter thou, then, among My devotees!

# 6023

"Yea, enter thou My Heaven!

# 6024

I do call to witness this City;-

# 6025

And thou art a freeman of this City;-

# 6026

And (the mystic ties of) parent and child;-

# 6027

Verily We have created man into toil and struggle.

# 6028

Thinketh he, that none hath power over him?

# 6029

He may say (boastfully); Wealth have I squandered in abundance!

# 6030

Thinketh he that none beholdeth him?

# 6031

Have We not made for him a pair of eyes?-

# 6032

And a tongue, and a pair of lips?-

# 6033

And shown him the two highways?

# 6034

But he hath made no haste on the path that is steep.

# 6035

And what will explain to thee the path that is steep?-

# 6036

(It is:) freeing the bondman;

# 6037

Or the giving of food in a day of privation

# 6038

To the orphan with claims of relationship,

# 6039

Or to the indigent (down) in the dust.

# 6040

Then will he be of those who believe, and enjoin patience, (constancy, and self-restraint), and enjoin deeds of kindness and compassion.

# 6041

Such are the Companions of the Right Hand.

# 6042

But those who reject Our Signs, they are the (unhappy) Companions of the Left Hand.

# 6043

On them will be Fire vaulted over (all round).

# 6044

By the Sun and his (glorious) splendour;

# 6045

By the Moon as she follows him;

# 6046

By the Day as it shows up (the Sun's) glory;

# 6047

By the Night as it conceals it;

# 6048

By the Firmament and its (wonderful) structure;

# 6049

By the Earth and its (wide) expanse:

# 6050

By the Soul, and the proportion and order given to it;

# 6051

And its enlightenment as to its wrong and its right;-

# 6052

Truly he succeeds that purifies it,

# 6053

And he fails that corrupts it!

# 6054

The Thamud (people) rejected (their prophet) through their inordinate wrong-doing,

# 6055

Behold, the most wicked man among them was deputed (for impiety).

# 6056

But the Messenger of Allah said to them: "It is a She-camel of Allah! And (bar her not from) having her drink!"

# 6057

Then they rejected him (as a false prophet), and they hamstrung her. So their Lord, on account of their crime, obliterated their traces and made them equal (in destruction, high and low)!

# 6058

And for Him is no fear of its consequences.

# 6059

By the Night as it conceals (the light);

# 6060

By the Day as it appears in glory;

# 6061

By (the mystery of) the creation of male and female;-

# 6062

Verily, (the ends) ye strive for are diverse.

# 6063

So he who gives (in charity) and fears (Allah),

# 6064

And (in all sincerity) testifies to the best,-

# 6065

We will indeed make smooth for him the path to Bliss.

# 6066

But he who is a greedy miser and thinks himself self-sufficient,

# 6067

And gives the lie to the best,-

# 6068

We will indeed make smooth for him the path to Misery;

# 6069

Nor will his wealth profit him when he falls headlong (into the Pit).

# 6070

Verily We take upon Ourselves to guide,

# 6071

And verily unto Us (belong) the End and the Beginning.

# 6072

Therefore do I warn you of a Fire blazing fiercely;

# 6073

None shall reach it but those most unfortunate ones

# 6074

Who give the lie to Truth and turn their backs.

# 6075

But those most devoted to Allah shall be removed far from it,-

# 6076

Those who spend their wealth for increase in self-purification,

# 6077

And have in their minds no favour from anyone for which a reward is expected in return,

# 6078

But only the desire to seek for the Countenance of their Lord Most High;

# 6079

And soon will they attain (complete) satisfaction.

# 6080

By the Glorious Morning Light,

# 6081

And by the Night when it is still,-

# 6082

Thy Guardian-Lord hath not forsaken thee, nor is He displeased.

# 6083

And verily the Hereafter will be better for thee than the present.

# 6084

And soon will thy Guardian-Lord give thee (that wherewith) thou shalt be well-pleased.

# 6085

Did He not find thee an orphan and give thee shelter (and care)?

# 6086

And He found thee wandering, and He gave thee guidance.

# 6087

And He found thee in need, and made thee independent.

# 6088

Therefore, treat not the orphan with harshness,

# 6089

Nor repulse the petitioner (unheard);

# 6090

But the bounty of the Lord - rehearse and proclaim!

# 6091

Have We not expanded thee thy breast?-

# 6092

And removed from thee thy burden

# 6093

The which did gall thy back?-

# 6094

And raised high the esteem (in which) thou (art held)?

# 6095

So, verily, with every difficulty, there is relief:

# 6096

Verily, with every difficulty there is relief.

# 6097

Therefore, when thou art free (from thine immediate task), still labour hard,

# 6098

And to thy Lord turn (all) thy attention.

# 6099

By the Fig and the Olive,

# 6100

And the Mount of Sinai,

# 6101

And this City of security,-

# 6102

We have indeed created man in the best of moulds,

# 6103

Then do We abase him (to be) the lowest of the low,-

# 6104

Except such as believe and do righteous deeds: For they shall have a reward unfailing.

# 6105

Then what can, after this, contradict thee, as to the judgment (to come)?

# 6106

Is not Allah the wisest of judges?

# 6107

Proclaim! (or read!) in the name of thy Lord and Cherisher, Who created-

# 6108

Created man, out of a (mere) clot of congealed blood:

# 6109

Proclaim! And thy Lord is Most Bountiful,-

# 6110

He Who taught (the use of) the pen,-

# 6111

Taught man that which he knew not.

# 6112

Nay, but man doth transgress all bounds,

# 6113

In that he looketh upon himself as self-sufficient.

# 6114

Verily, to thy Lord is the return (of all).

# 6115

Seest thou one who forbids-

# 6116

A votary when he (turns) to pray?

# 6117

Seest thou if he is on (the road of) Guidance?-

# 6118

Or enjoins Righteousness?

# 6119

Seest thou if he denies (Truth) and turns away?

# 6120

Knoweth he not that Allah doth see?

# 6121

Let him beware! If he desist not, We will drag him by the forelock,-

# 6122

A lying, sinful forelock!

# 6123

Then, let him call (for help) to his council (of comrades):

# 6124

We will call on the angels of punishment (to deal with him)!

# 6125

Nay, heed him not: But bow down in adoration, and bring thyself the closer (to Allah)!

# 6126

We have indeed revealed this (Message) in the Night of Power:

# 6127

And what will explain to thee what the night of power is?

# 6128

The Night of Power is better than a thousand months.

# 6129

Therein come down the angels and the Spirit by Allah's permission, on every errand:

# 6130

Peace!... This until the rise of morn!

# 6131

Those who reject (Truth), among the People of the Book and among the Polytheists, were not going to depart (from their ways) until there should come to them Clear Evidence,-

# 6132

An messenger from Allah, rehearsing scriptures kept pure and holy:

# 6133

Wherein are laws (or decrees) right and straight.

# 6134

Nor did the People of the Book make schisms, until after there came to them Clear Evidence.

# 6135

And they have been commanded no more than this: To worship Allah, offering Him sincere devotion, being true (in faith); to establish regular prayer; and to practise regular charity; and that is the Religion Right and Straight.

# 6136

Those who reject (Truth), among the People of the Book and among the Polytheists, will be in Hell-Fire, to dwell therein (for aye). They are the worst of creatures.

# 6137

Those who have faith and do righteous deeds,- they are the best of creatures.

# 6138

Their reward is with Allah: Gardens of Eternity, beneath which rivers flow; they will dwell therein for ever; Allah well pleased with them, and they with Him: all this for such as fear their Lord and Cherisher.

# 6139

When the earth is shaken to her (utmost) convulsion,

# 6140

And the earth throws up her burdens (from within),

# 6141

And man cries (distressed): 'What is the matter with her?'-

# 6142

On that Day will she declare her tidings:

# 6143

For that thy Lord will have given her inspiration.

# 6144

On that Day will men proceed in companies sorted out, to be shown the deeds that they (had done).

# 6145

Then shall anyone who has done an atom's weight of good, see it!

# 6146

And anyone who has done an atom's weight of evil, shall see it.

# 6147

By the (Steeds) that run, with panting (breath),

# 6148

And strike sparks of fire,

# 6149

And push home the charge in the morning,

# 6150

And raise the dust in clouds the while,

# 6151

And penetrate forthwith into the midst (of the foe) en masse;-

# 6152

Truly man is, to his Lord, ungrateful;

# 6153

And to that (fact) he bears witness (by his deeds);

# 6154

And violent is he in his love of wealth.

# 6155

Does he not know,- when that which is in the graves is scattered abroad

# 6156

And that which is (locked up) in (human) breasts is made manifest-

# 6157

That their Lord had been Well-acquainted with them, (even to) that Day?

# 6158

The (Day) of Noise and Clamour:

# 6159

What is the (Day) of Noise and Clamour?

# 6160

And what will explain to thee what the (Day) of Noise and Clamour is?

# 6161

(It is) a Day whereon men will be like moths scattered about,

# 6162

And the mountains will be like carded wool.

# 6163

Then, he whose balance (of good deeds) will be (found) heavy,

# 6164

Will be in a life of good pleasure and satisfaction.

# 6165

But he whose balance (of good deeds) will be (found) light,-

# 6166

Will have his home in a (bottomless) Pit.

# 6167

And what will explain to thee what this is?

# 6168

(It is) a Fire Blazing fiercely!

# 6169

The mutual rivalry for piling up (the good things of this world) diverts you (from the more serious things),

# 6170

Until ye visit the graves.

# 6171

But nay, ye soon shall know (the reality).

# 6172

Again, ye soon shall know!

# 6173

Nay, were ye to know with certainty of mind, (ye would beware!)

# 6174

Ye shall certainly see Hell-Fire!

# 6175

Again, ye shall see it with certainty of sight!

# 6176

Then, shall ye be questioned that Day about the joy (ye indulged in!).

# 6177

By (the Token of) Time (through the ages),

# 6178

Verily Man is in loss,

# 6179

Except such as have Faith, and do righteous deeds, and (join together) in the mutual teaching of Truth, and of Patience and Constancy.

# 6180

Woe to every (kind of) scandal-monger and-backbiter,

# 6181

Who pileth up wealth and layeth it by,

# 6182

Thinking that his wealth would make him last for ever!

# 6183

By no means! He will be sure to be thrown into That which Breaks to Pieces,

# 6184

And what will explain to thee That which Breaks to Pieces?

# 6185

(It is) the Fire of (the Wrath of) Allah kindled (to a blaze),

# 6186

The which doth mount (Right) to the Hearts:

# 6187

It shall be made into a vault over them,

# 6188

In columns outstretched.

# 6189

Seest thou not how thy Lord dealt with the Companions of the Elephant?

# 6190

Did He not make their treacherous plan go astray?

# 6191

And He sent against them Flights of Birds,

# 6192

Striking them with stones of baked clay.

# 6193

Then did He make them like an empty field of stalks and straw, (of which the corn) has been eaten up.

# 6194

For the covenants (of security and safeguard enjoyed) by the Quraish,

# 6195

Their covenants (covering) journeys by winter and summer,-

# 6196

Let them adore the Lord of this House,

# 6197

Who provides them with food against hunger, and with security against fear (of danger).

# 6198

Seest thou one who denies the Judgment (to come)?

# 6199

Then such is the (man) who repulses the orphan (with harshness),

# 6200

And encourages not the feeding of the indigent.

# 6201

So woe to the worshippers

# 6202

Who are neglectful of their prayers,

# 6203

Those who (want but) to be seen (of men),

# 6204

But refuse (to supply) (even) neighbourly needs.

# 6205

To thee have We granted the Fount (of Abundance).

# 6206

Therefore to thy Lord turn in Prayer and Sacrifice.

# 6207

For he who hateth thee, he will be cut off (from Future Hope).

# 6208

Say: O ye that reject Faith!

# 6209

I worship not that which ye worship,

# 6210

Nor will ye worship that which I worship.

# 6211

And I will not worship that which ye have been wont to worship,

# 6212

Nor will ye worship that which I worship.

# 6213

To you be your Way, and to me mine.

# 6214

When comes the Help of Allah, and Victory,

# 6215

And thou dost see the people enter Allah's Religion in crowds,

# 6216

Celebrate the praises of thy Lord, and pray for His Forgiveness: For He is Oft-Returning (in Grace and Mercy).

# 6217

Perish the hands of the Father of Flame! Perish he!

# 6218

No profit to him from all his wealth, and all his gains!

# 6219

Burnt soon will he be in a Fire of Blazing Flame!

# 6220

His wife shall carry the (crackling) wood - As fuel!-

# 6221

A twisted rope of palm-leaf fibre round her (own) neck!

# 6222

Say: He is Allah, the One and Only;

# 6223

Allah, the Eternal, Absolute;

# 6224

He begetteth not, nor is He begotten;

# 6225

And there is none like unto Him.

# 6226

Say: I seek refuge with the Lord of the Dawn

# 6227

From the mischief of created things;

# 6228

From the mischief of Darkness as it overspreads;

# 6229

From the mischief of those who practise secret arts;

# 6230

And from the mischief of the envious one as he practises envy.

# 6231

Say: I seek refuge with the Lord and Cherisher of Mankind,

# 6232

The King (or Ruler) of Mankind,

# 6233

The god (or judge) of Mankind,-

# 6234

From the mischief of the Whisperer (of Evil), who withdraws (after his whisper),-

# 6235

(The same) who whispers into the hearts of Mankind,-

# 6236

Among Jinns and among men.

