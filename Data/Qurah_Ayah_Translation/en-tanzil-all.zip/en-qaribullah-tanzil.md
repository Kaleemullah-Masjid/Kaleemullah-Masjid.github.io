<!--
Quran Translation
Name: Qaribullah & Darwish
Translator: Hasan al-Fatih Qaribullah and Ahmad Darwish
Language: English
ID: en.qaribullah
Last Update: June 4, 2010
Source: Tanzil.net
-->

# 1

In the Name of Allah, the Merciful, the Most Merciful

# 2

Praise be to Allah, Lord of the Worlds,

# 3

the Merciful, the Most Merciful,

# 4

Owner of the Day of Recompense.

# 5

You (alone) we worship; and You (alone) we rely for help.

# 6

Guide us to the Straight Path,

# 7

the Path of those upon whom You have favored, not those upon whom is the anger, nor the astray. (Amen please answer)

# 8

AlifLaamMeem.

# 9

That is the (Holy) Book, where there is no doubt. It is a guidance for the cautious (of evil and Hell).

# 10

Who believe in the unseen and establish the (daily) prayer; who spend out of what We have provided them.

# 11

Who believe in that which has been sent down to you (Prophet Muhammad) and what has been sent down before you (to Prophets Jesus and Moses) and firmly believe in the Everlasting Life.

# 12

These are guided by their Lord; these surely are the prosperous.

# 13

Those who disbelieve, whether you forewarn them or not, they will not believe.

# 14

Allah has set a seal upon their hearts and ears; their sight is dimmed and for them is a great punishment.

# 15

There are some people who say: 'We believe in Allah and the Last Day,'yet they are not believers.

# 16

They seek to deceive Allah and those who believe, but they deceive none except themselves, though they do not sense it.

# 17

There is a sickness in their hearts which Allah has increased. For them there is a painful punishment because they lie.

# 18

When it is said to them, 'Do not corrupt in the land,' they reply, 'We are only reformers.'

# 19

But it is they who are the evildoers, though they do not sense it.

# 20

When it is said to them: 'Believe as (other) people believe,' they reply, 'Are we to believe as fools believe?' It is they who are the fools, if only they knew!

# 21

When they meet those who believe, they say, 'We, too believe.' But when they are alone with their devils, they say to them: 'We follow none but you, we were only mocking

# 22

Allah will mock at them and prolong them in sin, blundering blindly.

# 23

Such are those who barter away guidance for error, their trade did not profit (them), nor are they guided.

# 24

Their example is like one who kindled a fire, and when it lit all around him, Allah took away their light and left them in darkness. They could not see.

# 25

Deaf, dumb, and blind, they shall never return.

# 26

Or, like (those who, under) a cloudburst from the sky with darkness, thunder and lightning, they thrust their fingers in their ears at the sound of every thunderclap for fear of death, and Allah encompasses the unbelievers.

# 27

The lightning almost snatches away their sight, whenever it flashes upon them they walk on, but as soon as it darkens they stand still. Indeed, if Allah willed, He could take away their sight and hearing. Allah has power over all things.

# 28

O people, worship your Lord who has created you and those who have gone before you, so that you will be cautious.

# 29

Who has made the earth a bed for you and the sky a dome, and has sent down water from the sky to bring forth fruits for your provision. Do not knowingly set up rivals to Allah.

# 30

If you are in doubt of what We have sent down to Our worshiper (Prophet Muhammad), produce a chapter comparable to it. Call upon your helpers, other than Allah, to assist you, if you are true.

# 31

But if you fail, as you are sure to fail, then guard yourselves against the Fire whose fuel is people and stones, prepared for the unbelievers.

# 32

Bear glad tidings to those who believe and do good works. They shall live in Gardens underneath which rivers flow. Whenever they are given fruit as provision they will say: 'This is what we were given before,' for they shall be given in resemblance. Therein they shall have pure spouses, and shall live there for ever.

# 33

Allah is not shy to strike a parable whatsoever a gnat or larger. Those who believe know that it is the truth from their Lord. As for those who disbelieve they ask: 'What could Allah mean by this parable? By it, Allah misleads many and guides many.' But He misleads none except the evildoers,

# 34

who break the covenant of Allah after accepting it and sever what Allah has bidden to be joined and corrupt in the land. These are the losers.

# 35

How can you disbelieve Allah? Did He not give you life when you were dead, and He will cause you to die and then restore you to life. Then you will return to Him.

# 36

He created for you all that is in the earth, then, He willed to the heaven, and leveled them seven heavens. He has knowledge of all things.

# 37

When your Lord said to the angels: 'I am placing on the earth a caliph,' they replied: 'Will You put there who corrupts and sheds blood, when we exalt Your praises and sanctify You?' He said: 'I know what you do not know'

# 38

He taught Adam (father of humans) the names all of them and then presented them to the angels, saying: 'Tell Me the names of these, if you are truthful'

# 39

'Exaltations to You,' they replied, 'we have no knowledge except that which You have taught us. You are indeed the Knowing, the Wise'

# 40

Then He said to Adam: 'Tell them their names.' And when Adam had named them, He said: 'Did I not tell you that I know the unseen of the heavens and earth, and all that you reveal and all that you hide'

# 41

And when We said to the angels: 'Prostrate (to Me) yourselves towards Adam,' they all prostrated themselves except iblis (satan, father of the jinn), who, in his pride refused and became an unbeliever.

# 42

To Adam We said: 'Dwell with your wife in Paradise and both eat of it as much as you wish and wherever you will. But neither of you should come close to this tree or else you shall both become transgressors'

# 43

But satan made them slip therefrom and caused them to depart from that in which they had been. 'Go down,' We said, 'be enemies to each other. The earth will provide your dwelling place an enjoyment for a while'

# 44

Then Adam received Words from his Lord, and his Lord relented towards him. He is the Receiver of Repentance, the Merciful.

# 45

'Go down, all together,' We said, 'so if a guidance shall come to you from Me, whosoever follows My guidance no fear shall be on them, neither shall they be saddened.

# 46

But those who disbelieve and belie Our verses shall be the companions of the Fire, and there they shall live for ever'

# 47

'Children of Israel, remember My favor I have bestowed upon you. Fulfill My covenant, and I will fulfill your covenant with you. Me, you must fear.

# 48

And believe in what I have sent down confirming what is with you, and do not be the first to disbelieve it. Do not sell My verses for a little price and fear Me.

# 49

Do not confound truth with falsehood, nor knowingly hide the truth while you know.

# 50

Establish your prayers, pay the obligatory charity, and bow with those who bow.

# 51

Would you order righteousness on others and forget it yourselves? Yet you recite the Book, have you no sense?

# 52

And seek help in patience and prayer. For it is heavy, except to the humble,

# 53

who reckon that they will meet their Lord and that to Him they will return.

# 54

Children of Israel, remember the favors I have bestowed on you, and that I have preferred you (the prophets among you) above the worlds.

# 55

Guard yourselves against the Day when no soul can avail a thing to another, when neither intercession nor ransom shall be accepted from it, nor will they be helped.

# 56

(Remember) how We saved you from Pharaoh's people who had oppressed you cruelly, slaying your sons and sparing your women. Surely, that was a great trial from your Lord.

# 57

We parted the sea for you, and, taking you to safety, drowned the family of Pharaoh before your eyes.

# 58

We appointed for Moses forty nights, but in his absence you took the calf, thereby committing harm.

# 59

Yet after that We pardoned you, so that you might give thanks.

# 60

And when We gave Moses the Book and the Criterion, so that you might be guided;

# 61

and when Moses said to his nation: 'My nation, you have harmed yourselves by taking the calf (to worship). So turn in repentance to your Creator and slay yourselves. That will be best for you with your Creator.' And He shall accept you. He is the Receiver of Repentance, the Merciful.

# 62

And when you said to Moses: 'We will not believe in you until we see Allah openly' a thunderbolt struck you whilst you were looking.

# 63

Then We raised you from your death, so that you might give thanks.

# 64

We caused the clouds to cast their shadow over you and sent down for you manna and quails, (saying:) 'Eat of the good things We have provided you. 'Indeed, they did not harm Us, but they harmed themselves.

# 65

'Enter this village' We said, 'and eat wherever you will and as much as you wish. Make your way prostrating through the gates, saying: "Unburdening." We shall forgive you your sins and We will increase the gooddoers'

# 66

But the harmdoers tampered with Our Words, different from that said to them, and We let loose on the harmdoers a scourge from heaven as a punishment for their debauchery.

# 67

(Remember) when Moses prayed for water for his nation, We said to him: 'Strike the Rock with your staff' Thereupon twelve springs gushed from it, and each tribe knew their drinking place. 'Eat and drink of that which Allah has provided and do not act evilly in the land, corrupting'

# 68

'Moses' you said, 'we will no longer be patient with one type of food. Call on your Lord to bring forth for us some of the produce of the earth, green herbs and cucumbers, corn, lentils and onions' 'What' he answered, 'Would you exchange that which is lesser for what is better? Go down into Egypt, there you shall find all that you have asked' Humiliation and abasement were pitched upon them, and they incurred the Anger of Allah; because they disbelieved His signs and slew His Prophets unjustly; because they disobeyed and were transgressors.

# 69

Those who believe, Jews, Nazarenes and Sabaeans whoever believes in Allah and the Last Day and does good deeds shall be rewarded by their Lord; they have nothing to fear nor are they saddened.

# 70

And when We made a covenant with you and raised the Mount above you, (saying) 'Take what We have given you forcefully and remember what is in it, so that you will be cautious'

# 71

yet after that you turned away, but for the Grace of Allah and His Mercy you would have surely been among the losers.

# 72

You have surely known of those amongst you who transgressed the Sabbath. We said to them: 'Be apes, despised'

# 73

We made it a punishment for the former times and for the latter, an exhortation to the cautious.

# 74

When Moses said to his nation: 'Allah commands you to slaughter a cow' they replied: 'Are you taking us in mockery' 'I seek protection with Allah lest I should be one of the ignorant' he said.

# 75

'Call on your Lord' they said, 'to make known to us what she shall be' He said: "He says she is a cow neither old, nor virgin, middling between both." Therefore, do as you have been ordered'

# 76

'Call on your Lord' they said, 'to make known to us what her color shall be' 'Your Lord says: "The cow is yellow, a rich yellow pleasing to the onlookers.'

# 77

'Call on your Lord' they said, 'to make known to us which cow she shall be; to us cows look alike. If Allah wills, we shall be guided'

# 78

He replied: 'He says: "She is a cow, neither worn out plowing the earth nor watering the field, one kept secure free from any blemish.' 'Now you have brought us the truth' they answered. And they slaughtered her, after they had been reluctant to do so.

# 79

And when you slew a soul and then fell out with one another concerning it, Allah made known what you concealed.

# 80

We said: 'Strike him with a piece of it' Like this, Allah restores the dead to life and shows you His signs in order that you will understand.

# 81

Yet after that your hearts became as hard as rock or even harder. Indeed among the stones are those from which rivers burst. And others split so that water issues from them; and others crash down through fear of Allah. Allah is not inattentive of what you do.

# 82

Do you then hope that they will believe in you, when some of them have already heard the Word of Allah and knowingly tampered with it, after they understood it!

# 83

When they meet those who believe, they say: 'We are believers' But when alone, they say to their other (chiefs). 'Do you tell to them what Allah has revealed to you so that they will dispute with you concerning it with your Lord? Have you no sense'

# 84

Do they not know that Allah has knowledge of all they hide and all that they reveal!

# 85

And some of them are common (people) and do not know the Book, but only wishful thoughts, and they are only doubters.

# 86

Woe to those who write the Book with their own hands and then say: 'This is from Allah' in order to gain a small price for it. So woe to them for what their hands have written, and woe to them for their earnings.

# 87

They say: 'The Fire will never touch us except for a number of days' Say: 'Did Allah make you such a promise for Allah never breaks His promise or do you say about Allah what you do not know'

# 88

Indeed, he who earns evil and becomes engrossed in his sin, they are the people of the Fire; in it they shall remain for ever.

# 89

But those who believe and do good works are the people of Paradise; for ever they shall live in it.

# 90

(Remember) when We made a covenant with the Children of Israel, you shall worship none except Allah. Show kindness to your parents, to kinsmen, to the orphans, and to the needy, and speak of goodness to people. Establish your prayers and pay the obligatory charity. But, except for a few, you all turned your backs and gave no heed.

# 91

And when We made a covenant with you, that you shall not shed your blood or turn yourselves out of your dwellings, to this you consented and bore witness.

# 92

Yet there you are, slaying your ownselves, and turning a number of them out of their dwellings, and helping each other against them with sin and aggression. Although, should they come to you as captives, you would ransom them. Surely, their expulsion was unlawful. Do you then believe in a part of the Book and disbelieve another! What shall be the recompense of those of you who do that, but degradation in the worldly life, and on the Day of Resurrection to be returned to the most terrible punishment. Allah is not inattentive of what you do.

# 93

Such are they who buy the worldly life at the price of the Everlasting Life. Their punishment shall not be lightened, nor shall they be helped.

# 94

To Moses We gave the Book and after him We sent other Messengers. We gave (Prophet) Jesus, the son of Mary, veritable signs, and supported him with the Spirit of Purity (Gabriel). Will you then become proud whenever any Messenger comes to you with that which does not suit your fancies, and you belied some (Prophet Jesus) and killed others!

# 95

They say: 'Our hearts are covered' But Allah has cursed them for their disbelief. Little is that they believe.

# 96

And when a Book came to them from Allah confirming what was with them, while before that they used to pray for victory over the unbelievers when there came to them what they knew, they disbelieved him. Therefore, the curse of Allah be upon the unbelievers!

# 97

Evil is that for which they have bartered away their souls, that they disbelieve what Allah has sent down, grudging that Allah should send down from His bounty to whom He chooses from His worshipers! They have incurred wrath over wrath. For the unbelievers there is a humiliating punishment.

# 98

When it is said to them: 'Believe in what Allah has sent down' they reply: 'We believe in what was sent down to us' But they disbelieve in what is sent after it, although it is the truth, confirming their own Book. Say: 'Why, before did you kill the Prophets of Allah, if you are believers'

# 99

Moses came to you with clear signs, then you took to yourselves the calf after him and you were harmdoers'

# 100

When We made a covenant with you and raised the Mount above you (saying): 'Take what We have given you forcefully and hear' they replied: 'We hear, but disobey' For their disbelief, they were made to drink the calf into their very hearts. Say: 'Evil is your belief that orders you to (worship the calf), if you are indeed believers'

# 101

Say: 'If the abode of the Everlasting Life is with Allah for you especially, to the exclusion of all other people, then long for death if you are truthful'

# 102

But they will never long for it (death), because of what their hands forwarded; and Allah knows the harmdoers.

# 103

Indeed, you will find them more eager than other people for this life. And (more than) those who disbelieve. Each one of them wishes to live a thousand years. But his prolonged life will surely not remove him from the punishment. Allah is the Seer of what they do.

# 104

Say: 'Whoever is an enemy of Gabriel, indeed, he has brought it down by the permission of Allah to your heart, confirming what was before it and a guidance and glad tidings to the believers.

# 105

Whoever is an enemy of Allah, His Angels, His Messengers, Gabriel, and Michael indeed Allah is the enemy of the unbelievers'

# 106

We have sent down to you clear verses, none will disbelieve them except the evildoers.

# 107

Why, whenever they make a promise do some of them cast it aside! Most of them do not believe.

# 108

And now that a Messenger has come to them from Allah confirming what was with them, some of those to whom the Book was given reject the Book of Allah behind their backs, as though they knew nothing

# 109

and follow what the devils recited over the Kingdom of Solomon. Solomon did not disbelieve, it is the devils who disbelieved, teaching people magic and that which was sent down upon the angels Harut and Marut in Babylon. They did not teach anyone, until both had said: 'We have been sent as a trial; do not disbelieve' From them they learned how they might separate a husband and his wife. However, they did not harm anyone with it, except by the permission of Allah. Indeed, they learned what harms them and does not profit them, yet they knew that anyone who buys it would have no share in the Everlasting Life. Evil is that for which they have sold their souls, if they but knew!

# 110

Had they believed and were cautious, far better for them would be the reward from Allah, if they but knew.

# 111

'Believers, do not say 'Observe us (Ra'ina, in Hebrew means evil) ', but instead say: "Look after us (Undhurna), and listen' for the unbelievers is a painful punishment.

# 112

The unbelievers among the People of the Book (Jews and Nazarenes) and the idolaters resent that any good should have been sent down to you from your Lord. But Allah chooses whom He will for His Mercy. And Allah is of great bounty.

# 113

If We supersede any verse or cause it to be forgotten, We bring a better one or one similar. Do you not know that Allah has power over all things!

# 114

Do you not know that it is to Allah that the Kingdom of the heavens and the earth belong, and that there is none, other than Him, to protect or help you!

# 115

Would you rather demand of your Messenger that which was once demanded of Moses! He who exchanges belief for disbelief has surely strayed from the Right Path.

# 116

Many of the People of the Book wish they might turn you back as unbelievers after you have believed, in envy of their souls, after the truth has been clarified to them. So pardon and forgive until Allah brings His command. Allah is Powerful over everything.

# 117

Establish your prayers and pay the obligatory charity. Whatever good you shall forward for your soul you shall find it with Allah. He is the Seer of what you do.

# 118

They say: 'None but Jews and Nazarenes shall be admitted to Paradise' Such are their wishful fancies. Say: 'Bring us your proof, if what you say is true'

# 119

Indeed, whoever submits his face to Allah and does good works shall be rewarded by his Lord; there they shall have nothing to fear nor shall they be saddened.

# 120

The Jews say the Nazarenes are not on anything, and the Nazarenes say it is the Jews who are not on anything. Yet they both read the Book. And those who do not know say like their saying. Allah will judge between them their disputes on the Day of Resurrection.

# 121

Who does greater harm than he who prevents His Name to be remembered in the Mosques of Allah and strives to destroy them? Those, they will not enter them except in fear. And for them shame in this world and a great punishment in the next.

# 122

To Allah belong the east and the west. Whichever way you turn, there is the Face of Allah. He is the Embracer, the Knower.

# 123

They say: 'Allah has taken (to Himself) a son' Exaltations to Him (Allah). For Him is what is in the heavens and the earth, all are obedient to Him.

# 124

Creator of the heavens and the earth! When He decrees a thing, He only says: 'Be' and it is.

# 125

And those who do not know say: 'Why does not Allah speak to us or a sign come to us' Likewise, those who were before them said similar to their saying. Their hearts are alike. Indeed, We have clarified the signs to a nation who are certain.

# 126

We have sent you (Prophet Muhammad) forth with the truth, a giver of glad tidings and a giver of warning. You shall not be questioned about the companions of Hell.

# 127

You will please neither the Jews nor the Nazarenes unless you follow their creed. Say: 'The guidance of Allah is the guidance' And if after all the knowledge you have been given you yield to their desires, you shall not have, other than Allah, either a guide or a helper.

# 128

Those to whom We have given the Book, and who recite it as it ought to be read, truly believe in it; those who disbelieve it shall be the losers.

# 129

Children of Israel, remember My favor which I bestowed upon you and that I preferred your (prophets among you) above the worlds.

# 130

And fear a Day when no soul for another will compensate a thing, and no equivalent will be accepted from it, neither intercession will benefit it, nor shall they be helped.

# 131

And when Abraham was tested by His Lord with certain words and he fulfilled them, He said: 'I have appointed you as a leader for the nation' (Abraham) asked: 'And of my descendants' 'My covenant' said He, 'the harmdoers shall not receive it'

# 132

And when We made the House (Ka'bah) a visitation and a sanctuary for the people (saying:) 'Make the place where Abraham stood a place of prayer. 'And We made a covenant with Abraham and Ishmael: 'Purify My House for those who circumambulate around it, and those who cleave to it, to those who bow and prostrate'

# 133

And when Abraham said: 'My Lord, make this country safe and provide its inhabitants whosoever of them believes in Allah and the Last Day with fruits' He said: 'And whosoever disbelieves, to him I shall give enjoyment for a while. Then I shall compel him to the punishment of the Fire, how evil an arrival'

# 134

And when Abraham and Ishmael raised the foundations of the House (supplicating): 'O our Lord, accept this from us, You are the Hearer, the Knower.

# 135

Our Lord, make us both submissive to You, and of our descendants a submissive nation to You. Show us our rites and accept us; You are the Receiver of Repentance, the Merciful.

# 136

Our Lord, send among them a Messenger from them who shall recite to them Your verses and teach them the Book and wisdom, and purify them; You are the Mighty, the Wise'

# 137

And who has no desire for the religion of Abraham, except he who fooled himself? We chose him in this world, and in the Everlasting world, he shall be among the righteous.

# 138

When his Lord said to him: 'Submit' he answered: 'I have submitted to the Lord of the Worlds'

# 139

Abraham charged his children with this, and so did Jacob, saying: 'My sons, Allah has chosen for you the religion. Do not die except being submissive (Muslims)'

# 140

Or, were you witnesses when death came to Jacob! He said to his children: 'What will you worship after me' They replied: 'We will worship your God and the God of your forefathers, Abraham, Ishmael, and Isaac, the One God. To Him, we are submissive'

# 141

That was a nation that has passed away. Theirs is what they earned, and yours what you have earned. You shall not be questioned about what they did.

# 142

They say: 'Be Jews or Nazarenes and you shall be guided' Say: 'No, rather the Creed of Abraham, the upright one. He was not among the idolaters'

# 143

Say: 'We believe in Allah and that which is sent down to us, and in what was sent down to Abraham, Ishmael, Isaac, Jacob, and the tribes; to Moses and Jesus and the Prophets from their Lord. We do not differentiate between any of them, and to Him we are submissive (Muslims)'

# 144

If they believe as you have believed they shall be guided; if they reject it, they shall surely be in clear dissension. Allah will suffice you. He is the Hearer, the Knower.

# 145

The (indelible) marking of Allah. And who marks better than Allah! And for Him we are worshipers.

# 146

Say: 'Would you dispute with us about Allah, who is our Lord and your Lord? Our deeds belong to us and your deeds belong to you. We are sincere to Him'

# 147

Or do you say that Abraham, Ishmael, Isaac, Jacob, and the tribes, were Jews or Nazarenes! Say: 'Who knows better, you or Allah? Who is more unjust than he who hides a testimony received from Allah? And Allah is not inattentive of what you do'

# 148

That nation has passed away. Theirs is what they earned and yours what you have earned. You shall not be questioned about what they did.

# 149

The fools among the people will say: 'What has made them turn away from the direction they were facing' Say: 'The east and the west belong to Allah. He guides whom He will to the Straight Path'

# 150

And so We have made you a median nation, in order that you will be a witness above the people, and that the Messenger be a witness above you. We did not change the direction that you were facing except that We might know who followed the Messenger from him who turned on both his heels. Though it was a hardship except for those whom Allah has guided. But Allah would never waste your faith. Indeed, Allah is Gentle with people, the Most Merciful.

# 151

We have seen you turning your face towards the heaven, We shall surely turn you to a direction that shall satisfy you. So turn your face towards the Sacred Mosque (built by Abraham); wherever you are, turn your faces to it' Those to whom the Book was given know this to be the truth from their Lord. Allah is not inattentive of what they do.

# 152

But even if you brought those to whom the Book had been given every proof, they would not accept your direction, nor would you accept theirs; nor would any of them accept the direction of the other. If after all the knowledge you have been given you yield to their desires, then you will surely be among the harmdoers.

# 153

Those to whom We gave the Book know him (Prophet Muhammad) as they know their own sons. But a party of them conceal the truth while they know.

# 154

The truth comes from your Lord so do not be among the doubters.

# 155

And for everyone is a direction for which he turns. So race in goodness. And wherever you are, Allah will bring you all together. He has power over all things.

# 156

From wherever you emerge, turn your face towards the Sacred Mosque. This is surely the truth from your Lord. Allah is never inattentive of what you do.

# 157

From wherever you emerge, turn your face towards the Sacred Mosque, and wherever you are, face towards it, so that the people will have no argument against you, except the harmdoers among them. Do not fear them, fear Me, so that I will perfect My Favor to you and that you will be guided.

# 158

As We have sent among you a Messenger (Prophet Muhammad) from yourselves, to recite to you Our verses and to purify you, who will teach you the Book and Wisdom, and teach you that of which you have no knowledge.

# 159

So remember Me, I will remember you. Give thanks to Me and do not be ungrateful towards Me.

# 160

Believers, seek assistance in patience and prayer, Allah is with those who are patient.

# 161

Do not say that those killed in the Way of Allah are dead, they are alive, although you are unaware.

# 162

We shall test you with something of fear and hunger, and decrease of goods, life and fruits. Give glad tidings to the patient,

# 163

who, in adversity say: 'We belong to Allah and to Him we shall return'

# 164

On those will be prayers and mercy from their Lord, those are guided.

# 165

Safah and Marwah are the waymarks of Allah. Whoever performs the pilgrimage to the House or the visit, there shall be no guilt on him to circumambulate between both of them. And whoever volunteers good, Allah is Thankful, the Knower.

# 166

Those who hide the clear verses and the guidance We have sent down after We have clarified them in the Book for the people shall be cursed by Allah and cursed by the cursers,

# 167

except those who repent, and mend (their deeds) and clarify. Those I shall accept them. I am the Receiver of repentance, the Most Merciful.

# 168

But those who disbelieve, and die disbelieving shall incur the curse of Allah, the angels, and all people.

# 169

They are there (in the Fire) for eternity neither shall the punishment be lightened for them; nor shall they be given respite.

# 170

Your God is One God. There is no god except He. He is the Merciful, the Most Merciful.

# 171

In the creation of the heavens and the earth; in the alternation of night and day; in the ships that sail upon the sea with what is beneficial to the people; in the water which Allah sends down from the sky and with which He revives the earth after its death, and He spread in it from each moving (creation); in the movement of the winds, and in the clouds that are compelled between heaven and earth surely, these are signs for people who understand.

# 172

And among the people are those who take to themselves rivals, other than Allah, loving them as Allah is loved. But those who believe are more loving to Allah. When the harmdoers see when they see the punishment because the power altogether belongs to Allah, and that Allah is firm in punishment,

# 173

when those who were followed disown those who followed, and they see the punishment and relationships are broken off,

# 174

those who followed them will say: 'If only that we might return once, and disown them as they have disowned us' As such Allah will show them their own works to be regrets for them, and they shall never emerge from the Fire.

# 175

People, eat of what is lawful and good on the earth and do not walk in satan's footsteps, because he is for you a clear enemy,

# 176

he orders you to commit evil and indecency and to assert about Allah what you do not know.

# 177

When it is said to them: 'Follow what Allah has sent down' they reply: 'We will follow that which we found our fathers upon' even though their fathers did not understand anything and they were not guided.

# 178

The likeness of those who disbelieve is as the likeness of he who calls to that which does not hear, except a shout and a voice. Deaf, dumb, and blind, they do not understand.

# 179

Believers, eat of the good with which We have provided you and give thanks to Allah, if you really worship Him.

# 180

He has forbidden you the dead, blood, and the flesh of swine, also that which is invoked to other than Allah. But whoever is constrained (to eat) any of these, not intending to sin or transgress, incurs no guilt. Allah is Forgiving and the Most Merciful.

# 181

Those who conceal what Allah has sent down of the Book and sell it for a small price shall swallow nothing but fire into their bellies. On the Day of Resurrection, Allah will neither speak to them nor purify them. Theirs shall be a painful punishment.

# 182

Such are those who buy error for guidance, and punishment for pardon. How patiently they will be in the Fire.

# 183

That is because Allah has sent down the Book with the truth; those who disagree about it are in extreme dissension.

# 184

Righteousness is not whether you face towards the east or the west. But righteousness is to believe in Allah and the Last Day, in the angels and the Book, and the Prophets, and to give wealth however cherished, to kinsmen, to the orphans, to the needy, to the destitute traveler, and to the beggars, and to ransom the slave; who establish their prayers and pay the obligatory charity; who are true to their promise when they have promised. Who are patient in misfortune and hardship and during the time of courage. Such are the truthful; such are the cautious.

# 185

Believers, retaliation is decreed for you concerning the killed. A free (man) for a free (man), a slave for a slave, and a female for a female. He who is pardoned by his brother, let the ensuing be with kindness, and let the payment be with generosity. This is an alleviation from your Lord and mercy. He who transgresses thereafter shall have a painful punishment.

# 186

O owners of minds, for you in retaliation is life, in order that you be cautious.

# 187

Written for any of you when death arrives, if he leaves behind goods, is the will for his parents and relatives with kindness. This is a duty incumbent on the cautious.

# 188

Then, if anyone changes it after hearing it, the sin shall rest upon those who change it. Allah is Hearing and Knowing.

# 189

He who fears injustice or sin on the part of a testator and brings about a settlement among the parties incurs no guilt. Allah is the Forgiver and the Most Merciful.

# 190

Believers, fasting is decreed for you as it was decreed for those before you; perchance you will be cautious.

# 191

(Fast) a certain number of days, but if any one of you is ill or on a journey let him (fast) a similar number of days later on; and for those who are unable (tofast), there is a ransom the feeding of a needy person. Whosoever volunteers good, it is good for him; but to fast is better for you, if you but knew.

# 192

The month of Ramadan is the month in which the Koran was sent down, a guidance for people, and clear verses of guidance and the criterion. Therefore, whoever of you witnesses the month, let him fast. But he who is ill, or on a journey shall (fast) a similar number (of days) later on. Allah wants ease for you and does not want hardship for you. And that you fulfill the number of days and exalt Allah who has guided you in order that you be thankful.

# 193

When My worshipers ask you about Me, I am near. I answer the supplication of the suppliant when he calls to Me; therefore, let them respond to Me and let them believe in Me, in order that they will be righteous.

# 194

Permitted to you, on the night of the Fast, is the approach to your wives; they are raiments for you, as you are raiments for them. Allah knows that you have been deceiving yourselves. He has accepted and pardoned you. Therefore, you may now touch them and seek what Allah has ordained for you. Eat and drink until the white thread becomes clear to you from a black thread at the dawn. Then resume the fast till nightfall and do not touch them while you cleave to the mosques. These are the Bounds of Allah, do not come near them. As such He makes known His verses to people so that they will be cautious.

# 195

Do not consume your wealth between you in falsehood; neither propose it to judges, in order that you sinfully consume a portion of the people's wealth, while you know.

# 196

They question you about the crescents. Say: 'They are times fixed for people and for the pilgrimage' Righteousness does not consist in entering dwellings from the back. But righteousness is he who wardsoff (sin). Enter dwellings by their doors and fear Allah, so that you will prosper.

# 197

Fight in the way of Allah those who fight against you, but do not aggress. Allah does not love the aggressors.

# 198

Kill them wherever you find them. Drive them out of the places from which they drove you. Dissension is greater than killing. But do not fight them by the Holy Mosque unless they attack you there; if they fight you, kill them. Like this is the recompense of the unbelievers,

# 199

but if they desist, know that Allah is the Forgiver and the Most Merciful.

# 200

Fight against them until there is no dissension, and the religion is for Allah. But if they desist, there shall be no aggression except against the harmdoers.

# 201

The sacred month for the sacred month, prohibitions are (subject to) retaliation. If any one aggresses against you, so aggress against him with the likeness of that which he has aggressed against you. Fear Allah, and know that Allah is with the cautious.

# 202

Spend in the way of Allah and do not cast into destruction with your own hands. Be gooddoers; Allah loves the gooddoers.

# 203

Fulfill the pilgrimage and make the visitation for Allah. If you are prevented, then whatever offering that may be easy. And do not shave your heads until the offerings have reached their destination. But if any of you is ill or suffers from an ailment of the head (scalp), he must pay a ransom either by fasting or by the giving of charity, or by offering a sacrifice. When you are safe, then whosoever enjoys the visitation until the pilgrimage, let his offering be that which may be easy, but if he lacks the means, let him fast three days during the pilgrimage and seven when he has returned, that is, ten days in all. That is for him whose family is not present at the Holy Mosque. And fear Allah and know that He is firm in inflicting punishment.

# 204

The pilgrimage is in the appointed months. (For) whosoever undertakes the pilgrimage there is no approaching (women), neither transgression nor disputing in the pilgrimage. Allah is Aware of whatever good you do. Provide well for yourselves, the best provision is piety. Fear Me, O owners of minds.

# 205

It shall be no offense for you to seek the bounty of your Lord. When you surge on from Arafat, remember Allah as you approach the Holy Mountain of Mash'ar. Remember Him as it is He who guided you though before that you were amongst the astray.

# 206

Then surge on from where the people surge and ask Allah for forgiveness. He is Forgiving and the Most Merciful.

# 207

And when you have fulfilled your sacred duties remember Allah as you remember your forefathers or with deeper reverence. There are some who say: 'Lord, give us good in this world' He shall have no share in the Everlasting Life.

# 208

But there are others who say: 'Lord, give us a merit in the world and good in the Everlasting Life, and save us from the punishment of the Fire'

# 209

These shall have a share of what they have earned. Swift is the reckoning of Allah.

# 210

Remember Allah during counted days. Whosoever hastens on in two days, no sin shall be on him. And if any delay, no sin shall be on him, for he who wardsoff (evil). And fear Allah, and know that you shall be assembled unto Him.

# 211

There is he whose sayings pleases you in this worldly life and uses Allah as a witness for what is in his heart, but he is most stubborn in adversary.

# 212

No sooner does he leave than he hastens about the earth to corrupt there and destroy crops and cattle. Allah does not love corruption.

# 213

When it is said to him: 'Fear Allah' egotism takes him in his sin. Gehenna (Hell) shall be enough for him. How evil a cradling!

# 214

But there are among people he who would give away his life desiring the Pleasure of Allah. Allah is Gentle to His worshipers.

# 215

Believers, all of you, enter the peace and do not follow in satan's footsteps; he is a clear enemy to you.

# 216

If you lapse back after the clear verses that have come to you, know that Allah is the Almighty, the Wise.

# 217

Are they waiting for Allah to come to them in the shadows of the clouds with the angels! Their matter will have been settled then. To Allah shall all things return.

# 218

Ask the Children of Israel how many clear signs We have given them. Whoever changes the Favor of Allah after it has come to him, Allah is Firm in inflicting the punishment.

# 219

For those who disbelieve, the worldly life is decked with all manner of decorations. They scoff at those who believe, but the cautious shall be above them on the Day of Resurrection. Allah gives without count to whom He will.

# 220

The people were one nation. Then Allah sent forth Prophets to give them glad tidings and to warn them; and with them He sent down the Book with the truth, that He might rule between the people in that which they differ. Only those to whom it had been given differed about it after the clear verses had come to them, transgressing between themselves. Then Allah guided those who believed concerning that which they were at variance in the truth, by His permission. Allah guides whom He will to the Straight Path.

# 221

Or did you suppose that you would go to Paradise untouched by that endured by those before you! Affliction and adversity befell them; and they were shaken until the Messenger, and those who believed with him, said: 'When will the victory of Allah come' Is it not so that the victory of Allah is near.

# 222

They will question you about what they should spend (in charity). Say: 'Whatever good you spend is for (your) parents, kinsmen, orphans, the needy, and the destitute traveler. Allah is Aware of whatever good you do'

# 223

(Offensive) fighting is obligatory for you, though it is hateful to you. But you may hate a thing although it is good for you, and may love a thing although it is evil for you. Allah knows, and you do not.

# 224

They ask you about the Sacred Month and fighting in it. Say: 'To fight in this month is a grave (offense); but to bar others from the Path of Allah, and disbelief in Him, and the Holy Mosque, and to expel its inhabitants from it is greater with Allah. Dissension is greater than killing' They will not cease to fight against you until they force you to renounce your religion, if they are able. But whosoever of you recants from his religion and dies an unbeliever, their works shall be annulled in this world and in the Everlasting Life, and those shall be the companions of Hell, and there they shall live for ever.

# 225

But those who believe and those who migrate and struggle in the way of Allah, those, have hope of the Mercy of Allah. Allah is Forgiving and Merciful.

# 226

They ask you about intoxicating drink and gambling. Say: 'There is great sin in both, although they have some benefit for people; but their sin is far greater than their benefit' They ask you what they should spend. Say: 'That which remains' So, Allah makes plain to you His verses, in order that you will reflect

# 227

upon this world and the Everlasting Life. They will question you concerning orphans. Say: 'Doing good for them is best. If you mix their affairs with yours, remember they are your brothers. Allah knows the corrupter from the reformer. If Allah willed He could have brought hardship upon you. He is Almighty and Wise'

# 228

Do not wed idolatresses, until they believe. A believing slavegirl is better than a (free) idolatress, even if she pleases you. And do not wed idolaters, until they believe. A believing slave is better than a (free) idolater, even though he pleases you. Those call to the Fire; but Allah calls to Paradise and pardon by His permission. He makes plain His verses to the people, in order that they will remember.

# 229

They ask you about menstruation. Say: 'It is an injury. Stay away from women during their menstrual periods and do not approach them until they are cleansed. When they have cleansed themselves, then come to them from where Allah has commanded you. Allah loves those who turn to Him in repentance and He loves those who cleanse themselves'

# 230

Women are your planting place (for children); come then to your planting place as you please and forward (good deeds) for your souls, and fear Allah. And know that you shall meet Him. Give glad tidings to the believers.

# 231

Do not make Allah a deterrent through your oaths, that you be righteous, cautious, and reform between people. Surely, Allah is Hearing and Knowing.

# 232

Allah will not call you to account for a slip in your oaths. But He will take you to task for that which is intended in your hearts. Allah is Forgiving and Merciful.

# 233

For those who swear a wait of four months from their women, if they revert, Allah is Forgiving, the Most Merciful.

# 234

But if they resolve on divorce, surely, Allah is the Hearer, the Knower.

# 235

Divorced women shall wait by themselves for three periods. It is unlawful for them, if they believe in Allah and the Last Day, to hide what He has created in their wombs, in which case their husbands would have a better right to restore them should they desire reconciliation. And for them similar to what is due from them with kindness. But men have a degree above them. Allah is Mighty and Wise.

# 236

Divorce is twice, then an honorable keeping or allowed to go with kindness. It is unlawful for you to take from them anything you have given them, unless both fear that they will not be able to keep within the Bounds of Allah; in which case it shall be no offense for either of them if she ransom herself. These are the Bounds of Allah; do not transgress them. Those who transgress the Bounds of Allah are harmdoers.

# 237

If he divorces her (for the third time), she shall not be lawful to him after that until she has wed (not for the purpose of remarrying her former husband) another spouse and then if he divorces her it shall be no offense for either of them to return to each other, if they think that they can keep within the Bounds of Allah. Those are the Bounds of Allah. He makes them plain to people who know.

# 238

When you have divorced women and they have reached the end of their waiting period, either keep them in kindness or let them go with kindness. But you shall not keep them, being harmful, in order to transgress. Whoever does this wrongs himself. Do not take the verses of Allah in mockery. Remember the favor of Allah upon you, and what He sent down to you from the Book and Wisdom to exhort you. Fear Allah and know that He has knowledge of everything.

# 239

When you divorce women, and they have reached their term, do not restrain them from marrying their (future) husbands, when they have agreed together with kindness. That is an exhortation for whosoever of you believes in Allah and the Last Day. That is cleaner and purer for you. Allah knows, and you do not know.

# 240

Mothers shall suckle their children for two years completely, for whoever desires to fulfill the suckling. It is for the father to provide for them and clothe them with kindness. No soul is charged except to its capacity. A mother shall not be harmed for her child, neither a father for his child. And upon the heir is like that. If both desire to wean by mutual consent and consultation, then no guilt shall be on them. And if you desire a wet nurse for your children, then no guilt shall be on you if you hand over what you have given with kindness. And fear Allah, and know that Allah is the Seer of what you do.

# 241

And those of you who die and leave wives behind such wives shall wait by themselves for four months and ten (nights). When they have reached the end of their waiting period, there shall be no offense for you in whatever they choose for themselves kindly. Allah is Aware of what you do.

# 242

No guilt shall be on you in the indication of an engagement to women or what you suppress in yourself. Allah knows that you will remember them; but do not promise them secretly unless you speak kind words (only of indication). And do not resolve on the knot of marriage until the writing has reached its term. And know that Allah knows what is in your hearts, so be cautious of Him. And know that Allah is the Forgiver, the Clement.

# 243

It shall be no offense for you to divorce your wives as long as you have not touched them or obligated a right for them. Provide for them with fairness; the rich according to his means, and the restricted according to his. A right on the gooddoers.

# 244

If you divorce them before you have touched them but after their dowry has been determined, give them half of what you determined, unless they pardon, or he pardons in whose hand is the marriage knot. And if you pardon it is nearer to wardingoff (evil). Do not forget the generosity between each other. Allah is the Seer of what you do.

# 245

And preserve the prayers and the middle prayer, and stand obedient to Allah.

# 246

And if you fear, then (pray) on foot or riding. But when you are safe, then remember Allah, as He has taught you what you did not know.

# 247

Those who die and leave wives behind should bequeath to them a year's maintenance without causing them to leave their homes; but if they leave, no blame shall be attached to you in what they do with themselves kindly. Allah is Mighty and Wise.

# 248

Provision should be made for divorced women with kindness. That is a right on the cautious.

# 249

Like this Allah clarifies to you His verses in order that you understand.

# 250

Haven't you seen those who went out from their homes in their thousands cautious of death? Allah said to them: 'Die' and then He revived them. Surely, Allah is Bountiful to the people, but most people do not thank.

# 251

Fight in the way of Allah. And know that Allah is the Hearer and the Knower.

# 252

Who is he that will lend Allah a good loan! He will multiply it many multiples! Allah grasps and outspreads and to Him you shall be returned.

# 253

Have you not seen the congregation of the Children of Israel who demanded of one of their Prophets after (the death of) Moses? 'Raise up for us a king' they said, 'and we will fight in the way of Allah' He replied: 'Might it be that if fighting is written for you, you will not fight' 'Why shouldn't we fight in the way of Allah' they replied, 'when we and all our children have been driven from our dwellings' Yet, when fighting was written for them all except for a few, turned away. And Allah has knowledge of the harmdoers.

# 254

Their Prophet said to them: 'Allah has raised Saul to be your king' But they replied: 'Should he be given the kingship over us, when we are more deserving of it than he and he has not been given abundant wealth' He said: 'Allah has chosen him over you and increased him with amplitude in knowledge and body. Allah gives His kingship to whom He will. Allah is the Embracer, the Knower'

# 255

Their Prophet said to them: 'The sign of his kingship is the coming of the Ark to you, therein shall be tranquility from your Lord, and a remnant which the House of Moses and the House of Aaron left behind. It will be borne by the angels. That will be a sign for you if you are believers'

# 256

And when Saul marched out with his army, he said: 'Allah will test you with a river. He who drinks from it shall cease to be one of mine but he who does not drink from it, except he who scoops up once with his hand, shall be of mine' But for a few of them, they all drank from it. And when he had crossed it with those who believed, they said: 'We have no power this day against Goliath and his soldiers' But those of them who reckoned they would meet Allah replied: 'Many a small band has, by the permission of Allah, vanquished a mighty army. Allah is with the patient'

# 257

When they appeared to Goliath and his soldiers, they said: 'Lord, pour upon us patience. Make us firm of foot and give us victory against the nation of unbelievers'

# 258

By the permission of Allah, they routed them. David slew Goliath, and Allah bestowed on him the kingship and wisdom, and taught him from that He willed. Had Allah not pushed the people, some by the other, the earth would have been corrupted. But Allah is Bountiful to the worlds.

# 259

These are the verses of Allah. We recite (them) to you in truth, for you (Prophet Muhammad) are one of the Messengers.

# 260

Of these Messengers, We have preferred some above others. To some Allah spoke; and some He raised in rank. We gave (Prophet) Jesus, the son of Mary, clear signs and strengthened him with the Spirit of Purity (Gabriel). Had Allah willed, those who succeeded them would not have fought against one another after the clear verses came to them. But they differed among themselves; some believed, and others disbelieved. Yet had Allah willed, they would not have fought against one another. Allah does whatever He will.

# 261

Believers, spend of what We have given you before that Day arrives when there shall be neither trade, nor friendship, nor intercession. It is the unbelievers who are the harmdoers.

# 262

Allah, there is no god except He, the Living, the Everlasting. Neither dozing, nor sleep overtakes Him. To Him belongs all that is in the heavens and the earth. Who is he that shall intercede with Him except by His permission! He knows what will be before their hands and what was behind them, and they do not comprehend anything of His Knowledge except what He willed. His Seat embraces the heavens and the earth, and the preserving of them does not weary Him. He is the High, the Great.

# 263

There is no compulsion in religion. Righteousness is now distinct from error. He who disbelieves in the idol and believes in Allah has grasped the firmest tie that will never break. Allah is Hearing, Knowing.

# 264

Allah is the Guardian of those who believe. He brings them out from darkness into the light. As for those who disbelieve, their guides are idols, they bring them out from the light into darkness. They are the companions of the Fire and shall live in it for ever.

# 265

Have you not seen he who argued with Abraham about his Lord that Allah had given him the kingship! When Abraham said: 'My Lord is He who revives, and causes to die' He said: 'I revive, and cause to die' Abraham said: 'Allah brings up the sun from the east; so you bring it from the west' Then he who disbelieved became pale. Allah does not guide the nation, the harmdoers.

# 266

Or of him, who, when passing by the ruined village that was fallen on its roofs, remarked: 'How can Allah give life to this after its death' Thereupon Allahcaused him to die, and after a hundred years He revived him. He asked: 'How long have you remained' 'A day' he replied, 'or part of a day' Allah said: 'Rather, you have remained a hundred years. Look at your food and drink; they have not rotted. And look at your donkey (that had died). We will make you a sign to the people. And look at the bones (of your donkey) how We shall revive them and clothe them with flesh' And when it had all become clear to him, he said: 'I know that Allah has power over all things'

# 267

And (remember) when Abraham said: 'Show me, Lord, how You raise the dead' He replied: 'Have you not believed' 'Rather' said Abraham, 'in order that my heart be satisfied' 'Take four birds' said He, 'draw them to you, then set a part of them on every hill, then call them, they will come swiftly to you. Know that Allah is Mighty and Wise'

# 268

The example of those who give their wealth in the way of Allah is like a grain of corn that sprouts seven ears, in every ear a hundred grains. Allah multiplies to whom He will, Allah is the Embracer, the Knower.

# 269

Those who spend their wealth in the way of Allah and do not follow their spending with reproach and insults shall be rewarded by their Lord; they shall have nothing to fear or to regret.

# 270

A kind word and forgiveness is better than charity followed by injury. Allah is the Clement.

# 271

Believers, do not annul your charitable giving with reproach and hurt, like he who spends his wealth to show off to the people and believes neither in Allah nor in the Last Day. His likeness is as a smooth rock covered with dust, if a heavy rain strikes it, it leaves it bare. They have no power over what they have earned. Allah does not guide the nation, the unbelievers.

# 272

But those who give away their wealth with a desire to please Allah and to reassure themselves are like a garden on a hillside, if heavy rain strikes it, it yields up twice its normal crop, and if heavy rain does not strike it, then light rain. Allah is the Seer of what you do.

# 273

Would any one of you, being welladvanced in age with helpless children, wish to have a garden of palmtrees, vines and all manner of fruits watered by running streams struck and burned by a fiery whirlwind? Even so, Allah makes plain to you His signs, in order that you give thought.

# 274

Believers, spend of the good you have earned and of that which We have brought out of the earth for you. And do not intend the bad of it for your spending; while you would never take it yourselves, except you closed an eye on it. Know that Allah is Rich, the Praised.

# 275

satan promises you with poverty and orders you to commit what is indecent. But Allah promises you His Forgiveness and bounty from Him. Allah is the Embracer, the Knower.

# 276

He gives wisdom to whom He will, and he who is given wisdom has been given a lot of good. Yet none will remember except the owners of minds.

# 277

Whatever you spend and whatever vows you make are known to Allah. The harmdoers shall have none to help them.

# 278

If you reveal your charity it is good, but to give charity to the poor in private is better and will acquit you from some of your evil deeds. Allah is Knowledgeable of what you do.

# 279

It is not for you (Prophet Muhammad to cause) their guidance. Allah guides whom He will. Whatever good you spend is for yourselves, provided that you give it desiring the Face of Allah. And whatever good you spend shall be repaid to you in full, you shall not be harmed.

# 280

(Charity is) for the poor who are restrained in the way of Allah, and are unable to journey in the land. The ignorant take them to be rich because of their abstinence. But you can recognize them by their signs. They do not persistently beg people. Whatever good you give is known to Allah.

# 281

Those who spend their wealth by day and by night, in private and in public, their wage is with their Lord, and no fear shall be on them, neither shall they sorrow.

# 282

Those who consume usury shall not rise up (from their tomb) except as he who rises in madness that satan has touched. That is because they say: 'Selling is like usury' Allah has permitted trading and forbidden usury. To whomsoever an exhortation comes from his Lord then he desists, he shall have his past gains, and his matter is with Allah. But whoever reverts shall be among the people of the Fire and shall remain in it for ever.

# 283

Allah effaces usury and nurtures charity. Allah does not love any ungrateful sinner.

# 284

Those who believe and do good works, establish the prayers and pay the obligatory charity, will be rewarded by their Lord and will have nothing to fear or to regret.

# 285

Believers, fear Allah and give up what is still due to you from usury, if you are believers;

# 286

but if you do not, then take notice of war from Allah and His Messenger. Yet, if you repent, you shall have the principal of your wealth. Neither will you harm nor will you be harmed.

# 287

If he should be in hardship, then a postponement until ease; while if you give charity it is better for you if you know.

# 288

Fear the Day when you shall be returned to Allah. And every soul shall be paid in full what it has earned; and they shall not be harmed.

# 289

Believers, when you contract a debt for a fixed period, put it in writing. Let a scribe write it down between you with fairness; no scribe shall refuse to write as Allah has taught him. Therefore, let him write; and let the debtor dictate, fearing Allah his Lord, and do not decrease anything of it. If the debtor is a fool, or weak, or unable to dictate himself, let his guardian dictate for him in fairness. Call to witness two witnesses of your men, if the two are not men, then a man and two women from the witnesses whom you approve; so that if one of the two errs, one of them will remind the other. Whenever witnesses are called upon they must not refuse, and do not be weary to write it down, be it small or large, together with its term. This is more just with Allah; it ensures accuracy in testifying and is the least of doubt. Unless it is present merchandise that you circulate between you; then no guilt shall be on you if you do not write it down and take witnesses when you are selling, and let no harm be done to either scribe or witness. If you do, that is a transgression in you. Fear Allah. Allah teaches you, and Allah has knowledge of everything.

# 290

If you are upon a journey and a scribe cannot be found, then let pledges be taken. If any of you trusts another let the trusted deliver his trust; and let him fear Allah his Lord. And you shall not conceal the testimony. He who conceals it, his heart is sinful. Allah has knowledge of what you do.

# 291

To Allah belongs all that is in the heavens and the earth. Whether you reveal what is in your hearts or hide it Allah will bring you to account for it. He will forgive whom He will and punish whom He will; He has power over all things.

# 292

The Messenger believes in what has been sent down to him from His Lord, and so do the believers. Each believes in Allah and His Angels, His Books, and His Messengers, we do not differentiate between any one of His Messengers. They say: 'We hear and obey. (We ask) Your forgiveness Lord, and to You is the arrival.

# 293

Allah charges no soul except to its capacity. For it is what it has earned, and against it what it has gained. 'Our Lord, do not take us to account if we have forgotten, or made a mistake. Our Lord, do not burden us with a load as You have burdened those before us. Our Lord, do not over burden us with more than we can bear. And pardon us, and forgive us, and have mercy on us. You are our Guide, so give us victory over the nation, the unbelievers.'

# 294

AlifLaamMeem.

# 295

Allah! There is no god except He, the Living, the Everlasting.

# 296

He has sent down to you the Book with the truth, confirming what preceded it; and He has sent down the Torah and the Gospel (of Prophet Jesus which has been lost)

# 297

before, as a guidance for people, and He sent down the Criterion. As for those who disbelieve in the verses of Allah, for them is an intense punishment. Allah is Mighty, Owner of Vengeance.

# 298

Nothing on earth or in heaven is hidden from Allah.

# 299

It is He who shapes you in your mothers' wombs as He wills. There is no god except Him, the Almighty, the Wise.

# 300

It is He who has sent down to you the Book. Some of its verses are precise in meaning they are the foundation of the Book and others obscure. Those whose hearts are swerving with disbelief, follow the obscure desiring sedition and desiring its interpretation, but no one knows its interpretation except Allah. Those who are wellgrounded in knowledge say: 'We believe in it, it is all from our Lord. And none remember except those who are possessed of minds.

# 301

Lord, do not cause our hearts to swerve after You have guided us. Grant us Your Mercy. You are the Embracing Giver.

# 302

Lord, You will surely gather all the people for a Day that will come in which there is no doubt' Allah will not break His promise.

# 303

Those who disbelieve, neither their riches nor their children shall save them from Allah. They shall become the fuel of the Fire.

# 304

Like Pharaoh's people and those before them who belied Our revelations; Allah seized them in their sinfulness. Allah is firm in inflicting punishment.

# 305

Say to those who disbelieve: 'You shall be overcome and gathered into Gehenna (Hell), an evil cradling'

# 306

Indeed, there was a sign for you in the two armies which met on the battlefield. One was fighting in the way of Allah, and another unbelieving. They (the believers) saw with their eyes that they were twice their own number. Allah strengthens with His victory whom He will. Surely, in that there was a lesson for those possessed of eyes.

# 307

Decorated for people are the desires of women, offspring, and of heaped up piles of gold and silver, of pedigree horses, cattle, and sown fields. These are the enjoyments of the worldly life, but with Allah is the best return.

# 308

Say: 'Shall I tell you of a better thing than that? For the cautious with their Lord, theirs shall be Gardens underneath which rivers flow, where they shall live for ever, and purified spouses, and pleasure from Allah' Allah is watching over His worshipers.

# 309

Those are they who say: 'Lord, we believe in You, forgive us our sins and save us from the punishment of the Fire',

# 310

who are patient, truthful, obedient, and charitable, and who ask forgiveness at dawn.

# 311

Allah bears witness that there is no god except He, and so do the angels and the knowledgeable. He upholds justice there is no god except He, the Mighty, the Wise.

# 312

The only religion with Allah is Islam (submission). Those to whom the Book was given disagreed among themselves only after knowledge had been given to them being insolent among themselves. He who disbelieves the verses of Allah indeed Allah is Swift in reckoning.

# 313

If they argue with you, say: 'I have submitted my face to Allah and so have those who follow me' To those who have received the Book (Jews and Nazarenes) and to the ignorant, ask: 'Have you submitted yourselves to Allah' If they became Muslims they were guided, if they turn away, then your only duty is to warn them. Allah is watching over all His worshipers.

# 314

Those who disbelieve the verses of Allah and slay the Prophets unjustly, and slay those who bid to justice give them the glad tidings of a painful punishment!

# 315

Their works shall be annulled in this world and in the Everlasting Life, and there shall be none to help them.

# 316

Have you not seen those who have received a portion of the Book being called to the Book of Allah, that it might judge between them, and some turned away, swerving aside.

# 317

For they say: 'The Fire will not touch us except for a certain number of days' And the lies they forged have deluded them in their religion.

# 318

How will it be when We gather them for a Day in which there is no doubt, when every soul will be given what it has earned and they will not be wronged?

# 319

Say: 'O Allah, Owner of the Kingdom. You give the kingdom to whom You will, and take it away from whom You will, You exalt whom You will and abase whom You will. In Your Hand is good, You have power over all things.

# 320

You cause the night to enter into the day, and the day to enter into the night. You bring forth the living from the dead and the dead from the living. You provide without reckoning to whom You will'

# 321

The believers should not take the unbelievers as guides in preference to the believers he who does this does not belong to Allah in anything, unless you have a fear of them. Allah warns you to be cautious of Him, the arrival is to Allah.

# 322

Say: 'Whether you hide what is in your hearts or reveal it, Allah knows it. He knows all that is in the heavens and earth and has power over all things'

# 323

The Day that every soul shall find what it has done of good brought forward, and what it has done of evil, it will wish if there were only a far space between it and that (Day). Allah warns you to be wary of Him; and Allah is Gentle with His worshipers.

# 324

Say (Prophet Muhammad): 'If you love Allah, follow me and Allah will love you, and forgive your sins. Allah is Forgiving and Merciful'

# 325

Say: 'Obey Allah and the Messenger' But if they turn away, then truly, Allah does not love the unbelievers.

# 326

Allah chose Adam and Noah, the House of Abraham and the House of Imran above all worlds.

# 327

They were the offspring of one another. Allah is Hearing, and Knowing.

# 328

(Remember) when the wife of 'Imran said: 'Lord, I have vowed to You in dedication that which is hidden inside me. Accept this from me. You are the Hearer, the Knower'

# 329

And when she was delivered of her, she said: 'Lord, I have given birth to her, a female' Allah knew of what she had given birth the male is not like the female 'and I have called her Mary. Protect her and all her descendants from satan, the stoned one'

# 330

Her Lord graciously accepted her. He made her grow with a fine upbringing and entrusted her to the care of Zachariah. Whenever Zachariah went to her in the sanctuary, he found that she had provision with her. 'Mary' he said, 'how does this come to you' 'It is from Allah' she answered. Truly, Allah provides whomsoever He will without reckoning.

# 331

Thereupon Zachariah supplicated to his Lord, saying: 'Lord, give me from You a good offspring. You hear all prayers'

# 332

And the angels called out to him when he was standing in the sanctuary worshipping, saying: 'Allah gives you glad tidings of John, who shall confirm a Word from Allah. He shall be a master and chaste, a Prophet and from the righteous'

# 333

He said: 'Lord, how shall I have a son when I am overtaken by old age and my wife is barren' He said: 'Even so, Allah does what He will'

# 334

He said: 'Lord, appoint for me a sign' He said: 'Your sign is that you shall not speak to people except by signs for three days' And remember your Lord abundantly, exalt Him in the evening and at the dawn'

# 335

And when the angels said to Mary: 'Allah has chosen you and purified you. He has chosen you above all women of the worlds.

# 336

Mary, be obedient to your Lord, prostrate and bow with those who bow'

# 337

This is from the news of the unseen. We reveal it to you (Prophet Muhammad). You were not present when they cast their quills to see which of them should look after Mary, nor were you present when they were disputing.

# 338

When the angels said: 'O Mary, Allah gives you glad tidings of a Word (Be) from Him, whose name is Messiah, Jesus, the son of Mary. He shall be honored in this world and in the Everlasting Life and he shall be among those who are close.

# 339

He shall speak to people in his cradle and when he is aged, and shall be among the righteous'

# 340

'Lord' she said, 'how can I bear a child when no human being has touched me' He replied: 'Such is the Will of Allah. He creates whom He will. When He decrees a thing, He only says: "Be," and it is.

# 341

He will teach him the Book, the Wisdom, the Torah and the Gospel,

# 342

to be a Messenger to the Children of Israel, (saying): "I have come to you with a sign from your Lord. From clay, I will create for you the likeness of a bird. I shall breathe into it and by the permission of Allah, it shall be a bird. I shall heal the blind, and the leper, and raise the dead to life by the permission of Allah. I shall tell you what you ate and what you store in your houses. Surely, that will be a sign for you, if you are believers.

# 343

Likewise confirming the Torah that has been before me and to make lawful to you some of the things you have been forbidden. I bring you a sign from your Lord, therefore, fear Allah and obey me.

# 344

Allah is my Lord and your Lord, therefore, worship Him. This is the Straight Path"'

# 345

When (Prophet) Jesus felt their disbelief, he said: 'Who will be my helpers in the way of Allah' The disciples replied: 'We are the helpers of Allah. We believe in Allah. Bear witness that we are submitters (Muslims).

# 346

Lord, we have believed in what You sent down and followed the Messenger. Write us among Your witnesses'

# 347

They devised, and Allah devised. And Allah is the Best Devisor.

# 348

Allah said' (Prophet) Jesus, I will take you to Me and will raise you to Me, and I will purify you from those who disbelieve. I will make your followers (who died before Prophet Muhammad) above those who disbelieve till the Day of Resurrection. Then, to Me you shall all return, and I shall judge between you as to that you were at variance.

# 349

As for those who disbelieve, I will sternly punish them in this world and in the Everlasting Life, there shall be none to help them.

# 350

As for those who believe and do good works, He will pay them their wages in full. Allah does not love the harmdoers.

# 351

This, We recite to you of the verses and the Wise Remembrance.

# 352

Truly, the likeness of (Prophet) Jesus with Allah, is as the likeness of Adam, He created him from dust then He said to him "Be" and he was.

# 353

The truth is from your Lord, therefore, do not be among the doubters.

# 354

Those who dispute with you concerning him after the knowledge has come to you, say: 'Come, let us gather our sons and your sons, our womenfolk and your womenfolk, ourselves and yourselves. Then let us humbly pray, so lay the curse of Allah upon the ones who lie'

# 355

This is indeed the truthful narration. There is no god except Allah. It is Allah who is the Almighty, the Wise.

# 356

If they turn away, Allah knows the evildoers.

# 357

Say: 'People of the Book, let us come to a common word between us and you that we will worship none except Allah, that we will associate none with Him, and that none of us take others for lords besides Allah' If they turn away, say: 'Bear witness that we are Muslims'

# 358

People of the Book, why do you dispute about Abraham when both the Torah and the Gospel were not sent down till after him? Have you no sense?

# 359

Indeed, you have disputed about that which you have knowledge. Why then dispute about that of which you have no knowledge? Allah knows and you do not know.

# 360

No, Abraham was neither a Jew nor a Nazarene. He was of pure faith, a submitter (Muslim). He was never of the idolaters.

# 361

Surely, the people who are nearest to Abraham are those who followed him, and this Prophet (Muhammad), and those who believe. Allah is the Guardian of the believers.

# 362

Some of the People of the Book wish to make you go astray, but they lead none astray except themselves, though they do not sense it.

# 363

People of the Book! Why do you disbelieve the verses of Allah while you are witness?

# 364

People of the Book! Why do you confound truth with falsehood, and knowingly hide the truth?

# 365

Some of the People of the Book say: 'Believe in that which is sent down to those who believe at the beginning of the day and disbelieve at the end of it, so that they will return.

# 366

Believe none except those who follow your own religion' Say: 'The true guidance is the Guidance of Allah that anyone should be given the like of what you have been given, or dispute with you before your Lord' Say: 'Bounty is in the Hand of Allah' He gives it to whomsoever He will. Allah is the Embracer, the Knower.

# 367

He singles out for His Mercy whom He will. And Allah is of abundant bounty.

# 368

Among the People of the Book there are some, who, if you trust him with a Qintar (98, 841. 6 lbs.), will return it to you, and there are others, who, if you trust him with a dinar will not hand it back unless you stand over him, for they say: 'As for the common people, they have no recourse to us' They say lies against Allah while they know.

# 369

Rather, those who keep their promise and fear Allah Allah loves the cautious.

# 370

Those who sell the promise of Allah and their own oaths for a little price shall have no share in the Everlasting Life. Allah will neither speak to them, nor look at them, nor purify them on the Day of Resurrection. Theirs shall be a painful punishment.

# 371

And there is a sect among them who twist their tongues with the Book, so you will think it is from the Book, whereas it is not from the Book. They say: 'This is from Allah' whereas it is not from Allah. And they knowingly tell lies against Allah.

# 372

No human to whom Allah has given the (Holy) Book, Judgement and Prophethood would say to the people: 'Be worshipers of me, other than Allah' But rather, 'Be of the Lord, for that you teach the Book, and in that you have studied'

# 373

Nor would he order you to take the angels and the Prophets for lords, what, would he order you with disbelief after you were submitters (Muslims)!

# 374

And when Allah took the covenant of the Prophets: 'That I have given you of the Book and Wisdom. Then there shall come to you a Messenger (Muhammad) confirming what is with you, you shall believe in him and you shall support him to be victorious, do you agree and take My load on this' They answered: 'We do agree' Allah said: 'Then bear witness, and I will be with you among the witnesses'

# 375

Whosoever turns back after that, they are the transgressors.

# 376

Are they seeking a religion other than that of Allah, and to Him whosoever is in the heavens and the earth has submitted willingly and unwillingly. To Him they shall be returned.

# 377

Say: 'We believe in Allah and in what is sent down to us and in that which was sent down to Abraham, Ishmael, Isaac, Jacob and the tribes, and in that which was given to (Prophets) Moses and Jesus, and the Prophets from their Lord. We do not differentiate between any of them. To Him we are submitters (Muslims)'

# 378

He who chooses a religion other than Islam, it will not be accepted from him, and in the Everlasting Life he will be among the losers.

# 379

How shall Allah guide a people who lapse into disbelief after they believed and bore witness that the Messenger is true, and after receiving clear proofs! Allah does not guide the harmdoers.

# 380

Those, their recompense shall be the curse of Allah, the angels, and all the people

# 381

there they shall live for ever. Their punishment shall not be lightened, nor shall they be given respite.

# 382

Except those who afterwards repent and mend their ways, Allah is Forgiving and the Most Merciful.

# 383

Indeed those who disbelieve after they have believed and increase in disbelief, their repentance shall not be accepted. These are those who are astray.

# 384

As for those who disbelieve and die unbelievers, there shall be not accepted from anyone of them, the whole earth full of gold, if he would ransom himself thereby. Those, for them there is a painful punishment, and none shall help them.

# 385

You shall not attain righteousness until you spend of what you love. Whatever you spend is known to Allah.

# 386

All food was lawful to the Children of Israel except what Israel forbade himself before the Torah had been sent down. Say: 'Bring the Torah and recite it, if you are truthful'

# 387

Those who after this invent lies about Allah are harmdoers.

# 388

Say: 'Allah has said the truth. Follow the Creed of Abraham, he was of pure faith, and not an idolater'

# 389

The first House ever to be built for people was that at Bakkah (Mecca) blessed and a guidance for the worlds.

# 390

In it, there are clear signs; the station where Abraham stood. Whoever enters it let him be safe. Pilgrimage to the House is a duty to Allah for all who can make the journey. And whosoever disbelieves, Allah is Rich, independent of all the worlds.

# 391

Say: 'People of the Book, why do you disbelieve the verses of Allah? Surely, Allah is witness to all that you do'

# 392

Say: 'People of the Book, why do you bar he who believes from the Path of Allah and seek to make it crooked, when you yourselves are witnesses? Allah is not inattentive of what you do'

# 393

Believers, if you obey a sect of those who were given the Book, they will turn you into unbelievers after you have believed.

# 394

How can you disbelieve when the verses of Allah are recited to you and His Messenger is among you! He who holds fast to Allah shall be guided to the Straight Path.

# 395

Believers, fear Allah as He should be feared, and do not die except as Muslims.

# 396

And hold fast to the Bond of Allah, together, and do not scatter. Remember the Favor of Allah bestowed upon you when you were enemies, and how He united your hearts, so that by His Favor you became brothers. And how He saved you from the Pit of Fire when you were on the brink of it. And so Allah makes plain to you His verses, in order that you will be guided.

# 397

Let there be one nation of you that shall call to righteousness, ordering honor, and forbidding dishonor. Those are the prosperous.

# 398

Do not follow the example of those who became divided and differed with one another after clear proofs had come to them. For those, there is a great punishment.

# 399

The Day when faces will be whitened and faces blackened. To those whose faces have become blackened it will be said: 'Did you disbelieve after you had believed? Then taste the punishment for that you disbelieved'

# 400

As for those whose faces will be whitened, they shall be in the Mercy of Allah for ever.

# 401

Such are the verses of Allah, We recite them to you with truth. Allah does not want injustice for the worlds.

# 402

To Allah belongs all that is in the heavens and the earth. To Him all matters shall return.

# 403

You are the best nation ever to be brought forth for people. You order honor and forbid dishonor, and you believe in Allah. Had the People of the Book believed, it would have surely been better for them. Some of them are believers, but most of them are evildoers.

# 404

They will not harm you except a little hurt. And if they fight against you, they will turn their backs. Then they will not be victorious.

# 405

Abasement shall be pitched upon them wherever they are found, except they are in a bond from Allah, and a bond of the people. They have incurred theAnger of Allah and have been humiliated, because they disbelieved the verses of Allah and unjustly slew His Prophets and because they disobeyed and were transgressors.

# 406

Yet they are not all alike. There are among the People of the Book an upstanding nation that recite the verses of Allah (the Koran) throughout the night and prostrate themselves,

# 407

who believe in Allah and the Last Day, who order honor and forbid dishonor and race in good works. These are the righteous.

# 408

Whatever good they do, for them it shall not be denied. Allah knows the cautious.

# 409

As for those who disbelieve, neither their riches nor their children shall help them a thing from Allah. They are the people of the Fire, and there they shall remain for ever.

# 410

The wealth they spend in this worldly life is like a freezing wind that smites the harvest of a people who have wronged themselves and destroys it. Allah has not wronged them, but they wronged themselves.

# 411

Believers, do not take intimates with other than your own. They spare nothing to ruin you, they yearn for you to suffer. Hatred has already shown itself from their mouths, and what their chests conceal is yet greater. Indeed, We have made clear to you the signs, if you understand.

# 412

There you are loving them, and they do not love you. You believe in the entire Book. When they meet you they say: 'We, believe' But when alone, they bite their fingertips at you out of rage. Say: 'Die in your rage! Allah has knowledge of what is in your chests'

# 413

When you are touched with good fortune, they grieve, but when evil befalls you, they rejoice. If you are patient and cautious, their guile will never harm you. Allah encompasses what they do.

# 414

And when you went out at dawn from your family to lodge the believers in their positions for the battle. Allah is Hearing, Knowing.

# 415

Two parties of you were about to fail, though Allah was their Guardian, and in Allah believers put all their trust.

# 416

And Allah most assuredly helped you at Badr when you were humiliated. Therefore, fear Allah, in order that you will give thanks to Him.

# 417

When you said to the believers: 'Is it not enough for you that your Lord should reinforce you with three thousand angels sent down upon you?

# 418

Rather, if you have patience and are cautious, and they suddenly come against you, your Lord will reinforce you with five thousand marked angels'

# 419

Allah did not make this to be except as glad tidings for you, so that your hearts might be comforted. Victory comes only from Allah, the Mighty, the Wise.

# 420

And that He might cut off a part of those who disbelieve or suppress them, so that they will turn back, disappointed.

# 421

No part of the matter is yours whether He turns towards them or punishes them. They are harmdoers.

# 422

To Allah belongs all that is in the heavens and the earth. He forgives whom He will and punishes whom He will. Allah is Forgiving, the Most Merciful.

# 423

Believers, do not consume usury, doubled and redoubled, and fear Allah, in order that you shall prosper.

# 424

Guard yourselves against the Fire prepared for unbelievers.

# 425

Obey Allah and the Messenger in order to be subjected to mercy.

# 426

And hasten to a forgiveness from your Lord and a Paradise as wide as heaven and earth, prepared for the cautious

# 427

who spend in prosperity and in adversity, for those who curb their anger and those who forgive people. And Allah loves the charitable

# 428

and those who, if they commit indecency or wrong themselves remember Allah and ask forgiveness of their sins for who but Allah forgives sins and those who do not persist in what they do while they know.

# 429

Those, their recompense is forgiveness from their Lord and Gardens underneath which rivers flow, where they shall live for ever. How excellent is the wage of those who labor.

# 430

There have been examples before you. Journey in the land and see what was the fate of the liars.

# 431

This is a declaration to the people, a guidance and an admonition to the cautious.

# 432

Do not be weak, neither sorrow while you are the upper ones, if you are believers.

# 433

If a wound touches you, a similar wound already has touched the nation. Such days We alternate between the people so that Allah knows those who believe, and that He will take witnesses from among you, for Allah does not love the harmdoers,

# 434

and so that Allah will examine those who believe and efface the unbelievers.

# 435

Did you suppose that you would enter Paradise without Allah knowing those of you who struggled and who were patient?

# 436

You used to wish for death before you met it, so you have seen it while you were looking.

# 437

Muhammad is not except a Messenger; Messengers have passed away before him. If he dies or is killed, will you turn about on your heels? And he who turns on his heels will not harm Allah a thing. Allah will recompense the thankful.

# 438

It is not for any soul to die except by the permission of Allah a postponed book and he who desires the reward of this world, We shall give him of it, and he who desires the reward of the Everlasting Life, We shall give him of it. And We will recompense the thankful.

# 439

There has been many a Prophet with whom many of the Lord have fought and they did not faint when they were smitten in the way of Allah, neither did they weaken, nor did they humble themselves, and Allah loves the patient.

# 440

Their only words were: 'Lord, forgive us our sins and that we exceeded in our affair, make us firm of foot and give us victory over the unbelievers'

# 441

And Allah gave them the reward of this life, and the best reward of the Everlasting Life. Allah loves the gooddoers.

# 442

Believers, if you obey those who disbelieve they will turn you upon your heels and you will turn to be losers.

# 443

But Allah is your Sponsor. He is the Best of victors.

# 444

We will throw terror into the hearts of those who disbelieve. For that they have associated with Allah that which He did not send down for a proof. Fire shall be their home, evil indeed is the dwellingplace of the harmdoers.

# 445

Allah has been true in His promise towards you when you routed them by His leave, until you lost heart, and quarreled about the matter, and disobeyed, afterHe had shown you that which you loved. Some among you wanted the world, and some among you wanted the Everlasting Life. Then He made you turn away from them in order to test you. But He has forgiven you, for Allah is Bounteous to the believers.

# 446

And when you were going up, and paid no heed for anyone, and the Messenger was calling you from behind; so He rewarded you with grief upon grief that you might not sorrow for what escaped you neither for what smote you. And Allah is Aware of what you do.

# 447

Then, after sorrow, He sent down upon you safety. Slumber overtook a party, while another party cared only for themselves, thinking of Allah thoughts that were not true, the guess of ignorance, saying: 'Have we any say in the affair' Say: 'The entire affair belongs to Allah' They conceal in themselves what they do not disclose to you. They say: 'If we had any say in the affair we should not have been killed here' Say: 'Had you stayed in your homes, those of you for whom slaying was written would have come out to their (death) beds so that Allah might try what was in your chests and that He will examine what is in your hearts' And Allah knows the innermost of the chests.

# 448

Those of you who turned away on the day when the two armies met must have been seduced by satan on account of some of what they had earned. But Allah has pardoned them. He is Forgiving and Clement.

# 449

Believers, do not be as those who disbelieve and say of their brothers when they journey in the land or go of to battle: 'Had they stayed with us, they would not have died, nor would they have been killed' In order that Allah will make that a regret in their hearts. Allah revives and causes to die. He has knowledge of what you do.

# 450

If you should be killed in the way of Allah or die, the Forgiveness and Mercy from Allah would surely be better than all you amass.

# 451

And if you die or are killed, before Allah you shall all be gathered.

# 452

It was by that Mercy of Allah that you (Prophet Muhammad) dealt so leniently with them. Had you been harsh and hardhearted, they would have surely deserted you. Therefore, pardon them and ask forgiveness for them. Take counsel with them in the matter and when you are resolved, put your trust in Allah. Allah loves those who trust.

# 453

If Allah helps you, none can overcome you. If He forsakes you, who then can help you after Him? Therefore, in Allah let the believers put all their trust.

# 454

It is not for a Prophet to defraud, whosoever defrauds shall bring that fraud on the Day of Resurrection. Then, every soul shall be paid in full what it has earned, and they shall not be wronged.

# 455

Is he who follows the pleasure of Allah like he who is laden with the Anger of Allah, Gehenna (Hell) shall be his shelter. Evil shall be his return!

# 456

They are in ranks with Allah. Allah sees what they do.

# 457

Allah has surely been gracious to the believers when He sent among them a Messenger from themselves to recite to them His verses, to purify them, and to teach them the Book and the Wisdom (prophetic sayings), though before that they were in clear error.

# 458

Why, when an affliction hits you and that you had yourselves inflicted twice the like of it, you said: 'How is this' Say: 'This is from your own selves' Surely, Allah has power over all things.

# 459

What hit you the day the two armies met was by the permission of Allah, so that He might know the believers

# 460

and that He might know the hypocrites' When it was said to them: 'Come, fight or repel in the way of Allah' They replied: 'If only we knew how to fight, we would follow you' On that day, they were nearer to disbelief than belief. They said with their mouths what was not in their hearts. And Allah knows what they hide.

# 461

Who said to their brothers and they themselves had stayed behind 'Had they obeyed us, they would not have been killed' Say to them: 'Avert death from yourselves then, if what you say is true'

# 462

You must not think that those who were killed in the way of Allah are dead. But rather, they are alive with their Lord and have been provided for,

# 463

rejoicing in the Bounty that Allah has given to them and having glad tidings in those who remain behind and have not joined them, for no fear shall be on them neither shall they sorrow,

# 464

having glad tidings of a Favor and Bounty from Allah. Allah will not waste the wage of the believers.

# 465

Those who answered Allah and the Messenger after the wound had afflicted them, for those of them who did good and were cautious there is a great wage.

# 466

Those to whom the people said: 'The people have gathered against you, therefore fear them' but it increased them in belief and they said: 'Allah is Sufficient for us. He is the Best Guardian'

# 467

So, they returned with the Favor and Bounty of Allah so evil did not touch them. They followed the pleasure of Allah, and Allah is of Great Bounty.

# 468

That is satan frightening those whom he sponsored. So do not fear them, and fear Me, if you are believers.

# 469

Do not let those who race in disbelief sadden you. They will not harm Allah a thing. Allah does not want to give them a share in the Everlasting Life. For them is a great punishment.

# 470

Those who buy disbelief with belief will not harm Allah a thing, for them there is a painful punishment!

# 471

Do not let those who disbelieve think that what We delay is better for them. Indeed, We delay for them only that they will increase in sin, and for them a humiliating punishment.

# 472

Allah will not leave the believers in that which you are till He shall distinguish the evil from the good. Allah will not let you see the unseen. But Allah chooses from His Messengers whom He will. Therefore, believe in Allah and His Messengers, for if you believe and are cautious there shall be for you a great wage.

# 473

And do not let those who are greedy with what Allah has given them of His Bounty think it is better for them, but rather, it is worse for them. They will be coiled in that which they were greedy on the Day of Resurrection. And to Allah belongs the inheritance of the heavens and the earth. And Allah is Aware of what you do.

# 474

Allah has heard the saying of those who said: 'Allah is poor, but we are rich' We will write down what they have said, and their slaying of the Prophets without right. And We shall say: 'Taste the punishment of the burning'

# 475

That, is for what your hands have forwarded. And Allah is never unjust to His worshipers.

# 476

Those (the Jews) who say: 'Allah has promised us that we do not believe in a Messenger unless he brings to us an offering that fire consumes' Say: 'Indeed Messengers have come to you before me with clear proofs and with that of which you spoke. Why did you kill them, if what you say is true'

# 477

If they belie you (Prophet Muhammad), indeed other Messengers before you were belied who came with clear proofs, and the Psalms, and the Illuminating Book.

# 478

Every soul shall taste death. You shall be paid your wages in full on the Day of Resurrection. Whoever is removed from Hell and is admitted to Paradise shall prosper, for the worldly life is nothing but the enjoyment of delusion.

# 479

You shall be tried in your wealth and yourselves, and you shall hear much hurt from those who were given the Book before you, and from those who are idolaters. But if you are patient and cautious, surely, that is of the firm affairs.

# 480

When Allah took a covenant with those to whom the Book was given, (saying): 'You shall make it clear to the people, and not conceal it. 'But they threw it behind their backs and they bought with it a little price. Evil was what they bought.

# 481

Do not think that those who rejoice in what they have brought and love to be praised for what they have not done do not think they will be secure from the punishment. And for them there is a painful punishment.

# 482

To Allah belongs the Kingdom of the heavens and the earth. Allah has Power over all things.

# 483

Surely, in the creation of the heavens and the earth, and in the alternation of night and day, there are signs for those with minds.

# 484

Those who remember Allah when standing, sitting, and on their sides, and contemplate upon the creation of the heavens and the earth (saying:) 'Lord, You have not created these in falsehood. Exaltations to You! Guard us against the punishment of the Fire.

# 485

Our Lord, whomsoever You admit into the Fire, You will have abased, and the harmdoers shall have no helpers.

# 486

Our Lord, we have heard the caller calling to belief, "Believe in your Lord!" So we believe. Our Lord, forgive us our sins and acquit us of our evil deeds, and take us to You in death with the righteous.

# 487

Our Lord, give us what You promised us by Your Messengers, and do not abase us on the Day of Resurrection. You do not break Your promise'

# 488

And indeed their Lord answers them: 'I do not waste the labor of any that labors among you, male or female you are from each other. And those who emigrated, and were expelled from their houses, those who suffered hurt in My way, and fought, and were killed those I shall surely acquit of their evil deeds, and I shall admit them to Gardens underneath which rivers flow' A reward from Allah, and Allah with Him is the best reward.

# 489

Do not let the coming and going in the land of those who disbelieve delude you;

# 490

a little enjoyment, then, their shelter is in Gehenna (Hell), an evil cradling.

# 491

But for those who fear their Lord, for them shall be Gardens underneath which rivers flow, there they shall live for ever, a (goodly) hosting from Allah, and that which is with Allah is better for the righteous.

# 492

There are some among the People of the Book who believe in Allah, and in what has been sent down to you, and what has been sent down to them, humble to Allah and do not buy with the verses of Allah a little price. Those, their wage shall be with their Lord. Allah is Swift at reckoning.

# 493

Believers, be patient, and race in patience, be steadfast, fear Allah, in order that you will be victorious.

# 494

O people, fear your Lord, who created you from a single soul. From it He created its spouse, and from both of them scattered many men and women. Fear Allah, by whom you ask one another, and (fear) the wombs (lest you sever its relationship). Allah is ever watching over you.

# 495

Give the orphans their wealth. Do not exchange the evil for the good, nor consume their wealth with your wealth. Surely, that is a great sin.

# 496

If you fear that you cannot act justly towards the orphans, then marry such women as seem good to you; two, three, four of them. But if you fear that you cannot do justice, then one only, or, those you possess. It is likelier then that you will not be partial.

# 497

Give women their dowries freely, but if they are pleased to offer you any of it, consume it good and smooth.

# 498

Do not give the (orphaned) fools your wealth with which Allah has entrusted you for (their) support, and provide for them and clothe them from it, and speak to them with kind words.

# 499

And test the orphans until they reach (the age of) marriage. If you perceive in them right judgment, hand over to them their wealth, and do not consume it wastefully, nor hastily before they are grown. And whosoever is rich let him abstain, if poor, let him consume with kindness. When you hand over to them their wealth, take witness over them; it is sufficient that Allah is the Reckoner.

# 500

Men shall have a share in what their parents and kinsmen leave, and women shall have a share in what their parents and kinsmen leave, whether it is little or abundant, it is an obligated share.

# 501

If relatives, orphans, or the needy are present at the division (of the inheritance), provide for them out of it, and speak to them in kind words.

# 502

And let them fear, who, if they themselves left behind weak offspring, would be afraid for them, and let them fear Allah and speak exactly.

# 503

Those who consume the wealth of orphans wrongfully, only consume fire in their bellies, and they shall roast in the Blaze.

# 504

Allah charges you concerning your children, for a male like the share of two females. If they are women, above two, they shall have two thirds of what he left, but if she is one, then to her a half. While for his parents, to each one of the two a sixth of what he left, if he has a child. But if he has no child and his heirs are his parents, his mother shall have a third. If he has siblings, to his mother a sixth after any bequest he had bequeathed, or any debt. Your fathers and your children, you do not know which of them is nearer in benefit to you. This is an obligation from Allah. Surely, Allah is the Knower, the Wise.

# 505

For you half of what your wives leave if they have no child. If they have a child, a quarter of what they leave shall be yours after any bequest she had bequeathed, or any debt. And for them (the females) they shall inherit one quarter of what you leave if you have no child. If you have a child, they shall inherit one eighth, after any bequest you had bequeathed, or any debt. If a man or a woman have no direct heirs, but have a brother or a sister, to each of the two a sixth. If they are more than that, they shall equally share the third, after any bequest that he had bequeathed or any debt without harm. This is an obligation from Allah. He is the Knower, the Clement.

# 506

Such are the Bounds of Allah. He who obeys Allah and His Messenger, He will admit him to Gardens underneath which rivers flow. That is a great wining.

# 507

And he who disobeys Allah and His Messenger and transgresses His Bounds, He will admit him to a Fire and shall live in it for ever. For him, there is a humiliating punishment.

# 508

If any of your women commit indecency, call in four witnesses from among yourselves against them, if they testify, confine them to their houses till death overtakes them or till Allah makes for them a way.

# 509

If two among you commit it punish them both. If they repent and make amends, leave them alone. Allah is the Relenter, the Merciful.

# 510

(Allah accepts) the repentance from only those who commit evil in ignorance and then quickly turn to Him in repentance. Allah will relent towards them. Allah is Knowing, Wise.

# 511

(Allah will accept) no repentance from those who do evil deeds until death comes to one of them, he says: 'Now I repent' Nor those who die unbelieving. For those We have prepared a painful punishment.

# 512

Believers, it is unlawful for you to inherit women forcefully, neither bar them, in order that you go off with part of what you have given them, except when they commit a clear indecency. Live with them honorably. If you hate them, it may be that you hate something which Allah has set in it much good.

# 513

If you wish to take a wife in the place of another wife, and you have given to one a Qintar (98, 841. 6 lbs.) so do not take from it anything. What, will you take it by way of calumny and a clear sin!

# 514

How can you take it back when you have reached one another (sexually) and they have taken from you a strong covenant!

# 515

And do not marry women your fathers married unless it is a thing of the past surely that was an indecency, hated, and a way of evil.

# 516

Forbidden to you are your mothers, your daughters, your sisters, your paternal aunts and maternal aunts, your brother's daughters, your sister's daughters, your mothers who have given suck to you, your suckling sisters, your wives mothers, and your stepdaughters who are in your care from your wives with whom you have lain, but if you have never lain with them it is no fault in you. (Also forbidden to you) are the wives of your sons who are of your loins, and to take to you two sisters together unless it is a thing of the past. Allah is the Forgiver and the Most Merciful.

# 517

And (forbidden to you) are married women, except those whom your right hand owns. Such Allah has written for you. Lawful to you beyond all that, is that you can seek using your wealth in marriage and not fornication. So whatever you have enjoyed from them give them their obligated wage. And there is no fault in you in what ever you mutually agree after the obligation. Allah is the Knower, the Wise.

# 518

If any one of you do not have the affluence to be able marry free believing women, (let him marry) from among the believing women that your right hand owns. Allah knows best your belief, you are from each other. Marry them with the permission of their people and give them their wages (dowry) honorably being women in marriage and chaste, not taking lovers. If, after marriage they commit adultery, they shall be liable to half the punishment of a married (free) woman. That is for those of you who fear fornication, but it is better for you to be patient. Allah is the Forgiver, the Most Merciful.

# 519

Allah wishes to make this clear to you and to guide you along the ways of those who have gone before you, and turns towards you. And Allah is the Knower, the Wise.

# 520

Allah wishes to turn towards you, but those who follow their lower desires wish you to greatly swerve away.

# 521

Allah wishes to lighten for you (the jurisprudence), and humans are created weak.

# 522

Believers, do not consume your wealth among yourselves in falsehood, except there be trading by your mutual agreement. And do not kill yourselves. Allah is the Most Merciful to you.

# 523

But whosoever does that in transgression and wrongfully We shall roast him in the Fire. That is an easy matter for Allah.

# 524

If you avoid the major sins that are forbidden to you, We shall pardon your evil deeds and admit you by an entrance of honor.

# 525

Do not wish for the bounty which Allah has preferred one of you above another. For men is a share of what they earn, and for women is a share of what they earn. Ask Allah of His Bounty. Allah has knowledge of all things.

# 526

To everyone we have made heirs of that which parents and kinsmen leave, and those with whom you have sworn an agreement, so give to them their share. Allah is Witness over everything.

# 527

Men are the maintainers of women for that Allah has preferred in bounty one of them over another, and for that they have spent of their wealth. Righteous women are obedient, guarding in secret that which Allah has guarded. Those from whom you fear rebelliousness, admonish them and desert them in the bed and smack them (without harshness). Then, if they obey you, do not look for any way against them. Allah is High, Great.

# 528

If you fear a breach between them send for an arbiter from his people and an arbiter from her people. If both wish reconciliation, Allah will bring success between them. Allah is the Knower, the Aware.

# 529

Worship Allah and do not associate anything with Him. Be kind to parents and near kinsmen, to the orphans and to the needy, to your neighbor who is your kindred, and to the neighbor at your far side, and the companion at your side, and to the destitute traveler, and to that which your right hands owns. Allah does not love he who is proud and struts,

# 530

(or) those who are greedy and order other people to be greedy, who themselves conceal the bounty that Allah has given them. And We have prepared a humiliating punishment for the unbelievers.

# 531

And those who spend their wealth to showoff to people and neither believe in Allah nor in the Last Day. Whosoever has satan for a companion, he is an evil companion.

# 532

What (harm) could befall them if they believed in Allah and the Last Day and spent of what Allah provided them with? Allah is Knowledgeable of them all.

# 533

Surely, Allah shall not harm so much as the weight of an atom, and if it is a good deed He will double it, and give from His Own a great wage.

# 534

How then shall it be when We bring forward from every nation a witness, and bring you (Prophet Muhammad) to witness against those!

# 535

On that Day those who disbelieved, and have disobeyed the Messenger (Muhammad) will wish that the earth might be leveled with them, and they will not conceal a statement from Allah.

# 536

Believers, do not come close to prayer when you are drunk, until you know what you are saying, nor when you are in a state of impurity, unless you are crossing through the way (prayer area) until you have bathed yourselves. If you are ill or on a journey, or if any of you comes from the toilet or you have touchedwomen, and you cannot find water, so touch pure dust and wipe your faces and your hands. Allah is the Pardoner, the Forgiver.

# 537

Have you not seen those to whom a portion of the Book was given purchasing error and wishing that you should err from the Path?

# 538

But Allah knows best your enemies. It is sufficient that Allah is the Guardian, and it is sufficient that Allah is the Helper.

# 539

Some Jews tampered with the words (altering) their places saying: 'We have heard and we disobey' and 'Hear, without hearing' and 'Observe us (Ra'ina, in Hebrew means evil) ', twisting with their tongues traducing religion. But if they had said: 'We have heard and obey' and 'Hear' and 'Regard us' it would have been better for them, and more upright; but Allah has cursed them for their disbelief, so they do not believe, except a few.

# 540

You, to whom the Book was given, believe in that which We have sent down confirming that which you have, before We obliterate faces and turn them on their backs, or curse them as We cursed the people of the Sabbath. And the command of Allah is done.

# 541

Allah does not forgive (the sin of inventing an) association with Him, but He forgives other (sins) to whomsoever He will. He who associates with Allah has invented a great sin.

# 542

Have you not seen those who exalt themselves? Rather, Allah purifies whom He will and they shall not be wronged a single tissue that covers a date stone.

# 543

Look how they forge lies against Allah, and it is sufficient for a clear sin.

# 544

Have you not seen those to whom a portion of the Book was given believing in (the two statutes of Mecca) jibt and taghout and say to those who disbelieve: 'Those are more guided on the way than those who believe.'

# 545

Those are they whom Allah has cursed and whosoever Allah has cursed, you will not find any helper for him.

# 546

Or, will they have a share in the Kingdom? If so, they will not give the people the pit mark of a date stone.

# 547

Or do they envy people for the Bounty Allah has given them? We gave the family of Abraham the Book and Wisdom, and a great kingdom.

# 548

There are some of them who believed in him (Prophet Muhammad), and some of them that bar from it, and Gehenna (Hell) is sufficient for a Blaze.

# 549

Those who disbelieve Our verses We will roast them in a Fire! As often as their skins are cooked, We exchange their skin with another, in order that they taste the punishment. Surely, Allah is Mighty, the Wise.

# 550

As for those who believe and do good works, We shall admit them to Gardens underneath which rivers flow, they are there for eternity, and for them purified spouses. And We shall admit them into plenteous shade.

# 551

Allah orders you all to hand back trusts to their owners, and when you judge between people you judge with justice. Indeed, the best is the exhortation with which Allah exhorts you. Allah is the Hearer, the Seer.

# 552

Believers, obey Allah and obey the Messenger and those in authority among you. Should you dispute about anything refer it to Allah and the Messenger, if you believe in Allah and the Last Day. That is better and the best interpretation.

# 553

Have you not seen those who claim that they believe in what has been sent down to you and what was sent down before you? They desire to be judged by the idol, although they have been commanded to disbelieve it. But satan desires to lead them astray into far error.

# 554

When it is said to them: 'Come to what Allah has sent down and to the Messenger' you see the hypocrites completely barring the way to you.

# 555

How would it be if some affliction hit them for what their hands have forwarded? Then, they would come to you swearing by Allah, 'We sought only kindness and conciliation'

# 556

Those, Allah knows what is in their hearts, so turn away from them, and exhort them, and say to them penetrating words about themselves.

# 557

We did not send a Messenger except that he should be obeyed, by the permission of Allah. If, when they wronged themselves, they had come to you and asked Allah for forgiveness, and the Messenger had asked for forgiveness for them, they would have found Allah the Turner, the Most Merciful.

# 558

But no, by your Lord, they will not believe you until they make you the judge regarding the disagreement between them, then, they will not find in themselves any discomfort concerning your verdict, and will surrender to you in full submission.

# 559

Had We written for them, saying, 'Slay yourselves' or 'Emerge from your houses' they would not have done so, except a few of them. Yet, if they had done as they were exhorted, it would have been better for them, and stronger in firmness,

# 560

and then We would surely have given them from Our Own, a great wage,

# 561

and guided them to a Straight Path.

# 562

Whosoever obeys Allah, and the Messenger, they are with those whom Allah has favored, the Prophets, the sincere, the martyrs and the righteous, and these are the best company.

# 563

This is the Bounty of Allah. It is sufficient that Allah is the Knowledgeable.

# 564

Believers, take your precautions. March in detachments or march all together.

# 565

Surely, there are among you, he who lingers, then, if an affliction hits you, he would say: 'Allah has favored me, that I was not a martyr with them'

# 566

But, if the Bounty of Allah reaches you, he would surely say as if there had never been any affection between you and him: 'Would that I had been with them! I should have indeed won a great triumph'

# 567

So let those who sell the worldly life for the Everlasting Life fight in the way of Allah, whoever fights in the way of Allah, and is killed or conquers, We shall give him a great wage.

# 568

So why is it, that you do not fight in the way of Allah, and for the abased among men, women, and children who say: 'Our Lord, bring us out from this village whose people are harmdoers, and give to us a guardian from You, and give to us a helper from You.'

# 569

And those who believe fight in the way of Allah, but those who disbelieve fight in the way of the idol. Therefore, fight against those guided by satan. Indeed, satan's guile is always weak.

# 570

Have you not seen those to whom it has been said: 'Restrain your hands, establish your prayers and pay the obligatory charity' Then, as soon as fighting is written for them, there is a party of them fearing people as they would fear Allah, or with stronger fear. And they say: 'Our Lord, why have You written fighting for us, why not postpone us to a near term' Say: 'The pleasure of this life is little. The Everlasting Life is better for the cautious. You shall not be wronged a single tissue (of the fine skin that covers a date stone).

# 571

Wherever you are, death will overtake you, even if you shall be in the fortified, high towers' If bounty reaches them, they say: 'This is from Allah' but when evil hits them, they say: 'This is from you' Say to them: 'All is from Allah' What is the matter with this people that they scarcely understand any statement.

# 572

Whatever good reaches you, it is from Allah, and whatever evil reaches you, it is from yourself. We have sent you (Prophet Muhammad) as a Messenger to humanity. Allah is sufficient for a Witness.

# 573

Whosoever obeys the Messenger, indeed he has obeyed Allah. As for those who turn away, We have not sent you to be their protector.

# 574

They say, 'Obedience' but as soon as they leave you, a party of them hide other than what they said. Allah writes down what they hide. So turn away from them, and rely on Allah. Allah is sufficient for a Guardian.

# 575

Will they not contemplate upon the Koran? If it had been from other than Allah, they would surely have found in it many contradictions.

# 576

When a matter comes to them, be it of security or fear, they broadcast it, whereas if they returned it to the Messenger and to those in authority among them, those of them whose task is to research it would have known it. If it was not for the Bounty of Allah and His Mercy, all but a few of you would have followed satan.

# 577

Therefore, fight in the way of Allah. You are only responsible for yourself. Urge the believers on, in order that Allah may restrain the might of those who disbelieve. Allah is stronger in might, and stronger in punishment.

# 578

Whosoever intercedes with a good intercession shall receive a share of it, and whosoever intercedes with a bad intercession shall receive a portion of it. Allah has power over all things.

# 579

And when you are greeted with a greeting, greet with better than it, or return it. Allah is the Reckoner of all things.

# 580

Allah, there is no god except He. He will gather you to the Resurrection Day, there is no doubt in it. And who is truer in statement than Allah?

# 581

What is the matter with you that you are two parties concerning the hypocrites when Allah has overthrown them for what they earned? Would you desire to guide those whom Allah has caused to be led astray? Whosoever Allah leads astray, you will not find for him a way.

# 582

They wish that you would disbelieve as they disbelieve, and then you would be equal. Therefore, do not take a guide from them until they emigrate in the way of Allah. Then, if they turn back take them and kill them wherever you find them. Do not take them for guides or helpers,

# 583

except those who join to a nation in which there is between you and them a treaty, or they come to you with their chests constricted from fighting you or fighting their nation. Had Allah willed, He would have given them power over you, and then they would have certainly fought you. Therefore, if they keep away from you and do not fight you, offering you peace, then Allah does not make any way for you against them.

# 584

You will find others desiring to be secure from you, and secure from their own nation. Whenever they are called back to sedition, they plunge into it. If they do not keep away from you and offer you peace, and restrain their hands, take them and kill them wherever you find them. Those, over them, We give you clear authority.

# 585

It is not for a believer to kill another believer, except that it is by error. Whosoever kills a believer in error, let him free a believing slave, and ransom is to be handed to his family, unless they forgo being charitable. If he belonged to a people who are your enemies and is a believer then, the setting free of a believing slave. If he belonged to a people in which there is between you and them a treaty, then a ransom is to be handed to his family and the setting free of a believing slave. But, if he does not find (the means) let him fast two consecutive months in repentance to Allah. And Allah is the Knower, the Wise.

# 586

The recompense for he who kills a believer deliberately is Gehenna (Hell), he is eternal there. Allah will be angry with him and will curse him and prepare for him a great punishment.

# 587

Believers, if you are journeying in the way of Allah, do not say to those who offer you peace, until it has been clarified: 'You are not believers' seeking the enjoyment of the worldly life, with Allah there are many spoils. You were like that before, and Allah has been gracious to you. Therefore let it be clarified. Surely, Allah is Aware of what you do.

# 588

Believers who stay behind, having no injury, are not equal to those who fight in the way of Allah with their wealth and their souls. Allah has preferred those who fight with their wealth and their souls a degree above those who stay behind (because of sickness). Yet to each, Allah has promised the most excellent (Paradise). And Allah has preferred those who fought over those who stayed behind with a great wage.

# 589

Ranks from Him, forgiveness and mercy. Allah is the Forgiver, the Most Merciful.

# 590

And the angels who take those who wronged themselves will say: 'In what condition were you' They will reply 'We were oppressed in the land' They (the angels) will say: 'Was not the earth of Allah wide enough for you in order that you migrate in it' Those, their shelter will be Gehenna (Hell), an evil arrival.

# 591

Except the men, women, and children, who, being abased have no means and they are unable to guide themselves to a way.

# 592

Those, Allah may pardon them, He is the Pardoner, the Forgiver.

# 593

Whosoever emigrates in the way of Allah shall find in the land numerous refuges and abundance. Whosoever leaves his house an immigrant to Allah and His Messenger and then death overtakes him, his wage shall have fallen upon Allah. Allah is the Forgiver, the Most Merciful.

# 594

And when you are journeying in the land, there is no fault in you that you shorten the prayer if you fear that those who disbelieve will afflict you. Indeed, the unbelievers are a clear enemy for you.

# 595

When you are with them, and establish the prayer, let a party of them stand with you, and let them take their weapons. After making their prostrations, let them be behind you, and let another party who have not prayed come and pray with you, taking their precautions and their weapons. Those who disbelieve wish that you should be inattentive of your weapons and your baggage, so that they might swoop upon you with one assault. But there is no fault in you if you are harmed by rain, or you are sick to lay aside your weapons, but take your precautions. Allah has prepared a humiliating punishment for the unbelievers.

# 596

When you have established the prayer, remember Allah standing, sitting, and on your sides. Then, when you are secure, establish the prayer, surely, prayer is timely written upon the believer.

# 597

And do not be weak in seeking out the people. If you are suffering, they are also suffering as you are suffering, but you are hoping from Allah that which they do not hope. Allah is the Knower, the Wise.

# 598

Surely, We have sent down to you the Book with the truth, so that you will rule between the people by that Allah has shown you. So do not be an advocate for the traitors.

# 599

And ask the forgiveness of Allah, surely Allah is the Forgiver, the Most Merciful.

# 600

And do not argue on behalf of those who betray themselves, surely, Allah does not love the sinful traitor.

# 601

They seek to hide themselves from the people, but they do not hide themselves from Allah for He is with them when they hide the saying that does not please Him. Allah encompasses what they do.

# 602

There you are, you have argued on their behalf in the worldly life, but who will argue with Allah on their behalf on the Day of Resurrection! Or who will be a guardian for them?

# 603

He who does evil or wrongs himself and then asks forgiveness of Allah will find that Allah is the Forgiver, the Most Merciful.

# 604

Whosoever earns a sin, he only earns it against himself. Allah is the Knower, the Wise.

# 605

Whosoever earns a fault or a sin and casts it upon the innocent, indeed, he bears the slander and a clear sin.

# 606

But for the Favor of Allah to you (Prophet Muhammad) and His Mercy, a party of them intended to lead you astray, but they only lead themselves astray, and they did not harm you a thing. Allah has sent down to you the Book and the Wisdom and He has taught you what you did not know. The Bounty of Allah to you is ever great.

# 607

There is no good in much of their confiding, except for he who bids to charity, honor, or reforms between people. Whosoever does that for the sake of the pleasure of Allah, We shall give him a great wage.

# 608

But whosoever opposes the Messenger after guidance has been made clear to him and follows a path other than that of the believers, We shall let him follow what he has turned to and We shall roast him in Gehenna (Hell) an evil arrival.

# 609

Allah does not forgive (the sin of inventing an) association with Him, but He forgives other sins to whomsoever He will. Whosoever associates with Allah has gone astray in far error.

# 610

Instead of Him they supplicate to none but females, and indeed they supplicate to none except the rebellious satan,

# 611

whom Allah has cursed and he (satan) said: 'Indeed, I will take to myself an appointed portion of Your worshipers,

# 612

and lead them astray. I shall fill them with fancies and order them to cut off the ears of cattle. I shall order them to alter the creation of Allah' Indeed, whosoever chooses satan for a guide, instead of Allah, has surely suffered a clear loss.

# 613

he promises them and fills them with fancies, but what satan promises them is only a delusion.

# 614

Those, their shelter will be Gehenna (Hell), and from it they shall find no refuge.

# 615

But those who believe and do good works We shall admit them to Gardens underneath which rivers flow, and there they shall live for ever, the promise of Allah is true. And who is truer in speech than Allah!

# 616

It is not by your fancies, nor by the fancies of the People of the Book. Whosoever does evil shall be recompensed for it, and he will not find for himself, other than Allah, a guardian or helper.

# 617

But whosoever does good works of righteousness, whether they be a believing male or female, shall enter Paradise, and not be wronged a pit mark of a date stone.

# 618

And who is better in religion than he who submits his face to Allah, being a gooddoer, and follows the Creed of Abraham, pure in faith? Allah took Abraham for a close friend.

# 619

To Allah belongs all that is in the heavens and the earth. Allah encompasses everything.

# 620

They will ask you for a verdict concerning women. Say: "Allah decides for you concerning them, and what has been recited in the Book concerning orphaned women to whom you do not give what is written, and yet desire to marry them, and the abased children, and that you secure justice for orphans. Whatever good you do, Allah has knowledge it.

# 621

If a woman fears hatred or aversion from her husband there is no fault in them if the couple set things right between them, for reconciliation is better. Avarice attends the souls, but if you do what is good and are cautious, surely, Allah is Aware of what you do.

# 622

You will not be able to be just between your women, even though you are eager. Do not be altogether partial so that you leave her as if she were suspended. If you reform and are cautious, Allah is the Forgiver, the Merciful.

# 623

But if they separate, Allah will enrich each of them out from His Vastness. He is the Embracer, the Wise.

# 624

To Allah belongs all that is in the heavens and earth. We have charged those who were given the Book before you and you to fear Allah. If you disbelieve, to Allah belongs all that is in the heavens and the earth. Allah is Rich, the Praised.

# 625

To Allah belongs all that is in heaven and earth. It is sufficient that Allah is a Guardian.

# 626

O people, if He will, He could make you extinct, and bring others. Surely, Allah is Powerful over that.

# 627

Whosoever desires the reward of the world, with Allah is the reward of the world and of the Everlasting Life. Allah is the Hearer, the Seer.

# 628

Believers, be maintainers of justice and witnesses for Allah, even though it is against yourselves, your parents, or your kinsmen, whether he is rich or poor, Allah has more rights over both of them. So do not follow desires, so that you are (not) just. If you twist or turn, Allah is Aware of what you do.

# 629

Believers, believe in Allah and His Messenger (Muhammad), in the Book He has sent down to His Messenger, and in the Book He sent down before. Whosoever disbelieves in Allah, His angels, His Books, His Messengers, and the Last Day, has surely gone astray into far error.

# 630

Those who believe, and then disbelieve, and then believe, and then disbelieve, and increase in disbelief Allah is not to forgive them nor guide them on a way.

# 631

Give glad tidings to the hypocrites that for them there is a painful punishment.

# 632

Those who take unbelievers for guides instead of believers, are they seeking might with them? Surely, the Might altogether belongs to Allah.

# 633

He has sent down upon you in the Book: "When you hear His verses being disbelieved or mocked, do not sit with them until they engage in other talk, or elseyou will surely be like them. Allah will surely gather the hypocrites and unbelievers altogether in Gehenna (Hell).

# 634

(As for) those who lay in wait for you. If a victory comes to you from Allah they say: 'Were we not with you' But if the unbelievers get a portion, they say, 'Were we not mightier than you, and did we not defend you from the believers' Allah will judge between you on the Day of Resurrection. Allah will not grant the unbelievers any way over the believers.

# 635

The hypocrites seek to deceive Allah, but Allah is deceiving them. When they stand up to pray, they stand up lazily, showing off to the people and do not remember Allah, except a little,

# 636

wavering between (belief and disbelief), neither to these nor to those, and whom Allah leads astray, you will not find a way for him.

# 637

Believers, do not take the unbelievers for guides instead of the believers, or do you desire to give Allah a clear authority over you?

# 638

The hypocrites will be in the lowest place of the Fire, you will not find a helper for them.

# 639

But those who repent and mend (their ways), who hold fast to Allah, and make their religion sincerely for Allah they are with the believers, and Allah will certainly give the believers a great wage.

# 640

What, would Allah do with punishing you if you thank and believe! Allah is the Thanker, the Knower.

# 641

Allah does not love the shouting of evil words, except by he who has been wronged. He is the Hearer, the Knower.

# 642

If you display good or hide it, or pardon an evil, surely, Allah is the Pardoner, the Powerful.

# 643

Those who disbelieve in Allah and His Messengers, and desire to divide between Allah and His Messengers (by believing in Him without them), and say, 'We believe in some (Prophets Moses and Jesus), and disbelieve in some of them (such as Prophet Muhammad)' desiring to take between this (and that) a way (between belief and disbelief)

# 644

those in truth are the unbelievers, and We have prepared for the unbelievers a humiliating punishment.

# 645

And those who believe in Allah, and His Messengers and do not divide between any of them; to those, We shall surely give them their wages. Allah is the Forgiver, the Most Merciful.

# 646

The People of the Book ask you to bring down upon them a Book from heaven. Of Moses they asked greater than that, they said to him: 'Show us Allah openly' And a thunderbolt took them for their evil doing. Then they took to themselves the calf, after the clear proofs had come to them, yet We forgave that and We gave Moses clear authority.

# 647

And We raised the Mount above them, and took covenant with them, and We said: 'Enter in at the gate, prostrating', and We said to them, 'Do not transgress the Sabbath', and We took from them a solemn covenant.

# 648

So, for their breaking of the covenant, and disbelieving the verses of Allah, and killing their Prophets without right and for saying, 'Our hearts are covered' no, but Allah has sealed them for their disbelief, so, except for a few, they do not believe.

# 649

Also for their disbelief and their saying about Mary a great calumny,

# 650

and for their saying, 'We killed the Messiah, Jesus the son of Mary, the Messenger (and Prophet) of Allah' They did not kill him, nor did they crucify him, but to them, he (the crucified) had been given the look (of Prophet Jesus). Those who differ concerning him (Prophet Jesus) are surely in doubt regarding him, they have no knowledge of him, except the following of supposition, and (it is) a certainty they did not kill him.

# 651

Rather, Allah raised him up to Him. Allah is Almighty, the Wise.

# 652

There is not one of the People of the Book but will surely believe in him (Prophet Jesus) before his death, and on the Day of Resurrection he will be a witness against them.

# 653

And for the harmdoing of those of Jewry, We have forbidden them the good things that were permitted to them, and also for their barring many from the way of Allah.

# 654

And for their taking of usury, that they were prohibited, and consuming the wealth of people in falsehood, for the unbelievers among them We have prepared a painful punishment.

# 655

But those of them that are firmly rooted in knowledge, and the believers believing in what has been sent down to you (Prophet Muhammad), and what was sent down before you, and those who establish the prayer and pay the obligatory charity, and those who believe in Allah and the Last Day to those, We surely give a great wage.

# 656

We have revealed to you as We revealed to Noah and to the Prophets after him, and We revealed to (Prophets) Abraham, Ishmael, Isaac, Jacob and the tribes, Jesus, Job, Jonah, Aaron, and Solomon, and We gave to David the Psalms.

# 657

And Messengers of whom We have narrated to you before, and Messengers of whom We did not narrate to you. Certainly, Allah talked to Moses.

# 658

Messengers bearing glad tidings and warning, so that the people will have no argument against Allah, after the Messengers. Allah is the Almighty, the Wise.

# 659

But Allah bears witness for that which He has sent down to you. He has sent it down with His Knowledge, and the angels bear witness, it is sufficient that Allah is the Witness.

# 660

Those who disbelieve and bar from the way of Allah have strayed into far error.

# 661

Surely, those who disbelieve and have done harm. Allah would not forgive them, neither guide them to a Path,

# 662

except the road to Gehenna, there they are eternal, and for Allah that is an easy matter.

# 663

O people, the Messenger (Prophet Muhammad) has come to you with the truth from your Lord, so believe, it is better for you. If you disbelieve, to Allah belongs all that is in the heavens and the earth. And Allah is the Knower, the Wise.

# 664

People of the Book, do not exaggerate your religion. Do not say about Allah except the truth. Indeed, the Messiah, Jesus son of Mary, is only a Messenger (and Prophet) of Allah, and His Word (Be) which He gave to Mary, and a (created) spirit by Him. So believe in Allah and His Messengers and do not say: 'Trinity. 'Refrain, it is better for you. Allah is only One God. Exaltations to Him that He should have son! To Him belongs all that is in the heavens and in the earth, it is sufficient that Allah is the Guardian.

# 665

The Messiah would not despise being a worshiper of Allah, nor would the angels who are near. Whosoever despises worshipping Him, and becomes proud, He will surely assemble them all to Him.

# 666

As for those who believe and did good deeds, He will pay them in full their wages, and He will increase them from His Bounty. As for those who despise and became proud, He will punish them with a painful punishment, and they will find neither a guide nor a helper for themselves, other than Allah.

# 667

O people, a proof has come to you from your Lord, and We have sent down to you a clear light.

# 668

Those who believe in Allah and hold fast to Him, He will surely admit them to a Mercy and Bounty from Him, and He will guide them to Him on a Straight Path.

# 669

They will ask you for a verdict. Say: 'Allah rules for you concerning the indirect heir (alkalalah which is), if a person dies, having no children, but he has a sister, she shall receive half of what he leaves, and he is her heir if she has no children. If there are two sisters, they shall receive twothirds of what he leaves, if there are siblings, men and women, for a male like the share of two females. Allah clarifies to you, lest you go astray, Allah is Knowledgeable of everything.

# 670

Believers, fulfill your obligations. It is lawful for you (to eat the flesh of) the beast among cattle other than that which is recited to you, hunting is forbidden while you are on pilgrimage. Allah decrees what He will.

# 671

Believers, do not violate the rites of Allah, or the sacred month, or the offerings, or (those hung with) necklaces, nor those whose aim is to the Sacred House seeking from their Lord bounty and pleasure. Once your pilgrimage has ended, you are free to hunt. Do not allow your hatred for a nation who would bar you from the Holy Mosque to lead you to transgress. And cooperate in righteousness and warding off (evil), and do not cooperate in sinfulness and transgression. Have fear of Allah, for Allah is Stern in retribution.

# 672

You are forbidden (to consume) the dead, blood and the flesh of swine; also flesh dedicated to any other than Allah, the flesh of strangled (animals) and of those beaten, that which is killed by falling, gored to death, mangled by beasts of prey, unless you find it (still alive) and slaughter it; also of animals sacrificed on stones (to idols). (You are forbidden) to seek division by the arrows, that is debauchery. Those who disbelieve have this day despaired of your religion. Do not fear them, but fear Me. This day I have perfected your religion for you and completed My favor to you. I have approved Islam to be your religion. (As for) he who does not intend to commit a sin but is constrained by hunger to eat of what is forbidden, then surely Allah is Forgiving, Merciful.

# 673

They ask you what is lawful to them. Say: 'The good things are lawful to you, as well as that which you have taught the birds and beasts of prey to catch, teaching them of what Allah has taught you. Eat of what they catch for you, pronouncing upon it the Name of Allah. And fear Allah, Allah is Swift at reckoning'

# 674

The good things have this day been made lawful to you. The food of those to whom the Book was given is lawful to you, and your food is lawful to them. Lawful to you (in marriage) are the free believing women and the free women from among those who were given the Book before you, provided that you give them their dowries in marriage, neither committing fornication nor taking them as mistresses. Whosoever denies the belief, his labors will be annulled. In the Everlasting Life he is of the losers.

# 675

Believers, when you rise to pray wash your faces and your hands as far as the elbow, and wipe your heads and (wash) your feet to the ankle. If you are in a state of impurity, cleanse yourselves. But if you are sick or traveling, or, if when you have just relieved yourselves or had intercourse with women and you cannot find water, touch the clean surface of the earth and rub your hands and faces with it. Allah does not wish to burden you, He seeks only to purify you and to complete His Favor to you in order that you may thank.

# 676

Remember the favor of Allah upon you, and the covenant with which He bound you when you said: 'We hear and obey' Have fear of Allah. Allah is the Knower of the innermost of the chests'

# 677

Believers, be dutiful to Allah and bearers of just witness. Do not allow your hatred for other people to turn you away from justice. Deal justly; it is nearer to piety. Have fear of Allah; Allah is Aware of what you do.

# 678

Allah has promised those who believe and do good works forgiveness and a great reward.

# 679

As for those who disbelieve and belie Our verses, they shall become the companions of Hell.

# 680

Believers, remember the favor which Allah bestowed upon you when certain people were about to stretch their hands towards you, but He restrained them. Have fear of Allah. In Allah let the believers put their trust.

# 681

Allah made a covenant with the Children of Israel and raised among them twelve chieftains. He said: 'I shall be with you and if you establish the prayers and pay the obligatory charity; if you believe in My Messengers and assist them and give Allah a generous loan, I shall forgive you your sins and admit you to Gardens underneath which rivers flow. Whosoever amongst you disbelieves after that, he indeed has strayed from the Straight Path'

# 682

But because they broke their covenant, We cursed them and hardened their hearts. They changed the Words from their places and have forgotten a portion of what they were reminded. Except for a few, you will always find treachery from them, yet pardon them, and forgive; indeed Allah loves the gooddoers.

# 683

With those who said they were Nazarenes, We made a Covenant, but they have forgotten much of what they were reminded. Therefore, We stirred among them enmity and hatred till the Day of Resurrection when Allah will inform them of all that they have done.

# 684

People of the Book! Our Messenger (Muhammad) has come to clarify to you much of what you have hidden of the Book, and to forgive you much. A light has come to you from Allah and a Clear Book,

# 685

with which Allah guides those who seek His pleasure to the Paths of Peace. By His permission He takes them out from darkness to the light, and guides them to a Straight Path.

# 686

Those who say that Allah is the Messiah, son of Mary are indeed those who disbelieved. Say: 'Who then could prevent any thing from Allah, if He willed to destroy the Messiah, son of Mary, together with his mother and all the people of the earth? For Allah is the kingdom of the heavens and the earth and all that lies between them. He creates what He will and has power over all things'

# 687

The Jews and the Nazarenes say: 'We are the children of Allah and His loved ones' Say: 'Why then does He punish you for your sins? Surely, you are mortals amongst what He created. He forgives whom He will, and punishes whom He will. For Allah is the Kingdom of the heavens and the earth, and all that is between them. All shall return to Him'

# 688

People of the Book! After an interval during which there were no Messengers, Our Messenger (Muhammad) has come to clarify (your religion) to you, lest you should say: 'No bearer of glad tidings or a warner has come to us' Indeed, there has come to you a bearer of glad tidings and a warner. Allah has power over all things.

# 689

(Remember) when Moses said to his people. 'Remember, my people, the favors which Allah has bestowed upon you. He has raised up Prophets among you, made you kings, and given you that which He has not given to any one of the worlds.

# 690

Enter, my people, the Holy Land which Allah has written for you. Do not turn back in your footsteps, lest you shall turn to be losers'

# 691

'Moses' they replied, 'therein is a nation of giants. We will not enter until they depart from it; if they depart from it only then shall we enter'

# 692

Thereupon, two pious men whom Allah had favored said: 'Go in to them through the gate, and if you enter you shall surely be victorious. In Allah put your trust, if you are believers'

# 693

They said: 'Moses, we will never go in so long as they are in it. Go, you and your Lord, to fight. We will stay here'

# 694

He said: 'Lord, I have none but myself and my brother. Set a barrier between us and the wicked people'

# 695

He said: 'They shall be forbidden this land for forty years, during which time they shall wander (homeless) on the earth. Do not grieve for these wicked people.'

# 696

Recite to them in all truth the news of Adam's two sons; how they each made an offering, and how the offering of the one was accepted while that of the other was not. He said: 'I will surely kill you' (The other) said: 'Allah accepts only from the righteous.

# 697

If you stretch your hand to kill me, I shall not stretch mine to kill you; for I fear Allah, the Lord of the Worlds.

# 698

I would rather you bear my sin and your sin and become among the inhabitants of Hell. Such is the recompense of the harmdoers'

# 699

His soul made it seem fair to him to slay his brother; he killed him and became one of the lost.

# 700

Then Allah sent down a crow, which dug the earth to show him how to bury the naked corpse of his brother. 'Alas' he said, 'am I unable to be like this crow and so I bury my brother's naked corpse' And he became among those who regret.

# 701

That was why We wrote for the Children of Israel that who ever killed a soul, except for a soul slain, or for sedition in the earth, it should be considered as though he had killed all mankind; and that who ever saved it should be regarded as though he had saved all mankind. Our Messengers brought them proofs; then many of them thereafter commit excesses in the earth.

# 702

The recompense of those who make war against Allah and His Messenger and spread corruption in the land is that they are to be killed or crucified, or have their hand and a foot cut off on opposite sides, or be expelled from the land. For them is shame in this world and a great punishment in the Everlasting Life;

# 703

except those who repent before you have power over them. For you must know that Allah is Forgiving, the Most Merciful.

# 704

Believers, have fear of Allah and seek the means by which you come to Him. Struggle in His Way in order that you are prosperous.

# 705

As for those who disbelieve, if they possessed all that the earth contains and as much besides to ransom themselves from the punishment of the Day of Resurrection, it shall not be accepted from them. Theirs shall be a painful punishment.

# 706

They will wish to get out of the Fire, but they shall not, theirs shall be a lasting punishment.

# 707

As for the man or woman who is guilty of theft, recompense them by cutting off their hands for their crimes. That is the punishment from Allah. Allah is Mighty, Wise.

# 708

But whoever repents and mends his ways after committing evil shall be pardoned by Allah. Allah is Forgiving, Most Merciful.

# 709

Do you not know that to Allah belongs the Kingdom of the heavens and the earth? He punishes whom He will and forgives whom He will. Allah has power over all things.

# 710

O Messenger, do not grieve for those who race into disbelief; those who say with their mouth: 'We believe' yet their hearts did not believe, and the Jews who listen to lies and listen to other nations who have not come to you. They pervert the words in their places and say: 'If you are given this, accept it; if not, then beware' Whomsoever Allah wishes to try, you will not own anything with Allah concerning him. For those whose hearts Allah does not will to purify shall be disgrace in this world and a grievous punishment in the Everlasting Life.

# 711

They are listeners to lies and devourers of the unlawful. If they come to you, judge between them or turn away from them. If you avoid them they cannot harm you in anything; but if you judge, judge between them with fairness. Allah loves the just.

# 712

But how will they come to you for judgment when they already have the Torah in which is the judgement of Allah? Then they turn away after that; those are not believers.

# 713

We have sent down the Torah in which there is guidance and light by which the submissive prophets judged the Jews, as did the rabbis and those of their Lord, guarding what they were required to of the Book of Allah, and for which they were witness. Do not fear people, but fear Me. And, do not take a small price for My verses. Those who do not judge with what Allah has sent down are the unbelievers.

# 714

We have written for them a life for a life, an eye for an eye, a nose for a nose, an ear for an ear, a tooth for a tooth, and for wounds equal retaliation, but whosoever forgoes it as a freewill offering, it will be an expiation for him. Whoever does not judge according to what Allah has sent down are the harmdoers.

# 715

And We sent, following in their footsteps (Prophet) Jesus, the son of Mary, confirming that which was before him in the Torah, and gave him the Gospel, in which there is guidance and light, confirming that which was before him in the Torah, a guide and an admonition to the cautious.

# 716

Therefore, let the people of Gospel judge in accordance with that which Allah has sent in it. Those who do not judge according to that which Allah has sent down are the evildoers.

# 717

And to you We have revealed the Book with the truth confirming the Book that was revealed before it, and a guardian over it. Therefore, give judgment among them in accordance to what Allah has sent down and do not yield to their fancies from the truth that has come to you. We have ordained a law and a Path for each of you. Had Allah willed, He could have made you one nation but that He might try you by that which He has bestowed upon you. Race with one another in good works, to Allah you shall all return and He will declare to you what you were at variance.

# 718

And judge among them in accordance to that which Allah has sent down and do not be led by their desires. Take heed lest they should turn you away from a part of that which Allah has sent to you. If they reject your judgment, know that Allah wants to scourge them for some of their sins. Many of the people are wrongdoers.

# 719

Is it pagan laws that they wish to be judged by? Who is a better judge than Allah for a nation whose belief is firm?

# 720

Believers, take neither Jews nor Nazarenes for your guides. They are guides of one another. Whosoever of you takes them for a guide shall become one of their number. Allah does not guide the wrongdoers.

# 721

You see those in whose hearts is sickness racing with one another to come to them. They say: 'We fear lest a change of fortune should befall us' May Allah bring victory or make known His ordinance, then, they shall regret what they had hidden in themselves.

# 722

Then the believers will say: 'Are those (the ones) who solemnly swore by Allah that they would stand by you' Their works will be annulled and they shall be the losers.

# 723

Believers, whosoever of you turns from his religion, Allah will bring a nation whom He loves and they love Him, humble towards the believers and stern towards the unbelievers, striving for the Path of Allah and fearless of anyone's blame. Such is the Bounty of Allah; He bestows it on whom He will. He is the Embracer, the Knower.

# 724

Your guide is only Allah, His Messenger, and the believers; those who establish the prayer, pay their obligatory charity, and bow down (in worship).

# 725

Whosoever takes Allah for a guide, His Messenger, and the believers the party of Allah is the victor.

# 726

Believers, do not take as guides those who were given the Book before you who have made of your religion a jest and a pastime, nor the unbelievers. Have fear of Allah, if you are believers.

# 727

When you call to prayer, they treat it as a jest and a pastime. That is because they are a people who have no understanding.

# 728

Say: 'People of the Book, do you blame us for any reason other than that we believe in Allah and in what has been sent down to us, and what was sent down before us, and that most of you are evildoers'

# 729

Say: 'Shall I tell you who will receive a worse recompense from Allah than that? Those whom Allah has cursed and with whom He is angry, and made some of them apes and swine, and those who worship the devil. The place of these is worse, and they have strayed further from the Right Path'

# 730

When they came to you they said: 'We are believers' Indeed, they have entered with disbelief, and so they have departed with it; Allah knows best what they conceal.

# 731

You see many of them race with one another in sin and transgression and devour the unlawful. Evil is what they do.

# 732

Do those of the Lord and the rabbis not forbid them to speak sinfully and to devour what is unlawful? Evil indeed is what they were doing.

# 733

The Jews say: 'The Hand of Allah is chained' Their own hands are chained! And they are cursed for what they said! Rather, His Hands are both outstretched, He spends as He will. That which Allah has sent down to you will surely increase the tyranny and disbelief of many of them. We have stirred among them enmity and hatred up until the Day of Resurrection. Whenever they kindle the fire of war, Allah extinguishes it. They spread corruption in the land, and Allah does not love those who corrupt.

# 734

If the People of the Book had believed and kept from evil, We would pardon them their sins and admit them to the Gardens of Delight.

# 735

If they had established the Torah and the Gospel and what was sent down to them from their Lord they would be eating from above them and from beneath their feet. Some of them are a righteous nation; but many of them evil is what they do.

# 736

O Messenger, deliver what is sent down to you from your Lord; if you do not, you will not have conveyed His Message. Allah protects you from the people. Allah does not guide the nation, the unbelievers.

# 737

Say: 'People of the Book, you are not upon anything until you establish the Torah and the Gospel and that which is sent down to you from your Lord' And that which is sent down to you (Prophet Muhammad) from your Lord will surely increase the tyranny and disbelief of many of them. But do not grieve for the unbelieving nation.

# 738

Those who believe, Jews, Sabaeans, and Nazarenes whoever believes in Allah and the Last Day and does good shall neither fear, nor shall they sorrow (as long as they do not reject any of the prophets).

# 739

We took a covenant with the Children of Israel and sent forth Messengers to them. But whenever a Messenger came to them with that which did not suit their fancies they belied some and killed others.

# 740

They thought there would be no trial; so they were blind and deaf. Then Allah turned towards them; then again many of them were blind and deaf. And Allah is the Seer of what they do.

# 741

The unbelievers are those who say: 'Allah is the Messiah, the son of Mary' But the Messiah said: 'Children of Israel, worship Allah, my Lord and your Lord. 'He who associates anything with Allah, Allah has indeed forbidden Paradise to him, and his abode shall be in the Fire. The harmdoers shall have no helpers.

# 742

Indeed those who say: 'Allah is the third of the Trinity' became unbelievers. There is but One God. If they do not desist in what they say, a painful punishment will afflict those of them that disbelieve.

# 743

Will they not turn to Allah in repentance and ask His forgiveness? He is Forgiving, Merciful.

# 744

The Messiah, the son of Mary, was not except a Messenger, other Messengers had gone before him. His mother was in the state of sincerity, they both ate food. See how We make plain to them Our signs. Then, see how perverted they are.

# 745

Say: 'Will you worship instead of Allah that which owns neither harm, nor benefit for you? Allah is the Hearer, Knower'

# 746

Say: 'People of the Book! Do not exaggerate your religion, other than the truth, and do not follow the desires of a people who went astray before, and led many astray, and, (once again) have gone astray from the Straight Path'

# 747

Those who disbelieved of the Children of Israel were cursed by the tongue of (Prophets) David and Jesus, the son of Mary, because they disobeyed and transgressed.

# 748

They did not forbid one another from the wrongdoing they were committing. Evil is what they were doing.

# 749

You see many of them taking the unbelievers as guides. Evil is that to which their souls forwarded them, that Allah is angered against them, and in the punishment they shall live for ever.

# 750

Had they believed in Allah and the Prophet (Muhammad) and that which is sent down to him, they would not have taken them as guides. But many of them are evildoers.

# 751

You will find that the most people in enmity to the believers are the Jews and idolaters, and that the nearest in affection to the believers are those who say: 'We are Nazarenes' That is because amongst them there are priests and monks; and because they are not proud.

# 752

When they listen to that which was sent down to the Messenger, you will see their eyes fill with tears as they recognize its truth. They say: 'Lord, we believe. Write us among the witnesses.

# 753

Why should we not believe in Allah and in the truth that has come down to us? Why should we not hope for admission among the righteous'

# 754

For their words Allah has rewarded them with Gardens underneath which rivers flow, where they shall live for ever. Such is the recompense of the righteous.

# 755

But those who disbelieve and belie Our verses shall be the companions of Hell.

# 756

Believers, do not forbid the good things that Allah has made lawful to you. Do not transgress; Allah does not love the transgressors.

# 757

Eat of the lawful and good things with which Allah has provided you. Have fear of Allah in whom you believe.

# 758

Allah will not take you to account for a slip in your oaths. But He will take you to account for the oaths which you solemnly swear. Its expiation is the feeding of ten needy (people) with such food as you normally offer to your own people; or the clothing of them; or the freeing of a slave. He who does not have must fast three days. That is the expiation of your oaths when you have sworn; but keep your oaths. Allah makes plain to you His verses, in order that you are thankful.

# 759

Believers, wine and gambling, idols and divining arrows are abominations from the work of satan. Avoid them, in order that you prosper.

# 760

satan seeks to stir up enmity and hatred among you by means of wine and gambling, and to bar you from the remembrance of Allah and from praying. Will you not abstain from them?

# 761

Obey Allah, and obey the Messenger. Beware; if you give no heed, know that Our Messenger's duty is only to give the clear delivery.

# 762

No blame shall be attached to those who believe and did good works in regard to any food they have eaten, so long as they ward off (the forbidden) and believe, and do good deeds, then they fear and believe, and again, so long as they fear and do fine deeds. Allah loves the generous.

# 763

Believers, Allah will test you by means of some hunting which you can catch with your hands and with your spears, in order that Allah knows those who fear Him in private. For he who transgresses thereafter shall be a painful punishment.

# 764

O believers, do not kill the hunted while you are in pilgrim sanctity. Whosoever of you kills it willfully there shall be a recompense, the like of what he has slain from cattle as shall be judged by two just men among you, an offering to reach the Ka'bah; or expiation food for needy persons or the equivalent of that in fasting, so that he may taste the weight of the recompense of his action. Allah has pardoned what is past; but whoever offends again, Allah will take vengeance on him. Allah is the Almighty, Owner of Vengeance.

# 765

Made lawful to you is the fished of the sea and its food, an enjoyment for you and for travelers. But you are forbidden the hunted of the land whilst you are on pilgrimage. Have fear of Allah, before whom you shall all be assembled.

# 766

Allah has made the Ka'bah the Sacred House, as an establishment for people; and the Sacred Month, and the offering, and the necklaces, in order that you know that Allah has knowledge of all that is in the heavens and the earth; and that Allah has knowledge of all things.

# 767

Know that Allah is Stern in retribution, and that Allah is the Forgiver and the Most Merciful.

# 768

The duty of the Messenger is only the delivery (of the Message). Allah knows what you reveal and what you hide.

# 769

Say: 'The evil and the good are not alike, even if the abundance of evil pleases you. Have fear of Allah, you who are possessed of minds, in order that you prosper'

# 770

Believers, do not ask about things that if they appeared to you, would only upset you; but if you ask about them when the Koran is being sent down, they shall be made plain to you. Allah will pardon it; Allah is Forgiving, Clement.

# 771

A nation asked about them before you, and with it they became unbelievers.

# 772

Allah has not made cattle, a slit eared shecamel, nor a freely grazing shecamel, nor a shecamel that bore twins, nor an uncastrated camel (dedicated to idols), but those who disbelieve invent lies against Allah. Most of them do not understand.

# 773

When it is said to them: 'Come to that which Allah has sent down, and to the Messenger' they reply: 'Sufficient for us is what we have found our fathers upon' even though their fathers knew nothing and were not guided.

# 774

Believers, look after your own souls, he who goes astray cannot harm you if you are guided. You shall all return to Allah, and He will inform you of what you have done.

# 775

Believers, if you are traveling in the land and the affliction of death befalls you, at the bequeathing testimony shall be two just men from among you, or two others from other than you. You shall detain both after the prayer, and they shall swear by Allah if you are doubtful: 'We will not sell it for a price, even though it were a near kinsmen, nor will we hide the testimony of Allah, because then we would surely be among the sinful'

# 776

But if it is discovered that both of them have been subject to sinning, then two others shall stand in their place, these being the nearest of those most concerned, and they shall swear by Allah: 'Our testimony is truer than their testimony, and we have not transgressed, because then we would surely be among the harmdoers'

# 777

So it is likelier that they will bear testimony in proper form, or else they will be afraid that oaths may be rejected after their oaths. Fear Allah, and listen; Allah does not guide the people of the evildoers.

# 778

On a Day, Allah will gather all the Messengers and ask them: 'How were you answered' They will reply: 'We have no knowledge, You are the Knower of the unseen'

# 779

When Allah said: '(Prophet) Jesus, son of Mary, remember the favor upon you and on your mother; how I strengthened you with the Holy Spirit (Gabriel), to speak to people in your cradle and of age (when he descends and dies); how I taught you the Book and Wisdom, the Torah and the Gospel; and how, by My permission, you fashioned from clay the likeness of a bird, and breathed into it so that, by My permission, it became a living bird. How, by My permission, you healed the blind man and the leper, and by My permission you brought the dead forth; and how I protected you from the Children of Israel when you brought them clear signs; whereupon the unbelievers among them said: "This is nothing but plain magic".

# 780

When I revealed to the disciples to believe in Me and in My Messenger they replied: "We believe, bear witness that we submit."

# 781

When the disciples said: 'O (Prophet) Jesus, son of Mary, can your Lord send down to us a table from heaven' He replied: 'Have fear of Allah, if you are believers'

# 782

'We wish to eat of it' they said, 'so that we can satisfy our hearts and know that what you said to us is true, and that we become witnesses to it'

# 783

'Allah, our Lord' said (Prophet) Jesus, the son of Mary, 'send down upon us a table out of heaven, that shall be a festival for us the first and the last of us and a sign from You. And provide for us; You are the Best of providers'

# 784

Allah replied: 'I am sending it to you. But whoever of you disbelieves thereafter I shall punish him with a punishment that I do not punish anyone from the worlds'

# 785

And when Allah said: '(Prophet) Jesus, son of Mary, did you ever say to the people: "Take me and my mother for two gods, other than Allah?" 'Exaltations to You' he said, 'how could I say that to which I have no right? If I had said that, You would have surely known. You know what is in my self, but I do not know what is in Yours. Indeed, You are the Knowledgeable of the unseen.

# 786

I spoke to them of nothing except that which You ordered me, that you worship Allah, my Lord and our Lord. I witnessed them whilst living in their midst and ever since You took me to You, You have been the Watcher over them. You are the Witness of everything.

# 787

If You punish them (for their disbelief), they surely are Your subjects; and if You forgive them, surely You are the Almighty, the Wise'

# 788

Allah will say: 'This is the Day the truthful shall benefit by their truthfulness. They shall live for ever in Gardens underneath which rivers flow. Allah is pleased with them, and they are pleased with Him. That is the great winning'

# 789

To Allah belongs the Kingdom of the heavens and the earth and what is in them. He has power over all things.

# 790

Praise is due to Allah, who has created the heavens and the earth and made darkness and light. Yet the unbelievers make (others) equal with their Lord.

# 791

It is He who has created you from clay. He has decreed a term for you and another one set with Him. Yet you are still in doubt.

# 792

He is Allah in the heavens and earth. He has knowledge of all that you hide and all that you reveal. He knows what you earn.

# 793

Yet every time a sign comes to them from the signs of their Lord, they turn away from it.

# 794

They belied the truth when it came to them, but there shall come to them news of that they were mocking.

# 795

Have they not seen how many generations We have destroyed before them whom We had established in the land in a way We never established you, sending down for them abundant water from the sky and made the rivers to flow underneath them? Yet because they sinned, We destroyed them and raised up other generations after them.

# 796

Had We sent down to you a Book on parchment and they touched it with their own hands, those who disbelieved would say: 'This is nothing but plain magic'

# 797

They ask: 'Why has no angel been sent down to him' If We had sent down an angel, their fate would have been determined and they would never have been respited.

# 798

If We had made him an angel, We would have given him the resemblance of a man, and would have as such confused them with that in which they are already confused.

# 799

Other Messengers have been mocked before you. But those who scoffed at them were encompassed by that they had mocked'

# 800

Say: 'Travel the land and see what was the fate of those who belied'

# 801

Say: 'To whom belongs that which is in the heavens and the earth' Say: 'To Allah. He has written for Himself mercy, and will gather you on the Day ofResurrection in which there is no doubt. Those who have lost their souls, they do not believe'

# 802

His is whatever is at rest in the night and in the day. He is the Hearing, the Knowing.

# 803

Say: 'Should I take any but Allah for a guardian? He is the Originator of the heavens and the earth. He feeds and is not fed' Say: 'I was commanded to be the first to submit to Him' Do not be one of the idolaters.

# 804

Say: 'Indeed I fear, if I should disobey my Lord, the punishment of a great Day'

# 805

From whomsoever it is averted on that Day, He will have mercy on him; that is a clear triumph.

# 806

If Allah visits you with affliction, none can remove it except He; and if He touches you with good, indeed, He has power over all things.

# 807

He is the Conqueror over His worshipers. He is the Wise, the Aware.

# 808

Say: 'What thing is greatest in testimony' Say: 'Allah is a witness between me and you. This Koran has been revealed to me in order that I can warn you and all whom it reaches. Do you indeed testify that there are gods other than Allah' Say: 'I do not testify' Say: 'He is only One God, and I am quit of that which you associate'

# 809

Those to whom We have given the Book know him (Prophet Muhammad) as they know their own children. But those who have lost their own souls do not believe.

# 810

Who is more wicked than he who invents a lie about Allah or belies His verses? The harmdoers shall never prosper.

# 811

On the Day when We gather them all together We shall say to the idolaters: 'Where are your partners now, those whom you claimed'

# 812

Then it was not their trial, but they will say: 'By Allah, our Lord we have never been idolaters'

# 813

Look how they lie against themselves, and how that which they were forging has gone astray from them!

# 814

Some of them listen to you. But We have cast veils over their hearts lest they understand it and in their ears heaviness; and if they see every sign they do not believe in it. When they come to you they argue, the unbelievers say: 'This is nothing but the tales of the ancient ones'

# 815

They forbid from it (the Koran) and keep away from it. They destroy none except themselves, though they do not sense it.

# 816

If you could see them when they are set before the Fire! They will say: 'Would that we could return! Then we would not belie the verses of our Lord and would be believers'

# 817

Indeed, that which they concealed will appear to them. But if they were sent back, they would return to that which they have been forbidden. They are indeed liars.

# 818

They say: 'There is only but our present life; we shall not be resurrected'

# 819

If you could see them when they are made to stand before their Lord! He will say: 'Is this not the truth' 'Yes, by our Lord' they will reply, and He will say: 'Taste then the punishment, for that which you disbelieved'

# 820

They are lost indeed, those who belied the meeting with Allah. When the Hour overtakes them suddenly, they will say: 'Alas, for us, that we neglected it' On their backs they shall be bearing their sinful loads; how evil is what they sin!

# 821

The life of this world is but playing and an amusement. Surely, the Everlasting home is better for the cautious. Will you not understand?

# 822

We know what they say saddens you. It is not you that they belie; but the harmdoers deny the verses of Allah.

# 823

Messengers indeed were belied before you, yet they became patient with that which they were belied, and were hurt until Our help came to them. There is none to alter the Words of Allah; and there has already come to you some news of the Messengers.

# 824

If their turning away is hard upon you, seek if you can, a tunnel in the ground or a ladder to the sky by which you can bring them a sign. Had Allah willed, He would gather them to guidance. Do not then be among the ignorant.

# 825

Those who listen will surely answer. As for the dead, Allah will revive them. To Him they shall return.

# 826

They ask: 'Why has no sign been sent down to him from his Lord' Say: 'Allah is Able to send down a sign' But most of them do not know.

# 827

There is no crawling creature on the earth, nor a bird that flies with its two wings, but they are nations like you. We have neglected nothing in the Book. They shall all be gathered before their Lord.

# 828

Those who belie Our verses are deaf and dumb, in darkness. Allah leaves in error whom He will, and guides to the Straight Path whom He pleases.

# 829

Say: 'Do you see yourselves when the punishment of Allah smites you or the Hour overtakes you, will you call on any except Allah, if you are truthful?

# 830

No, on Him alone you will call, and He will remove that for which you call upon Him, if He will. Then you will forget what you associate (with Him).

# 831

Before you We sent forth to other nations, and then seized them with misery and hardship so that they might humble themselves.

# 832

If only they humbled themselves when Our scourge overtook them! But their hearts were hardened, and satan decorated to them what they were doing.

# 833

And when they had forgotten that with which they have been admonished, We opened the gates of everything to them, until just as they were rejoicing in what they were given, We suddenly seized them and they were in utter despair.

# 834

As such the harmdoers were annihilated. Praise be to Allah, Lord of the Worlds!

# 835

Say: 'What would you see if Allah took away your hearing and your sight, and set a seal upon your hearts, who is a god, other than Allah, to bring it back to you' Look how We make plain to them Our verses, and yet they turn away.

# 836

Say: 'What do you see yourselves then, if the punishment of Allah overtook you suddenly or openly, would any perish but the harmdoing nation'

# 837

We send forth Our Messengers only to give glad tidings to mankind and to warn them. Those who believe and mend their ways shall have nothing to fear or to be saddened.

# 838

But those who belie Our verses, punishment shall touch them for their misdeeds.

# 839

Say: 'I do not tell you that I have the treasuries of Allah or know the unseen, nor do I claim to be an angel. I follow only that which is revealed to me' Say: 'Are the blind and the seeing alike? Will you not think'

# 840

And warn with it those who fear to be brought before their Lord that they have no guardian or intercessor, other than Allah, in order that they are cautious.

# 841

Do not drive away those who call on their Lord morning and evening, seeking only His Face. Nothing of their account falls upon you, and nothing of your account falls upon them, that you should drive them away and so become one of the harmdoers.

# 842

As such We have made some of them a means for testing others, so that they should say: 'Are those whom Allah favors amongst us' But does not Allah best know the thankful?

# 843

When those who believe in Our verses come to you, say: 'Peace be upon you. Your Lord has decreed Mercy on Himself, if any one of you commits evil through ignorance, and then repents, and mends his ways, then He is Forgiving, the Most Merciful'

# 844

As such We make plain Our verses, so that the path of the wicked will be clear.

# 845

Say: 'I am forbidden to worship whom you call upon instead of Allah' Say: 'I will not yield to your wishes, for then I should have strayed and should not be of those guided'

# 846

Say: 'I am upon a clear proof from my Lord, yet you belie Him. I do not have that which you seek to hasten; judgement is for Allah alone. He narrates the truth and He is the Best of deciders'

# 847

Say: 'If what you seek to hasten were with me, the matter between you and me would be decided, and Allah knows very well the harmdoers'

# 848

With Him are the keys of the unseen, none knows them but He. He knows that which is in the land and sea. No leaf falls except He knows it, and there is no grain in the darkness of the earth, fresh or withered, but is recorded in a clear Book.

# 849

It is He who makes you to die by night, knowing what you have gained by day, and then resurrects you so that an ordained term is realized. To Him you shall return, and He will tell you of what you have been doing.

# 850

He is the Conqueror over His worshipers. He sends forth guardians who watch over you until death comes to one of you, when Our messengers take him, and they are not neglectful.

# 851

Then, they are returned to Allah their Guardian, the True. Surely, the judgement is for Him, He is the Swiftest of reckoners'

# 852

Say: 'Who saves you from the darkness of the land and sea, when you call out to Him humbly and in secret, (saying:) "If You save us from this, we will be among the thankful."

# 853

Say: 'Allah saves you from them, and from all afflictions. Then, you associate (with Him)'

# 854

Say: 'He is Able to send forth upon you punishment from above you or beneath your feet, or to divide you into discordant factions, and to make some of you taste the affliction of the other' Look how We make plain Our verses, in order that they understand.

# 855

Your nation has belied it (the Koran), although it is the truth. Say: 'I am not a guardian over you.

# 856

Every news has its appointed time; you will surely know'

# 857

When you see those who plunge (scoffing) into Our verses, withdraw from them till they plunge into some other talk. If satan causes you to forget, leave the wrongdoing people as soon as you remember.

# 858

Those who are cautious are not accountable for them in anything, but it is a reminder in order that they be cautious.

# 859

Avoid those who take their religion as playing and an amusement and are seduced by the life of this world. Admonish them hereby lest a soul be taken by what it has gained, for it has no guardian or intercessor before Allah, and though it offers every ransom, it shall not be taken from it. Those are they who are taken for that which they earned. For them a drink of boiling water, a stern punishment for their disbelief.

# 860

Say: 'Are we to call, other than Allah, what can neither help nor harm us? Are we to turn on our heels after Allah has guided us like him, who, being bewitched by devils, blunders aimlessly in the earth, although his friends call him to the guidance, (saying) 'Come to us' Say: 'The guidance of Allah is the Guidance. We are commanded to submit to the Lord of the Worlds,

# 861

and to establish prayer, and fear Him. Before Him you shall all be assembled'

# 862

It was He who created the heavens and the earth in truth. On the Day when He says: 'Be' it shall be. His Word is the truth. His shall be the Kingdom on the Day when the Horn is blown. The Knower of the unseen and the visible, and He is the Wise, the Aware.

# 863

(And remember) when Abraham said to his father Azar: 'Will you take idols for gods, surely I see you and your people are in clear error'

# 864

And so We showed Abraham the kingdom of the heavens and the earth, so that he might be of those who are certain.

# 865

When night drew over him, he saw a planet. 'This' he said: 'is surely my Lord' But when it set he said: 'I do not like the setting ones'

# 866

When he saw the rising moon, he said: 'This is my Lord' But when it set, he said: 'If my Lord does not guide me, I shall surely be amongst the astray nation'

# 867

Then, when he saw the sun rise, shining, he said: 'This must be my Lord, it is larger' But when it set, he said: 'O nation I am quit of what you associate (with Allah, the Creator),

# 868

I have turned my face to Him who has created the heavens and the earth, uprightly, and I am not among the idolaters'

# 869

His nation argued with him. He said: 'Will you argue with me about Allah, indeed He guided me! Except by His will, I do not fear those you associate with Him. My Lord embraces all things in knowledge, will you not remember?

# 870

And how should I fear what you have associated when you yourselves are not afraid that you have associated with Allah that which He did not send down for it upon you an authority. Which of the two parties is more deserving of safety, if you know?

# 871

Those who believe and have not confounded their belief with harm security belongs to them; and they are guided'

# 872

Such is the argument that We gave Abraham against his nation. We raise whom We will to an exalted rank. Your Lord is Wise, Knowing.

# 873

We gave him Isaac and Jacob and guided both; and We guided Noah before them, among his descendants were David and Solomon, Job, Joseph, Moses and Aaron as such, We recompense the gooddoers,

# 874

and (Prophets) Zachariah, John, Jesus and Elias, each was of the righteous,

# 875

and Ishmael, Elisha, Jonah and Lot. Each We preferred above the worlds,

# 876

as We did their fathers, their descendants, and their brothers. We chose them and guided them to a Straight Path.

# 877

Such is the guidance of Allah by it He guides whom He will of His worshipers. Had they associated (others with Him), their labors would have indeed been annulled.

# 878

Those, We have given them the Book, judgment, and prophethood. If these disbelieve it, We have entrusted it to others who do not disbelieve in it.

# 879

Those were whom Allah guided. Follow then their guidance and say: 'I do not ask you a wage for it. Surely, it is a reminder to the worlds'

# 880

They have not valued Allah with His true value, when they said 'Allah has never sent down anything to a mortal' Say: 'Who, then sent down the Book which Moses brought, a light and guidance for people? You put it on to parchments, revealing them and hiding much, you have now been taught what neither you nor your fathers knew before' Say: 'Allah' Then leave them, playing in their plunging.

# 881

And this is a Blessed Book which We have sent down, confirming what came before it, in order that you warn the Mother of the Villages (Mecca) and those who (live) around it. Those who believe in the Everlasting Life believe in it and preserve their prayers.

# 882

Who is more harmful than he who invents a lie about Allah, or says: "It has been revealed to me," when nothing has been revealed to him? Or he who says: 'I will send down the like of what Allah has sent down' Would that you could see the harmdoers when death overwhelms them! With hands outstretched, the angels (will say): 'Yield up your souls. You shall be recompensed with a humiliating punishment this Day, for you have said of Allah what is untrue and you grew proud against His verses.

# 883

Now you have returned to Us, alone, as We created you at first, leaving behind all that We have bestowed on you. Nor do We see with you your intercessors, those whom you asserted to be your associates. The ties which bound you are broken, and that which you asserted has gone astray from you'

# 884

It is Allah who splits the grain and the datestone. He brings forth the living from the dead, and the dead from the living. So, that is Allah; how then are you perverted?

# 885

He splits the sky into dawn. He has ordained the night for rest and the sun, and the moon for reckoning. Such is the ordinance of the Almighty, the Knowing.

# 886

It is He who has created for you the stars, so that you can be guided by them in the darkness of land and sea. We have made plain Our verses to a nation who know.

# 887

It is He who originated you from one soul, then a lodging (place), and then a repository. We have made plain the verses to a nation that understands.

# 888

He sends down water from the sky, and with it We bring forth the plant of every thing. From these We bring forth green foliage and composite grain, palmtrees laden with clusters of dates within reach, vineyards and olive groves and pomegranates alike and unlike. Behold their fruits when they bear fruit and ripen. Surely, in these there are signs for a nation who believe.

# 889

Yet they regard the jinn as the partners of Allah, although He created them, and without knowledge ascribe to Him sons and daughters. Exaltations to Him! He is above what they describe.

# 890

He is the Creator of the heavens and the earth. How can He have a son when He had no female companion? He created all things and has knowledge of all things.

# 891

That is Allah, your Lord. There is no god except He, the Creator of all things. Therefore, worship Him. He is the Guardian of all things.

# 892

No eye can see Him, though He sees all eyes. He is the Subtle, the Aware.

# 893

Clear proofs have come to you from your Lord. Whosoever sees clearly it is for himself, and whosoever is blind, it is against himself. I am not an overseer for you.

# 894

As such We make plain Our verses, so that they can say: 'You have studied' in order that We clarify it to a nation that knows.

# 895

Therefore, follow what has been revealed to you from your Lord there is no god except Him, and avoid the idolaters.

# 896

Had Allah willed, they would not have associated. We have not made you an overseer for them, nor are you their guardian.

# 897

Do not say crude words to those who call upon other than Allah, lest they use crude words about Allah in revenge without knowledge. As such we have made the actions of each nation seem pleasing. To their Lord they shall return, and He will inform them of that they were doing.

# 898

They solemnly swear by Allah that if a sign is given to them they would believe in it. Say: 'Signs are only with Allah' And how can you tell if it comes they will not believe'

# 899

We will turn away their hearts and eyes since they refused to believe in it at first. We will leave them in their insolence wandering blindly.

# 900

Even if We sent down the angels to them and the dead spoke to them, and assembled all things in front of them, they would still not believe, unless Allah willed it. But most of them are ignorant.

# 901

As such We have assigned for every Prophet an enemy; the satans of humans and jinn, revealing varnished speech to each other, all as a delusion. But had your Lord willed, they would not have done so. Therefore leave them and what they invent,

# 902

so that the hearts of those who have no belief in the Everlasting Life are inclined to it and, being pleased, persist in their sinful ways.

# 903

Should I seek a judge other than Allah when it is He who has sent down the well distinguished Book for you? Those to whom We have given the Book know that it is the truth sent down from your Lord, so do not be among the doubters.

# 904

Perfected are the words of your Lord in truth and justice, none can change His Words. He is the Hearing, the Knowing.

# 905

If you obeyed most of those on earth, they would lead you astray from the Path of Allah. They follow only supposition and they are but conjecturing.

# 906

Your Lord knows best who stray from His Path and the guided.

# 907

Eat then of that over which the Name of Allah has been mentioned (when slaughtered), if you truly believe in His verses.

# 908

And why should you not eat of that over which the Name of Allah has been pronounced when He has already made plain to you what is forbidden, except when you are constrained? Many are those who mislead through ignorance on account of their fancies, but your Lord best knows the transgressors.

# 909

Forsake the revealed and hidden sin. Those who earn sin shall be recompensed for what they have committed.

# 910

Do not eat from that which the Name of Allah has not been mentioned, for it is a sin. The satans will reveal to their guided ones to argue with you. If you obey them, you shall indeed become idolaters.

# 911

Is he who was dead whom We have revived and given a light with which he walks among people to be compared to him who blunders about in darkness from which he will never emerge? As such what the unbelievers have done appear decorated to them.

# 912

And as such we have placed in every village its archtransgressors to scheme there. But they scheme only against themselves, though they do not sense it.

# 913

When a sign came to them they said: 'We will not believe in it unless we are given that which the Messengers of Allah have been given' But Allah knows best where to place His Message. Humiliation with Allah shall befall the sinners as well as a terrible punishment for what they devised.

# 914

Whomsoever Allah desires to guide, He expands his chest to Islam (submission). Whomsoever He desires to lead astray, He makes his chest narrow, tight, as though he were climbing to heaven. As such Allah lays the scourge on the unbelievers.

# 915

This is the Path of your Lord, a Straight Path. We have made plain Our verses to a nation who remember.

# 916

Theirs is the abode of peace with their Lord. He is their Guardian for what they did.

# 917

On the Day when He assembles them all together, 'O company of Jinn, you have seduced mankind in great numbers' And their guided ones among the humans will say: 'Lord, we have enjoyed each other. But now we have reached the term which You have appointed for us' He will say: 'The Fire shall be your lodging, and there you shall remain for ever except as Allah will' Your Lord is Wise, Knowing.

# 918

So We make the harmdoers guides of each other for what they have earned.

# 919

'Jinn and human, did there not come to you Messengers of your own who narrated to you My verses and warned you of encountering this Day' They will reply: 'We bear witness against ourselves' Indeed, the life of this world beguiled them. They will bear witness against themselves that they were unbelievers.

# 920

That is because your Lord will not destroy villages unjustly, while their inhabitants were inattentive.

# 921

They all have their degrees according to their deeds. Your Lord is not inattentive of their actions.

# 922

Your Lord is Rich and the Owner of Mercy. He can destroy you if He will and replace you with whom He pleases, just as He raised you from the offspringof other nations.

# 923

That which you are promised is sure to come. You shall not frustrate Me.

# 924

Say: 'Work according to your station my people, for indeed I am working' You shall know to whom will be the good end of the abode. The harmdoers shall not be triumphant.

# 925

They set aside for Allah a share of what He has created of tilth and cattle saying: 'This is for Allah so they claim and this for our associates (gods)' The share of their associates never reaches Allah, but the share of Allah reaches their associates. How evil they judge!

# 926

As such their associates made it attractive to the idolaters to kill their children so that they ruin them and confuse them about their religion. But had Allah willed, they would not have done so. Therefore, leave them to their false inventions.

# 927

They say: 'These cattle, and these crops are forbidden. None can eat of them except those whom we permit' so they claim 'and cattle whose backs are forbidden, and others over which they do not pronounce the Name of Allah' As such fabricating lies against Him. He will recompense them for their invented lies.

# 928

They also say: 'What is in the bellies (wombs) of these cattle is reserved for our males but not for our wives' But if it is stillborn, they all partake of it. He will recompense them for their describing. He is Wise, Knowing.

# 929

Lost are those who, without knowledge, have foolishly slain their own children and made unlawful that which Allah has provided them, fabricating lies about Allah. They have gone astray and are not guided.

# 930

He brings forth gardens, trellised and untrellised, palmtrees and crops, different to eat, and the olive and pomegranates alike and unlike. When it bears fruit eat of it and pay what is due (the zakat) of it upon the harvest day. But do not be wasteful; He does not love the wasteful.

# 931

And of the cattle, some are for carrying burdens, and others for slaughter. Eat of that which Allah has provided you with and do not follow in satan's footsteps; he is your open enemy.

# 932

(He has given you) eight couples, a pair of sheep and a pair of goats. Say: 'Of these, has He forbidden you the males, the females, or what the wombs of the two females contain? Tell me with knowledge, if you are truthful'

# 933

Then a pair of camels and a pair of cattle. Say: 'Of these, has He forbidden you the males, the females, or what the wombs of the two females contain? Were you witnesses when Allah charged you with this? Who is more harmful than he who, without knowledge, invents a lie about Allah to mislead people? Allah does not guide the harmdoers.

# 934

Say: 'I find nothing in what has been revealed to me that forbids any one to eat of any food except the dead, running blood, and the flesh of swine for these are unclean and that which has been hallowed in its slaughter to other than Allah. But whoever is constrained to eat of any of these, not intending to sin or transgress, then your Lord is Forgiving, the Most Merciful.

# 935

We forbade the Jews all with undivided hoofs and the fat of sheep and cattle, except what is on their backs and entrails, and what is mixed with their bones. As such We recompensed them for their transgress ions. Indeed, We are truthful.

# 936

If they belie you, say: 'Your Lord is the Owner of all Encompassing Mercy, but His Might cannot be withheld from the nation, the evildoers'

# 937

The idolaters will say: 'Had Allah willed, neither we nor our fathers would have associated (idols), nor would we have forbidden anything. As such, those who have gone before them belied until they tasted Our Might. Say: 'Have you any knowledge you can bring forth to us? You follow nothing but guessing and you are only speakers of conjecture'

# 938

Say: 'Allah alone has the conclusive proof. Had He willed, He would have guided you all'

# 939

Say: 'Bring those witnesses of yours who can testify that Allah has forbidden this' If they testify to it, do not testify with them, nor follow the wishes of those who belie Our verses, and disbelieve in the Everlasting Life and ascribe equals to their Lord.

# 940

Say: 'Come, I will recite to you what your Lord forbids you; that you shall associate anything with Him; that you shall be good to your parents, that you shall not kill your children because of poverty, We provide for you and for them, that you shall not commit foul deeds whether openly or in secret, and that you shall not kill the soul that Allah has forbidden except by right. With such Allah charges you, in order that you understand.

# 941

Do not touch the wealth of the orphan, except in the fairer manner until he reaches maturity. Give just weight and full measure, We never charge a soul with more than it can bear. When you speak, be just, even if it affects your own kinsmen. Fulfill the covenant of Allah. With such He charges you, in order that you remember.

# 942

This Path of Mine is straight. Follow it and do not follow other paths, for they will scatter you away from His Path. With such Allah charges you, in order that you be cautious.

# 943

Then to Moses We gave the Book, complete for him who does good, and (to make) plain all things, and guidance, and mercy, so that they might believe in the ultimate meeting with their Lord.

# 944

And We have sent down this blessed Book (the Holy Koran). Follow it and be cautious in order that you receive mercy,

# 945

lest you should say: 'The Book was sent down only to two parties before us; we are inattentive to their study'

# 946

Or (you say), 'Had the Book been sent down to us, we would have been better guided than they' Indeed a clear sign has now come to you from your Lord; a guidance and a mercy. And who is more harmful than he who belies the verses of Allah and turns away from them! We shall recompense those who turn away from Our verses with an evil punishment for their turning away.

# 947

Are they waiting for the angels or your Lord to come to them, or for some of the signs of your Lord? On the Day when some of the signs of your Lord come, no soul will be benefited by its belief had it not believed before or earned good in its belief. Say: 'Wait, we are waiting'

# 948

You have nothing to do with those who have made divisions in their religion and become sects. Their affair is with Allah and He will inform them of what they have done.

# 949

He who brings a good deed shall have tenfold of its like, but he who brings a sin shall be recompensed only for its like. None shall be wronged.

# 950

Say: 'My Lord has guided me to a Straight Path, an upright religion, the creed of Abraham, he was upright, not from the idolaters'

# 951

Say: 'My prayers and my worship (for example, pilgrimage and sacrifice), my life and my death, are all for Allah, the Lord of the Worlds.

# 952

He has no partner, with that I am commanded, and I am the first of the submitters (Muslims)'

# 953

Say: 'Should I seek a lord other than Allah, who is the Lord of all things? Every soul earns only to its account no soul shall bear another's burden. Then to your Lord you shall be returned, and He will inform you about that in which you differed'

# 954

It is He who has made you caliphs in the earth and raised some of you in rank above others, so that He might try you in what He has given you. Swift is your Lord in retribution; yet He is Forgiving, Merciful.

# 955

AlifLaamMeemSaad.

# 956

The Book has been sent down to you; so let your chest have no constriction because of it, in order to warn thereby and as a reminder to the believers.

# 957

Follow that which is sent down to you from your Lord and do not follow guardians other than Him; little do you remember.

# 958

How many a village have We laid in ruin! In the night Our Might fell upon it, or at midday when they were drowsy.

# 959

And when Our Might fell upon them they only said: 'We have indeed been harmdoers'

# 960

We will question those to whom Our Message was sent, as We shall question the Messengers.

# 961

With knowledge We will narrate to them, for We are never absent.

# 962

On that Day, the weighing is true. He whose scales are heavy those are the prosperers,

# 963

but he whose scales are light those have lost their souls because they were harmful towards Our verses.

# 964

We established you in the earth and made for you a livelihood but little is it that you give thanks.

# 965

We created you then We shaped you, then We said to the angels: 'Prostrate yourselves before Adam' They all prostrated themselves except iblis he was not among the prostrated.

# 966

He (Allah) asked: 'What prevented you to prostrate, when I commanded you' 'I am better than he' he replied. 'You created me of fire and You created him of clay'

# 967

He (Allah) said: 'Descend from it! This is no place for you to be proud. Begone, you are of the humiliated'

# 968

he replied: 'Respite me till the Day of Resurrection'

# 969

Said He (Allah): 'you are among the respited'

# 970

he answered: 'Because You have caused me to go astray, I will waylay them as they walk on Your Straight Path,

# 971

and come upon them from the front and from the rear, from their right and from their left. Then, You shall find most of them ungrateful'

# 972

'Begone' said He, 'despised and outcast. (As for) those of them that follow you, I shall fill Gehenna (Hell) with all of you'

# 973

'O Adam dwell with your wife in Paradise, and eat from whatever you please; but never approach this tree or you shall both become harmdoers'

# 974

But satan whispered to them, so that he might reveal to them their shameful parts which had been hidden from them, he said: 'Your Lord has prohibited you from this tree lest you both become angels or become among the immortal'

# 975

he swore to both: 'Indeed, I am to you among the advisers'

# 976

So he cheated both by delusion. And when they had tasted the tree, their shameful parts became apparent to them, and they both covered themselves with the leaves of Paradise. (Then) their Lord called to them, saying: 'Did I not prohibit you to approach that tree, and did I not warn you that satan was your clear enemy'

# 977

Both replied: 'Lord, We have harmed ourselves. If You do not forgive us and have mercy on us, we shall surely be among the lost'

# 978

He said: 'Descend, each of you an enemy to each other. The earth will be a dwelling place for you and an enjoyment for a time.

# 979

He said: 'There you shall live and there you shall die, and from there you shall emerge'

# 980

Children of Adam! We have sent down to you clothing that covers your nakedness, and feathers. But the clothing of piety that is better. That is one of the signs of Allah, in order that they remember.

# 981

Children of Adam! Do not let satan tempt you, as he brought your parents out of Paradise. He stripped them of their garments to show them their shameful parts. Indeed he and his descendants see you from where you cannot see them. We have made the satans supporters of those who do not believe.

# 982

When they commit an indecency, they say: 'This is what we found our fathers practicing, and with it Allah has ordered us' Say: 'Allah does not order indecency. Would you tell of Allah what you do not know'

# 983

Say: 'My Lord ordered justice. Turn your faces to Him in every place of prayer and supplicate to Him, making the religion sincerely to Him. As He originated you, you shall return'

# 984

Some He has guided, and upon some justly is the straying; for they had chosen the satans for supporters instead of Allah and suppose themselves to be guided.

# 985

Children of Adam, take your adornment at every place of prayer. Eat and drink, and do not waste. He does not love the wasteful.

# 986

Say: 'Who has forbidden the adornment that Allah has brought for His worshipers and the good provision' Say: 'They are in this life for those who believe, and purely theirs on the Day of Resurrection' As such We distinguish the verses to people who know.

# 987

Say: 'My Lord has forbidden all indecent acts whether apparent or disguised and sin, and unjust insolence, and that you associate with Allah that for which He has never sent down an authority, or to say about Allah what you do not know'

# 988

To every nation a term; when their term comes they shall not delay it by a single hour, nor yet hasten it.

# 989

Children of Adam, when Messengers of your own come to narrate to you My verses, those who are cautious and mend their ways will have nothing to fear neither shall they be saddened,

# 990

but, those who belie and grow proud against Our verses shall be the inhabitants of the Fire, and there they shall remain for ever.

# 991

Who is more harmful than he who invents a lie about Allah or belies His verses? Such shall have their share of the Book, and when Our Messengers come to take them away, they shall say to them: 'Where now are those whom you invoked, other than Allah' 'They have forsaken us' they will answer, and will bear witness against themselves that they were unbelievers.

# 992

He will say: 'Enter the Fire and join the nations of jinn and humans that have gone before you' As they enter, every nation will curse its sisternation, and when all are gathered in the pit, the last of them will say of the first: 'These, Lord, are those who led us astray. Give them a double punishment of the Fire. He will answer: 'For each double, although you do not know it'

# 993

Then, the first will say to the last: 'You were no better than us' So taste the punishment for what you have earned.

# 994

The gates of heaven shall not be opened for those who have belied and grew proud against Our verses; nor shall they enter Paradise until a camel shall pass through the eye of a needle. As such We shall recompense the sinners.

# 995

Gehenna (Hell) shall be their cradle, and layers of fire shall cover them. As such We recompense the harmdoers.

# 996

As for those who believe and do good works We never charge a soul with more than it can bear they are the companions of Paradise, and there they shall live for ever.

# 997

We shall strip away all rancor from their chests. Rivers shall flow underneath them, and they shall say: 'Praise be to Allah who has guided us to this. Had Allah not given us guidance we should not have been guided. The Messengers of our Lord surely came with the truth' Then they are called: 'This is the Paradise which you have inherited for what you did'

# 998

Then the companions of Paradise will call out to the companions of the Fire: 'What our Lord promised we have found to be true, have you too, found the promise of your Lord to be true' 'Yes' they shall answer, and a Caller will announce between them that the curse of Allah is upon the harmdoers,

# 999

who have barred others from the Path of Allah and sought to make it crooked, and who had no belief in the Everlasting Life.

# 1000

And between them is a veil, and on the ramparts there shall stand men who will know each by their marks. To the companions of Paradise they shall call: 'Peace be upon you' Yet they did not enter it on account of their eagerness.

# 1001

And when they turn their eyes towards the companions of the Fire, they will say: 'Lord, do not cast us among the harmdoers'

# 1002

And the companions of the ramparts call to men whose marks they recognize: 'Neither your amassing nor your pride have availed you.

# 1003

Are these whom you swore that Allah would never have mercy upon them' (To them it will be said:) 'Enter Paradise. You have nothing to fear neither will you be saddened'

# 1004

The companions of the Fire will call out to the companions of Paradise: 'Pour upon us some water, or some of that which Allah has provided you' But they shall reply: 'Allah has forbidden both to the unbelievers,

# 1005

who made their religion an amusement and play, and who were beguiled by their worldly life' On this Day We will forget them as they forgot the meeting of that Day; for they denied Our verses.

# 1006

We have brought to them a Book which We have made plain based upon knowledge, a guidance and a mercy to believers.

# 1007

Are they waiting but for its fulfillment? On the Day when it is realized, those who have forgotten it will say: 'The Messengers of our Lord have surely come with the truth. Have we then any intercessors to intercede for us, or shall we be returned to do other than that we have done' They have lost their souls, and that which they invented will have gone astray from them.

# 1008

Your Lord is Allah, who, in six days created the heavens and the earth, and then willed to the Throne. He throws the veil of night over the day. Swiftly they follow one another. The sun, the moon, and the stars are compelled to His order. His is the creation, His is the command. Blessed is Allah, the Lord of the Worlds.

# 1009

Supplicate to your Lord with humility and in secret. He does not love the transgressors.

# 1010

Do not make mischief in the earth after it has been put right. Pray to Him with fear and hope; His Mercy is near to the righteous.

# 1011

He sends forth the winds as carriers of the glad tidings between the hands of His Mercy, and when they have carried up a heavy cloud, We drive it on to some dead land and therewith send down water bringing forth all manner of fruit. As such We will raise the dead, in order that you remember.

# 1012

Good land yields its vegetation by the permission of its Lord. While the corrupted yields only the scanty. So We make plain the verses to those who are thankful.

# 1013

We sent forth Noah to his nation. He said: 'Worship Allah, my people for you have no god except He. I fear for you the punishment of a great Day.'

# 1014

But the assembly of his nation said: 'We can see that you are in clear error.'

# 1015

'I am not in error, my nation' he replied. 'I am a Messenger from the Lord of the Worlds

# 1016

(sent) to convey to you the messages of my Lord and to advise you, for I know from Allah what you do not know.

# 1017

Do you wonder that a Remembrance should come to you from your Lord to a man from yourselves in order that he may warn you and that you may be cautious so that mercy comes upon you'

# 1018

(But) they belied him, so We saved him and those who were with him in the Ark, and We drowned those who belied Our verses. Surely, they were a blind nation.

# 1019

And to (the people of) Aad We sent their brother, Hood. He said: 'Worship Allah, my nation, for you have no god except He. Will you not then be cautious'

# 1020

The disbelieving assembly of his nation said: 'We see you in foolishness, and think that you are of the liars'

# 1021

'My nation, there is no foolishness in me' he replied. 'I am a Messenger of the Lord of the Worlds

# 1022

I deliver to you the messages of my Lord and I am your honest adviser.

# 1023

Do you wonder that a remembrance should come to you from your Lord to a man from yourselves in order that he may warn you? Remember, that He has made you the heirs of Noah's nation and increased you in broad stature, remember the favors of Allah in order that you prosper'

# 1024

They said: 'Have you come to us in order that we worship Allah alone and renounce that which our fathers worshipped? Bring down that with which you threaten us if you are from the truthful!

# 1025

He answered: 'The punishment and wrath of your Lord has already fallen upon you. Would you dispute with me about names which you and your fathers have invented, and for which no authority has been sent down from Allah? Wait if you will, I am waiting with you'

# 1026

We saved him and all who were with him through Our Mercy and annihilated those who belied Our verses. They were not believers!

# 1027

And to Thamood We sent their brother Salih. He said: 'Worship Allah, my nation, for you have no god except He. A clear proof has come to you from your Lord. Here is the shecamel of Allah, a sign for you. Leave her to graze in the earth of Allah and do not touch her with evil, lest a painful punishment seizes you.

# 1028

Remember, that He has made you the successor of 'Aad, and lodged you in the land. You have built palaces on its plains and hewed out houses in the mountains. Remember the favor of Allah and do not act mischievously in the earth, corrupting'

# 1029

The proud assembly of his nation said to the weak? amongst them who believed: 'Do you really believe that Salih is sent from his Lord' They answered: 'We believe in that with which he was sent'

# 1030

Those who were proud said: 'We disbelieve in that which you believed in'

# 1031

(Then) they hamstrung the shecamel and defied the order of their Lord, saying to Salih: 'Bring down that which you have promised us if you truly are one of the Messengers'

# 1032

Thereupon the earthquake seized them, at morning in their dwellings they were crouched, dead.

# 1033

He turned from them, saying: 'I conveyed to you, my nation the Message of my Lord and gave you counsel; but you had no love for sincere advisers'

# 1034

And Lot, who said to his nation: 'Do you commit such indecency (sodomy) in a way that no one has preceded you in the worlds?

# 1035

You approach men lustfully instead of women. Truly, you are a nation who exceed (in sin)'

# 1036

The only answer of his nation was: 'Expel them from your village. They are people who keep themselves purified'

# 1037

We saved him and all his family, except his wife, who was made to remain,

# 1038

and We rained down upon them a rain. So look how was the end of the evildoers.

# 1039

And to Midian, their brother Shu'aib. He said: 'Worship Allah, my nation, for you have no god except He. A clear sign has come to you from your Lord. Give just weight, and full measure; and do not diminish the goods of people. Do not corrupt the land after it has been set right, that is best for you, if you are believers.

# 1040

'Do not sit in every road, threatening and barring from the Path of Allah those who believed it, nor seek to make it crooked. Remember how He multiplied you when you were few in number. Consider the end of the corrupters.

# 1041

If there are some among you who believe in that which I have been sent and others who disbelieve it, be patient until Allah shall judge between us. He is the best of judges'

# 1042

The proud assembly of his nation said: 'We will expel you Shu'aib and those who believe with you from our village unless you return to our creed' He replied: 'Even though we hate it?

# 1043

We would have invented lies about Allah if we returned to your creed from which Allah has saved us, it is not for us that we return into it again except if Allah, our Lord wills. For our Lord has embraced everything with knowledge, and in Allah we have put our trust. Our Lord, open between us and our nation with truth, You are the Best of openers'

# 1044

But the unbelieving assembly of his nation said: 'If you follow Shu'aib, you shall assuredly be losers.'

# 1045

So the earthquake seized them, at the morning they were crouched in their dwellings, dead.

# 1046

It seemed as if those who had belied Shu'aib had never lived there. Those who belied Shu'aib were the losers.

# 1047

He turned away from them saying: 'I conveyed to you, my nation, the messages of my Lord and advised you. How can I grieve for the unbelieving nation'

# 1048

We sent no Prophet to a village but seized its inhabitants with misfortune and adversity in order that they might be humble in supplication.

# 1049

Then We changed evil for good, until they multiplied and said: 'Our fathers were indeed touched by misfortune and adversity' So We seized them suddenly while they were unaware.

# 1050

Had the people of the villages believed and been cautious, We would have opened upon them the blessings from heaven and earth. But they belied, and We seized them for what they earned.

# 1051

Do the inhabitants of the villages feel secure from Our Might coming to them at night whilst they sleep?

# 1052

Or do the inhabitants of the villages feel secure from Our Might coming to them in the midmorning while they play?

# 1053

(In reply to your devising) do they feel secure from the devising of Allah? None feels secure from the devising of Allah except the loosing nation.

# 1054

Is it not plain to those who inherit the earth after its inhabitants that if We willed We could smite them for their sins and set a seal upon their hearts, so that they do not hear.

# 1055

Those villages We narrate their news to you. Their Messengers came to them with clear proofs, yet they would not believe what they had belied before; as such Allah seals the hearts of the unbelievers.

# 1056

We did not find the covenant upheld by the majority of them, but We found most of them evildoers.

# 1057

After those We sent forth Moses with Our signs to Pharaoh and his assembly, but with it they harmed. Look at the end of the corrupters.

# 1058

Moses said: 'Pharaoh, I am a Messenger from the Lord of the Worlds,

# 1059

incumbent upon me is that I say nothing of Allah except the truth. I bring you a clear proof from your Lord. So let the Children of Israel depart with me'

# 1060

He answered: 'If you have come with a sign, show it to us if you are of the truthful'

# 1061

He threw down his staff, and it was clearly a serpent.

# 1062

Then he drew out his hand and it was luminous to the onlookers.

# 1063

The assembly of Pharaoh's nation said: 'This man is a wellversed sorcerer

# 1064

who seeks to drive you from your land what do you command'

# 1065

Others said: 'Put them off a while, he and his brother, and send forth to your cities gatherers

# 1066

to summon every wellversed sorcerer to you'

# 1067

The sorcerers came to Pharaoh. They said: 'Shall we be rewarded if we are the winners'

# 1068

'Yes' he answered, 'and you will be among those near'

# 1069

They said: 'Moses, will you throw first or shall we be the throwers'

# 1070

'Throw' he replied. And when they threw, they bewitched the people's eyes and terrified them, and produced great sorcery.

# 1071

Then We revealed to Moses: 'Now, throw down your staff' And thereupon it swallowed up their false invention.

# 1072

So, the truth prevailed and what they were doing was annulled;

# 1073

they were defeated and turned belittled,

# 1074

and the sorcerers prostrated themselves,

# 1075

saying: 'We believe in the Lord of the Worlds,

# 1076

the Lord of Moses and Aaron'

# 1077

Pharaoh said: 'Do you believe in Him before I permit? This is a plot that you have contrived in the city in order to expel its people from it. Now you shall know!

# 1078

I will cut off on opposite sides a hand and a foot, and then crucify you all'

# 1079

They replied: 'We shall surely turn to our Lord.

# 1080

You would take revenge on us only because we believed in the signs of our Lord when they came to us. Lord, pour patience upon us and let us die as submitters (Muslims)'

# 1081

The assembly of Pharaoh's nation said: 'Will you allow Moses and his nation to corrupt in the land and to forsake you and your gods' He replied: 'We will put their sons to death and spare their women, indeed we are conquerors over them'

# 1082

Moses said to his nation: 'Seek help from Allah and be patient. The earth belongs to Allah; He gives it as a heritage to whom He chooses amongst His worshipers. The outcome is for the cautious'

# 1083

They replied: 'We were hurt before you came to us, and after you came to us' He said: 'Your Lord may destroy your enemies and make you inheritors in the land. Then He will see how you conduct yourselves'

# 1084

We seized Pharaoh's people with years of drought and scarcity of fruit so that they might remember.

# 1085

When good things came their way, they said: 'It is our due' but when evil befell them they blamed their ill fortune on Moses and those with him. Indeed their ill fortune was with Allah, though most of them did not know.

# 1086

They said: 'Whatever sign you bring to us, to cast a spell upon us, we will not believe in you'

# 1087

So We sent upon them floods, locusts, lice, frogs, and blood. (All these were) clear signs, yet they were proud against them, for they were wicked people.

# 1088

And when the plague smote them, they said: 'Moses, pray to your Lord for us invoking the promise He has made with you. If you lift the plague from us, we will believe in you and let the Children of Israel go with you'

# 1089

But when We had lifted the plague from them for a term which they had to reach, they broke their promise.

# 1090

So We punished them and drowned them in the sea, for they had belied Our signs and gave no heed to them.

# 1091

We gave the persecuted nation dominion over the eastern and western lands which We had blessed. So the Word of your Lord, the finest, was fulfilled for the Children of Israel because of their patience; and We destroyed the edifices, and towers of Pharaoh and whatsoever they manufactured.

# 1092

and We moved the Children of Israel from one side of the sea to the other, and they came upon a nation zealously devoted to the idols they had. They said to Moses: 'Make a god for us, as they have gods' Moses replied: 'You are indeed an ignorant nation.

# 1093

That which they are engaged upon shall be shattered and all their works are vain.

# 1094

Should I seek any god for you except Allah? He has exalted you above the nations.

# 1095

And that We saved you from Pharaoh's family, who had oppressed you cruelly, putting your sons to death and sparing your women. Surely, that was a great trial from your Lord'

# 1096

We appointed for Moses thirty nights, and We completed them with ten more; so that the appointment with his Lord took forty nights. Moses said to Aaron, his brother: 'Take my place among my nation. Do what is right and do not follow the path of the corrupt doers'

# 1097

And when Moses came at the appointed time and his Lord spoke to him, he said: 'Lord, let me see, that I can look at You' He replied: 'You shall not see Me. But look at the mountain; if it remains firm in its place, then shall you see Me' And when his Lord was revealed to the mountain and caused it to be crushed and leveled whereupon Moses fell down senseless, and when he recovered, he said: 'Exaltations to You! I repent to You. I am the first of believers'

# 1098

He said: 'Moses, I have chosen you from all mankind with My Messages and My Words. Therefore, take what I have given you, and be among the thankful.'

# 1099

We inscribed for him upon the Tablets all kinds of exhortation and clear explanations of all things. So take it forcefully, and order your nation to take what is best of it. I shall show you the home of the wicked.

# 1100

From My signs I will turn away the unrightfully, arrogant in the land, so that even if they witness every sign they would not believe it. If they see the path of righteousness, they shall not take it as a path; but if they see the path of error, they shall take it for their path because they belied Our signs and were inattentive towards them.

# 1101

Vain are the deeds of those who belie Our signs and the Everlasting Life. Shall they not be recompensed except for what they used to do?

# 1102

In his absence, the nation of Moses made a calf from their ornaments, a body with a hollow sound. Did they not see that it could neither speak to them, nor guide them to a path? Yet they took it in worship and were harmdoers.

# 1103

But when it landed in their hands and saw that they had strayed, they said: 'If our Lord does not have mercy on us and forgive us, we shall be lost'

# 1104

And when Moses returned to his nation, angry and sorrowful, he said: 'Evil is what you have done in my absence! Would you hasten the retribution of your Lord' He threw down the Tablets, and seizing his brother by the head, dragged him towards him. 'Son of my mother' said (Aaron), 'the nation weakened me, and almost killed me. Do not let my enemies rejoice over me; do not number me among the harmdoers.'

# 1105

'Lord' said Moses, 'forgive me and forgive my brother. Admit us to Your Mercy, for You are Most Merciful of the merciful'

# 1106

Those who worshipped the calf incurred the Anger of their Lord and abasement in this life, and as such We recompense the forgers.

# 1107

As for those who do evil and later repent and believe, your Lord is Forgiving, the Most Merciful thereafter.

# 1108

When his anger abated, Moses took up the Tablets upon which was inscribed guidance and mercy to those who fear their Lord.

# 1109

Moses chose from among his nation seventy men for Our appointment, and when the quake seized them, Moses said: 'My Lord, had it been Your Will, You would have destroyed them before, and me. Will You destroy us for that which the fools amongst us did? It is only Your trial by which You leave in error whom You will, and guide whom You will. You alone are our Guardian. Forgive us and have mercy on us, You are the Best of those who forgive.

# 1110

Write for us what is good in this life and in the Everlasting Life. To You alone we turn' He replied: 'I will smite with My punishment whom I will; yet My Mercy embraces all things. I will write it (My Mercy) to those who are cautious, give the obligatory charity, and believe in Our verses;

# 1111

and to those who shall follow the Messenger the Unlettered Prophet (Muhammad) whom they shall find written with them in the Torah and the Gospel. He will order kindness upon them and forbid them to do evil. He will make good things lawful to them and prohibit all that is foul. He will relieve them of their burdens and of the shackles that weigh upon them. Those who believe in him and honor him, those who aid him and follow the light sent forth with him, shall surely prosper'

# 1112

Say: 'O mankind, I am the Messenger of Allah to you all. His is the kingdom in the heavens and the earth. There is no god except He. He revives and causes to die. Therefore, believe in Allah and His Messenger, the Unlettered Prophet, who believes in Allah and His Words. Follow him in order that you are guided.'

# 1113

Yet among the people of Moses there was a nation who preached the truth and acted justly.

# 1114

We divided them into twelve tribes, each a nation. And when his people demanded drink, We revealed to Moses: 'Strike the rock with your staff' Thereupon twelve springs gushed from the rock and each tribe knew its drinkingplace. We caused the clouds to cast their shadow over them, and sent down for them manna and quails, saying: 'Eat of the good things We have provided for you' Indeed, they did Us no wrong, but they wronged themselves.

# 1115

When it was said to them: 'Dwell in this village, and eat of whatever you please; and say, "Unburdening" and enter the gate prostrating, We will forgive you your sins and increase the gooddoers'

# 1116

The wicked amongst them changed what was said for other words. Therefore We sent down upon them from heaven a punishment for their evil doing.

# 1117

Ask them about the village that overlooked the sea and what befell (its people) when they broke the Sabbath. Each Sabbath, their fish came swimming towards the shore, but on other days they did not come to them. As such We tempted them (the people) because they had done wrong.

# 1118

And when some asked: 'Why do you admonish a nation whom Allah will destroy or sternly punish' They replied: '(Seeking) a pardon from your Lord, and in order that they may be cautious'

# 1119

Therefore, when they forgot that of which they were reminded, We saved those who were forbidding evil, and seized the evildoers with an evil punishment for that which they used to do of evil.

# 1120

And when they had scornfully persisted in what they had been forbidden, We said to them: 'Be apes, despised'

# 1121

Then your Lord declared He would send against them he who would oppress them cruelly till the Day of Resurrection. Swift is the retribution of your Lord, yet surely He is Forgiving, the Most Merciful.

# 1122

We dispersed them through the earth in nations some were righteous, others were not, and tested them with good and evil in order that they return.

# 1123

Then others succeeded them who inherited the Book and availed themselves of the vanities of this lower world, saying: 'It will be forgiven us' But if similar vanities came their way, they would again take them. Have they not taken the covenant of the Book, which they have studied, to tell nothing of Allah except what is true? Surely, the Everlasting Life is better for the cautious, do you not understand!

# 1124

As for those who hold fast to the Book and are steadfast in prayer, We do not waste the wage of the righteous.

# 1125

When We suspended the mountain over them as though it were a shadow and they feared that it was falling down on them: (We said): 'Take forcefully that which We have given you and remember what it contains, in order that you keep from evil'

# 1126

When your Lord brought forth descendants from the loins of Adam's children, and made them testify concerning themselves (He said): 'Am I not your Lord.' They replied: 'We bear witness (that You are)' Lest you should say on the Day of Resurrection: 'We had no knowledge of this'

# 1127

or you say: 'Our forefathers were idolaters before, and we were the descendants after them, will You destroy us for the deeds of the vaindoers'

# 1128

As such We make plain Our verses in order that they return.

# 1129

Recite to them the news of he to whom We gave Our verses and who turned away from them; how satan overtook him so he was led astray.

# 1130

Had it been Our will We would have raised with it, but he clung to this earthly life and succumbed to his fancies. His likeness was that of a dog, whether you chase it away or let it alone it pants. Such is the example of a nation who belie Our signs. Recount to them these narratives, in order that they reflect.

# 1131

Evil is the example of those who belied Our verses; they wronged themselves.

# 1132

He whom Allah guides is one that is guided, but he whom Allah leaves in error shall surely be the lost.

# 1133

For Gehenna, We have created many jinn and many humans. They have hearts, with which they cannot understand; eyes, with which they do not see; and ears, with which they do not hear. They are like cattle, rather, they are the more misguided. Such are the heedless.

# 1134

To Allah belongs the Finest Names, so call Him by them, and keep away from those who pervert them. They shall be recompensed for the things they did.

# 1135

Among those whom We created there is a nation who guide with the truth and with it they are just.

# 1136

As for those who belie Our verses, We will draw them on little by little, from where they cannot tell;

# 1137

and I respite them, My stratagem is firm.

# 1138

Have they not reflected? There is no madness in their companion, he is but a plain warner.

# 1139

Will they not ponder upon the kingdom of the heavens and the earth, and all that Allah created, and that it may be that their term is drawing near? So, in which speech will they believe thereafter?

# 1140

None can guide those whom Allah leaves in error. He leaves them in their insolence, wandering blindly.

# 1141

They ask you about the Hour and when it is to come. Say: 'None knows except my Lord. He alone will reveal it at the appointed time. It is heavy in the heavens and earth. It will not come to you but suddenly' They will question you, as though you had full knowledge of it. Say: 'Its knowledge is with Allah, though most people are unaware'

# 1142

Say: 'I do not have the power to acquire benefits or to avert harm from myself, except by the Will of Allah. Had I possessed knowledge of the unseen, I would have availed myself of much that is good, and no harm would have touched me. But I am only a warner and a bearer of glad tidings for a nation who believe.

# 1143

It is He who created you from a soul. From it He created its mate, so that he might reside with her. And when he had covered her, she conceived, and for a time her burden was light. She carried it with ease, but when it grew heavy, they both supplicated to Allah, their Lord: 'Grant us a goodly child and we will be among the thankful'

# 1144

Yet when He gave both of them (the parents) a goodly child, they set up associates with Him, in return for what He had given them. Exalted be Allah above that they associate with Him.

# 1145

Will they associate that which cannot create a thing while they are created?

# 1146

They cannot help them, nor can they help themselves.

# 1147

If you call them to guidance, they will not follow you. It is the same whether you call them or you are silent.

# 1148

Those whom you invoke, other than Allah, are worshipers like yourselves. Call them, and let them answer you, if what you say is true!

# 1149

Have they feet to walk with? Have they hands to punish with? Have they eyes to see with? Have they ears to hear with? Say: 'Call on your partners and then try to scheme against me. Give me no respite.

# 1150

My Guardian is Allah, who has sent down the Book. He guards the righteous.

# 1151

Those whom you invoke, other than Him, cannot help you, nor can they help themselves'

# 1152

If you call them to guidance, they will not hear you. You see them looking towards you, but they cannot see.

# 1153

Accept the easing, order with fine jurisprudence, and avoid the ignorant.

# 1154

When satan provokes you seek refuge in Allah; He is the Hearing, the Knowing.

# 1155

Indeed, when a visitation of satan touches the cautious (worshipers) they remember, and then see clearly.

# 1156

And their brothers, they prolong them in error, and they will never stop.

# 1157

When you do not bring them a verse, they say, 'Why have you not chosen one' Say: 'I follow only what is revealed to me from my Lord. This (Koran) is a veritable proof from your Lord, guidance and mercy for people who believe'

# 1158

When the Koran is recited, listen to it in silence in order that Allah has mercy upon you.

# 1159

Remember your Lord in your soul with humility and fear, and not with a loud voice, morning and evening, and do not be among the inattentive.

# 1160

Those who are with your Lord are not too proud to worship Him. They exalt Him and to Him they prostrate.

# 1161

They ask you about the spoils (of war). Say: 'The spoils belong to Allah and the Messenger. Therefore, have fear of Allah and set things right between you. Obey Allah and His Messenger, if you are believers'

# 1162

Indeed the believers are those whose hearts quake at the mention of Allah, and when His verses are recited to them it increased them in faith. They are those who put their trust in their Lord.

# 1163

Those who pray steadfastly, and spend of that which We have provided them,

# 1164

those are, in truth, the believers. They shall have degrees with their Lord and forgiveness, and a generous provision.

# 1165

It is like when your Lord caused you to leave your home with the truth, though some of the believers disliked it.

# 1166

They argued with you about the truth after it had been made clear, as though they were being led to certain death while looking.

# 1167

(Remember) when Allah promised to grant you one of the two parties (at Badr), and you wished for the one that was not strong. Allah wanted to establish the truth by His Words and to sever the unbelievers to the last,

# 1168

in order that He might verify the truth and annul the falsehood, even though the wrongdoers hated it.

# 1169

And when you (Prophet Muhammad) prayed to your Lord for help, He answered: 'I am sending to your aid a thousand angels in succession'

# 1170

Allah only made it to be glad tidings and so that your hearts may be satisfied; victory comes only from Allah; He is Almighty, Wise.

# 1171

When you were overcome by sleep, as security from Him, He sent down water from the sky to cleanse you and to purify you of satan's filth, to strengthen your hearts and to steady your footsteps.

# 1172

And when Allah revealed to the angels, saying: 'I shall be with you. Give courage to the believers. I shall cast terror into the hearts of the unbelievers. Strike them above the necks, smite their finger tips'

# 1173

This is because they had made a breach with Allah and His Messenger. He who makes a breach with Allah and His Messenger indeed, Allah is stern in retribution.

# 1174

'That for you, so taste it, the punishment of the Fire is for the unbelievers'

# 1175

Believers, when you encounter unbelievers on the march do not turn your backs to them in flight.

# 1176

If anyone on that day turns his back to them in flight, except when maneuvering to fight, or to join another party, he shall be laden with the Anger of Allah and Gehenna shall be his refuge an evil arrival.

# 1177

It was not you who killed them, but Allah slew them, neither was it you who threw at them. Allah threw at them in order that He confers on the believers a fair benefit. Indeed, Allah is Hearing, Knowing.

# 1178

Allah will surely weaken the guile of the unbelievers.

# 1179

If you were seeking a victory, victory has now come to you. If you desist, it will be better for you. If you resume We will return, and even if your forces are numerous, they shall not help you at all. And Allah is with the believers.

# 1180

Believers, obey Allah and His Messenger, and do not turn away from him when you are hearing.

# 1181

Do not be like those who say: 'We hear' but they do not listen.

# 1182

The worst beasts before Allah are those who are deaf, dumb, and do not understand.

# 1183

Indeed, had Allah known any good in them, He would have let them hear. But even if He had made them hear, they would have turned away, swerving aside.

# 1184

Believers, respond to Allah and the Messenger when he calls you to that which revives you. Know that Allah is between the person and his heart, and that toHim you shall all be gathered.

# 1185

And be cautious against a sedition that will not smite the harmdoers alone. Know that the punishment of Allah is Stern.

# 1186

And remember how He gave you shelter when you were few in number and considered weak in the land, ever fearing that the people would snatch you away; but He gave you refuge and supported you with His victory and provided you with goodness, so that you might give thanks.

# 1187

Believers, do not betray Allah and the Messenger, nor knowingly betray your trust.

# 1188

Know that your children and your wealth are but a temptation, and that the reward with Allah is great.

# 1189

Believers, if you fear Allah, He will give you a criteria and cleanse you of your sins and forgive you. Allah is the Owner of great bounty.

# 1190

And when the unbelievers plotted against you (Prophet Muhammad). They sought to either take you captive or have you killed, or expelled. They plotted but Allah (in reply) also plotted. Allah is the Best in plotting.

# 1191

Whenever Our verses are recited to them, they say: 'We have heard them, if we wished, we could speak its like. They are but tales of the ancients'

# 1192

When they say: 'O Allah, if this is indeed the truth from You, rain down upon us stones from heaven or bring us a painful punishment.'

# 1193

But Allah was not to punish them whilst you were living in their midst. Nor would Allah punish them if they repeatedly ask forgiveness of Him.

# 1194

And why should Allah not punish them, when they have barred others from the Sacred Mosque, although they were not its guardians? Its only guardians are the cautious, though most of them do not know.

# 1195

Their prayers at the Sacred House are nothing but whistling and clapping. Therefore, taste the punishment for your disbelief.

# 1196

Those who disbelieve spend their wealth to bar (others) from the Path of Allah. They will spend it; but it will become a regret for them, then they will be overcome. The unbelievers shall be gathered in Gehenna,

# 1197

in order that Allah will separate the wicked from the good. He will heap the wicked one upon another, and then heap them together and cast them in Gehenna those shall be the losers.

# 1198

Tell the unbelievers that if they abandon their ways He will forgive them what is past; but, if they return, that was indeed the way of their forefathers who have passed away.

# 1199

Fight them until persecution is no more and the Religion of Allah reigns supreme. If they desist, Allah sees the things they do;

# 1200

but if they turn away, know that Allah is your guardian, (He is) the best Guardian and the best Giver of victory.

# 1201

And know that one fifth of whatever you take as spoils belong to Allah, the Messenger, kinsmen of the Messenger, the orphans, the needy, and the destitute traveler; if you believe in Allah and what We sent down to Our worshiper on the day of victory, the day when the two armies met. Allah has power over all things.

# 1202

And when you were encamped on the nearside and they (the unbelievers) on the farther side, with the caravan below, had you made an appointment with them, you would have surely failed to keep it; but Allah sought to accomplish what He had ordained, so that by clear evidence, he who was destined to perish might perish, and he who was destined to live might live. Surely, Allah is Hearing, Knowing.

# 1203

And when Allah made them appear to you in a vision as a small band, had He showed them to you as many, your courage would have failed you and you would have quarreled over the affair. But Allah saved; He knows the inner most thoughts in the chests.

# 1204

And when you met them, He showed them in your eyes as being few, and decreased (your number) in their eyes so that Allah might determine what was ordained. To Allah all matters return.

# 1205

Believers, when you meet an army stand firm and remember Allah abundantly, in order that you are prosperous.

# 1206

Obey Allah and His Messenger and do not dispute with one another lest you should lose courage and your resolve weaken. Have patience Allah is with those who are patient.

# 1207

Do not be like those who left their homes elated with insolence and showing off to people, barring others from the Path of Allah but Allah encompasses what they do.

# 1208

And when satan made their foul deeds seem fair to them. He said: 'No one shall conquer you this day. I shall be your savior' But when the two armies came within sight of each other, he took to his heels, saying: 'I reject you, for I can see what you cannot. I fear Allah, Allah is Stern in retribution'

# 1209

And when the hypocrites and those in whose hearts was sickness said: 'Those, their religion has deceived them' But whosoever puts his trust in Allah, indeed Allah is Mighty, Wise.

# 1210

If you could see the angels when they carry off the souls of the unbelievers, beating their faces and their backs, saying: 'Taste the punishment of Burning!

# 1211

That is for what your hands have forwarded, Allah is not unjust to His worshipers'

# 1212

Like Pharaoh's family and those who have gone before them, they disbelieved the signs of Allah. Therefore, Allah seized them in their sinfulness. Mighty is Allah and stern in retribution.

# 1213

This is because Allah would never change His favor that He bestowed upon a nation until they change what is in their hearts. Allah is Hearing, Knowing.

# 1214

Like Pharaoh's family and those who have gone before them, they belied the signs of their Lord, and so We destroyed them for their sins and drowned Pharaoh's family. They were all harmdoers.

# 1215

Indeed, the basest creatures before Allah are the unbelievers for they will not believe;

# 1216

those with whom you have made a treaty, then break their treaty with you every time; having no fear (of Allah),

# 1217

if you meet them in battle, cause their example to scatter those behind them so that they remember.

# 1218

If you fear treachery from any of your allies, you can dissolve with them equally. Allah does not love the treacherous.

# 1219

Do not suppose that the unbelievers have outstripped (Allah). They cannot frustrate Me.

# 1220

Muster against them whatever you are able of force and tethers (ropes) of horses, so that you strike terror into the enemies of Allah and your enemy, and others besides them whom you do not know but Allah does. All that you spend in the Way of Allah shall be repaid to you. You shall not be wronged.

# 1221

If they incline to peace, incline to it also, and put your trust in Allah. Surely, He is the Hearing, the Knowing.

# 1222

Should they seek to deceive you, Allah is sufficient for you. It is He who supported you with His victory and with believers,

# 1223

and brought their hearts together. If you had given away all the riches of the earth, you could not have so united them, but Allah has united them. He isAlmighty, Wise.

# 1224

O Prophet, Allah suffices you and whosoever follows you of the believers.

# 1225

O Prophet, urge the believers to fight. If there are twenty patient men among you, you shall overcome two hundred, and if there are a hundred, they shall overcome a thousand unbelievers, for they are a nation who do not understand.

# 1226

Allah has now lightened it for you, for He knows that there is weakness amongst you. If there are a hundred patient men among you, they shall overcome two hundred; and if there are a thousand, they shall, by the permission of Allah, defeat two thousand. Allah is with the patient.

# 1227

It is not for any Prophet to have prisoners in order to slaughter many in the land. You want the gains of this life, and Allah wants the Everlasting Life, and Allah is Mighty, Wise.

# 1228

Had there not been a previous writing from Allah, you would have been afflicted by a mighty punishment.

# 1229

Eat of what you have taken from the spoils; such is lawful and good, and fear Allah. Allah is Forgiving and Most Merciful.

# 1230

O Prophet, say to those you have taken captive in your hand: 'If Allah finds goodness in your hearts, He will give you that which is better than what has been taken from you, and He will forgive you. Allah is Forgiving, the Most Merciful'

# 1231

But if they seek to betray you, they had betrayed Allah before, but He has let you overcome them. Allah is the Knower, the Wise.

# 1232

Those who believe and migrated, and fought for the Cause of Allah with their wealth and their persons; and those who sheltered them and helped them shall be guides to each other. And those who believe, but have not emigrated you have no guidance towards them till they emigrate. But if they seek your help in the cause of your religion, it is your duty to help them, except against a nation with whom you have a treaty. Allah sees the things you do.

# 1233

The unbelievers, they are guides of one another. Unless you do this, there will be persecution in the land and great corruption.

# 1234

Those who believe and migrated from their homes and fought for the Way of Allah, and those who have sheltered them and helped them they are truly the believers. Theirs shall be forgiveness and a generous provision.

# 1235

And those who believed afterwards and emigrated, and struggled with you they are of you. And in the Book of Allah, the near kinsmen deserve one another (in inheritance). Allah has knowledge of all things.

# 1236

An acquittal from Allah and His Messenger to the idolaters with whom you have made agreements;

# 1237

'For four months you shall journey freely in the land. But know that you shall not render Allah incapable, and that Allah will humiliate the unbelievers'

# 1238

A proclamation from Allah and His Messenger, to the people on the day of the Grand Pilgrimage; 'Allah rejects, and His Messenger (rejects) the idolaters. So if you repent, that will be better for you; but if you turn your backs, know that you cannot frustrate Allah. And give glad tidings to the unbelievers of a painful punishment,

# 1239

except those idolaters who have fully honored their treaties with you and aided none against you. With these fulfill your covenant till their term. Surely, Allah loves the righteous.

# 1240

When the sacred months are over, slay the idolaters wherever you find them. Take them and confine them, then lie in ambush everywhere for them. If they repent and establish the prayer and pay the obligatory charity, let them go their way. Allah is Forgiving and the Most Merciful.

# 1241

If an idolater seeks asylum with you, give him protection in order that he hears the Word of Allah, and then convey him to his place of safety, because they are a nation who do not know.

# 1242

How can the idolaters have any treaty with Allah and His Messenger, except those with whom you have made treaties by the Sacred Mosque? So long as they are straight with you, so be straight with them. Allah loves the righteous.

# 1243

How? If they prevail against you they will respect neither agreements nor ties of kindred. They satisfy you with their tongues, but their hearts are averse; and most of them are wicked.

# 1244

They sell the verses of Allah for a small price and bar others from His Path. Evil is what they have been doing.

# 1245

They honor with the believers neither bonds nor treaties. Such are the transgressors.

# 1246

If they repent and establish the prayer and pay the obligatory charity, they shall become your brothers in the religion. So We make plain Our verses for a nation that knows.

# 1247

But if, after coming to terms with you, they break their oaths and revile your belief, fight the leaders of the disbelief for they have no oaths in order that they will desist.

# 1248

Will you not fight against those who have broken their oaths and conspired to expel the Messenger? They were the first to attack you. Do you fear them? Surely, Allah has better rights that you fear Him, if you are believers.

# 1249

Fight them, Allah will punish them with your hands and degrade them. He will grant you victory over them and heal the chests of a believing nation.

# 1250

He will take away all anger from their hearts: Allah turns to whomsoever He will. Allah is Knowing, Wise.

# 1251

Did you suppose that you would be left before Allah has known those of you who fought and did not take a confidant other than Allah, His Messenger, and the believers? Allah is Aware of what you do.

# 1252

Idolaters should not inhabit the mosques of Allah bearing witness against themselves with disbelief. Those, their deeds have been annulled, and in the Fire they shall live for ever.

# 1253

None should inhabit the mosques of Allah except those who believe in Allah and the Last Day, establish their prayers and pay the obligatory charity, and fear none except Allah. May these be among the guided.

# 1254

Do you consider giving drink to the pilgrims and inhabiting the Sacred Mosque is the same as one who believes in Allah and the Last Day, and struggles in the Way of Allah? These are not held equal by Allah. Allah does not guide the harmdoers.

# 1255

Those who believe, and migrated, and struggle in the Way of Allah with their wealth and their persons are greater in rank with Allah. It is they who are the winners.

# 1256

Their Lord gives them glad tidings of mercy from Him, and pleasure; for them await gardens in which there is eternal bliss.

# 1257

where they shall live for ever. The wage with Allah is great indeed.

# 1258

Believers, do not take your fathers or your brothers for a guide if they love disbelief rather than belief. Whosoever of you takes them for guides are the harmdoers.

# 1259

Say: 'If your fathers, your sons, your brothers, your wives, your tribes, the property you have acquired, the merchandise you fear will not be sold, and the homes you love, are dearer to you than Allah, His Messenger and the struggling for His Way, then wait until Allah shall bring His command. Allah does not guide the evildoers'

# 1260

Allah has helped you on many a battlefield. In the Battle of Hunain, when your numbers were pleasing you they availed you nothing; the earth, for all its vastness, seemed to close in upon you and you turned your backs and fled.

# 1261

Then, Allah caused His tranquility (sechina) to descend upon His Messenger and the believers; He sent legions you did not see and sternly punished the unbelievers. Such is the recompense of the unbelievers.

# 1262

Yet thereafter, Allah turns to whom He will. He is the Forgiving, the Most Merciful.

# 1263

Believers, the idolaters are unclean. Do not let them approach the Sacred Mosque after this year. If you fear poverty, Allah, if He wills, will enrich you through His bounty. He is Knowing, Wise.

# 1264

Fight those who neither believe in Allah nor the Last Day, who do not forbid what Allah and His Messenger have forbidden, and do not embrace the religion of the truth, being among those who have been given the Book (Bible and the Torah), until they pay tribute out of hand and have been humiliated.

# 1265

The Jews say Ezra is the son of Allah, while the Christians (who follow Paul) say the Messiah is the son of Allah. Such are their assertions, by which they imitate those who disbelieved before. Allah fights them! How perverted are they!

# 1266

They take their rabbis and monks as lords besides Allah, and the Messiah, son of Mary, though they were ordered to worship but one God, there is no god except He. Exalted is He above that they associate with Him!

# 1267

They desire to extinguish the Light of Allah with their mouths; but Allah seeks only to perfect His Light, though the unbelievers hate it.

# 1268

It is He who has sent forth His Messenger with guidance and the religion of truth to uplift it above every religion, no matter how much the idolaters hate it.

# 1269

Believers, many are the rabbis and monks who in falsehood defraud people of their possessions and bar people from the Path of Allah. Give glad tidings of a painful punishment to those who treasure gold and silver and do not spend it in the Way of Allah.

# 1270

On that Day they (the treasures) will be heated in the fire of Gehenna (Hell), and their foreheads, sides, and backs will be branded with them, and told: 'These are the things which you have treasured. Taste then that which you were treasuring'

# 1271

The number of the months, with Allah, is twelve in the Book of Allah, the day when He created the heavens and the earth; of these, four are sacred. That is the right religion. Therefore, do not wrong yourselves in them and fight against the unbelievers all together as they themselves fight against you all together; know that Allah is with the cautious.

# 1272

The postponement of sacred months is an increase in disbelief in which the unbelievers are misguided. They allow it one year and forbid it another year, so that they can make up for the months that Allah has sanctified so making lawful what Allah has forbidden. Their foul acts seem fair to them Allah does not guide the unbelievers.

# 1273

Believers, why is it that when it is said to you: 'March in the Way of Allah' you linger with heaviness in the land? Are you content with this life rather than theEverlasting Life? Yet the enjoyment of this life in (comparison to) the Everlasting Life is little.

# 1274

If you do not go forth, He will punish you with a painful punishment and replace you by another nation. You will in no way harm Him; for Allah has power over all things.

# 1275

If you do not help him, Allah will help him as He helped him when he was driven out with one other (Abu Bakr) by the unbelievers. When the two were in the cave, he said to his companion: 'Do not sorrow, Allah is with us' Then Allah caused His tranquility (shechina) to descend upon him and supported him with legions (of angels) you did not see, and He made the word of the unbelievers the lowest, and the Word of Allah is the highest. Allah is Mighty, Wise.

# 1276

Whether lightly or heavily, march on and fight for the Way of Allah, with your wealth and your persons. This will be best for you, if you but knew.

# 1277

Had the gain been immediate or the journey easy, they would have followed you; but the distance seemed far to them. Yet they will swear by Allah: 'Had we been able, we would have gone out with you' They bring destruction upon their souls. Allah knows that they are lying.

# 1278

Allah has forgiven you! Why did you give them leave (to stay behind) until it was clear to you which of them was truthful and knew those who lied?

# 1279

Those who believe in Allah and the Last Day will not ask your permission so that they may struggle with their wealth and their selves. Allah knows best the righteous.

# 1280

Only those who ask your permission do not believe in Allah and the Last Day and whose hearts are filled with doubt. And in their doubt, they waiver.

# 1281

Had they intended to set forth with you, they would have prepared themselves for it. But Allah did not like their going forth and held them back, and it was said: 'Stay back with those who stay back'

# 1282

Had they gone forth among you, they would only have increased your burden, and run to and fro in your midst, seeking to stir up sedition between you; and some of you would listen to them; and Allah knows the harmdoers.

# 1283

Beforehand they had already sought to stir up sedition, and turned things upside down for you, until the truth came, and the command of Allah appeared, although they were averse.

# 1284

Among them are some that say: 'Give us leave and do not expose us to temptation' Surely, they have already succumbed to temptation. Gehenna shall encompass the unbelievers.

# 1285

If good comes to you, it grieves them; but if hardship befalls you, they say: 'We have taken our precautions' and they turn away, rejoicing.

# 1286

Say: 'Nothing will befall us except what Allah has ordained. He is our Guardian. In Allah, let the believers put their trust'

# 1287

Say: 'Are you waiting for anything to befall us except one of the two excellent things (victory or martyrdom)? We are waiting for the punishment of Allah to smite you, either from Him or at our hands. Wait if you will, we are waiting'

# 1288

Say: 'Whether you spend voluntarily or reluctantly it shall not be accepted from you; for you are a wicked nation'

# 1289

Nothing prevents their offerings from being accepted except that they do not believe in Allah and His Messenger. They do not come to the prayer except lazily and spend grudgingly.

# 1290

Let neither their wealth nor their children please you. Through these Allah seeks to punish them in this life, and that their souls depart while they are unbelievers.

# 1291

They swear by Allah that they belong with you, yet they are not of you. They are a nation that are afraid.

# 1292

If they could find a shelter or caverns, or any place to creep into they will turn stampeding to it.

# 1293

There are some among them who find fault with you concerning the distribution of alms. If a share is given to them they are contented, but if they receive nothing then they are angry.

# 1294

Would that they were wellpleased with what Allah and His Messenger have given them, and would say: 'Allah is sufficient for us. Allah will provide for us from His abundance, and so will His Messenger. To Allah, we hope'

# 1295

The obligatory charity shall be only for the poor and the needy, and for those who work to collect it, and to influence hearts (to belief), for ransoming captives, and debtors in the Way of Allah and the destitute traveler. It is an obligation from Allah. Allah is Knowing, Wise.

# 1296

And there are others among them who hurt the Prophet saying: 'He lends an ear (to everything)' Say: 'He lends an ear of good for you; he believes in Allah and trusts the believers, and he is a mercy to the believers among you. Those who hurt the Messenger of Allah for them there is a painful punishment'

# 1297

They swear in the Name of Allah in order to please you. But it is more just that they should please Allah and His Messenger if they are believers.

# 1298

Are they not aware that whosoever opposes Allah and His Messenger shall live for ever in the Fire of Gehenna? That surely is the greatest degradation.

# 1299

The hypocrites are afraid lest a chapter be sent down against them telling them what is in their hearts. Say: 'Mock if you will; Allah will surely bring forth what you are fearing'

# 1300

If you question them, they will say: 'We were only plunging and playing' Say: 'Were you mocking Allah, His verses, and His Messenger?

# 1301

Do not make excuses. You have disbelieved after you believed. If we forgive some of you, We will punish others, for they were sinners'

# 1302

Be they men or women, the hypocrites are all alike. They order what is evil, forbid what is just, and tighten their purse strings. They forsook Allah, so Allah forsook them. Surely, the hypocrites are evildoers.

# 1303

Allah has promised the hypocrites, both men and women, and the unbelievers the Fire of Gehenna. They shall live in it for ever. It is sufficient for them. Allah has cursed them and for them is a lasting punishment.

# 1304

You are like those before you. They were stronger than you in might, and had greater riches and more children. They took enjoyment in their share, so do you take enjoyment in your share as those before you took enjoyment in their share. You have plunged as they plunged. Those, their works are annulled, failed in this world and in the Everlasting Life, those, they are the losers.

# 1305

Have they not heard the news of those who have gone before them? The news of the nations of Noah, Aad and Thamood, of Abraham's nation, and the people of Midian and the ruined cities? Their Messengers showed them clear signs. Allah did not harm them, but they harmed themselves.

# 1306

The believers, both men and women, are guides to each other. They order what is just and forbid what is evil; they establish their prayers and pay the obligatory charity and obey Allah and His Messenger. On these Allah will have mercy. He is Mighty, Wise.

# 1307

Allah has promised the believing men and women gardens underneath which rivers flow, in which they shall live for ever. Goodly mansions in the Gardens of Eden, and the pleasure from Allah which is greater. That is the greatest winning.

# 1308

O Prophet, struggle with the unbelievers and the hypocrites and be harsh with them. Gehenna shall be their refuge an evil arrival.

# 1309

They swear by Allah that they said nothing. Yet they did utter the word of disbelief and disbelieved after they had submitted. They intended what they never attained to, and took revenge only that Allah enriched them, and His Messenger, of His Bounty. If they repent, it will indeed be better for them; but if they turn away, Allah will sternly punish them both in this world and in the Everlasting Life. They have none on earth to protect or help them.

# 1310

Some of them have made a covenant with Allah, 'If Allah gives to us of His bounty, we will give charity and be of the righteous'

# 1311

But when Allah had bestowed His bounty on them they became greedy and turned away, swerving aside.

# 1312

He has caused hypocrisy to be in their hearts till the Day they meet Him, because they have changed what they promised Allah and because they were liars.

# 1313

Did they not know that Allah knows their secret and what they conspire together, and that Allah knows all the unseen?

# 1314

As for those who taunt the believers who give charity voluntarily, and scoff at those who give according to their means, Allah will scoff at them. Theirs shall be a painful punishment.

# 1315

(It is the same) whether or not you beg forgiveness for them. If you beg forgiveness for them seventy times Allah will not forgive them, for they have disbelieved in Allah and His Messenger. Allah does not guide the evildoers.

# 1316

Those who were left behind were glad that they were left behind by the Messenger of Allah, for they disliked to struggle in the Way of Allah with their wealth and their persons. They said: 'Do not go forth in the heat' Say: 'The Fire of Gehenna is more hot' Would that they understood!

# 1317

They shall laugh but little and shed many tears. So shall they be recompensed for their earnings.

# 1318

If Allah brings you back to a party of them and they ask permission to march with you, say: 'You shall never march with me, nor shall you fight with me against any enemy. You were pleased to remain on the first occasion, therefore, you shall now stay with those who remain behind'

# 1319

You shall never pray over any one of them when he is dead, nor stand over his tomb. For they disbelieved in Allah and His Messenger and died whilst they were sinners.

# 1320

Let neither their riches nor their children please you. With it Allah wants to punish them in this life, so that their souls depart while they disbelieve.

# 1321

Whenever a chapter is sent down, saying: 'Believe in Allah and struggle with His Messenger' the rich among them asked you to excuse them, saying: 'Leave us with those who are to stay behind'

# 1322

They were content to be with those who stayed behind, a seal was set upon their hearts, so they do not understand.

# 1323

But the Messenger and those who believed with him struggled with their wealth and their selves For them awaits goodness and those are the winners.

# 1324

Allah has prepared for them gardens underneath which rivers flow, in which they shall live for ever. That is the greatest winning.

# 1325

Some Arabs of the desert who had an excuse came asking permission to stay behind; whilst those who belied Allah and His Messenger remained behind. A painful punishment shall fall on those of them that disbelieved.

# 1326

There is no fault for the weak, the sick, and those lacking the means to spend (to stay behind), if they are true to Allah and His Messenger. There is no way against the righteous; Allah is Forgiving, the Most Merciful.

# 1327

Nor shall those who came to you to be provided with mounts. And when you said: 'I can find no mounts for you' they turned back, their eyes streaming with tears grieving that they could not find the means to spend.

# 1328

But the blame is to be laid on those who asked permission of you whilst they are rich. They are content to remain with those who stay behind. Allah has set a seal upon their hearts so they do not know.

# 1329

When you return, they will apologize to you. Say: 'Make no excuses; we will not believe you. Allah has already told us of your news. Surely, Allah and His Messenger will see your work; then you will be returned to the Knower of the unseen and the visible, and He will inform you of what you were doing'

# 1330

When you return to them, they will swear to you by Allah that you might turn aside from them. Let them alone, they are unclean. Gehenna shall be their refuge, a recompense for their earnings.

# 1331

They will swear to you in order to please you. But if you will be pleased with them, Allah will not be pleased with the evildoing nation.

# 1332

The Bedouin Arabs surpass (the city dwellers) in disbelief and hypocrisy, and are more likely not to know the bounds that Allah has sent down to His Messenger. But Allah is Knowing, Wise.

# 1333

Some Arabs (Banu Asad and Ghatfan tribes) regard what they spend as a (compulsory) fine and wait for some misfortune to befall you. Theirs shall be the evil turn! Allah is Hearing, Knowing.

# 1334

Yet there are some Arabs (Juhaina and Muszaina tribes) who believe in Allah and the Last Day, and regard what they spend as a means of bringing them close to Allah and to the prayers of the Messenger. Indeed, they are an offering for them; Allah will admit them to His Mercy. He is Forgiving, Merciful.

# 1335

As for the first outstrippers among the migrants and supporters and those who followed them in doing good, Allah is pleased with them and they are pleased with Him. He has prepared for them gardens underneath which rivers flow, where they shall live for ever. That is the greatest winning.

# 1336

Some of the Bedouin Arabs around you are hypocrites, and so are some of the people of Madinah who are well versed in hypocrisy. You do not know them, but We do. Twice We will punish them then they shall return to a mighty punishment.

# 1337

There are others who have confessed their sins; they intermixed good deeds with another evil. It may be that Allah will turn towards them in mercy. Allah is Forgiving, Merciful.

# 1338

Take charity from their wealth, in order that they are thereby cleansed and purified, and pray for them; for your prayer is a comforting mercy for them. Allah is Hearing, Knowing.

# 1339

Do they not know that Allah accepts the repentance of His worshipers and takes their charity, and that Allah is the Forgiving, the Merciful?

# 1340

Say: 'Allah will see your works and so will His Messenger and the believers; then you shall be returned to the Knower of the unseen and the visible, and He will inform you of what you were doing'

# 1341

There are others who must wait for the Commandment of Allah. He will either punish or turn towards them. And Allah is Knowing, Wise.

# 1342

And there are those who have taken a mosque to cause harm, disbelief, and to divide the believers, and as a place of ambush for those who fought Allah and His Messenger before. They swear: 'We desired nothing but good', but Allah bears witness that they are liars.

# 1343

You shall never stand there. A mosque founded upon piety from the first day is worthier for you to stand in. In it are men who love to purify themselves. Allah loves those who purify themselves.

# 1344

Is he who founds his building on the fear of Allah and His pleasure, better or he who founds his building on the brink of a crumbling edge so that it will tumble with him into the Fire of Gehenna? Allah does not guide the harmdoers.

# 1345

The buildings they have built will always cause doubt in their hearts, unless their hearts are torn into pieces. Allah is Knowing, Wise.

# 1346

Allah has purchased from the believers their selves and possessions, and for them is Paradise. They fight in the Way of Allah, slay, and are slain. That is a binding promise upon Him in the Torah, the Gospel and the Koran; and who is there that more truthfully fulfills his covenant than Allah? Therefore, rejoice in the bargain you have bargained with Him. That is the mighty winning.

# 1347

Those who repent, those who worship Allah and praise (Him); those who journey, those who bow, those who prostrate themselves; those who order righteousness and forbid evil, and those who observe the limits of Allah give glad tidings to the believers.

# 1348

It is not for the Prophet or the believers to ask forgiveness for idolaters, even though they are near kindred, after it has become clear that they are the inhabitants of Hell.

# 1349

Abraham only asked for forgiveness for his father because of a promise he had made to him. But when it became clear to him that he was an enemy of Allah, he declared himself quit of him. Surely, Abraham was earnest in his supplication and tenderhearted.

# 1350

Nor will Allah lead a nation astray after He has given them guidance until He has made clear to them all that they should guard against. Allah has knowledge of all things.

# 1351

Indeed, to Allah belong the kingdom of the heavens and the earth; He gives life and causes death. Other than Allah, you have neither a guardian nor a helper.

# 1352

In the hour of adversity, Allah turned (in mercy) to the Prophet, the Emigrants (of Mecca) and the Supporters (of Madinah) who followed him when some of their hearts were about to swerve away. He turned to them, indeed, He is Gentle, the Most Merciful.

# 1353

And to the three who were left behind (at the Battle of Tabuk), until the earth became narrow with all its vastness, and their souls became narrow for them, they knew there was no shelter from Allah except in Him. Then He turned to them (in mercy) so that they might also turn (in repentance). Allah is the Turner, the Most Merciful.

# 1354

Believers, fear Allah and stand with the truthful.

# 1355

The people of Madinah and the Arabs who dwell around them have no cause to stay behind the Messenger of Allah, or to prefer their lives to his. They are neither stricken by thirst, nor by tiredness, nor yet by hunger in the Way of Allah, nor do they take steps that anger the unbelievers, nor gain any gain from an enemy, but that it is counted as a righteous deed. Allah does not waste the wage of the gooddoers.

# 1356

Each sum they spend, be it small or large, and each valley they cross is written to their account, so that Allah may recompense them for their best deeds.

# 1357

The believers should not go forth altogether, rather, a party from each section should go forth to become well versed in the religion, and when they return to their people warn them in order that they may beware.

# 1358

Believers, fight the unbelievers who are near you. Let them find firmness in you. Know that Allah is with those who are cautious.

# 1359

Whenever a chapter is sent down to you, some ask: 'Which of you has it increased in belief' It will surely increase the belief of the believers and they are joyful.

# 1360

As for those whose hearts are diseased, they will be increased in filth added to their filth, so that they die as unbelievers.

# 1361

Do they not see how once or twice every year they are tried? Yet still they neither repent nor remember.

# 1362

Whenever a chapter is sent down, they glance at each other, (asking): 'Does anyone see you' Then they turn away. Allah has turned away their hearts, for they are a nation who do not understand.

# 1363

Indeed, there has come to you a Messenger from your own, he grieves for your suffering, and is anxious about you, and is gentle, merciful to the believers.

# 1364

Therefore, if they turn away, say: 'Allah is sufficient for me. There is no god except He. In Him I have put my trust. He is the Lord of the Mighty Throne'

# 1365

AlifLaamRa. Those are the verses of the Wise Book.

# 1366

Is it a wonder to the people that We revealed to a man from among themselves: 'Warn mankind, and bear the glad tidings to those who believe that they stand firm with their Lord' (Yet) the unbelievers say: 'This is a clear sorcerer'

# 1367

Indeed, your Lord is Allah, who, in six days created the heavens and the earth and then willed to the Throne, directing affairs. There is no intercessor except by His permission. Such is Allah your Lord, therefore worship Him. Will you not remember?

# 1368

To Him all of you will return together. This is, in truth, the promise of Allah. He originates creation, then He revives it so that He may recompense those who believe and do righteous deeds. As for the unbelievers, theirs is a drink of boiling water and a painful punishment for their disbelief.

# 1369

It was He that made the sun a brightness and the moon a light, and determined it in phases so that you might know the number of years and the reckoning. Allah did not create them except in truth, and distinguishes the verses to a nation who know.

# 1370

In the alternation of the night and day, and in all that Allah has created in the heavens and the earth, surely there are signs for people who are cautious.

# 1371

Those who do not expect to meet Us, and are wellpleased with this life and are satisfied with it, and those who are inattentive to Our signs,

# 1372

for them, their refuge is the Fire for what they have been earning.

# 1373

Indeed, those who believe and do righteous works, their Lord will guide them for their belief, beneath them rivers will flow in gardens of bliss.

# 1374

(In it) their supplication will be: 'Exaltations to You, Allah' And their greeting will be: 'Peace' They will end their supplication with 'Praise be to Allah, Lord of the all the Worlds'

# 1375

If Allah should hasten evil to people as they would hasten good, their term would already have been decided. But We leave those who do not expect to meet Us to wander blindly in their insolence.

# 1376

When affliction befalls a man, he supplicates to Us (lying) on his side, sitting or standing. But as soon as We relieve him from his affliction, he continues (in the same way), as though he never supplicated to Us when harm touched him. So it is, that which the sinners were doing seem fairly decorated to them.

# 1377

We destroyed generations before you when they did evil. (When) their Messengers came to them with clear verses they would not believe; so We recompense the sinning nation.

# 1378

After them We made you their successors in the earth, so that We might see how you would do.

# 1379

When Our verses, clear verses, are recited to them, those who do not reckon to meet Us say: 'Bring a Koran other than this, or make changes in it' Say: 'It is not for me to change it by myself. I follow nothing, except what is sent down to me. Indeed, if I should rebel against my Lord I fear the punishment of a Great Day.'

# 1380

Say (Prophet Muhammad): 'Had Allah willed, I would not have recited it to you, nor would He have made it known to you. I lived among you all my life before it (was sent down). Will you not understand?

# 1381

Who does greater evil than he who forges a lie about Allah or belies His verses? Indeed, the evildoers do not prosper.

# 1382

They worship, other than Allah, that which can neither harm nor benefit them, and say: 'These are our intercessors with Allah' Say: 'Will you tell Allah of something He does not know about either in the heavens or earth? Exaltations to Him! Exalted be He above what they associate'

# 1383

(Before) mankind were but one nation, then they differed with one another. But for a Word that preceded from your Lord, it (the matters) over which they differed had already been decided.

# 1384

They say: 'Why has no sign been sent down to him from his Lord' Say: 'The Unseen belongs to Allah alone. Wait if you will I am one of those who wait'

# 1385

When We let people taste (Our) mercy after they had been afflicted by hardship, they devise against Our verses. Say: 'Allah is more swift in devising' Indeed, Our Messengers (the angels) are writing down whatever you devise.

# 1386

It is He who conveys you by land and sea. When you are on board the ship and the ships run with them upon a fair breeze they are joyful. (But when) a strong wind and waves come upon them from every side, and they think they are encompassed, they supplicate to Allah, making their religion His sincerely, (saying): 'If You save us from this, we will indeed be among the thankful'

# 1387

But when He has saved them, see how they become wrongfully insolent in the land. People, your insolence is only against yourselves; the enjoyment of this present life, then to Us you shall return and We shall tell you what you did.

# 1388

This present life is like the water We send down from the sky. The plants of the earth mix with it and from it mankind and cattle eat; then when the earth has become lush and adorned, its inhabitants think they have power over it, Our command comes upon it by night or day, and We cause it to be stubble, just as though it had not flourished the day before. In this way We distinguish Our verses for those who reflect.

# 1389

Allah invites you to the House of Peace. He guides whom He will to a Straight Path

# 1390

for those who do good is a fine reward and a surplus. Neither dust nor shame shall cover their faces. Those are the companions of Paradise in it they shall live for ever.

# 1391

As for those who have earned evil deeds, evil shall be recompensed with its like. Abasement will cover them, they shall have none to defend them from Allah as though their faces were covered with parts of the blackness of night. Those, they are the companions of the Fire, in it they shall live for ever.

# 1392

And on the Day when We assemble them all together, We shall say to those who associated (other gods with Allah): 'Go to your place, you and your associates' Then, We will separate them, and their associates will say (to them): 'It was not us that you worshipped'

# 1393

Allah is a Sufficient witness between us and you, surely, we were heedless of your worship.

# 1394

There, each soul shall prove its past deeds. They shall be restored to Allah, their Guardian, the True, and that which they forged will escape from them.

# 1395

Say: 'Who provides for you from heaven and earth, or who owns the hearing and the sight? Who brings forth the living from the dead, and the dead from the living' Who directs the affair? Surely, they will say: 'Allah' Then say: 'Then, will you not be fearful'

# 1396

Such is Allah, your Lord, the True. What, is there after truth, anything except error. Then how are you turned around (from faith)'

# 1397

So the Word of your Lord is realized against the evildoers that they do not believe.

# 1398

Say: 'Is there any (among) your associates who originates creation, then cause it to be revived yet again' Say: 'Allah, He originates creation, then revives it yet again. How is it that you are so perverted'

# 1399

Say: 'Do any of your partners guide you to the truth' Say: 'Allah, He guides to the truth. Who then is worthier to be followed He who guides to the truth or he who cannot guide unless he (himself) is guided? What is the matter with you, how then can you judge'

# 1400

Most of them follow nothing except conjecture. But conjecture does not help against the truth. Allah knows the things they do.

# 1401

This Koran could not have been forged by other than Allah. It confirms what was before it; a distinguishing Book, in which there is no doubt, from the Lord of all the worlds.

# 1402

Do they say: 'He has forged it'. Say: 'Compose one chapter like it, and call upon whom you will, other than Allah (to help you), if what you say is true'

# 1403

They have belied that which they did not understand of its knowledge, nor has its interpretation reached them. Those who were before also belied. But see how was the end of the harmdoers.

# 1404

Some believe in it, while others do not believe it. Your Lord knows well the corrupters.

# 1405

If they belie you, say: 'I have my work, you have your work. You are quit of what I do, and I am quit of what you do'

# 1406

Some of them listen to you. But can you make the deaf hear you, even though they cannot understand?

# 1407

Some of them look to you. But can you guide the blind, even though they do not see?

# 1408

Indeed, Allah does not wrong mankind a thing, but they wrong themselves.

# 1409

The Day when He will gather them, (it will be) as though they had lingered but an hour of the Day and they will recognize one another. Lost are those who belied the meeting with their Lord and were not guided.

# 1410

Whether We let you see some of that with which We promised them, or We call you to Us, to Us they shall return. Allah is witness of the things they do.

# 1411

Every nation has its Messenger. Then, when their Messenger comes the matter is justly decided between them; they are not wronged.

# 1412

They ask: 'If what you say is true, when will this promise come'

# 1413

Say: 'I have no power to benefit or harm myself except as Allah wills. To every nation is a fixed term and when their term comes they cannot delay it for an hour, nor can they bring it forward.

# 1414

Say: 'Have you considered? Should His punishment come upon you by night or by day, what (part) of it would the sinners try to hasten'

# 1415

And when it overtakes you, is it then that you will believe in it, now, when you already try to hasten it!

# 1416

Then it shall be said to the evildoers: 'Taste the punishment of eternity! Shall you be recompensed except according to what you earned'

# 1417

They ask you to tell them if it is true. Say: 'Yes, by my Lord! It is true, and you cannot frustrate it'

# 1418

If each soul that has done evil had all that is in the earth, it would offer it for its ransom. And secretly they will feel regret when they see the punishment, and the matter is justly decided between them, and they are not wronged.

# 1419

Indeed, to Allah belongs everything in the heavens and the earth. Indeed, the promise of Allah is true though most of them do not have knowledge.

# 1420

It is He who gives life and causes death, and to Him you shall be returned.

# 1421

People, an admonition has now come to you from your Lord, and a healing for what is in the chests, a guide and a mercy to believers.

# 1422

Say: 'In the Bounty of Allah and His Mercy let them rejoice, it (the Koran) is better than that which they hoard'

# 1423

Say: 'Have you considered the provision that Allah has sent down for you, and some you have made unlawful and some lawful' Say: 'Has Allah given you His permission, or do you forge (falsehood) against Allah'

# 1424

What will those who forged falsehood about Allah think on the Day of Resurrection? Allah is Bountiful to mankind; yet most of them do not give thanks.

# 1425

You are not engaged in any matter, neither do you recite any portion of the Koran, nor do you do any work, except that We are witnesses over you when you press upon it? Not even as much as the weight of an ant in earth or heaven escapes your Lord, nor is there anything smaller or greater, but it is (recorded) in a Clear Book.

# 1426

Indeed, there shall be neither fear nor sorrow upon the guided by Allah.

# 1427

Those who believe and are cautious

# 1428

there is for them glad tidings in this present life and in the Everlasting Life. The Word of Allah is unchanging, that is the mighty triumph.

# 1429

Do not let their speech grieve you. All might belongs to Allah. He is the Hearing, the Knowing.

# 1430

Attention: Indeed to Allah belongs everyone that is in the heavens and in the earth. Those who call upon associates, other than Allah, follow nothing but assumptions, (they are) only lying.

# 1431

He it is who has made the night for your rest and the day to see. Surely, in this there are signs for people who listen.

# 1432

They say: 'Allah has taken a son' Exaltations be to Him (Allah)! Rich is He. To Him belongs all that is in the heavens and the earth you have no authority for this! What, do you say of Allah what you do not know?

# 1433

Say: 'Those who forge falsehoods against Allah shall not prosper'

# 1434

(They take their) enjoyment in this world, but to Us they shall return, then, We shall let them taste the terrible punishment because they were unbelievers'

# 1435

And recite to them the story of Noah. He said to his nation: 'O my nation, if my standing here, reminding you of the verses of Allah grieves you, and in Allah I have put my trust; decide upon your affair with your associates, then do not let your affair worry you. Come to a decision about me, and give me no respite.

# 1436

Then, if you turn your backs, I have not asked of you a wage. My wage falls only on Allah. I am commanded to be from those who surrender (Muslims)'

# 1437

But they belied him. Therefore We saved him and those who were with him in the Ark, and We made them caliphs, and We drowned those who belied Our verses. See what was the end of those who were warned!

# 1438

After him We sent Messengers to their nation. They brought them clear signs, but they were not of those to believe because they had belied it previously. SoWe seal the hearts of the evildoers.

# 1439

Then, after them We sent Moses and Aaron with Our signs to Pharaoh and his Council. But they were arrogant, for they were a sinful nation.

# 1440

When the truth came to them from Us they said: 'This is indeed clear magic'

# 1441

Moses said: 'Is this what you say of the truth when it has come to you? Is this sorcery? Sorcerers do not prosper'

# 1442

They said: 'Have you come to turn us away from that which we found our fathers practicing (in order that) the domination of the land might belong to you two? We do not believe you'

# 1443

(Then) Pharaoh said: 'Bring every skilled sorcerer'

# 1444

When the sorcerers came, Moses said to them: 'Cast down what you will cast'

# 1445

And when they had cast, Moses said: 'What you have brought is sorcery. Surely, Allah will render it as nothing. Allah does not put right the work of the corrupt'

# 1446

Allah verifies the truth by His Words, even though the sinners hate it.

# 1447

So none believed Moses except a few of his nation because they feared that Pharaoh and their Council would persecute them. Pharaoh was mighty in theland, and one of the evildoers.

# 1448

Moses said: 'O my nation, if you believe in Allah, put your trust in Him, if you have surrendered (Muslims)'

# 1449

They said: 'We have put our trust in Allah. Our Lord, do not let us be a temptation to the harmdoing nation.

# 1450

Save us, through Your Mercy, from the unbelieving nation'

# 1451

We revealed to Moses and his brother: 'Take certain houses for your people in Egypt. Make your houses a direction (for pray); establish the prayer; and give glad tidings to the believers'

# 1452

'Our Lord' supplicated Moses. 'You have given Pharaoh and his Council adornments and possessions in this life. Our Lord, let them go astray from YourPath. Our Lord, destroy their possessions and harden their hearts so that they shall not believe until they see the painful punishment.

# 1453

He (Allah) said: 'Your supplication is answered; so go straight and do not follow the way of those who do not know'

# 1454

We brought the Children of Israel through the sea, and Pharaoh and his legions pursued them arrogantly and frantically. But as he was drowning he cried out: '(Now) I believe that there is no god except He in whom the Children of Israel believe. I am of those that surrender (Muslims)'

# 1455

(Allah said): 'Now (you believe)! But before this you rebelled and were of the corrupt.

# 1456

We shall deliver you (Ramsis II) with your body this day, so that you may be a sign to those after you. Indeed many people pay no heed to Our signs!

# 1457

(Thereafter) We settled the Children of Israel in a blessed land and provided them with good things. They did not differ until knowledge was given them. Indeed, your Lord will decide between them on the Day of Resurrection.

# 1458

If you are in doubt of what We have sent down to you, ask those who recite the Book before you. The truth has come to you from your Lord, therefore do not be of the doubters.

# 1459

Do not be among those who belie the verses of Allah, for then you would be among the losers.

# 1460

Those against whom the Word of your Lord will be realized will not believe,

# 1461

even though every sign comes to them, until they see the painful punishment.

# 1462

Why, was there never a village that believed and its belief benefited them? Except Jonah's nation, when they believed, We spared them from a degrading punishment in this life and We gave them enjoyment for awhile.

# 1463

Had your Lord willed, whosoever is in the earth, all would have believed. Would you then constrain people until they believe?

# 1464

No soul can believe except by the permission of Allah. Upon those who do not understand lays His punishment.

# 1465

Say: 'See what is in the heavens and the earth' But neither signs nor warnings help the unbelievers.

# 1466

Do they watch and wait for anything except for days similar to those who passed away before them? Say: 'Wait; I shall be with you among those who arewaiting'

# 1467

Then we shall save Our Messengers and the believers. It is Our obligated duty, We shall save those who believe.

# 1468

Say: 'O people! If you are in doubt concerning my religion, I worship none of those you worship, other than Allah but I worship Allah, who will cause you to die, for I am commanded to be among the believers,

# 1469

and, set your face towards the religion, being of pure faith, and do not be among the idolaters.

# 1470

Do not pray to, other than Allah, to anything that can neither help nor harm you, for if you do, you will become a harmdoer.

# 1471

If Allah touches you an affliction none can remove it except He; and if He wills any good for you, none can repel His Bounty. He causes it to fall upon whosoever of His worshippers that He will. He is the Forgiving, the Most Merciful.'

# 1472

Say: 'O people! The truth has come to you from your Lord. Whosoever is guided is guided only for himself, and whosoever goes astray, he is astray for himself. I am not a guardian over you'

# 1473

Follow what is revealed to you, and be patient till Allah shall judge, and He is the Best of judges.

# 1474

AlifLaamRa. (This is) a Book whose verses are clear, and then distinguished from Him, the Wise, the Aware.

# 1475

Worship none except Allah. I am for you, a warner sent from Him and a bearer of glad tidings.

# 1476

And ask forgiveness of your Lord and then repent to Him. He will give you enjoyment till a stated term and will give of His Bounty to those of grace. But if you turn away, I fear for you the punishment of a Mighty Day.

# 1477

To Allah you shall all return. He has power over all things.

# 1478

See, they cover their chests to conceal from Him. But when they wrap themselves in their clothes He knows what they hide and what they reveal. Indeed, He knows every thought within the chest.

# 1479

There is not a crawling (creature) on the earth whose provision is not by Allah. He knows its resting place and its repository. All is in a Clear Book.

# 1480

It is He who created the heavens and the earth in six days and His Throne was upon the waters that He might try you, (and see) which of you excel in works. If you say: 'After death you shall be raised up' the unbelievers will say: 'This is nothing but clear sorcery'

# 1481

And if We delay the punishment till an appointed time, they will ask: 'What has detained it' Indeed, the Day will come to them, it will not be turned awayfrom them, and that they mocked at will encompass them.

# 1482

If We let a human taste Our Mercy and then withhold it from him, he becomes desperate and ungrateful.

# 1483

And if after adversity had come upon him, We let him taste prosperity, he says: 'Evil has left me' see, he is jubilant and boastful,

# 1484

except those who are patient and do good deeds, for them awaits forgiveness and a mighty wage.

# 1485

Perhaps you are leaving part of what has been sent down to you, and your chest is straitened by it, because they say: 'Why has no treasure been sent down to him, or an angel come with him' You are only a warner, and Allah is a Guardian over everything.

# 1486

Or do they say: 'He has forged it' Say (to them): 'Then produce ten forged chapters like it. Call, if you are able, upon other than Allah, if what you say is true'

# 1487

But if they do not answer you, know that it has been sent down with the knowledge of Allah, and that there is no god except He. So, have you surrendered (become Muslims)?

# 1488

We shall pay those who desire the present life and its adornments in full for the work they have done therein, they shall not be defrauded;

# 1489

those are they who in the Everlasting Life will have only the Fire. There, their deeds will have failed and their works will be void.

# 1490

Then what of he who stands upon a clear proof from his Lord, recited by a witness from Him and before him is the Book of Moses for a guide and a mercy? Those believe in it. But as for those partisans who disbelieve in it, their promised land shall be the Fire. Therefore do not doubt it. It is the truth from your Lord, yet most people do not believe.

# 1491

And who is greater in evil than he who forges a lie against Allah? Those, they shall be brought before their Lord, and witnesses will say: 'Those are they who lied against their Lord' Indeed, the curse of Allah shall fall upon the evildoers,

# 1492

who bar others from the Path of Allah and seek to make it crooked, they disbelieve in the Everlasting Life.

# 1493

They are unable to frustrate Him on the earth; there is none to protect them, except Allah. Those, their punishment shall be doubled; they could neither hear nor see.

# 1494

Those are they that have lost their souls, and that which they forged has left them;

# 1495

without doubt they will be the greatest losers in the Everlasting Life.

# 1496

Whereas those who believe and do good deeds and humble themselves before their Lord, they are the companions of Paradise, and there they shall live for ever.

# 1497

The likeness of the two parties is as one who is blind and deaf, and one that sees and hears, are they equally alike, will you not remember?

# 1498

We sent Noah to his nation. (He said:) 'I am a warner for you, and a bearer of glad tidings.

# 1499

Worship none except Allah. I fear for you the punishment of a painful Day'

# 1500

The unbelieving Council of his nation said: 'We do not see you other than a human like ourselves. We see your followers are none but the lowliest amongst us, and their opinion is not to be considered. We do not see you superior to us, rather, we consider you liars'

# 1501

He said: 'What do you think my nation! If I have a clear proof from my Lord and He has given me mercy from Him, though it is hidden from you, can wecompel you to accept it when you hate it?

# 1502

My nation, for this I do not ask you for your wealth for my wage is only with Allah. Nor will I drive away the believers, for they will surely meet their Lord. But, I can see that you are ignorant.

# 1503

Were I to drive you away my nation, who would help me from Allah? Will you not remember?

# 1504

I do not say to you that I possess the treasuries of Allah, and I do not know the unseen. I do not say I am an angel, nor do I say to those whom you despise, Allah will not give them any good. Allah knows best what is in their hearts. Indeed, if this were so then I would be amongst the harmdoers'

# 1505

They said: 'O Noah, you have disputed, and disputed too much, with us. Bring (down) upon us that which you promised us, if what you say is true'

# 1506

He replied: 'Allah will bring it (down) upon you if He will; you will never frustrate Him.

# 1507

Nor will my sincere counsel benefit you if I sincerely desire to counsel you if Allah desires to lead you astray. He is your Lord, and to Him you shall return'

# 1508

Or do they say: 'He has fabricated it (himself)' Say: 'If I had fabricated it, then the sin rests upon me. I reject the sins you do'

# 1509

And it was revealed to Noah: 'None of your nation will believe except whosoever has already believed. Do not distress yourself with what they may do.

# 1510

Build the Ark with Our seeing (and protection), and as We reveal. Do not speak to Me concerning the evildoers; they shall be drowned'

# 1511

Whenever an assembly of his nation passed by him as he was building the Ark, they mocked him. Whereupon he said: 'If you mock us, we shall indeedmock you, just as you mock.

# 1512

You shall know to whom a degrading punishment will come, and upon whom an everlasting punishment will fall'

# 1513

And when Our command came and the oven gushed (forth with water), We said (to Noah): 'Take on board (the Ark) a pair from every species and yourfamily, except he of whom the word has already been spoken, and those who believe. And none except a few believed with him.

# 1514

He (Noah) said: 'Embark. In the Name of Allah will be its course and berthing. Indeed, my Lord is Forgiving, the Most Merciful'

# 1515

And so it (the Ark) ran with them amidst the mountainous waves, and Noah cried out to his son, who was standing apart, 'Embark with us, my son, do not be with the unbelievers'

# 1516

But he replied: 'I shall seek refuge on a mountain, which will protect me from the water' He (Noah) said: 'Today, there is no defender from the command of Allah, except those to whom He has mercy' And the waves came between them, and he was drowned.

# 1517

And it was said: 'Earth, swallow up your waters. Heaven, cease' The water subsided and the matter was accomplished. And the Ark came to rest upon (the mountain of) AlJudi, and it was said: 'Be gone, evildoing nation'

# 1518

Noah called out to his Lord, saying: 'O Lord, my son was of my family, and Your promise is surely the truth. You are the most Just of judges'

# 1519

He said: 'Noah, he is not of your family. It is not a good deed. Do not ask Me about things of which you have no knowledge. I reproach you lest you become among the ignorant'

# 1520

He said: 'My Lord, I seek refuge with You from asking You of that which I have no knowledge. If You do not forgive me and have mercy on me, I shall be among the losers'

# 1521

It was said: 'O Noah, descend with peace from Us and blessings on you and on the nations of those with you; and nations We shall give them enjoyment, and then from Us they shall be visited with a painful punishment'

# 1522

That is from the news of the unseen which We reveal to you; neither you nor your nation knew this before now. Have patience; the outcome is for the cautious.

# 1523

To Aad (We sent) their brother Hood. He said: 'My nation, worship Allah; you have no god except He. You are only forgers.

# 1524

My nation, for this I ask of you no wage. My wage is only with He who created me. Will you not understand?

# 1525

My nation, ask your Lord to forgive you and turn to Him in repentance. From the sky He will loose an abundance (of rain) upon you; He will add strength to your strength. Do not turn away as sinners'

# 1526

They replied: 'Hood, you have not brought us a clear sign. We will not forsake our gods because of what you say. We do not believe you.

# 1527

We say nothing except our gods have afflicted you with some kind of evil' He said: 'I call Allah to witness, and you to bear witness, that I reject what you associate,

# 1528

other than Him, so all of you, scheme against me, then you shall give me no respite.

# 1529

In truth, I have put my trust in Allah, (who is) my Lord and your Lord. There is no crawling creature that He does not take by the forelock. Indeed, my Lord is on a Straight Path.

# 1530

If you turn away, I have delivered to you that with which I was sent, and my Lord will cause people other than you to be your successors. You cannot harm Him a thing. My Lord is the Guardian over every thing'

# 1531

And when Our command came, We saved Hood, together with those who believed with him through Our Mercy, and saved them from a harsh punishment.

# 1532

Such was Aad. They disbelieved the verses of their Lord, rebelled against His Messengers, and did the bidding of every rebellious tyrant.

# 1533

They were overtaken by a curse in this world, and (they shall be cursed) on the Day of Resurrection. Indeed, Aad disbelieved in their Lord. Gone are Aad, the nation of Hood.

# 1534

And to Thamood, (We sent) their brother Salih. He said: 'My nation, worship Allah; you have no god except He. It is He who made you from the earth and let you live upon it. Ask His forgiveness then repent to Him. Indeed, my Lord is near and answers (prayers)'

# 1535

They said: 'Salih, before this you were a source of hope to us. What, would you now forbid us to worship what our fathers worshipped? Indeed, we are disquieted, and doubt that to which you invite'

# 1536

He said: 'My nation, think! If I have a clear proof from my Lord and He has given me His Mercy, who would help me against Allah if I rebel against Him? Indeed, you would do nothing for me except increase my loss'

# 1537

'My nation, this is the shecamel of Allah, a sign for you. Leave her to graze upon the earth of Allah and do not touch her with evil lest you be seized by a punishment that is near'

# 1538

Yet they hamstrung her. He (Salih) said: 'Take your enjoyment in your homes for three days! This is a promise that cannot be belied'

# 1539

And when Our command came, We saved Salih together with those who believed with him through Our Mercy, and from the ignominy of that day. YourLord is Strong and Mighty.

# 1540

And the harmdoers were seized by the Shout (of the angel), and in the morning, they were found crouched in their dwellings, dead,

# 1541

as though they had never lived there. Indeed, Thamood disbelieved in their Lord. So, begone Thamood.

# 1542

Our Messengers came to Abraham with glad tidings. They said: 'Peace' He replied 'Peace' and in a while brought them a roasted calf.

# 1543

But when he saw that their hands did not reach towards it, he was wary and became fearful of them, but they said: 'Do not be afraid. We are sent to thenation of Lot'

# 1544

His wife (Sarah), who was standing nearby, laughed. Thereupon, We gave her the good news of Isaac, and after Isaac of Jacob.

# 1545

She replied: 'Alas for me! Shall I bear (a child) when I am old woman and my husband is advanced in years? This is indeed a strange thing'

# 1546

They said: 'What, do you marvel at the command of Allah? The Mercy of Allah and His Blessings be upon you, O people of the House. Indeed, He isPraised, Exalted'

# 1547

And when the wonderment departed from Abraham and the glad tidings reached him, he pleaded with Us for the nation of Lot;

# 1548

indeed, Abraham was forbearing, tenderhearted and penitent.

# 1549

(It was said:) 'Abraham, turn away from this; your Lord's command has indeed come, and there is coming upon them a punishment that will not be turned back'

# 1550

And when Our messengers came to Lot, he was troubled and distressed for them, and said: 'This is a harsh day'

# 1551

His nation came running towards him; whilst they were doing evil deeds. 'My nation' he said: 'here are my daughters (take them in marriage), they are cleaner for you. Fear Allah and do not humiliate me by my guests. Is there not one man amongst you of right mind'

# 1552

They replied: 'You know we have no right for your daughters. You know very well what we desire'

# 1553

He said: 'Would that I were powerful over you, or might take refuge in a strong pillar'

# 1554

They (the angels) said: 'Lot, we are the Messengers of your Lord, they shall not touch you. Depart with your family in the watch of the night and let none of you turn round, except your wife. She shall be struck by that which strikes them. Their appointed time is the morning. Is it not that the morning is near'

# 1555

And when Our command came, We turned it upside down, and rained on it, stone after stone of baked clay,

# 1556

marked with your Lord, and never far from the evildoers.

# 1557

And to Midian, (We sent) their brother Shu'aib. He said: 'My nation, worship Allah; you have no god except He. Do not reduce the measure nor the scale. I see you are prosperous, and fear the punishment of an encompassing day for you.

# 1558

'My nation, be just in filling the measure and the scale. Do not reduce people's goods and do not corrupt the land with mischief.

# 1559

What remains with Allah is better for you, if you are believers. I am not your guardian'

# 1560

'Shu'aib' they replied, 'does your prayer command you that we should abandon that which our fathers worshipped or do as we please with our goods? You are clement and rightminded'

# 1561

He said: 'Think, my nation! If I have a clear sign from my Lord and He has provided me with good provision, I do not desire to go behind you, taking for myself that which I forbid you. I seek but to reform as much as I can, my help comes only from Allah. In Him I have put my trust and to Him I turn in penitence.

# 1562

And my nation, do not let your breaking with me bring upon you something similar to that which struck the nation of Noah, Hood, and Salih and it is not long since the people of Lot (were punished).

# 1563

Ask the forgiveness of your Lord and turn to Him in repentance. Indeed, my Lord is the Most Merciful, Loving'

# 1564

They said 'Shu'aib, we do not understand much of what you say to us. Indeed, we see you weak among us. If it was not for your tribe we would have stoned you because you are not strong against us'

# 1565

He said: 'My nation, is my tribe stronger against you than Allah? You have taken Him to be thrown behind you, my Lord encompasses all that you do.

# 1566

My nation, do according to your position; as I am doing; and certainly you will know to whom the degrading punishment will come and who is a liar. Be watchful; I shall be watching with you'

# 1567

And when Our command came We saved Shu'aib through Our Mercy, together with those who believed. (Then) the evildoers were seized by a Shout, and when morning came they were crouched in their dwellings, dead,

# 1568

as if they had never have lived there. Begone, the nation of Midian, just as Thamood are gone.

# 1569

We sent Moses with Our signs and with clear authority

# 1570

to Pharaoh and his Council. But they followed the command of Pharaoh, and Pharaoh's command was not rightminded.

# 1571

He shall go before his nation on the Day of Resurrection and lead them into the Fire. Evil is the wateringplace to be led down to!

# 1572

A curse was sent to follow them in this world and then upon them on the Day of Resurrection. Evil is the offering to be offered.

# 1573

That, which We have related to you, is the news of the villages; some of them still stand, whereas others are stubble.

# 1574

We did not wrong them, rather, they wronged themselves. Their gods that they called upon, other than Allah, did not help them when your Lord's command came they did not increased them except in their destruction.

# 1575

Such is the seizing of your Lord, when He seizes the evildoing villages. His seizing is painful, stern.

# 1576

Indeed, for he who fears the punishment of the Everlasting Life that is a sign. That is a Day on which everyone shall be assembled. That shall be a witnessed Day.

# 1577

We shall not postpone it except until a counted term.

# 1578

When that Day arrives no soul shall speak except by His permission. Some shall be wretched, and others happy.

# 1579

The wretched shall be (cast) in the Fire where they will moan and sigh,

# 1580

and there they shall live for ever, as long as the heavens and the earth endure, and as your Lord wills. Indeed, your Lord accomplishes whatsoever He will.

# 1581

As for the happy, they shall live in Paradise for ever, so as long as the heavens and the earth endure, and as your Lord wills an unbroken gift.

# 1582

Therefore do no be doubtful as to what these worship. They worship only that which their fathers worshiped before them. We shall indeed pay them in full their undiminished measure.

# 1583

We gave Moses the Book, but they differed regarding it, but for a word that preceded from your Lord, it had been decided between them; and they are indisquieting doubt of it.

# 1584

Indeed, your Lord will pay each one of them in full for their deeds. He is aware of the things they do.

# 1585

So you and whosoever repents with you go straight as you have been commanded and do not be insolent, indeed, He sees what you do.

# 1586

And do not incline to the wrongdoers lest you are touched by the Fire, for then you shall not be helped. You have no guardians other than Allah.

# 1587

And establish your prayer at the two edges of the day and in part of the night. Good deeds will repel evil deeds. That is a remembrance for those whoremember.

# 1588

Therefore have patience; Allah will not let the wage of the gooddoers go to waste.

# 1589

If (only) there had been except for a few among them whom We saved among the generations that have gone before you, some that remained forbidding corruption in the land, but the wrongdoers pursued the ease they had been given to delight in and became sinners.

# 1590

Your Lord would never destroy the villages unjustly, whilst their people were reforming.

# 1591

Had your Lord willed, He would have made mankind a single nation. But they continue in their differences

# 1592

except those on whom your Lord shows mercy. For this end He has created them. The Word of your Lord shall be perfectly completed: 'I shall fillGehenna (Hell) with jinn and people, all together'

# 1593

And all We relate to you of the tidings of the Messengers is that whereby We strengthen your heart and through these the truth has come to you, and anadmonition and a reminder to the believers.

# 1594

Say to those who disbelieve: 'Do according to your station; we are doing according to our station'

# 1595

Wait; we too are waiting'

# 1596

To Allah belongs the unseen in the heavens and in the earth; to Him the matter, in its entirety, shall be returned. Worship Him, and put your trust in Him. Your Lord is not inattentive of the things you do.

# 1597

AlifLaamRa. Those are the verses of the Clear Book.

# 1598

We have sent it down, an Arabic Koran, in order that you understand.

# 1599

In the sending down of this Koran, We will narrate to you (Prophet Muhammad) the best of narratives, of which you were previously unaware.

# 1600

When Joseph said to his father: 'Father, I saw eleven planets, and the sun and the moon; I saw them prostrating themselves before me'

# 1601

He said: 'O my son, say nothing of this vision to your brothers lest they should cunningly plot against you indeed, satan is the clear enemy of the human,

# 1602

so your Lord will choose you and teach you the interpretation of visions, and perfect His Favor upon you and upon the House of Jacob, as He perfected it on your fathers Abraham and Isaac before you. Your Lord is Knowing, Wise.

# 1603

Indeed, in Joseph and his brothers there were signs for those who inquire.

# 1604

They said: 'Joseph and his brother are dearer to our father than ourselves, even though we are many. Truly, our father is obviously wrong.

# 1605

(Let us) kill Joseph, or cast him away in some (far off) land, so that your father's face will be left for you, and afterwards you will be a righteous nation'

# 1606

One of them said: 'No, do not kill Joseph, if you do anything, cast him into a dark pit, a traveler will pick him up'

# 1607

They said: 'Father, what is the matter with you, do you not trust us with Joseph? Indeed, we are sincere advisors.

# 1608

Send him with us tomorrow to frolic and play. We will look after him'

# 1609

He said: 'It grieves me to let him go with you, for I fear lest the wolf should devour him when you are not paying attention to him'

# 1610

They said: 'We are many, if a wolf devours him, then we are losers'

# 1611

When they went with him, they agreed to put him in the bottom of a well. We revealed to him: 'You shall tell them of what they did when they are not aware (it is you)'

# 1612

At nightfall, they returned weeping to their father.

# 1613

They said: 'We went racing and left Joseph with our things. The wolf devoured him, but you will not believe us, though we speak the truth'

# 1614

And they brought his shirt (stained) with blood, a lie. He said: 'No, your souls have tempted you to do something. But come sweet patience! The help ofAllah is always there to seek against that which you describe'

# 1615

Thereafter travelers came, and sent their waterman. And when he had let down his pail, (he cried:) 'Rejoice, a boy' Then they concealed him among their merchandise, but Allah knew what they did.

# 1616

Then, they sold him for a trifling price, a number of dirhams, because they considered him to be of little value.

# 1617

The Egyptian that bought him said to his wife: 'Make his stay honorable. He may benefit us, or take him for our son' As such We established Joseph in the land, so that We might teach him the interpretation of visions. Allah prevails in His affairs, though most people do not know.

# 1618

And when he reached maturity, We bestowed on him judgment and knowledge. As such We recompense those who do good.

# 1619

And she, in whose house he was, sought to seduce him and closed the doors saying: 'Come' 'In Allah is my refuge' he replied. 'My Lord has made my dwelling a good one. Harmdoers never prosper'

# 1620

She desired him, had he not been shown the proof of his Lord he would have taken her. But We turned him away from evil and abomination, for he was one of Our sincere worshipers.

# 1621

They raced to the door and she tore his shirt from behind. And by the door, they met her husband whereupon she said: 'What is the recompense of one whose intent is evil against your people other than being imprisoned, or sternly punished'

# 1622

He (Joseph) said: 'It was she who sought to seduce me' and a witness (an infant) of her people bore witness, saying: 'If his shirt is torn from the front, she is speaking the truth and he is one of the liars,

# 1623

but, if his shirt is torn from behind, she lied, and he is of the truthful'

# 1624

And when he saw his shirt torn at the back, he said: 'This is one of your (women's) guiles. Your guile, (O woman), is great indeed!

# 1625

Joseph, turn away from this. And you, ask forgiveness for your sin. You are indeed one of the sinners'

# 1626

Certain women in the city said: 'The Governor's wife has sought to seduce her servant. He has made her heart stricken with love for him. Clearly, we perceive her to be in error'

# 1627

When she heard of their sly whispers, she sent for them and prepared a banquet. To each she gave a knife, (then called Joseph saying:) 'Come and attend to them' When they saw him, they were so taken with him that they cut their hands, and said: 'Allah save us! This is no mortal, he is no other but a noble angel'

# 1628

Whereupon she said: 'Now you see, this is he on whose account you blamed me. Yes, I sought to seduce him, but he was unyielding. If he declines to do what I command, he shall be imprisoned and be one of the humiliated'

# 1629

He supplicated: 'Lord, prison is dearer to me than that to which they invite me. Yet if You do not shield me from their guile I shall yield to them and be one of the ignorant'

# 1630

His Lord answered him and He turned their guile away from him. Indeed, He is the Hearer, the Knower.

# 1631

Then it seemed good to them, even after they had seen the signs, that they should imprison him for some time.

# 1632

Two young men went to prison with him. One of them said: 'I saw (in a vision) that I was pressing grapes' And the other said: 'I saw (in a vision) that I was carrying bread upon my head, and that birds ate of it. Tell us its interpretation, for we can see you are among the good'

# 1633

He said: 'Before any food comes to feed either of you, I will give you its interpretation. That which I will tell you has been taught to me by Allah. I reject the belief of a nation who do not believe in Allah and disbelieve in the Everlasting Life.

# 1634

I follow the creed of my fathers, Abraham, Isaac, and Jacob. It is not for us to associate anything with Allah. Such is the favor of Allah to us, and to mankind. Yet most people do not give thanks.

# 1635

My fellowprisoners, say which is better, many gods at variance, or Allah the One, the Conqueror?

# 1636

That which you worship, other than Him, are nothing but names which you and your fathers have named and for which Allah has sent down no authority. Judgement rests with Allah alone. He has commanded you to worship none except Him. That is the right religion, yet most people do not know.

# 1637

My fellowprisoners, one of you will pour wine for his lord whereas the other will be crucified, and birds will peck at his head. The matter you inquired about has been decided.

# 1638

And he said to the one of the two who he knew would be saved: 'Mention me in the presence of your lord' But satan made him forget to mention him to his master, so that he remained in prison for a certain number years.

# 1639

The king said: 'I saw in a vision seven fatted cows being devoured by seven lean ones; and seven green ears of corn and seven others withered. My counselors, tell me the meaning of my vision, if you can interpret visions'

# 1640

They said: 'They are confused nightmares, nor do we know anything of the interpretation of visions'

# 1641

After all that time, the one of the two who had been saved remembered, he said: 'I will interpret it for you, so let me go'

# 1642

(He said:) 'Joseph, the truthful, tell us of the seven fatted cows that were devoured by seven lean ones also of the seven green ears of corn and the other seven which were withered, so that I can go back to the people and then they will then know'

# 1643

He replied: 'You shall sow for seven years as is your way. Leave in the ear (of corn) you reap, except a little which you eat.

# 1644

Thereafter, seven hard years will come upon you, which will consume all but little of that which you have stored.

# 1645

Then, there will come a year in which people are helped, in which the people will press'

# 1646

The king said: 'Bring him before me' But when the king's envoy came to him, he said: 'Go back to your lord and ask him: "What about the women who cut their hands. Indeed, my Lord knows their guile'

# 1647

'What was your business, women' he asked, 'when you solicited Joseph' 'Allah save us' they replied. 'We know no evil against him' The Governor's wife said: 'The truth has been discovered at last; I solicited him; he is among the truthful.

# 1648

This (I have done) so that he will know I did not secretly betray him, and that Allah does not guide the guile of the treacherous.

# 1649

Yet I do not consider my soul was innocent, surely the soul incites to evil except to whom my Lord has mercy; indeed, my Lord is Forgiving, the MostMerciful'

# 1650

The king said: 'Bring him before me. I will assign him to myself' And when he had spoken with him he said: 'Today, you are firmly established in both our favor and trust'

# 1651

He (Joseph) said: 'Give me charge of the storehouses of the land, I am a knowledgeable guardian'

# 1652

And as such We established Joseph in the land to live wherever he liked. We bestow Our Mercy on whom We will, and We never waste the wage of therighteous.

# 1653

Indeed, the reward of the Everlasting Life is better for those who believe and are cautious.

# 1654

Joseph's brothers came and presented themselves before him. He recognized them, but they did not know him.

# 1655

And when he had given them their provisions, he said: 'Bring me a certain brother from your father. Do you not see that I give just measure and am the bestof hosts?

# 1656

If you do not bring him to me, you shall receive no measure (of corn) from me, nor shall you come near me (again)'

# 1657

They replied: 'We will ask our father for him. This we will surely do'

# 1658

Then he said to his attendants: 'Put their merchandise in their saddlebags, hopefully they will recognize it when they return to their people. Perhaps they will come back'

# 1659

When they returned to their father, they said: 'Father, we have been denied the measure. Send our brother with us and we shall receive our measure. We will indeed look after him'

# 1660

He replied: 'Am I to trust you with him as I once trusted you with his brother? Why, Allah is the Best of guardians, and He is the Most Merciful of theMerciful'

# 1661

When they opened their saddlebags, they found that their merchandise had been given back to them. 'Father' they said 'what more do we desire? Look, our merchandise has been returned to us. We will receive provisions for our family and we will look after our brother. We shall receive an extra camelload, that is an easy measure'

# 1662

He replied: 'I will never send him with you until you swear by Allah that you will bring him back to me, unless you are prevented' And when they had given him their oath, he said: 'Allah is the Guardian of what we say'

# 1663

Then he said: 'My sons, do not enter from one gate. Enter through different gates. I cannot be of any help to you against Allah; judgement belongs to Allah alone. In Him I have put my trust. In Him let all put their trust'

# 1664

And when they entered from where their father had instructed them, nothing helped them against (the decree of) Allah. It was but a need in Jacob's soul which he had fulfilled. He possessed knowledge because of what We had taught him, though most people do not know.

# 1665

When they presented themselves before Joseph, he took his brother in his arms, and said: 'I am your brother. Do not grieve at what they did'

# 1666

And when he had given them their provisions, he hid a drinkingcup in his brother's saddlebag. Then a herald called out after them: 'Cameleers, you are thieves!'

# 1667

They turned back and asked: 'What have you lost'

# 1668

'We are missing the goblet of the king' he replied. 'Whosoever restores it shall have a camelload, that I guarantee'

# 1669

'By Allah' they said, 'you know we did not come to do evil in this land. We are not thieves'

# 1670

They said: 'What shall be the recompense, if you prove to be lying'

# 1671

They replied: 'Its recompense in whosoever's saddle bag it is found, he shall be its recompense. As such we punish the harmdoers'

# 1672

He searched their bags before his brother's and then took out the goblet from his brother's bag. As such We directed Joseph. By the king's law he had no right to seize his brother unless Allah willed otherwise. We raise whom We will in rank; over every knowledgeable person is One who knows.

# 1673

They said: 'If he is a thief know then that a brother of his has committed theft before him' But Joseph kept it secret and did not reveal it to them. He said:'You are in a worse position. And Allah knows well what you describe'

# 1674

They said: 'Mighty prince, his father is old, advanced in years, take one of us instead of him. We can see you are amongst the gooddoers'

# 1675

He replied: 'Allah forbid that we should seize any but he with whom our property was found, for then we should be harmdoers'

# 1676

When they despaired of him, they went in private to confer together. The eldest said: 'Do you not know that your father took a pledge from you in the Name of Allah, and that you failed before regarding Joseph? I shall never stir from this land until my father gives me leave or Allah makes known to me His judgement: He is the Best of judges.

# 1677

Return, all of you to your father and say to him: 'Father, your son has committed a theft. We testify only to what we know. How could we guard against the unforeseen?

# 1678

Ask the village where we were and the caravan in which we traveled, we speak the truth'

# 1679

'No' he (Jacob) said, 'your souls have tempted you to do something. But come sweet patience. Allah may bring them all to me. He alone is the Knowing, the Wise'

# 1680

And he turned away and said: 'Alas for Joseph' His eyes turned white with the grief he repressed within him.

# 1681

They said: 'By Allah, will you not cease to mention Joseph until you are consumed, or are among the perishing'

# 1682

He replied: 'I complain to Allah of my anguish and sadness. I know from Allah what you do not know.

# 1683

Go and seek news of Joseph and his brother. Do not despair of the Comfort of Allah, none but unbelievers despair of the Comfort of Allah'

# 1684

And when they presented themselves before him they said: 'O mighty prince, we and our people are afflicted with distress. We have brought but little merchandise. Fill up the measure, and be charitable to us; Allah rewards the charitable'

# 1685

'Do you know' he replied, 'what you did to Joseph and his brother in your ignorance'

# 1686

They said: 'Are you Joseph' 'I am Joseph' he answered, 'and this is my brother. Allah has been gracious to us. Those who keep from evil and are patient, indeed, Allah does not let the wage of the good doers go to waste'

# 1687

'By Allah' they said, 'Allah has preferred you above us all. We have indeed been sinful'

# 1688

He replied: 'Let no reproach be on you this day. Allah will forgive you He is the Most Merciful of the merciful.

# 1689

Go, take this shirt of mine and cast it over my father's face, he will recover his sight. Then return to me with all your family'

# 1690

As the caravan departed, their father said: 'I smell the scent of Joseph, unless you think I am foolish'

# 1691

'By Allah' they said, 'this is but your old illusion'

# 1692

And when the bearer of glad tidings arrived, he laid Joseph's shirt over him, and he saw once again. He said: 'Did I not tell you that I know from Allah what you do not know'

# 1693

His sons said: 'Father, ask forgiveness for our sins. We have indeed been sinners'

# 1694

He said: 'I shall ask my Lord to forgive you. He is Forgiving, the Most Merciful'

# 1695

And when they entered before Joseph, he took his father and mother into his arms and said: 'Welcome to Egypt, safe, if Allah wills'

# 1696

He lifted his parents to the throne, and (the others) bowed before him. Joseph said to his father: 'This is the meaning of my vision of long ago, my Lord has verified it. He has been gracious to me. He brought me out of prison and brought you out of the desert after satan had corrupted (the relationship) between me and my brothers. My Lord is Gentle to whom He will. He alone is the Knower, the Wise.

# 1697

Lord, You have given me the kingdom and taught me to interpret visions. Originator of the heavens and the earth, my Guardian in this world and in the Everlasting Life. Let me die in submission (as a Muslim) and let me join the righteous'

# 1698

That is of the news We reveal to you of the unseen. You were not present when they agreed upon their plan, scheming.

# 1699

Even though you are so eager, most people will not believe.

# 1700

You shall ask no wage for it. It is nothing except a reminder to all mankind.

# 1701

How many signs in the heavens and earth do they pass by and turn away from.

# 1702

And most of them do not believe in Allah, but they associate others with Him.

# 1703

Do they feel secure that the punishment of Allah will envelop them, or that the Hour will overtake them suddenly when they are unaware?

# 1704

Say: 'This is my Path. I call to Allah with sure knowledge, I and my followers. Exaltations be to Allah! I am not among the idolaters'

# 1705

We did not send any before you from the inhabitants of the village, but men to whom a revelation was sent. Have they not traveled in the land and seen what was the end of those before them? Better is the dwelling in the Everlasting Life for those who keep from evil. Do you not understand?

# 1706

And when at length Our Messengers despaired and reckoned that they would be belied, Our help came down to them, saving whom We pleased. OurMight cannot be withheld from the guilty nation.

# 1707

Indeed, in their stories is a lesson for those of understanding. This is no forged tale, rather, it is a confirmation of the previous, a distinguishing of all things, a guidance and a mercy to a nation who believe.

# 1708

AlifLaamMeemRa. Those are the verses of the Book. That which is sent down to you (Prophet Muhammad) from your Lord is the truth, yet most people do not believe.

# 1709

It is Allah who raised the heavens without pillars that you see. Then He willed to the Throne and subjected the sun and the moon, each pursuing an appointed course. He directs the affair. He makes plain His verses so that you will firmly believe in meeting your Lord.

# 1710

It is He who stretched out the earth and placed upon it firm mountains and rivers. And of all fruits, He has put in it two pairs and drew the veil of night over the day. Surely, in these there are signs for a nation who think.

# 1711

And in the land, there are adjoining plots, gardens of vines, sown fields and palmtrees in pairs and single that are watered with one water, yet We make some excel others in produce. Surely, in that are signs for a nation who understand.

# 1712

If you would wonder, then wondrous is their saying: 'When we are dust, shall we be raised to life again, a new creation' Such are those who disbelieve in their Lord. Their necks shall be fettered. They shall be the inhabitants of the Fire, in it they shall live for ever.

# 1713

They bid you to hasten the evil before the good, yet examples have passed away before them. Your Lord is Forgiving to people despite their evildoing; yet your Lord is Stern in retribution.

# 1714

The unbelievers say: 'Why has no sign been sent down to him from his Lord' You are only a warner, and there is a guide for every nation.

# 1715

Allah knows what every female bears, and what shrinks and swells the womb. And everything with Him has its measure.

# 1716

(He is) the Knower of the unseen and the seen, the Great, the Exalted.

# 1717

Similar to yourself is he who conceals his saying, and he who proclaims it, he who hides himself in the night, and he who goes forth by day,

# 1718

he has attendant angels before him and behind him, who, by the Command of Allah watch over him. Allah does not change what is in a nation unless they change what is in themselves. Whenever Allah wants evil for a nation, none can ward it off. Other than Him, they have no guardian.

# 1719

It is He who shows you the lightning, for fear and hope, and Who produces laden clouds.

# 1720

The thunder exalts His praise, and so are the angels are in awe of Him. He looses the thunderbolts and smites whosoever He will. Yet they dispute aboutAllah who is Mighty in power.

# 1721

To Him is the Call of truth. Those to whom they call, other than Him, give them no answer. They are like he who stretches out his hands to the water andbids it rise to his mouth, it does not reach it! The prayers of the unbelievers goes astray.

# 1722

All who dwell in the heavens and earth shall prostrate themselves before Allah, either willingly or unwillingly; as do their shadows in the mornings andevenings.

# 1723

Say: 'Who is the Lord of the heavens and the earth' Say: 'Allah' Say: 'Why then have you chosen guardians other than Him, even though they have neither the power to benefit nor harm themselves' Say: 'Are the blind and the seeing equal? Are darkness and light equal? Or, have they ascribed to Allah associates who create as He creates so that all creation is alike to them?" Say: 'Allah is the Creator of everything. He is the One, the Conqueror'

# 1724

He sends down water from the sky and the valleys (wadis) flow each in their measure, and the torrent carries a swelling scum; and fire from that which they kindle; desiring ornament or ware, from that rises a scum like it. As such, Allah strikes both the truth and the false. As for the scum it is cast away as jetsam, but, that which profits people remains on the earth. As such Allah strikes the parables.

# 1725

For those who answer their Lord is a most fine reward. But for those who do not answer Him if they possessed all that the earth contains, and as much besides, they would offer it for their ransom. Theirs shall be an evil reckoning. Gehenna (Hell) shall be their refuge, an evil cradling!

# 1726

Then is he who knows what is sent down to you from your Lord is the truth like he who is blind? Indeed, only those possessed with minds remember

# 1727

who fulfill their promise to Allah and do not break their pledge;

# 1728

who join together what Allah has bidden to be united; who fear their Lord and dread the evil reckoning.

# 1729

Patient men, desiring the Face of their Lord, establish their prayers, and spend of what We have given them in private and in public; and who wardoff evil with good. Theirs shall be the Ultimate Abode.

# 1730

They shall enter the Gardens of Eden together with the righteous among their fathers, their wives, and their descendants. From every gate the angels will come to them,

# 1731

'Peace be to you, for that you were patient' Best is the Ultimate Abode.

# 1732

As for those who break the covenant of Allah after accepting it, who part what He has commanded to be united and worked corruption in the land, a curse shall be laid on them, and they shall have an evil abode.

# 1733

Allah gives abundantly and sparingly to whom He will. They rejoice in this present life; but this present life, beside the Everlasting Life, is nothing but a passing enjoyment.

# 1734

And those who disbelieve say: 'Why has no sign been sent down to him by his Lord' Say: 'Allah leads astray whom He will, and guides those who repent,

# 1735

those who believe, and whose hearts find comfort in the remembrance of Allah. Is it not with the remembrance of Allah that hearts are satisfied.

# 1736

For those who believe and do good works is blessedness and blessed resort'

# 1737

As such, We have sent you forth to a nation before whom others have passed away in order that you recite to them what We have revealed to you. Yet they disbelieve the Merciful. Say: 'He is my Lord. There is no god except He. In Him I have put my trust, and to Him I turn'

# 1738

If only a Koran whereby the mountains were set in motion, or the earth cleaved asunder, or the dead spoken to. No, but to Allah is the affair altogether. Do those who believe know that had Allah willed He could have guided all people? As for those who disbelieve, because of what they do, disaster will not cease to afflict them, or it alights near their home until the promise of Allah comes. Allah will not break His promise.

# 1739

Other Messengers were mocked before you but I respited the unbelievers, then I seized them. And how was My retribution!

# 1740

What, He who stands over every soul for what it has earned, yet they made partners for Allah. Say: 'Name them. Or would you tell Him of that which is unknown in the earth to Him? Or in outward speech only' Indeed, their devising seems fair to the unbelievers, for they are barred from the Right Way. None can guide those whom Allah leads astray.

# 1741

They shall be punished in this life but the punishment of the Everlasting Life is more grievous. None shall defend them from Allah.

# 1742

The likeness of Paradise which the righteous have been promised beneath it rivers flow, its produce and shade are eternal. Such is the payment of the righteous. But the payment of the unbelievers is the Fire.

# 1743

Those to whom We have given the Book rejoice in what is sent down to you, while some factions reject a part of it. Say: 'I am commanded to worship Allah and to associate none with Him. To Him I supplicate, and to Him I turn'

# 1744

And as such We have sent it down an Arabic judgment. And if you follow their desires, after the knowledge that has come to you, you shall have no guardian other than Allah, nor yet a defender.

# 1745

We have sent forth other Messengers before you and given them wives and descendants. Yet none of them could bring a sign except by the permission of Allah. Every term has its Book.

# 1746

Allah blots out, and He establishes what He will. With Him is the Essence of the Book.

# 1747

Whether We show you part of that We promise them, or We call you to Us, it is only for you to deliver the Message, and Ours is the accounting.

# 1748

Do they not see how We come to the land and reduce its extremities? Allah judges; none repel His judgement. Swift is His reckoning.

# 1749

Those who have gone before them devised, but to Allah is the devising altogether. He knows what every soul earns. The unbelievers shall know without doubt for whom is the Ultimate Abode.

# 1750

Those who disbelieve say: 'You are not a Messenger' Say: 'Allah is a Sufficient witness between me and you, and whosoever possess knowledge of the Book'

# 1751

AlifLaamRa. We have sent down to you (this Book) in order that you bring mankind from darkness to the light by the permission of your Lord, to the Path of the Almighty, the Praised.

# 1752

Allah to whom belongs all that is in the heavens and the earth. Woe to the unbelievers for a terrible punishment.

# 1753

Those who prefer this life more than the Everlasting Life, and bar others from the way of Allah and seek to make it crooked they are in far error.

# 1754

We have sent no Messenger except in the tongue of his own nation, so that he might make everything plain to them. But Allah leads astray whom He will and guides whom He will. He is the Almighty, the Wise.

# 1755

We sent Moses with Our signs, 'Bring your nation out of darkness into the light, and remind them of the Days of Allah' Surely, in that are signs for every patient, thankful (person).

# 1756

Moses said to his nation: 'Remember the blessing of Allah to you when He saved you from Pharaoh's family, who had oppressed you cruelly, and who slew your sons and spared your women. Surely, that was a great trial from your Lord.

# 1757

And when your Lord proclaimed: "If you give thanks, I will increase you, but, if you are unthankful My punishment is indeed stern.'

# 1758

And Moses said: 'If you and all mankind are thankless, He is surely Rich, Praised'

# 1759

Have you not heard what befell the nations that have gone before you? The nations of Noah, Aad, and Thamood, and those who came after? None knows them but Allah. Their Messengers came to them with clear signs, but they thrust their hands into their mouths and said: 'Without doubt we disbelieve the Message you have been sent with. That which you call us to is disquieting'

# 1760

Their Messengers said: 'Is there any doubt about Allah, the Originator of the heavens and the earth? He calls you to Him in order that He forgives you your sins and defers you till a stated term' They said: 'You are only mortals like us. You wish to bar us from that which our fathers worshipped. Give us some clear proof.'

# 1761

Their Messengers said to them: 'We are nothing except humans like you. But Allah bestows His Mercy on those of His worshipers whom He chooses. We cannot give you proof, except with the permission of Allah. In Allah, let believers put their trust.

# 1762

And why should we not put our trust in Allah, when He has already guided us to our Paths? We will endure your hurt patiently. In Allah, let all who trust place their trust'

# 1763

Those who disbelieved said to their Messengers: 'Return to our faith or we will banish you from our land' But Allah revealed to them: 'We shall destroy the harmdoers

# 1764

and let you live in the land after them. This is for him who fears My station and fears My threat'

# 1765

They sought a judgment, then every tyrant was disappointed.

# 1766

Gehenna (Hell) is before him and he is given oozing pus to drink,

# 1767

which he gulps and can scarcely swallow. Death will come to him from every side, yet he cannot not die, and yet to come is a dreadful punishment.

# 1768

As for the likeness of those who disbelieve in their Lord, their works are like ashes which a strong wind scatters on a stormy day; they are powerless over that they have earned; that is the far error.

# 1769

Do you not see that Allah has created the heavens and the earth with truth? He can put you away if He will and bring into being a new creation;

# 1770

indeed, that is no great thing for Allah.

# 1771

Together they shall all come before Allah. Then the weak will say to those who were proud: 'We were your followers. Can you help us in anything against the punishment of Allah' They will say: 'Had Allah guided us we would have guided you. It is now the same for us whether we cannot endure or bear patiently, we have no place of refuge'

# 1772

And when the issue has been decided, satan will say (to them): 'The promise which Allah made you was true. I promised you, but failed to keep it. I had no authority over you except that I called you, and you answered me. Do not bame me, rather, blame yourselves. I cannot help you, nor can you help me. I disbelieved in your associating me (with Allah) before' Indeed, for the evildoers there is a painful punishment.

# 1773

As for those who believe and do good works, they shall be admitted to gardens underneath which rivers flow in which, by the permission of their Lord, they shall live for ever. Their greeting shall be: 'Peace'

# 1774

Have you not seen how Allah sets forth a parable that a good deed is like a good tree, its roots are firm and its branches are in the heaven,

# 1775

yielding its fruit every season by the permission of Allah? Allah gives parables to mankind so that they might remember.

# 1776

The likeness of a corrupt word is like a corrupt tree uprooted from the earth having no stability.

# 1777

Allah will strengthen the believers with a steadfast Word, both in this life and in the Everlasting Life. Allah leads the evildoers astray. Allah does what He will.

# 1778

Have you not seen those who exchanged the favor of Allah with disbelief and landed their nation in a house of ruin?

# 1779

They shall be roasted in Gehenna; an evil establishment!

# 1780

They set up rivals with Allah to lead others astray. Say to them: 'Take your pleasure; your arrival shall be the Fire'

# 1781

Tell My worshippers, those who believe, who establish the prayer, and spend of what We have given them in private and in public, before the coming of that Day in which there is neither bargaining, nor the taking of friends,

# 1782

it is Allah who created the heavens and the earth, and sends down water from the heaven with which He brings forth fruits for your provision. He has subjected to you ships which, by His command, run upon the sea. He has subjected to you rivers,

# 1783

and He subjected to you the sun and the moon, which are constant in their courses. And, He has subjected to you the night and the day, and gave you all that you asked of Him.

# 1784

If you count the blessings of Allah, you will never number them. Indeed, the human is wicked and thankless.

# 1785

And when Abraham said: 'My Lord, make this a land secure. Turn me and my children away from worshipping idols.

# 1786

My Lord they have led many people astray. Whosoever follows me belongs to me. Whosoever rebels against me, You are surely Forgiving, the MostMerciful.

# 1787

'Our Lord, I have settled some of my offspring in a barren valley near Your Holy House; our Lord, in order that they establish the prayer. Make the hearts of people yearn towards them, and provide them with fruits, in order that they are thankful.

# 1788

Our Lord, You have knowledge of all that we hide and all that we reveal; nothing in heaven or earth is hidden from Allah.

# 1789

Praise be to Allah who has given me Ishmael and Isaac in my old age! Indeed, my Lord is the Hearer of the supplication.

# 1790

My Lord, make me and my descendants establishers of prayer. Our Lord, accept my prayer.

# 1791

Forgive me, our Lord, and forgive my parents and all the believers on the Day of Reckoning'

# 1792

Do not think that Allah is unaware of the harmdoers work. He only gives them respite till the Day on which all eyes will stare,

# 1793

when they shall run with their necks outstretched and heads erect, their glances never return to themselves, their hearts are empty.

# 1794

Warn mankind of the Day when the punishment will overtake them, when the evildoers will say: 'Our Lord, grant us respite for awhile, we will answer Your call, and follow the Messengers' Did you not once swear that you would never cease?

# 1795

You lived in the dwellings of those who wronged themselves, and it was clear to you how We dealt with them, and how We struck parables for you.

# 1796

They plotted their plots, but their plots are (known) to Allah, even though their plots were such as to move mountains.

# 1797

Do not think that Allah will break the promise He gave to His Messengers. Mighty is Allah, and Vengeful.

# 1798

On the Day when the earth is changed into other than the earth and the heavens, all shall come before Allah, the One, the Conqueror.

# 1799

On that Day, you shall see the sinners coupled together in fetters;

# 1800

their garments shall be of melted tar, and their faces enveloped by the Fire.

# 1801

Allah will recompense each soul according to its earnings. Swift is the Reckoning of Allah.

# 1802

This is a message to be delivered to mankind so that they may be warned by it, and know that He is (Allah) One God, and so all those possessed of minds may remember.

# 1803

AlifLaamRa. Those are the verses of the Book, the Clear Koran.

# 1804

It could be that those who disbelieve will wish that they were Muslims.

# 1805

Let them eat and enjoy; and let their hopes deceive them, soon they shall know.

# 1806

We never destroyed a village whose term had not already been decreed.

# 1807

No nation can outstrip its term, nor do they put it back.

# 1808

They say: 'You to whom the Remembrance is sent down, you are indeed mad.

# 1809

Why do you not bring down the angels, if what you say is true'

# 1810

We do not send angels except with the truth. Then they shall have no respite.

# 1811

It is We who sent down the Koran, and We watch over it.

# 1812

We have sent forth before you Messengers among the factions of the ancients.

# 1813

But no Messenger came to them except he was mocked.

# 1814

So We make it enter the hearts of the sinners.

# 1815

They do not believe in it even though the practice of the ancients has already gone.

# 1816

If We opened a gate in the heaven and they kept ascending through it,

# 1817

still they would say: 'Our eyes were dazzled; truly, we must have been a bewitched people'

# 1818

We have set constellations in the heavens and made them pleasing to the beholders,

# 1819

and guarded them from every stoned satan.

# 1820

Except for he who steals the listening and is then pursued by a visible flame.

# 1821

We have spread out the earth and set upon it firm mountains. Everything We have caused to grow therein is justly weighed;

# 1822

and there appointed for you is a livelihood, and for those you do not provide.

# 1823

And there is not a thing but with Us are its treasuries, and We do not send it down except in a known measure.

# 1824

We send the winds fertilizing, and We send down out of heaven water, from which you drink and you are not its treasurers.

# 1825

And surely, it is We who give life and make to die. We are the Inheritor.

# 1826

We know those of you who press forward, and We know the laggards,

# 1827

and it is your Lord who will gather them. He is Wise, Knowing.

# 1828

We created mankind from clay, molded from mud,

# 1829

and before him We created the jinn from smokeless fire.

# 1830

When your Lord said to the angels: 'See, I am creating a mortal from clay of molded mud.

# 1831

When I have shaped him and ran My created soul in him fall down prostrating towards him'.

# 1832

All the angels prostrated themselves,

# 1833

except iblis (father of the jinn) who refused to be one of those who prostrated themselves.

# 1834

He said: 'iblis, what is the matter with you, that you do you not prostrate yourself'

# 1835

He replied: 'I will not prostrate to a mortal You have created of clay, from molded mud'

# 1836

(Allah) said: 'Begone, you are accursed!

# 1837

A curse shall be on you till the Day of Recompense'

# 1838

He said: 'My Lord, reprieve me till the Day they are raised'

# 1839

He answered: 'You are among those reprieved

# 1840

till the appointed time.

# 1841

(satan) said: 'My Lord, for Your perverting me, I shall make (matters) in the earth seem most fair to them and I shall pervert all,

# 1842

except the devoted amongst Your worshippers.

# 1843

He (Allah) said: 'This is for Me the Right Path

# 1844

over My worshipers you have no authority, except the perverse that follow you.

# 1845

Gehenna (Hell) will be the promise for all of them.

# 1846

It has seven gates, and through each gate a portion of them belong.

# 1847

But the cautious shall live amongst gardens and fountains:

# 1848

'In peace and security, enter them'

# 1849

We shall remove all rancor from their hearts, and as brethren they shall recline on couches face to face.

# 1850

There, no fatigue shall smite them, nor shall they ever be driven from it'

# 1851

Tell My worshipers that I am the Forgiving, the Most Merciful,

# 1852

and that My punishment is the painful chastisement.

# 1853

Tell them of Abraham's guests.

# 1854

They entered to him and said: 'Peace' but he replied: 'We are afraid of you'

# 1855

'Do not be afraid' they answered. 'We come to give you glad tidings of a knowledgeable child'

# 1856

He said: 'What is this, do you bring me glad tidings even though I am old' Of what do you give me glad tidings'

# 1857

They replied: 'In truth we have given you glad tidings, do not be one of those who despair'

# 1858

He replied: 'And who despairs of the mercy of his Lord, except those that are astray?

# 1859

He asked: 'Messengers, what is your errand'

# 1860

They replied: 'We are sent to sinful nation.

# 1861

Except Lot's family, of whom we shall save all,

# 1862

but his wife. We decreed that she should be amongst those who remain behind.

# 1863

And when the envoys came to the family of Lot,

# 1864

he said to them: 'I do not know you'

# 1865

'No' they replied: 'We bring you (news) of that concerning which they were doubting.

# 1866

We bring you the truth, and indeed we are truthful.

# 1867

Depart with your family in a part of the night and walk behind them and let none of you turn round. Go to a place where you are commanded'

# 1868

And We made known to him this decree that the wrongdoers were to be utterly cut off in the morning.

# 1869

The people of the city came to him rejoicing.

# 1870

He said: 'These are my guests; do not shame me.

# 1871

Fear Allah and do not disgrace me'

# 1872

They replied: 'Have we not forbidden you (the people of) the worlds'

# 1873

He said: 'Here are my daughters; take them (in marriage), if you would be doing'

# 1874

By your life, they wandered blindly in their dazzlement.

# 1875

At sunrise a dreadful Shout seized them.

# 1876

We laid it (the city) upside down and rained stones of baked clay upon them.

# 1877

Surely, in that there are signs for those who contemplate.

# 1878

Indeed, it is on a way which still exists.

# 1879

Surely, in that there is a sign for those who believe.

# 1880

The dwellers of the Thicket were harmdoers.

# 1881

On them, too, We took vengeance, and they are both on a clear roadway.

# 1882

And the dwellers of Al Hijr also belied the Messengers.

# 1883

We brought them signs, but they turned away.

# 1884

They hewed their dwellings out of the mountains in safety.

# 1885

But the Shout seized them in the morning,

# 1886

and that which they had earned did not help them.

# 1887

We did not create the heavens and the earth, and what is between them except in truth. The Hour is sure to come, therefore, forgive them with a graciouspardon.

# 1888

Your Lord is the Creator, the Knower.

# 1889

We have given you the seven dual (verses, Al Fatihah) and the Mighty Holy Reading (Koran).

# 1890

Do not stretch your eyes to that We have given pairs of them to enjoy, nor sorrow for them, and lower your wing to the believers.

# 1891

And say: 'I am the plain warner'

# 1892

So We sent it down to the partitioners,

# 1893

who have broken the Koran into parts,

# 1894

so by your Lord, We will question them all

# 1895

about what they did.

# 1896

Proclaim then, what you are commanded and turn away from the unbelievers.

# 1897

We suffice you against those who mock,

# 1898

and those who set up other gods with Allah, indeed, they will soon know.

# 1899

Indeed, We know your chest is straitened by that they say.

# 1900

Exalt with the praise of your Lord and be one of those who prostrate.

# 1901

Worship your Lord till the certainty (death) comes to you.

# 1902

The Command of Allah will surely come; do not seek to hasten it. Highly exalted is He above that they associate with Him.

# 1903

He sends down the angels with the Spirit (Gabriel) by His command to those of His worshipers whom He chooses, (saying:) 'Warn, there is no god except Me, therefore fear Me'

# 1904

He created the heavens and the earth with truth. Exalted is He above what they associate (with Him)!

# 1905

He created mankind from a sperm drop, yet he is a clear adversary.

# 1906

And the cattle He created for you. In them, you have warmth and other uses, and of them you eat.

# 1907

In them there is beauty for you when you bring them home and when you lead them to pasture.

# 1908

They carry your loads to a land which you could not otherwise reach except by painful toil to oneself. Your Lord is the Clement, the Most Merciful.

# 1909

(He has created for you) horses, mules, and donkeys, which you ride and as an adornment; and He creates what you do not know.

# 1910

It is for Allah to show the way. Some swerve from it, but had He willed, He would have guided all of you.

# 1911

It is He who sends down water from heaven, which provides drink for you and brings forth trees on which your herds feed.

# 1912

And thereby He brings forth crops and olives, palms and vines, and all the fruits. Surely, in this there is a sign for a nation who think.

# 1913

He has subjected to you the night, the day, the sun and the moon. The stars are subjected by His Command. Surely, in that there is a sign for a nation who understands.

# 1914

And what He has multiplied for you in the earth is of various hues; surely, in that there is a sign for a nation who remember.

# 1915

It is He who has subjected the sea to you, so that you eat of its soft flesh and bring up from it ornaments which you wear. And you see the ships plowingtheir course through it in order that you seek His bounty and give thanks.

# 1916

He set firm mountains upon the earth lest it should shake with you; and rivers, and roads, in order that you are guided.

# 1917

And waymarks; and by the star they are guided.

# 1918

Is He who creates as he who does not create? Will you not remember?

# 1919

If you count the favors of Allah, you could not number them. Indeed, Allah is Forgiving and the Most Merciful.

# 1920

Allah has knowledge of all that you hide and all that you reveal.

# 1921

But those whom you invoke, other than Allah do not create anything they are themselves created.

# 1922

They are dead, not living; and they do not know when they will be raised (to life).

# 1923

Your God is One God. Those who do not believe in the Everlasting Life their hearts disbelieve, and are puffed up with pride.

# 1924

Allah knows without doubt what they hide and what they make known. He does not love the proud.

# 1925

And if they are asked: 'What has your Lord revealed' they say: 'Tales of the ancients, fairytales'

# 1926

They shall carry their sins completely on the Day of Resurrection, and some of the sins of those who were led astray by them without knowledge. Evil is that which they sin.

# 1927

Those who have gone before them also plotted. Then, Allah came upon their building from the foundations, and the roof fell down on them from above them. And the punishment overtook them from where they did not know.

# 1928

He will degrade them on the Day of Resurrection. He will say: 'Where are My partners, for whose sake you opposed' And those to whom knowledge has been given will say: 'Degradation today and evil are on the unbelievers,

# 1929

whom the angels take while they were still harming themselves' Then they will offer submission, saying: 'We have done no evil' No, surely Allah knows what you have done.

# 1930

Enter the gates of Gehenna (Hell) to be in it for ever. Evil is the lodging of the proud.

# 1931

It is said to the cautious: 'What has your Lord revealed' They will reply: 'Good' For those who did good in this world is goodness; indeed the lodging in the Everlasting Life is better an excellent dwelling for the cautious.

# 1932

They shall enter the Gardens of Eden, under which rivers flow, and there they shall have all they desire. So Allah recompenses the cautious,

# 1933

whom the angels take while they are goodly, saying: 'Peace be on you. Enter Paradise for what you were doing'

# 1934

Are they looking for the angels to come down or the order of your Lord to come? As such did those who have gone before them. Allah did not wrong them, but they wronged themselves,

# 1935

so the evil things which they did coiled around them, and they were encompassed by that they mocked.

# 1936

The idolaters say: 'Had Allah willed, neither we nor our fathers would have worshipped anything other than Him, nor would we have forbidden anything without Him', as such did those before them. Yet what should Messengers do but give a clear deliverance?

# 1937

We sent a Messenger to every nation, saying: 'Worship Allah and avoid the idols' Amongst them were some whom Allah guided, and some justly disposed to error. Travel in the land and see what was the end of those who belied (the Revelation and the prophets)!

# 1938

Though you are ever so eager to guide them, Allah will not guide those who mislead (others). There shall be none to help them.

# 1939

They solemnly swear by Allah that Allah will never raise the dead to life. No, surely the promise of Allah is binding upon Him, though most people do not know.

# 1940

This is in order that He may make clear to them that which they differed upon, and in order that those who disbelieve might know that they were indeed lying.

# 1941

When We decree a thing, We only say: 'Be' and it is.

# 1942

And those who after they have been wronged emigrated for the Cause of Allah, We will lodge them with a good (life) in this world, but greater still is the wage of the Everlasting Life, if they but knew;

# 1943

such are those who are patient, and put their trust in their Lord.

# 1944

We never sent but men before you to whom We revealed, ask the people of the Remembrance, if you do not know.

# 1945

(We sent them) with clear signs and the Psalms. And We sent down to you the Remembrance so that you can make clear to people what has been sent down to them, in order that they reflect.

# 1946

Do those who do evil feel secure that Allah will not make the earth to swallow them, or that the punishment will not fall upon them from where they do not know?

# 1947

Or, that He will not seize them in their going to and fro, and they will not be able to frustrate Him?

# 1948

Or, that He will not seize them, a little at a time and destroy them? Indeed, your Lord is Clement, the Most Merciful.

# 1949

Do they not see how every thing Allah created casts its shadow right and left, prostrating itself before Allah in all humility?

# 1950

Everything in the heavens and every crawling creature on earth, and the angels prostrate to Allah and they are not proud;

# 1951

they fear their Lord from above them and do as they are commanded.

# 1952

Allah says: 'Do not take to yourself two gods. He is only One God; so have awe of Me'

# 1953

To Him belongs all that is in the heavens and the earth. His is the Religion for ever. Would you then fear any but Allah?

# 1954

Whatever favor you have is from Allah. Whenever you are afflicted you groan to Him.

# 1955

When He removes your affliction then some of you set up associates to their Lord

# 1956

that they may show ingratitude for what We gave them. So, take your pleasure, you shall soon know.

# 1957

They set aside a share of that which We have provided them for what they did not know. By Allah, you shall be questioned about your forgeries!

# 1958

They ascribe daughters to Allah exaltations to Him! But they themselves would have what they desire!

# 1959

When good news of the birth of a female is given to any of them, his face grows dark and inwardly he chokes.

# 1960

Because of the evil of the good news he hides himself from people, (pondering) whether he will keep her and be humiliated, or trample her into the dust. Evil is their judgement!

# 1961

Those who do not believe in the Everlasting Life, theirs is the evil likeness; and for Allah is the highest likeness. He is the Mighty, the Wise.

# 1962

If Allah punished people for their sins, He would not leave one creature that crawls on the earth. He reprieves them to an appointed term; when their term is come, they shall neither delay it by a single hour nor can they hasten it.

# 1963

They ascribe to Allah what they themselves dislike. Their tongues utter falsehoods (when they say) the finest of wages shall be theirs. Without doubt, the Fire shall be theirs and they will be hastened to it.

# 1964

Indeed, by Allah, We have sent Messengers before you to other nations. But satan made their deeds seem fair to them so that today he is their guardian, and a painful punishment awaits them.

# 1965

We have not revealed to you (Prophet Muhammad) the Book except that you may clarify for them that upon which they differ, and as guidance and mercy to a nation who believe.

# 1966

Allah sends down water from the sky with which He revives the earth after its death. Surely, in this there is a sign for people who listen.

# 1967

Indeed, in the cattle there is a lesson for you. We give you to drink of that which is in their bellies, between the filth (bowels) and blood, pure milk, which is sweet to those who drink.

# 1968

And the fruits of the palm and of the vine, from which you derive intoxicants and wholesome provisions. Surely, in this there is a sign for nation who understand.

# 1969

Your Lord revealed to the bee: 'Build your homes in the mountains, in the trees, and in what they are building.

# 1970

Eat every kind of fruit, and follow the easy ways of your Lord' From its belly comes forth a drink (honey) of many hues in which there is healing for people. Surely, in this there is a sign for a nation who reflect.

# 1971

Allah created you, and causes you to die. There are some of you who, after knowing something, will be kept back to the vilest state of life, knowing nothing. Allah is the Knowing, Powerful.

# 1972

In your provisions Allah has preferred some of you above others. But, those who have been preferred do not give their provisions to those whom their right hand possess so that they might be equal therein. What, do they vainly disbelieve the favor of Allah?

# 1973

Allah has given you wives from among yourselves, and has given you and your wives, sons and grandsons and He has provided you with good things. What, do they believe in vanity; do they disbelieve in the favor of Allah?

# 1974

Do they worship, other than Allah, that which has no power to provide them with anything either from the heavens or earth, and can do nothing!

# 1975

Therefore, do not strike parables for Allah; Allah knows, but you do not!

# 1976

Allah strikes a parable. A servant owned by his master, having no power over anything, and one to whom We have given from Us a fine provision who spends it secretly and openly, are they equal? Praise be to Allah! No, most of them do not know!

# 1977

And Allah strikes a parable. Two men, one is dumb and powerless, a burden to his master wherever he sends him he returns with no good. Is he equal with one who orders justice and follows the Straight Path?

# 1978

To Allah belongs the unseen of the heavens and the earth. The matter of the Final Hour shall be like the twinkling of an eye, or even less. Allah has power over all things.

# 1979

Allah brought you out of your mothers' wombs, and gave you hearing, sight and hearts, in order that you be thankful.

# 1980

Have they not seen the birds that are subjected in the air of the heaven? Nothing holds them except Allah. Surely, in this are signs for those who believe.

# 1981

And it is Allah who has given you houses in which to rest, and from the hides of cattle homes so they are light for you on the day you travel and on the day of settling; while from their wool, fur, and hair (He has given you) furnishing and enjoyment for a while.

# 1982

From the things He created, Allah has given you a covering shade, and He has made for you refuges in the mountains. He has given you garments to protect you from the heat, and garments to protect you from your own violence. As such it is that He perfects His favors upon you, in order that you submit.

# 1983

But, if they turn away, your mission is only to give plain warning.

# 1984

They recognize the favors of Allah, then they disbelieve them; most of them are unbelievers.

# 1985

On the Day We shall raise up from every nation a witness, then permission will not be given to the unbelievers, nor shall they be allowed to make restitution.

# 1986

And when the harmdoers see their punishment, it shall never be lightened, nor shall they ever be respited.

# 1987

And when the idolaters see their associates they will say: 'Our Lord, these are our associates on whom we called other than You' But they will throw back at them saying: 'Surely, you are truly liars'

# 1988

On that Day they shall offer to submit to Allah, and what they forged will forsake them.

# 1989

Those who disbelieve and bar others from the Path of Allah, We shall add punishment upon their punishment because they were corrupting.

# 1990

And on that Day We shall raise up from every nation a witness from their own against them, and We shall bring you (Prophet Muhammad) as a witness against those. And We have sent down to you the Book making everything clear, as a guidance, and mercy, and glad tidings to those who submit.

# 1991

Allah orders justice, and good deeds, and giving to one's kindred. He forbids indecency, dishonor and insolence. He admonishes you in order that you take heed.

# 1992

Fulfill the covenant of Allah, when you make a covenant and do not break your oaths after they have been confirmed (by swearing in His Name) for you make Allah your surety. Allah has knowledge of what you do.

# 1993

Do not be like the woman who breaks her thread, after it is firmly spun into fibers, by taking your oaths as mere mutual deceit, one nation being more numerous than the other. Allah tries you with it. On the Day of Resurrection, He will clarify to you everything on which you were at variance.

# 1994

Had Allah willed, He would have made you one nation. But He leads astray whomsoever He will and gives guidance to whomsoever He will. You shall be questioned about what you did.

# 1995

Do not take oaths to deceive each other, lest your foot should slip after its firmness, lest you should taste evil, for you barred others from the Path of Allah, and lest a mighty punishment awaits you.

# 1996

Do not sell the covenant of Allah for a trifling price. What is with Allah is better for you if you but knew.

# 1997

That which you have is transitory, but that which is with Allah endures. We shall reward the patient according to the best of their deeds,

# 1998

For whosoever does a righteous deed, be they believing men or women, We shall recompense them with their wage according to the best of their deeds.

# 1999

When you recite the Koran, seek refuge in Allah from the stoned satan:

# 2000

he has no authority over the believers who put their trust in their Lord.

# 2001

He has authority over those who are guided by him, and those who ascribe associates to Him (Allah).

# 2002

When We exchange a verse for another and Allah knows best what He is sending down they say: 'You are but a forger' No, most of them do not know.

# 2003

Say: 'The Holy Spirit (Gabriel) brought it down from your Lord in truth to confirm those who believe, and to give guidance and glad tidings to those who surrender'

# 2004

We know very well that they say: 'A mortal teaches him' The tongue of him at whom they hint is a nonArab; and this is a clear Arabic tongue.

# 2005

Those who disbelieve in the verses of Allah, Allah does not guide them for them is a painful punishment.

# 2006

None forge lies except those who disbelieve the verses of Allah those, they are the liars.

# 2007

Whosoever disbelieves in Allah after believing except he who is forced while his heart remains in his belief but he who opens his chest for disbelief, shall receive the Anger of Allah and for such awaits a mighty punishment.

# 2008

That is because they loved this present life above the Everlasting Life. Allah does not guide the unbelievers.

# 2009

They are those whose hearts, hearing and sight are sealed by Allah; they are the heedless.

# 2010

In the Everlasting Life, they shall assuredly be the losers.

# 2011

Then indeed your Lord? to those who emigrated, after they were persecuted, and then strove and were patient, surely, your Lord is thereafter Forgiving, the Most Merciful.

# 2012

On the Day when every soul will come pleading for itself and when every soul will be recompensed in full for what it did they shall not be wronged.

# 2013

Allah strikes a parable of the village which was safe and peaceful. Its provisions came in abundance from everywhere; but it was thankless for the favors of Allah. Therefore, for what they were doing, Allah let it taste the garment of hunger and fear.

# 2014

A Messenger from their own was sent to them, but they belied him. So while they were harmdoers they were seized by the punishment.

# 2015

Eat of the lawful and good things with which Allah has provided you and be thankful for the favors of Allah if it is He you worship.

# 2016

These things alone He has forbidden to you: what is already dead, blood, the flesh of swine, what has been offeredup to other than Allah. But to whoever is forced to eat any of these, neither desiring nor wanting to transgress, Allah is Forgiving, Merciful.

# 2017

And do not say what your tongues falsely describe 'This is lawful, and that is forbidden' in order to forge a lie about Allah. Indeed, those who forge a lie about Allah shall never prosper.

# 2018

Brief (is their) enjoyment, after which a painful punishment awaits them.

# 2019

We have forbidden the Jews what We have already related to you. We did not wrong them, but they wronged themselves.

# 2020

Surely, your Lord to those who commit evil through ignorance and afterwards repent, and mend their ways your Lord thereafter is surely Forgiving, Merciful.

# 2021

Abraham was (equal to) a nation, obedient to Allah, of pure faith and was not among the idolaters,

# 2022

ever thankful for His favors. He chose him and He guided him to a Straight Path.

# 2023

We gave goodness to him in this world, and in the Everlasting Life he shall be amongst the righteous.

# 2024

Then, We revealed to you: 'Follow the Creed of Abraham, he of pure faith, he was not among the idolaters'

# 2025

The Sabbath was ordained only for those who differed about it. On the Day of Resurrection, your Lord will decide the differences that were between them.

# 2026

Call to the Path of your Lord with wisdom and fine admonition. Dispute with them in the best manner. Your Lord is well aware of those who have gone astray from His Path and He is well aware of those who are guided.

# 2027

If you punish, let your punishment be proportionate to the punishment you received. But if you are patient, it is better for the patient.

# 2028

Be patient; yet your patience is only by the help of Allah. Do not grieve for them (the unbelievers), nor distress yourself because of their devising.

# 2029

Allah is with the cautious and those who do good.

# 2030

Exalted is He who carried His worshiper (Prophet Muhammad) to travel in the night from the Sacred Mosque to the Furthest Mosque which We have blessed around it so that We might show him some of Our signs. He is the Hearer, the Seer.

# 2031

We gave Moses the Book and made it a guide for the Children of Israel. 'Take no guardian other than Me.

# 2032

(You are) the descendants of those whom We carried (in the Ark) with Noah. He was a truly thankful worshiper'

# 2033

And We decreed for the Children of Israel in the Book: 'You shall corrupt the land twice, and you shall ascend exceedingly high'

# 2034

And when the promise of the first came, We sent against you Our worshipers, those of great might, and they went through the habitations, and the promise was accomplished.

# 2035

Then, We gave the turn back to you to prevail over them, and We helped you with wealth and children, and made you the greater host.

# 2036

(We said): 'If you do good, it shall be for your own souls; but if you do evil it is likewise' And when the second promise came (We sent them against you), to sadden your faces and to enter the Mosque as they entered it the first time, they utterly destroyed whatever they came across.

# 2037

Perhaps Allah will have mercy on you. But if you return, We will return. We have made Gehenna (Hell) a prison for the unbelievers.

# 2038

This Koran guides to the straightest way. It gives glad tidings of a great wage to the believers who do good deeds,

# 2039

and for those who do not believe in the Everlasting Life We have prepared for them a painful punishment.

# 2040

Yet the human prays for evil as he prays for good mankind is always hasty.

# 2041

We appointed the night and the day as two signs. Then, We blotted out the sign of the night and made the sign of the day to see, so that you seek the bounty of your Lord and that you know the number of years and the reckoning. And We have clearly distinguished everything.

# 2042

And to every human? We have fastened to him his bird of deeds upon his neck; and on the Day of Resurrection We shall bring forth to him a book spread open wide.

# 2043

'Read your book. Your self suffices you this Day as a reckoner against you'

# 2044

Whosoever is guided is only guided for his own self, and whosoever goes astray it is only against it. No soul shall bear another's burden. Nor do We punish until we have sent a Messenger.

# 2045

When We desire to annihilate a village, We command those who live in ease, but they commit evil therein, then the Word is realized against it and it is utterly annihilated.

# 2046

How many generations have We destroyed since Noah! Your Lord suffices as One who is Aware of and sees the sins of His worshipers.

# 2047

For whosoever desires this fleeting life We hasten for him whatever We will and to whom We want. Then, We have prepared Gehenna for him where he will be roasted, condemned and rejected.

# 2048

Whosoever, being a believer, desires the Everlasting Life and strives for it as he should those their striving will be thanked.

# 2049

We help these and those, a gift from your Lord; and your Lord's gift is not restricted.

# 2050

See how We have preferred some above others. Yet the Everlasting Life is greater in rank and greater in preferment.

# 2051

Do not set up with Allah another god, or you will sit condemned and forsaken.

# 2052

Your Lord has ordered you to worship none except Him, and to be good to your parents. If either or both of them attain old age with you, do not say: "Fieon you", nor rebuke them, but speak to them with words of respect.

# 2053

And lower to them the wing of humbleness out of mercy and say: 'My Lord, be merciful to them, as they raised me since I was little'

# 2054

Your Lord knows very well what is in your hearts. If you are good, He is forgiving to those who are penitent.

# 2055

Give to the near of kin, the needy and the destitute traveler their rights and do not squander,

# 2056

for the wasteful are the brothers of satan; and satan is ungrateful to his Lord.

# 2057

But if you turn away from them to seek the Mercy of your Lord, hoping to attain it, then speak to them with gentle words.

# 2058

And do not keep your hand chained to your neck (when spending), nor open it completely, so that you will sit blamed and destitute.

# 2059

Your Lord gives to whom He will His provisions both abundantly and sparingly. He is aware and sees His worshipers.

# 2060

Do not kill your children because you fear poverty. We will provide for you and them. Killing them is a great sin.

# 2061

Do not draw near to fornication, for it is an indecency, and its way is evil.

# 2062

Do not kill the soul whom Allah has forbidden except by right. If he is slain unjustly, We have given his heir authority. But let him not exceed the limit in slaying, for he will be helped.

# 2063

Do not draw near the wealth of the orphan except in the best manner, until he reaches maturity. And keep your promise. Surely, the promise will be questioned.

# 2064

Give full measure when you measure, and weigh with even scales. That is better, and fairer in the end.

# 2065

Do not follow what you do not know. The hearing, sight and heart about all these you shall be questioned.

# 2066

Do not walk proudly in the earth. Indeed, you will never tear open the earth, nor attain the height of mountains.

# 2067

The wickedness of all this is hateful with your Lord.

# 2068

That is of the wisdom your Lord has revealed to you. Do not set up with Allah another god, or you will be cast into Gehenna, condemned and rejected.

# 2069

What! Has your Lord favored you with sons and taken to Himself females from among the angels? Indeed, you utter a monstrous thing!

# 2070

In this Koran We have clarified so that they may remember; but it has only increased their aversion.

# 2071

Say: 'If there had been other gods with Him, as they say, they would surely have sought a way to the Lord of the Throne'

# 2072

Exaltations be to Him! High indeed be He exalted above what they say!

# 2073

The seven heavens, the earth, and whosoever in them, exalt Him. There is nothing that does not exalt with His praise, but you do not understand their exaltation. Surely, He is Clement, Forgiving.

# 2074

When you recite the Koran, We place between you and those who do not believe in the Everlasting Life an obstructing barrier.

# 2075

We lay veils upon their hearts and heaviness in their ears, lest they understand it. When you (Prophet Muhammad) mention your Lord alone in the Koran, they turn their backs in aversion.

# 2076

When they listen to you, We know very well how they listen. When they conspire, when the evildoers declare: 'You are only following a man who is bewitched'

# 2077

See what they compared you to. They have surely gone astray and cannot find a Path.

# 2078

'What' they say. 'When we are (turned to) bones and broken bits, shall we be raised again in a new creation'

# 2079

Say: 'Let you be stones or iron,

# 2080

or any other creation yet more monstrous in your minds' They will ask: 'Who will restore us' Say: 'He who originated you at first' They will shake theirheads and ask: 'When will this be' Say: 'Maybe it is near,

# 2081

on that Day, He will summon you, and you shall answer Him with praise and you shall think you have stayed but for a little'

# 2082

Tell My worshipers, that they should say words that are the finest, satan would arouse discord among them; he is the clear enemy of mankind.

# 2083

Your Lord knows you very well. He will have mercy on you if He will, or punish you if He will. We have not sent you to be their guardian.

# 2084

Your Lord knows very well all who are in the heavens and the earth. We have preferred some Prophets above others, and to David We gave the Psalms.

# 2085

Say: 'Call to those whom you assert, other than Him. They have neither the power to remove your affliction nor to transfer it'

# 2086

Those, they call upon are themselves seeking a means to come to their Lord, competing with each other to be nearer; they hope for His Mercy and fear His punishment. Indeed, the punishment of your Lord is the subject of caution.

# 2087

There is no village except that it shall be destroyed or that We will punish it with a stern punishment before the Day of Resurrection. That is inscribed in theBook.

# 2088

Nothing prevented Us from sending the signs but that the ancients belied them. To Thamood, We brought the shecamel as a visible (sign), yet they wronged her. We do not send signs except to frighten.

# 2089

When We said to you: 'Indeed, your Lord encompasses all people' We did not make the vision which We showed to you, and the tree cursed in the Koran except to be a trial for people, and We frighten them, but it only increases them in great insolence.

# 2090

When We said to the angels: 'Prostrate yourselves before Adam' they all prostrated themselves, except iblis (father of the jinn), who said: 'Shall I prostrate to him whom You have created from clay?

# 2091

What do You think' he said: 'This whom You have honored above me, if You defer me until the Day of Resurrection, I will root out all but a few of his seed (by misleading them)'

# 2092

'Begone' said He. 'Indeed, Gehenna is your recompense, and the reward of those who follow you, an ample recompense.

# 2093

Rouse with your voice whoever you are able from among them. Rally against them your cavalry and those on foot. Share their wealth and children with them, and promise them' But satan promises them nothing except delusion.

# 2094

'Over My worshipers you shall have no authority' Your Lord is their Sufficing Guardian.

# 2095

It is your Lord who drives your ships at sea so that you may seek His bounty. He is indeed the Most Merciful towards you.

# 2096

When misfortune befalls you at sea, all except He of those to whom you supplicate forsake you; yet when He delivers you safely to the land, you turn away. The human is unthankful.

# 2097

Do you feel secure that He will not cause the shore to swallow you, or let loose a squall of pebbles upon you? Then you shall find no guardian for yourself.

# 2098

Or, do you feel secure that He will not send you back into it a second time, and send against you a violent tempest and drown you because of disbelief? Then you shall find no prosecutor (to help) you against Us.

# 2099

We have honored the children of Adam and carried them on both land and sea. We have provided them with good things and greatly preferred them above much of Our creation.

# 2100

On the Day when We call all the people with their record, whosoever is given his book in his right hand shall read their book, and they shall not be wronged by as much as a single datefiber.

# 2101

But he who is blind in this life, shall be blind in the Everlasting Life and will be further astray from the Path.

# 2102

Indeed, they were near to seducing you from that We revealed to you, so that you might forge against Us another, and then they would surely have taken you as a friend;

# 2103

and if We had not fortified you, you would have been very slightly inclining towards them;

# 2104

then We would have let you taste the double of life and death; and you would have found none to help you against Us.

# 2105

They very nearly provoked you to drive you out of the land, but they would have only lingered for a little while after you.

# 2106

Such was Our way with those whom We sent before you. You shall find no change in Our way.

# 2107

Establish the prayer at the decline of the sun till the darkening of the night and the Koran recital at dawn. Surely, the Koran recital at dawn is witnessed.

# 2108

As for the night there is a voluntary deed for you to keep vigil in part it. Perhaps your Lord will raise you to a praiseworthy station.

# 2109

Say: 'Lord, grant me an entrance of sincerity and an exit of sincerity, and give me from Yours a victorious power'

# 2110

Say: 'Truth has come and falsehood has vanished. Indeed, falsehood will certainly vanish'

# 2111

We sent down of the Koran that which is a healing and a mercy to believers, but to the harmdoers it does not increase them, except in loss.

# 2112

Yet when We bestow favors upon mankind he turns his back and withdraws to one side. But when evil befalls him, he despairs.

# 2113

Say: 'Each human works in his own manner. But your Lord knows very well who is best guided on the way'

# 2114

They question you about the spirit. Say: 'The spirit is from the command of my Lord. Except for a little knowledge you have been given nothing'

# 2115

If We pleased We could take away that which We have revealed to you then you should find none to guard you against Us,

# 2116

except for Mercy from your Lord; for His favor to you is great indeed.

# 2117

Say: 'If mankind and jinn combined together to produce the like of this Koran, they would never be able to produce one like it, not even if they were to help one another'

# 2118

Indeed, We have set forth for mankind in this Koran every kind of parable, yet most people refuse all except disbelief.

# 2119

They say: 'We will not believe in you until you make a spring gush from the earth for us,

# 2120

or, until you own a garden of palms and vines and cause rivers to gush forth with abundant water in them;

# 2121

or, until you cause the sky to fall upon us in pieces, as you have claimed, or, as a surety bring Allah with the angels in front;

# 2122

or, until you possess an ornate house of gold, or ascend into the heavens; and we will not believe in your ascension until you have brought down for us a book which we can read' Say: 'Exaltations to my Lord! Am I anything except a human Messenger'

# 2123

Nothing prevented people from believing when guidance came to them but (the excuse): 'Has Allah sent a human as a Messenger'

# 2124

Say: 'Had there been angels walking at peace in the earth, We would have sent down an angel from heaven to them as a Messenger'

# 2125

Say: 'Allah is sufficient as a witness between me and you. He knows and observes His worshipers'

# 2126

Those whom Allah guides are rightly guided; but for those whom He leads astray you shall find no guardian, other than Him. On the Day of Resurrection We shall gather all of them upon their faces, blind, dumb, deaf. Gehenna shall be their refuge, whenever it dwindles, We will increase the Blaze for them.

# 2127

That will be their recompense because they disbelieved Our verses and said: 'When we are turned to bones and broken bits, shall we really be raised up once more as a new creation'

# 2128

Have they not seen that Allah, who has created the heavens and the earth, has power to create their like? There is no doubt that He has appointed for them aterm, yet the unbelievers refuse all but disbelief.

# 2129

Say: 'If you possessed the treasuries of my Lord's Mercy, you would hold them back for fear of spending and mankind is ever grudging!

# 2130

To Moses We gave nine clear signs. Ask the Children of Israel about how he came to them. When Pharaoh said to him: 'Moses, I think you are bewitched.'

# 2131

'You know' he replied, 'that none except the Lord of the heavens and the earth has sent down these as clear proofs. Pharaoh, I believe you are destroyed.'

# 2132

Pharaoh sought to provoke them so that they would leave the land, but We drowned him, together with all who were with him.

# 2133

And thereafter We said to the Children of Israel: 'Dwell in the land. When the promise of the Everlasting Life comes We shall bring you all together'

# 2134

We have sent it down with the truth, and with the truth it has come down. We have not sent you except a bearer of glad tidings and a warner,

# 2135

and We have divided the Koran for you to recite at intervals to mankind and We have sent it down successively.

# 2136

Say: 'Believe in it, or do not believe. When it is recited to those to whom knowledge was given before they fall prostrate upon their faces

# 2137

and say, "Exaltations be to our Lord! The promise of our Lord is done.'

# 2138

They fall down upon their chin, weeping and it increases them in humility.

# 2139

Say: 'Call upon Allah, or call upon the Merciful; whichever (Name) you call upon, to Him belong the Most Beautiful Names' Pray neither loudly nor to quietly, rather, seek a middle course between them.

# 2140

Say: 'Praise be to Allah who has not taken a son; who has no associate in the Kingdom; nor out of humility any guardian' And exalt Him repeatedly with exaltations.

# 2141

Praise belongs to Allah who has sent down the Book to His worshiper (Prophet Muhammad) and has not made any crookedness in it,

# 2142

unswerving. To warn of great violence from Him, and to give good tidings to the believers who do good deeds that theirs shall be a goodly wage

# 2143

and they will live for ever therein.

# 2144

And it (the Koran) warns those who say: 'Allah has taken a son'

# 2145

. Surely, of this they have no knowledge, neither they nor their fathers; it is a monstrous word that comes from their mouths, they say nothing but a lie.

# 2146

Yet perchance, if they do not believe in this tiding, you will consume yourself with grief and follow after them.

# 2147

We have appointed all that is on the earth an adornment for it, in order that We try which of them is finest in works.

# 2148

We will surely reduce all that is on it to barren dust.

# 2149

Or, do you think the companions of the Cave and the tomb stone were a wonder among Our signs?

# 2150

When the youths sought refuge in the Cave, they said: 'Lord give us from Your Mercy and furnish us with rectitude in our affair'

# 2151

For many years We sealed up their hearing in the Cave,

# 2152

and thereafter We revived them to find out which of the two parties could best calculate the length of their stay.

# 2153

In truth We tell to you their news. They were young men who believed in their Lord, and We increased them in guidance.

# 2154

We strengthened their hearts when they stood up and said: 'Our Lord is the Lord of the heavens and the earth. We will call on no other god except Him; (for if we did), we would have spoken outrageously (in disbelief),

# 2155

These, our nation have taken to themselves gods, other than Allah. Why do they not bring some clear authority regarding them! Who does greater evil than he who forges a lie against Allah'

# 2156

When you depart from them and from what they worship, other than Allah, seek refuge in the Cave. Allah will extend His Mercy to you and will furnish you with a gentle issue of your affair.

# 2157

You might have seen the rising sun incline towards the right of their Cave, and, as it set go past them on the left, while they stayed within an open space in the Cave. That was one of the signs of Allah. He whom Allah guides is rightly guided; but he whom He leads astray you shall not find for him a guardian to guide him.

# 2158

You might have thought them awake, though they were sleeping. We turned them about to the right and to the left, while their dog stretched its paws at the entrance. Had you seen them you would surely have become filled with terror and turned your back on them in flight.

# 2159

As such We revived them so that they might question one another. 'How long have you stayed here' asked one of them. 'We have been here a day, or part of it' they replied. They said: 'Your Lord knows best how long we have stayed here. Let one of you go to the city with this silver (coin) and let him search for one who has the purest food and bring provision from it. Let him be courteous, but let no one sense it is you.

# 2160

For, if they appear in front of you, they will stone you to death or restore you to their religion. Then you will never prosper'

# 2161

And so We made them (the unbelievers) stumble upon them, so that they might know that the promise of Allah is true and that there is no doubt about theHour. They argued among themselves over their affair, then (the unbelievers) said: 'Build a building over them (their remains). Their Lord knows best who they were. 'But those who prevailed over the matter said; 'We will build around them a Mosque'

# 2162

Some will say: 'They were three; their dog was the fourth' Others, guessing at the Unseen, will say: 'They were five and their dog was the sixth' And yet others: 'Seven; their dog was the eighth' Say: 'My Lord knows best their number. Except for a few none know their number' Therefore, do not dispute with them except in outward disputation, and do not ask any of them concerning them.

# 2163

Do not say of anything: 'I will do it tomorrow'

# 2164

unless (you add) 'if Allah wills' And remember your Lord when you forget and say: 'It may be that my Lord will guide me to something nearer to rectitude than this'

# 2165

And they stayed in the Cave three hundred years and to that they added nine more.

# 2166

Say: 'None but Allah knows how long they stayed. To Him belong the Unseen in the heavens and the earth. How well He sees, and how well He hears! They have no other guardian, other than Him, and He allows no one (to share) His rule'

# 2167

Recite what is revealed to you in the Book of your Lord. No one can change His Words. You shall find no refuge other than Him.

# 2168

And be patient with those who call to their Lord in the morning and evening, desiring His Face. And do not turn your eyes away from them desiring the good things of this life, nor obey he whose heart We have made neglectful of Our remembrance; so that he follows his own lust, and his affair has become excessive.

# 2169

Say: 'This is the truth from your Lord. Let whosoever will, believe, and whosoever will, disbelieve it' For the harmdoers, We have prepared a Fire, the pavilion of which encompasses them. When they cry out for relief, they shall be showered with water as hot as molten copper, which will scald their faces; how evil a drink, and how evil a restingplace!

# 2170

As for those who believe and do good works We do not waste the wage of whosoever does good works.

# 2171

Those, they shall live in the Gardens of Eden, underneath which rivers flow. They shall be adorned with bracelets of gold and arrayed in green garments of silk, and brocade, reclining therein on couches; how excellent is their reward and how fine is their resting place!

# 2172

Give them the parable of two men. To one we gave two gardens of vines and surrounded them with palm trees and in between the two we placed a sownfield.

# 2173

Each of the two gardens yielded its produce and did not fail in the least and We made a river to gush through them,

# 2174

so he had fruit. As he spoke with his companion, as he was conversing with him, 'My wealth is more abundant than yours and men have a greater respect for me'

# 2175

And when, having wronged himself, he entered his garden, he said: 'I do not think that this will ever perish!

# 2176

Nor do I think that the Hour will come. Even if I returned to my Lord, I should surely find a better place than this'

# 2177

His companion said, during his conversation with him: 'What, do you disbelieve in Him who created you from dust, then from a spermdrop, and then fashioned you into a man!

# 2178

He is Allah, my Lord, and I will not associate anyone with My Lord.

# 2179

When you entered your garden why did you not say: "If Allah wills; there is no power except by Allah." Though you see me lesser than yourself in wealth and children,

# 2180

maybe my Lord will give me a garden better than yours, and send down a thunderbolt from heaven, so that in the morning it will be a slope of dust,

# 2181

or, in the morning its water will be drained into the earth so that you will not have a means to reach it'

# 2182

And all his fruit were destroyed, and in the morning he wrung his hands with grief at all he had spent on it, for it had collapsed upon its trellises, and he said: 'Would that I had not associated anyone with my Lord'

# 2183

He had no host to help him besides Allah, and he was helpless

# 2184

that Day. Supremacy belongs only to Allah, the True. He is the best to reward and the best ending.

# 2185

Give to them a parable about this present life. It is like water We have sent down from the sky with which the plants of the earth mingle, and in the morning it is straw the wind scatters. Allah is Powerful over all things.

# 2186

Wealth and children are the ornament of this present life. But the things that last and good deeds, are better with your Lord in reward and hope.

# 2187

And on the Day when We shall set the mountains in motion and you shall see the earth a leveled plain; when We gather them together, and would not leave even one behind,

# 2188

and they shall be presented in ranks before your Lord (who will say to them:) 'You have returned to Us as We created you the first time. No, you claimed We would not appoint a meeting for you!

# 2189

And the Book shall be set in place, and you will see the sinners fearful of what is in it' They shall say: 'Woe to us! How is it, this book omits nothing small or great, all are counted' And they shall find what they did is present, and Your Lord will wrong no one.

# 2190

When We said to the angels: 'Prostrate yourselves before Adam' all prostrated themselves except iblis, who was one of the jinn, disobedient to the command of his Lord. Would you then take him and his descendants to be your guardians, other than Me, when they are your clear enemy? How evil is the exchange for the harmdoers!

# 2191

Neither did I make them witnesses at the creation of the heavens and the earth, nor at their own creation. I would never take those who lead others astray to be My supporters.

# 2192

And the Day He will say: 'Call on those whom you claimed to be My associates' They will invoke them, but they will receive no answer, for We shall place a gulf between them.

# 2193

And when the evildoers see the Fire of Hell they will reckon it is there they shall fall. They shall find no escape from it.

# 2194

We have set forth for people in this Koran all manner of parables; the human is the most disputatious of things.

# 2195

Nothing prevented people from believing and seeking the forgiveness of their Lord when guidance came to them, unless they are waiting for the fate of the ancients to overtake them, or that the punishment should come upon them face to face.

# 2196

We send Our Messengers only to proclaim glad tidings and to give warning. But the unbelievers dispute with false arguments so that they may belie the truth. They have taken My verses and warnings in mockery.

# 2197

Who is greater in evil than he who, when reminded of the verses of his Lord, turns away from them and forgets what his hands have sent before him? We have placed veils over their hearts lest they should understand it, and there is heaviness in their ears. Even if you call them to guidance, they will never be guided.

# 2198

Your Lord is Forgiving, Owner of Mercy. Had it been His will to take them to task for what they earned, He would have hastened their punishment; but they have an appointed hour from which they will never escape.

# 2199

And those villages! When they became evil We destroyed them and appointed a meeting for their destruction.

# 2200

When Moses said to his (assisting) youth: 'I will not give up until I reach the point where the two seas meet even though I should go on for many years'

# 2201

But when they came to the point where the two met, they forgot their fish, which made its way burrowing into the sea.

# 2202

And when they had gone further, he said to his assisting youth; 'Bring us our breakfast; we are worn out from our journey'

# 2203

He replied: 'What do you think, I forgot the fish when we were resting on the rock. None but satan made me forget to mention this it made its way into the sea in a marvelous fashion'

# 2204

'This is what we have been seeking' said he, and they retraced their footsteps

# 2205

and found one of Our worshipers to whom We had given from Our Mercy, and to whom We had taught knowledge of Ours.

# 2206

Moses said to him: 'May I follow you so that you can teach me of that you have learned of righteousness'

# 2207

'You will not bear patiently with me' He replied.

# 2208

'For how can you bear patiently with that which you have never encompassed in your knowledge'

# 2209

He (Moses) said: 'If Allah wills, you shall find me patient, I shall not disobey your order'

# 2210

He said: 'If you follow me, you must not question me about anything till I myself speak to you concerning it'

# 2211

So they departed. When they boarded a ship, he bored a hole in it. 'What, have you made a hole in it' he said, 'is it to drown its passengers? You have done a dreadful thing'

# 2212

'Did I not I tell you' he replied, 'that you would not bear patiently with me'

# 2213

Moses said: 'Do not blame me for what I forgot, nor press me to do something which is too difficult'

# 2214

and so they departed. Thereafter they met a boy and he killed him. He (Moses) exclaimed: 'What, have you killed a pure soul and it was not done (in retaliation) for a soul you have done a terrible thing'

# 2215

'Did I not tell you' he replied, 'that you would not be able to bear patiently with me'

# 2216

He (Moses) said: 'If I question you again do not let me be your companion; you already have enough excuse'

# 2217

So they departed and thereafter they came to the inhabitants of a village. They asked its inhabitants for some food, but they declined to host them. There, they found a wall about to fall down whereupon his companion restored it. He (Moses) said: 'Had you wished, you could have taken payment for that'

# 2218

He said: 'This is the parting between me and you. But now I will tell you the interpretation of that which you could not patiently bear.

# 2219

As for the ship, it belonged to poor people working on the sea. I rendered it imperfect because behind them there was a king who was taking every ship by brutal force.

# 2220

As for the boy, his parents are believers, and we were afraid lest he should impose on them with his insolence and disbelief.

# 2221

It was our wish that their Lord should grant them another in exchange, another better in purity and tenderness.

# 2222

As for the wall, it belonged to two orphan boys in the city. Beneath it was (buried) a treasure which belonged to them. Their father had been a righteous person and your Lord willed that when they reach manhood to bring out their treasure as a mercy from your Lord. What I did was not done by my own command. That is the interpretation of what you could not bear with patience'

# 2223

They will ask you about ThulKarnain (the pious and chosen). Say: 'I will recite to you something of his story.

# 2224

We established him in the land and gave him means to all things.

# 2225

He journeyed on a way

# 2226

until, when he reached the setting of the sun, he found it setting in a muddy spring, and nearby he found a nation. 'ThulKarnain' We said, 'you must either punish them or show them kindness'

# 2227

He replied: 'The evildoer we shall punish. Then he shall return to his Lord and He will punish him with a stern punishment.

# 2228

As for he who believes and does good works he shall receive a fine reward in recompense and we shall speak to him with a mild command'

# 2229

Then he followed the road,

# 2230

until he reached the rising of the sun, he found it rising upon a nation for whom We provided no veil against it to shade them.

# 2231

So, We encompassed in knowledge what was with him.

# 2232

Then he followed the road,

# 2233

when he reached between the two barriers he found on one side of them a nation who could barely understand speech.

# 2234

'ThulKarnain' they said, 'Look, Gog and Magog are corrupting the earth. Build for us a barrier between us and them, and we will pay you a tribute'

# 2235

He replied: 'That which my Lord has given me is better, therefore help me with all your power, and I will build a barrier between you and between them.

# 2236

Bring me ingots of iron' After he had leveled between the two cliffs, he said: 'Blow' And when he made it a fire, he said: 'Bring me molten copper so that I may pour over it'

# 2237

Thereafter they could neither scale it, nor could they pierce it.

# 2238

He said: 'This is a mercy from my Lord. But when my Lord's promise is come, He will make it dust. The promise of my Lord is true'

# 2239

On that day, We will let them surge on one another, and the Horn shall be blown, and We will gather them all together.

# 2240

On that Day We shall present Gehenna (Hell) to the unbelievers,

# 2241

whose eyes were blinded to My remembrance and they were not able to hear.

# 2242

Do the unbelievers think that they can take My worshipers as guides other than Me? We have prepared Gehenna to be the hospitality of the unbelievers.

# 2243

Say: 'Shall we tell you of those who are the greatest losers in deeds'

# 2244

(They are) those whose striving in this world go astray, while they think that what they are doing are good deeds.

# 2245

Those are they who disbelieve the verses of their Lord and deny that they will ever meet Him their deeds have failed. On the Day of Resurrection, We shall not give any weight to them.

# 2246

Gehenna is their recompense; because they disbelieved and mocked My verses, and My Messengers.

# 2247

The hospitality of those who believe and do good works shall be the Gardens of Paradise

# 2248

where they will live for ever and never wish that they should be removed from it.

# 2249

Say: 'If the sea were ink for the Words of my Lord, the sea would surely be spent before the Words of my Lord are spent, even if We brought its like for replenishment'

# 2250

Say: 'I am only a human like you, revealed to me is that your God is One God. Let him who hopes for the encounter with his Lord do good work, and not associate anyone with the worship of his Lord'

# 2251

KaafHaYa'aeenSaad.

# 2252

A mention of the Mercy of your Lord to his worshiper Zachariah,

# 2253

when he called upon his Lord in secret,

# 2254

saying: 'O my Lord, my bones are enfeebled, and my head glows silver with age. Yet, never Lord, have I been unblessed in prayer to You.

# 2255

Indeed, I fear my kinsmen who will succeed me, for my wife is barren. Grant me a kinsman

# 2256

who will be my heir and an heir to the House of Jacob, and make him, my Lord, satisfied'

# 2257

'O Zachariah, We give you good tidings of a son, and he shall be called John (Yahya); a name We have never given before'

# 2258

'How shall I have a son, Lord' he asked, 'when my wife is barren, and I am advanced in years'

# 2259

He replied: 'It shall be so; your Lord says: "It is easy for Me, indeed, I created you before time when you were not a thing."

# 2260

He (Zachariah) said: 'Lord, make for me a sign' He replied: 'Your sign is that you shall not speak to people for three nights being without fault'

# 2261

Then he came out from the Sanctuary to his nation, and gestured to them to exalt (their Lord) at the dawn and at the evening.

# 2262

(We said): 'O John, hold fast to the Book', and We bestowed on him judgment while yet a child

# 2263

and tenderness from Us and purity, and he was cautious;

# 2264

honoring his parents, being neither arrogant nor rebellious.

# 2265

Peace be upon him on the day he was born and the day he dies, and on him the day when he is raised up alive.

# 2266

And mention in the Book, Mary, how she withdrew from her people to an eastern place and she took a veil apart from them;

# 2267

We sent to her Our Spirit (Gabriel) in the resemblance of a perfect human.

# 2268

(And when she saw him) she said: 'I take refuge in the Merciful from you! If you are fearful'

# 2269

'I am the Messenger of your Lord' he replied, 'and have come to give you a pure boy'

# 2270

'How shall I bear a son' she answered, 'when I am not touched by a human and not unchaste'

# 2271

"Even so" he replied, "as such your Lord has said: 'Easy it is for Me. And We shall make him a sign to mankind and a mercy from Us. It is a matter decreed.'"

# 2272

Thereupon she carried him, and retired to a far off place.

# 2273

And when the birthpangs came upon her by the trunk of a palmtree, she said: 'Oh, would that I had died before this and become a thing forgotten'

# 2274

He called from below to her: 'Do not sorrow, look, your Lord has provided a rivulet below you,

# 2275

and shake the trunk of this palmtree it will drop fresh ripe dates upon you.

# 2276

Therefore eat and drink and rejoice with your eyes. If you meet any human say to him: "I have vowed a fast to the Merciful and will not speak with anyone today.'

# 2277

She came to her nation, carrying him; and they said: 'O Mary, you have committed a monstrous thing.

# 2278

O sister of Aaron, your father was never an evil man, nor was your mother unchaste'

# 2279

So she pointed to him (Prophet Jesus). But they replied: 'How can we speak with a baby in the cradle'

# 2280

He (the baby) said: 'I am the worshiper of Allah. Allah has given me the Book and made me a Prophet.

# 2281

He made me to be blessed wherever I am, and He has charged me with prayer and charity for as long as I shall live.

# 2282

(He has made me) kind to my mother; He has not made me arrogant, unprosperous.

# 2283

Peace be upon me on the day I was born, and on the day I die; and on the day when I shall be raised up alive'

# 2284

Such was (Prophet) Jesus, the son of Mary. A saying of truth, concerning what they doubt.

# 2285

It is not for Allah to take a son! Exaltations to Him! When He decrees a thing He only says: 'Be' and it is.

# 2286

Indeed, Allah is my Lord and your Lord therefore worship Him. That is the Straight Path.

# 2287

But the parties have fallen into variance among themselves, then woe to those who disbelieve for the scene of a Dreadful Day.

# 2288

How well they will hear and see on the Day when they come before Us! The evildoers are today in clear error.

# 2289

Warn them of that Day of Anguish, when the matter is determined whilst heedlessly they disbelieve.

# 2290

For We shall inherit the earth and all that are on it. To Us, they shall return.

# 2291

Mention in the Book Abraham; He was truthful and a Prophet.

# 2292

He said to his father: 'O father, why worship that which can neither see nor hear, nor helps you in anything?

# 2293

Father, knowledge has come to me which has not come you, therefore, follow me. I will guide you to a Level Path.

# 2294

Father, do not worship satan; for satan has rebelled against the Merciful.

# 2295

Father, I fear that the punishment of the Merciful will fall upon you and you will become a guide of satan'

# 2296

But he replied: 'Do you shrink away from my gods, Abraham? Surely, if you do not cease I will stone you, so leave me for awhile'

# 2297

'Peace be on you' he (Abraham) said, 'I shall call upon my Lord to forgive you, for to me He has been gracious.

# 2298

Now I will go away from you and that you call upon, other than Allah. I will call on my Lord. Perhaps I shall not be unblessed in calling my Lord'

# 2299

So when he turned away from them and those they worshipped, other than Allah, We gave him Isaac and Jacob. Each of them We made a Prophet,

# 2300

and We gave them of Our Mercy and We appointed to them a truthful, highly sincere tongue,

# 2301

Mention in the Book, Moses. He was devoted, a Messenger, and a Prophet.

# 2302

We called out to him from the right side of the mountain, and drew him near in (Divine) conversation.

# 2303

From Our Mercy We gave him, his brother Aaron, a Prophet.

# 2304

And mention in the Book, Ishmael; he too was true to his promise, a Messenger and a Prophet.

# 2305

And he ordered his people to pray and to give charity and his Lord was pleased with him.

# 2306

And mention in the Book, Idris; he too was of the truth and a Prophet,

# 2307

We raised him to a high place.

# 2308

These are whom Allah has blessed among the Prophets from among the seed of Adam and of those whom We bore with Noah; the descendants ofAbraham, of Israel, and of those whom We have guided and chose. For when the verses of the Merciful were recited to them, they fell down prostrate, weeping.

# 2309

But the generation that succeeded them wasted their prayers and followed their desires, so they shall encounter error

# 2310

except he who repents and believes and does good works; those shall be admitted to Paradise and shall not be wronged in any way.

# 2311

(They shall enter the) Gardens of Eden, which the Merciful has promised His worshipers in the Unseen. Indeed, His promise shall come.

# 2312

There, they shall hear no idle talk, but only peace. And there they shall be given their provision at dawn and at the evening.

# 2313

That is the Paradise which We shall give the cautious worshipers to inherit.

# 2314

(Gabriel said:) 'We do not descend except at the command of your Lord. To Him belongs all that is before us and all that is behind us, and all that lies between. Your Lord does not forget.

# 2315

Lord of the heavens and the earth and all that is between them, so worship Him, be patient in His worship. Do you know any that can be named with His Name'

# 2316

The human says: 'What, when I am dead, shall I be raised to life'

# 2317

Will the human not remember that We created him before when he was not a thing.

# 2318

By your Lord, We will gather them and the satans, and We shall parade them hobbling on their knees in Gehenna:

# 2319

from every party We will pluck out whichever of them was the most hardened in disdain of the Most Merciful.

# 2320

We alone know who deserves most to be burned therein.

# 2321

There is not one of you who shall not go down to it: such is a thing decreed, determined by your Lord.

# 2322

Then, We will save those who were cautious of Us, but the harmdoers shall be left there hobbling on their knees.

# 2323

When Our clear verses are recited to them the unbelievers say to the believers: 'Which of the two parties has a better position or company'

# 2324

How many generations have We destroyed before them, who were far greater in riches and more boastful!

# 2325

Say: 'Whosoever is in error, let the Most Merciful prolong his life span until they see that which they were threatened, be it a punishment, or the Hour. Thenshall they know whose is the worst place and who is weaker in hosts'

# 2326

Allah will increase those who were guided in guidance and things that abide. Good deeds are better in reward with your Lord, and, better in return.

# 2327

Have you seen he who disbelieves Our verses and yet says: 'I shall surely be given wealth and children'

# 2328

Has he gained knowledge of the Unseen? Or taken a covenant with the Merciful?

# 2329

On the contrary, We will write down what he says and prolong the length of his punishment.

# 2330

We shall inherit that of which he speaks and he will come before Us alone.

# 2331

And they have taken gods, other than Allah, that they might be a power from them.

# 2332

Indeed no! They will renounce their worship and turn against them.

# 2333

Have you not seen how We send down to the unbelievers satans who prick them?

# 2334

Therefore, do not hasten (things) against them, for We count out to them a number,

# 2335

and on the Day when We will ceremonially gather the righteous to the Merciful,

# 2336

and drive the evildoers as herds, into Gehenna

# 2337

who have no power of intercession, except those who have taken a covenant with the Merciful.

# 2338

And they say: 'The Merciful has taken a son'

# 2339

Surely, you have brought a monstrous thing!

# 2340

Thereby the heavens are nearly torn and the earth split asunder, and mountains fall crashing down

# 2341

because they have ascribed a son to the Merciful.

# 2342

It is not for the Merciful to take a son!

# 2343

There is none in the heavens and earth except he comes to the Merciful as a worshiper.

# 2344

He has counted them and exactly numbered all;

# 2345

and each one shall come to Him on the Day of Resurrection, alone.

# 2346

Those who believe and do righteous deeds, the Merciful will assign for them love.

# 2347

We have made it easy in your own tongue in order that you proclaim the glad tidings to the cautious and give warning to a stubborn nation.

# 2348

How many generations have We destroyed before them! Do you sense even one of them, or hear a whisper from them?

# 2349

TaHa.

# 2350

We have not sent down the Koran to you for you to be tired,

# 2351

but as a reminder to he who fears.

# 2352

It is a sending down from Him who has created the earth, and the high heavens,

# 2353

the Merciful willed to the Throne.

# 2354

To Him belongs all that is in the heavens and the earth, and all that lies between them, and underneath the soil.

# 2355

If you speak loudly; He has indeed knowledge of the secret and the hidden.

# 2356

Allah, there is no god except He. To Him belong the most Beautiful Names.

# 2357

Has the story of Moses reached you?

# 2358

When he saw a fire, he said to his family: 'Stay here, for I can see a fire. Perhaps I can bring you a lighted torch or find at the fire guidance'

# 2359

When he reached it, he was called: 'O Moses,

# 2360

I am your Lord. Take off your shoes, for you are in Towa, the sacred valley.

# 2361

I have chosen you. Therefore, listen to what shall be revealed.

# 2362

Indeed, I am Allah. There is no god except Me. Worship Me, and establish the prayer of My remembrance.

# 2363

The Hour is coming. I almost conceal it, so that every soul will be recompensed for its labors.

# 2364

Do not let those who disbelieve in it and follow their desires bar you from it, or you will perish.

# 2365

What is that in your right hand, Moses'

# 2366

'It is my staff," Moses replied, "upon it I lean and with it I beat down leaves to feed my sheep and for me there are other uses in it'

# 2367

He said: 'Moses, cast it down'

# 2368

So he cast it down, and thereupon it turned into a sliding serpent.

# 2369

'Take it, and do not fear' He said, 'We will restore it to its former state.

# 2370

Now, put your hand under your armpit. It shall come out white, without evil, a second sign.

# 2371

But We shall show you some of Our greatest signs.

# 2372

24 Go to Pharaoh, he has become insolent'

# 2373

'Lord' said Moses, 'expand my chest,

# 2374

and ease my task for me.

# 2375

Unloose the knot upon my tongue,

# 2376

that they may understand my speech.

# 2377

Appoint for me a minister from my family

# 2378

Aaron, my brother.

# 2379

By him confirm my strength

# 2380

and let him share my task,

# 2381

so that we exalt You

# 2382

and remember You abundantly.

# 2383

You are surely seeing us'

# 2384

He replied: 'Moses, your request is granted.

# 2385

We had already shown you favor

# 2386

when We revealed what was to be made known to your mother,

# 2387

saying: "Put him in the box and cast it into the river. The river will cast him on to the bank, and he shall be taken up by an enemy of Mine and an enemy of his." I lavished My Love on you, and to be formed in My Sight.

# 2388

Your sister went (to them) and said: 'Shall I guide you to one who will nurse him' And so We restored you to your mother, so that her eyes might rejoice and that she might not sorrow. And when you killed a soul We saved you from grief and then We tried you with many trials. You stayed among the people of Midian for a number of years, and then, Moses, you came here according to a decree.

# 2389

I have chosen you for Me.

# 2390

Go, you and your brother with My signs, and do not be negligent of My Remembrance.

# 2391

Go to Pharaoh, for he has become insolent.

# 2392

Speak to him with gentle words; perhaps he will ponder or fear'

# 2393

'O our Lord' both said, 'We fear lest he may be excessive against us or become insolent'

# 2394

He replied: 'Have no fear I shall be with you, both hearing and seeing.

# 2395

Both of you go to him (Pharaoh) and say: "We are the Messengers of your Lord. Let the Children of Israel depart with us, and do not punish them. We have come to you with a sign from your Lord; peace be on him who follows guidance!

# 2396

It is revealed to us that a punishment will fall on those who belie and turn away."

# 2397

He (Pharaoh) said: 'Moses, who is the Lord of you both'

# 2398

'Our Lord' he replied, 'is He Who gave everything its creation and then guided it'

# 2399

He (Pharaoh) asked: 'How was it then, with the former generations'

# 2400

He (Moses) answered: 'The knowledge of them is in a Book with My Lord. My Lord neither goes astray, nor forgets.

# 2401

It is He who has made for you the earth as a cradle and threaded roads for you and sends down water from the sky with which We bring forth every kind of plant.

# 2402

You eat and let your cattle graze' Surely, in this there are signs for those of understanding.

# 2403

We created you from it (the earth), and to it We shall restore you; and from it We will bring you forth yet a second time.

# 2404

So We showed him (Pharaoh) Our signs, all of them, but he belied and refused them.

# 2405

He said: 'Moses, have you come to drive us from our land with your sorcery?

# 2406

We will indeed bring sorcery similar to yours. Appoint a meeting place between us and you, in a place which is agreeable to both which neither we nor you shall not fail (to keep)'

# 2407

He (Moses) replied: 'Your meeting shall be on the day of the feast, and let the people be assembled by midmorning'

# 2408

So Pharaoh withdrew and gathered his guile, then returned,

# 2409

and Moses said to them: 'Alas! Do not forge a lie against Allah lest He destroys you with a punishment. Indeed, whosoever forges has failed'

# 2410

They disputed upon their plan with one another, and spoke in secret

# 2411

saying: 'These two are sorcerers whose aim is to drive you from your land by their sorcery and destroy your noble ways.

# 2412

Gather your guile and then lineup a rank those who gain the upper hand today shall indeed prosper'

# 2413

They said to Moses: 'Will you throw down or shall we be the first?

# 2414

Moses replied: 'No, you throw first' And by their sorcery it seemed to him that their ropes and staffs were sliding.

# 2415

Moses became fearful within himself.

# 2416

But We said to him: 'Do not be afraid; you shall surely be the uppermost.

# 2417

Throw that which is in your right hand. It will swallow up that which they have made, for that which they made is but the guile of a sorcerer. Wherever he goes the sorcerer does not prosper'

# 2418

Thereafter the sorcerers threw themselves down, prostrating, saying: 'We believe in the Lord of Aaron and Moses'

# 2419

'Have you believed him before I have given you permission' he (Pharaoh) said. 'Indeed, he (must be) your chief, the one who taught you sorcery. I will cut off on opposite sides a hand and a foot then crucify you on the trunks of palmtrees. Indeed, you shall know whose punishment is more stern, and more lasting'

# 2420

Their reply was: 'We will not prefer you over the clear signs that have come to us, nor over Him who has created us. So decide upon whatever you decide, you can only decided upon things in this present life.

# 2421

We believe in our Lord so that He forgives us our sins and the sorcery you have forced us to practice. Allah is Better, and Everlasting'

# 2422

Gehenna (Hell) awaits whosoever comes before his Lord as a sinner, there he shall neither die nor live.

# 2423

But for whosoever comes before Him as a believer and having done good works there awaits the most highest degree;

# 2424

living for ever in the Gardens of Eden, underneath which rivers flow. Such shall be the recompense of he who purifies himself.

# 2425

To Moses we also revealed: 'Set forth with My worshipers by night and strike for them a dry path in the sea. Do not fear that you will be overtaken, neither be afraid'

# 2426

Pharaoh pursued them with his legions so they were overwhelmed from the sea with that which drowned them.

# 2427

For Pharaoh had misled his nation, and did not guide them.

# 2428

Children of Israel! We saved you from your enemies and made a covenant with you on the right side of the Mountain. We sent down manna and quails.

# 2429

'Eat of the good things with which We have provided you and do not transgress therein lest My Anger should fall upon you, and upon whosoever My Anger falls has assuredly fallen,

# 2430

but to whosoever repents, believes and does good deeds, and is at last guided, I am Forgiving'

# 2431

'Moses, why have you come with such haste from your nation'

# 2432

Moses replied: 'They are following me. My Lord, I made haste only so that I might please You'

# 2433

He (Allah) said: 'We tempted your nation in your absence, and the Samaritan has misled them into error'

# 2434

With great anger and sorrow, Moses returned to his nation. 'My nation' he said, 'did your Lord not make you a fine promise? Did the time of the covenant seem long to you? Or did you desire that the anger of your Lord should fall upon you so that you failed in your coming to my appointment'

# 2435

They replied: 'We have not failed in our promise to you through our choosing. We were laden with fardels, even the ornaments of the nation, and threw them just as the Samaritan had thrown them (into the fire),

# 2436

and made a calf for them, a figure that lowed. "This," they said, "is your god and the god of Moses but whom he has forgotten."

# 2437

What! Did they not see that it did not speak a word to them in return, and for them it could own neither harm nor benefit?

# 2438

Aaron had said to them before: 'My nation, you have been tempted by it. Your Lord is the Merciful. Follow me and obey my order'

# 2439

They replied: 'We will not stop; we will cling to it until Moses returns to us.'

# 2440

He (Moses) said to Aaron: 'When you saw them in error, what prevented you,

# 2441

from following after me, did you disobey my order'

# 2442

'Son of my mother' he replied, 'Do not seize my beard nor my head. I was afraid that you might say: "You have divided the Children of Israel and did not uphold my word."

# 2443

'You, Samaritan' said he (Moses), 'what was your business'

# 2444

He replied: 'I saw what they did not see and seized a handful of dust from the foot print of the messenger and so I cast it this my soul prompted me to do'

# 2445

'Begone! Your lot in this life is to cry: "untouchable!' said he (Moses). 'An appointment awaits you that you cannot fail to keep. Look at your god which you clung to indeed we will burn it and scatter its ashes upon the sea'

# 2446

Your God is only One, Allah. There is no god, except He, alone. His knowledge encompasses all things.

# 2447

And so We narrate to you the stories of the past, and We have given you a remembrance from Us.

# 2448

Whosoever has turned away from it shall bear a burden on the Day of Resurrection.

# 2449

and live in it for ever; how evil will that burden be for them on the Day of Resurrection.

# 2450

The Day when the Horn shall be blown. On that Day, We shall assemble all the sinners with blued eyes,

# 2451

and they shall murmur among themselves: 'You have stayed away but ten (days and nights)'

# 2452

We know well what they will say. The most just among them in the matter will declare: 'You have stayed away but one day'

# 2453

They will question you about the mountains. Say: 'My Lord will scatter them as ashes

# 2454

and leave them a desolate waste,

# 2455

with neither crookedness nor any curving to be seen therein'

# 2456

On that Day, they will follow the Summoner, who is not crooked, their voices hushed before the Merciful, and you shall hear nothing except a murmuring.

# 2457

On that Day intercession will not benefit them except him that has received the permission of the Merciful and whose words are pleased by Him.

# 2458

He knows what is before them and behind them, and they do not comprehend Him in knowledge.

# 2459

(All) faces shall be humbled before the Living One, the Eternal. Those who are burdened with wrong doing shall have failed,

# 2460

but those who have believed and done good works shall fear neither wrong nor injustice.

# 2461

As such We sent it down, an Arabic Koran, and explained in it threats in order that they be cautious, or, that it prompts the Remembrance in them.

# 2462

Highly exalted be Allah, the true King! Do not hasten with the Koran before its revelation has been completed to you, but say: 'Lord, increase me in knowledge'

# 2463

We made a covenant with Adam, but he forgot and We found in him no constancy.

# 2464

And when We said to the angels: 'Prostrate yourselves before Adam' they all prostrated themselves except iblis, who refused.

# 2465

'Adam' We said, 'This is you and your wife's enemy. Do not let him expel you from the Garden, so that you (Adam) will be tired.

# 2466

It has been given to you so that you shall neither become hungry nor naked therein;

# 2467

there, (you shall) neither thirst, nor suffer from the sun'

# 2468

But satan whispered to him saying: 'Adam, shall I direct you the Tree of Eternity and a kingdom which never decays'

# 2469

They both ate of it, and their shameful parts appeared to them, whereupon they began to stitch upon themselves leaves from the Garden. And so it was, Adam erred and disobeyed his Lord.

# 2470

But afterwards his Lord chose him; He turned again towards him and guided him.

# 2471

'Both of you, together, go down out of it (the Garden) each of you an enemy to the other' He said: 'but, if My Guidance comes to you, whosoever followsMy Guidance shall neither go astray nor be unprosperous;

# 2472

but whosoever turns away from My remembrance, his life shall be narrow and on the Day of Resurrection We shall raise him blind'

# 2473

'My Lord' he will say: 'why have You raised me blind when I was able to see'

# 2474

He (Allah) will say: 'It is so, Our verses came to you and you forgot them. So this Day you are forgotten'

# 2475

In this way We recompense the prodigal who disbelieves the verses of his Lord. But the punishment of the Everlasting Life is more terrible and everlasting.

# 2476

Is it not a guidance to them, how many generations We destroyed before them in whose dwelling places they walk? Surely, in this there are signs for thoseof reason.

# 2477

Except for a Word that preceded from your Lord, and a stated term, it had been fastened.

# 2478

Therefore, be patient with what they say, and exalt with the praise of your Lord before sunrise and before sunset. And in the watches of the night and at the edges of the day, exalt Him, so that you will be pleasing.

# 2479

Do not stretch your eyes at the flower of this life which We have given couples to enjoy, it is with this that We might try them; and the provision of yourLord is better, and more enduring.

# 2480

Order your family to pray and be patient in it. We do not ask you for provisions, rather, it is We who provide for you. And the final outcome is for the cautious.

# 2481

They say: 'Why does he not bring us a sign from his Lord' Did not a clear sign come to them in the preceding Scrolls?

# 2482

Had We destroyed them with a punishment before this, they would have said: 'Our Lord, why did You not send us a Messenger so that we could have followed Your verses before we were humiliated and degraded'

# 2483

Say: 'Everyone is waiting; so wait. Indeed, you shall know who are the companions of the Even Path, and those who are guided'

# 2484

The Reckoning for mankind is drawing near, yet they are heedless and turn away.

# 2485

No recent revival of the remembrance comes to them from their Lord, except that they play with it as they listen

# 2486

their hearts are diverted. The harmdoers mutter to one another: 'Is this anything else but a human like yourself? What, will you follow sorcery with your eyes open'

# 2487

He said: 'My Lord has knowledge of what is said in the heavens and on earth. He is the Hearer, the Knower'

# 2488

Some say: 'No, it is only mixed dreams' 'No, he has forged it himself', or, 'no, he is a poet! Let him bring us a sign, just as the ancient ones were sent asMessengers'

# 2489

Of the villages We destroyed, there was not one that believed. What, will they not believe?

# 2490

We never sent (anyone) before you except men to whom We revealed to them. 'Ask the people of the Remembrance if you do not know'

# 2491

Nor did We make them bodies that ate no food, nor were they immortal.

# 2492

Then We were true to the promise, We saved them together with those whom We willed, and destroyed the transgressors.

# 2493

Now, We have sent down to you a Book in which is your Remembrance. Will you not understand?

# 2494

How many harmdoing villages have We shattered and replaced them with another nation.

# 2495

And when they felt Our Might they fled from it.

# 2496

'Do not run away. Return to your luxury that you rejoiced in, and your homes in order that you be questioned'

# 2497

They said: 'Alas for us we were harmdoers'

# 2498

And this they did not stop crying out until We made them stubble, silent, and still.

# 2499

It was not in play that We created the heavens and the earth and all that lies between them.

# 2500

Had We wished to take to Us an amusement We would have taken it to Us from Ours had We done so.

# 2501

No, We hurl truth at falsehood, and it shall conquer it, and see, falsehood vanishes. Woe to you for all you have described.

# 2502

To Him belongs whosoever is in the heavens and the earth. Those who are with Him are not too proud to worship Him, nor are they ever wearied.

# 2503

They never fail to exalt Him either at night or in the day.

# 2504

Or, have they taken earthly gods who revive the dead?

# 2505

Had there been gods in heaven or earth, other than Allah, both would indeed have been ruined. Exalted be Allah, Lord of the Throne, above that they describe.

# 2506

He is not to be questioned about what He does, but they shall be questioned.

# 2507

Have they taken gods, other than Him? Say: 'Bring us your proof! Here is the Remembrance of he who is with me and the Remembrance of those before me' But no, most of them do not know the truth, therefore they turn away.

# 2508

We never sent a Messenger before you except that We revealed to him saying: 'There is no god except Me, therefore, worship Me'

# 2509

They say 'The Merciful has taken a son' Exaltations to Him! No, they are only His honored worshipers,

# 2510

who do not surpass Him in speech, and do as He commands.

# 2511

He knows what is before them and what is behind them. They intercede for none except for him whom He is well pleased, and they tremble in awe of Him.

# 2512

If any one of them says: 'I am a god other than Him' We will recompense him with Gehenna (Hell). As such We recompense the harmdoers.

# 2513

Have the unbelievers not seen that the heavens and the earth were sewn up as one (solid) mass, then We unstitched them, and that We made every living thing of water? Will they not believe!

# 2514

We set firm mountains upon the earth lest it should shake with them, and We placed therein ravines to be paths so that they might be guided.

# 2515

We established the heaven as a well protected roof, yet they still turn away from its signs.

# 2516

It is He who created the night and the day, and the sun and the moon; each floating in an orbit.

# 2517

We have never assigned immortality to a human before you, therefore, if you yourself die, will they live for ever?

# 2518

Every soul shall taste death. We will try you with a trial of evil and good. Then, to Us you shall be returned.

# 2519

When the unbelievers see you, they take you only for mockery, saying: 'Is this he who talks about your gods' While they are unbelievers in the Remembrance of the Merciful.

# 2520

The human was created of haste. Indeed, I will show you My signs; so do not ask Me to hasten them.

# 2521

They say: 'If you are truthful, when will this promise come'

# 2522

If the unbelievers only knew when they will be unable to shield either their faces or their backs from the Fire; when they will not be helped!

# 2523

It will overtake them suddenly, dumbfounding them. They shall be unable to ward it off, and they shall not be respited.

# 2524

Before you, other Messengers were mocked, but the mockers were encompassed by the very thing they mocked.

# 2525

Say: 'Who will guard you, by night and by day from the Merciful' But no, they turn away from their Lord's remembrance.

# 2526

Or have they gods to defend them, other than Us? Indeed, they are unable to help themselves, neither shall they be guarded in safety from Us.

# 2527

We gave days of enjoyment to them and their fathers until their life became long. Are they unable to see how We come to their land and reduce its borders. Or, is it they who are the victors?

# 2528

Say: 'I warn you only by the Revelation' But the deaf hear nothing when they are warned.

# 2529

But if just a breath of your Lord's punishment were to touch them, they would say: 'Woe for us, we were harmdoers'

# 2530

On the Day of Resurrection We shall set up just scales, so that no soul shall in the least be wronged, even though it be the weight of a grain of mustard seedWe will bring it We Suffice as reckoners.

# 2531

We gave Moses and Aaron the Criterion, and gave them a light and a Remembrance for the cautious:

# 2532

those who fear Allah in the Unseen, tremble because of the Hour.

# 2533

This is a blessed Remembrance which We have sent down. Do you disbelieve it?

# 2534

Before this We gave Abraham his virtue, for We knew him.

# 2535

He said to his father and to his nation: 'What, are these the statues to which you cling'

# 2536

They replied: 'We found our fathers worshipping them'

# 2537

He said: 'Truly, you and your fathers are in clear error'

# 2538

They said: 'Is it the truth you have brought us, or are you one of those that play'

# 2539

'No' he answered, 'your Lord is the Lord of the heavens and the earth, the Originator of them, and I am among those bearing witness to it.

# 2540

By Allah, I will certainly outwit your idols as soon as you have turned your backs and gone'

# 2541

He broke them all into pieces, except their great one so that they might return to it.

# 2542

'Who has done this to our gods' they exclaimed. 'He must surely be a harmdoer'

# 2543

'We have heard a young man called Abraham mention them' they replied.

# 2544

They said: 'Then bring him here so that the people may see, so that they may bear witness'

# 2545

'Abraham' they said, 'was it you who did this to our gods'

# 2546

'No' he replied. 'It was their great one amongst them that did it. Ask them, if they are able to speak'

# 2547

So they returned one to another saying, 'Surely, it is you who are the harmdoers'

# 2548

But then they reversed their minds: 'You know they do not speak'

# 2549

He said: 'Would you then worship that, instead of Allah, which can neither help nor harm you?

# 2550

Shame on you and on that you worship other than Allah! Have you no understanding'

# 2551

They said: 'Burn him and help your gods, if you are going to do anything'

# 2552

'O Fire' We said, 'be coolness and safety for Abraham'

# 2553

They sought to outwit him, but We made them the worst of losers.

# 2554

We saved him and Lot, and brought them to the land which We had blessed for all the worlds.

# 2555

We gave him, in excess, Isaac, and Jacob (for a grandson); and We made each righteous

# 2556

and appointed them leaders to guide by Our Command and We revealed to them to do good deeds, and to establish the prayer, and the giving of charity, and they were for Us worshipers.

# 2557

To Lot, We gave judgment and knowledge and saved him from the village that had been committing corrupt deeds; for they were an evil nation and were debauched.

# 2558

We admitted him to Our Mercy, he was among the righteous.

# 2559

And (remember) Noah, when he supplicated to Us, We answered him, and We saved him and his nation from great distress,

# 2560

and helped him against the nation who had belied Our signs. They were an evil nation; We drowned them all.

# 2561

And David and Solomon they passed judgment upon the tilled land on which the people? s sheep had strayed. We bore witness to their judgment, and

# 2562

We made Solomon to understand it, and to both We gave judgment and knowledge. And with David We subjected the mountains and birds to exalt (Allah). All this We have done.

# 2563

We taught him the craft of making garments that fortify you against your own violence. Are you thankful?

# 2564

To Solomon the raging wind ran at his command to the land which We had blessed. We have knowledge of all things.

# 2565

And some of the satans dived for him and others did work as well. We were watching over them.

# 2566

And Job when he called to his Lord: 'Affliction has befallen me, and You are the Most Merciful of the merciful'

# 2567

We answered him and removed his affliction, and We gave his people, and those like them that were with them, mercy from Us, as a reminder to those who worship.

# 2568

And Ishmael, Idris, and ThulKifl (the son of Job) each were patient.

# 2569

We admitted them to Our Mercy, for they were of the righteous.

# 2570

And ThulNun (Prophet Jonah), he went away in anger thinking We had no power over him. But in the darkness he cried: 'There is no god except You. Exaltations to You! I was among the harmdoers'

# 2571

We heard his prayer and saved him from grief. As such We shall save the believers.

# 2572

And Zachariah when he called to his Lord saying: 'Lord, do not let me remain by myself; You are the Best of inheritors'

# 2573

So We answered him, and gave him John, curing his wife (of sterility). They raced with each other in good works and called on Us out of yearning and awe, and they were humble to Us.

# 2574

And she (Mary) who guarded her virginity. We breathed into her of Our spirit (Gabriel), and made her and her son a sign for the worlds.

# 2575

Indeed, this nation of yours is one nation, and I am Your Lord, therefore worship Me.

# 2576

But they (the Christians and Jews) split their affair between them all shall return to Us.

# 2577

The endeavors of he who believes and does good works shall not go unthanked. We write it down for him.

# 2578

(It is ordained that) no village We have destroyed shall return

# 2579

till Gog and Magog are let loose and slide down out of every slope;

# 2580

when the true promise draws near; the eyes of the unbelievers will stare (and they will say): 'Alas for us! Of this we have been heedless. We have beenharmdoers'

# 2581

You and all those who you were worshipping, other than Allah, shall be the fuel of Gehenna; there you shall all go down to it.

# 2582

If those had been gods, they would never have gone down to it, but in it they shall live for ever.

# 2583

There is groaning for them therein, and they do not hear.

# 2584

But those whom We have surpassed with the finest (rank) from Us shall be far removed from it,

# 2585

neither shall they hear any of its whisper, but shall live for ever in that their souls desired.

# 2586

The greatest terror shall not grieve them, and the angels will receive them: 'This is the Day you have been promised'

# 2587

On that Day, We shall roll up the heaven like a written scroll is rolled. As We originated the first creation, so will We bring it back again. This is a binding promise on Us which We shall assuredly fulfill.

# 2588

We have written in the Psalms, after the Remembrance: 'The righteous among My worshipers shall inherit the earth'

# 2589

Surely, in this is a proclamation to a worshiping nation.

# 2590

We have not sent you (Prophet Muhammad) except as a mercy to all the worlds.

# 2591

Say: 'It is revealed to me that your God is One God, do you then surrender'

# 2592

If they turn back, say: 'I have warned you all alike, though I cannot tell whether what you are promised is imminent or distant.

# 2593

He knows your spoken words and what you hide.

# 2594

And I do not know if this is a trial for you and an enjoyment for a time'

# 2595

He said: 'My Lord, judge in truth. Our Lord is the Merciful whose help is ever to be sought against what you describe'

# 2596

O people, have fear of your Lord. The earthquake of the Hour shall be a great thing.

# 2597

On that Day you will see every one that suckles shall forsake her suckling, and every carrier shall miscarry, and you shall see mankind drunk although they arenot drunk; dreadful will be the punishment of Allah.

# 2598

Among people there are those, who without knowledge, dispute about Allah and follow every rebel satan,

# 2599

against whom it is written down that whosoever takes him for a guide, he guides astray, and leads him to the punishment of the Blaze.

# 2600

O people, if you are in doubt about the Resurrection, remember that We first created you from dust, then, from a sperm drop, then from a clot, and then from a bitesize tissue formed and unformed, so that We might clarify for you. We establish in the wombs whatever We will for an appointed term, and then We bring you forth as infants, then you come of age. Some of you die, and some of you are kept back to the vilest state of life, after knowing somewhat, they know nothing. And you see the earth dry; but no sooner do We send down rain upon it than it begins to quiver and swell, putting forth every fine variety (of herbage).

# 2601

That is because Allah is the Truth; He revives the dead and has power over all things.

# 2602

And the Hour is sure to come there is no doubt. And Allah will raise up those in the graves.

# 2603

Some dispute about Allah, though they have neither knowledge nor guidance, nor an illuminating Book.

# 2604

There is for him who turns his side to lead (others) astray from the Path of Allah, degradation in this life and We shall let him taste the punishment of theburning on the Day of Resurrection.

# 2605

'This, is the reward for what your hands have forwarded. Allah is not unjust to the worshipers'

# 2606

There are among the people such who worship Allah and (yet stand) on the very edge. When goodness comes to him, he is content, but if a trial befalls him he falls upon his face, he loses this world and the Everlasting Life; that is indeed a clear loss.

# 2607

He calls to other than Allah, to that which neither hurts him, nor benefits him; that is indeed far error.

# 2608

He calls upon him whose harm is nearer than his benefit, an evil guide and an evil friend.

# 2609

As for those who believe and do good works Allah will admit them to gardens underneath which rivers flow. Allah indeed does what He will.

# 2610

If any one thinks that Allah will not give him (Prophet Muhammad) victory in this present world and in the Everlasting Life, let him stretch a rope to heaven, and let him sever it. Then, let him see if his guile does away with that which has enraged him.

# 2611

As such We have sent it in clear verses. Indeed, Allah gives guidance to whom He will.

# 2612

Surely, they that believe, and those of Jewry, the Sabaeans, the Nazarenes, the Magians, and the unbelievers, Allah will judge them on the Day of Resurrection. Surely, Allah is witness over everything.

# 2613

Have you not seen that to Allah prostrate all who are in the heavens and all who are in the earth, the sun and the moon, the stars and the mountains, the trees and the beasts, and many people? And many deserve the punishment. He who is abased by Allah has none to honor him. Allah does what He will.

# 2614

Those are two who disputed concerning their Lord. Garments of fire have been prepared for the unbelievers. Boiling water shall be poured over their heads,

# 2615

and that which is in their bellies and their skins shall be melted;

# 2616

for them are hooked rods of iron.

# 2617

Whenever in their anguish they try to get out of it, they are restored to it. (It will be said): 'Taste the punishment of burning'

# 2618

Allah will admit those who believe and do good works to gardens underneath which rivers flow. They shall be adorned therein with bracelets of gold and with pearls, and their garments shall be of silk.

# 2619

For they shall be guided to good speech and guided to the praised path.

# 2620

The unbelievers who bar from the Way of Allah and from the Holy Mosque which We made equal for all peoples, he who cleaves to it and the tentdweller alike, and whosoever seeks to violate it wrongfully, We shall let him taste a painful punishment.

# 2621

And when We settled for Abraham (and Ishmael) the place of the Holy Mosque, (We said): 'You shall not associate with Me anything. Purify My House for those who circumambulate it and those who stand, for those who bow and prostrate.

# 2622

Proclaim the pilgrimage to the people. They will come to you on foot and on every lean camel, they shall come from every deep ravine;

# 2623

that they witness profitable things for them and mention the Name of Allah on well known days over the flocks which He has provided them. Eat thereof, and feed the wretched poor.

# 2624

Then, let the pilgrims accomplish their acts of cleansing, and let them fulfill their vows, and circumambulate the Ancient House.

# 2625

All that; and whosoever venerates the sacred rites of Allah it shall be better for him with his Lord. The flocks are lawful to you, except that which is recited to you. Therefore, avoid the filth of idols and avoid speaking falsely,

# 2626

being of pure faith to Allah, not associating anything with Him. He who associates others with Allah is like he who falls from heaven and is snatched away by the birds or carried by the wind to some faroff place.

# 2627

All that; and, he who venerates the waymarks of Allah, surely it is from the piety of the hearts.

# 2628

In them, you have benefits until an appointed time. After their place of sacrifice is at the Ancient House.

# 2629

For every nation We have appointed a holy ritual, that they pronounce the Name of Allah over the beast of flocks which He has provided them. Your God isOne God; to Him surrender yourselves. Give glad tidings to the humble,

# 2630

whose hearts, when Allah is mentioned, quake, who endure their misfortunes with patience, and establish their prayers, and spend of that which We have provided them.

# 2631

And the camels We have made a part of the waymarks of Allah. In them is good for you. Pronounce over them the Name of Allah, when they are hobbled; and when they have fallen down on their sides, eat of them and feed the impoverished nonrequestor and the requestor. As such We have subjected them to you, in order that you give thanks.

# 2632

Their flesh and blood does not reach Allah rather it is piety from you that reaches Him. As such He has subjected them to you, in order that you exalt Allahfor guiding you. And give glad tidings to the generous.

# 2633

Allah will defend those who believe. Verily, Allah does not love the ungrateful cheat.

# 2634

Permission is given to those who fight because they were wronged. Allah has power to grant them victory:

# 2635

those who have been unjustly driven from their homes, just because they said: 'Our Lord is Allah' Had Allah not repelled some people by the means ofothers, the monasteries and churches, the synagogues and mosques in which the Name of Allah is remembered would have been destroyed. But whoever helps Allah shall be helped by Him. Allah is the Strong, the Almighty,

# 2636

those who, if We established them in the land, will establish the prayers and pay the obligatory charity, order with honor and forbid dishonor, and to Allah is the end of all affairs.

# 2637

If they belie you, so too before them, the nation of Noah belied, and Aad and Thamood

# 2638

and the nation of Abraham and the nation of Lot;

# 2639

and the inhabitants of Midian, to Moses they also belied. I respited the unbelievers, then I seized them, and how was My disapproval!

# 2640

How many a village We have destroyed in its harmdoing, so that it lies fallen upon its turrets, and how many an abandoned well, and empty palace!

# 2641

Have they never journeyed through the land so that they have hearts to understand, or ears to hear with? It is not the eyes, but the hearts in the chests that are blind.

# 2642

They ask you to hasten the punishment. Allah will not break His promise. Each day with your Lord is like a thousand years in your reckoning.

# 2643

And how many a village have I respited in its evil doing! Then I seized it. To Me is the return.

# 2644

Say (Prophet Muhammad): 'O people, I have been sent to warn you plainly.

# 2645

Those who believe and do good works, theirs shall be forgiveness and a generous provision;

# 2646

but those who strive to void Our verses, thinking they have escaped, shall be the people of Hell'

# 2647

Never have We sent a Messenger or a Prophet before you, but when he hoped, satan tampered with his hope. But Allah supersedes the tampering of satan and confirms His verses. And Allah is the Knower, the Wise.

# 2648

(This He permits) in order that He makes satan's interjections a temptation for those in whose hearts is a sickness and those whose hearts are hardened and the harmdoers are in a wide schism,

# 2649

and so that those to whom knowledge has been given will know that this is the truth from your Lord and so believe in it and that their hearts will be humble to Him. Indeed, Allah will surely guide those who believe to a Straight Path.

# 2650

The unbelievers will never cease to doubt it until the Hour overtakes them suddenly or the punishment of the Barren Day comes upon them.

# 2651

The Kingdom upon that Day shall belong to Allah. He will judge between them. Those who believe and do good works shall be in Gardens of Bliss,

# 2652

but for those who disbelieved Our verses and belied there awaits a humbling punishment.

# 2653

As for those who emigrated in the way of Allah and were slain, or died, Allah will provide them with fine provisions. Allah is the Best of providers.

# 2654

He will admit them by a gate that is pleasing to them, and surely, Allah is the Knower, the Clement.

# 2655

So shall it be. He who punishes after the manner that he was punished and then again is oppressed, shall be helped by Allah. Allah is Pardoning, Forgiving.

# 2656

That is because Allah causes the night to enter into the day, and the day enter into the night. Allah is the Hearer and the Seer.

# 2657

That is because Allah is the Truth, and falsehood is all that they call upon, other than Him. Allah is the Most High, the Most Great.

# 2658

Do you not see that Allah sends down water from the sky and in the morning the earth becomes green? Allah is Subtle, the Aware.

# 2659

To Him belong all that is in the heavens and earth, surely, Allah is the Rich, the Praised.

# 2660

Do you not see that Allah has subjected to you all that is on the earth, and the ships which run upon the sea by His command? He holds the sky back lest it should fall upon the earth except by His permission. Allah is Gentle to people, the Most Merciful.

# 2661

It is He who revives you, then He will cause you to die and then He revives you. Indeed, the human is ungrateful.

# 2662

For every nation We have appointed a Holy Rite which they shall perform. Do not let them dispute with you concerning the matter. Call to your Lord; surely, you are upon a Straight Path.

# 2663

If they argue with you, say: 'Allah knows best all that you do.

# 2664

On the Day of Resurrection, Allah will judge between you concerning that in which you vary.

# 2665

Are you not aware that Allah has knowledge of what is in the heaven and earth? This is (recorded) in a Book. That is easy for Allah.

# 2666

Yet they worship that for which He did not send down authority, and that of which they have no knowledge. Indeed, the harmdoers shall have no helpers.

# 2667

When Our clear verses are recited to them, you will recognize denial upon the faces of the unbelievers. They nearly rush upon those who recite Our verses to them. Say: 'Shall I tell you what is worse than that' The Fire which Allah has promised those who disbelieve an evil arrival'

# 2668

People, this is a parable, listen to it. Those whom you call upon, other than Allah, could never create a fly, though they banded together to do this. And if a fly robs them of anything, they could never rescue it from it. The seeker and the sought are alike in their weakness.

# 2669

They do not value Allah as He should be valued. For Allah is Powerful and Mighty.

# 2670

Allah chooses Messengers from angels and from people. Allah is the Hearer, the Seer.

# 2671

He knows what is before them and behind them. To Allah all things are returned.

# 2672

O you who believe, bow down and prostrate yourselves. Worship your Lord and do good, in order that you prosper.

# 2673

Struggle for Allah as is due to Him. He has chosen you and has not laden a burden upon you in your religion, being the Creed of Abraham your father. He has named you Muslims before and in this so that the Messenger (Muhammad) can be a witness for you, and in order that you be witnesses against mankind. Therefore, establish the prayer and pay the obligatory charity and hold fast to Allah. He is your Guardian, the Excellent Guardian, the Excellent Helper!

# 2674

Prosperous are the believers,

# 2675

who are humble in their prayers;

# 2676

who turn away from idle talk;

# 2677

who give charity,

# 2678

who guard their privates,

# 2679

except with their wives and what their right hand possess, and then they are not blamed.

# 2680

Those who seek beyond that are transgressors.

# 2681

(Prosperous are those) who preserve their trusts and pledges

# 2682

and those who observe their prayers.

# 2683

Those are the heirs

# 2684

who will inherit Paradise; they shall live there for ever.

# 2685

We created the human from an essence of clay:

# 2686

then We made him, a drop, in a secure receptacle (the womb).

# 2687

Then We created of the drop, a clot (of congealed blood) and We created the clot into bitesize tissue, then We created the bitesize tissue into bones, thenWe clothed the bones with flesh, and then produced it an other creation. Blessed is Allah, the Best of creators!

# 2688

After that you shall surely die,

# 2689

and be resurrected on the Day of Resurrection.

# 2690

We have created seven ways above you; of Our creation, We are never inattentive.

# 2691

We sent down water from the sky in due measure, and lodged it in the earth, and We are able to take it all away.

# 2692

With it, We produced for you gardens of palms and vines, yielding abundant fruit for you to eat.

# 2693

Also, a tree which grows on the Tor of Sinai and gives oil and relish for its eaters.

# 2694

In the cattle, too, is a lesson for you. We let you drink of that which is in their bellies, and there are many benefits in them for you, and you eat of them,

# 2695

and upon them and on the ships you are carried.

# 2696

We sent Noah to his nation. 'Worship Allah, my nation' he said, 'for you have no god except He. Will you not be cautious'

# 2697

The unbelieving assembly of his nation said: 'This is but a human like you, who desires to gain superiority over you. Had Allah willed, He could have sent down angels. We never heard of this among our ancient forefathers.

# 2698

He is nothing else except a man who is mad, so watch him for awhile.

# 2699

He (Noah) said: 'Lord, help me, for they belie me'

# 2700

We said to him: 'Make the Ark under Our Eye, and Our Revelation, and then when Our command comes and the oven gushes water, take onboard a pair from every kind and your family, except him against whom the decision has already been passed. Do not address Me concerning those who have done evil; they shall be drowned.

# 2701

And when you and all those with you are seated in the Ark, say: 'Praise be to Allah who has saved us from the harmdoing nation'

# 2702

And say: 'Lord, let me land a blessed landing. You are the Best of harborers'

# 2703

Surely, in that are signs, and surely We will put (nations) to the test.

# 2704

Then We produced after them another generation

# 2705

and We sent to them a Messenger from themselves, saying: 'Worship Allah, for you have no god except He. Will you not be cautious'

# 2706

The unbelieving assembly of his nation, who belied the encounter of the Everlasting Life, and on whom We had bestowed ease in this life, said: 'This is but a human like yourselves; he eats of what you eat and drinks of what you drink.

# 2707

If you obey a mortal like yourselves, you shall be lost.

# 2708

What, does he promise you that when you are dead and turned to dust and bones, you will be brought forth?

# 2709

After, after with that which you are promised!

# 2710

There is nothing but our present life; we die, and we live, and we shall not be resurrected.

# 2711

He is nothing but a man who has forged against Allah a lie, we will never believe him'

# 2712

He said: 'Help me, Lord, they belie me'

# 2713

He replied: 'Before long, by the morning, they shall be remorseful'

# 2714

And the Cry seized them in justice and We made them withered. So begone with the harmdoing nation.

# 2715

After them We produced other generations

# 2716

no nation outstrips its term, nor do they put it back.

# 2717

Then We sent Our Messengers in succession. Yet whenever its Messenger came to a nation they belied him, so We made them follow others, and We made them but as tales, so begone the nation who did not believe!

# 2718

Then We sent Moses and his brother Aaron with Our signs and clear authority

# 2719

to Pharaoh and his Council, but they were very proud, and they were a tyrannical nation.

# 2720

'What' they said, 'are we to believe in two mortals like us, whose nation are our worshipers'

# 2721

So they belied them, and they were among the destroyed.

# 2722

And We gave Moses the Book, in order that they might be guided.

# 2723

We made the son of Mary and his mother a sign, and gave them a refuge on a hillside where there was a hollow and a spring.

# 2724

Messengers! Eat of that which is good and do good deeds; I have knowledge of the things you do.

# 2725

Your nation is but one nation, and I am your Lord, therefore fear Me.

# 2726

Yet they have split their affairs between themselves into sects, each rejoicing in what it has.

# 2727

Leave them in their perplexity for a time.

# 2728

Do they think that in giving them wealth and children

# 2729

We hasten in good works for them? No, they are not aware.

# 2730

Those who tremble in fear of their Lord,

# 2731

who believe in the verses of their Lord;

# 2732

who associate none with their Lord,

# 2733

who give what they give, with their hearts quaking, that they will return to their Lord:

# 2734

those, hasten in good works, outracing to them.

# 2735

We charge no soul with more than it can bear. We have a Book with Us which speaks the truth, and they shall not be wronged.

# 2736

But their hearts are in ignorance of this (Koran); and they have deeds besides that which they are doing.

# 2737

But when We seize with the punishment those of them that live in ease, they groan.

# 2738

(We shall say): 'Do not groan today, surely you shall receive no help from Us'

# 2739

My verses were recited to you, but you turned upon your heels,

# 2740

being proud against it, talking foolishness by night.

# 2741

Should they not think upon the saying? Or, did anything come upon them that had not come upon their ancient forefathers?

# 2742

Or, is it because they do not recognize their Messenger that they denied him?

# 2743

Do they say he is mad! No, he came to them with the truth, but most of them hate the truth.

# 2744

Had the truth followed their fancies, the heavens, the earth, and all who live in them would have surely been corrupted. No, We brought them theirRemembrance; but from their Remembrance they turn away.

# 2745

Or, do you ask a tribute from them? Your Lord's tribute is better. He is the Best of providers.

# 2746

Indeed you are calling them to a Straight Path,

# 2747

but those who disbelieve in the Everlasting Life deviate from the Path.

# 2748

If We had mercy on them and removed their afflictions, they would still persist in their insolence, blindly wandering.

# 2749

Already We have seized them with the punishment, but they neither humbled themselves to their Lord, nor did they beseech Him,

# 2750

when We opened on them a gate of severe punishment, they utterly despaired.

# 2751

It was He who produced for you hearing, eyes, and hearts, yet little is that you thank.

# 2752

It was He who scattered you on the earth, and before Him you shall be gathered.

# 2753

It is He who revives and makes to die, and to Him belong the alternation of the night and the day. Will you not understand!

# 2754

No, but they said what the ancients said before them:

# 2755

'When we are dead and become dust and bones shall we be resurrected?

# 2756

We and our fathers have been promised this before. It is but of the ancients' fictitious tales'

# 2757

Say: "If you have knowledge, 'to whom belongs the earth' and, 'whoever is in it? '"

# 2758

They will say: 'To Allah' Say: 'Then will you not remember'

# 2759

Say: 'Who is the Lord of the seven heavens, and of the Great Throne'

# 2760

They will say: 'Allah' Say: 'Will you not be cautious'

# 2761

Say: 'In whose Hands is the Kingdom of all things, He protects, and none protects against Him, if you have knowledge'

# 2762

'Allah' they will reply. Say: 'How then can you be so bewitched'

# 2763

No, We have brought the truth to them, but they are liars.

# 2764

Allah has not taken to Himself any son, there is no other god with Him. Were this otherwise each god would have taken that which he created, and some ofthem would have risen above others; Exalted is Allah beyond that they describe!

# 2765

(He is) the Knower of the Unseen and the Seen, High Exalted be He above that they associate.

# 2766

Say: 'Lord, if You should show me that which they are promised,

# 2767

O my Lord, do not put me among the harmdoing people'

# 2768

Indeed, We are able to show you that which We promised them.

# 2769

Repel evil with that which is better. We know that which they describe.

# 2770

And say: 'O my Lord, I seek refuge in You from evil suggestions of the satans.

# 2771

O my Lord, I seek refuge in You lest they attend me'

# 2772

Until, when death comes to one of them he says: 'My Lord, let me go back,

# 2773

that I should do righteousness in that I forsook' No! It is only a word which he will speak. Behind them there shall stand a barrier till the Day that they shall be resurrected.

# 2774

And when the Horn is blown, on that Day their ties of kindred shall be no more, nor will they ask each other.

# 2775

Those whose scales are heavy shall prosper,

# 2776

but those whose scales are light shall forfeit their souls and live in Gehenna (Hell) for ever.

# 2777

The fire lashes their faces and therein are shriveled lips.

# 2778

(We shall say): 'Were My verses not recited to you, and did you not belie them'

# 2779

'Lord' they will reply, 'adversity prevailed over us and we were erring.

# 2780

Our Lord, bring us out of it. If we return (to sin), then we shall indeed be harmdoers'

# 2781

He will say: 'Slink there in it and do not speak to Me'

# 2782

Among My worshipers there were a party who said: "Lord, we believed. Forgive us and have mercy on us: You are the Best of the merciful."

# 2783

But you took them for laughingstock, mocking at them, until they caused you to forget My remembrance.

# 2784

Today I shall recompense them for their patience, for it is they that have won.

# 2785

And He will ask: 'How many years did you live on earth'

# 2786

They will reply: 'A day, or part of a day; ask those who have kept count'

# 2787

He will say: 'You have tarried a little, did you know?

# 2788

Did you think that We had created you only for play, and that you would never be returned to Us'

# 2789

High Exalted be Allah, the King, the Truth. There is no god except He, the Lord of the Noble Throne.

# 2790

Whosoever calls upon another god, other than Allah, having no proof his reckoning will be with his Lord. The unbelievers shall never prosper.

# 2791

And say: 'My Lord, forgive and have mercy, for You are the Best of the merciful'

# 2792

This is a chapter which We have sent down and appointed; and in it We have sent down clear verses in order that you will remember.

# 2793

You shall lash the fornicatress and the fornicator each with a hundred lashes. In the religion of Allah, let no tenderness for them seize you if you believe in Allah and the Last Day; and let their punishment be witnessed by a party of believers.

# 2794

The fornicator shall marry none but a fornicatress or an idolatress; and the fornicatress none shall marry her but a fornicator or an idolater; that is forbidden to the believers.

# 2795

Those who accuse chaste women, and cannot produce four witnesses, you shall lash them with eighty lashes. And never accept their testimony, for they are evildoers,

# 2796

except those among them that afterwards repent and mend their ways. Allah is Forgiving, Merciful.

# 2797

And those who accuse their wives and have no witnesses except themselves, let them testify by swearing by Allah four times that he is of the truthful,

# 2798

and the fifth time, that the curse of Allah shall be upon him, if he should be of the liars.

# 2799

But the punishment will be averted from her if she swears four times that he is of the liars,

# 2800

and on the fifth time the Wrath of Allah shall be upon her if he is of the truthful.

# 2801

If it were not for the bounty of Allah to you and His Mercy, and that Allah turns, and is the Wise,

# 2802

those who came with the slander were a number of you. Do not regard it evil for you, rather it is good for you. Every person of them shall have the sin that he has earned charged to him. As for he who took upon himself the greater part there is a mightier punishment.

# 2803

Had you heard it, and the believing men and women, thought good thoughts about one another said: 'This is a clear falsehood'

# 2804

Why, did they not bring four witnesses against it? But since they did not bring the witnesses, before Allah they are the liars.

# 2805

But for the bounty of Allah and His Mercy towards you in this life and in the Everlasting Life you would have been sternly punished for that which you were involved.

# 2806

You carried with your tongues and uttered with your mouths what you did not know. You have thought it a trifle, but before Allah it was a mighty thing.

# 2807

When you heard it, why did you not say: 'It is not right for us to speak of this. Exaltations to You! This is a mighty slander'

# 2808

Allah exhorts you never again to repeat the like, if you are believers.

# 2809

Allah makes plain to you His verses, and Allah is the Knower, the Wise.

# 2810

Those who love that indecency should be broadcast about those who believe theirs is a painful punishment in this world and in the Everlasting Life. Allah knows, and you do not know.

# 2811

If it was not for the bounty of Allah to you and His Mercy, and Allah is the Gentle, the Most Merciful.

# 2812

Believers, do not follow in the steps of satan, for those who follow the steps of satan, he bids to indecency and dishonor. But for the bounty of Allah to you, and His Mercy no one of you would ever have been purified; but Allah purifies whom He will; Allah is the Hearer, the Knower.

# 2813

Do not let those of you who possess bounty and plenty swear not to give kinsmen, and the poor, and those who emigrate in the way of Allah. Let them pardon and forgive. Do you not yearn that Allah forgives you? And Allah is the Forgiver, the Most Merciful.

# 2814

Surely, those who defame chaste, unsuspecting, believing women, shall be cursed in this world and in the Everlasting Life, and for them there is a mightypunishment.

# 2815

On the Day when their tongues, hands and feet shall testify against them concerning what they were doing.

# 2816

Upon that Day Allah will pay them their due in full, and they will know that Allah is the clear truth.

# 2817

Evil women for evil men, and evil men for evil women; good women for good men, and good men for good women these are clear of what has been said; for them is forgiveness, and a generous provision.

# 2818

Believers, do not enter houses other than your houses until you first ask permission and greet with peace the people thereof; that is better for you in order that you remember.

# 2819

And if you do not find anyone there, do not enter it until permission is given to you. And if you are told 'Return', so return, that is purer for you; and Allah knows the things you do.

# 2820

There is no fault in you that you enter uninhabited houses wherein there is benefit for you. Allah knows what you reveal and what you hide.

# 2821

Say to the believers they should lower their gaze and guard their private parts that is purer for them. Allah is Aware of the things they do.

# 2822

And say to the believing women, that they lower their gaze cast down their eyes and guard their chastity, and do not reveal their adornment except that which is outward (face and hands); and let them draw their veils over their neck, and not reveal their adornment except to their husbands, or their fathers, or their husbands' fathers, or their sons, or their husbands' sons, or their brothers, or their brothers' sons, or their sisters' sons, or their women, or what their right hands own, or such male attendants having no sexual desire, or children who have not yet attained knowledge of women's private parts; nor let them stamp their feet, so that their hidden ornament is known. And, O believers turn to Allah all together, in order that you prosper.

# 2823

Marry those among you who are spouseless and the virtuous among your male and female slaves (thereby freeing them), if they are poor, Allah will enrichthem of His bounty; Allah is Embracing, Knowing.

# 2824

Let those who do not find the means to marry be abstinent until Allah enriches them of His bounty. Those your right hand owns who seek their freedom, make a contract with them accordingly if you know some good in them, and give them from the wealth of Allah that He has given you. Do not force your slavegirls into prostitution in order to seek worldly gain for they wish to preserve their chastity. Whosoever compels them, surely Allah, after their being compelled, is the Forgiver (to the girls), the Most Merciful.

# 2825

Now We have sent down to you clarifying verses, and an example of those who passed away before you and admonition to the cautious.

# 2826

Allah is the Lighter of the heavens and the earth. The example of His Light is like a tube, in which there is a wick. The wick is in a lamp and the lamp is as a glittering planet kindled from a Blessed Tree, an olive that is neither of the East nor of the West. Its oil would almost shine forth though no fire touched it. Light upon light; Allah guides to His Light whom He will. Allah strikes parables for people. Allah has knowledge of all things.

# 2827

In houses which Allah has allowed to be raised up, and His Name to be remembered therein. In the morning and evening

# 2828

are men who exalt Him there, whom neither trade nor sale can divert from the remembrance of Allah, and establish the prayers, and pay the obligatorycharity; fearing a Day when hearts and eyes shall be turned about,

# 2829

that Allah will recompense them for the finest deeds they did and increase them from His bounty. Allah provides without measure to whom He will.

# 2830

As for the unbelievers, their works are like a mirage in the wilderness. The thirsty person thinks it is water, but when he comes near he finds that it is nothing. He finds Allah there, who pays him his account in full. Allah is Swift in reckoning.

# 2831

Or, they are like darkness upon a deep sea covered with a wave above which is another wave, above which are clouds, darkness piled one upon the other; when he stretches out his hand he can scarcely see it. Indeed, to whomsoever Allah assigns no light, he shall have no light.

# 2832

Have you not seen how Allah is exalted by those in the heavens and earth, and the birds with outspread wings? He knows its prayers and its exaltations and Allah has knowledge of the things they do.

# 2833

To Allah belongs the Kingdom of the heavens and the earth. To Him is the arrival.

# 2834

Have you not seen how Allah drives the clouds, then gathers them and converts them into a mass, then you see rain coming from the midst of them? And He sends down out of heaven mountains in which there is hail, pelting with it whom He will, and turning it away from whom He will. The flash of its lightning almost snatches away the sight.

# 2835

Allah turns about the night and the day (to succeed one another); surely, in this there is a lesson for those who have eyes.

# 2836

Allah created everything that walks from water. Some creep upon their bellies, others walk on two feet, and others walk on four. Allah creates whatever He will. Allah is Powerful over everything.

# 2837

We have sent down clarifying verses. Allah guides whom He will to a Straight Path.

# 2838

They say: 'We believe in Allah and the Messenger and obey' But a party of them turn away after this. Those are not believers.

# 2839

And when they are called to Allah and His Messenger so that he judges between them, a party of them swerve away.

# 2840

If the right is theirs, they would have hastened to him obediently.

# 2841

Is there a sickness in their hearts, or, are they in doubt? Do they fear that Allah and His Messenger will be unjust? No, but those they are the harmdoers.

# 2842

But when the believers are called to Allah and His Messenger, in order that he judges between them, their reply is: 'We hear and obey' Such are theprosperous.

# 2843

Those who obey Allah and His Messenger, and fear Allah, and have awe of Him, shall be the winners.

# 2844

They swear by Allah in the most earnest oaths, that if you order them, they would go forth. Say: 'Do not swear, known obedience (is better). Allah is Aware of the things you do'

# 2845

Say: 'Obey Allah and obey the Messenger. If you turn away, upon him only rests what is laid upon him, and upon you rests what is laid on you. If you obey him, you shall be guided. It is only for the Messenger to deliver a clear message'

# 2846

Allah has promised those of you who believe and do good works that He will indeed make them successors in the land as He made those who were before them successors, and that He will indeed establish their religion for them; that which He has approved for them, and will exchange safety for them after their fear. They worship Me and associate nothing with Me. After that, those who disbelieve are the impious.

# 2847

Establish the prayers, pay the charity, and obey the Messenger, in order to have mercy.

# 2848

Never think that the unbelievers will be able to frustrate (Us) in the earth. Their refuge is the Fire, an evil arrival.

# 2849

Believers, let those your right hand owns and those who have not come of age ask permission of you three times before the dawn prayer, when you put aside your garments, in the heat of noon, and after the night prayer. These are the three occasions of privacy. There is no fault in you or them, apart from these, that they go about you, you are of each other. As such Allah makes plain to you His verses, Allah is the Knower, the Wise.

# 2850

And when children reach the age of puberty, let them ask permission as those before them asked permission. As such Allah makes clear to you His verses. Allah is the Knower, the Wise.

# 2851

(As for) women that are past childbearing who have no hope of marriage there is no fault in them that they discard their cloaks provided they do not reveal their adornments, but it is better if they abstain. Allah is the Hearer, the Knower.

# 2852

It shall be no fault for the blind, the lame, the sick and yourselves to eat from your houses. Nor the houses of your fathers', your mothers', your brothers', your sisters', your paternal uncles, your paternal aunts, your maternal uncles, your maternal aunts or in houses the keys of which you own, or in those of your friend, there is no fault in you that you all eat together, or separately. When you enter houses, greet (with peace) one another with a salutation from Allah, blessed and good. As such Allah makes clear to you His verses so that you understand.

# 2853

The believers are only those who believe in Allah and His Messenger, and who, when gathered with him upon a common matter do not depart till they have asked his permission. Surely, those who ask your permission are those who believe in Allah and His Messenger. When they ask your permission for some of their affairs, grant it to whomever you please and ask Allah for forgiveness for them; Allah is the Forgiver, the Merciful.

# 2854

Do not make the calling of the Messenger among yourselves like your calling to one another. Allah knows those of you who slip away surreptitiously, so let those who disobey His command beware, lest they are struck by sedition, or, they are stricken with a painful punishment.

# 2855

To Allah belongs all that is in the heavens and the earth. He has Knowledge of what state you are upon. On the Day when they shall be returned to Him, He will tell them all what they have done. And Allah has knowledge of everything.

# 2856

Blessed is He who has sent down the Criterion to His worshiper (Prophet Muhammad), that he is a warner to all mankind;

# 2857

to whom the Kingdom of the heavens and the earth belongs, who has not taken a son, nor does He have an associate in the Kingdom, and He created everything, then He ordained it very precisely.

# 2858

Yet they worship, other than Him, gods which cannot create anything and were themselves created. They own neither harm nor benefit for themselves, neither do they own death nor life, nor a resurrection.

# 2859

The unbelievers say: 'This is but a falsehood he has forged? another nation has helped him' So they have come with wrong and falsehood.

# 2860

They say: 'He has written tales of the ancients, they are recited to him at dawn and at the evening'

# 2861

Say: 'It was sent down by Him who knows the secrets of heavens and earth. He is Forgiving, the Most Merciful.

# 2862

They also say: 'How is it that this Messenger eats food and walks about the markets? Why has no angel been sent down with him to warn us?

# 2863

Or, why has no treasure been thrown to him, or a garden for him to eat from' And the harmdoers say: 'The man you follow is surely bewitched'

# 2864

See how they strike examples for you, surely they have gone astray and are unable to find a way.

# 2865

Blessed be He who, if He wills, can assign you better things than these; gardens underneath which rivers flow, and He shall assign for you palaces.

# 2866

No, they belied the Hour. We have prepared for him who belied the Hour a Blaze.

# 2867

When it sees them from a far off place, they shall hear it raging and sighing.

# 2868

And when, chained in (iron) fetters, they are cast into some narrow space of the Fire, they will call out for destruction.

# 2869

'Do not call out today for one destruction; call out for many destructions'

# 2870

Say: 'Is that better, or the Garden of Eternity which the cautious have been promised? It is their recompense and their arrival'

# 2871

Living there for ever, they shall find in it all that they desire. That is a promise binding upon your Lord, and to be asked of Him.

# 2872

On the Day when He gathers them with all that they worship, other than Allah, He will say: 'Was it you who misled My worshipers, or did they themselves go astray'

# 2873

They will answer: 'Exaltations to You. We should not have taken others for a guardian, but You gave them and their fathers enjoyment until they forgot Your Remembrance and they were a destroyed nation'

# 2874

So they belie what you say, and you can neither turn it aside, nor find any help. Those of you who have done evil, We let them taste a great punishment.

# 2875

We did not send Messengers before you but that they ate food and walked about in the markets, We have appointed some of you to be a trial for others. Will you endure? Your Lord is the Seer.

# 2876

Those who do not hope to meet Us ask: 'Why have no angels been sent to us? Why can we not see our Lord' How proud they are within themselves, and have become greatly disdainful.

# 2877

On the Day when they behold the angels, there will be no glad tidings for the sinners. They will say: 'A refuge which is forbidden'

# 2878

Then We shall advance upon the work which they have done and render it as scattered dust.

# 2879

On that Day, the companions of Paradise (will have) a better abode and a finer restingplace.

# 2880

On that Day, the heaven is split asunder with clouds and the angels are sent down in majesty,

# 2881

the true Kingdom on that Day shall belong to the Merciful a harsh day for the unbelievers.

# 2882

Upon that Day the harmdoer shall bite his hands, and say: 'Would that I had taken a Path with the Messenger!

# 2883

Would that I had never chosen soandso for my companion!

# 2884

He led me astray from the Remembrance after it had reached me, satan is ever the foresaker of humans'

# 2885

The Messenger says: 'O my Lord, my people have taken this Koran while deserting it'

# 2886

To every Prophet We have appointed an enemy among the harmdoers; your Lord is Sufficient for you, a Guide and a Helper.

# 2887

The unbelievers ask: 'Why was the Koran not sent down to him all at once' As such We strengthen your heart thereby, and We have recited it very distinctly.

# 2888

They do not bring to you any parable but that which We bring to you is the truth and better in explanation.

# 2889

Those who will be gathered into Gehenna (Hell) upon their faces shall be in the worst in place, and have gone further astray from the Path.

# 2890

We gave the Book to Moses and gave him his brother Aaron as a minister.

# 2891

(Then) We said: 'Go to the nation who have belied Our signs' And We utterly destroyed them.

# 2892

The nation of Noah, We drowned them when they belied their Messenger, and made of them a sign to the nation. For the harmdoers We have prepared a painful punishment

# 2893

also to Aad and Thamood and the nation of ErRass and many generations in between;

# 2894

to each of them We gave examples, and each of them We utterly ruined.

# 2895

They have surely passed by the village which was rained upon by evil rain (of stones); what, have they never seen it? No, they look for no resurrection.

# 2896

Whenever they see you, they mock you (saying): 'Is this whom Allah has sent as a Messenger?

# 2897

He would have mislead us from our gods, if we had not been steadfast to them' But they shall know who is further astray from the Path when they see the punishment.

# 2898

Have you seen him who has made gods of his own desires? Would you be a guardian over him?

# 2899

Do you think that most of them can hear or understand? They are like cattle, no, they are further astray from the Path.

# 2900

Do you not see how your Lord stretches the shadow? Had it been His will, He could have made it constant. Then He appointed the sun to be a guide to it;

# 2901

thereafter We seize it to Us withdrawing it gently.

# 2902

It is He who has appointed the night a mantle for you and sleep for a rest. The day He has appointed for rising.

# 2903

It is He who loosens the winds, bearing glad tidings before the Hands of His Mercy, and We have sent down pure water from the heaven,

# 2904

so, that with it We revive dead lands and provide drink for the cattle and the human We created.

# 2905

We have indeed turned it about them, so that they remember; yet most people refuse all except disbelief.

# 2906

Had it been Our will, We could have raised a warner in every village.

# 2907

So do not obey the unbelievers, but struggle mightily with it (the Koran).

# 2908

It was He who let forth the two seas, this one is palatably sweet and this salt, a bitter taste, and He set a barrier between them, and a refuge which is forbidden.

# 2909

And it is He who created the human from water and gave him kindred of blood and of marriage. Your Lord is the Powerful.

# 2910

Yet they (the unbelievers) worship, other than Allah, that which can neither benefit nor harm them. Surely, the unbeliever is ever a partisan against his Lord.

# 2911

We did not send you but as a bearer of glad tidings and as a warner.

# 2912

Say: 'I demand of you no wage for this except for he who wishes to take the Path to his Lord'

# 2913

Put your trust in the All Living who never dies, and exalt with His praise, He is sufficiently aware of His worshipers' sins.

# 2914

(It is) He who, in six days created the heavens and the earth and all that lies between them, and then He willed to the Throne. The Merciful; ask about Him from he who knows Him.

# 2915

When it is said to them: 'Prostrate yourselves before the Merciful', they ask: 'And what is the Merciful? Shall we prostrate ourselves to whatever you bid us' And it increases their aversion.

# 2916

Blessed be He who has set the constellations in the heaven, and set amongst them a sun, and an illuminating moon.

# 2917

It is He who has made the night and day follow each other for those whom He desires to remember or He desires to be thankful.

# 2918

The worshipers of the Merciful are those who walk humbly on the earth, and when the ignorant address them say: 'Peace'

# 2919

who pass the night prostrating and standing to their Lord.

# 2920

Who say: 'Our Lord, turn from us the punishment of Gehenna, for its punishment is the most terrible;

# 2921

it is an evil settling, and an evil residence'

# 2922

who when they spend are neither wasteful nor miserly, between that is a just stand,

# 2923

who do not call upon another god with Allah, nor slay the soul which Allah has forbidden except by right; who do not fornicate, for he who does this shall face punishment

# 2924

doubled for him on the Day of Resurrection is his punishment, and therein he shall live, humbled,

# 2925

except he who repents and believes and does good works those, Allah will change their evil deeds into good deeds; Allah is ever Forgiving and Merciful.

# 2926

He who repents and does good works truly turns to Allah in repentance,

# 2927

and those who do not bear false witness, and when they pass by idle talk, pass by with honor

# 2928

and who when they are reminded of the verses of their Lord, they do not fall down deaf and blind.

# 2929

Those who say: 'Lord give us of our wives and children what pleases our eyes and make us leaders to the fearful'

# 2930

Those shall be recompensed with the highest rank for their patience. There they shall receive a greeting, and peace!

# 2931

There they shall live for ever; a fine dwelling place, and residence.

# 2932

Say: 'My Lord cares little for you if it was not for your supplication, indeed you have belied (the Messenger and the Koran) so it (the punishment) will be fastened'

# 2933

TaSeenMeem.

# 2934

Those are the verses of the clear Book.

# 2935

Perhaps you consume yourself that they are not believers.

# 2936

If We will, We can send down on them a sign from heaven before which their necks will remain humbled.

# 2937

A fresh remembrance has never come to them from the Merciful, except they turn away from it.

# 2938

So, they belied, but surely the tidings of that they mocked will come to them.

# 2939

Have they not seen the earth, how many We caused to grow in it every generous kind?

# 2940

Surely, in this there is a sign yet most of them do not believe.

# 2941

Your Lord, He is the Almighty, the Most Merciful.

# 2942

And when your Lord called to Moses, saying: 'Go to the harmdoing nation,

# 2943

the nation of Pharaoh. Will they not fear Me'

# 2944

'My Lord' he replied, 'I fear they will belie me

# 2945

and my chest will become constricted and my tongue will not be loosed (in my speech), therefore, send to Aaron.

# 2946

They hold a sin against me, and I fear that they will kill me'

# 2947

He said: 'Never so, go both of you with Our signs; We shall be with you, listening

# 2948

go both to Pharaoh and both of you say to him: 'We are (each) a Messenger from the Lord of all the Worlds.

# 2949

Send forth with us the Children of Israel'

# 2950

He (Pharaoh) said (to Moses): 'Did We not bring you up when you were a child? And have you not spent years of your life amongst us?

# 2951

Yet you were ungrateful and have done the deed you did'

# 2952

He (Moses) replied: 'Indeed, I did that when I was among those who stray.

# 2953

I fled from you because I feared you. But my Lord has given me judgment and made me one of the Messengers.

# 2954

Is this then the blessing with which you reproach me, that you have the Children of Israel for worshipers'

# 2955

Pharaoh said: 'And what is the Lord of the Worlds'

# 2956

'He' (Moses) replied: 'is the Lord of the heavens and the earth and all that is between them, if you believe'

# 2957

'Do you not hear' said he (Pharaoh) to those around him.

# 2958

He said, 'Your Lord and the Lord of your fathers, the ancients'

# 2959

(Pharaoh) said: 'Surely, the Messenger who has been sent to you is mad!'

# 2960

'He is the Lord of the East and the West' said he (Moses), 'and all that is between them, if you could understand'

# 2961

'If you take any other god except myself' he (Pharaoh) replied, 'you shall be thrown into prison'

# 2962

'What, even if I brought you something clear' said he (Moses).

# 2963

He (Pharaoh) replied: 'Show us your sign, if you are of the truthful'

# 2964

He cast down his staff and thereupon it was a clear serpent.

# 2965

Then he drew out his hand, and it was luminous to the onlookers.

# 2966

'This', said he (Pharaoh) to his Council, 'is a cunning sorcerer

# 2967

who seeks to expel you from your land by his sorcery. What is your counsel'

# 2968

They replied: 'Put him and his brother off for a while, and send heralds to your cities

# 2969

to bring every knowledgeable sorcerer'

# 2970

The sorcerers were gathered at the appointed time on a wellknown day,

# 2971

and the people were asked: 'Will you gather

# 2972

in order that we shall follow the sorcerers if they are the victors'

# 2973

Then, when the sorcerers came to Pharaoh, they said: 'Shall we receive a wage if we win'

# 2974

'Yes, indeed' he answered, 'and you shall become among those who are near stationed'

# 2975

Moses said to them: 'Cast down what you cast'

# 2976

So they cast their ropes and staffs, saying: 'By Pharaoh's might, we shall be the victors'

# 2977

Then Moses cast down his staff and it swallowed up their lying invention,

# 2978

so the sorcerers were cast down, prostrating themselves,

# 2979

saying: 'We believe in the Lord of the Worlds,

# 2980

the Lord of Moses and Aaron'

# 2981

He (Pharaoh) said: 'You have believed him before I have given you permission. He is the chief of you who has taught you sorcery. But you shall know. I will surely cut off on opposite sides a hand and a foot, and crucify you all.'

# 2982

'There is no harm' they replied, 'for surely to our Lord we are turning.

# 2983

We are eager that Our Lord should forgive us our offenses, for we are the first of the believers'

# 2984

Also, We revealed to Moses, saying: 'Go with My worshipers by night, for you will be followed'

# 2985

Then Pharaoh sent gatherers to the cities.

# 2986

'These' they said, 'are a small band,

# 2987

they have enraged us,

# 2988

and we are a host on our guard'

# 2989

As such We expelled them from their gardens and their fountains,

# 2990

their treasures and a noble station.

# 2991

As such we gave it to the Children of Israel.

# 2992

At sunrise, they followed them.

# 2993

And when the two hosts came in view of each other, Moses' companions said: 'We have been reached'

# 2994

'No, indeed' he replied, 'my Lord is with me and He will guide me'

# 2995

Then We revealed to Moses: 'Strike the sea with your staff', so it divided and each part was as a mighty mount.

# 2996

And there We brought the others on,

# 2997

and We saved Moses and those who were with him together,

# 2998

then, We drowned the others.

# 2999

Surely, in that there is a sign; yet most of them do not believe.

# 3000

Surely, your Lord is the Almighty, the Most Merciful.

# 3001

And recite to them the news of Abraham.

# 3002

He said to his father and to his nation: 'What do you worship'

# 3003

They replied: 'We worship idols and continue cleaving to them'

# 3004

'Do they hear you when you call on them' He asked.

# 3005

'Can they benefit you or harm you'

# 3006

They replied: 'No, but we found our fathers doing so'

# 3007

He said: 'Have you considered what you worship,

# 3008

you, and your elderly fathers?

# 3009

They are enemies to me except the Lord of all the Worlds

# 3010

who created me; and He guides me,

# 3011

and He gives me to eat and drink,

# 3012

who, when I am sick, heals me;

# 3013

who makes me to die and then revives me,

# 3014

and whom I am eager shall forgive me my sins on the Day of Recompense'

# 3015

My Lord, give me judgment, and join me with the righteous.

# 3016

And appoint me a tongue of truthfulness among the latter.

# 3017

and place me amongst the inheritors of the Garden of Bliss.

# 3018

and forgive my father, for he was among the astray.

# 3019

Do not degrade me on the Day when they are resurrected.

# 3020

The Day when neither wealth nor sons shall benefit

# 3021

except him who comes before Allah with a pure heart;

# 3022

and Paradise shall be brought forward to the cautious.

# 3023

And Hell is brought near to the perverse'

# 3024

It will be said to them: 'Where is that you worshipped,

# 3025

other than Allah? Do they help you or even help themselves'

# 3026

And they will be pitched into it, they and the perverse

# 3027

and the hosts of iblis all together.

# 3028

And they will say while they dispute with one another,

# 3029

'By Allah, we were certainly in clear error,

# 3030

when we made you equal with the Lord of the Worlds.

# 3031

It was nothing but the evildoers who led us astray.

# 3032

We have no intercessors now,

# 3033

no caring friend.

# 3034

Would that we might return again, and be among the believers'

# 3035

Surely, in that there is a sign, yet most of them do not believe.

# 3036

Surely, Your Lord is the Almighty, the Most Merciful.

# 3037

The nation of Noah, belied their Messengers.

# 3038

when Noah, their brother, said to them: 'Will you not be cautious?

# 3039

I am for you an honest Messenger,

# 3040

so fear Allah, and obey me.

# 3041

For this I ask of you no wage, for my wage falls only on the Lord of the Worlds.

# 3042

So fear Allah and obey me'

# 3043

They replied: 'Are we to believe you whom the lowliest follow'

# 3044

He said: 'I have no knowledge of what they have done.

# 3045

Their account falls only upon My Lord, if you were but aware.

# 3046

I will not drive away the believers.

# 3047

I am only a clear warner'

# 3048

'Noah' they replied, 'if you do not desist you shall be of those stoned'

# 3049

He said: 'My Lord, my nation have belied me.

# 3050

So open between me and them an opening, and save me and the believers who are with me'

# 3051

We saved him and those who were with him in the laden ship,

# 3052

afterwards, We drowned the rest.

# 3053

Surely, in that there is a sign; yet most of them do not believe.

# 3054

Your Lord is the Almighty, the Most Merciful.

# 3055

(The nation of) Aad belied their Messengers.

# 3056

When their brother Hood said to them: 'Will you not be cautious?

# 3057

I am for you an honest Messenger.

# 3058

Fear Allah and obey me.

# 3059

For this I ask of you no wage, for my wage falls only on the Lord of the Worlds.

# 3060

Do you build over each high place a sign to amuse yourselves!

# 3061

And do you take to yourselves underground reservoirs, in order to live for ever!

# 3062

When you assault, you assault like tyrants.

# 3063

So fear Allah, and obey me.

# 3064

Fear Him who has given you all the things you know.

# 3065

He has given you flocks and sons,

# 3066

gardens and fountains.

# 3067

Indeed, I fear for you the punishment of a dreadful Day'

# 3068

They replied: 'It is the same to us whether you admonish or whether you are not one of the admonishers.

# 3069

That is nothing but a habit of the ancients,

# 3070

and we shall never be punished'

# 3071

So they belied him, so We destroyed them. Surely, in that there is a sign; yet most of them do not believe.

# 3072

Surely, your Lord is the Almighty, the Most Merciful.

# 3073

Thamood, belied their Messengers.

# 3074

Their brother Salih said to them: 'Will you not be cautious?

# 3075

I am for you an honest Messenger.

# 3076

So fear Allah, and obey me.

# 3077

For this I ask of you no wage; my wage falls only upon the Lord of the Worlds.

# 3078

Will you be left secure in this,

# 3079

amidst gardens and fountains,

# 3080

sown fields and palmtrees, with slender spathes.

# 3081

Will you still hew your dwellings in the mountains?

# 3082

So fear Allah and obey me.

# 3083

Do not obey the order of the wasteful,

# 3084

who corrupt in the earth, and do not reform'

# 3085

They replied: 'Surely, you are one of those bewitched.

# 3086

You are but a human like ourselves. Produce for us a sign, if you are of the truthful'

# 3087

He said: 'Here is a shecamel. She shall have her share of water as you have yours on an appointed day.

# 3088

Do not touch her with malice so that punishment of a dreadful day seizes you'

# 3089

Yet they hamstrung her, and in the morning they were remorseful,

# 3090

and the punishment seized them. Surely, in that there is a sign. Yet most of them do not believe.

# 3091

Your Lord, He is the Almighty, the Most Merciful.

# 3092

Lot's nation, belied their Messengers.

# 3093

When their brother Lot said to them: 'Will you not be cautious?

# 3094

I am for you an honest Messenger.

# 3095

So fear Allah, and obey me.

# 3096

I ask of you no wage for this; my wage is only with the Lord of the Worlds.

# 3097

What, do you come to the males of the world,

# 3098

and leave your wives whom your Lord has created for you? No, but you are a transgressing nation'

# 3099

'Lot' they replied, 'if you do not desist, you shall be thrown out'

# 3100

He said: 'Truly, I am a detester of what you do'

# 3101

'My Lord, save me and my people from that they are doing'

# 3102

So We saved him and all his people,

# 3103

except an old woman who stayed behind,

# 3104

then We destroyed the others.

# 3105

We rained upon them a rain, and evil is the rain (of stones) on those that are warned.

# 3106

Surely, in that there is a sign. Yet most of them do not believe.

# 3107

Your Lord, He is the Almighty, the Most Merciful.

# 3108

The dwellers of the Thicket belied their Messengers.

# 3109

Shu'aib said to them: 'Will you not be cautious?

# 3110

I am for you an honest Messenger.

# 3111

So fear Allah, and obey me.

# 3112

I ask of you no wage for this; my wage is only with the Lord of the Worlds.

# 3113

Fill up the measure, do not be among the cheats,

# 3114

and weigh with the straight scale,

# 3115

and do not diminish the goods of the people, and do not make mischief in the earth, working corruption.

# 3116

Fear He who created you, and the generations of the ancient'

# 3117

They replied: 'You are surely one of those bewitched.

# 3118

You are but a human like ourselves, we think that you are one of the liars.

# 3119

Drop down on us lumps from heaven, if you are one of the truthful'

# 3120

He said: 'My Lord knows what you are doing'

# 3121

But they belied him, then the punishment of the Day of Shadow (raining fire) seized them. Truly, it was the punishment of a dreadful day.

# 3122

Surely, in that there is a sign; yet most of them do not believe.

# 3123

Your Lord, He is the Almighty, the Most Merciful.

# 3124

Truly, it is the sending of the Lord of the Worlds.

# 3125

The honest Spirit (Gabriel) brought it down

# 3126

upon your heart (Prophet Muhammad), in order to be one of the warners,

# 3127

in a clear, Arabic tongue.

# 3128

Truly, it is in the Books of the ancients.

# 3129

Was it not a sign for them known to the learned of the Children of Israel?

# 3130

If We had revealed it to a nonArab,

# 3131

and he had recited it to them, they would not have believed.

# 3132

Even so, We have caused it to enter into the hearts of harmdoers:

# 3133

they shall not believe in it until they see the painful punishment

# 3134

so that it will come upon them suddenly, while they are unaware,

# 3135

and then they will say: 'Shall we be respited'

# 3136

Do they wish to hasten Our punishment?

# 3137

What do you see? If We gave them enjoyment for years,

# 3138

and then what they were promised comes to them,

# 3139

what avail will their past enjoyments be to them?

# 3140

We never destroyed a village that did not have warners

# 3141

for a reminder, and We never harmed.

# 3142

It was not the satans who brought it down:

# 3143

it is not for them, nor are they able.

# 3144

Truly, they are expelled from hearing.

# 3145

So do not call upon another god with Allah, lest you should be one of those who are punished.

# 3146

Warn your tribe and your near kinsmen.

# 3147

and lower your wing to the believers who follow you.

# 3148

If they disobey you, say: 'I am quit of what you do'

# 3149

Put your trust in the Almighty, the Most Merciful,

# 3150

who sees you when you stand

# 3151

and when you turn among those who prostrate themselves.

# 3152

Surely, He is the Hearer, the Knower.

# 3153

Shall I tell you on whom the satans descend?

# 3154

They descend on every guilty impostor.

# 3155

They listen, but most of them are liars.

# 3156

Poets are followed by the perverse.

# 3157

Have you not seen how they wander in every valley,

# 3158

and they say what they do not do?

# 3159

Except those who believe, and do good works and remember Allah in abundance and became victorious after they had been wronged. The wrongdoers will surely know which turn they will be returning to (Hell).

# 3160

TaSeen. Those are the verses of the Koran, a clear Book,

# 3161

a guidance and glad tidings to believers,

# 3162

who establish their prayers, and pay the obligatory charity, and are certain of the Everlasting Life.

# 3163

As for those who do not believe in the Everlasting Life, We have decorated for them their works, and they wander blindly.

# 3164

Such are those for whom there is an evil punishment, and in the Everlasting Life are the greatest losers.

# 3165

You have received the Koran from the Wise, the Knower.

# 3166

When Moses said to his household: 'Indeed, I can see a fire far away. I will go and bring you news of it or I will bring you a lighted flame so that you can warm yourselves'

# 3167

And when he came near it he was called: 'Blessed be who is (Moses) in the fire and (the angels) who are around it! Exaltations to Allah, Lord of the Worlds!

# 3168

Moses, it is I, Allah, the Almighty, the Wise.

# 3169

Cast down your staff' And when he saw it writhing like a serpent, he turned about retreating, and did not turn back. 'Moses, do not fear, indeed theMessengers do not fear (when they are) with Me,

# 3170

except he who has done evil, then, after evil, has changed into good. I am the Forgiving, Most Merciful.

# 3171

Put your hand inside your collar and it will come out luminous without evil? among the nine signs to Pharaoh and his nation, indeed they were an impious nation'

# 3172

But when Our signs came to them visibly, they said: 'This is plain sorcery.'

# 3173

They denied them unjustly out of pride, though their souls acknowledged them. See, how was the end of the corrupt workers!

# 3174

We gave knowledge to David and Solomon. They said: 'Praise be to Allah who has preferred us above many of His believing worshipers'

# 3175

Solomon inherited David. He said: 'Know, my people, we have been taught the speech of birds and given everything. Surely, this is a clear bounty'

# 3176

We gathered to Solomon his army of jinn, humans and birds; gathered and dispersed,

# 3177

and when they came to the Valley of the Ants, an ant said: 'Ants, go into your dwellings lest Solomon and his army should, unknowingly, crush you'

# 3178

He smiled, and laughed at its words, and said: 'My Lord, inspire me that I should be thankful for Your blessing with which You have blessed me and my parents, and that I may do good works that will please You. Admit me, by Your Mercy, among Your righteous worshipers'

# 3179

He reviewed the birds and said: 'Why is it that I do not see the hoopoe here? Or is he among the absent?

# 3180

Surely, I will punish him with a terrible punishment, or I will slaughter him or he gives me a good reason'

# 3181

He was not long in coming, and said: 'I know what you do not know. I come to you from Sheba with certain news.

# 3182

There I found a woman ruling over them. She possess everything and has a great throne.

# 3183

But she and her people prostrate to the sun instead of Allah. And satan has made their deeds seem pleasing to them and barred them from the Path, and therefore they are not guided.

# 3184

Do they not prostrate themselves to Allah who brings forth all that is concealed in the heavens and earth and He knows what they hide and what they reveal?

# 3185

Allah, there is no god except He, the Lord of the Mighty Throne'

# 3186

He replied: 'We shall see if what you have said is true or whether you are among those who lie.

# 3187

Take my letter, and drop it to them. Then turn aside and see what they shall return'

# 3188

She (the Queen of Sheba) said: 'O Council, look, an honorable letter has been dropped to me.

# 3189

It is from Solomon and it is "In the Name of Allah, the Merciful, the Most Merciful.

# 3190

Do not rise up against me, but come to me in surrender (Muslims)."

# 3191

She said: 'O Council, let me hear your counsel, concerning my affairs, for I am not used to deciding an affair until you bear me witness'

# 3192

They replied: 'We are possessors of force and great might. It is for you to command, so consider what you will'

# 3193

She said: 'When kings enter a village, they ruin it and humiliate its nobles. And this they will do.

# 3194

But I shall send them a gift and see what the messengers bring back'

# 3195

But when he came to Solomon, he said: 'Is it wealth that you would give me, when Allah has given me that which is better than He has given to you? No, but instead you rejoice in your gift!

# 3196

Go back then, we shall surely come against them with soldiers of which they have no power to oppose, and we shall drive them from there abased and humiliated'

# 3197

And he said: 'O Council, which of you will bring me her throne, before they come to me, Muslims (submissive to Allah)'

# 3198

An efreet (an extremely strong jinn) among the jinn replied: 'I will bring it to you before you rise from your place; I have the strength and am trustworthy'

# 3199

But he who had knowledge of the Book, said: 'I will bring it to you before your glance comes back to you' And when he saw it set before him, he (Solomon) said: 'This is a favor from my Lord that He might test me whether I am thankful or ungrateful. Whosoever gives thanks gives thanks only for his (own soul's) good, but he who is ungrateful, truly my Lord is Rich and Generous'

# 3200

(Then) he said: 'Let her throne be disguised, so that we can see whether she is guided or if she is among those who are not guided'

# 3201

And when she came she was asked: 'Is your throne like this' And she replied: 'It looks like it' And we were given the knowledge before her, and wereMuslims.

# 3202

That which she worshipped, other than Allah, had prevented her, for she came from an unbelieving nation.

# 3203

It was said to her: 'Enter the pavilion' And when she saw it, she thought it was a pool of water, and bared her legs. But he said: 'It is a pavilion smoothed with crystal' She said: 'My Lord, I have wronged myself, and I become a Muslim (submissive) with Solomon to Allah, Lord of the Worlds'

# 3204

To Thamood We sent their brother Salih saying: 'Worship Allah' But they were two parties in dispute with one another.

# 3205

'My nation' he said, 'why do you wish to hasten evil rather than good? Why do you not ask the forgiveness of Allah, in order that you find mercy'

# 3206

They said: 'We predict an evil omen from you and those who are with you' He replied: 'Your prediction is with Allah, you are a nation being tested'

# 3207

In the city there were nine people who were corrupting the land and did not reform.

# 3208

They said: 'Let us swear by Allah to attack him and his family at night, then we will tell his guardian we were not witnesses of the destruction of his family; and surely we are truthful'

# 3209

And they devised a scheme and, without their knowledge, We devised a scheme.

# 3210

And behold the consequences of their devising! We destroyed them, and their nation altogether.

# 3211

Those are their houses, all are in ruins because of the evil they committed; surely in this there is a sign for nation who know.

# 3212

And We saved those who believed and were cautious.

# 3213

And Lot, he said to his nation: 'Do you commit indecencies with your eyes open!

# 3214

Do you approach men lustfully instead of women! No, you are an ignorant nation'

# 3215

Yet the only answer of his nation was that they said: 'Expel the family of Lot from your village, they are people who purified themselves'

# 3216

So We saved him and his family, except his wife, whom We decreed should stay behind.

# 3217

And we rained on them a rain (of stones); indeed it is an evil rain that rains on those that are warned.

# 3218

Say: 'Praise belongs to Allah and peace be upon His worshipers whom He has chosen' Who is more worthier, Allah or that which they associate!

# 3219

Is He who created the heavens and the earth, and sent water from the sky for you and caused gardens to grow full of beauty of which its tree you could never grow, is there a god with Allah? No, but they are a nation who set up equals with Him!

# 3220

Who has established the earth a fixed place and set therein rivers; and set for it firm mountains and placed a barrier between the two seas, is there a god with Allah? No, most of them are without knowledge.

# 3221

Who answers the oppressed when he supplicates to Him and removes evil and appoints you as inheritors of the earth, is there a god with Allah? How little you remember!

# 3222

Who guides you in the darkness of the land and sea, and sends the winds bearing glad tidings of His Mercy, is there a god with Allah? Exalted is Allah above what they associate.

# 3223

Who originates creation, then brings it back again, who gives you sustenance from the heaven and the earth, is there a god with Allah? Say: 'Bring us your proof if you are among the truthful'

# 3224

Say: 'None in the heavens or the earth knows the Unseen except Allah, and they are not aware when they shall be resurrected'

# 3225

No, their knowledge fails them as to the Everlasting Life; no, they are in doubt about it, no, they are blind to it.

# 3226

The unbelievers say: 'When we and our fathers are turned to dust, shall we be brought forth?

# 3227

We were promised this before, and so were our fathers. It is but the fictitious story of the ancients'

# 3228

Say: 'Journey in the land and see what was the end of the sinners'

# 3229

Do not be sorry for them, nor be distressed for what they devise.

# 3230

And they ask: 'When will this promise come, if what you say is true'

# 3231

Say: 'It may be that part of what you seek to hasten on is already riding behind you'

# 3232

Surely, your Lord is bountiful to the people; yet most of them do not give thanks.

# 3233

Surely, your Lord knows what they hide in their hearts and what they reveal.

# 3234

There is not a thing hidden in the heaven and earth except that it is in a Clear Book.

# 3235

Surely, this Koran relates to the Children of Israel most of that which they are at variance.

# 3236

It is a guidance and a mercy to believers.

# 3237

Surely, by His Judgement, your Lord will decide between them. He is the Mighty, the Knower.

# 3238

Therefore put your trust in Allah, for you are upon a clear truth.

# 3239

You do not make the dead hear, nor do you make the deaf hear you call when they turn about, retreating.

# 3240

Nor do you guide the blind out of their error, nor do you make any to hear, except those who believe in Our verses and are Muslims.

# 3241

And when the Word falls on them, We will bring out from the earth a beast that shall speak to them: 'Indeed the people were not certain of Our verses.'

# 3242

On that Day We shall gather a crowd from every nation of those who belied Our verses, so they are gathered.

# 3243

When they have come, He will say: 'Did you belie My verses, although you knew nothing, or what was it you were doing'

# 3244

And the Word shall fall upon them because of the evil they committed, and they shall be speechless.

# 3245

Have they not seen how We have made the night for them to rest in and the day to see? Surely, there are signs in this for the nation who believe.

# 3246

On the Day the Horn shall be blown all who live in the heavens and earth will be terrified, except those whom Allah wills. All shall come to Him humbled.

# 3247

And you will see the mountains which you think to be firm pass by like clouds. (Such is the) making of Allah, who has created everything well. He is Aware of the things you do.

# 3248

Whosoever comes with a good deed shall have better than it, and shall be secure from the terrors of that Day.

# 3249

But those who come with an evil deed shall have their faces thrust into the Fire: 'Are you recompensed except for your deeds'

# 3250

(Say Prophet Muhammad): 'I am only ordered to worship the Lord of this country, which He has made sacred, everything belongs to Him. And I am ordered to be of the Muslims,

# 3251

and to recite the Koran. Whosoever is guided is only guided for himself, and to whosoever goes astray, say: 'I am only a warner'

# 3252

And say: 'Praise belongs to Allah! He will show you His signs and you will recognize them. Your Lord is not inattentive of what you do'

# 3253

TaSeenMeem.

# 3254

Those are the verses of the Clear Book.

# 3255

We shall in truth recite to you some of the news of Moses and Pharaoh for a nation who believe.

# 3256

Pharaoh had exalted himself in the land and had divided its people into sects, one group he abased, putting their sons to death and sparing their women, for he was one of those who corrupted.

# 3257

But We wanted to be gracious to those abased in the land, and to make them leaders and inheritors,

# 3258

and to establish them in the land; and to show Pharaoh and Haman, and their armies, the very thing they dreaded.

# 3259

We revealed this to Moses' mother: 'Suckle him, but when you fear for him cast him into the water. Neither fear, nor sorrow because We shall restore him to you and make him among the Messengers'

# 3260

Then the family of Pharaoh picked him out to be an enemy and a sorrow for them, indeed Pharaoh and Haman, and their army were sinners.

# 3261

Pharaoh's wife said to him: 'He will be a comfort to me and you. Do not slay him, perhaps he may benefit us, or we will take him for our son' But they were unaware.

# 3262

In the morning the heart of Moses' mother became empty. She would have revealed (who he was) had We not settled her heart so that she might be among the believers.

# 3263

She said to his sister: 'Follow him' And she watched him from a distance, but they were unaware.

# 3264

We had forbidden to him before that he should be suckled by foster mothers, therefore she (Moses' sister) said (to them): 'Shall I direct you to a people of a household who will take charge of him for you and advise him'

# 3265

So, We restored him to his mother, so that she might be comforted and not sorrow, and that she might know that the promise of Allah is true. Yet most of them do not know.

# 3266

And when he was full grown, and reached the perfection of his strength, We gave him judgment and knowledge. As such We recompense the gooddoers.

# 3267

And he entered the city unnoticed by the people and found two men fighting, one was of his own party, and the other of his enemies. The one of his party appealed for his help against his enemy, Moses struck and killed him, and said: 'This is the work of satan, he is surely a clear, misleading enemy.

# 3268

Forgive me, my Lord, for I have wronged myself' and so He forgave him; for He is indeed the Forgiving, the Most Merciful.

# 3269

He said: 'My Lord as You have favored me, I will never be a helper to the wrongdoer'

# 3270

In the morning, he was in the city, fearful and vigilant, then he whom he had helped the day before cried out to him again for help. 'Clearly' said Moses, 'you are quarrelsome'

# 3271

And when Moses was about to seize he who was the enemy of both of them, he said: 'Moses, would you kill me as you killed a living soul yesterday? You desire only to be a tyrant in the land, and you do not want to be among the reformers'

# 3272

Then a man came running from the furthest part of the city, 'Moses' he said, 'the Assembly are plotting to kill you. Leave, for I am one of your sincere advisers'

# 3273

So he left, fearful and vigilant, saying: 'My Lord, save me from the harmdoing nation'

# 3274

And when he turned his face towards Midian, he said: 'It may be that my Lord will guide me on the right way'

# 3275

When he came to the water wells of Midian he found there some people drawing water, and he found two women apart from them who were keeping back (their flocks). 'What is your business' he asked. They replied: 'We cannot draw water until the shepherds have driven away (their flocks), and our father is an elderly man'

# 3276

So he drew water for them and then retired to the shade, saying: 'O my Lord, surely I have need of whatever good You send me'

# 3277

Then, one of the two came to him walking shyly, and said: 'My father invites you, so that he can recompense you with a wage for having drawn water for us.' So when he came to him and told him his story, (the father) said: 'Do not be afraid, you have been saved from the nation of harmdoers'

# 3278

One of the two women said: 'Father, hire him. The best who you can hire, is the strong, the honest'

# 3279

He said: 'I will let you marry one of these two daughters of mine on condition that you hire yourself to me for eight years. If you complete ten that is of your own accord; I shall not press you. Surely, you will find me, if Allah wills, among the good'

# 3280

'So be it between me and you' said Moses. 'Whichever of the two terms I fulfill, it will be no injustice to me. Allah is the Guardian of what we say'

# 3281

And when Moses had fulfilled the term and departed with his household, he saw from far away on the side of the Tor a fire. He said to his household: 'Stay here, for I can see a fire. Perhaps I can bring you news, or a flame from the fire so that you can warm yourselves'

# 3282

When he came to it, he was called from the right bank in the blessed plot of the tree (he heard speech without letter or voice coming from all directions):'Moses, I am Allah, Lord of the Worlds.

# 3283

Cast down your staff' And when he saw his staff writhing as though it were a serpent, he turned about in retreat, and did not turn back. 'O Moses, approach and have no fear. You are surely safe.

# 3284

Put your hand in the neck (of your shirt), it will come out luminous, unharmed, and draw your arm to you so that you are not afraid. These are two signs from your Lord to Pharaoh and his Assembly. Surely, they were an impious nation.'

# 3285

'My Lord' (said Moses), 'I have killed a living soul among them, and fear that they will slay me.

# 3286

Aaron my brother has a more eloquent tongue than I, (please) send him with me as a helper to confirm I speak truly, I fear that they will belie me'

# 3287

He said: 'We will strengthen your arm with your brother, and appoint for you both an authority so that they shall not reach you. With our signs you and those who follow you shall be the victors.

# 3288

And when Moses came to them with Our clear signs, they said: 'This is nothing but forged sorcery. We have never heard of this among our fathers, the ancients.'

# 3289

Moses replied: 'My Lord knows well who brings guidance from Him and who shall possess the Last Residence. The harmdoers will not prosper'

# 3290

'Assembly' said Pharaoh, 'I do not know that you have any god except me' 'O Haman, kindle a fire upon clay and make me a tower so that I can climb to see the God of Moses, I think that he is one of the liars'

# 3291

He and his hosts became wrongfully proud in the land and they thought that they would never be returned to Us.

# 3292

Therefore, We seized him and his hosts, and cast them into the sea. See how was the end of the harmdoers.

# 3293

We made them leaders inviting to the Fire, and on the Day of Resurrection they shall not be victors.

# 3294

In this world We laid Our curse on them, and on the Day of Resurrection they shall be among the exiled.

# 3295

And We gave Moses the Book, after We had destroyed the former generations, to be reflections for people and a guidance, and a mercy in order that they might remember.

# 3296

(Prophet Muhammad) you were not on the western side (of the mountain) when We decreed the commandment to Moses, nor were you among thosewitnessing.

# 3297

We raised generations who lived long. You did not live among the people of Midian, nor did you recite to them Our verses; but We were sendingMessengers.

# 3298

You were not present on the side of the Tor when We called. Yet as a mercy from your Lord to warn a nation to whom no warner has been sent before, in order that they remember

# 3299

and not say, when evil befalls them on account of that which their hands forwarded: 'Our Lord, why did You not send a Messenger to us so that we might follow Your verses and so that we might be among the believers'

# 3300

So when the truth (Prophet Muhammad) came to them from Us, they said: 'Why is he not given the like of that which was given to Moses' But did they not also disbelieve in that which Moses was given before! They say (about Moses and Aaron): 'Two sorcerers supporting one another' And they said: 'We disbelieve both'

# 3301

Say: 'If what you say is true, bring down from Allah a Book that is a better guidance than both, I will follow it'

# 3302

If they do not answer you, know that they are only following their desires. And who is further astray than he who is led by his desires without guidance fromAllah! Allah does not guide the harmdoers.

# 3303

We have brought them the Word in order that they remember.

# 3304

Those to whom We gave the Book before, believe in it.

# 3305

When it is recited to them, they say: 'We believe in it, because it is the truth from Our Lord. We surrendered ourselves before it came.

# 3306

'Their wage shall be given them twice, because they have endured patiently, averting evil with good and spending from what We have given them;

# 3307

and because when they hear idle talk they turn away from it and say: 'We have our deeds, and you have your deeds. Peace be upon you. We do not desire the ignorant'

# 3308

You cannot guide whom you please; it is Allah who guides whom He will. He knows well those who are guided.

# 3309

They say: 'If we follow the guidance with you, we shall be driven from our land' But have We not given them a secure sanctuary from which fruits of every kind are collected as a provision from Us? Indeed, most of them do not know.

# 3310

How many a village have We destroyed that were ungrateful in their life! Those are their dwellings, (they are) uninhabited after them except for a little; We are the inheritors.

# 3311

Nor did your Lord destroy the villages until He had sent a Messenger to its mother village reciting to them Our verses. We never destroyed villages unless their inhabitants were harmdoers.

# 3312

The things you have been given, and its adornments, are but the enjoyment of this present life. What is with Allah is better and everlasting. Do you not understand?

# 3313

Is he to whom We promised a fine promise and receives it, like he who has been given the enjoyment of this present life, then on the Day of Resurrection shall be among those that are arraigned?

# 3314

On that Day He will call to them, saying: 'Where are those whom you alleged to be My associates'

# 3315

Those against whom the Word is realized shall say: 'Our Lord, those whom we led astray, we led them astray even as we ourselves were astray. We are quit of them to You; it was not us that they worshipped'

# 3316

It will be said to them: 'Call on your associates' And they will call on them, but they will not respond to them, and they shall see the punishment if only they had been guided.

# 3317

On that Day He will call to them and He will say: 'What response did you give Our Messengers'

# 3318

And on that Day the news will be blinded for them, and they will not ask each other.

# 3319

But, as for he who repents and believes, and does good deeds, he will be among those who prosper.

# 3320

Your Lord creates whosoever He will and He chooses the choice was not theirs (the unbelievers). Exalted is Allah, above that they associate!

# 3321

Your Lord knows what their chests hide and what they reveal.

# 3322

And He is Allah; there is no god except He. The Praise is His in the former as in the latter. His is the Judgement, to Him you shall be returned.

# 3323

Say: 'Think! What if Allah should enshroud you in unceasing night till the Day of Resurrection, what god, other than Allah, shall bring you light! Will you not hear?'

# 3324

Say: 'What would you think if Allah should make the day unceasing over you till the Day of Resurrection, what god, other than Allah, shall bring you the night to sleep in. Will you not see'

# 3325

In His Mercy He has appointed for you the night and the day, so that you can rest in it, and seek His bounty, in order that you will be thankful'

# 3326

Upon that Day He will call to them saying: 'Now, where are those whom you alleged to be My associates'

# 3327

From every nation We will bring a witness, and We shall say to them: 'Produce your proof' Then they shall know the truth is with Allah, and their own fabrications will forsake them.

# 3328

. Korah was one of Moses' nation. But he was insolent to them, for We had given him such treasures that their very keys were too heavy a burden for even the strong. His people said to him: 'Do not exult; Allah does not love the boastful.

# 3329

But seek, in that which Allah has given you to attain the Everlasting residence. Do not forget your share in this world. Do good, as Allah has been good to you, and do not corrupt in the land, Allah does not love those who corrupt.

# 3330

But he replied: 'What was given me is only because of the knowledge I possess' Did he not know that from the generations before him Allah had destroyed a mightier and more numerous in multitude? The sinners shall not be questioned about their sins.

# 3331

So he went out in all his finery among his nation, those who desired this life said: 'Would that we had the like of that Korah has been given! He has indeed a mighty fortune'

# 3332

But those to whom knowledge had been given said: 'Alas for you! Better is the reward of Allah for him who believes and does good works; but none shall receive it except the patient'

# 3333

We caused the earth to swallow him, together with his dwelling, and there was no host to help him, other than Allah; and he was not amongst the victorious.

# 3334

And in the morning those who had wished to be in his place the previous evening said: 'Indeed, Allah outspreads to whom He will among His worshipers, and He restrains. Had He not shown us favor, He could have caused the earth to swallow us. Indeed, the unbelievers shall never prosper'

# 3335

That is the Last Abode, We shall assign it to those who desire neither exorbitance in the earth, nor corruption. The outcome is for the cautious.

# 3336

Whosoever does a good deed shall have better than it. But whosoever does evil deeds, they shall be recompensed for what they were doing.

# 3337

He who has obligated the Koran will bring you to an appointment. Say: 'My Lord knows well who comes with guidance, and who is in clear error'

# 3338

You did not hope that the Book would be given to you except as mercy from your Lord. So do not be a supporter of the unbelievers.

# 3339

Let no one bar you from the verses of Allah after they have been sent down to you, but call to your Lord, and do not be amongst the idolaters.

# 3340

And do not call upon another god with Allah, there is no god except He. All things perish, except His Face, Judgement is His, and to Him all of you shall return.

# 3341

AlifLaamMeem.

# 3342

Do people think that they are left alone by saying: 'We are believers' and will not be tried?

# 3343

We tried those who have gone before them. Allah knows those who are truthful and those who lie.

# 3344

Or do the evildoers think that they will outstrip Us? How evil is their judgment!

# 3345

He who hopes to meet Allah (must know) that the term of Allah is coming. He is the Hearer, the Knower.

# 3346

He who strives, strives for himself. Allah is the Rich, independent of the worlds.

# 3347

As for those who believe and do good works, We shall acquit them of their sins, and recompense them with the best for what they were doing.

# 3348

We have charged the human to be kind to his parents. But if they bid you to associate with Me that which you have no knowledge, do not obey them. To Me you will return, and I shall inform you of all that you have done.

# 3349

Those who believe and do good works shall be admitted among the righteous.

# 3350

There are some people who say: 'We believe in Allah' yet when such is hurt in the cause of Allah, he makes the persecution of people as though it were the punishment of Allah. But then if help comes from his Lord, he will say: 'We were with you' Does Allah not know what is in the (people's) chests of the worlds?

# 3351

Most certainly Allah knows the believers and the hypocrites.

# 3352

The unbelievers say to those who believe: 'Follow our path, and we will carry your sins' Yet they cannot carry even a thing of their sins. They are surely lying.

# 3353

They shall certainly carry their loads, and other loads besides their loads, and on the Day of Resurrection, they shall be questioned about what they forged.

# 3354

Indeed, We sent Noah to his nation, and he lived amongst them for a thousand years, less fifty (but they belied him), then the Flood seized them while they were harmdoers.

# 3355

But We saved him and all who were in the Ark, and made (the event) a sign to the worlds.

# 3356

And (remember) Abraham. When he said to his people 'Worship Allah and fear Him. That would be best for you, if you but knew.

# 3357

You only worship, other than Allah, idols and invent falsehoods. Those whom you worship, other than Allah, have no power to give you provision. Therefore seek the provision of Allah, and worship Him. Give thanks to Him, to Him you shall return'

# 3358

If you belie me, other nations before you also belied. It is only for a Messenger to deliver the clear deliverance.

# 3359

Do they not see how Allah originates the Creation, and then brings it back? That is an easy matter for Allah.

# 3360

Say: 'Travel in the land and see how He started the Creation. Then Allah will originate the Everlasting Life. Allah has power over all things.

# 3361

He punishes whom He will and has mercy to whom He will. To Him you shall be turned.

# 3362

You are not able to frustrate Him either in the earth or heaven, nor have you, other than Allah, a guardian or helper.

# 3363

Those who disbelieve the verses of Allah and the meeting with Him shall despair of My Mercy, for them there awaits a painful punishment.

# 3364

The only answer his nation gave was that they said: 'Kill him, or burn him! 'But Allah saved him from the fire. Surely, in this there are signs for a nation who believe.

# 3365

He said: 'Other than Allah, you have taken to yourselves idols as an affection between yourselves in the present life. Then, on the Day of Resurrection, you shall deny one another and curse one another, and your refuge will be the Fire, and none shall help you'

# 3366

Lot believed him, and said: 'I will migrate to my Lord; He is the Almighty, the Wise'

# 3367

And, We gave him (Abraham), Isaac and Jacob and appointed on his descendants the Prophethood and the Book. We gave him his wage in this world, and in the Everlasting Life he shall be among the righteous.

# 3368

And Lot who said to his nation: 'You commit indecency which no other being in all the world has committed before you.

# 3369

What, do you approach men and cause a detour on the road, and commit dishonor (sodomy) in your assembly' But the only reply of his nation was: 'Then bring down the punishment of Allah, if what you say is true'

# 3370

'My Lord' he said, 'help me against this corrupt nation'

# 3371

And when Our Messengers brought Abraham the glad tidings they said: 'We are destroying the people of this village, because its people are harmdoers'

# 3372

He said: 'Lot is in it' They replied: 'We know who are in it, we shall save him and his family, except his wife, she has become of those that shall remain behind'

# 3373

And when Our Messengers came to Lot, he was troubled and distressed on their account. But they said: 'Have no fear, and do not be sad. Surely, we will save you and your family except your wife, she has become of those that shall remain behind'

# 3374

We shall send down anger out of heaven upon the people of this city because they are debauchers.

# 3375

Indeed, We left a clear sign for a nation that understands.

# 3376

And to Midian their brother Shu'aib. He said: 'Worship Allah, my nation. Look to the Last Day. Do not make mischief in the land, doing corrupt works.

# 3377

But they belied him, so the earthquake seized them, and when morning came, they were found fallen crouched in their dwellings, dead.

# 3378

Aad and Thamood, it has become clear to you from their dwellings; satan made their works seem fair to them and barred them from the Path, although they saw clearly.

# 3379

And Korah, Pharaoh, and Haman Moses came to them with clear signs, but they became very insolent in the earth, yet they did not outstrip Us.

# 3380

Each of them We seized for his sin. On some We loosed a squall of pebbles, and others were seized by the Cry. Some We caused to be swallowed up by the earth, and some We drowned. Allah would never wrong them but they wronged themselves.

# 3381

The likeness of those who have taken guardians, other than Allah, is as the likeness of the spider that takes to itself a house; surely the spider's house is the weakest house if they but knew.

# 3382

Allah knows whatever they call upon other than Him; He is the Almighty, the Wise.

# 3383

And We strike these parables for the people, but none understands except the knowledgeable.

# 3384

Allah has created the heavens and the earth with the truth. Surely, in that there is a sign for believers.

# 3385

Recite what has been sent down to you of the Book, and establish the prayer. Prayer forbids indecency and dishonor. The remembrance of Allah is greater, and Allah knows what you do.

# 3386

And do not dispute with the People of the Book (Nazarenes) except in the best manner, except for those among them who do wrong and say (to them): 'We believe in that which was sent down to us and that which was sent down to you. Our God and your God is One, and to Him we have surrendered'

# 3387

As such, We have sent down to you the Book. Those to whom We gave the Book believe in it, and so do some of these. None reject Our verses except the unbelievers.

# 3388

Never before did you recited any Book, or inscribe it with your right hand. If you had done so, those who follow falsehood would have doubted.

# 3389

No, rather they are clear verses in the chests of those who have been given knowledge. None disbelieves Our verses except the harmdoers.

# 3390

They ask: 'Why has not a sign been sent down upon him from his Lord' Say: 'The signs are only with Allah. I am only a clear warner'

# 3391

Is it not enough for them that We have sent down to you the Book that is recited to them? Surely, in this there is a mercy and a reminder to a nation who believe.

# 3392

Say: 'Allah suffices as a witness between me and you. He knows whatsoever is in the heavens and the earth. Those who believe in falsehood and disbelieve in Allah those are they who are the losers'

# 3393

They demand that you hasten the punishment! But had it not been for the stated term, the punishment would come to them; it will come upon them suddenly when they are unaware.

# 3394

They demand that you hasten on the punishment! Gehenna (Hell) will encompass the unbelievers.

# 3395

On the Day the punishment shall cover them from above them and from beneath their feet, He shall say: 'Taste now what you were doing'

# 3396

O My worshipers who believe, My earth is vast, therefore worship Me!

# 3397

Every soul shall taste death, and to Us you shall be returned.

# 3398

Those who believe and do good deeds We shall lodge them in the rooms of Paradise underneath which rivers flow, therein living for ever, an excellent wage for those who labor,

# 3399

those who are patient, and put their trust in their Lord.

# 3400

How many a beast does not bear its own provision. Allah provides for it, as (He provides) for you. He is the Hearer, the Knower.

# 3401

If you ask them: 'Who has created the heavens and the earth and subjected the sun and the moon' They will say: 'Allah' How perverted they are!

# 3402

Allah outspreads and restricts His provision to whomsoever He will of His worshipers. Allah has knowledge of all things.

# 3403

If you were to ask them: ''Who sends down water out of the sky and thereby revives the earth after it was dead' they will reply: 'Allah' Say: 'Praise, belongs to Allah' No, but most of them do not understand.

# 3404

The life of this world is nothing but a diversion and play. Indeed, the Everlasting Residence is the Eternal Life, if they but knew.

# 3405

When they embark upon ships, they call to Allah making their religion sincerely His; but when He brings them safe to the land, they associate others with Him

# 3406

showing ingratitude for what We have given them and take their enjoyment; soon they shall know!

# 3407

Do they not see how We appointed a safe Sanctuary while all around them people are snatched away? Would they believe in falsehood and do they disbelieve in the favor of Allah!

# 3408

And who does greater evil that he who forges a lie against Allah or belied the truth when it comes to him! Is there not a lodging in Gehenna for the unbelievers?

# 3409

Those who struggle in Our cause, We will surely guide them to Our ways; and Allah is with those who do good.

# 3410

AlifLaamMeem.

# 3411

The Romans have been defeated (by the Persians)

# 3412

in a land close by. But, in a few years after their defeat they shall become the victors.

# 3413

To Allah belongs the Command before and after, and on that Day the believers will rejoice

# 3414

in the victory of Allah. Allah gives victory to whosoever He will, and He is the Mighty, the Merciful.

# 3415

The promise of Allah! Allah does not fail His promise, yet most people do not know.

# 3416

They know an outward part of this life, but of the Everlasting Life they are inattentive.

# 3417

Have they never thought to themselves that Allah did not create the heavens and the earth and all that is between except with truth, and for a stated term? Yet most people disbelieve that they will ever meet their Lord.

# 3418

What, have they never journeyed in the land and seen what was the end of those before them? They were stronger in might than themselves, and they plowed the land and cultivated it more than they themselves have cultivated it. And to them, their Messengers came with clear signs, and Allah did not wrong them, but they wronged themselves.

# 3419

Evil was the end of the harmdoers, because they belied the verses of Allah and mocked at them.

# 3420

Allah originates creation, then brings it back again, then to Him you shall be returned.

# 3421

On the Day when the Hour comes, the wrongdoers will be speechless.

# 3422

They shall have none to intercede for them amongst their associates, and they shall disbelieve in their associates.

# 3423

On the Day when the Hour has come, they will be divided,

# 3424

those who believe and did good deeds shall be well pleased in a garden,

# 3425

but those who disbelieved and belied Our verses and the meeting of the Everlasting Life, shall be arraigned for punishment.

# 3426

Therefore, exalt Allah when you enter the evening and in the morning.

# 3427

His is the praise in the heavens and the earth, at the setting sun and at noon.

# 3428

He brings out the living from the dead, and the dead from the living. He revives the earth after its death. Likewise you shall be brought forth.

# 3429

And of His signs is that He created you from dust and you became humans scattered throughout the earth.

# 3430

And of His signs is that He created for you wives from among yourselves, that you might reside with them, and has put kindness and mercy between you. Surely, there are signs in this for those who think.

# 3431

And His signs are the creation of heavens and earth and the diversity of your tongues and colors. Surely, there are signs in this for all the worlds.

# 3432

And of His signs is that you sleep at night and day, and seek His bounty. Surely, there are signs in this for those who hear.

# 3433

And of His signs is that He shows you the lightning for fear and hope. He sends down water from the sky and with it He revives the earth after its death. Surely, in this there are signs for a nation that understand.

# 3434

And of His signs is that the heaven and earth stand firm at His command. And when He calls you once out of the earth, you shall come forth.

# 3435

To Him belongs whosoever is in the heavens and the earth. All are obedient to His Will.

# 3436

It is He who originates the creation, and then brings it back again, that is easier for Him. For Him is the Highest Example in the heavens and earth He is the Almighty, the Wise.

# 3437

He sets for you an example, drawn from yourselves. Do you have from among those whom your right hand possesses associates in what We have given you, who share it equally with you? Do you fear them as you fear one another? So We made plain Our signs to a nation of understanding.

# 3438

No, the wrongdoers follow their own desires without knowledge. And who can guide those whom Allah has led astray? There shall be none to help them.

# 3439

Therefore set your face to the religion purely, the upright creation upon which He originated people. There is no changing of the creation of Allah. This is the valuable religion, although most people do not know?

# 3440

turning to Him. And fear Him, establish the prayer and do not be of the idolaters,

# 3441

those who have divided their religion, and become sects, each rejoicing in what they have.

# 3442

When affliction befalls mankind they turn to Him calling their Lord in prayer, but when He lets them taste His Mercy, some of them assign associates to their Lord,

# 3443

disbelieving in what We have given them. Enjoy, but you shall soon know.

# 3444

Or have We sent down to them an authority that speaks of that they associate with Him?

# 3445

When We give people a taste of mercy, they rejoice in it, but when evil befalls them through the forwarding of their own hands, they become despondent.

# 3446

Do they not see that Allah outspreads and restricts His provision to whom He will? Surely, there are signs in this for those who believe.

# 3447

And give to the kinsman his due, and to the needy, and to the destitute traveler. That is best for those who desire the Face of Allah; such will surely prosper.

# 3448

That which you give in usury so that it increases in other people's wealth, will not increase with Allah; but the charity you give desiring the Face of Allah, to those, they shall be recompensed many times over.

# 3449

It is Allah who has created you and given you your provision. He will cause you to die, and will then revive you. Can any of your associates do any of that? Exalted is He above what they associate.

# 3450

Corruption has appeared on land and sea with what the hands of the people earned. Therefore, they taste some of what they did in order that they return.

# 3451

Say: 'Journey in the land and see what was the end of those who were before you. Most of them were idolaters'

# 3452

Therefore in purity set your face to the religion, before there comes from Allah a Day that cannot be turned back. On that Day mankind will be separated.

# 3453

Those who disbelieve will be charged for their disbelief, while the righteous are making provision for themselves

# 3454

so that He will recompense those who believe and do righteous deeds from His bounty. He does not love the unbelievers.

# 3455

And of His signs is that He looses the winds as bearers of glad tidings, so that He lets you taste His Mercy and that the ships may sail at His command in order that you can seek His bounty and be thankful.

# 3456

Before you We sent other Messengers to their people; and they came with clear signs. We took revenge upon the sinners, and it was an incumbent duty upon Us to give victory to the believers.

# 3457

It is Allah who looses the winds that stir the clouds. He spreads them as He will in heaven and disperses them, so that you can see the rain falling from their midst. When He smites with it whom He will of His worshipers they rejoice,

# 3458

though before its coming they had despaired.

# 3459

Look then at the marks of Mercy of Allah; how He revives the earth after its death. He is the Reviver of the dead. He has power over all things.

# 3460

Yet if We sent a wind so they see it yellow, indeed after that they would still be unbelievers.

# 3461

You cannot make the dead hear you, nor can you make the deaf hear the call when they retreat, turning about.

# 3462

You cannot guide the blind out of their error. Nor shall you make any to hear except those who believe in Our verses, and are submissive.

# 3463

Allah creates you weak; after weakness He gives you strength and after strength weakness and gray hairs. He creates whatever He will. He is the Knower, the Capable.

# 3464

Upon the Day when the Hour has come, the harmdoers will swear that they had stayed no more than an hour. As such they are deceived.

# 3465

But those to whom knowledge and belief have been given will say: 'You have stayed in the Book of Allah (the Protected Tablets) till the Day of Resurrection. This is the Day of Resurrection, yet you did not know'

# 3466

On that Day, excuses shall not benefit the harmdoers, nor shall they be asked to make amends.

# 3467

In this Koran We have set forth for mankind all manner of examples. Yet if you bring to them a sign the unbelievers will surely say: 'You are but falsifiers'

# 3468

As such Allah seals the hearts of those who do not know.

# 3469

Therefore, have patience. The promise of Allah is true. Do not let those who are uncertain make you unsteady.

# 3470

AlifLaamMeem.

# 3471

Those are the verses of the Wise Book,

# 3472

a guidance and a mercy to those who do good,

# 3473

who establish the prayer, pay the obligatory charity, and firmly believe in the Everlasting Life.

# 3474

Those are guided by their Lord and will surely prosper.

# 3475

There are some people who would purchase distracting talk, to lead astray from the Path of Allah without knowledge, and take it in mockery; for those is a humiliating punishment.

# 3476

When Our verses are recited to him, he turns his back in pride, as though he never heard them, and in his ears was heaviness. Give glad tidings to him of a painful punishment!

# 3477

But for those who believe and do good works are Gardens of Bliss,

# 3478

where they shall live for ever. The promise of Allah is the truth; He is the Almighty, the Wise.

# 3479

He created the heavens without pillars that you see and cast on the earth firm mountains lest it should shake with you. Upon it He dispersed all manner of crawling thing, and He sent down water from the sky with which He caused to grow in it every generous kind.

# 3480

Such is the creation of Allah; now show me what, other than Him, created! No, the harmdoers are in clear error.

# 3481

We gave wisdom to Lokman (saying): 'Give thanks to Allah. He who gives thanks, thanks only for himself, but whosoever is ungrateful, surely, Allah is the Rich, the Praised'

# 3482

And when Lokman said to his son, in warning: 'My son, associate none with Allah, to associate others with Allah is a tremendous wrong'

# 3483

And We charged the human concerning his parents, for his mother bore him in weakness upon weakness, and his weaning was in two years. Be thankful to Me and to your parents, to Me is the arrival.

# 3484

But if they strive with you to make you associate with Me that of which you have no knowledge, do not obey them. And accompany them in this life with kindness; and follow the Path of he who turned to Me. To Me you shall return and I will inform you of all that you have done.

# 3485

(Lokman said:) 'My son, if it should be but the weight of one grain of mustardseed, and though it be on a rock, or in the heavens, or in the earth, Allah shall bring it. Surely, Allah is the Subtle, Aware.

# 3486

My son, establish the prayer, order with honor but forbid dishonor, and bear patiently with whatever may fall upon you, indeed that is true constancy.

# 3487

Do not turn your cheek in scorn away from people, nor walk proudly on the earth; Allah does not love the proud and the boastful.

# 3488

Walk modestly, and lower your voice; the most hideous of voices is the braying of the donkey.

# 3489

Do you not see how Allah has subjected to you all that is in the heavens and the earth, and lavished on you His visible and unseen favors? Yet some people would argue about Allah without knowledge, or guidance, or an Illuminating Book'

# 3490

When it is said to them: 'Follow what Allah has sent down' they reply: 'No, rather we will follow that which we found our fathers upon' What! Even though satan is inviting them to the punishment of the Fire!

# 3491

He who surrenders himself to Allah and is a good doer, has grasped the firmest handle. To Allah the issue of affairs return.

# 3492

As for those who disbelieve, do not let their disbelief grieve you, to Us they shall return and We will tell to them what they did. Allah has knowledge of what is innermost in their chests.

# 3493

We give to them a little enjoyment for awhile, and then will compel them to a tremendous punishment.

# 3494

If you ask them: 'Who has created the heavens and the earth' They will reply: 'Allah' Say: 'Praise belongs to Allah' But most of them do not have knowledge.

# 3495

To Allah belongs all that is in the heavens and the earth. He is the Rich, the Praised.

# 3496

If all the trees in the earth were pens, and the sea, with seven more seas to replenish it (with ink), the Words of Allah would never end. Allah is the Almighty, the Wise.

# 3497

Your creation and your resurrection are but as a single soul. Allah is the Hearer, the Seer.

# 3498

Do you not see how Allah causes the night to enter into the day, and the day enter into the night and has subjected the sun and the moon, each running to a named term? Allah is Aware of what you do.

# 3499

For Allah is the Truth, while that which they call upon, other than Him, is false. For that Allah is the Most High, the Great.

# 3500

Do you not see how the ships run upon the sea, by the Favor of Allah so that He may show you His signs? Surely, there are signs in this for every steadfast, thankful person.

# 3501

When the waves, like shadows, envelop them, they call to Allah making their religion sincerely His, but no sooner does He bring them safely to land then some of them are halfhearted. None denies Our verses, except the ungrateful traitor.

# 3502

People, fear your Lord, and fear the Day when no father shall ransom a thing for his child nor a child for his father. The promise of Allah is surely true. So do not let the life of this present world delude you, nor let the deluder (satan) delude you concerning Allah.

# 3503

Allah, He alone has knowledge of the Hour. He sends down the rain and He knows what is in the wombs. No soul knows what he will earn tomorrow; and no soul knows in what land it will die. Surely, Allah is the Knower, the Aware.

# 3504

AlifLaamMeem.

# 3505

The sending down of the Book in which there is no doubt that is from the Lord of the Worlds.

# 3506

Or do they say: 'He has forged it himself' Say: 'No, it is the truth from your Lord so that you can warn a nation to whom none has warned before you, in order that they are guided.

# 3507

It was Allah, who, in six days created the heavens and the earth and all that is between them, and then willed to the Throne. You have no guardian nor intercessor other than Him. Will you not remember?

# 3508

He directs the affair from heaven to earth. Then it will ascend to Him in one day, a day whose value is a thousand years by your reckoning.

# 3509

He is the Knower of the Unseen and the Visible, the Almighty, the Most Merciful,

# 3510

who perfected everything He created. He originated the creation of the human from clay,

# 3511

then He made his offspring from a clot of weak water (semen).

# 3512

Then He created him and (caused the angel to) breathe into him his (created) spirit. He gave you eyes and ears, and hearts, yet little do you thank.

# 3513

They say: 'What, when we have been destroyed in the earth, shall we indeed be in a new creation' Indeed, they disbelieve that they will meet their Lord.

# 3514

Say: 'The Angel of Death, who has been given charge of you will gather you then to your Lord you shall be returned'

# 3515

Would that you could see the wrongdoers when they lower their heads before their Lord! They will say: 'Our Lord, we have now seen and heard. Send us back and we will do righteous deeds, we are certain'

# 3516

Had We Willed, We would have guided every soul. But My Word shall be realized, 'I will fill Gehenna (Hell) with jinn and people all together'

# 3517

(We shall say to them): 'Now taste, for you forgot the encounter of this Day, We have forgotten you. Taste Our eternal punishment, for that which you were doing'

# 3518

Only those who believe in Our verses, when reminded of them, prostrate themselves and exalt with the praise of their Lord in humility;

# 3519

whose sides forsake their couches as they supplicate to their Lord in fear and hope; who give in charity of that which We have given them.

# 3520

No soul knows what pleases the eye is in store for them as a recompense for what they used to do.

# 3521

Can he, then, who is a believer, be compared to he who is wicked? They are not equal.

# 3522

As for those who believe and do good works, there are for them the Gardens of Refuge, in hospitality for that which they have done.

# 3523

But those who do evil their refuge is the Fire. As often as they desire to come out of it they shall be driven back, and it will be said to them: 'Taste the punishment of the Fire, which you have belied'

# 3524

But We will let them taste the nearest punishment (in this life) before the greater punishment, so that they may return (to faith).

# 3525

And who is more wicked than he who, when reminded of the verses of his Lord turns away from them? We take revenge on the sinners.

# 3526

We have given the Book to Moses, so (Prophet Muhammad) do not be in doubt concerning the meeting with him (Prophet Moses) and made it a guidance to the Children of Israel.

# 3527

When they were patient, We made from them leaders, guiding with Our Command and they were certain of Our verses.

# 3528

On the Day of Resurrection your Lord will distinguish between them that on which they varied.

# 3529

Is it not a guidance to them, how many generations We destroyed before them in whose dwelling places they walk? Surely, in this there are signs. Will they not then hear!

# 3530

Do they not see how We drive the water to the parched lands and bring forth therefrom crops from which their cattle and themselves eat? Will they not see!

# 3531

They also ask: 'When will this Opening come, if what you say is true'

# 3532

Say: 'On the Day of Opening the faith of the unbelievers will not benefit them, nor shall they be respited'

# 3533

Therefore turn away from them, and wait, they are waiting.

# 3534

O Prophet, fear Allah, and do not obey the unbelievers and the hypocrites. Allah is the Knower, the Wise.

# 3535

Follow what is revealed to you from your Lord, for Allah is Aware of what they do,

# 3536

put your trust in Allah; Allah suffices as a Guardian.

# 3537

Allah has never made any man with two hearts inside him. Nor has He made your wives, when you divorce, saying: 'Be as my mother's back' your mothers. Neither has He made your fostered sons as your own sons. These are your own sayings, words which you utter with your mouths; but Allah speaks the truth and guides to the Path.

# 3538

Name them after their fathers, that is more just with Allah. If you do not know their fathers, regard them as your brothers in the religion, or those under your sponsorship. There is no fault in you if you make mistakes, but only in what your hearts intended. Allah is Forgiving and the Most Merciful,

# 3539

The Prophet has a greater right on the believers than their own selves, his wives are their mothers. Kinsmen are closer to one another in the Book of Allah than to other believers and the emigrants; although you should act honorably towards those you sponsor, that is written in the Book

# 3540

We took from the Prophets their covenant and from you (Prophet Muhammad), from Noah and Abraham, from Moses and Jesus the son of Mary. We took a solemn covenant from them,

# 3541

so that Allah might question the truthful about their truthfulness. But for the unbelievers He has prepared a painful punishment.

# 3542

Believers, remember the Favor of Allah to you when there came against you hosts (armies). We unleashed against them a wind and hosts (angels) you could not see. Allah sees the things you do.

# 3543

They came on you from above and from below, and when your eyes swerved and your hearts leapt to your throats, and you thought thoughts about Allah;

# 3544

there the believers were tried, they were shaken, a severe quake.

# 3545

The hypocrites and those in whose hearts there is a disease said: 'Allah and His Messenger promised nothing but delusion'

# 3546

And when a party of them said: 'People of Yathrib (Madinah), there is no place for you here, therefore return' And a party of them asked leave of theProphet, saying: 'Our houses are exposed' whereas they were not, they only wished to flee.

# 3547

And if an entrance had been forced against them from its quarters, and then they had been asked to incite, they would have done so, and remained in it (the city) but a little (time).

# 3548

Yet before that, they made a covenant with Allah never to turn their backs. And covenants with Allah shall be questioned.

# 3549

Say: 'Flight will not avail you, if you flee from death or slaughter, you would enjoy (this world) only for a little (time)'

# 3550

Say: 'Who can defend you from Allah if He desires harm for you, or if He desires mercy for you' They shall find for themselves none, other than Allah, to protect or help them.

# 3551

Allah knows those of you who hinder, and those who say to their brothers: 'Come to us' and they do not come to the battle but a little,

# 3552

being mean towards you. When fear comes to them, you see them looking at you, their eyes rolling as though they were on the point of death. But once the fear departs they assail you with their sharp tongues, being greedy to possess good things. Those have never believed; Allah has annulled their deeds. That is easy for Allah.

# 3553

They think the confederates have not departed. Indeed, if the confederates should come again they would sooner be in the desert among the Bedouins asking news of you. If they were among you, they would fight but a little.

# 3554

In the Messenger of Allah you have a fine example for he who hopes for Allah and the Last Day and remembers Allah abundantly.

# 3555

When the believers saw the confederates they said: 'This is what Allah and His Messenger have promised us. Surely, Allah and His Messenger have spoken in truth' And this did not increase them except in belief and submission.

# 3556

Among the believers there are men who have been true to their covenant with Allah. Some have fulfilled their vow dying, and others await, unyielding tochange,

# 3557

so that Allah will recompense the truthful for their truthfulness and punish the hypocrites if He will, or turn again to them. Surely, Allah is the Forgiver and the Most Merciful.

# 3558

Allah sent back the unbelievers in their rage, and they gained no good. Allah spared the believers from fighting, surely Allah is the Strong, the Mighty.

# 3559

He brought down from their fortresses those who had supported them from among the People of the (Jewish) Book and cast terror into their hearts, so that some you killed and others you took captive.

# 3560

He made you inheritors of their land, their houses, and their possessions, and another land on which you had never set foot before. Truly, Allah is Powerful over everything.

# 3561

O Prophet, say to your wives: 'If you seek this life and its finery, come, I will release you with a fine release.

# 3562

But if you seek Allah and His Messenger and the Everlasting Residence, know that Allah has prepared for those of you who do good works a mighty wage'

# 3563

O wives of the Prophet! Whosoever among you commit a flagrant indecency, for her the punishment shall be doubled, that is easy for Allah.

# 3564

But she who obeys Allah and His Messenger and does good works shall be doubly recompensed; for her We have made a generous provision.

# 3565

O wives of the Prophet, you are not like other women. If you fear (Allah), do not be to complaisant in your speech, lest he in whose heart there is a sickness may desire (of his mother); but speak honorable words.

# 3566

Stay in your homes and do not display your finery as pagan women used to do in the olden Days of Ignorance. Establish your prayers, pay the obligatory charity, and obey Allah and His Messenger. O family of the House, Allah only wishes to distance fault from you, and to cleanse you, and to purify you abundantly.

# 3567

And remember that which is recited in your houses of the verses of Allah and the Wisdom. Allah is the Subtle, the Knower.

# 3568

For men and women who have surrendered believing men and women; obedient men and women; truthful men and women, patient men and women, humble men and women, men and women who give charity, men and women who fast, men and women who guard their privates, men and women who remember Allah in abundance, for them Allah has prepared forgiveness and a mighty wage.

# 3569

It is not for any believer man or woman to have the choice in the affair when a matter is decreed by Allah and His Prophet. Whosoever disobeys Allah and His Messenger strays into clear error.

# 3570

And when you said to he whom Allah had favored and yourself have favored: 'Keep your wife and fear Allah' and you sought to hide in yourself what Allah was to reveal, fearing people; although Allah has a better right for you to fear Him. And when Zayd had accomplished what he would of her (divorce), We gave her to you (Prophet Muhammad) in marriage, so that there is no fault in believers concerning (marriage to) the former spouse of their foster children if they divorced them. The decree of Allah must be done.

# 3571

No fault shall be attached to the Prophet for doing what Allah has obligated for him. Such was the way of Allah with those who passed away before the decree of Allah is a decree determined

# 3572

who were delivering the Messages of Allah, fearing Him and fearing none except Allah. Allah suffices as a Reckoner.

# 3573

Muhammad is not the father of any of your men. He is the Messenger of Allah and the Seal of the Prophets. Allah has knowledge of all things.

# 3574

Believers, remember Allah frequently,

# 3575

exalt Him at dawn and in the evening.

# 3576

It is He who has mercy on you, and His angels to bring you out from the darkness into light. He is the Most Merciful to the believers.

# 3577

On the Day they meet Him, their greeting shall be 'Peace' A generous recompense He has prepared for them.

# 3578

O Prophet, We have sent you as a witness, a bearer of glad tidings, and to bear warning;

# 3579

a caller to Allah by His permission and as a light shedding lamp.

# 3580

Give to the believers the glad tidings that with Allah there is for them a great bounty.

# 3581

Do not obey the unbelievers and the hypocrites, pay no attention to their hurt. Put your trust in Allah; Allah suffices as a Guardian.

# 3582

Believers, if you marry believing women and divorce them before the marriage is consummated, you have no period to count against them. Provide for them and release them kindly.

# 3583

O Prophet, We have made lawful to you the wives to whom you have given dowries and those whom your right hand possesses, of whatever spoils of war that Allah has given you; and the daughters of your paternal uncles and paternal aunts, and of your paternal and maternal aunts who migrated with you; and any believing woman who gives herself to the Prophet, if the Prophet wishes to take her in marriage. This is only for you and not any other believer. We know the duties We have imposed on them concerning their wives and those whom their right hand possesses, so that there should be no fault in you. Allah is the Forgiving and Merciful.

# 3584

You may defer any of them (your wives) if you please and invite any of them if you please. If you seek any you have put aside there is no fault in you. So that it is likelier they will be comforted, and not sorrow, and every one of them will be pleased, and all are pleased with what you give them. Allah knows what is in your hearts. Allah is the Knower, the Clement.

# 3585

It shall be unlawful for you to take more wives or to exchange your present wives for other women, though their beauty pleases you, except those whom your right hand possesses. Allah is watchful over everything.

# 3586

Believers, do not enter the houses of the Prophet for a meal without waiting for the proper time, unless you are given permission. But if you are invited, enter, and when you have eaten, disperse, not desiring conversation, for that is hurtful to the Prophet and he would be shy before you; but of the truth Allah is not shy. And when you ask his wives for anything, speak to them from behind a curtain, that is cleaner for your hearts and theirs. You must not hurt the Messenger of Allah, nor shall you ever wed his wives after him, surely, this would be a monstrous thing with Allah.

# 3587

Whether you reveal a thing or conceal it, Allah has knowledge of all things.

# 3588

It shall be no offense for them (to be seen unveiled) by their fathers, their sons, their brothers, their brothers' sons, their sisters' sons, their women, and those whom their right hands possess. And fear Allah, for Allah is witness of everything.

# 3589

Allah and His angels praise and venerate the Prophet. Believers, praise and venerate him and pronounce peace upon him in abundance.

# 3590

Those who (try to) hurt Allah and His Messenger shall be cursed by Allah in this present life and in the Everlasting Life, and He has prepared for them a humbling punishment.

# 3591

Those who hurt believing men and believing women undeservedly, shall bear the guilt of slander and a major sin.

# 3592

O Prophet, tell your wives, your daughters and the believing women to draw their veils close to them, so it is likelier they will be known, and not hurt. Allah is the Forgiver, the Most Merciful.

# 3593

If the hypocrites and those who have a disease in their hearts, and those who make a commotion in the City do not desist, We will surely urge you against them. Then they will be your neighbors for only a little (while),

# 3594

cursed wherever they are found, they will be seized and put to death.

# 3595

Such has been the way of Allah with those who have passed before them, and you shall find no change in the ways of Allah.

# 3596

The people will ask you about the Hour. Say: 'The knowledge of it is with Allah alone, what makes you to know that the Hour is near'

# 3597

Allah has cursed the unbelievers and prepared for them a Blaze.

# 3598

Living there for ever, they shall neither find a guardian nor a helper.

# 3599

On that Day when their faces are turned about in the Fire, they shall say: 'Would that we had obeyed Allah and obeyed the Messenger'

# 3600

And they shall say: 'Our Lord, We obeyed our masters and our eminent ones, but they misled us from the way.

# 3601

Our Lord, let their punishment be doubled; and curse them with a mighty curse'

# 3602

Believers, do not be like those who hurt Moses. Allah cleared him of what they said. His face is honorable with Allah.

# 3603

O you who believe, fear Allah and say sound statements,

# 3604

and He will mend your deeds for you and forgive your sins. Whosoever obeys Allah and His Messenger shall win a great victory.

# 3605

We offered the trust to the heavens, and the earth, and the mountains, but they refused to bear it, and were afraid of it, and the human carried it. Surely, he is a harmdoer, and ignorant.

# 3606

Allah punishes the hypocrites, men and women alike, and the idolaters, both men and women alike; and Allah turns to the believers, men and women alike. Allah is the Forgiver, the Most Merciful.

# 3607

Praise is for Allah, to whom belongs all that is in the heavens and the earth! And the Praise belongs to Him in the Everlasting Life. He is the Wise, the Knower.

# 3608

He knows all that penetrates the earth and all that comes forth from it, all that comes down from heaven and all that ascends to it. He is the Most Merciful, the Forgiver.

# 3609

The unbelievers say: 'The Hour will never come to us' Say: 'By my Lord, yes, it is surely coming to you! By Him who knows the Unseen, not even the weight of an atom in heavens and earth escapes Him; neither is there anything smaller than that, nor greater except that it is in a Clear Book,

# 3610

in order that He recompenses those who believe and do good works; theirs shall be forgiveness and a generous provision.

# 3611

But those who labor against Our verses (thinking they are) frustrating (Our Messengers), theirs shall be the painful punishment of anger'

# 3612

Those to whom the knowledge has been given can see that what has been sent down to you from your Lord is the truth, guiding to the Path of the Almighty, the Praised.

# 3613

The unbelievers say: 'Shall we direct you to a man who will tell you that when you have been utterly torn into pieces you will be raised in a new creation?'

# 3614

What, has he forged a lie about Allah, or is he mad' No, those who do not believe in the Everlasting Life are in the punishment and in far error.

# 3615

Have they not seen what is before them and behind them in heaven and earth? If We willed, We would make the earth swallow them up, or We would let lumps from heaven fall down on them. Surely, there is a sign in this for every penitent worshiper.

# 3616

We gave David bounty from Us. 'O mountains, and birds, echo (the praise of Allah) with him' And We softened iron for him,

# 3617

(saying): 'Make large coats of mail and measure their links well. Do good deeds, for surely I see the things you do'

# 3618

To Solomon the morning course of the wind was a month's journey, and its evening course was also a month's journey. We caused copper to be (as a) molten spring for him. And the jinn, some served him by the permission of his Lord. But as for those amongst them that swerved away from Our Command, We shall let them taste the punishment of the Blaze (the Fire).

# 3619

They made for him whatever he wanted, arches, statues, bowls as basins, and fixed cauldrons. (We said:) 'Give thanks, House of David and work' Yet only a few of My worshipers are thankful.

# 3620

And when We decreed (Solomon's) death, they had no indication that he was dead until (they saw a termite), a crawler of the earth eating away his staff. And when he fell down, the jinn realized that had they known the unseen, they would not have continued in their humiliating punishment.

# 3621

For Sheba there was indeed a sign. In their dwelling place there were two gardens, on the right and left side. (We said): 'Eat of your Lord's provisions and give thanks to Him, a good land, and a Lord who is the Forgiving'

# 3622

But they turned away. So We sent against them the Flood (at the city) of Arim, and exchanged their gardens with two others bearing bitter fruit andTamarisks, and here and there a few Lotus trees.

# 3623

As such We recompensed them for their disbelief; do We recompense any except the unbelievers?

# 3624

Between them and the villages which We had blessed, We placed easily visible villages, and We spaced the journey between them exactly. (We said):'Travel through them by day and night in safety'

# 3625

But they said: 'Lord, make the stages between our journeys longer' so they wronged themselves; so We made them news and We tore them utterly into pieces. Surely, there are signs in this for every one who is patient, thankful.

# 3626

iblis' made his guess true to them; and all except for a party of believers followed him.

# 3627

Yet he had no authority over them except that We would know who believed in the Everlasting Life, from he who doubted. Your Lord is the Watcher over all things.

# 3628

Say: 'Call on those whom you assert, other than Allah. They do not possess as much as the weight of an atom in the heavens or earth, nor do they have a partnership in either, neither does He have supporters among them'

# 3629

Intercession with Him will not help, except for him to whom He gives permission. When terror is lifted from their hearts, they shall say: 'What did your Lord say' 'The truth' they shall answer. 'He is the Most High, the Great'

# 3630

Say: 'Who provides for you from the heavens and earth' Say: 'Allah' Surely, either we or you are rightly guided or in clear error.

# 3631

Say: 'You will not to be questioned about our sins, neither will we be questioned for your actions'

# 3632

Say: 'Our Lord will bring us all together, then, with truth, He will rightly judge between us. He is the Opener, the Knower.

# 3633

Say: 'Show me those whom you joined with Him as associates; no, indeed; rather He is Allah, the Almighty, the Wise.

# 3634

We did not send you (Prophet Muhammad) for all mankind except to bring them glad tidings and to warn, but most people do not know.

# 3635

They ask: 'When, if what you say is true, will this promise come'

# 3636

Say: 'You are promised a Day. You can neither hold it back, nor can you hasten it by a single hour'

# 3637

The unbelievers say: 'We will not believe in this Koran, nor in (the Books) that were before it' If you could only see the harmdoers when they are brought before their Lord! They will argue against each other. Those who had been abased will say to those who were proud: 'But for you, we would have been believers'

# 3638

Then, those who were proud will say to those who were abased, 'Was it we who barred you from the Guidance after it had come to you? No, you yourselves were sinners'

# 3639

Those that were abased will say to those who were proud: 'Rather, it was scheming night and day, when you ordered us to disbelieve in Allah and set up equals to Him' And they will regret in secret when they see the punishment and We put (iron) fetters on the necks of the unbelievers. Shall they be recompensed except for what they were doing?

# 3640

We never sent a warner to a village except that those (who lived) in luxury said: 'We disbelieve in the Message you have been sent with'

# 3641

And they said: 'We have been given an abundance of wealth and children we shall never be punished'

# 3642

Say: 'My Lord outspreads and withholds His provision to whomsoever He will. But most people do not know'

# 3643

It is neither your riches nor your children that shall bring you close in nearness to Us, except he who believes and does good work. For those their awaits a double recompense for their deeds, they shall live in safety in their lofty chambers.

# 3644

But those who labor to negate Our verses shall be arraigned in to the punishment.

# 3645

Say: 'My Lord outspreads and withholds His provision to whomsoever He will of His worshipers. Whatsoever you expend He will replace it. He is the Best of providers'

# 3646

On the Day when He gathers them all together, He will say to the angels: 'Was it you that these worshipped'

# 3647

'Exaltations to You' they will answer. 'You are our Guardian other than them! No, rather they worshipped the jinn, and it was them which most believed'

# 3648

Therefore, today none of you shall have the power to either benefit or harm one another' To the evildoers We shall say: 'Taste the punishment of the Fire, which you belied'

# 3649

When Our clear verses, are recited to them, they say: 'This is nothing but a man whose wish is to prevent you from that which your fathers used to worship. 'And they say: 'This is nothing but a forged lie' And those who disbelieve say of the truth when it reaches them: 'This is nothing but clear sorcery.?

# 3650

Yet We have not given them any Books to study, nor, before you, have We sent them a warner.

# 3651

Those who have gone before them belied, yet they did not reach a tenth of what We gave them; yet they belied My Messengers. And how was (My) rejection (their destruction)!

# 3652

Say: 'I give you only one admonition, that you stand before Allah either two by two, or one by one and reflect. There is no madness is in your companion. He (Prophet Muhammad) is only a warner to you, before a terrible punishment'

# 3653

Say: 'I ask no wage of you; that shall be yours. My wage is only upon Allah and He is Witness over everything'

# 3654

Say: 'My Lord hurls the truth the Knower of the Unseen'

# 3655

Say: 'Truth has come. Falsehood has vanished and shall return no more.'

# 3656

Say: 'If I go astray, then I go astray only against myself; if I am guided it is because of that which my Lord has revealed to me. He is the Hearer, and theNear'

# 3657

If you could only see when they (the unbelievers) are seized with terror, and there is no escape. They shall be seized from a nearby place,

# 3658

and say: 'We believe in it' But how can they reach from a place that is distant,

# 3659

since they disbelieved in it before, guessing at the Unseen from a distant place?

# 3660

And a barrier is set between them and that which they desire, as it was done before with their like; they were in suspicious doubt'

# 3661

Praise belongs for Allah, the Originator of the heavens and earth, who appointed the angels to be Messengers, with wings, two, three, and four. He increases the creation as He wills. Allah has power over all things.

# 3662

Whatever mercy Allah opens to people, none can withhold; and whatever He withholds none can release after Him. He is the Almighty, the Wise.

# 3663

People, remember the blessings of Allah to you. Except for Allah, is there any other creator who provides for you out of heaven and earth? There is no god except He. Where then do you turn?

# 3664

If they belie you, other Messengers have been belied before you. To Allah all matters are returned.

# 3665

People, the promise of Allah is true, so do not let this present life delude you, and do not let the deluder (satan) delude you about Allah.

# 3666

satan is indeed your enemy; therefore take him for an enemy. He calls his party so that they will become the companions of the Blaze.

# 3667

For the unbelievers awaits a terrible punishment, but for those who believe and do good deeds is forgiveness and a great recompense.

# 3668

What then of he whose evil deeds have been decorated fair to him and thinks them to be good? Allah leads astray whomsoever He will and whomsoever He will He guides. Do not let your soul be wasted in regrets for them; Allah has knowledge of all they do.

# 3669

Allah is He who sends the winds that stir up the clouds. Then, We drive them on to a dead land and revive the earth after it's death. Such is the Raising Up.

# 3670

He who wants might, the Might belongs to Allah altogether. To Him ascend good words, and the righteous deed He raises. But those who devise evil deeds theirs shall be a terrible punishment, and their plotting shall be annulled.

# 3671

Allah created you from dust, then from a (sperm) drop. Then he made you pairs. No female conceives or is delivered except by His Knowledge. He whose life is long, whatsoever is increased or decreased of his age is in a Clear Book. Surely, that is easy for Allah.

# 3672

The two seas are not alike. One is fresh, sweet and pleasant to taste, while the other is salt and bitter. Yet, from each you eat fresh flesh and bring forth out of it ornaments for you to wear. And you see the ships plow their course through it so that you may seek His bounty, and in order that you give thanks.

# 3673

He causes the night to enter into the day and the day into the night. He has subjected the sun and the moon each running for a named term. Such is Allah, your Lord. To Him belongs the Kingdom; and those whom you call upon, other than Him, do not possess even as much as the membrane of a datestone.

# 3674

If you supplicate to them they cannot hear your supplication, and if they heard, they cannot answer you. On the Day of Resurrection they will disown your associating. None can tell you like He who is the Aware.

# 3675

People, it is you who are in need of Allah. He is the Rich, the Praised.

# 3676

He can put you away, if He will, and bring a new creation

# 3677

this is not a great matter for Allah.

# 3678

No laden soul shall bear another's load. If one is heavyburdened and calls for his load to be carried, nothing of it will be carried, not even if he is a close relative. You warn only those who fear their Lord in the Unseen, and establish the prayer. He who purifies himself, purifies himself for the good of his own soul. To Allah is the arrival.

# 3679

The blind and the seeing are not equal,

# 3680

nor are darkness and light.

# 3681

The shade and the hot wind are not equal,

# 3682

nor are the living and the dead equal. Allah makes to hear whosoever He will, but you cannot make those who are in their graves hear.

# 3683

You (Prophet Muhammad) are but a warner.

# 3684

We have sent you with the truth, a bearer of glad tidings and warning, for there is no nation, that has not had a warner pass away in it.

# 3685

If they belie you, those before them also belied. Their Messengers came to them with clear signs; the Psalms, and the Illuminating Book.

# 3686

Then I seized those who disbelieved, and how was My rejection!

# 3687

Did you not see how Allah sends down water from the sky and with it brings forth different colored fruits? In the mountains there are paths of various colors, of white and red, and jetblack.

# 3688

People too, and beasts and cattle have their different colors. But it is only those amongst His worshippers that fear Allah who have knowledge. Indeed, Allah is the Almighty and the Forgiving.

# 3689

Indeed, those who recite the Book of Allah and establish their prayers and spend, in secret and in public of that which We have provided them, look for a trade that does not come to nothing,

# 3690

so that He may pay them in full their wages and enrich them from His bounty. Surely, He is the Forgiver and the Thanker.

# 3691

That which We have revealed to you of the Book is the truth and it confirms what was before it. Allah is Aware and sees His worshipers.

# 3692

Then, We gave the Book as an inheritance to those of our worshipers whom We chose. Among them, is he who was harmful to himself, and some who minimize, and some who, by the permission of Allah, race in charity, this is the greatest virtue.

# 3693

They shall enter the Gardens of Eden, where they shall be adorned with bracelets of gold and with pearls, and there, their robes shall be of silk.

# 3694

They shall say: 'Praise belongs to Allah who has removed all sorrow from us. Indeed, our Lord is the Forgiver, the Thanker.

# 3695

Through His bounty He has made us to live in the abode of Everlasting Life, where neither weariness nor fatigue shall touch us'

# 3696

As for the unbelievers, theirs is the Fire of Gehenna. They shall neither be done away with nor die, and its punishment shall never be lightened for them. As such shall We recompense every unbeliever.

# 3697

There they will cry out: 'Our Lord, bring us out, and we will do good, other than what we have done' What, did We not make your lives long enough to remember for whosoever would remember? A warner came to you, so taste now! None shall help the harmdoers.

# 3698

Allah knows the Unseen in the heavens and earth. He knows that which is in the innermost of the chests.

# 3699

It is He who made you caliphs in the earth. He who disbelieves, his disbelief shall be charged against him. The unbelievers disbelief does nothing for them, except, increase them in hate with Allah their disbelief increases the unbelievers only in loss.

# 3700

Say: 'Have you considered your associates who you call upon, other than Allah? Show me what they have created in the earth! Or, have they a partnership in the heavens' Or, have We given them a Book so that they have proof of it? No, the harmdoers promise each other nothing else but delusion.

# 3701

It is Allah who holds the heavens and the earth lest they vanish. Should they vanish, none would hold them after Him. He is the Clement, the Forgiving.

# 3702

They solemnly swore by Allah that if a warner came to them they would be more rightly guided than any other of the nations. Yet, when a warner came to them, it only increased their aversion,

# 3703

behaving arrogantly in the land and devising evil. But, evil devising coils only those who do it. Do they look except for the ways of former nations? You shall never find any change in the way of Allah.

# 3704

What, have they not journeyed through the land and seen the end of those who went before them? They were stronger and mightier than themselves. Allah! There is nothing in heavens or earth that can frustrate Him, He is the Knower, the Able.

# 3705

If Allah should take people to task for what they have earned, He would not leave one creature that crawls upon the face (of the earth)! But, He is deferring them to a named time. And when their time comes, indeed, Allah is the Seer of His worshipers.

# 3706

YaSeen.

# 3707

By the Wise Koran,

# 3708

you (Prophet Muhammad) are truly among the Messengers sent

# 3709

upon a Straight Path.

# 3710

The sending down of the Mighty, the Most Merciful

# 3711

so that you may warn a people whose fathers were not warned, and so were heedless.

# 3712

The Phrase has become obligatory upon most of them, yet they do not believe.

# 3713

We have bound their necks with fetters up to their chin, so that their heads are raised and cannot be lowered.

# 3714

We have set a barrier before them and a barrier behind them, and, We have covered them so that they do not see.

# 3715

It is the same whether you have warned them or you have not warned them, they do not believe.

# 3716

You only warn he who follows the Remembrance and fears the Merciful in the Unseen. Give to him glad tidings of forgiveness and a generous wage.

# 3717

Surely, it is We who revive the dead and write down what they have forwarded and what they have left behind; We have counted everything in a Clear Book.

# 3718

Give to them a parable; to the people of the village there came Messengers,

# 3719

We sent to them two, but they belied them so We reinforced them with a third. They said: 'We have surely been sent as Messengers to you'

# 3720

But they said: 'You are only humans like ourselves. The Merciful has not sent down anything, your speech is but lies'

# 3721

They said: 'Our Lord knows that we are Messengers to you.

# 3722

And it is only for us to deliver a Clear Message'

# 3723

They answered: 'We predict evil of you. If you do not desist, we will stone you and a painful punishment from us will befall you'

# 3724

They said: 'Your prediction is with you, if you are reminded. Surely, you are but a wayward nation'

# 3725

Then, a man came running from the furthest part of the village 'My nation' he said, 'follow the Messengers,

# 3726

follow those who ask no wage of you and are rightly guided.

# 3727

Why should I not worship Him who has originated me and to whom you shall all be returned?

# 3728

What, shall I take, other than Him, gods whose intercession, if the Merciful desires to afflict me, cannot help me at all, and they will never save me?

# 3729

Surely, I should then be in clear error.

# 3730

I believe in your Lord, so hear me'

# 3731

It was said (to him): 'Enter Paradise' and he said: 'Would that my people knew

# 3732

that my Lord has forgiven me, and caused me to be amongst the receivers of generosity'

# 3733

And We did not send down to his nation after him any army from heaven, neither would We send any down.

# 3734

It was only one Shout and they were silent, still.

# 3735

Woe, for those (unbelieving) worshipers! They mocked every Messenger that came to them.

# 3736

Have they not seen how many generations We destroyed before them? They shall never return to them,

# 3737

all shall be arraigned before Us.

# 3738

The dead land is a sign for them. We revive it, and from it produce grain from which they eat.

# 3739

And there We made gardens of palms and vines, and in it We caused fountains to gush forth,

# 3740

so that they might eat of its fruit and the labor of their hands. Will they not give thanks?

# 3741

Exaltations to Him who created pairs of all the things the earth produces and of themselves, and that of which they have no knowledge.

# 3742

A sign for them is the night. From it We withdraw the day and they are in darkness.

# 3743

The sun runs to its fixed restingplace; that is the decree of the Almighty, the Knower.

# 3744

And the moon, We have determined it in phases till it returns like an old palmbranch.

# 3745

The sun shall not outstrip the moon, nor shall the night outstrip the day. Each is floating in an orbit.

# 3746

And a sign for them is that We carried their offspring in the laden Ark (of Noah).

# 3747

And We have created for them the like of it in which they board.

# 3748

We drown them if We will, then they have none to cry to, nor can they be saved,

# 3749

except through Our Mercy and as enjoyment for awhile.

# 3750

When it is said to them: 'Have fear of that which is before you and behind you in order that you find mercy'

# 3751

Yet there never comes to them any sign of their Lord's signs, but they turn away from it.

# 3752

And when it is said to them: 'Spend of that which Allah has given you' the unbelievers say to the believers: 'Are we to feed those whom Allah can feed if He chooses? Surely, you are only in clear error'

# 3753

They also say: 'When will this promise be, if what you say is true'

# 3754

They await but one Shout, which will seize them while they dispute.

# 3755

Then they will be unable to make a will, nor shall they return to their kinsmen.

# 3756

And the Horn is blown, and, from the graves they rush forth to their Lord.

# 3757

'Woe for us' they will say. 'Who has roused us from our sleepingplace? This is what the Merciful promised; the Messengers have spoken the truth'

# 3758

And it is but one Shout and they are all arraigned before Us.

# 3759

Today, no soul shall be wronged a thing. You shall not be recompensed except according to your deeds.

# 3760

Indeed, the companions of the Garden are this Day busy in their rejoicing.

# 3761

Together with their spouses, they shall recline on couches in the shade.

# 3762

They shall have fruits and all that they call for.

# 3763

Peace, a saying from the Most Merciful Lord.

# 3764

(And He will say): 'Distance yourselves, O sinners, this Day.

# 3765

Children of Adam, did I not make a covenant with you, that you should not worship satan he is surely a clear enemy to you

# 3766

and that you worship Me? Surely, that is the Straight Path.

# 3767

Yet he has led many a host of you astray, did you not understand?

# 3768

This, then is Gehenna (Hell), that which you were promised.

# 3769

Roast well therein this Day for you were unbelievers'

# 3770

This Day We set a seal on their mouths and their hands speak to Us, and their feet will testify to their earnings.

# 3771

Had it been Our will We would have obliterated their sight so that they raced to the Path. But, how would they see?

# 3772

Had it been Our will We would have transmuted them (into monkeys, pigs and stones) where they were, so that they could neither go forward nor yet return.

# 3773

To whoever We give a long life We make him stoop. Do they not understand?

# 3774

We have not taught him (Prophet Muhammad) poetry, nor does it become him. This is only a Remembrance and a Clear Holy Reading (Koran)

# 3775

that he may warn the living, and so that Judgement may be passed against the unbelievers.

# 3776

Have they not seen how We have created for them the cattle they master with Our Hands?

# 3777

We have subdued these to them, and some of them they ride and some of them they eat;

# 3778

they also have other uses in them and drinks. What, will they not give thanks!

# 3779

And yet they have taken gods, other than Allah, so that they might helped!

# 3780

They cannot help them, for them (the socalled) army are brought (with them to Hell).

# 3781

So do not let their sayings grieve you. Surely, We have knowledge of what they hide and all that they reveal.

# 3782

Has the human not seen how We created him from a drop (of sperm)? Yet he is a clear opponent.

# 3783

And he has struck for Us a parable, and forgotten his own creation. He asks: 'Who will quicken the bones after they have decayed'

# 3784

Say: 'He will quicken them who originated them the first time; He has knowledge of every creation;

# 3785

who has made fire for you from the green tree with which you kindle'

# 3786

Is He who created the heavens and the earth unable to create their like? Yes, indeed, He is the Creator, the Knower.

# 3787

When He wills a thing, His command is to say to it 'Be', and it is!

# 3788

Exaltations to Him in whose Hand is the Kingdom of all things, and to Him you will be returned.

# 3789

By the aligners (angels) aligning.

# 3790

and the drivers driving,

# 3791

and those who recite the Remembrance

# 3792

surely, your God is One,

# 3793

the Lord of the heavens and the earth and of all that is between them; the Lord of the Easts.

# 3794

We have adorned the lower heaven with the adornment of the planets,

# 3795

a protection against every rebel satan;

# 3796

so they cannot listen to the High Assembly, for they are pelted from every side.

# 3797

They are rejected and theirs is an everlasting punishment;

# 3798

except such as snatches a fragment, and he is pursued by a piercing flame.

# 3799

So ask them, are they stronger in constitution, or those whom We have created. We have created them of sticky clay.

# 3800

No, you marvel, while they scoff.

# 3801

When they are reminded, they do not remember.

# 3802

When they are shown a sign, they scoff at it

# 3803

and say: 'This is nothing but clear sorcery'

# 3804

What, when we are dead and become dust and bones, shall we be resurrected.

# 3805

What, and our forefathers, the ancients'

# 3806

Say: 'Yes, but worthless'

# 3807

It will be but one Shout, then see, they are watching

# 3808

and they will say: 'Woe for us. This is the Day of Recompense'

# 3809

This is the Day of Decision which you belied.

# 3810

Gather together the evildoers, their wives, and that they were worshipping,

# 3811

other than Allah, and guide them to the Path of Hell!

# 3812

And halt them so that they may be questioned.

# 3813

'Why do you not help one another?

# 3814

No, today they will resign themselves in submission,

# 3815

and approach each other with questions,

# 3816

saying: 'You used to come to us from the right hand'

# 3817

But they reply: 'Rather, you were not believers.

# 3818

We had no authority over you, but you were an insolent nation.

# 3819

The statement of Our Lord is realized against us, and we are tasting it,

# 3820

we perverted you, indeed, we were perverts'

# 3821

Therefore, on that Day they will all share Our punishment.

# 3822

As such We shall deal with the evildoers.

# 3823

For when it was said to them: 'There is no god except Allah' they were always proud

# 3824

and said: 'Are we to renounce our gods for the sake of a mad poet'

# 3825

No, indeed, he has brought the truth, and confirmed the Messengers.

# 3826

You shall certainly taste the painful punishment:

# 3827

but you shall not be recompensed except for what you were doing.

# 3828

But for the sincere worshipers of Allah,

# 3829

there is waiting for them a known provision;

# 3830

fruits. And they are receivers of generosity

# 3831

in the Gardens of Delight,

# 3832

sitting face to face upon couches,

# 3833

a goblet from a spring shall be passed round to them

# 3834

white, a delight to the drinkers,

# 3835

there is neither sickness in it, nor intoxication.

# 3836

And with them will be maidens (houris) who restrain their wide glances

# 3837

as if they were hidden pearls.

# 3838

They will go to one another asking each other questions.

# 3839

One of them will say: 'I had a companion

# 3840

who would say: "Are you among the believers (of the resurrection)?

# 3841

When we are dead and turned to dust and bones, shall we be recompensed?"

# 3842

And he will reply: 'Are you looking down (into Hell)'

# 3843

Then, he will look and see him in the midst of Hell.

# 3844

'By Allah' he will say, 'you almost destroyed me!

# 3845

But for the Favor of Allah I should have surely been among those who were arraigned (with you in Hell).

# 3846

What then, shall we not die

# 3847

except our first death, and shall we not be punished'

# 3848

Indeed, this is the mighty victory,

# 3849

and for the like of this let the workers work.

# 3850

Is this a better hospitality or the tree of AzZakkum!

# 3851

We have made this (tree) a trial for the evildoers.

# 3852

It is a tree that grows from the bottom of Hell;

# 3853

its spathes are like the heads of satans

# 3854

on it they shall feed, and with it they shall fill their bellies.

# 3855

On top of it they shall have a brew of boiling water,

# 3856

then their return is to Hell.

# 3857

They found their fathers in error,

# 3858

yet they run in their footsteps,

# 3859

yet before them most of the ancients went astray,

# 3860

though We had sent among them warners.

# 3861

See then the end of those who were warned,

# 3862

except the sincere worshipers of Allah.

# 3863

Noah called to Us, and We are the Best to answer.

# 3864

We saved him and his people from the great distress,

# 3865

and We made his offspring the survivors.

# 3866

And We let it remain upon him in the latter:

# 3867

'Peace be upon Noah among all the worlds'

# 3868

As such We recompense the gooddoers,

# 3869

he was one of Our believing worshipers.

# 3870

Afterwards We drowned the others.

# 3871

Of his party was Abraham.

# 3872

(Remember when) he came to his Lord with a pure heart;

# 3873

and when he said to his father and to his nation: 'What do you worship?

# 3874

It is falsehood that you desire gods other than Allah!

# 3875

What do you think of the Lord of the Worlds'

# 3876

He cast a glance at the stars

# 3877

and said: 'Surely, I am sick (of what you worship)'

# 3878

But they turned their backs and went away from him.

# 3879

Then he turned to their gods, and said: 'What do you eat?

# 3880

What is the matter with you, that you do not speak'

# 3881

And he turned upon them striking them with the right hand.

# 3882

Thereafter they (the people) came to him in haste.

# 3883

He said: 'Do you worship what you, yourselves have carved

# 3884

when it is Allah who created you and all that you do'

# 3885

They replied: 'Build for him a building and cast him into the fire'

# 3886

Their desire was to outwit him, but We made them to be the humiliated.

# 3887

He said: 'I will go to my Lord; He will guide me.

# 3888

My Lord, grant me a righteous (son)'

# 3889

And We gave him the glad tidings of a very gentle son (Ishmael).

# 3890

And when he reached the age of traveling with him, he said: 'My son, while I was sleeping I saw that I shall slaughter (sacrifice) you, tell me what is your opinion' He replied: 'Father, do as you are ordered (by Allah). Allah willing, you shall find me one of those who are steadfast'

# 3891

And when they had both submitted, and his son had laid down prostrate upon his forehead,

# 3892

We called to him, saying: 'O Abraham,

# 3893

you have confirmed your vision' As such We recompense the gooddoers.

# 3894

That was indeed a clear trial.

# 3895

So, We ransomed him with a mighty sacrifice,

# 3896

and We let it (the beautiful praise) remain upon him in the latter (generations),

# 3897

'Peace be upon Abraham'

# 3898

As such We recompense the gooddoers.

# 3899

He was one of Our believing worshipers.

# 3900

Then, We gave him the glad tidings of Isaac, a Prophet, one of the righteous,

# 3901

and We blessed him and Isaac, and from their offspring are some gooddoers, and others who clearly wronged themselves.

# 3902

We also favored Moses and Aaron

# 3903

and We saved them with their nation from a great distress.

# 3904

We helped them, and they became victorious,

# 3905

and We gave them the Clear Book,

# 3906

and guided them upon the Straight Path.

# 3907

And We let it (the beautiful praise) remain upon on both of them in the latter (generations),

# 3908

'Peace be upon Moses and Aaron'

# 3909

As such We recompense the gooddoers.

# 3910

They were among Our believing worshipers.

# 3911

And Elias (El Yaseen) was among the Messengers.

# 3912

He asked his people: 'Do you not fear (Allah)?

# 3913

Do you call on Ba'lan (the idol Baal) and abandon the Best Creator,

# 3914

Allah is your Lord and the Lord of your fathers, the ancients'

# 3915

But they belied him, so they will be among the arraigned (in Hell),

# 3916

except the sincere worshipers of Allah.

# 3917

And We let it (the beautiful praise) remain upon him in the latter (generations),

# 3918

'Peace be upon El Yaseen'

# 3919

As such We recompense the gooddoers.

# 3920

He was among Our believing worshipers.

# 3921

Lot, too, was among the Messengers.

# 3922

We saved him and all his kinsmen,

# 3923

except an old woman who lingered,

# 3924

and We destroyed the others.

# 3925

You pass by them in the morning

# 3926

and at night, will you not understand?

# 3927

Jonah, too, was one of the Messengers.

# 3928

He ran away to the laden ship,

# 3929

and cast lots, and he was among the losers (of the lots that were cast).

# 3930

So the whale swallowed him, for he was blameworthy,

# 3931

and had he not been among those who exalt (Allah),

# 3932

he would have lingered in its belly till the Day they are resurrected.

# 3933

But We cast him, upon the shore, and he was ill,

# 3934

and We caused a pumpkin tree to grow over him.

# 3935

Then We sent him to a hundred thousand or more,

# 3936

and they believed, and We gave them enjoyment for awhile.

# 3937

Now, ask them, has your Lord daughters, and they sons?

# 3938

Or, did We create the angels females while they were witnessing?

# 3939

Then is it of their lying that they say:

# 3940

'Allah has begotten' They are truly liars.

# 3941

Has He chosen daughters above sons?

# 3942

What is the matter with you? How do you judge?

# 3943

What, will you not remember?

# 3944

Or, do you have a clear authority?

# 3945

Bring your Book, if what you say is true!

# 3946

They assert kinship between Him and the angels. But the angels know that they (the liars) will be arraigned (in Hell).

# 3947

Exaltations to Allah above what they describe,

# 3948

except for the sincere worshipers of Allah.

# 3949

But as for you, and that you worship,

# 3950

you shall tempt none against Him

# 3951

except for he who shall roast in Hell.

# 3952

(Gabriel said to the Prophet): 'Each of us has a known place.

# 3953

We are surely those who are arranged in ranks.

# 3954

And we are they who exalt (Allah)'

# 3955

What, would they then say:

# 3956

'If only we had a reminder from the ancients,

# 3957

we would have been sincere worshipers of Allah'

# 3958

But they disbelieve in it (the Koran), but soon they shall know!

# 3959

Our Word had already preceded Our worshipers, the Messengers,

# 3960

that they shall receive Our help

# 3961

and Our armies shall be the victors.

# 3962

So turn (away) from them for a while.

# 3963

See them and soon they shall see.

# 3964

What, do they seek to hasten Our punishment?

# 3965

When it descends upon their courtyards, evil will be the morning of those forewarned.

# 3966

So turn (away) from them for a while,

# 3967

and see, soon they shall see!

# 3968

Exaltations be to your Lord, the Lord of Might, above that they describe!

# 3969

Peace be on the Messengers.

# 3970

And praise belongs to Allah, Lord of the Worlds.

# 3971

Saad, by the Holy Reading (Koran) of the Remembrance.

# 3972

No, the unbelievers exalt in their division.

# 3973

How many generations have We destroyed before them. They called: 'The time is neither of escape, nor safety'

# 3974

They marvel now that, from among themselves, a warner has come to them. The unbelievers say: 'This is a lying sorcerer.

# 3975

What, has he made the gods One God? This is indeed a wondrous thing'

# 3976

Their assembly left (saying): 'Go, and be patient to your gods, this is something to be desired.

# 3977

We never heard of this in the former religion. It is nothing but an invention.

# 3978

What, out of all of us, has the Remembrance been sent down to him (Prophet Muhammad)' No, they are doubtful about My Remembrance, no, they have not yet tasted My punishment.

# 3979

Or, have they the treasuries of the Mercy of your Lord, the Almighty, the Giving?

# 3980

Or, is theirs the Kingdom of the heavens and the earth and all that is between them? Then let them ascend by (their) means!

# 3981

The army is defeated as (were) the confederates.

# 3982

Before them the nations of Noah, Aad and Pharaoh, and he of the tentpegs belied,

# 3983

Thamood, the nation of Lot and the dwellers of the Thicket such were the confederates.

# 3984

There was not one of those that did not belie the Messengers. Therefore, My retribution was realized.

# 3985

These only wait for a single Shout for which there will be no delay.

# 3986

They say: 'Our Lord, hasten to us our share before the Day of Recompense'

# 3987

Bear patiently with what they say, and remember Our worshiper David, a man of might. He was ever turning in repentance.

# 3988

We subjected the mountains to exalt (Me) with him in the evening and at sunrise,

# 3989

and the birds, too, gathered each obedient to him.

# 3990

We made his kingdom strong and gave him wisdom and decisive speech.

# 3991

Has the news of the dispute reached you (Prophet Muhammad)? When they scaled the Sanctuary

# 3992

they went to David whereupon he was afraid of them, but they said: 'Do not be afraid, we are two that have a dispute, one of us has wronged the other. Judge between us justly, and do not transgress, and guide us to the Right Path.

# 3993

This, my brother has ninetynine ewes, but I have only one ewe (a female sheep). He said: "Give her into my keeping" and overcame me in the argument'

# 3994

He (David) replied: 'He has without doubt wronged you in seeking to add your ewe to his sheep. Many intermixers wrong one another; except those who believe, and do good works, and they are few indeed' David realized that We had tried him and sought the forgiveness of his Lord and fell down, prostrate and repented.

# 3995

So, We forgave him that, and he has a near place with Us and a fine return.

# 3996

(We said): 'David, We have made you a caliph in the earth. Judge with justice among people and do not yield to your own preference in case it should lead you from the Path of Allah. Surely, a terrible punishment awaits those who stray from the Path of Allah, because they forget the Day of Reckoning'

# 3997

It was not in falsehood that We created the heavens and the earth and all that is between them. That is the thought of the unbelievers. But woe to the unbelievers because of the Fire!

# 3998

Are We to make those who believe and do good works the same as those who corrupt the earth? Are We to make the righteous as the wicked?

# 3999

It is a Blessed Book that We have sent down to you (Prophet Muhammad), so that those possessed with minds might ponder its verses and remember.

# 4000

We gave Solomon to David; and he was an excellent worshiper, he was penitent.

# 4001

When his dressage steeds were presented to him in the evening,

# 4002

he said: 'Indeed I have loved the love of good things better than the remembrance of my Lord until the sun has vanished behind a veil.

# 4003

Bring them back to me' And he hacked their legs and necks (slaughtering them for Allah).

# 4004

Indeed, We tried Solomon and placed a body (of a child) upon his throne, then he repented.

# 4005

He said: 'Forgive me my Lord, and give me a kingdom the like of which will not befall any after me, surely, You are the Giver'

# 4006

So We subjected the wind to him, so that it ran softly by his command wherever he wished;

# 4007

and the satans, every builder and diver

# 4008

and others joined together by (iron) fetters.

# 4009

'This is Our gift, give or withhold without reckoning'

# 4010

And he has a place near to Us, and a fine return.

# 4011

Also, remember Our worshiper Job. He called out to his Lord, (saying): 'satan has afflicted me with harm and pain'

# 4012

(We said): 'Stamp your foot on the ground, here is cool water with which to wash and a drink'

# 4013

We restored to him to his family and like those with them, a mercy from Us and a reminder to a nation that understand.

# 4014

(We said to him): 'Take a bundle of rushes and strike with it; and do not break your oath' We found him to be patient, a good worshiper and he was penitent.

# 4015

Also, remember Our worshipers Abraham, Isaac, and Jacob, those of might and vision.

# 4016

Indeed, We purified them with a most pure quality, the remembrance of the Everlasting Life.

# 4017

Indeed with Us they are among the chosen, the excellent.

# 4018

Also, remember our worshipers Ishmael, Elisha, and ThulKifl, they are among the good.

# 4019

This is a Reminder, and indeed for the cautious is a fine return,

# 4020

the Gardens of Eden whose gates shall be open to them,

# 4021

in which they will recline, and call for abundant fruit and drink therein.

# 4022

And with them will be maidens of equal age with modest gaze.

# 4023

'This is what you are promised on the Day of Recompense,

# 4024

this is Our unending provision'

# 4025

All of this; but, for the proud there is an ill return.

# 4026

They shall roast in (the Fire) of Gehenna, an evil cradling.

# 4027

All of this; so let them taste it, boiling water and pus,

# 4028

and other similar to it, joined together.

# 4029

(We shall say to their leaders): 'This is a troop rushing in with you, there is no welcome for them, they shall roast in the Fire'

# 4030

But they will say: 'No, it is you that has no welcome. It was you who brought it upon us, an evil place'

# 4031

They will say: 'Our Lord, give those who brought this upon us double the punishment of the Fire'

# 4032

And they will say: 'Why do we not see the men that we counted as being among the wicked in here?

# 4033

Have we taken them in mockery? Or, have our eyes swerved from them?'

# 4034

Surely that is true the disputing of the inhabitants of the Fire

# 4035

Say: 'I am only a warner. There is no god except Allah, the One, the Conqueror,

# 4036

the Lord of the heavens and the earth and all that is between them; the Almighty, the Forgiving'

# 4037

Say: 'This is a mighty message

# 4038

from which you turn away.

# 4039

I had no knowledge of the High Assembly's dispute.

# 4040

This alone is revealed to me, I am only a clear warner'

# 4041

When your Lord said to the angels: 'I am creating a human from clay,

# 4042

after I have shaped him and breathed of My spirit (I created) into him, fall down prostrate before him'

# 4043

So all the angels prostrated themselves

# 4044

except iblis (satan, the father of the jinn), he became too proud, for he was one of the unbelievers.

# 4045

He (Allah) said: 'iblis, what prevented you from prostrating yourself towards that which I have created with My Hands? Have you become too proud, or areyou among the grand'

# 4046

He (satan) replied: 'I am better than he. You created me from fire, and You created him from clay'

# 4047

'Begone' said He, 'you are stoned'.

# 4048

'My curse shall rest on you until the Day of Recompense'

# 4049

He (satan) replied: 'Respite me my Lord till the Day of Resurrection'

# 4050

He (Allah) said: 'You are among those that are respited

# 4051

till the Day of the known time'

# 4052

He (satan) said: 'I swear by Your Might, that I will seduce all of them

# 4053

except those among them who are Your sincere worshipers'

# 4054

He (Allah) said: 'This is the truth, and I speak the truth:

# 4055

I shall certainly fill Gehenna with you and every one of them that follows you'

# 4056

Say (Prophet Muhammad): 'For this I ask of you no wage, and I am not of those who take things upon themselves.

# 4057

This is nothing else but a reminder to all the worlds,

# 4058

and after a while you shall know its news'

# 4059

The sending down of the Book is from Allah, the Almighty, the Wise,

# 4060

We have sent down the Book with the truth to you (Prophet Muhammad), therefore worship Allah, and make your religion sincerely His.

# 4061

Is it not that the sincere religion belongs to Allah? As for those who choose guardians, other than Him, (saying): 'We only worship them so that they will bring us near to Allah' Indeed, Allah will judge between them concerning their differences. Indeed, Allah does not guide he who is an unthankful liar.

# 4062

If Allah had desired to take a son, He would have chosen whatever He willed out of His creation. Exaltations to Him! He is Allah, the One, the Conqueror.

# 4063

He created the heavens and the earth in truth, wrapping the night about the day and wrapping the day about the night, He has subjected the sun and the mooneach to run for a stated term. Is He not the Almighty, the Forgiving?

# 4064

He created you from a single soul, then from it He created its spouse. And He sent down to you eight pairs of the cattle. He creates you in your mothers' womb, creation after creation, in three (stages of) darkness. Such then is Allah, your Lord. For Him is the Kingdom. There is no god except Him. How, then, can you turn away?

# 4065

If you disbelieve, Allah is Rich, independent of you. Yet He does not approve of disbelief to His worshipers, but if you believe He will approve it in you. No laden soul shall bear another's load. Then, to Allah you shall return and He will tell to you what you have done. He knows the innermost of your chests.

# 4066

When an affliction befalls a human, he supplicates to his Lord and turns to Him (in repentance) yet, no sooner does He bestow on him His blessing than he forgets that for which he had just supplicated and sets up associates with Allah in order to lead (people) away from His Path. Say: 'Enjoy your disbelief for awhile, you shall surely be among the companions of the Fire.

# 4067

Or, is he who is obedient that prostrates himself and stands during parts of the night, being afraid of the Everlasting Life but hoping for the Mercy of the Lord (to be compared to the unbeliever)' Say: 'Are they equal, those who know and those who do not know' Only those with minds remember.

# 4068

Say: 'My worshipers who believe, fear your Lord. For those who do good in this world there is good and the earth of Allah is wide surely, those who are patient will be recompensed in full without count'

# 4069

Say: 'I am ordered to worship Allah making my religion sincerely His.

# 4070

I am ordered to be the first of those to be submissive (Muslims to Him)'

# 4071

Say: 'Indeed, if I rebel against my Lord I fear the punishment of a dreadful Day'

# 4072

Say: 'I worship Allah and make my religion sincerely His.

# 4073

(As for yourselves) worship what you will, other than Him' Say: 'The losers are surely those who lose themselves and their families on the Day ofResurrection. Is that not a clear loss'

# 4074

Above them they shall have layers of fire and beneath them layers. By this Allah puts fear into His worshipers' 'O My worshipers, fear Me'

# 4075

Those who shun the worship of idols and turn in repentance to Allah for them glad tidings. Therefore give good tidings to My worshipers,

# 4076

who listen to the Words and follow what is finest of it. These are they whom Allah has guided. They are those of understanding.

# 4077

Can you save from the Fire he whom against the word of punishment has been realized?

# 4078

As for those who fear their Lord, there await high mansions above which are built (more) high mansions, beneath which rivers flow, such is the promise ofAllah; Allah will not fail His promise.

# 4079

Have you not seen how Allah sends down water from the sky and threaded it as springs in the earth? Then, He brings forth plants of various colors, after which they wither, and you see them turning yellow, and then He makes them into broken stubble. Surely, in this there is a reminder for those of understanding.

# 4080

Is he whose chest Allah has expanded to Islam, so that he walks upon a light from his Lord (as those whose heart is sealed)? But woe to those whose hearts are hardened against the Remembrance of Allah! Those are in clear error.

# 4081

Allah has sent down the best discourse, a Book, consimilar in its oftrepeated (verses) that the skins of those who fear their Lord tremble; and thereafter their skins and hearts soften to the Remembrance of Allah. Such is the Guidance of Allah, whereby He guides whosoever He will; and whosoever Allah leads astray, he has no guide.

# 4082

Is he whose face is cautious of the evil of the punishment on the Day of Resurrection (to be compared to the unbeliever)! To the evildoers it shall be said:'Now taste that which you have been earning'

# 4083

Those who went before them also belied, then Our punishment overtook them from where they were unaware;

# 4084

Allah let them taste degradation in this present life, but the punishment of the Everlasting Life shall be greater if they but knew.

# 4085

Indeed, We have struck of every manner of parable for mankind in this Koran in order that they will remember.

# 4086

It is an Arabic Koran free from all crookedness, in order that they will be cautious.

# 4087

Allah has struck an example of a man shared by disagreeing partners, and a man who is owned by just one man, are the two equally alike? Praise belongs toAllah, but most of them do not know.

# 4088

You are mortal, and they are mortal

# 4089

then, on the Day of Resurrection, you shall dispute before your Lord.

# 4090

Who does greater evil than he who lies against Allah and belies the truth when it comes to him? Is there not a lodging in Gehenna (Hell) for the unbelievers?

# 4091

And he who comes with the truth, and confirms it, those are they who surely fear Allah.

# 4092

They shall have whatever they want with their Lord, that is the recompense of the gooddoers,

# 4093

that Allah may acquit them of the worst of what they did, and recompense with the finest wages for what they did.

# 4094

Is it not that Allah suffices His worshiper, even though they frighten you with those other than Him? He whom Allah leads astray has no guide.

# 4095

But he whom Allah guides, none can lead astray. Is not Allah the Almighty, capable of retribution?

# 4096

If you ask them who created the heavens and the earth, they will reply: 'Allah' Say: 'Do you think that, if Allah wills to afflict me those you call upon, other than Him, could remove His affliction, or, that if He wills to let me have mercy, they could withhold His Mercy' Say: 'Allah suffices me. Those who put their trust, put their trust in Him'

# 4097

Say: 'O nation, work according to your status, I am working according to my status, and soon you will know

# 4098

upon whom the punishment will come that will degrade him, and who will be overtaken by an everlasting punishment'

# 4099

Surely, We have sent down to you the Book for mankind with the truth. Whosoever is guided, is guided for himself, and he who goes astray, it is only for his own loss, you (Prophet Muhammad) are not their (compulsory) guardian.

# 4100

Allah takes away souls at the time of their death (the temporary death of sleep), and those who do not die during their sleep He withholds that upon whichHe has decreed death, but turns lose the other till a stated term. Surely, there are signs in this for a nation who contemplate.

# 4101

Have they chosen, other than Allah, to intercede for them? Say: 'What, even though they have no power at all, nor understanding'

# 4102

Say: 'Intercession belongs altogether to Allah. His is the Kingdom of the heavens and the earth. To Him you shall be returned'

# 4103

When Allah is mentioned alone, the hearts of those who do not believe in the Everlasting Life shrink in aversion. But when those, other than Him, are mentioned, see, they are filled with glad tidings.

# 4104

Say: 'O Allah, the Originator of the heavens and the earth who has knowledge of the Unseen and Visible, You shall judge between the differences of Your worshipers'

# 4105

On the Day of Resurrection, if the harmdoers owned all that is in the earth and as much again besides, they would offer it to ransom themselves from the evil of the punishment. From Allah will come to them that with which they had never reckoned,

# 4106

and the evils of their earnings will appear to them, and that which they mocked at will encompass them.

# 4107

When an affliction befalls a human he calls upon Us, but when We confer Our Favor on him, he says: 'I have only been given it on account of knowledge. 'Rather, it is but a trial, yet most do not know.

# 4108

Those before them said the same, but what they earned did not help them;

# 4109

and the evil of their earnings coiled upon them. The harmdoers among these will also be coiled by the evils of their earnings, they will be unable to defeat it.

# 4110

Do they not know that Allah outspreads and withholds His provision to whosoever He will? Surely, there are signs in this for a believing nation.

# 4111

Say: 'O My worshipers, who have sinned excessively against themselves, do not despair of the Mercy of Allah, surely, Allah forgives all sins. He is theForgiver, the Most Merciful.

# 4112

Turn to your Lord and surrender yourselves to Him before the punishment overtakes you, for then you will not be helped.

# 4113

Follow the best of what has been sent down from your Lord before the punishment overtakes you suddenly, while you are unaware'

# 4114

Lest any soul should say: 'Sadly, I have neglected my duty to Allah and was of those that mocked'

# 4115

Or, lest it should say: 'If Allah had only guided me I would have been one of the cautious'

# 4116

Or, lest when it sees the punishment should say: 'O that I might return, and be among those that did good'

# 4117

'Indeed, My verses did come to you, but you belied them. You were proud and became one of the unbelievers'

# 4118

On the Day of Resurrection, you shall see those who lied about Allah with blackened faces. In Gehenna is there not a lodging for those who were proud?

# 4119

But, Allah will save those who fear Him with their winnings (Paradise). No evil shall touch them, nor shall they ever grieve.

# 4120

Allah is the Creator of all things, and of all things He is the Guardian.

# 4121

To Him belong the keys of the heavens and the earth. Those who disbelieve in the verses of Allah they are the losers.

# 4122

Say: 'O you who are ignorant, is it other than Allah that you would order me to worship'

# 4123

It has already been revealed to you and to those who have gone before you, that if you associate (partners) with Allah, your works would be annulled and you will be among the losers.

# 4124

No, worship Allah and be with those who give thanks!

# 4125

They have not valued Allah with His true value. But on the Day of Resurrection, the entire earth will be in His grip, and the heavens shall be rolled up upon in His Right. Exaltations to Him! Exalted high is He above all that they associate!

# 4126

The Horn shall be blown and all who are in heavens and earth shall swoon, except those whom Allah wills. Then, the Horn will blow again and they shall stand and gaze.

# 4127

The earth will shine with the Light of its Lord, and the Book (of deeds) will be set (in place). The Prophets and witnesses shall be brought and the matter will be justly decided between them, and they will not be wronged.

# 4128

Every soul shall be paid in full according to what it has done, for He knows well what they did.

# 4129

In companies the unbelievers shall be driven into Gehenna. As they draw near, its gates will be opened and its keepers will ask them: 'Did there not come to you Messengers of your own, who recited to you the verses of your Lord and warned you of the encounter of this your Day' 'Yes indeed' they will answer. And the word of the punishment has been realized against the unbelievers.

# 4130

It will be said to them: 'Enter the gates of Gehenna and live there for ever' Evil is the lodging place of the proud.

# 4131

Then, those that feared their Lord shall be driven in companies into Paradise. When they draw near its gates will be opened, and its keepers will say to them: 'Peace be upon you, you have done well. Enter and live in it for ever'

# 4132

They will say: 'Praise belongs to Allah who has been true to His promise to us and given us the earth to inherit, that we shall live in Paradise wherever we wish' How excellent is the recompense of those that labor!

# 4133

And you shall see the angels encircling the Throne exalting with the praise of their Lord. And the matter will be justly decided between them, and it shall be said: 'Praise belongs to Allah, Lord of all the Worlds'

# 4134

HaMeem.

# 4135

The sending down of the Book is from Allah, the Almighty, the Knower.

# 4136

The Forgiver of sins and the Acceptor of repentance. Stern in retribution, the Bountiful, there is no god except He and to Him is the arrival.

# 4137

None but the unbelievers dispute concerning the verses of Allah. So do not be deluded by their going to and fro in the land.

# 4138

The nation of Noah before them belied, and so did the parties after them. Every nation strove against their Messenger to seize him, disputing with false arguments to refute the truth. Then I seized them, how was My punishment!

# 4139

And so it is that the Word of your Lord shall be realized against the unbelievers they are the inhabitants of the Fire.

# 4140

Those who bear the Throne and those around it exalt with the praise of their Lord and believe in Him. They ask forgiveness for the believers (saying): 'Our Lord, You embrace all things in mercy and knowledge. Forgive those who repent and follow Your Way. Shield them against the punishment of Hell.

# 4141

Admit them, Our Lord, to the Gardens of Eden which You have promised them, together with those who were righteous among their fathers, their wives, and their offspring. You are the Almighty, the Wise,

# 4142

and guard them against all evil deeds. Whosoever You guarded against evil deeds on that Day, surely, You have had mercy upon them, and that is indeed the mighty triumph'

# 4143

It shall be proclaimed to the unbelievers: 'Surely, the hatred of Allah for you is greater than your hatred of yourselves. You were called to belief but disbelieved.'

# 4144

They shall say: 'Our Lord, twice You have made us die, and twice You have given us life, now, we confess our sins. Is there any way we can be brought out of this'

# 4145

(They shall be answered): 'That is because you disbelieved when Allah alone was supplicated to, but when others were associated with Him you believed.' Judgement belongs to Allah, the Most High, the Great.

# 4146

It is He who shows to you His signs and sends down your provision from the sky. Yet no one remembers except he who is penitent.

# 4147

Supplicate then to Allah making your religion sincerely His, even though the unbelievers oppose it.

# 4148

Exalter in ranks, Owner of the Throne. He lets the spirit (the revelation) descend at His order on those of His worshipers whom He chooses, in order that He warns of the Day of the Meeting;

# 4149

the Day when they shall rise up with nothing hidden from Allah. And who is the Owner of the Kingdom on that Day? Allah, the One, the Conqueror!

# 4150

On that Day every soul shall be recompensed for its earnings and on that Day none shall be wronged. The reckoning of Allah is swift.

# 4151

Warn them against the Imminent Day when, choking with anguish, the hearts will be in their throats, the harmdoers will not have a single, loyal friend, and there will be no intercessor to be obeyed.

# 4152

He (Allah) knows the furtive looks of the eyes and what the chests conceal.

# 4153

With justice Allah will judge, but those upon whom they call, other than Him, can not judge anything at all! Allah is the Hearer, the Seer.

# 4154

Have they never journeyed through the land and seen what was the end of those who have gone before them? They were stronger than themselves in might and left firmer traces in the earth, but Allah seized them for their sinning, and they had none to protect them from Allah.

# 4155

That was because they disbelieved their Messengers when they came to them with clear signs, and so Allah seized them. Surely, He is Strong, and Stern in retribution.

# 4156

We sent Moses with Our signs and with clear authority

# 4157

to Pharaoh, Haman, and Korah. But they said: 'A sorcerer, a liar'

# 4158

And when he brought them the truth from Us they said: 'Kill the sons of those who believe with him, but spare their women' But the scheming of the unbelievers is always in error.

# 4159

Pharaoh said: 'Let me kill Moses, then let him call to his Lord! I am fearful that he will change your religion or cause mischief in the land'

# 4160

Moses said: 'I take refuge in my Lord and in your Lord from every proud (person), who does not believe in Day of Reckoning'

# 4161

But one of Pharaoh's people, who was in secret a believer, asked: 'Would you kill a man because he says: "My Lord is Allah?" He has brought you clear signs from your Lord. If he is lying, let his lie be on his head, but, if he is speaking the truth then at least a part of what he promises will befall you. Allah does not guide the lying sinner.

# 4162

O my nation, today the kingdom is yours and you are the masters in the land. But, if the might of Allah should come against us, who will help us' Pharaoh said: 'I only let you see what I see. I guide you to the path of righteousness'

# 4163

The one who believed said: 'I fear for you the like of the day of the confederates my nation,

# 4164

or, something similar to the circumstances of the nations of Noah, Aad, and Thamood, and those who came after them. Allah does not want to wrong His worshipers.

# 4165

And, my nation, I fear for you the Day of Calling,

# 4166

the Day when you will turn in retreat with none to protect you from Allah. He whom Allah leads astray has no guide.

# 4167

Before this, Joseph brought you clear signs, but you continued to be doubtful of that which he brought. When he passed away you said: "Allah will never send another Messenger after him." As such Allah leads astray the sinner, the doubter.

# 4168

Those who dispute the signs of Allah without any authority having reached them are very hateful before Allah and the believers. As such Allah sets a seal on every heart that is proud and arrogant.

# 4169

Pharaoh said: 'Haman, build me a tower that I can reach the ways,

# 4170

the ways of heaven so that I may look upon the God of Moses, because I think that he is a liar' And so Pharaoh's evil deeds were made to seem fair to him, and he was barred from the Way. And Pharaoh's guile came to nothing except ruin.

# 4171

He who was a believer said: 'Follow me, my nation, so that I may guide you to the Right Path.

# 4172

O my nation, the life of this world is nothing but an enjoyment, but surely, the life of the Everlasting Life is the stable abode.

# 4173

Those who do an evil deed shall only be rewarded with its like, but those who believe and do good works, either men and women, shall enter the Gardens of Paradise and are provided for without reckoning.

# 4174

My nation, how is it that I call you to salvation and you call me to the Fire?

# 4175

You call me to disbelieve in Allah and to associate with Him that of which I know nothing; while I call you to the Almighty, the Forgiving.

# 4176

There is no doubt that what you call me to has neither a call in this world, nor in the Everlasting Life. To Allah we shall return, and the excessive sinners are the inhabitants of the Fire.

# 4177

You will remember what I say to you. To Allah I commit my affair, surely, Allah sees His worshipers'

# 4178

Allah saved him from the evils that they devised, and an evil punishment encompassed Pharaoh's people.

# 4179

(Before) the Fire they shall be exposed morning and evening, and on the Day when the Hour comes, (it will be said): 'Admit the family of Pharaoh into the most terrible punishment'

# 4180

And when they argue with one another in Hell, the weak will say to the proud: 'We were your followers, will you help us against any share of the Fire'

# 4181

But those who were proud will reply: 'All of us are in it (Hell). Allah has judged between His worshipers'

# 4182

And those in the Fire will say to the keepers of Gehenna (Hell): 'Call your Lord to lessen our punishment for one day'

# 4183

But they will say: 'Did your Messengers not come to you with clear signs' 'Yes indeed' they will answer. And they will reply: 'Then you call' But the calling of the unbelievers is only in error.

# 4184

Surely, We shall help Our Messengers and the believers both in this world and on the Day when the witnesses rise.

# 4185

On that Day no excuse will benefit the harmdoers. Theirs shall be the curse, and an evil lodging.

# 4186

We gave Moses the Guidance and bequeathed upon the Children of Israel the Book

# 4187

for guidance and a reminder for those of understanding.

# 4188

Therefore have patience; the promise of Allah is true, and ask forgiveness of your sins, and exalt with the praise of your Lord in the evening and at dawn.

# 4189

(As for) those who dispute the verses of Allah without authority having been given to them, there is nothing in their chests but pride; that, they shall never attain. Therefore seek refuge in Allah, surely, He is the Hearer, the Seer.

# 4190

Indeed, the creation of heavens and earth is greater than the creation of mankind, yet most people do not know.

# 4191

The blind and the seeing are not equal, nor are those who believe and do good works, and the wrongdoer yet you seldom reflect.

# 4192

There is no doubt that the Hour is coming, yet most people do not believe.

# 4193

Your Lord has said: 'Call on Me and I will answer you. Those who are too proud to worship Me shall enter Gehenna utterly abject'

# 4194

It is Allah who made for you the night in which to rest and the day to see. Allah is bountiful to the people, yet most people do not give thanks.

# 4195

Such is Allah, your Lord, the Creator of all things. There is no god except He. How then can you turn away from Him?

# 4196

As such those who disbelieve the signs of Allah turn away.

# 4197

It is Allah who has given you the earth as a fixed place, and the heaven for a canopy. He has shaped you and made you fine images, and provided you with goodness. Such is Allah, your Lord. Blessed be Allah, Lord of all the Worlds.

# 4198

He is the Living; there is no god except He. Supplicate to Him and make the religion sincerely His. Praise belongs to Allah, Lord of the Worlds!

# 4199

Say: 'I am forbidden to worship those whom you worship, other than Allah. Clear verses have come to me from my Lord and I am commanded to surrender to the Lord of the Worlds'

# 4200

It is He who created you from dust, then from a (sperm) drop, and then a (blood) clot. He then brings you forth as an infant, then you reach your strength, after which you come of age though some of you die before it and that you reach an appointed term, in order that you understand.

# 4201

It is He who gives life and makes to die, and when He decrees a thing, He says to it: 'Be' and it is!

# 4202

Do you not see how those who dispute about the verses of Allah how they are turned about?

# 4203

Those who belie the Book and that with which We sent Our Messengers shall soon know.

# 4204

When the fetters and chains are round their necks they shall be dragged

# 4205

into boiling water, then, into the Fire they shall be poured.

# 4206

It will then be asked of them: 'Where are those whom you associated,

# 4207

other than Allah' They will reply: 'They have gone astray from us. Indeed what we used to call upon before is nothing' Accordingly, Allah leads the unbelievers astray.

# 4208

(And it will be said): 'That is because you rejoiced on earth in things of which you had no right, and were very happy.

# 4209

Enter the gates of Gehenna and live there for ever. Evil is the lodging of the proud.

# 4210

Therefore have patience, the Promise of Allah is true. Whether We show you something of that We promise them or call you to Us, to Us they shall all return.

# 4211

We sent other Messengers before you; of some, We have already told you, of others We have not told you. Yet it was not for any Messenger to bring a verse except by the permission of Allah. And when the command of Allah comes the matter will be justly decided; and the vaindoers will be lost.

# 4212

It is Allah who has provided you with cattle, some that you ride and some that you eat,

# 4213

and for you there are other uses in them, and that upon them you may reach a need in your chests, and upon them and on ships you are carried.

# 4214

He shows you His signs. Now which of the signs of Allah do you disbelieve?

# 4215

Have they never journeyed through the land and seen what was the end of those who have gone before them? They were stronger than themselves in might and left firmer traces upon the earth; yet, whatsoever they earned did not help them.

# 4216

When their Messengers brought them clear verses they rejoiced in such knowledge as they had; but they were encompassed by that which they mocked.

# 4217

And when they saw Our Might, they said: 'We believe in Allah alone, and we disbelieve in that we used to associate with Him'

# 4218

But when they saw Our Might their belief did not benefit them! It is the way of Allah that has passed concerning His worshipers. There, the unbelievers shall be lost.

# 4219

HaMeem.

# 4220

A sending down from the Merciful, the Most Merciful.

# 4221

A Book, the verses of which are distinguished, an Arabic Koran for a nation who know.

# 4222

It bears glad tidings and a warning, yet most of them turn away and do not listen.

# 4223

They say: 'Our hearts are veiled from that to which you call us, and in our ears there is heaviness. And between us and you is a veil. So work (as you will) and we are working'

# 4224

Say (Prophet Muhammad): 'I am only a human like you, to whom it is revealed that your God is One God. Therefore be straight with Him and ask Him to forgive you. Woe to the idolaters,

# 4225

who do not pay charity and disbelieve in the Everlasting Life.

# 4226

For those who believe and do good works is an enduring wage'

# 4227

Say: 'Do you disbelieve in Him who created the earth in two days? And do you set up equals with Him? He is the Lord of the Worlds'

# 4228

He set firm mountains on top (of the earth) and He blessed it. And in four days He ordained in it many provisions, equal to those who ask.

# 4229

Then He willed to the heaven when it was smoke, and to it and the earth He said: 'Come willingly, or unwillingly' 'We come willingly' they answered.

# 4230

In two days He determined them seven heavens, and He revealed to each heaven its commands. We decorated the lowest heaven with lamps and preserve them. Such is the decree of the Almighty, the Knower.

# 4231

But if they turn away, say: 'I have given you warning of a thunderbolt similar to that which overtook Aad and Thamood'

# 4232

When their Messengers came to them from before them and behind them, (saying): 'Worship none except Allah' they answered: 'Had it been the will of our Lord, He would have sent down angels. So we disbelieve in the Message with which you were sent'

# 4233

As for Aad, they behaved proudly in the earth without right. 'Who is stronger than us' they would say. Could they not see that Allah, who created them, is stronger than they? But they disbelieved Our signs.

# 4234

Then, on the ominous days, We loosed against them a howling wind that We might let them taste the punishment of humiliation in this life; but more humiliating will be the punishment of the Everlasting Life and they will not be helped.

# 4235

As for Thamood, We (offered) them Our Guidance, but they preferred blindness to guidance. So a thunderbolt of the humiliating punishment seized them because of what they had earned;

# 4236

and We saved those who believed and feared Allah.

# 4237

On the Day when the enemies of Allah will be rightfully gathered together before Fire,

# 4238

when they reach it, their hearing, eyes and skins will testify against them for what they were doing.

# 4239

'Why did you bear witness against us' they will ask their skins, and they will reply: 'Allah has given us speech, as He has given speech to everything. It was He who created you the first time, and to Him you shall return.

# 4240

It is not that you covered yourselves so that your hearing, eyes and skin could not bear witness against you but you thought that Allah did not know much of that which you do.

# 4241

Rather, it is the thoughts you thought about your Lord that have destroyed you, therefore, this morning you find yourselves among the losers'

# 4242

Even if they are patient the Fire shall still be their lodging, and if they seek pardon, they shall not be among those who are pardoned.

# 4243

We have assigned companions to them, who make what is before them and behind them seem fair to them. The statement has been realized against them in nations of people and jinn alike that passed away before them they were indeed the losers.

# 4244

The unbelievers say: 'Do not listen to this Koran, and talk idly about it so that you might be overcome'

# 4245

We will let the unbelievers taste a terrible punishment, and recompense them with the worst of what they were doing.

# 4246

The Fire that is the recompense of the enemies of Allah. There it is that they will be lodged for eternity, a recompense for their disbelief of Our verses.

# 4247

The unbelievers will say: 'Lord, show us the jinn and people who led us astray, to put them under our feet so that they are among the lowest'

# 4248

The angels will descend on those who said: 'Allah is Our Lord' and have then gone straight, (saying:) 'Be neither fearful, nor sad; rejoice in the Paradise you have been promised.

# 4249

We are your guides in this world and in the Everlasting Life. There, you shall have all that your souls desire, and all that you ask for

# 4250

as hospitality from One, the Forgiving, the Most Merciful'

# 4251

And, who is better in saying than he who invites to Allah, does what is right, and says: 'Surely, I am of those who surrender'

# 4252

Good and evil deeds are not equal. Repel with that which is most just, and see, the one whom there is enmity between you will be as if he were a loyal guide.

# 4253

But none will receive it except those who are patient and, none shall receive it, except he who has a great share.

# 4254

If a provocation from satan should provoke you, seek refuge in Allah. He is the Hearer, the Knower.

# 4255

Among His signs are the night and the day, and the sun and the moon. But do not prostrate yourselves before the sun or the moon; rather prostrate before Allah, who created them both, if it is He whom you worship.

# 4256

But if they become proud, those who are with your Lord exalt Him by day and night, and never grow weary.

# 4257

And among His signs is that you see the earth humble; then when He sends down rain upon it, it quivers and swells. He who revives is He who revives the dead, surely, He is powerful over everything.

# 4258

Those who disbelieve Our verses when it comes to them are not hidden from Us. Is he who is cast in the Fire better than he who comes in safety on the Day of Resurrection? Do as you will, surely, He sees the things you do.

# 4259

Those who disbelieve in the Remembrance when it comes to them and indeed this is a Mighty Book

# 4260

falsehood does not come to it from before it or from behind it. It is a sending down from the One, the Wise, the Praised.

# 4261

Nothing that is said to you has not already been said to other Messengers before you. Indeed, your Lord is a Lord of forgiveness, but stern in retribution.

# 4262

Had We made the Koran in a nonArabic (language) they would have said: 'If only its verses were distinguished! Why in (a) nonArabic (language, when theProphet is) an Arab' Say: 'To the believers it is a guidance and a healing. But to those who do not believe, there is a heaviness in their ears, to them it is blindness. They are those called from afar'

# 4263

We gave the Book to Moses, but there were disputes about it, and had it not been for a Word that preceded from your Lord (their disputes) would have been decided between them. But they are in disquieting doubt about it.

# 4264

He who does good does it for himself; and he who does evil does so against it. Your Lord never wrongs His worshipers.

# 4265

To Him is referred the knowledge of the Hour. No fruit sprouts forth from its sheath, no female conceives or is delivered, except with His Knowledge. On the Day He will call to them: 'Where then are My associates' they will reply: 'We proclaim to You that none of us can bear witness'

# 4266

Those they used to call upon before will go away from them, and they shall think that they have no asylum.

# 4267

Mankind never wearies of supplicating for goodness, but when evil befalls him he is downcast and (grows) desperate.

# 4268

And if We give him a taste of mercy from Us after his affliction has befallen him, he is sure to say: 'This is my own. I do not think the Hour will ever come. And even if I am returned to my Lord, with Him there is for me the finest reward (Paradise)' Then, We shall tell the unbelievers what they did and let them taste a harsh punishment.

# 4269

When We favor a human, he swerves away and withdraws aside, but when evil befalls him he is full of unending prayer.

# 4270

Say: 'Think, if this (Koran) is indeed from Allah, and you disbelieve in it, who is further astray than he who is in a wide schism'

# 4271

We will show them Our signs in all the horizons and in themselves, until it is clear to them that it is the truth. Is it not sufficient that your Lord is witness over everything'

# 4272

Are they not in doubt concerning the Meeting with their Lord? Attention, He encompasses everything.

# 4273

HaMeem

# 4274

'AeenSeenQaaf

# 4275

As such Allah, the Almighty, the Wise reveals to you (Prophet Muhammad) and to those before you.

# 4276

To Him belongs whatsoever is in the heavens and the earth. He is the High, the Exalted.

# 4277

The heavens nearly break apart above them as the angels exalt with the praise of their Lord and ask forgiveness for those on earth. Indeed Allah is the Forgiving, the Most Merciful.

# 4278

As for those who take guardians for themselves, other than Him, Allah is the Warden over them. You are not a guardian over them.

# 4279

As such We have revealed to you an Arabic Koran, so that you can warn the Mother of Villages (Mecca) and all who live about it, and that you also warn them of the Day of Gathering in which there is no doubt that a division will be in Paradise, and a division in the Blaze.

# 4280

Had it been the Will of Allah, He would have made them all one nation. But He admits into His Mercy whom He will the harmdoers shall have neither a guardian nor helper.

# 4281

Or have they taken to themselves guardians other than Him? But Allah, He is the Guardian. He revives the dead and has power over all things.

# 4282

Whatever you differ upon, its judgement belongs to Allah. Such is Allah, my Lord, in Him I have put my trust, and to Him I turn in repentance.

# 4283

The Originator of the heavens and the earth, He has given you from yourselves, pairs, and also pairs of cattle, thereby multiplying you. There is nothing like Him. He is the Hearer, the Seer.

# 4284

To Him belongs the keys of the heavens and the earth. He outspreads and withholds His provisions to whom He will, surely, He has knowledge of all things.

# 4285

He has made plain for you the Religion with which He charged Noah and that which We have revealed to you, and that with which We charged (Prophets) Abraham, Moses and Jesus, (saying): 'Establish the Religion and do not be divided therein' That which you invite them to is too overwhelming for the idolaters. Allah brings close to Himself whom He will, and guides to Him those who turn in repentance.

# 4286

Yet they became divided only after knowledge had reached them from their own insolence. And had it not been for a Word that had preceded from yourLord, till an appointed term, it would have been determined between them. But those who inherited the Book after them are in disquieting doubt about it,

# 4287

so invite and go straight as you are ordered, and do not follow their desires and say: 'I believe in whatever Book Allah has sent down. I am ordered to be just among you. Allah is our Lord and your Lord. We have our deeds and you have yours; there is no argument between us and you, Allah will bring us all together, to Him is the arrival'

# 4288

As for those who argue concerning Allah after being answered, their arguments will be annulled before their Lord, and His Wrath will fall upon them, and for them there is a terrible punishment.

# 4289

It is Allah who has sent down the Book in truth and the Scale. And what will let you know? The Hour is near.

# 4290

Those who disbelieve in it seek to hasten it, but the believers are in fear of it, knowing it to be the truth. Indeed, those who doubt the Hour have strayed far away.

# 4291

Allah is Subtle towards His worshipers, and provides for whosoever He will. He is the Strong, the Almighty.

# 4292

Whoever hopes for the tillage of the Everlasting Life, We will increase his tillage; and whoever hopes for the tillage of this world, We give him some of it, but in the Everlasting Life he shall have no share.

# 4293

Or do they have associates who have made lawful to them in religion what Allah has not permitted? Had it not been for the Decisive Word, it would have been decided between them. For the evildoers there is a painful punishment.

# 4294

You shall see the harmdoers in fear of what they have earned as it is about to fall on them. But those who believe and do good deeds shall live in the meadows of the Gardens and from their Lord they will have all that they desire that is the great bounty.

# 4295

This is the glad tidings that Allah gives to His worshipers, who believe and do good works. Say: 'For this I ask of you no wage except the love of the (Prophet's) relatives. We will add good to whosoever gains a good deed. Allah is the Forgiving and the Thanker'

# 4296

Or do they say: 'He has forged a lie about Allah? But if Allah wills He could set a seal upon your heart. Allah wipes out falsehood and verifies the truth by His Words. He knows the innermost of the chests.

# 4297

It is He who accepts the repentance of His worshipers and pardons their evil deeds. He has knowledge of what you do.

# 4298

He answers those who believe and do good deeds, and He increases them from His bounty. But for the unbelievers there is a terrible punishment.

# 4299

If Allah had expanded His provision to His worshipers, they would become tyrannical in the earth, but He sends down to them what He will in due measure; He is Aware and sees His worshipers.

# 4300

It is He who sends down rain for them after they despaired, and He unfolds His Mercy. He is the Guardian, the Praised.

# 4301

Among His signs is the creation of the heavens and the earth and the crawling things which He has dispersed in them. If He will, He is Able to gather all of them.

# 4302

If affliction befalls you, it is what your own hands have earned, but He pardons a lot.

# 4303

You are not able to frustrate Him in the earth, nor do you have a guardian and a helper other than Allah.

# 4304

And among His signs are the ships that run on the sea like mountains and

# 4305

if He will, He calms the wind so that they remain motionless upon its back, surely, there are signs in this for every thankful, patient (person).

# 4306

Or, He wrecks them for what they have earned, but He pardons a lot.

# 4307

Those who dispute Our verses may know that they have no asylum.

# 4308

That which you have been given is but the enjoyment of the present life. Better and more enduring is that which Allah has for those who believe and put their trust in their Lord.

# 4309

And those who avoid the major sins and indecencies and, when angered, forgive;

# 4310

those who answer their Lord, establish the prayers, and their affairs are by consultation; who spend of that which We have given them,

# 4311

and when harmed they become victorious.

# 4312

The recompense of a sin is a sin like it, but whosoever forgives and seeks to reform, his wage will be with Allah. Surely, He does not love the harmdoers.

# 4313

And whosoever harms after he has been harmed there is no blame upon them.

# 4314

The blame is only against those who wrong people, and are wrongfully insolent in the earth, for them there is a painful punishment.

# 4315

Surely, he who bears patiently and forgives indeed that is true constancy.

# 4316

He whom Allah leads astray has none to protect him thereafter. You will see the harmdoers when they see the punishment saying: 'Is there a way back'

# 4317

You shall see them exposed before it, humbled in shame and looking upon it with a furtive glance and the believers will say: 'Indeed, the losers are they who lose themselves and their families on the Day of Resurrection' The harmdoers shall suffer an everlasting punishment.

# 4318

They shall have none to protect or help them other than Allah. He whom Allah leads astray there is no way for him.

# 4319

Answer your Lord before that Day arrives which cannot be turned back from Allah, for you on that Day there shall be neither shelter, nor denial.

# 4320

But if they turn away, We have not sent you (Prophet Muhammad) to be their (compulsory) guardian. It is only for you to deliver (the Message). When We give the human a taste of Our Mercy, he rejoices because of it; but when, because of what he has earned, evil befalls him, the human is ungrateful.

# 4321

To Allah belongs the Kingdom of the heavens and the earth. He creates what He will. He gives females to whom He will and males to whom He will.

# 4322

Or, He couples them, both males and females, and to others, if He will, He makes them barren. Surely, He is the Knower, the Powerful.

# 4323

It does not belong to any human that Allah should speak to him except by Revelation, or from behind a veil, or that He sent a Messenger to revealwhatsoever He will by His Permission. He is the High, the Wise.

# 4324

As such We have revealed to you (Prophet Muhammad) a spirit (the revelation of the Koran) from Our Ordinance. You did not know what the Book was, nor belief, but We made it a light whereby We guide those of Our worshipers whom We will. And you (Prophet Muhammad), you, surely guide to a Straight Path.

# 4325

The Path of Allah, to whom belongs all that is in the heavens and all that is in the earth. Surely, to Allah all things return.

# 4326

HaMeem.

# 4327

By the Clear Book

# 4328

We have made it an Arabic Koran in order that you understand.

# 4329

It is in the Origin of the Book with Us, sublime and wise.

# 4330

Shall We turn away the Remembrance from you because you are a sinful nation?

# 4331

How many a Prophet did We send to the ancients,

# 4332

no Prophet came to them except that they mocked him,

# 4333

so We destroyed those who were mightier in courage than they. And the example of the ancients has passed away.

# 4334

Yet, if you ask them who created the heavens and the earth, they will answer: 'The Almighty, the Knower created them'

# 4335

(It is) He who made the earth to be a cradle for you and made in it ways for you, in order that you are guided.

# 4336

And (it is He), who sends down water from the sky in its measure thereby We revive the land that was dead, as such you shall be brought forth.

# 4337

And, (it is He) who has created all the pairs and appointed for you ships and the cattle on which you ride,

# 4338

so that you can sit upon their backs and then remember the Favors of your Lord and say: 'Exaltations to Him who has subjected these to us otherwise, we ourselves were not capable of it,

# 4339

indeed, to our Lord we are turning'

# 4340

Yet they assign to Him some of His own (created) worshipers! Clearly, the human is unthankful.

# 4341

Or, has He taken daughters from those He has created for Himself and favored sons for you?

# 4342

Yet when one of them is given glad news of (a daughter) that which he likened to the Merciful his face darkens and he chokes inwardly (with gloom).

# 4343

(As such they attribute to Allah) who is brought up among ornaments but when disputes arise are powerless.

# 4344

They claim that the angels, who are themselves the worshipers of the Merciful, are females. Did they witness their creation! Their witness shall be written down and they shall be questioned.

# 4345

They say: 'Had it been the will of the Merciful, we would never have worshipped them' Of this they have no knowledge, they are but guessing.

# 4346

Or have We given them a Book before this which they hold fast to?

# 4347

No, but they say: 'We found our fathers following a creed, and by following in their footsteps we are guided.

# 4348

As such, We never sent a warner before you to a village, except those living in luxury said: 'We found our fathers following a creed, and by following in their footsteps we are guided'

# 4349

Say: 'What then if I bring you a better guidance than that you found your fathers following' But they reply: 'We disbelieve in that you have been sent with.'

# 4350

So We took vengeance upon them, and see how the end was of those who lied.

# 4351

(Remember) when Abraham, said to his father and his nation: 'I am quit from what you worship,

# 4352

except Him who originated me, for He will guide me'

# 4353

He made this an abiding word among his descendants, in order that they would return.

# 4354

I gave them and their fathers days of enjoyment until the truth and a clear Messenger came to them.

# 4355

But when the truth came to them, they said: 'This is sorcery, we disbelieve in it'

# 4356

They also said: 'Why was this Koran not sent down to a great man from the two Villages'

# 4357

What, is it they who divide the Mercy of your Lord! (It is) We who divided between them their livelihoods in this life, raising some in rank above others, sothat some may take the other into his service. Your Lord's Mercy is better than all they gather.

# 4358

If it were not that mankind would be one nation We would have made for whosoever disbelieves in the Merciful silver roofs upon their houses, and stairs toclimb,

# 4359

with doors to their houses and couches on which to recline;

# 4360

and gold, surely, all this is but the enjoyment of this present life. The Everlasting Life with your Lord is for those who fear (Him).

# 4361

To whosoever blinds himself from the Remembrance of the Merciful, We shall assign him a satan so he is his companion,

# 4362

and they bar them from the Way, though they themselves think that they are guided.

# 4363

And when he comes before Us, he shall say: 'Would that there had been between me and you, the distance of the two Easts' Evil is the companion.

# 4364

Because of the harm you did, it would be of no benefit to you today, you are partners in the punishment.

# 4365

What, will you make the deaf hear, or guide the blind and he who is in clear error?

# 4366

Even if We take you away, We shall take vengeance upon them,

# 4367

or We show you a part of that which We have promised them, for indeed We have power over them.

# 4368

Therefore, hold fast to that which is revealed to you, indeed, you are on the Straight Path.

# 4369

It is indeed a Reminder to you and to your nation, and without doubt you shall be questioned.

# 4370

Ask Our Messengers whom We sent before you if We have ever made gods, other than the Merciful, to be worshipped.

# 4371

We sent Moses with Our signs to Pharaoh and his Council, and he said: 'I am the Messenger of the Lord of the Worlds'

# 4372

But when he showed them Our signs they laughed at them,

# 4373

yet there was not a sign that We showed them that was not greater than its sister, and We seized them with the punishment so that they might return.

# 4374

'Sorcerer' they said, 'pray to your Lord for us in accordance to the covenant He has made with you, and surely we shall be rightly guided'

# 4375

But when We had relieved them of their punishment they broke their promise.

# 4376

Then Pharaoh made a proclamation to his people: 'My people, is the kingdom of Egypt not mine and these rivers which flow beneath me? What, can you not see?

# 4377

Am I not better than this contemptible (man), who can scarcely make things clear (because of the impediment of his speech)?

# 4378

Why have no armlets of gold been given him, or angels sent down successively with him'

# 4379

He (Pharaoh) intimidated his nation, so they obeyed him, for they were a sinning nation.

# 4380

And when they angered Us, We took vengeance on them and drowned all of them,

# 4381

and We made them a thing of the past, and We made them an example to later people.

# 4382

When the son of Mary is mentioned as an example, your people turn away from it

# 4383

and say: 'What are our gods better, or is he' They do not mention him to you except to dispute, truly, they are a contentious nation.

# 4384

He (Prophet Jesus) was only a worshiper whom We favored and We made him an example to the Children of Israel.

# 4385

Had it been Our Will We would have made angels among you as successors in the earth.

# 4386

It is the knowledge of the Hour. Have no doubt concerning it, and follow me. This is a Straight Path,

# 4387

and do let satan prevent you, for he is your clear enemy.

# 4388

And when (Prophet) Jesus came with clear signs, he said: 'I have come to you with wisdom and to clarify to you some of the matters about which you differ. Fear Allah and obey me.

# 4389

Indeed, Allah is my Lord and your Lord, therefore worship Him. That is the Straight Path'

# 4390

Yet the parties differed among themselves. So woe to those who did evil among the punishment of a Painful Day.

# 4391

Are they looking for anything except the Hour (to overtake them). It will come upon them suddenly when they are unaware!

# 4392

On that Day close friends shall become enemies of each other, except those who fear (Allah).

# 4393

O My worshipers, there is no fear for you on this Day, nor will you grieve

# 4394

to those who believed in Our verses and were Muslims,

# 4395

(it will be said) 'You and your spouses, enter, walking with joy into Paradise'

# 4396

To them will be passed large platters and cups of gold. There will be all that souls desire and all that eyes delight in. (And it will be said:) 'There you shall live for ever.

# 4397

Such is the Paradise you shall inherit, for the things you did.

# 4398

You shall have therein abundant fruit to eat'

# 4399

But the evildoers shall live for ever in the punishment of Gehenna (Hell),

# 4400

which will not be lightened for them, and therein they shall be silent.

# 4401

We did not wrong them, but they were harmdoers.

# 4402

'O Malik' (the angel of Hell) they will call out, 'let your Lord put an end to us' But he will answer: 'Here you shall stay'

# 4403

We brought you the truth, but most of you were averse to the truth.

# 4404

Or have they devised a matter! We are devising.

# 4405

Do they think We do not hear their secret and that which they conspire! Yes, indeed Our angels, who are present with them write it down.

# 4406

Say (Prophet Muhammad): 'If the Merciful had a son, I would be the first of the worshipers.

# 4407

Exaltations be to the Lord of the heavens and the earth, the Lord of the Throne, above that which they describe'

# 4408

Let them alone to plunge and play, until they encounter that Day of theirs which they are promised.

# 4409

He who is God in the heavens is also God in the earth; He is the Wise, the Knower.

# 4410

Exaltations to Him to whom belong the Kingdom of the heavens and the earth, and all that is between them! With Him is the knowledge of the Hour and toHim you shall be returned.

# 4411

Those whom they call upon, other than Him, have no power to intercede (for them), except those that have knowingly borne witness to the truth.

# 4412

Yet if you ask them: 'Who created you' they will say: 'Allah' How then can they turn away from Him?

# 4413

And for his saying: 'My Lord, these are an unbelieving nation'

# 4414

pardon them, and say: 'Peace', soon they will know.

# 4415

HaMeem

# 4416

By the Clear Book

# 4417

that We sent down during a Blessed Night. We are ever warning.

# 4418

In it every wise matter is determined

# 4419

an order from Us. We are ever sending.

# 4420

A Mercy from your Lord, He is the Hearer, the Knower.

# 4421

Lord of the heavens and the earth and all that is between them, if you are certain (of your faith).

# 4422

There is no god except He. He revives and causes to die. (He is) your Lord and the Lord of your fathers, the ancients.

# 4423

Yet they are in doubt, playing.

# 4424

Watch for the Day when the heaven will bring clear smoke,

# 4425

engulfing the people; this will be a painful punishment.

# 4426

'Our Lord, remove this punishment from us, we are believers'

# 4427

But how will they avail themselves of the Reminder, when a clear Messenger had already come to them

# 4428

but then they turned away from him, saying: 'He is tutored, mad'

# 4429

We are removing the punishment a little, but you revert.

# 4430

But on that Day We will assault them most mightily, and then We shall revenge!

# 4431

We tried Pharaoh's nation before them. A noble Messenger came to them,

# 4432

(saying:) 'Be obedient to me O worshipers of Allah. I am your honest Messenger.

# 4433

Do not rise up against Allah, I come to you with clear authority.

# 4434

I take refuge with my Lord and your Lord lest you stone me.

# 4435

And if you do not believe me, then leave me'

# 4436

Then he supplicated to his Lord saying: 'These are sinful people'

# 4437

(His Lord answered): 'Set out with My worshipers in the night, for you will surely be followed.

# 4438

Then leave the sea calm they are an army that will be drowned.

# 4439

How many gardens and fountains did they leave behind,

# 4440

and sown fields, fine sitting places,

# 4441

and good things in which they took delight.

# 4442

As such (it was). And We made other people inherit them.

# 4443

Neither heaven nor earth shed tears for them; nor were they respited,

# 4444

and We saved the Children of Israel from a humiliating punishment

# 4445

from Pharaoh, who ranked high in sin,

# 4446

and We chose them, out of a knowledge above the nations (of their time).

# 4447

And gave signs to them in which there was a clear trial.

# 4448

Yet these say:

# 4449

'There is nothing except the first death, we shall never be revived.

# 4450

Bring us our fathers, if what you say is true'

# 4451

Are they better or the people of Tubba' and those who were before them whom We destroyed? Indeed they were sinners.

# 4452

It was not in play that We created the heavens and the earth and all that is between them.

# 4453

We created them in nothing else except the truth. But most do not know.

# 4454

The Day of Decision is the appointed time for all.

# 4455

On that Day no cousin shall help his cousin and they shall not be helped

# 4456

except those on whom Allah will have mercy. He is the Almighty, the Most Merciful.

# 4457

The food of the Zakkum tree

# 4458

shall be the food of the guilty sinners.

# 4459

Like molten copper boiling in the belly

# 4460

as the boiling of the hot water.

# 4461

'Seize him and drag him into the center of Hell.

# 4462

Then pour the punishment of boiling water over his head,

# 4463

(Saying): 'Taste, surely you are the mighty and noble!

# 4464

This is that which you doubted'

# 4465

Indeed, for those who feared (Allah) is a secure place

# 4466

amidst gardens and fountains,

# 4467

dressed in silks and brocade, set face to face.

# 4468

As such, We shall wed them to wideeyed houris (the virgins of Paradise).

# 4469

There in security, they will call for every kind of fruit.

# 4470

There they shall not taste death, except the first death, and He will shield them from the punishment of Hell,

# 4471

as a bounty from your Lord. That will be the mighty triumph.

# 4472

We have now made it easy on your tongue, in order that they remember.

# 4473

So be watchful, they too are watching.

# 4474

HaMeem.

# 4475

The sending down of the Book is from Allah, the Almighty, the Wise.

# 4476

Indeed, there are signs in the heavens and earth for believers,

# 4477

and in your creation, and in the crawling things that He has scattered far and near, there are signs for a nation whose belief is certain,

# 4478

and in the alternation of the night and day, in the provision Allah sends down from heaven with which the earth is revived after its death, and in the changing about of the winds, there are signs for people who understand.

# 4479

Such are the verses of Allah. We recite them to you in truth. So in what speech, after Allah and His signs, will they believe?

# 4480

Woe to all the guilty impostors!

# 4481

He hears the verses of Allah recited to him and then, as though he never heard them, persists in insolence. Give to him the glad tidings of a painful punishment.

# 4482

As for he who knows something of Our verses and then mocks them for those there is a humiliating punishment.

# 4483

Gehenna (Hell) is behind them, all that they have earned shall not help them at all, nor shall those they took as guardians, other than Allah. For them there is a mighty punishment.

# 4484

This is guidance; for those who disbelieve in the verses of their Lord the anger of the painful punishment awaits them.

# 4485

It is Allah who has subjected to you the sea so that ships run upon it at His command, and so that you may seek His bounty and be thankful.

# 4486

He has subjected to you whatsoever is in the heavens and the earth; all is from Him. Surely, there are signs in this for people who contemplate.

# 4487

Tell the believers to forgive those who do not look for the Days of Allah, so that He recompenses the people for what they have earned.

# 4488

He who does what is right does it for his own gain, and he who does evil does so at his own loss, then to your Lord you shall all return.

# 4489

We gave to the Children of Israel the Book, judgment and prophethood. We provided them with good things and preferred them above the worlds (of theirtime).

# 4490

We gave them clear signs of the Command; yet it was not until after knowledge had come to them that they differed among themselves, and were insolent to each other. On the Day of Resurrection your Lord will indeed decide their differences.

# 4491

And now, We have set you on the jurisprudence of the Command, therefore follow it and do not follow the desires of those who do not know.

# 4492

Indeed, they will not help you at all against Allah. The harmdoers are guides of each other; but Allah is the Guide of the cautious.

# 4493

These are clear proofs for people, a guidance, and mercy for those who are certain (of the Resurrection) in belief.

# 4494

Do those who commit evil deeds think that We will make them (equal) to the believers who do good works, so that in life and death they shall be alike? How evil they judge!

# 4495

Allah created the heavens and the earth in truth and that each soul shall be recompensed for what it earned, they shall not be wronged.

# 4496

Have you seen he who took his desire for a god? With knowledge, Allah has led him astray, setting a seal upon his hearing and heart, and has made a veil over his eyes, who then shall guide him after Allah? Will you not then remember!

# 4497

They say: 'There is nothing except this life, we die and we live, it is only time that destroys us' Surely, of this they have no knowledge, they are just guessing.

# 4498

And when Our verses are recited to them, their only argument is: 'Bring our fathers back to us, if what you say is true'

# 4499

Say: 'Allah revives you and causes you to die. Then, He shall gather you on the Day of Resurrection, and of this there is no doubt, yet most people do notknow'

# 4500

To Allah belongs the Kingdom in the heavens and the earth. On the Day when the Hour comes, those who disbelieved shall be the losers.

# 4501

You shall see every nation hobbling on their knees. Each nation shall be summoned to its Book. (And it will be said:) 'This Day, you shall be recompensedfor what you were doing.

# 4502

This is Our Book that speaks with the truth over you. We have recorded all that you were doing'

# 4503

As for those who have believed and done good works, their Lord will admit them into His Mercy that is a mighty triumph!

# 4504

But, to the unbelievers (it will be said): 'Were My verses not recited to you, but you were proud and were you not a sinful nation'

# 4505

When it was said: 'The promise of Allah is true, and of the Hour there is no doubt' you replied: 'We do not know what the Hour is, we guess, assuming, and we are by no means certain'

# 4506

The evil of their deeds will appear to them, and they shall be encompassed by that they mocked,

# 4507

and it shall be said: 'Today, We will forget you as you yourselves forgot that you would encounter this Day. The Fire shall be your refuge, and none will help you.

# 4508

That is because you took the verses of Allah (the Koran) in mockery, and you were deluded by your worldly life' So that Day they will not be brought outof it; nor shall they be repentant.

# 4509

Praise, belongs to Allah, the Lord of the heavens and the earth, the Lord of the Worlds.

# 4510

His is the Pride in the heavens and earth. He is the Almighty, the Wise.

# 4511

HaMeem.

# 4512

The sending down of the Book is from Allah, the Almighty, the Wise.

# 4513

It was in truth that We created the heavens and the earth, and all that is between them, for an appointed term. Yet the unbelievers do not turn away from that which they were warned.

# 4514

Say: 'Have you seen those whom you call upon, other than Allah? Show me what they have created from the earth! Or, do they have a partnership in theheavens? Bring me a Book before this or some other remnant of knowledge, if what you say is true'

# 4515

Who is further astray than he who calls upon, other than Allah, those who will never answer him till the Day of Resurrection, who are indeed, heedless of their supplication?

# 4516

And, when mankind are gathered, those will become their enemies and disown their worship.

# 4517

When Our clear verses are recited to them, the unbelievers say of the truth that came to them: 'This is clear sorcery'

# 4518

Or, do they say: 'He has forged it' Say: 'If I have forged it, then you have no power to help me against Allah, He knows what you say. It is sufficient that Heis the Witness between me and you. He is the Forgiving, the Most Merciful'

# 4519

Say: 'I am not an innovation among the Messengers; nor know what will be done with me or you. I follow only what is revealed to me; I am only a clearwarner'

# 4520

Say: 'Consider, if this (Koran) is from Allah and you disbelieve in it, and a witness from the Children of Israel testifies to its like and believes, while you areproud! Indeed, Allah does not guide the harmdoers'

# 4521

The unbelievers say of the believers: 'Had it been any good they would not have believed in it before us' And because they are not guided by it they say: 'This is an ancient falsehood'

# 4522

Yet before it there was the Book of Moses which was an authority, and a mercy. This (Koran) is the Book confirming it (the other untampered Books) in theArabic tongue, to warn the harmdoers and to give glad tidings to those who do good.

# 4523

Those who say: 'Our Lord is Allah' and follow the Straight Path shall have nothing to fear nor shall they sorrow.

# 4524

Those, they shall be for ever the inhabitants of Paradise, a recompense for what they did.

# 4525

We have charged the human to be kind to his parents. With much pain his mother bore him, and with much pain she gave birth to him; his bearing andweaning are thirty months. When he grows to manhood and attains his fortieth year, he says: 'Make me so disposed My Lord, so that I give thanks for the favorswith which You have blessed me, my father and mother, and that I will do good deeds that will please You. And, make me righteous and also my descendants. To You I repent, and I am among those who surrender'

# 4526

Such are those from whom We will accept the best of what they have done and whose evil deeds We shall overlook. Those, they are among the inhabitants of Paradise; true is the promise that has been promised them.

# 4527

But he who says to his father and his mother, 'Fie on you! Do you promise me that I shall be brought forth, when entire generations have passed away before me' Yet they supplicate to Allah for help 'Woe to you! Believe, surely the promise of Allah is true' Then he says: 'This is nothing but fairytales of the ancients'

# 4528

Such are they against whom the statement is realized concerning the nations of humans and jinn alike that passed away before them; they were the losers.

# 4529

Each shall have their degrees, according to what they have done, so that He will recompense them for their works, and they shall not be wronged.

# 4530

Upon the Day when the unbelievers are brought before the Fire, (We shall say to them): 'You squandered your good things in your earthly life and took your fill of enjoyment in them, therefore today you shall be recompensed with a humiliating punishment, because you were unrightfully proud in the earth and for that you were debauchers'

# 4531

Remember Aad's brother who warned his nation in (the valley of) Al Ahqaf. Warners had already preceded and succeeded him saying: 'Worship noneexcept Allah! (he said) 'Indeed, I fear for you the punishment of a Dreadful Day'

# 4532

'Have you come to turn us away from our gods (they replied)? If what you say is true then bring down that which you promise us'

# 4533

'Allah alone has the knowledge' he said, 'I am sent to deliver to you the Message. But I can see that you are ignorant people'

# 4534

And when they saw it as a sudden cloud heading for their valley they said: 'This is a cloud that will bring us rain' 'Rather' (he replied): 'it is that which you have sought to hasten, a wind in which there is a painful punishment.

# 4535

It will destroy everything by the command of its Lord' And when morning came there was nothing to be seen except their dwellings. As such Werecompense sinful people.

# 4536

And We had established them in that which We have not established you, and We made for them hearing, sight, and hearts, but their hearing, sight, andhearts did not help them a thing, because they disbelieved the signs of Allah. And what they mocked encompassed them.

# 4537

We destroyed the villages around you and We repeated Our signs so that they might return.

# 4538

Why did not those who they took, other than Allah, as mediating gods help them! Indeed, they went astray from them! Such were their lies and what they were forging.

# 4539

(Remember) how We sent to you (Prophet Muhammad) a company of jinn who, when they came and listened to the Koran, said to each other: 'Be silent' Then, when it was finished, they returned to their nation and warned them.

# 4540

'Our nation' they said: 'we have just been listening to a Book sent down after Moses confirming what came before it and guiding to the truth and to aStraight Path.

# 4541

Our nation, answer the Caller of Allah and believe in Him! He (Allah) will forgive you some of your sins and protect you from a painful punishment.

# 4542

Those who do not answer the Caller of Allah cannot frustrate Allah in the earth, nor shall any one protect them other than Him; those are in clear error'

# 4543

Have they not seen that it is Allah who created the heavens and the earth and was not wearied by their creation, and that He is Able to restore the dead tolife? Yes, He has power over all things!

# 4544

On the Day when the unbelievers are brought before the Fire they shall be asked: 'Is this not the truth' 'Yes, by our Lord' they will answer. He will say:'Then taste the punishment, for you were unbelievers'

# 4545

Be patient, as the Messengers of might were patient, and do not hasten it for them. On the Day when they see what they have been promised, it will be as if they did not stay except an hour of a day. (This Koran is) a Conveyance! Shall any be destroyed except the nation of evildoers?

# 4546

Those who disbelieve and bar from the way of Allah, Allah will cause their deeds go astray.

# 4547

As for the believers who do good works and believe in what is sent down to Muhammad which is the truth from their Lord He will acquit them of their sinsand repair their condition.

# 4548

This is because the unbelievers follow falsehood while the believers follow the truth from their Lord. As such Allah sets forth for people their examples.

# 4549

Therefore, when you meet the unbelievers smite their necks, then, when you have killed many of them, tie the bonds. Then, either free them by grace orransom until war shall lay down its loads, in this way, it shall be. Had Allah willed, He would have been victorious over them; except that He might test you, the oneby the means of others. As for those who are killed in the Way of Allah, He will not let their works to go astray.

# 4550

He will guide them and repair their condition;

# 4551

and He will admit them to the Paradise He has made known to them.

# 4552

Believers, if you help Allah, He will help you and strengthen your feet.

# 4553

But the unbelievers shall be the destroyed losers. He will bring their deeds to nothing.

# 4554

That is because they hated what Allah has sent down, so He annulled their deeds.

# 4555

Have they never journeyed through the land and seen what was the end of those who had gone before them? Allah destroyed them! Likewise it is for theunbelievers,

# 4556

that is because Allah is the Guardian of the believers, and the unbelievers have no guardian.

# 4557

Allah will indeed admit those who believe and do good works into Gardens underneath which rivers flow. As for the unbelievers, they take their fill of pleasure and eat as the cattle eat, but the Fire shall be their lodging!

# 4558

How many a village mightier than your own village, which has expelled you, We have destroyed there was none to help them!

# 4559

Is he who has clear proof from his Lord to be compared to him whose evil deeds are made to seem fair to him, so that they followed their desires?

# 4560

The example of the Paradise which the cautious have been promised in it, there are rivers of unstaling water, and rivers of milk that never change in flavor, and rivers of wine, delectable to the drinkers, and rivers of pure, filtered honey. They shall have therein of every fruit and forgiveness from their Lord. Are they then like he who shall live in the Fire for ever and given boiling water to drink that tears his bowels apart!

# 4561

Some of them listen to you, but no sooner do they leave you they ask those to whom knowledge has been given: 'What did he say just now' Such are those whom Allah has set a seal upon their hearts and who follow their own desires.

# 4562

As for those who were guided, He increases their guidance and gives them their protection.

# 4563

Are they looking except for the Hour to overtake them suddenly? Its signs have come. But how will they be reminded when it has come to them?

# 4564

Therefore, know that there is no god except Allah and ask for forgiveness of your sins and for the believers, men and women. Allah knows your going to and fro, and your lodging.

# 4565

The believers ask: 'Has a chapter been sent down' But when a clear chapter is sent down and fighting is mentioned in it, you see those in whose hearts is sickness looking towards you as one who swoons at death.

# 4566

Yet obedience and honorable words (would be better for them). Then, when the matter is decided, if they were true to Allah it would be better for them.

# 4567

Could it be, that if you turn away, you might make corruption in the land and break the ties of kinship?

# 4568

Such are those whom Allah has cursed, making them deaf and blinding their eyes.

# 4569

Will they not then contemplate on the Koran? Or are there locks upon their hearts!

# 4570

As for those who turn back in their footsteps after the guidance of Allah has become clear to them, it was satan who tempted them, and Allah has respited them.

# 4571

That is because they say to those averse to what Allah has sent down 'We shall obey you in some of the matters' Allah knows their secrets.

# 4572

How shall it be when the angels (of death) take them and beat them on their face and back?

# 4573

That is because they follow what angers Allah and hate His pleasure, therefore He has annulled their deeds.

# 4574

Or, do those who have a disease in their hearts think that Allah will not reveal their hatred?

# 4575

If We willed, We would show them to you and you would recognize them by their marks. But you will surely know them by their twisted speech. Allahknows your deeds.

# 4576

Without doubt We shall test you until We know those who struggle and are patient among you, and make clear your news.

# 4577

Those who disbelieve and bar from the Path of Allah, and break with the Messenger after guidance has been made clear to them shall not hurt Allah a thing, and He will annul their deeds.

# 4578

Believers, obey Allah and His Messenger and never let your labors go in vain!

# 4579

As for those who disbelieve and bar (others) from the Path of Allah and then die as unbelievers? Allah will not forgive them.

# 4580

Therefore, do not be weakened and call out for peace, you shall be the upper ones, and Allah is with you and will not deprive you of your labors.

# 4581

The life of this world is but play and an amusement. If you believe and are cautious, He will give you your wage, and will not ask for your possessions.

# 4582

If He asked you for them, and presses you, you would be mean and He would expose your anger.

# 4583

There you are! You are called upon to spend in the Way of Allah. Some of you are mean; yet whoever is mean is mean only to his own soul. Allah is theRich and you are the poor. If you turn away, He will replace you with another nation, and they will not be like you.

# 4584

Indeed, We have opened for you (Prophet Muhammad) a clear opening,

# 4585

that Allah forgives your past and future sins, and completes His Favor to you, and guides you on a Straight Path,

# 4586

and that Allah helps you with a mighty help.

# 4587

It was He who sent down tranquility into the hearts of the believers so that they might add belief upon belief. To Allah belong the armies of the heavens and the earth. Allah is the Knower, the Wise.

# 4588

(From His Wisdom) He admits the believers, both men and women, into Gardens underneath which rivers flow, there to live for ever, and acquit them of their sins that with Allah is a mighty triumph

# 4589

and that He might punish the hypocrites and the idolaters, both men and women, and those who think evil thoughts of Allah. An evil turn (of fortune) will befall them. The Wrath of Allah is on them, and He has cursed them and prepared for them Gehenna (Hell), an evil arrival!

# 4590

To Allah belong the armies of the heavens and the earth. Allah is the Almighty and the Wise.

# 4591

We have sent you (Prophet Muhammad) as a witness and as a bearer of glad tidings and warning,

# 4592

so that you believe in Allah and His Messenger and that you support him, revere him (Prophet Muhammad), and exalt Him (Allah), at the dawn and in theevening.

# 4593

Those who swear allegiance to you swear allegiance to Allah. The Hand of Allah is above their hands. He who breaks his oath breaks it against his self, but for he that keeps his covenant made with Allah, Allah shall give him a mighty wage.

# 4594

The Bedouins who lagged behind will say to you: 'We were occupied with our possessions and families, so ask Allah to forgive us' But they say with theirtongues what they do not mean in their hearts. Say: 'Who can help you against Allah if it is that He wills harm for you or desires benefit for you? Allah is Aware ofwhat you do'

# 4595

No, you thought that the Messenger and the believers would never return to their families, and this was made to seem fair in your hearts so you harbored evil thoughts, and so you are a destroyed nation.

# 4596

But whosoever disbelieves in Allah and His Messenger; We have prepared a Blazing Fire for the unbelievers.

# 4597

To Allah belongs the Kingdom of the heavens and the earth. He forgives whom He will and punishes whom He will. Allah is Forgiving and Merciful.

# 4598

When you set forth to take the spoils, those Bedouins who lagged behind will say: 'Let us follow you' They hope to change the Words of Allah. Say: 'Youshall not follow us. Allah has said so before' They will reply: 'No, you are envious of us' Rather, they have only understood a little!

# 4599

Say to the Arabs who lagged behind: 'You shall be called upon to fight a mighty nation, unless they embrace Islam. If you are obedient you shall receive agood wage from Allah. But, if you turn away, as you turned your backs before, He will punish you with a painful punishment'

# 4600

There is no fault in the blind, or the lame, or the sick. He who obeys Allah and His Messenger He shall admit him to Gardens underneath which rivers flow; but he who turns away shall be punished with a painful punishment.

# 4601

Allah was pleased with the believers when they swore allegiance to you under the tree and He knew what was in their hearts. Therefore, He sent downtranquility upon them and rewarded them with a victory close by

# 4602

and they took many spoils, and Allah is the Almighty, and the Wise.

# 4603

Allah has promised that you take many spoils. He has hastened this to you, and restrained the hands of people from you so that He makes it a sign to the believers and to guide you on a Straight Path.

# 4604

And there were (other spoils) which you were unable to take. Allah has encompassed it already, Allah is powerful over all things.

# 4605

If the unbelievers had fought you they would have been put to flight, and found none to protect or help them.

# 4606

Such is the way of Allah in days gone by, and you shall find no change in the ways of Allah.

# 4607

It was He who restrained their hands from you and your hands from them in the hollow (Hudaibiah) of Mecca after He had given you victory over them. Allah sees the things you do.

# 4608

They are those who disbelieved and barred you from the Holy Mosque and the offering detained so as not to reach its place of sacrifice if it had not been for certain believing men and certain believing women whom you did not know, you might have trampled upon them, and so sin reached you because of (killing) them while you did not know. In order that Allah admits into His Mercy whom He will, had they (the believers) been easy to distinguish, We would have punished the unbelievers among them with a painful punishment.

# 4609

And when the unbelievers established in their hearts fierce bigotry, the fierce bigotry of ignorance, Allah sent down His tranquility on His Messenger and the believers and firmly fastened to them the Word of 'taqwa' (there is no god except Allah, and Muhammad is His Messenger, as it is the cause of righteousness) to which they have better right and are worthy of it. Allah has knowledge of all things.

# 4610

Indeed, Allah, in truth, has realized His Messenger's vision. You shall enter the Sacred Mosque in security if Allah wills, with hair shaven or cut short and without fear. He knew what you did not know, and granted you a near victory.

# 4611

It is He who has sent His Messenger with guidance and the religion of truth, so that He exalts it above all other religions. Allah is the Sufficient Witness.

# 4612

Muhammad is the Messenger of Allah. Those who are with him are harsh against the unbelievers but merciful to one another. You see them bow andprostrate themselves seeking the bounty and pleasure of Allah. Their mark is on their faces from the trace of prostration. That is their likeness in the Torah and their likeness in the Gospel, as the seed which puts forth its shoot and strengthens it, so that it grows stout and rises straight upon its stalk, delighting the sowers, and through them He enrages the unbelievers. Allah has promised those of them who believe and do good deeds, forgiveness and a great wage.

# 4613

Believers do not advance before Allah and His Messenger. Fear Allah. Allah is the Hearer, the Knower.

# 4614

Believers, do not raise your voices above the voice of the Prophet, nor speak loudly to him as you do to one another lest your works should be annulledwithout your knowledge.

# 4615

Those who lower their voice in the presence of the Messenger of Allah are those whose hearts Allah has tested for warding off (evil). They shall receiveforgiveness and a great wage.

# 4616

Whereas those who call out to you from behind the apartments, most of them lack understanding.

# 4617

If they had patience until you went out to them, it would have been better for them. But Allah is the Forgiving and the Most Merciful.

# 4618

Believers, if an evildoer brings you a piece of news, inquire first, in case you should unwittingly wrong others and then repent of what you have done.

# 4619

Know that the Messenger of Allah is among you. If he were to obey you in many matters, you would surely suffer. But Allah has endeared the Belief to youand beautified it in your hearts, and has made detestable to you disbelief, wrongdoing, and disobedience. Such are those who are righteous

# 4620

by the Favor and Blessing of Allah. Allah is the Knower and the Wise.

# 4621

If two parties of believers fight, reform between them. If either of them is insolent against the other, fight the insolent one till they revert to the order of Allah. If they revert, reform between them with justice, and weigh with justice. Allah loves those who weigh with justice.

# 4622

Believers are indeed brothers, therefore make things right among your two brothers and fear Allah, so that you will be subject to mercy.

# 4623

Believers, do not let people mock other people who may be better than themselves. Do not let women mock women, who may be better than themselves. Do not find fault with one another, nor abuse one another with nicknames. An evil name is disobedience after belief. Those who do not repent are the harmdoers.

# 4624

Believers, abstain from most suspicion, some suspicion is a sin. Neither spy nor backbite one another would any of you like to eat the flesh of his deadbrother? Surely, you would loathe it. Fear Allah, without doubt Allah turns (in mercy) and He is the Merciful.

# 4625

People, We have created you from a male and a female, and made you into nations and tribes that you might know one another. The noblest of you before Allah is the most righteous of you. Allah is the Knower, the Aware.

# 4626

The Arabs declare: 'We believe' Say: 'You do not', rather, say: 'we submit' because belief has not yet found its way into your hearts. If you obey Allah and His Messenger, He will not reduce a thing from of your deeds. Allah is the Forgiving and the Most Merciful.

# 4627

The believers are those who believe in Allah and His Messenger and have not doubted, and who struggled in His Way with their possessions and themselves. Such are those who are truthful.

# 4628

Say: 'Would you teach Allah what your religion is, when Allah knows all that is in the heavens and the earth' Allah has knowledge of all things.

# 4629

They regard it as a favor to you that they have submitted! Say: 'Do not regard your submission as a favor to me, rather, it is Allah who bestows upon you a favor by guiding you to belief, if you are truthful'

# 4630

Indeed, Allah knows the Unseen of the heavens and the earth, and Allah is the Seer of what you do'

# 4631

Qaaf. By the Glorious Koran!

# 4632

No, but they marvel that from among themselves a warner has come to them. The unbelievers say (in mockery): 'This is a marvelous thing!

# 4633

What, when we are dead and turned to dust? That indeed would be an unlikely return'

# 4634

We know all that the earth takes away of them, and a Book of Records is with Us.

# 4635

Rather, they belied the truth when it came to them, and now they are in a state of confusion.

# 4636

What, have they never observed the heaven above them, (and seen) how We built and adorned it, leaving no crack?

# 4637

We spread out the earth and set upon it firm mountains, and We cause every delightful thing to grow in it

# 4638

as a lesson and a reminder to every penitent worshiper.

# 4639

We sent down blessed water from the sky with which We caused gardens and the grains of harvest to grow,

# 4640

and tall palmtrees with compact spathes

# 4641

as a provision for the worshipers; thereby We revived a land that was dead. Such shall be the emerging.

# 4642

Before them, the nation of Noah, the nation of ArRass belied and so did Thamood

# 4643

and Aad, Pharaoh and the brothers of Lot,

# 4644

the dwellers of the Thicket and the nation of Tubba', all belied their Messengers, therefore My threat was realized.

# 4645

What, were We wearied by the first creation? No, indeed; yet they are in doubt about a new creation.

# 4646

Indeed, We created the human. We know the whisperings of his soul, and are closer to him than the jugular vein.

# 4647

When both receivers (the angels) receive, one on his right, the other on his left,

# 4648

whatever phrase he utters, an observer is present.

# 4649

And when the agony of death comes in truth (they will say): 'This is what you have been trying to avoid'

# 4650

And the Horn shall be blown; that is the Day of Threat!

# 4651

Each soul shall come with a driver, and a witness.

# 4652

(It will be said): 'Of this you have been heedless. Therefore, we have now removed your covering. Today your sight is sharp'

# 4653

And his companion will say: 'This is that which I have present'

# 4654

(It will be said): 'Indeed, cast into Gehenna (Hell) every deviating unbeliever,

# 4655

forbidder of good, transgressor and doubter,

# 4656

who has set up with Allah another god. Indeed, you two, cast him into the terrible punishment'

# 4657

And his companion shall say: 'Our Lord, I did not make him insolent, he was far astray'

# 4658

He (Allah) will say: 'Do not dispute before Me. I sent you a warning beforehand.

# 4659

The Word cannot be changed with Me; I do not wrong My worshipers'

# 4660

On that Day We shall ask Gehenna: 'Are you full' And it will answer: 'Are there any more'

# 4661

And Paradise, which is not far away, shall be brought closer to those who were cautious.

# 4662

(It shall be said to them): 'This is that you were promised. It is for every heeding penitent.

# 4663

Whosoever fears the Merciful in the Unseen, and comes with a contrite heart.

# 4664

Enter it in peace. This is the Day of Eternity'

# 4665

There they have all that they desire, and with Us is much more.

# 4666

How many generations, stronger in might than they have We destroyed before them! They searched the land, could they find any asylum?

# 4667

Surely, in this there is a Reminder for he who has a heart or listens attentively while witnessing.

# 4668

In six days We created the heavens and the earth and all that is between them and no weariness touched Us!

# 4669

Bear then with patience what they say. Exalt with the praise of your Lord before sunrise and before sunset.

# 4670

And exalt Him in the night, and at the ends of the prostrations.

# 4671

Listen for the Day when the Caller will call from a nearby place.

# 4672

On the Day when they will hear the Shout, in truth that Day they will emerge.

# 4673

It is We who give life and make to die. To Us is the arrival.

# 4674

Upon that Day the earth will be rent asunder from around them as they hurry forth that is an easy gathering for Us.

# 4675

Indeed, We know what they say. You (Prophet Muhammad) are not a tyrant over them. Therefore, remind by the Koran whosoever fears (My) threat.

# 4676

By the scatterers (the wind) scattering,

# 4677

then the bearers of weight (the clouds),

# 4678

then the easy runners (the ships);

# 4679

then by the distributors (angels), ordered;

# 4680

indeed, that which you are promised is true,

# 4681

and the recompense shall surely happen.

# 4682

By the heaven with its passages,

# 4683

surely, you are in different sayings,

# 4684

and are turned away from him who is turned.

# 4685

Woe to the liars

# 4686

who are heedless in the immersion.

# 4687

'When will the Day of Judgement be' they ask.

# 4688

On that Day they shall be tried at the Fire,

# 4689

'Taste your trial. This is what you have sought to hasten'

# 4690

The righteous shall live among gardens and fountains,

# 4691

receiving what their Lord will give them because before this they were gooddoers.

# 4692

They slept but a little at night,

# 4693

and at dawn would ask forgiveness,

# 4694

and in their wealth was a share for whosoever asked and for whosoever was prevented.

# 4695

For those with sure belief there are signs in the earth,

# 4696

and also in yourselves. Can you not see?

# 4697

In the sky is your provision and that which you are promised.

# 4698

So by the Lord of heaven and earth, it is as true as your speech.

# 4699

Have you heard the story of Abraham's honored guests?

# 4700

They entered to him and said: 'Peace' And he replied: 'Peace, you are people unknown to me'

# 4701

So he turned to his household and brought a fattened calf.

# 4702

He set it before them, saying: 'Will you not eat'

# 4703

Then he conceived a fear about them, and they said: 'Have no fear', and gave him the glad tidings that he was to have a knowledgeable son.

# 4704

(Sarah) his wife came with an exclamation and clasped her face, and said: 'Surely, I am a barren old woman'

# 4705

'Such, says your Lord' they replied: 'He is the Wise, the Knower'

# 4706

'Messengers' said he (Abraham), 'what is your errand'

# 4707

They replied: 'We are sent to a sinful nation,

# 4708

so that we bring down stones of clay upon them

# 4709

marked by your Lord for the sinful'

# 4710

So We brought the believers out of that they were in.

# 4711

But We found in it only one household of those who had surrendered themselves,

# 4712

and left therein a sign for those who fear the painful punishment.

# 4713

In Moses, too, (there were signs). We sent him to Pharaoh with clear authority,

# 4714

but he turned his back with his Assembly, saying: 'He is (either) a sorcerer or a mad man'

# 4715

So We seized him and his hosts and cast them into the sea. Indeed, he was blameworthy.

# 4716

And in Aad. We let loose on them a withering wind

# 4717

that left nothing it came upon, except that it was ashes.

# 4718

And in Thamood it was said to them: 'Take your enjoyment for awhile'

# 4719

But in their pride they turn away from the commandment of their Lord and the thunderbolt struck them whilst they were looking;

# 4720

they could neither stand up straight, nor were they helped.

# 4721

And before them the nation of Noah, indeed they were a debauched nation.

# 4722

We built the heaven with might, and We widely extended it.

# 4723

and We cradled the earth. And We are the Best of Cradlers.

# 4724

We created two kinds of all things, so that you will remember.

# 4725

Therefore, flee to Allah. I am a clear warner to you from Him.

# 4726

Do not set up with Allah another god. I am a clear warner to you from Him.

# 4727

Similarly, no Messenger came to those before them but they said: 'Sorcerer, or mad'

# 4728

Have they handed this down from one to another? No, rather, they are an insolent nation.

# 4729

So turn away from them, you shall not be blamed,

# 4730

But remind, the Reminder will benefit the believers.

# 4731

I have not created mankind and jinn except to worship Me.

# 4732

I do not desire provision from them, nor do I desire that they should feed Me.

# 4733

Surely, Allah is the Provider, the Possessor of Power, the Mighty.

# 4734

The evildoers shall have for their portion, a portion like their companions (who were destroyed before them). Therefore, they should not ask Us to hasten!

# 4735

Woe then to the unbelievers for their Day which they were promised!

# 4736

By the Mount

# 4737

and by the Book in lines

# 4738

in an exposed parchment

# 4739

by the Visited House,

# 4740

and the uplifted roof

# 4741

and the sea that is full

# 4742

surely, the punishment of your Lord is about to come,

# 4743

there is none to prevent it.

# 4744

Upon the Day when the heaven spins dizzily

# 4745

and the mountains move, moving.

# 4746

On that Day woe to those who belied

# 4747

those who are in plunging, playing.

# 4748

On that Day when they shall be pitched into the Fire of Gehenna (Hell),

# 4749

(it will be said to them): 'This is the Fire which you belied!

# 4750

Is this magic, or is it that you do you not see?

# 4751

Roast in it, bear it with or without patience, it is the same, you are only being recompensed for that which you used to do'

# 4752

But in the Gardens the righteous shall live in bliss,

# 4753

rejoicing in all their Lord has given them, and their Lord will guard them against the punishment of Hell.

# 4754

(It will be said): 'Eat and drink with a good appetite because of that which you did'

# 4755

(They shall be) reclining on couches ranged in rows and We shall wed them to houris (virgins of Paradise) with large wide eyes.

# 4756

Those who believe, and whose descendants follow in belief, We will join their descendants to them. And We will not reduce them of anything of their deeds. Every one is pledged for what he has earned.

# 4757

We shall give them fruits and meat as they desire.

# 4758

There they will pass a goblet to one another with neither idle talk nor sin,

# 4759

and youths, of their own, shall pass among them as if they were hidden pearls.

# 4760

They will go to one another asking each other questions:

# 4761

'When we were among our people' they will say, 'we were ever fearful,

# 4762

but Allah has been gracious to us and has protected us from the punishment of the burning wind.

# 4763

Before, we were supplicating to Him. He is the Giving, the Most Merciful'

# 4764

Therefore, remind. By the Favor of Allah, you are neither a soothsayer, nor mad.

# 4765

Or do they say: 'He is a poet, we are waiting for some misfortune to befall him'

# 4766

Say: 'Wait if you will; I shall be waiting with you'

# 4767

Or, do their intellects order them to do this? Or, are they an insolent people?

# 4768

Do they say: 'He has invented it' No, they do not believe.

# 4769

Let them produce a phrase like it, if what they say is true!

# 4770

Or, were they created out of nothing? Or, were they their own creators?

# 4771

Or, did they create the heavens and the earth? No, their belief is not certain!

# 4772

Or, are the treasures of your Lord in their keeping? Or, are they the controllers?

# 4773

Or, do they have a ladder on which they listen? Then let any of them that has listened bring a clear authority.

# 4774

Or, has He daughters, and they sons?

# 4775

Or, do you ask them for a wage, so that they become weighed down in debt?

# 4776

Or, is the Unseen in their keeping, so they are writing it down?

# 4777

Or, do they desire to outwit? The unbelievers are the outwitted.

# 4778

Or, do they have a god, other than Allah? Exaltations to Allah above that which they associate!

# 4779

Even if they saw lumps falling from the sky they would say: 'A massed cloud'

# 4780

So leave them till they encounter their Day in which they shall be thunderstruck.

# 4781

The Day when their guile shall not relieve them a thing, and they shall not be helped.

# 4782

For the harmdoers there is indeed, a punishment before that, but most of them do not know.

# 4783

And be patient under the Judgement of your Lord, surely, you are before Our Eyes. And exalt with the praise of your Lord when you arise,

# 4784

and exalt Him in the night and at the declining of the stars.

# 4785

By the star when it plunges,

# 4786

your companion is neither astray, neither errs,

# 4787

nor does he speak out of desire.

# 4788

Indeed it is not except a Revelation which is revealed,

# 4789

taught by One who is Stern in power.

# 4790

Of might, he (Gabriel) stood firm

# 4791

while he was in the highest horizon;

# 4792

then he drew near, and became close

# 4793

he was but two bows' length or even nearer,

# 4794

so (Allah) revealed to His worshiper (Gabriel) that which he revealed (to Prophet Muhammad).

# 4795

His heart did not lie of what he saw.

# 4796

What, will you dispute with him about what he sees!

# 4797

Indeed, he saw him in another descent

# 4798

at the Lote Tree (Sidrat tree) of the ending

# 4799

close to the Garden of Refuge.

# 4800

When there comes to the Lote Tree, that which comes

# 4801

his eyes did not swerve, nor did they stray

# 4802

for indeed he saw one of the greatest signs of his Lord.

# 4803

(Among the idols) have you considered allat and al'uzza,

# 4804

and, another, the third manat?

# 4805

What, have you males, and He females!

# 4806

That is indeed an unjust division.

# 4807

They are but names, named by you and your fathers. Allah has not sent down any authority for them. They follow conjecture and their soul's desire, eventhough the guidance of their Lord has come to them.

# 4808

Is the human to have whatever he fancies?

# 4809

To Allah belongs the Eternal life and the first life.

# 4810

How many an angel is there in the heavens whose intercession shall not benefit until Allah gives permission to whom He will and is pleased.

# 4811

Those who disbelieve in the Everlasting Life call the angels by female names.

# 4812

Yet of this they have no knowledge, they follow mere conjecture, and conjecture does not help against truth.

# 4813

So turn from those who turn away from Our Remembrance and only desire this present life.

# 4814

That is all they have of knowledge. Your Lord knows best who has strayed from His Path, and those who are guided.

# 4815

To Allah belongs whatsoever is in the heavens and whatsoever is in the earth. He will recompense the evildoers according to their deeds, and recompense those who have done good with the finest reward

# 4816

those who avoid the major sin and indecencies except the small sins, indeed your Lord is of immense forgiveness and He is more knowledgeable of you when He created you from the earth and when you were still unborn in your mothers' wombs. Do not praise yourself. Allah knows the cautious.

# 4817

Have you considered he who turns his back,

# 4818

and gives a little, grudgingly?

# 4819

Or, does he possess knowledge of the Unseen, and can therefore see?

# 4820

Or, has he not been told of that which is in the Scrolls of Moses

# 4821

and Abraham, who paid his debt in full?

# 4822

That no soul shall bear another's burden,

# 4823

and that everyone shall have in his account only that which he worked for,

# 4824

and that his work is surely seen

# 4825

then, he shall be recompensed for it in full repayment

# 4826

and that the final return is to your Lord,

# 4827

that it is He who causes to laugh and causes to weep.

# 4828

and that it is He who causes to die, and causes to live

# 4829

and that it is He who created pairs, the male and the female,

# 4830

from an ejaculated drop (of sperm),

# 4831

and that upon Him is the second creation

# 4832

and that it is He who gives riches and causes to hoard,

# 4833

and that He is the Lord of (the star) Sirius,

# 4834

that it was He that destroyed ancient Aad

# 4835

and Thamood, sparing no one,

# 4836

and before them the nation of Noah, they exceeded in evil and were insolent.

# 4837

He plunged the villages

# 4838

so that there came upon them that which came.

# 4839

So which then of your Lord's favors do you dispute?

# 4840

This is a warner from the warners of ancient times.

# 4841

The Imminent is near at hand;

# 4842

none except Allah can disclose it.

# 4843

Do you marvel then at this discourse (the Koran)?

# 4844

Or do you laugh, and do you not weep

# 4845

while you are thoughtless?

# 4846

Rather, prostrate to Allah and worship Him.

# 4847

The Hour is drawing near, and the moon is split (in two).

# 4848

Yet if they see a sign (the unbelievers) turn their backs and say: 'This is but a continuation of sorcery'

# 4849

They have belied, and follow their own fancies. But, every issue will be settled!

# 4850

Tidings containing a deterrent have come to them

# 4851

which are full of wisdom; but the warnings do not help.

# 4852

Therefore, turn away from them. On the Day when the Caller summons them to a terrible thing,

# 4853

their eyes will be humbled as they come out from their graves as if they were scattered locusts,

# 4854

running (with their necks extended) to the Caller. The unbelievers will say: 'This is indeed a harsh Day'

# 4855

(Long) before them the nation of Noah belied. They belied Our worshiper saying: 'Mad' and he was reprimanded.

# 4856

Then he supplicated to his Lord, (saying): 'I am overcome, help me'

# 4857

We opened the Gates of Heaven with torrential water

# 4858

and caused the earth to gush with springs, so that the waters met for a predestined matter.

# 4859

We carried him in a well built, watertight vessel made from planks (of wood)

# 4860

that ran on under Our Eyes, a recompense for him because he had been disbelieved.

# 4861

We have left it as a sign. Is there any that will remember?

# 4862

How then were My punishment and My warnings!

# 4863

We have made the Koran easy to remember, is there any that will remember!

# 4864

Aad too belied. How then were My punishment and My warnings!

# 4865

And We sent against them a howling wind in a Day of continuous of ill fortune

# 4866

and snatched people up as though they were stumps of uprooted palmtrees.

# 4867

How then were My punishment and My warnings!

# 4868

We have made the Koran easy to remember, is there any that will remember?

# 4869

Thamood, too, belied Our warnings.

# 4870

They said: 'Are we to follow a mortal who is one of us? Then indeed, we would surely be in error and insane.

# 4871

Out of all of us has the Reminder been given to him alone? Rather, he is indeed an arrogant liar'

# 4872

(To him We said): 'Tomorrow they shall know who is the arrogant liar.

# 4873

We are sending to them as a trial, a shecamel, so watch them and have patience.

# 4874

Tell them that the water is to be divided between them, a drink each for them in turn'

# 4875

But they called their companion who took hold of her and hamstrung her.

# 4876

How then were My punishment and My warnings!

# 4877

Then We sent against them one Shout and they became like the trampled twigs of the (sheep) penbuilder.

# 4878

We have made the Koran an easy Remembrance, is there any that will remember!

# 4879

The nation of Lot belied Our warnings.

# 4880

We let loose on all of them a squall of claystones, except for the house of Lot whom We saved at dawn

# 4881

through Our Mercy. So it is that We recompense the thankful.

# 4882

He had warned them of Our assault but they disputed the warnings.

# 4883

They even solicited of him his guests, but We obliterated their eyes: 'Now, taste My punishment and My warnings'

# 4884

And at daybreak a determined punishment came upon them.

# 4885

'Now, taste My punishment and My warnings'

# 4886

We have made the Koran an easy Remembrance, is there any that will remember!

# 4887

The warnings also came to Pharaoh's people,

# 4888

but they belied all Our signs so We seized them with the seizing of the Mighty, Powerful.

# 4889

What then, are your unbelievers better than those? Or do you have an immunity (written) in the Scrolls?

# 4890

Or do they say: 'We are a gathering that will be victorious'

# 4891

Most certainly their gatherings shall be routed, and they will turn their backs.

# 4892

Rather, the Hour is their encounter. And that Hour will be most calamitous and bitter.

# 4893

Indeed the wrongdoers are in error and a raging fire.

# 4894

On the Day when they are dragged on their faces into the Fire, (it will be said to them): 'Taste the touch of the Scorching'

# 4895

Indeed, We have created all things according to a measure.

# 4896

And Our Order is but one word like the flashing of an eye.

# 4897

And We destroyed those like you, is there any that will remember!

# 4898

All their deeds are in the Scrolls,

# 4899

everything, be it great or small, is recorded.

# 4900

Indeed, the cautious shall live amid gardens and a river,

# 4901

in a secure abode, in the presence of the Powerful King.

# 4902

The Merciful

# 4903

has taught the Koran.

# 4904

He created the human

# 4905

and taught him its pronunciation.

# 4906

The sun and the moon to a reckoning.

# 4907

The stars and the trees prostrate themselves.

# 4908

He raised the heaven on high and set the scale.

# 4909

Do not transgress the scales.

# 4910

Give just weight and do not skimp the scales.

# 4911

He set down the earth for the creation.

# 4912

Therein are fruits and palm trees with sheaths,

# 4913

the grain in the blade; and aromatic herbs.

# 4914

Which favors of your Lord will you both (humans and jinn) belie?

# 4915

He created the human from clay, like earthenware

# 4916

and He created the jinn from smokeless fire.

# 4917

Which favors of your Lord will you both belie?

# 4918

The Lord of the Two Easts, the Lord of the Two Wests.

# 4919

Which favors of your Lord will you both belie?

# 4920

He has let forth the two seas, they meet together,

# 4921

and between them is a barrier which they do not overpass.

# 4922

Which favors of your Lord will you both belie?

# 4923

Pearls and corals come from both.

# 4924

Which favors of your Lord will you both belie?

# 4925

Also, His are the ships that run, raised up like mountains upon the sea.

# 4926

Which favors of your Lord will you both belie?

# 4927

All that live on it will perish.

# 4928

Yet the Face of your Lord will abide forever, Majestic and Splendid.

# 4929

Which favors of your Lord will you both belie?

# 4930

Whosoever is in the heaven and earth ask Him. Every day He is upon an affair (He reveals according to His Eternal determination).

# 4931

Which favors of your Lord will you both belie?

# 4932

We shall surely aim, O both burdened.

# 4933

Which favors of your Lord will you both belie?

# 4934

Tribe of jinn and of human, if you are able to penetrate the provinces of heaven and earth, pass through them! But you shall not pass through except with a power!

# 4935

Which favors of your Lord will you both belie?

# 4936

Flames of fire and molten copper shall be loosed against you, and you shall not be helped.

# 4937

Which favors of your Lord will you both belie?

# 4938

When the heaven splits asunder and turns crimson, like red leather.

# 4939

Which favors of your Lord will you both belie?

# 4940

On that Day, neither human nor jinn shall be asked about his sin.

# 4941

Which favors of your Lord will you both belie?

# 4942

The sinners shall be known by their mark, they shall be seized by their forelocks and their feet.

# 4943

Which favors of your Lord will you both belie?

# 4944

This is Gehenna (Hell) which the sinners belied,

# 4945

they shall go round between it, and between a hot, boiling water.

# 4946

Which favors of your Lord will you both belie?

# 4947

And for he who fears the standing (before) his Lord there are two Gardens.

# 4948

Which favors of your Lord will you both belie?

# 4949

(Gardens) with many branches.

# 4950

Which favors of your Lord will you both belie?

# 4951

Therein are two running fountains.

# 4952

Which favors of your Lord will you both belie?

# 4953

Therein are two kinds of every fruit.

# 4954

Which favors of your Lord will you both belie?

# 4955

(They shall) recline on couches lined with brocade, and the fruits of the Gardens will be near at hand.

# 4956

Which favors of your Lord will you both belie?

# 4957

Therein are maidens who restrain their glances, whom neither human nor jinn have touched before.

# 4958

Which favors of your Lord will you both belie?

# 4959

As (lovely as) rubies and as (beautiful as) coral.

# 4960

Which favors of your Lord will you both belie?

# 4961

Shall the recompense of goodness be anything other than goodness?

# 4962

Which favors of your Lord will you both belie?

# 4963

And beside these there shall be two Gardens.

# 4964

Which favors of your Lord will you both belie?

# 4965

The greenest of green pastures.

# 4966

Which favors of your Lord will you both belie?

# 4967

Therein are two gushing fountains of water.

# 4968

Which favors of your Lord will you both belie?

# 4969

In them are fruits, palm trees and pomegranates.

# 4970

Which favors of your Lord will you both belie?

# 4971

In them shall be good and pleasing.

# 4972

Which favors of your Lord will you both belie?

# 4973

Maidens (of Paradise, Houris) in cloistered cool pavilions.

# 4974

Which favors of your Lord will you both belie?

# 4975

Neither human nor jinn will have touched them before.

# 4976

Which favors of your Lord will you both belie?

# 4977

Reclining on green cushions and fine carpets.

# 4978

Which favors of your Lord will you both belie?

# 4979

Blessed be the Name of your Lord, Majestic, Splendid.

# 4980

When the Event (the resurrection) comes

# 4981

there is no denying its coming

# 4982

(it will) abase (some) and exalt (others).

# 4983

When the earth is shaken

# 4984

and the mountains fragmented

# 4985

becoming scattered dust,

# 4986

you shall be divided into three parties,

# 4987

Companions of the Right, what are the Companions of the Right?

# 4988

Companions of the Left, what are the Companions of the Left?

# 4989

And the Outstrippers, the Outstrippers

# 4990

those are they brought near (to their Lord)

# 4991

in the Gardens of Delight,

# 4992

a host of the ancients

# 4993

but only a few from the later generations.

# 4994

on lavish couches

# 4995

they shall recline, facing each other,

# 4996

(and there) shall wait on them immortal youths

# 4997

with goblets and ewers, and a cup from a spring

# 4998

that will neither make the head throb, nor intoxicate,

# 4999

with fruits of their own choice

# 5000

and any flesh of fowl that they desire.

# 5001

And wideeyed houris

# 5002

like hidden pearls,

# 5003

a recompense for all that they did.

# 5004

There they shall hear no idle talk, no cause of sin,

# 5005

but only the saying: 'Peace, Peace'

# 5006

The Companions of the Right

# 5007

(will be) among thornless Lote trees.

# 5008

Bananatrees, piled

# 5009

and continuous shade,

# 5010

and flowing water

# 5011

and an abundance of fruits,

# 5012

unfailing and not forbidden.

# 5013

And couches raised up.

# 5014

Indeed We formed them (the houris and all believing women),

# 5015

and made them virgins,

# 5016

chaste, loving companions of the same age

# 5017

for the Companions of the Right

# 5018

a multitude of the ancients,

# 5019

and a multitude of the later people.

# 5020

As for the Companions of the Left

# 5021

(they shall live) amid burning winds and boiling water,

# 5022

in the shadow of a smoking blaze,

# 5023

neither cool nor good.

# 5024

Before they lived at ease,

# 5025

and persisted in the great sin

# 5026

and constantly said: 'What, when we are dead and become dust and bones, shall we then be restored to life?

# 5027

What, and our fathers, the ancients'

# 5028

Say: 'Those of ancient times and those of later times

# 5029

shall be gathered together to the appointed time on a known Day'

# 5030

Then you went astray, you that belied,

# 5031

you shall eat (the fruit) of the Tree of Zakkum.

# 5032

You shall fill your bellies with it,

# 5033

and drink boiling water on top of that,

# 5034

and you will drink as the lapping of thirsty camels.

# 5035

Such shall be your hospitality on the Day of Recompense.

# 5036

We created you, why will you not believe!

# 5037

Have you thought about what (sperm) you ejaculate?

# 5038

Did you create it, or are We the Creator?

# 5039

It was We who decreed death among you. We will not be surpassed

# 5040

that We will change you and cause you to grow again in a way you do not know.

# 5041

You have surely known of the first creation. Why then, will you not remember!

# 5042

Ponder upon the soil you till,

# 5043

is it you that sow it, or are We the Sower?

# 5044

If We will, We would make it broken stubble and you would remain wondering,

# 5045

(Saying:) 'We are laden with debts!

# 5046

Rather, we have been prevented'

# 5047

Have you thought about the water you drink?

# 5048

Is it you that send it down from the clouds or We?

# 5049

If We will, We would make it bitter, why then do you not give thanks?

# 5050

Have you thought about the fire you kindle?

# 5051

Is it you that originated its tree, or are We the Originator?

# 5052

We have made it a reminder, and a blessing to the traveler.

# 5053

Then, exalt the Name of your Lord, the Great.

# 5054

I swear by the fallings of the stars

# 5055

and that is a mighty oath, if you but knew

# 5056

it is indeed a Glorious Koran,

# 5057

in a Book protected (from tampering)

# 5058

which none shall touch except the purified;

# 5059

a sending down from the Lord of all the Worlds.

# 5060

What, do you hold this discourse in disdain,

# 5061

do you make it your provision to belie it?

# 5062

Why, then, when the soul leaps up to the throat of the dying

# 5063

and you are watching at that time

# 5064

We are nearer to him than you, but you do not see

# 5065

why then, if you are not revived,

# 5066

do you not restore his soul, if you are truthful?

# 5067

If he is among the near

# 5068

there shall be calmness and ease, a Garden of Delight.

# 5069

If he is a Companion of the Right

# 5070

(he will be greeted with): 'Peace be upon you, Companion of the Right'

# 5071

But, if he is of those who belied, and went astray,

# 5072

there shall be a hospitality of boiling water,

# 5073

and a roasting in Hell.

# 5074

Indeed, this is the certain truth.

# 5075

So exalt the Name of your Lord, the Great.

# 5076

All that is in the heavens and earth exalt Allah. He is the Almighty, the Wise.

# 5077

To Him belongs the Kingdom in the heavens and earth. It is He who revives and causes to die, and He has power over all things.

# 5078

He is the First and the Last, the Clear and the Hidden. He has knowledge of all things.

# 5079

He created the heavens and the earth in six days, and willed to the Throne. He knows what penetrates the earth and all that emerges from it; all that descends from heaven and all that ascends to it. He is with you wherever you are. Allah sees the things you do.

# 5080

To Him belongs the Kingdom of the heavens and the earth. To Him all matters shall return.

# 5081

He causes the night to enter into the day and the day to enter into the night. He has knowledge of the thoughts of the innermost of the chests.

# 5082

Believe in Allah and His Messenger and spend (in charity) of that which He has made you successors. Whosoever of you believes and spends shall have amighty wage.

# 5083

Why is it that you do not believe in Allah, when the Messenger calls on you to believe in your Lord, and He has made a covenant with you if you arebelievers?

# 5084

It is He who sends down clear verses to His worshiper, so that He brings you out of the darkness into the light. Indeed, Allah is the Gentle, the Most Merciful to you.

# 5085

And why is it that you do not spend in the Way of Allah, when the inheritance of the heavens and earth belong to Allah alone? Those who spent before the victory and took part in the fighting are mightier in rank and are not equal to those who spent and fought thereafter. Yet, Allah has promised each a fine reward, and Allah is Aware of what you do.

# 5086

Who will lend a generous loan to Allah? He will multiply it for him and he shall receive a generous wage.

# 5087

The Day (will surely come) when you shall see believing men and women with their light running before them on their right hands, (it will be said to them):'Glad tidings for you this Day. You shall live for ever in Gardens underneath which rivers flow! That is indeed the mighty triumph.

# 5088

On that Day the hypocrites, both men and women, will say to the believers: 'Wait for us so that we can take from your light' But they will be answered: 'Go back and seek a light' And a wall with a door shall be between them. Inside it there is mercy, and outside will be the punishment.

# 5089

They will call out to them, saying: 'Were we not with you' 'Yes' they will reply, 'but you tempted yourselves, you waited (for problems to befall thebelievers), and you doubted, and were deluded by your own fancies until the Command of Allah came, and the deluder (satan) deluded you concerning Allah.

# 5090

Today no ransom shall be accepted from you or from the unbelievers. Your shelter is the Fire, that is your sponsor, the worst arrival'

# 5091

Is it not time that the hearts of the believers be humbled to the Remembrance of Allah and the truth which He has sent down? They should not be like those who were given the Book before this, whose time became very long so that their hearts became hardened. Many of them were impious.

# 5092

Know that Allah revives the earth after it was dead. We have made plain to you the signs in order that you understand.

# 5093

Indeed, those who give in charity, be they men or women, and those who lend a good loan to Allah, shall be repaid in multiples. They shall receive agenerous wage.

# 5094

Those who believe in Allah and His Messengers are the sincere and the martyrs before their Lord, they shall have their reward and their light. But those that disbelieve and belied Our verses are the inhabitants of Gehenna (Hell).

# 5095

Know that the life of this world is but play and an amusement, and adornment, and a cause for boasting among you, a rivalry for greater riches and children. It is like rain whose vegetation pleases the unbelievers, but then it withers and turns yellow, becoming broken stubble. In the Everlasting Life is a terrible punishment, forgiveness, and great pleasure from Allah. The life of this world is nothing except the joy of delusion.

# 5096

Therefore, race for forgiveness from your Lord, and for a Garden as wide as heaven and earth, prepared for those who believe in Allah and His Messengers. Such is the Favor of Allah; He gives it to whom He will. Allah is the Owner of great favor.

# 5097

No affliction can befall either the earth, or yourself, except that it is (written) in a Book before We created it. That is easy for Allah;

# 5098

so that you will not be saddened for whatever does not come to you, nor be overjoyed in what has come to you. Allah does not love those who are proudand boastful

# 5099

nor those who are mean, and encourage others to be mean. And he that turns away, (know) that Allah is Rich and Praised.

# 5100

We have sent Our Messengers with proofs, and sent them with the Book and the Scales, so that people might establish the Scale (of justice). We have sent down iron in which there is great might and diverse benefit for people, so that Allah knows those who help Him and His Messengers in the Unseen. Indeed, Allah is the Strong, the Almighty.

# 5101

We sent forth Noah and Abraham, and appointed the Prophethood and the Book to be given to their descendants. Some were guided, but many wereimpious.

# 5102

Following them We sent Our (other) Messengers, and We sent following in their footsteps, (Prophet) Jesus, the son of Mary and gave him the Gospel, and put tenderness and mercy in the hearts of his followers. As for monasticism, they invented it thereby seeking the pleasure of Allah. We did not write it for them, and they did not observe it as it should be observed. We gave to those of them who believed their wage, but many of them are impious.

# 5103

Believers, fear Allah and believe in His Messenger (Prophet Muhammad), He will give you a double portion of His Mercy and He will make for you a light inwhich to walk, and forgive you; Allah is the Forgiver and the Most Merciful.

# 5104

So that the People of the Book may know that they have no power over any of the favors of Allah; that the favors are in the Hand of Allah; He gives it towhom He will. The Favor of Allah is the Great.

# 5105

Allah has heard the words of her that reasons with you (Prophet Muhammad) concerning her husband and made her complaint to Allah. Allah has heard both of you discussing with one another. Indeed, Allah is the Hearer, the Seer.

# 5106

Those of you who say to their wives, 'Be as my mother's back' indeed, they are not their mothers. Their mothers are only those who gave birth to them. Indeed they speak dishonorably and falsely. But Allah is the Pardoning, the Forgiving.

# 5107

Those who say to their wives, 'Be as my mother's back' then retract their words thereafter shall set a person free before they touch each other again. By that you are admonished. Allah is Aware of all that you do.

# 5108

He who is unable shall fast for two successive months before they touch one another. If he is unable to do this, let him feed sixty needy people that, so that you believe in Allah and His Messenger. Such are the bounds of Allah. There is a painful punishment awaiting the unbelievers.

# 5109

Those who oppose Allah and His Messenger shall be frustrated just as those before them were frustrated. We have sent down proofs and clear verses, and for the unbelievers, there is a humiliating punishment.

# 5110

On the Day when Allah will raise them up all together He will inform them of what they did. Allah has taken count of it, although they have forgotten. Allah is Witness to all things.

# 5111

Have you not seen that Allah knows that which is in the heavens and the earth? There is no secret talk between three but He is the fourth of them; nor between five but He is the sixth of them; nor between fewer or more but He is with them wherever they are. Then, on the Day of Resurrection, He will inform them of what they have done. Surely, Allah has knowledge of all things.

# 5112

Have you not seen those who were forbidden to talk in secrecy together? They return to that which they are forbidden and talk secretly together in sin andhatred, and in disobedience to the Messenger. Then, when they come to you they greet you with greetings with which Allah does not greet you, and they say within themselves: 'Why does Allah not punish us for what we say' Gehenna (Hell) suffices them, they shall be roasted, an evil arrival!

# 5113

Believers, when you talk in secret do not talk together in sin and hatred, and disobedience towards the Messenger, but talk of piety and caution. Fear Allah before whom you shall be gathered.

# 5114

Talking together maliciously in secret is from satan, so that believers should sorrow, yet he can not harm them at all, except by the permission of Allah. In Allah let the believers put their trust.

# 5115

Believers, make room in your sitting places when it is asked of you, and Allah will make room for you. When you are asked to move, so move, and Allahwill raise up in ranks those who believed among you and those who have been given knowledge. Allah is Aware of what you do.

# 5116

Believers, when you consult with the Messenger, present before your consultation a free will offering. That is best and purest for you. But if you lack themeans, Allah is the Forgiver and the Most Merciful.

# 5117

Are you afraid to offer a freewill offering before your consultation? But if you do not, Allah will turn to you again, then establish the prayer and pay theobligatory charity, and be obedient to Allah and His Messenger. Allah is Aware of what you do.

# 5118

Do you see those who have been guided by a nation that incurred the Wrath of Allah? They belong neither to you, nor to them, and knowingly they swear to lies.

# 5119

Allah has prepared for them a grievous punishment. Evil indeed is that which they have done.

# 5120

They have taken their oaths as a disguise and bar from the Way of Allah, so a humiliating punishment awaits them.

# 5121

Neither their wealth nor their children shall help them a thing against Allah. They are the inhabitants of the Fire, and there they shall live for ever.

# 5122

On the Day when Allah shall raise them all up, they will swear to Him as they now swear to you thinking that they are upon something. Indeed, they are the liars!

# 5123

satan has mastered them and caused them to forget the Remembrance of Allah. Those are satan's party; and satan's party shall assuredly be the losers.

# 5124

Those who oppose Allah and His Messenger shall be among the humiliated.

# 5125

Allah has written: 'I will surely be the Victor, I and My Messengers' Surely, Allah is the Strong, the Almighty.

# 5126

You shall find no nation believing in Allah and the Last Day loving anyone that opposes Allah and His Messenger, even though they be their fathers, theirsons, their brothers, or their tribe. Those, He has written upon their hearts faith and strengthened them with a spirit from Him. He will admit them to the Gardensunderneath which rivers flow, where they shall live for ever. Allah is pleased with them and they are pleased with Him. They are the Party of Allah; and the Party ofAllah are the winners.

# 5127

All that is in heavens and earth exalt Allah. He is the Almighty, the Wise.

# 5128

It was He who expelled the unbelievers among the People of the Book from their homes into the first exile. You did not think that they would go out, and they thought their fortresses would protect them from Allah. But Allah came upon them from where they did not expect, casting terror into their hearts that their homes were destroyed by their own hands as well as by the hands of the believers. Therefore, take heed you that have eyes.

# 5129

Had it been that Allah had not decreed that they should be dispersed, He would have surely punished them in this world. And in the Everlasting Life thepunishment of the Fire awaits them,

# 5130

because they broke their promise with Allah and His Messenger; and whosoever breaks their promise with Allah Allah is Stern in retribution.

# 5131

Whatever palmtree you cut down or left standing upon its roots, it is by the permission of Allah, so that He might humiliate the impious.

# 5132

And whatever spoils of war Allah has given to His Messenger from them, you hastened on neither horse nor camel against them, but Allah gives HisMessengers authority over whom He will. Allah is Powerful over all things.

# 5133

The spoils of war taken from the villagers and given by Allah to His Messenger belong to Allah, His Messenger and the near kinsmen, the orphans, the needy and the destitute traveler, so that it is not something taken in turns by the rich among you. Whatever the Messenger gives you, accept it; and whatever he forbids you, abstain. And fear Allah; surely, Allah is Stern in retribution.

# 5134

(A share of the spoils shall also be given) to the poor emigrants who were expelled from their homes and their possessions, who seek the Favor and Pleasure of Allah, and help Allah and His Messenger. These are they that are truthful.

# 5135

And those before them who had made their dwelling in the abode (the City of Madinah), and because of their belief love those who have emigrated to them; they do not find any (envy) in their chests for what they have been given and prefer them above themselves, even though they themselves have a need. Whosoever is saved from the greed of his own soul, they are the ones who win.

# 5136

Those who came after them say: 'Forgive us our Lord, and forgive our brothers who were believers before us. Do not put in our hearts any spite towards those who believe. Lord, You are the Gentle, the Most Merciful'

# 5137

Have you not seen the hypocrites? They say to their brothers among the People of the Book who disbelieve, 'If they expel you, we will go with you. We willnever obey anyone against you. If they fight against you we will certainly help you' But Allah bears witness that they are, without doubt, liars.

# 5138

If they are expelled or fought against, they will not go with them, nor will they will help them. Indeed, if they helped them, they would turn their backs andthen they would not be helped.

# 5139

Their fear of you in their hearts is greater than their fear of Allah; that is because they are a people who do not understand.

# 5140

They will never fight against you all together except from fortified villages or from behind walls. Their courage is great among themselves; you think them to be united, yet their hearts are not united. That is because they are a people who have no sense.

# 5141

Just as those who, not long before, tasted the mischief of their actions, there awaits for them a painful punishment.

# 5142

Like satan when he said to the human, 'Disbelieve'; then as soon as he disbelieved, he said, 'Indeed, I am innocent of you, surely, I fear Allah, the Lord of all the Worlds'

# 5143

Their end shall be that they live for ever in the Fire. That is the recompense of the harmdoers.

# 5144

Believers, fear Allah. Let every soul look to what it has forwarded for the future, and fear Allah, for Allah is Aware of the things you do.

# 5145

Do not be like those who have forgotten Allah so that He has caused them to forget their souls. Those, they are the evildoers.

# 5146

The inhabitants of the Fire and the inhabitants of Paradise are not equal. The inhabitants of Paradise shall be triumphant.

# 5147

Had We sent down this Koran upon a mountain, you would have seen it humble itself and split asunder for fear of Allah. Such are the parables we strike for people so that they will reflect.

# 5148

He is Allah, there is no god except He. He knows the Unseen and the Visible. He is the Merciful, the Most Merciful.

# 5149

He is Allah, there is no god except He. He is the King, the Pure, the Peace, the Confirmer, the Watchful, the Almighty, the Compeller, the Sublime. Exalted is Allah, above all that they associate!

# 5150

He is Allah, the Creator, the Originator, the Shaper. To Him belong the Most Beautiful Names. All that is in the heavens and earth exalt Him. He is theAlmighty, the Wise.

# 5151

Believers, do not take My enemy and your enemy for your guides, offering them love when they have disbelieved the truth that has come to you, who expelthe Messenger and yourselves because you believe in Allah, your Lord! If you go out to struggle in My way seeking My pleasure, but secretly love them, I know well what you conceal and what you reveal; whosoever of you does this will have gone astray from the Right Path.

# 5152

If they come upon you, they will be your enemies, and stretch out their hands and tongues to do evil to you. They wish that you would disbelieve.

# 5153

On the Day of Resurrection neither your blood relatives nor your children shall be of benefit to you. Allah will differentiate between you, and Allah sees thethings you do.

# 5154

You have a good example in Abraham and those with him. They said to their nation: 'We are quit of you, and that which you worship, other than Allah. We disbelieve you, enmity and hatred has shown itself between us for ever until you believe in Allah alone' Except that Abraham said to his father: 'Surely, I shall supplicate to ask for forgiveness for you although I have no power to do anything for you with Allah' ' Our Lord, in You we have put our trust; to You we turn, and to You is the arrival,

# 5155

Our Lord, do not make us a temptation for the unbelievers and forgive us. Our Lord, You are the Almighty, the Wise'

# 5156

In those there is a good example for whosoever hopes for Allah and the Last Day. Whosoever turns away, indeed, Allah is the Rich and the Praised.

# 5157

It may be that Allah establishes love between you and those with whom you are at enmity. Allah is the Powerful, Allah is the Forgiving and the Most Merciful.

# 5158

Allah does not forbid you to be kind and to act justly to those who have neither made war on your Religion nor expelled you from your homes. Allah loves the just.

# 5159

But Allah only forbids you to be guided by those who have fought against you in your religion's cause and expelled you from your homes or have supportedothers in your expulsion. Whosoever takes them as guides are harmdoers.

# 5160

Believers, when believing women come to you as emigrants, test them. Allah best knows their belief. If you find them to be believers do not return them to the unbelievers; they are not permitted to the unbelievers, nor are the unbelievers permitted to them. But give back to the unbelievers what they have spent, and there is no fault in you to marry such women, provided you give them their dowries. Do not hold on to the ties with unbelieving women, ask what you have spent and let them ask what they have spent. Such is the Judgement of Allah; He judges between you; and Allah is the Knower, and the Wise.

# 5161

If any of your wives desert you to be with the unbelievers and you retaliate, give those whose wives who have deserted the equivalent of what they have spent. And fear Allah in whom you believe.

# 5162

O Prophet, when believing women come to you and swear loyalty to you upon the condition that they will not associate anything with Allah, and will notsteal, nor commit adultery, nor slay their children, nor fabricate slander between their hands and their feet, nor disobey you in any honorable thing, supplicate to Allah for forgiveness for them, Allah is the Forgiving and the Most Merciful.

# 5163

Believers, do not take as guides those who have incurred the Wrath of Allah and who despair of the Everlasting Life (to come), like the unbelieversdespaired of the inhabitants of the tombs (that they shall be resurrected).

# 5164

All that is in the heavens and earth exalt Allah. He is the Almighty, the Wise.

# 5165

Believers, why do you say what you never do?

# 5166

It is most hateful to Allah that you should say that which you do not do.

# 5167

Allah loves those who fight in His Way lining up as if they were a stacked building.

# 5168

And when Moses, said to his nation: 'Why do you harm me, when you know that I am the Messenger of Allah sent to you' But when they swerved away Allah caused their hearts to swerve. Allah never guides impious people.

# 5169

And when (Prophet) Jesus, the son of Mary said: 'Children of Israel, I am sent to you by Allah to confirm the Torah that was before me, and to give news of a Messenger (Prophet Muhammad) who will come after me whose name shall be Ahmad' Yet when he came to them with clear proofs, they said: 'This is clearsorcery'

# 5170

And who does greater evil than he who forges a lie against Allah, when he is being called to Islam? Allah does not guide the harmdoing people.

# 5171

They seek to extinguish the Light of Allah with their mouths; but Allah will complete His Light, much as the unbelievers dislike it.

# 5172

It is He who has sent His Messenger with guidance and the Religion of Truth, so that He raises it above all religions, much as the unbelievers dislike it.

# 5173

Believers! Shall I direct you to a commerce that will save you from a painful punishment?

# 5174

You shall believe in Allah and His Messenger and struggle for His Way with your possessions and yourselves. That is better for you, if you but knew.

# 5175

He will forgive you your sins and admit you to Gardens underneath which rivers flow, and to fine dwelling places in the Gardens of Eden. That is the mightytriumph.

# 5176

And other things that you love, victory from Allah and an opening that is near. (O Prophet Muhammad) give glad tidings to the believers.

# 5177

Believers, be the helpers of Allah. When (Prophet) Jesus, the son of Mary said to the disciples: 'Who will be my helpers unto Allah' The disciples replied:'We will be the helpers of Allah' A party of the Children of Israel believed, and a party disbelieved. So, We supported those who believed against their enemy, and they overcame.

# 5178

All that is in heavens and earth exalt Allah, the King, the Pure, the Almighty, the Wise.

# 5179

It is He who has raised among the illiterate (Arabs), a Messenger from themselves, to recite to them His verses, to purify them, and to teach them the Book and the Wisdom, though before that they were in clear error,

# 5180

together with others who have not as yet joined them. He is the Almighty, the Wise.

# 5181

Such is the Favor of Allah; He gives it to whom He will, and Allah is of abounding favors.

# 5182

The likeness of those who were loaded with the Torah, but did not carry it, is like that of a donkey carrying books. Evil is the example of the people who have belied the verses of Allah. Allah does not guide the evildoers.

# 5183

Say: 'O you who are Jews, if you claim that of all people, you alone are the guided by Allah, then long for death if you are truthful'

# 5184

But, because of what their hands forwarded they will never long for it. Allah knows the harmdoers.

# 5185

Say: 'Death from which you flee is sure to reach you. Then you shall be returned to the Knower of the Unseen and the Visible, and He will tell you all that you have done'

# 5186

Believers, when you are called to prayer on the Day of the Congregation (Friday), hasten to the Remembrance of Allah and put your trading to oneside. That is the best for you, if you but knew.

# 5187

Then, when the prayer has ended, disperse in the land and seek the favor of Allah, and, remember Allah often, so that you prosper.

# 5188

Yet when they see some commerce or amusement they flock to it, leaving you standing. Say: 'That which is with Allah is better than the amusement and commerce. Allah is the Best of Providers'

# 5189

When the hypocrites come to you they say: 'We bear witness that you are the Messenger of Allah' Allah knows that you (Prophet Muhammad) are indeedHis Messenger, and Allah bears witness that the hypocrites are truly liars!

# 5190

They have taken their oaths as a cover and barred others from the Path of Allah. Evil is what they have done.

# 5191

That is because they believed, then disbelieved, because of this a seal has been set upon their hearts so they are unable to understand.

# 5192

When you see them their bodies please you, but when they speak and you listen to their sayings, they are like proppedup timber. Every shout (they hear) they take it to be against them. They are the enemy be wary of them. Allah kills them! How perverse they are!

# 5193

When it is said to them: 'Come, the Messenger of Allah will ask forgiveness for you' they turn their heads in pride and you see them go away.

# 5194

It is equal for them whether you ask for their forgiveness or you do not ask for their forgiveness, Allah will not forgive them. Allah does not guide the evildoers.

# 5195

It is they that say: 'Spend nothing on those who follow the Messenger of Allah until they disperse' Yet to Allah belong the treasuries of heavens and the earth, but the hypocrites do not understand.

# 5196

They say: 'If we return to the City, the strong will expel the humiliated' But the might belongs to Allah, and His Messenger and the believers, but thehypocrites do not know.

# 5197

Believers, do not let either your possessions or your children divert you from the Remembrance of Allah. Those who do that shall be the losers.

# 5198

So spend of that with which We have provided you before death comes upon any of you and he then says: 'O my Lord, if only You would defer me to anear term, so that I could give in charity and be among the good doers'

# 5199

But Allah will never defer any soul when its term comes. Allah is Aware of what you do.

# 5200

All that is in heavens and earth exalt Allah. His is the Kingdom, and His the Praise. He is powerful over all things.

# 5201

It is He who created you. Amongst you is an unbeliever and amongst you is a believer. Allah sees the things you do.

# 5202

He created the heavens and the earth in truth and He shaped you and gave you good shapes. To Him is the arrival.

# 5203

He knows whatever is in the heavens and the earth and He knows all what you conceal and what you reveal. Allah knows the innermost of the chests.

# 5204

Have you not heard the news of those before you who disbelieved? They tasted the mischief of their action, and for them is a painful punishment.

# 5205

That is because, when their Messengers came to them with clear proofs they said: 'Shall humans be our guides' They disbelieved and turned away, but Allah was not in need (of them). Allah is the Rich and the Praised.

# 5206

The unbelievers think that they will never be raised up. Say: 'By my Lord, yes indeed, you shall assuredly be raised up! Then you shall be told of all that you have done. That is easy for Allah'

# 5207

Believe in Allah, and His Messenger, and in the Light which We have sent down. Allah is Aware of all that you do.

# 5208

The Day on which He will gather you for the Day of Gathering; that is the Day of Loss and Gain. He who believes in Allah and does good deeds, Allah willacquit him of his evil deeds and admit him to Gardens underneath which rivers flow, where he shall live for ever. That is the mighty triumph.

# 5209

As for those who disbelieved and belied Our verses, they shall be the inhabitants of the Fire and shall live therein for ever. Evil shall be their arrival.

# 5210

No affliction falls except by the permission of Allah. For those who believe in Allah, Allah will guide his heart. Allah has knowledge of all things.

# 5211

Obey Allah and obey the Messenger. But, if you turn away, Our Messenger's duty is only to deliver the Clear Message.

# 5212

Allah, there is no god except He. In Allah let the believers put their trust.

# 5213

Believers, some of your wives and children are enemies; so beware of them. But if you pardon, overlook and forgive them, then Allah is the Forgiving, the Most Merciful.

# 5214

Your wealth and children are but a trial, and with Allah is a mighty wage.

# 5215

Therefore fear Allah as much as you can, and listen, obey, and spend well for yourselves. And whosoever is saved from the greed of his own soul; those are the winners.

# 5216

If you lend a good loan to Allah He will multiply it for you and will forgive you. Allah is the Thankful, the Clement.

# 5217

He is the Knower of the Unseen and the Visible, the Almighty, the Wise.

# 5218

O (nation of the) Prophet, if you divorce your wives, divorce them after (the end of their) menstrual cycle. Count their waiting period and fear Allah your Lord. Do not drive them from their homes or let them go away unless they commit a proven immorality. Such are the bounds set by Allah, he that exceeds the bounds of Allah wrongs himself. You do not know, perhaps after that Allah will bring a new event.

# 5219

When they have reached their term, either keep them honorably or part from them honorably. Call two honest men among you to witness and give yourwitnessing before Allah. Whoever believes in Allah and the Last Day is warned to do this. Whosoever fears Allah, He will appoint for him a way out,

# 5220

and provide for him from where he does not expect, Allah is Sufficient for whosoever puts his trust in Him. Indeed, Allah brings about whatever He decrees. Allah has set a measure for all things.

# 5221

As for your women who have despaired of further menstruating, if you are in doubt, then their waiting period is three months as well as those who have not yet menstruated. As for those who are pregnant, their term shall be the time they deliver their burden. Allah will ease (matters) by His order for whosoever fears Him.

# 5222

Such is the command of Allah that He has sent down to you. Whosoever fears Allah shall be relieved of his sins and given a mighty wage.

# 5223

Lodge them in your home according to your means. Do not harass them so as to (make life) difficult for them. If they are with child, spend upon them until they deliver their burden; and if they suckle give them their wage and consult together honorably. But if you both make difficulties, let another woman suckle for him.

# 5224

Let the rich spend according to his wealth and for he whose provision is little, let him spend from what Allah has given him. Allah does not charge a soulexcept with that He has given him. Surely, Allah will bring ease after difficulty.

# 5225

How many a village has turned in its pride against the Order of their Lord and His Messengers! We made it a stern reckoning, and punished it with a horrible punishment.

# 5226

So it tasted the mischief of its action, and the end of its matter was loss.

# 5227

Allah has prepared a severe punishment for them. So those possessing understanding fear Allah. Believers, Allah has sent this down for you as a Reminder,

# 5228

a Messenger reciting to you the verses, clear verses of Allah, so that he may bring forth those who believe and do good deeds from the darkness into thelight. Whosoever believes in Allah and does good deeds He will admit to Gardens underneath which rivers flow where they shall live for ever and ever. For those, Allah has made a goodly provision.

# 5229

It is Allah who has created the seven heavens, and of the earth their like, and the Command descends between them so that you know Allah is powerful over all things, and that Allah encompasses everything in knowledge.

# 5230

O Prophet, why do you forbid that which Allah has made lawful to you. Do you seek to please your wives' Allah is the Forgiving, the Most Merciful.

# 5231

Allah has absolved you from your oaths. Allah is your Guardian, the Knowing, the Wise.

# 5232

The Prophet confided a certain matter to one of his wives but thereafter she disclosed it, then Allah revealed what she had done to him. He made part of it known and another part not. And when he acquainted her with it, she said: 'Who has told you this' He replied: 'I was told of it by the Knower, the Aware'

# 5233

If both of you (wives) turn to Allah in repentance, even though your hearts inclined; but if you support one another against him, (know that) Allah is hisGuardian, and Gabriel, and the righteous among the believers; and thereafter the angels are his reinforcers.

# 5234

It may be that if he divorces you his Lord will give him in your place better wives than yourselves, women who have surrendered, believing, obedient, penitent worshippers and given to fasting; who were (previously) married, and virgins too.

# 5235

Believers, guard yourselves and your families against the Fire the fuel of which is people and stones, over which there are harsh, and stern angels who never disobey Allah in that which He orders and do what they are ordered.

# 5236

Unbelievers, make no excuse for yourselves this Day. You shall be recompensed only according to your deeds.

# 5237

Believers, turn to Allah in sincere repentance. Your Lord may acquit you of your sins, and admit you to Gardens underneath which rivers flow on a Day whenAllah will not degrade the Prophet and those who believe with him. Their light will run before them and on their right hands, and they will say: 'Our Lord, completeour light for us and forgive us. Surely, You have power over all things'

# 5238

O Prophet, struggle with the unbelievers and the hypocrites and deal harshly with them. Gehenna (Hell) shall be their refuge, an evil arrival!

# 5239

Allah has given as an example for the unbelievers, the wife of Noah and the wife of Lot. They were married to two of Our righteous worshipers, but theybetrayed them. It was not for (Noah and Lot) to avail them a thing. It was said to them both: 'Enter the Fire with those who shall enter'

# 5240

But to those who believe Allah has given as an example Pharaoh's wife, who said: 'My Lord, build me a house before You in Paradise and save me fromPharaoh and his work, and save me from a harmdoing nation'

# 5241

And, Mary, 'Imran's daughter, who guarded her chastity so We breathed into her of Our Spirit (Gabriel); and she put her trust in the Words of her Lord andHis Books, and was among the devout.

# 5242

Blessed be He in whose Hand is the Kingdom, He is powerful over all things,

# 5243

who created death and life that He might examine which of you is best in deeds, and He is the Almighty, the Forgiving,

# 5244

who created the seven heavens, one above the other. You cannot see any inconsistency in the creation of the Merciful. Return your gaze, do you see anycrack!

# 5245

Then return your gaze once more and yet again, your gaze comes back to you dazzled, and tired.

# 5246

We have adorned the lower heaven with lamps, and We made them a stoning for the satans, We have prepared the punishment of the Blaze for them.

# 5247

And for those who disbelieve in their Lord there awaits the punishment of Gehenna (Hell) an evil arrival!

# 5248

When they are cast into it they shall hear it sighing, while it boils

# 5249

nearly bursting apart out of rage. Every time a host is cast therein, its keepers will ask them: 'Did no one come to warn you'

# 5250

'Yes, indeed' they will reply, 'but we belied the Warner (Messenger) saying: 'Allah has not sent down anything, you are but in great error'

# 5251

And they will then say: 'If only we had listened and understood we should not now be among the inhabitants of the Blaze'

# 5252

So it is that they confess their sins. Curse the inhabitants of the Blaze!

# 5253

But those who fear their Lord in the Unseen, for them there is forgiveness and a great wage.

# 5254

(Whether you) speak in secret or aloud, He knows the innermost of the chests.

# 5255

Shall He who has created (all things) not know? He is the Subtle, the Aware.

# 5256

It is He who has made the earth submissive to you. Walk about in its land and eat of His provision. To Him is the Resurrection.

# 5257

Do you feel secure that He who is in the heaven will not cause the earth to swallow you up while it shakes?

# 5258

Do you feel secure that He who is in the heaven will not loose against you a squall of pebbles then you shall know how was My warning.

# 5259

Those who have gone before you also belied (their Messengers) then how was My disapproval!

# 5260

Do they not observe the birds above them, spreading their wings and folding them? None, except the Merciful holds them. Surely, He sees all things.

# 5261

Or, who is it that shall be your host to help you, other than the Merciful? Indeed, the unbelievers are only deluded.

# 5262

Or, who is it that shall provide for you if He withholds His provision? Yet they persist in arrogance and aversion.

# 5263

What, is he who walks, falling upon his face, more guided than he who walks upright on a Straight Path!

# 5264

Say: 'It is He who has created you and given to you hearing, sight and hearts but little is it that you thank'

# 5265

Say: 'It was He who created you, dispersing you in the earth, and to Him you shall be gathered'

# 5266

They ask: 'When will this promise come, if you speak truthfully'

# 5267

Say: 'The knowledge (of that) is with Allah; I am only a clear warner'

# 5268

Then, when they see it drawing near, the faces of the unbelievers will be blackened, and it is said: 'This is what you were promised'

# 5269

Say: 'What do you think, if Allah destroys me and those with me, or has mercy upon us, who then will protect the unbelievers from the painful punishment'

# 5270

Say: 'He is the Merciful. In Him we believe and in Him we put all our trust. Indeed, you shall soon know who is in clear error'

# 5271

Say: 'What do you think. If your water should sink into the earth in the morning, who then would bring you running water'

# 5272

Noon. By the Pen and that (the angels) write,

# 5273

you are not, because of the favor of your Lord, mad.

# 5274

Indeed, there is an unfailing wage for you.

# 5275

Surely, you (Prophet Muhammad) are of a great morality.

# 5276

You shall see and they will see

# 5277

which of you is the demented.

# 5278

Indeed, your Lord knows very well those who strayed from His Path, and those who are guided.

# 5279

Therefore, do not obey those who belie,

# 5280

they wish you would compromise, then, they would compromise.

# 5281

And do not obey every mean swearer,

# 5282

the backbiter who goes about slandering,

# 5283

those who hinder good, the guilty aggressor,

# 5284

the crude of low character

# 5285

because he has wealth and sons.

# 5286

When Our verses are recited to him, he says: 'They are but fairytales of the ancients'

# 5287

We shall mark him upon his nose!

# 5288

We have tried them as We tried the owners of the garden who had sworn that in the morning they would reap it,

# 5289

without adding to their swearing, (Allah willing, InshaAllah).

# 5290

Then, a visitation from your Lord came down upon it while they slept,

# 5291

and in the morning it was if the garden had been reaped.

# 5292

(Then) in the morning they called out to one another, saying:

# 5293

'Come out to your tillage if you want to reap'

# 5294

And so they departed, whispering to one another:

# 5295

'No needy person shall set foot in it today'

# 5296

And they went out early, determined in their resolve.

# 5297

But when they saw it they said: 'We have surely gone astray.

# 5298

No, rather, we have been prevented'

# 5299

(Whereupon) the best among them said: 'Did I not say to you to exalt (Allah)'

# 5300

'Exaltations to Allah, our Lord' they said, 'We were truly harmdoers'

# 5301

And they came blaming one another.

# 5302

They said 'Woe to us, truly we were insolent'

# 5303

It may be that our Lord will give us better than it in exchange. To our Lord we humbly turn'

# 5304

Such was their punishment. But the punishment of the Everlasting Life is much greater, if they but knew.

# 5305

Surely, the cautious shall have Gardens of Bliss with their Lord.

# 5306

What, shall We make those who are submissive like the wrongdoers?

# 5307

What is the matter with you then, how do you judge?

# 5308

Or, have you a Book from which you study

# 5309

surely in it you shall have whatever you choose!

# 5310

Or, have you an oath from Us that stretches to the Day of Resurrection (if so) you shall surely have what you judge!

# 5311

Ask them, which of them will guarantee that!

# 5312

Or, do they have associates? Then let them bring their associates, if what they say is true!

# 5313

On the Day when the leg shall be bared, and they are ordered to prostrate themselves, they will be unable.

# 5314

Their eyes will be humbled, and humiliation shall spread over them for they were already ordered to prostrate themselves when they were undiminished.

# 5315

Therefore, leave Me with he who belied this discourse. We will draw them on little by little from where they do not know.

# 5316

I shall respite them, My stratagem is firm.

# 5317

Or, do you ask them for a wage, so that they are burdened withdebt?

# 5318

Or, is the Unseen with them, and they are writing it down!

# 5319

So be patient with the judgement of your Lord and do not be like the Companion of the Whale (Jonah), when he called out choking inwardly.

# 5320

Had the favor of his Lord not come upon him, he would have been blamed, cast upon the shore.

# 5321

But his Lord had chosen him and He placed him among the righteous.

# 5322

When the unbelievers hear the Reminder, they nearly strike you down with their glances, and say: 'Surely, he is mad'

# 5323

But it is nothing other than a Reminder for all the worlds.

# 5324

The Resurrection Verifier;

# 5325

and what is the Resurrection Verifier?

# 5326

What makes you to know what the Resurrection Verifier is?

# 5327

Thamood and Aad belied the Clatterer.

# 5328

Thamood, they were destroyed by the violent shout (of Gabriel),

# 5329

as for Aad, they were destroyed by a howling, violent wind

# 5330

that He subjected upon them for seven nights and eight days consecutively and you might have seen them struck down as if they were the stumps of palm trees that had fallen down.

# 5331

Can you see any remnant of them now?

# 5332

Similarly, Pharaoh, and those before him, and the ruined villages, sinned

# 5333

and rebelled against their Lord's Messenger. So He took them with a stern taking.

# 5334

And when the waters rose (high) We carried you in the sailing (Ark),

# 5335

making it a Reminder for you, for all attentive ears to retain.

# 5336

When a single blow is blown on the Horn,

# 5337

when the earth with all its mountains is lifted up and crushed with a single blow,

# 5338

on that Day, the Event occurs.

# 5339

The heaven will be split; because on that Day it will be frail.

# 5340

The angels will stand on all its sides. And on that Day, eight (of them) will carry the Throne of your Lord above them.

# 5341

On that Day you shall be exposed, and no secret of yours will remain hidden.

# 5342

Then, he who is given his book in his right hand will say: 'Here, take and read my book!

# 5343

Indeed, I knew that I should come to my reckoning'

# 5344

His shall be a pleasing life

# 5345

in a high Garden,

# 5346

its fruits are near.

# 5347

(It will be said): 'Eat and drink with a good appetite because of what you did in days long passed'

# 5348

But, he who is given his book in his left hand will say: 'Woe to me, would that my book had not been given to me!

# 5349

Nor that I knew my reckoning!

# 5350

Would that it (my death) had ended it all!

# 5351

My wealth has not helped me a thing

# 5352

and my authority has been destroyed'

# 5353

(It will be said): 'Take him and bind him.

# 5354

Roast him in Hell,

# 5355

then in a chain seventy arm's lengths long insert him.

# 5356

He did not believe in Allah, the Great,

# 5357

nor did he urge the feeding of the needy.

# 5358

Today he shall have no loyal friend here,

# 5359

nor any food except foul pus

# 5360

that none but sinners eat'

# 5361

I swear by all that you can see,

# 5362

and all that you do not see,

# 5363

that this is the speech of a noble Messenger.

# 5364

It is not the speech of a poet little do you believe

# 5365

nor is it the speech of a soothsayer little do you remember.

# 5366

(It is) a sending down from the Lord of all the Worlds.

# 5367

Had he invented sayings against Us,

# 5368

We would have seized him by the right hand

# 5369

then, We would surely have cut from him the aorta (vein)

# 5370

not one of you could have prevented it from him.

# 5371

Indeed, it is a Reminder to those who fear Allah,

# 5372

We know that there are some among you who will belie.

# 5373

Indeed, it is a sorrow to the unbelievers

# 5374

yet it is a certain truth.

# 5375

Exalt the Name of your Lord, the Great.

# 5376

A caller supplicated about a punishment to fall on

# 5377

the unbelievers which none can prevent.

# 5378

(A punishment) from Allah, the Owner of the Elevated Passages.

# 5379

To Him the angels and the Spirit (Gabriel) ascend in a day, the measure of which is fifty thousand years.

# 5380

Therefore be patient, with a beautiful patience;

# 5381

they see it as being far off;

# 5382

but We see it near.

# 5383

On that Day the heaven shall become like molten copper,

# 5384

and the mountains shall be like puffs of wool.

# 5385

No loyal friend will ask another loyal friend

# 5386

though they are in sight of each other. To ransom himself from the punishment of that Day, the sinner will wish that he might even ransom himself by his sons,

# 5387

his companion (wife), his brother,

# 5388

the kinsmen who gave him shelter,

# 5389

and whosoever is in the earth, altogether, so that it might save him.

# 5390

No, in truth, it is a Furnace!

# 5391

It snatches away by the scalps,

# 5392

and it shall call him who withdrew and turned his back

# 5393

and amassed (riches) and hoarded.

# 5394

Indeed, the human was created grudging and impatient.

# 5395

When evil comes upon him he is impatient;

# 5396

but when good comes upon him, he is grudging

# 5397

except those that pray

# 5398

who are constant in prayer;

# 5399

who, from their wealth is a known right

# 5400

for the impoverished nonrequester and the requester,

# 5401

who confirm the Day of Reckoning

# 5402

and go in fear of the punishment of their Lord,

# 5403

for none is secure from the punishment of their Lord,

# 5404

who guard their privates

# 5405

except from their wives and what their right hands own, for these they are not blameworthy.

# 5406

But whosoever seeks beyond that, they are the transgressors.

# 5407

(Those) who keep their trusts and their covenant,

# 5408

and standby their witnessing,

# 5409

and who are constant in their prayers.

# 5410

Those are highly honored in the Gardens.

# 5411

But what is the matter with the unbelievers, that they strain their glances continuously towards them,

# 5412

on the right and on the left in groups?

# 5413

What, is every one of them eager to be admitted to the Garden of Bliss?

# 5414

Not at all, for We have created them of what they know.

# 5415

No, I swear by the Lord of the Easts and the Wests that We have the ability

# 5416

to exchange them with others better than they; nothing can outstrip Us!

# 5417

So leave them alone to plunge and play, until they encounter the Day which they are promised;

# 5418

the Day when they shall rush from their graves, as if they were hurrying to a raised flag,

# 5419

their eyes are humbled and they are covered with humiliation. Such is the Day that they were promised.

# 5420

We sent Noah to his nation, saying: 'Give warning to your nation before a painful punishment overtakes them'

# 5421

He said: 'My nation, I am a clear warner for you.

# 5422

Worship Allah, fear Him, and obey me.

# 5423

He will forgive you your sins and respite you till an appointed term. When the term of Allah arrives it cannot be deferred; if you but knew'

# 5424

'My Lord' said he, 'night and day I have called my nation,

# 5425

but my call has only increased them in running away.

# 5426

Each time I called them so that You might forgive them, they thrust their fingers in their ears and wrapped themselves in their garments, and persisted becomingvery proud.

# 5427

I called to them clearly,

# 5428

and indeed, I spoke to them both publicly and in secret:

# 5429

"Ask for forgiveness of your Lord," I said. "Surely, He is the Forgiver.

# 5430

He will let loose the sky upon you in abundance

# 5431

and give to you wealth and sons, and provide you with gardens and rivers.

# 5432

What is the matter with you that you do not want the Greatness of Allah,

# 5433

He has created you by stages!

# 5434

Have you not seen how Allah created the seven heavens one above the other,

# 5435

setting in them the moon as a light and the sun as a lantern?

# 5436

Allah has caused you to grow out of the earth,

# 5437

and to it He will return you. Then, He will bring you forth.

# 5438

Allah has made the earth spread out for you

# 5439

so that you walk in its spacious paths.'

# 5440

Noah said: 'My Lord, they have rebelled against me and followed he whose wealth and offspring increase him only in loss,

# 5441

they have devised a mighty plot,

# 5442

and said: 'Do not renounce your gods, do not leave waddan or suwa'an or yaghutha, or ya'uqa, or nasra'

# 5443

And they have led many astray. (Noah supplicated saying): 'Allah, do not increase the harmdoers except in error'

# 5444

So because of their sins they were drowned and admitted into the Fire. They found none to help them other than Allah.

# 5445

And Noah (supplicated) saying: 'My Lord, do not leave a single unbeliever upon the earth.

# 5446

Surely, if You leave them they will mislead Your worshipers and father none but the immoral, and unbelievers.

# 5447

Forgive me, My Lord, and my parents, and whosoever seeks refuge in my house as a believer, and the believers men and women alike, and do not increase the harmdoers except in ruin'

# 5448

Say: 'It is revealed to me that a party of jinn listened then said: "We have indeed heard a wonderful Koran,

# 5449

that guides to the Right Path. We believe in it and we will not associate anyone with our Lord.

# 5450

He exalted be the Majesty of our Lord, who has neither taken to Himself a wife, nor a son!

# 5451

The ignorant fool among us has spoken outrageously against Allah,

# 5452

we never thought that either human or jinn would ever tell a lie against Allah!'

# 5453

But there were certain men from mankind who would take refuge with certain males from the jinn and they increased them in tyranny.

# 5454

Like you, they thought that Allah would never raise the dead.

# 5455

(The jinn continued saying): "We made our way towards heaven, but we found it filled with stern guards and a flame.

# 5456

There, we would sit to eavesdrop, but now an eavesdropper finds a flame in wait for him.

# 5457

And so we do not know whether evil is intended for those on earth, or whether their Lord intends to guide them.

# 5458

Some of us are righteous, but some are otherwise, we are sects that differ.

# 5459

We know that we cannot frustrate Allah in the earth, nor can we frustrate Him by flight.

# 5460

When we heard the Guidance, we believed in it, and whosoever believes in his Lord shall fear neither shortage nor injustice.

# 5461

Some of us have surrendered (Muslims) and some of us have deviated. Those who surrendered sought the Right Path,

# 5462

but those who have deviated shall become the fuel of Gehenna (Hell).

# 5463

If they had followed the Path We would give to them abundant water to drink,

# 5464

and tested them with it. And whosoever turns away from his Lord's Remembrance, He will hurl him into a stern punishment.

# 5465

Mosques belong to Allah, so do not call to anyone else, other than Allah.

# 5466

When the worshiper of Allah stood supplicating to Him, they swarmed around him (Prophet Muhammad).

# 5467

Say: 'I supplicate only to my Lord and I do not associate any with Him'

# 5468

Say: 'Indeed, I possess no power over you, either for harm or for guidance'

# 5469

Say: 'None shall protect me from Allah, and other than Him, I will find no refuge,

# 5470

except a deliverance from Allah and His Messages. He who disobeys Allah and His Messenger, for him is the Fire of Gehenna, which he will be in for ever.

# 5471

When they see that which they were promised they shall know who is weaker in helpers and fewer in numbers.

# 5472

Say: 'I do not know whether that which you are promised is near, or whether my Lord will set for it a time.

# 5473

He is the Knower of the Unseen and does not disclose His Unseen to anyone,

# 5474

except only to a Messenger that He has chosen, and He sends guardians before him and behind him,

# 5475

so that He may know that they have delivered the Messages of their Lord and He encompasses all that is with them, and He has counted everything innumbers'

# 5476

O you (Prophet Muhammad) wrapped,

# 5477

rise (to pray) the night except a little;

# 5478

half the night, or a little less

# 5479

or a little more; and with recitation, recite the Koran.

# 5480

We are about to cast upon you a weighty Word.

# 5481

Indeed, the first part of night is heavier in tread, and more upright in speech.

# 5482

You have by day prolonged occupations.

# 5483

Remember the Name of your Lord and dedicate yourself devoutly to Him.

# 5484

He is the Lord of the East and the West; there is no god except Him. Take Him for your Guardian.

# 5485

Bear patiently with what they say and with a fine abandonment forsake them.

# 5486

Leave to Me those who belie, those who lead a life of pleasure, and bear with them yet a little while.

# 5487

We have fetters (for them) and a blazing fire,

# 5488

choking food and a painful punishment.

# 5489

On the Day when the earth with all its mountains quake and the mountains become heaps of shifting sand.

# 5490

Indeed, We have sent to you a Messenger as a witness over you, just as We sent a Messenger to Pharaoh.

# 5491

Pharaoh disobeyed Our Messenger, so We seized him remorselessly.

# 5492

If you disbelieve, how will you guard yourself against the Day that will make children gray haired,

# 5493

on which the heaven will split apart, and His promise is done.

# 5494

This is indeed a Reminder. Let whosoever will take the Path to his Lord.

# 5495

Your Lord knows that you keep vigil nearly two thirds of the night and sometimes half or onethird of it, and a party of those with you. Allah measures thenight and the day. He knows that you cannot count it, and turns to you. Therefore, recite from the Koran as much as is easy (for you); He knows that among youthere are the sick and others traveling the road seeking the bounty of Allah; and others fighting in the Way of Allah. So then, recite from it as much as is easy. Establish your prayers, pay the obligatory charity, and lend Allah a generous loan. Whatever good you shall forward to your souls' account, you surely will find it better with Allah, and a mightier wage. And supplicate for the forgiveness of Allah. Allah is the Forgiving, the Merciful.

# 5496

O you (Prophet Muhamad), the cloaked,

# 5497

arise and warn,

# 5498

and exalt your Lord,

# 5499

and purify your clothing,

# 5500

and flee from the statues!

# 5501

Do not give, thinking to gain greater

# 5502

be patient unto your Lord.

# 5503

When the Horn is blown,

# 5504

that shall be a Harsh Day

# 5505

and it will not be easy for the unbelievers.

# 5506

Leave Me alone with he whom I created

# 5507

and designated for him ample wealth,

# 5508

and sons that stand in witness.

# 5509

I made things smooth and easy for him,

# 5510

yet he is eager that I increase him.

# 5511

Not at all! Surely, he has been disobedient to Our verses.

# 5512

I will constrain him to a hard ascent.

# 5513

He reflected, and then determined

# 5514

death seized him, how was his determining!

# 5515

Again, death seized him, how was his determining!

# 5516

Then he looked,

# 5517

frowned and scowled;

# 5518

then he retreated and grew proud

# 5519

and said: 'This is no more than traced sorcery;

# 5520

It is nothing but the word of a mortal'

# 5521

I will surely roast him in the Scorching.

# 5522

What will let you know what the Scorching is like!

# 5523

It neither spares, nor releases,

# 5524

and it burns the flesh.

# 5525

Over it are nineteen (angels guarding).

# 5526

We have appointed none but angels to guard the Fire, and made their number only as a trial for the unbelievers, so that those to whom the Book was given are certain and those who believe increase in belief. And that those who were given the Book, and those who believe will not be in doubt. And that those in whose hearts there is a sickness, together with the unbelievers, may say: 'What did Allah intend by this as an example' As such, Allah leaves in error whom He will and He guides whomsoever He will. None knows the hosts of your Lord except He. This is no more than a Reminder to humans.

# 5527

No, by the moon!

# 5528

By the receding night

# 5529

and the morning when it appears,

# 5530

it is one of the greatest trials,

# 5531

a warning to humans,

# 5532

to whoever among you desires to go forward, or lag behind.

# 5533

Each soul is held in pledge for what it earns,

# 5534

except the Companions of the Right.

# 5535

In Gardens they will question

# 5536

concerning the sinners,

# 5537

'What caused you to be thrust into the Scorching (Fire)'

# 5538

They will reply: 'We were not among those who prayed

# 5539

and we did not feed the needy.

# 5540

We plunged in with the plungers

# 5541

and belied the Day of Recompense

# 5542

till the certainty (death) overtook us'

# 5543

The intercession of their intercessors shall not benefit them.

# 5544

What is the matter with them that they turn away from this Reminder,

# 5545

like startled wild donkeys

# 5546

fleeing before a lion?

# 5547

Indeed, each one of them desires to be given unrolled scrolls.

# 5548

No, indeed they have no fear of the Everlasting Life.

# 5549

No, indeed, surely, this is a Reminder.

# 5550

So, whoever wills, will remember it.

# 5551

But none will remember, unless Allah wills, He is the Owner of fear, the Owner of forgiveness.

# 5552

No! I swear by the Day of Resurrection,

# 5553

No! I swear by the reproachful soul!

# 5554

What, does the human think We shall never gather his bones?

# 5555

Indeed yes, We are able to shape his fingerstips yet again!

# 5556

Rather, the human desires to continue in his immorality,

# 5557

'When will the Day of Resurrection be' he asks,

# 5558

but when the sight is dazed

# 5559

and the moon eclipsed,

# 5560

when the sun and moon are gathered together

# 5561

on that Day the human will ask: 'To (which place) shall I flee'

# 5562

No, there shall be no (place of) refuge.

# 5563

For on that Day the refuge shall be to your Lord.

# 5564

On that Day the human shall be informed of his former and latter deeds.

# 5565

He shall be a clear proof against himself,

# 5566

even though he offers his excuses.

# 5567

Do not move your tongue with it (the Revelation) to hasten it.

# 5568

It's gathering and reciting is upon Us.

# 5569

When We recite it, follow its recitation.

# 5570

It's explanation is upon Us.

# 5571

Yet you love this hasty world

# 5572

and are heedless of the Everlasting Life.

# 5573

On that Day there shall be radiant faces,

# 5574

gazing towards their Lord.

# 5575

And on that Day there shall be scowling faces,

# 5576

so they might think the Calamity had been inflicted upon them.

# 5577

But, when (the soul) reaches the collar bone

# 5578

and it is said: 'Who is a healing chanter'

# 5579

and when he thinks it is the time of departure

# 5580

and when leg is intertwined with leg,

# 5581

upon that Day the driving shall be to your Lord.

# 5582

Because, he neither believed nor prayed;

# 5583

he belied the truth and turned away;

# 5584

then went arrogantly to his household.

# 5585

Near to you and nearer,

# 5586

then nearer to you and nearer!

# 5587

Does the human think he will be left to roam at will?

# 5588

What, was he not an ejaculated drop (of sperm)?

# 5589

Then he was a clot of blood, then He created and formed him

# 5590

and made from him two kinds, male and female.

# 5591

What, is He then unable to revive the dead?

# 5592

Indeed, there came upon the human a period of time when he was an unremembered thing.

# 5593

We have created the human from a (sperm) drop, a mixture, testing him; We made him to hear and see.

# 5594

Indeed, We have guided him to the path, he is either grateful or ungrateful.

# 5595

Indeed, for the unbelievers We have prepared chains, fetters and a Blazing (Fire).

# 5596

But the righteous shall drink of a goblet mixed with camphor;

# 5597

a fountain at which the worshipers of Allah drink and make it gush forth abundantly;

# 5598

they who keep their vows and fear a Day whose evil is spread;

# 5599

who give food, for the love of Him to the needy, the orphan, and the captive,

# 5600

(saying): 'We feed you only desirous of the Face of Allah; we seek of you neither recompense nor thanks,

# 5601

for we fear from our Lord a stern, frownful Day'

# 5602

So Allah will save them from the evil of that Day and has secured for them radiance and joyfulness,

# 5603

and recompense them for their patience with a Garden, and robes of silk.

# 5604

Reclining there upon couches, they shall see neither the sun nor the moon.

# 5605

Near them shall be its shades with its clusters hung gently down,

# 5606

and passed around them shall be silver vessels, and crystal goblets,

# 5607

goblets of silver that they have precisely measured.

# 5608

And they shall be given to drink from a cup whose mixture is ginger,

# 5609

from a fountain called Salsabila.

# 5610

Immortal youths will go about them, when you see them, you would suppose them to be scattered pearls.

# 5611

When you see them, you see bliss, and a great Kingdom.

# 5612

Upon them there will be garments of green silk, rich brocade, and they will be adorned with bracelets of silver. Their Lord will give them a pure beverage to drink.

# 5613

'See, this is your recompense, your striving is thanked'

# 5614

We have indeed, sent down to you the Koran, a (clear) sending,

# 5615

therefore be patient under the Judgement of your Lord, and do not obey either the sinner or the unbeliever.

# 5616

And, remember the Name of your Lord at the dawn and in the evening;

# 5617

and in the night prostrate to Him; and exalt Him for a long night.

# 5618

Indeed, these love the hasty life, and are heedless and leave behind them a heavy Day.

# 5619

We created them, and We strengthened their joints, but, when We will, We shall indeed exchange their likes.

# 5620

This is indeed a Reminder, so that he who will, takes a path to his Lord.

# 5621

Yet you will not unless Allah wills; surely, Allah is the Knower, the Wise.

# 5622

He is Merciful to whom He will; but, for the harmdoers He has prepared for them a painful punishment.

# 5623

By (the wind) those sent (as horses') mane (in succession),

# 5624

storming tempestuously

# 5625

and by the scatterers scattering (rain)

# 5626

then the criterion (the verses of Koran), separating

# 5627

and those (angels) dropping, reminding

# 5628

excusing or warning,

# 5629

surely, that which you have been promised is about to fall!

# 5630

When the stars are extinguished,

# 5631

and when the sky is rent asunder

# 5632

and the mountains scattered,

# 5633

and when the Messengers' time is set

# 5634

to what day shall they be deferred?

# 5635

Upon the Day of Decision!

# 5636

Would that you knew what the Day of Decision is!

# 5637

Woe on that Day to those who belied it!

# 5638

Did We not destroy the ancients

# 5639

and let the latter follow them?

# 5640

As such shall We deal with the sinners.

# 5641

Woe on that Day to those who belied it!

# 5642

Did We not create you from a weak water,

# 5643

which We placed within a sure lodging

# 5644

for an appointed term?

# 5645

We determined, how excellent a Determiner are We!

# 5646

Woe on that Day to those who belied it!

# 5647

Have We not made the earth a housing

# 5648

for both the living and the dead?

# 5649

Have We not placed high mountains upon it and filled you with sweet water?

# 5650

Woe on that Day to those who belied it!

# 5651

Depart to that which you belied!

# 5652

Depart into the shadow of three masses,

# 5653

wherein there is neither shade, nor freeing from the blazing flames

# 5654

it throws spits as (high as a huge) palace,

# 5655

as black camels.

# 5656

Woe on that Day to those who belied it!

# 5657

This is the Day they shall not speak,

# 5658

nor shall they be given permission, so that they can apologize.

# 5659

Woe on that Day to those who belied it!

# 5660

Such is the Day of Decision. We will gather you with the ancients.

# 5661

If you are cunning, then try your cunning against Me!

# 5662

Woe on that Day to those who belied it!

# 5663

Indeed, the cautious, shall live amid shades and fountains

# 5664

and have such fruits as they desire.

# 5665

(It shall be said to them): 'Eat and drink, with a good appetite, for all that you did'

# 5666

As such We recompense those who did good.

# 5667

Woe on that Day to those who belied it!

# 5668

'Eat and enjoy yourselves a little, for you are sinners'

# 5669

Woe on that Day to those who belied it!

# 5670

When it is said to them: 'Bow yourselves' they do not bow.

# 5671

Woe on that Day to those who belied it!

# 5672

After this, in what discourse will they believe?

# 5673

What do they question each other about!

# 5674

About the Great News

# 5675

whereupon they are at variance?

# 5676

Indeed, they shall know!

# 5677

Again, indeed, they shall know!

# 5678

Have We not made the earth as a cradle

# 5679

and the mountains as pegs?

# 5680

And We created you in pairs,

# 5681

and We made your sleep a rest,

# 5682

and We made the night a mantle,

# 5683

and We made the day for a livelihood.

# 5684

And We built above you seven strong ones,

# 5685

and placed in them a blazing lamp

# 5686

and have sent down from the clouds, pouring rain

# 5687

that We may bring forth with it grain, plants

# 5688

and luxuriant gardens.

# 5689

Indeed, the Day of Decision is an appointed time,

# 5690

the Day that the Horn is blown, and you shall come in crowds

# 5691

and heaven is opened, having gates,

# 5692

and the mountains move, and vaporize.

# 5693

Indeed, Gehenna (Hell) has become an ambush,

# 5694

a return for the insolent,

# 5695

there, they shall live for ages,

# 5696

tasting neither coolness nor any drink

# 5697

except boiling water and pus

# 5698

for a suitable recompense.

# 5699

Indeed, they did not hope for a Reckoning,

# 5700

and they absolutely belied Our verses,

# 5701

and everything We have numbered in a Book.

# 5702

'Taste! We shall not increase you except in punishment'

# 5703

But, for the cautious a place of prosperity,

# 5704

and gardens and vineyards,

# 5705

curvaceous (virgins), of equal age

# 5706

and an overflowing cup.

# 5707

There, they shall neither hear idle talk, nor yet any falsehood,

# 5708

a recompense from your Lord, a gift, a reckoning,

# 5709

the Lord of the heavens and earth, and all that is between them, the Merciful, of whom they are unable to speak.

# 5710

On that Day, when the Spirit (Gabriel) and the angels stand in ranks they shall not speak, except he to whom the Merciful has given permission, and sayswhat is right.

# 5711

That is the Day, the truth, so whosoever wills takes a way to his Lord.

# 5712

Indeed, We have forewarned you of an imminent punishment, the Day when the person will look upon his works and the unbelievers will say: 'Would that I were dust'

# 5713

By the pluckers (the angels of death), violently plucking (the souls of the unbelievers),

# 5714

by the drawers (the angels of death), gently drawing (the souls of the believers),

# 5715

by the swimmers (angels) swimming gently

# 5716

and the outstrippers (angels), outstripping,

# 5717

by the managers (angels) affair.

# 5718

On the Day, the shiverer shivers

# 5719

followed by the succeeding,

# 5720

hearts will throb on that Day

# 5721

and their eyes will be humbled.

# 5722

They say: 'What, are we being restored as we were before,

# 5723

even after we are fragmented bones'

# 5724

They will say: 'Then we are returned lost'

# 5725

But it will be only a single blow,

# 5726

and they will be upon the surface of the earth (alive).

# 5727

Have you received the story of Moses?

# 5728

His Lord called to him in the Sacred Valley of Towa,

# 5729

saying 'Go to Pharaoh, he has become exceedingly insolent,

# 5730

and say: "Will you purify yourself,

# 5731

that I might guide you to your Lord, so that you fear (Him)."

# 5732

He showed him the mighty sign,

# 5733

but he belied and disobeyed,

# 5734

and hastily turned away,

# 5735

then, he gathered, proclaimed, then said:

# 5736

'I am your lord, the most high'

# 5737

So Allah seized him with the punishment of the Everlasting Life, and of this world.

# 5738

Surely, in this there is a lesson for he that fears!

# 5739

What, are you harder to create than the heaven which He has built?

# 5740

He raised it high and leveled it,

# 5741

and darkened its night and brought forth its morning.

# 5742

And the earth He extended after that;

# 5743

and then brought from it its water and pastures.

# 5744

And the mountains He set firm

# 5745

an enjoyment for you and your herds.

# 5746

But when the Great Catastrophe comes,

# 5747

the Day when the human will remember what he has worked for,

# 5748

and when Hell is advanced for whoever sees,

# 5749

then as for whosoever was insolent

# 5750

preferring the present life,

# 5751

surely, Hell will be their refuge.

# 5752

But, whosoever feared the standing before his Lord and prevented the self from desires,

# 5753

indeed, their refuge shall be Paradise.

# 5754

They will question you about the Hour: 'When shall it be'

# 5755

But how are you to know?

# 5756

Its final end is for your Lord.

# 5757

You are but a warner for those who fear it.

# 5758

On the Day when they behold it, it will be as if they had lingered but an evening, or, a morning.

# 5759

He frowned and turned away

# 5760

when the blind came to him.

# 5761

And what could let you know? Perhaps he (comes to hear you) to be purified.

# 5762

(He might) remember, and the Reminder might profit him.

# 5763

As for he who is sufficed

# 5764

you attended to him,

# 5765

although it is not for you to be concerned if he remained unpurified.

# 5766

And to him who came to you eagerly

# 5767

and fearfully,

# 5768

of him you were unmindful.

# 5769

No indeed, this is a Reminder;

# 5770

and whosoever wills, shall remember it.

# 5771

upon highly honored pages,

# 5772

exalted, purified,

# 5773

by the hands of scribes

# 5774

noble and pious.

# 5775

Perish the human! How unthankful he is!

# 5776

From what did He create him?

# 5777

From a (sperm) drop He created him and then determined him,

# 5778

then eased his path for him,

# 5779

then causes him to die and buries him,

# 5780

then, He will raise him when He wills.

# 5781

Indeed, he has not fulfilled that which He has ordered him.

# 5782

Let the human reflect on the food he eats,

# 5783

how We pour down rain in abundance,

# 5784

and split the earth, splitting,

# 5785

how We made the grain to grow,

# 5786

grapes, and fresh fodder,

# 5787

and the olive, and the palm,

# 5788

the densely tree'd gardens,

# 5789

and fruit and pastures,

# 5790

for you and for your herds to delight in.

# 5791

But, when the Blast comes,

# 5792

on that Day each person will flee from his brother,

# 5793

his mother and his father,

# 5794

his wife and his children.

# 5795

Everyone on that Day will have affairs to keep him occupied.

# 5796

Some faces will shine,

# 5797

laughing and joyful,

# 5798

whereas some faces will be covered with dust

# 5799

and veiled with darkness.

# 5800

Those, they are the unbelievers, the immoral.

# 5801

When the sun is woundup;

# 5802

when the stars are thrown down,

# 5803

and the mountains have been taken,

# 5804

when the pregnant camels are neglected,

# 5805

when the savage beasts are gathered

# 5806

when the seas are set boiling,

# 5807

when the souls are coupled (to their body),

# 5808

when the buried female infant is asked

# 5809

for what crime she was slain,

# 5810

when the scrolls are unrolled,

# 5811

when heaven is stripped,

# 5812

when Hell is set ablaze,

# 5813

when Paradise is brought near,

# 5814

then, each soul shall know what it has produced.

# 5815

Rather, I swear by the returning

# 5816

orbiting, disappearing;

# 5817

by the night when it approaches

# 5818

and the morning when it extends,

# 5819

it is indeed the word of an Honorable Messenger,

# 5820

of power, given a rank by the Owner of the Throne

# 5821

obeyed, and honest.

# 5822

Your Companion is not mad,

# 5823

in truth he saw him (Gabriel) on the clear horizon,

# 5824

he is not grudging of the Unseen.

# 5825

Nor is this the word of a stoned satan.

# 5826

Where then are you going?

# 5827

This is nothing but a Reminder to the worlds,

# 5828

for whosoever of you would go straight,

# 5829

but you shall not, unless Allah wills, the Lord of all the Worlds.

# 5830

When the sky is split,

# 5831

when the planets are scattered,

# 5832

when the oceans are gushed forth,

# 5833

when the graves are overturned,

# 5834

the soul shall know what it has done, the former and the latter.

# 5835

O human! What has deceived you concerning your Generous Lord

# 5836

who created you, formed you and proportioned you?

# 5837

In whatever shape He will He could surely have fashioned you.

# 5838

Rather, you belied the Recompense.

# 5839

Yet over you there are watchers,

# 5840

noble scribes

# 5841

who know of all that you do.

# 5842

Indeed, the righteous shall (live) in bliss.

# 5843

But the wicked, indeed they shall be in the Fiery Furnace,

# 5844

roasting in it on the Day of Recompense

# 5845

and from it they shall never be absent.

# 5846

What could let you know what the Day of Recompense is!

# 5847

Again, what could let you know what the Day of Recompense is!

# 5848

It is the Day when no soul can do a thing for another soul. That Day, the command belongs to Allah.

# 5849

Woe to the diminishers,

# 5850

who, when people measure for them, take full measure,

# 5851

but when they measure or weigh for others, they reduce!

# 5852

Do they not think that they will be resurrected

# 5853

for a great Day,

# 5854

the Day when people will stand before the Lord of the Worlds?

# 5855

No indeed, the Book of the immoral is in Sijjeen.

# 5856

What could let you know what the Sijjeen is!

# 5857

(It is) a marked Book.

# 5858

Woe on that Day to those who belied it,

# 5859

who belied the Day of Recompense!

# 5860

None belies it except every guilty sinner.

# 5861

When Our verses are recited to him, he says: 'Fictitious tales of the ancients'

# 5862

No indeed! Their own deeds have cast a veil over their hearts.

# 5863

No indeed, on that Day they shall be veiled from their Lord.

# 5864

Then they shall roast in Hell,

# 5865

and it will be said to them: 'This is that which you belied'

# 5866

But, the Book of the righteous is in the 'Illiyoon.

# 5867

What could let you know what the 'Illiyoon is!

# 5868

(It is) a marked Book,

# 5869

witnessed by those who are near (to Allah).

# 5870

The righteous shall indeed be blissful,

# 5871

(reclining) upon couches they will gaze,

# 5872

and in their faces you shall know the radiance of bliss.

# 5873

They shall be given to drink of a wine that is sealed,

# 5874

its seal is musk, for this let the competitors compete;

# 5875

and its mixture is Tasneem,

# 5876

a fountain at which those brought near (to their Lord) drink.

# 5877

The sinners laughed at the believers

# 5878

and winked at one another as they passed them by.

# 5879

When they returned to their people they returned jesting;

# 5880

and when they saw them said: 'These are they who are astray'

# 5881

Yet they were not sent to be their guardians.

# 5882

But on this Day the believers will laugh at the unbelievers

# 5883

as they (recline) upon their couches and gaze (around them).

# 5884

Have the unbelievers been rewarded for what they did?

# 5885

When the sky is torn apart,

# 5886

hearing and obeying its Lord, as it must do;

# 5887

when the earth is stretched out

# 5888

and casts out all that is within and voids itself,

# 5889

obeying its Lord, as it must do!

# 5890

O human, you are working hard towards your Lord and you will meet Him.

# 5891

Then, he who is given his Book in his right hand

# 5892

shall have an easy reckoning

# 5893

and will return rejoicing to his family.

# 5894

But he who is given his Book from behind his back

# 5895

shall call for destruction

# 5896

and roast at the Blaze.

# 5897

Once, he lived joyfully among his family

# 5898

and surely thought he would never return (to his Lord).

# 5899

Yes indeed, his Lord was ever watching him.

# 5900

I swear by the twilight;

# 5901

by the night and all that it envelops;

# 5902

by the moon, in its fullness

# 5903

that you shall surely ride from stage to stage.

# 5904

What is the matter with them, that they do not believe

# 5905

and when the Koran is recited to them that they do not prostrate!

# 5906

No, the unbelievers only belie,

# 5907

and Allah knows very well what they gather.

# 5908

Therefore give to them glad tidings of a painful punishment,

# 5909

except to those who believe, and do righteous deeds, for theirs is an unfailing recompense.

# 5910

By the heaven of the constellations!

# 5911

By the Promised Day!

# 5912

By the witness and the witnessed!

# 5913

The companions of the pit were killed

# 5914

the fire with its fuel,

# 5915

when they were seated around it

# 5916

and they were witnesses of what they did to the believers

# 5917

and their revenge on them was only because they believed in Allah, the Almighty, the Praised,

# 5918

to whom belongs the Kingdom of the heavens and earth. And Allah is the Witness of all things.

# 5919

Those who persecuted the believing men and women and never repented, there is for them the punishment of Gehenna (Hell), and for them the punishment of the burning.

# 5920

(But) for those who believe and do good works, for them there are Gardens underneath which rivers flow that is the Great Victory!

# 5921

Indeed, the seizing of your Lord is severe.

# 5922

It is He who originates and repeats.

# 5923

And He is the Forgiving, and the Loving.

# 5924

Owner of the Throne, the Exalted.

# 5925

The Doer of whatever He wants.

# 5926

Has it come to you the story of the hosts

# 5927

of Pharaoh and of Thamood?

# 5928

Yet the unbelievers still belie,

# 5929

Allah encompasses them all from behind.

# 5930

Indeed, this is a Glorious Koran,

# 5931

in a Guarded Tablet.

# 5932

By the sky, and by the nightly comer!

# 5933

What could let you know what the nightly comer is!

# 5934

(It is) the piercing star.

# 5935

For every soul there is a watcher.

# 5936

Let the human reflect of what he is created.

# 5937

He was created from ejaculated water

# 5938

that issues from between the loins and the ribs.

# 5939

Surely, He is Able to bring him back,

# 5940

on the Day when consciences are examined,

# 5941

when he will be helpless, with no supporter.

# 5942

By the sky with its returning rain,

# 5943

and by the earth bursting with vegetation;

# 5944

this is indeed a Decisive Word,

# 5945

it is not a jest.

# 5946

They are cunningly devising,

# 5947

and I am cunningly devising.

# 5948

Therefore respite the unbelievers, and delay them for a while.

# 5949

Exalt the Name of your Lord, the Highest,

# 5950

who has created and shaped,

# 5951

who has ordained and guided,

# 5952

who brings forth the pastures,

# 5953

then made it dry dark, flaky stubble,

# 5954

We shall make you recite so that you will not forget,

# 5955

except what Allah wills, surely, He knows all that is (spoken) aloud and what is hidden.

# 5956

We shall ease you to the easy.

# 5957

Therefore remind, if the Reminder benefits,

# 5958

and he who fears shall remember,

# 5959

but the most wretched shall avoid it,

# 5960

who will roast in the Great Fire,

# 5961

in which he will neither die nor live therein.

# 5962

Prosperous is he who purifies himself,

# 5963

and remembers the Name of his Lord, so he prays.

# 5964

But you prefer the present life,

# 5965

but the Everlasting Life is better, and more enduring.

# 5966

Surely, this is in the ancient Scrolls,

# 5967

the Scrolls of Abraham and Moses.

# 5968

Have you received the news of the Enveloper?

# 5969

On that Day faces shall be humbled,

# 5970

laboring, wornout,

# 5971

roasting at a scorching Fire

# 5972

that is fueled from a tremendously hot fountain,

# 5973

no food for them except thorny plants

# 5974

which neither sustains, nor satisfy hunger.

# 5975

(Whereas other) faces on that Day will be joyful,

# 5976

well pleased with their striving,

# 5977

in a Garden on high,

# 5978

where they will hear no idle talk.

# 5979

A gushing fountain shall be there

# 5980

and raised couches,

# 5981

and prepared goblets,

# 5982

and arranged cushions

# 5983

and outspread carpets.

# 5984

What, do they not reflect upon how the camel was created?

# 5985

And how the heaven was raised up,

# 5986

and how the mountains were firmly fixed?

# 5987

And how the earth was outstretched?

# 5988

Therefore remind, you are only a Reminder.

# 5989

You are not charged to oversee them.

# 5990

As for those who turn their back and disbelieve,

# 5991

Allah will punish them with the greatest punishment.

# 5992

Indeed, to Us they shall return,

# 5993

then upon Us shall rest their reckoning.

# 5994

By the dawn

# 5995

and ten nights (of pilgrimage or the last ten days of Ramadan),

# 5996

by the even, and the odd,

# 5997

by the night when it journeys on!

# 5998

Is there in that an oath for the mindful?

# 5999

Have you not heard how your Lord dealt with Aad?

# 6000

of the columned (city) of Iram,

# 6001

the like of which was never created in the countries?

# 6002

And Thamood, who hewed out the rocks of the valley?

# 6003

And Pharaoh, of the pegs (impaling his victims)?

# 6004

They were tyrants in the land

# 6005

and exceeded in corruption therein.

# 6006

(Therefore) your Lord let loose upon them a scourge of punishment;

# 6007

indeed, your Lord is ever watchful.

# 6008

As for man, when his Lord tests him by honoring him and favoring him, he says: 'My Lord, has honored me'

# 6009

But when He tests him by restricting his provision, he says: 'My Lord has humiliated me'

# 6010

No! But you show no good to the orphan,

# 6011

nor do you urge one another to feed the needy.

# 6012

and you devour the inheritance with greed,

# 6013

and you ardently love wealth.

# 6014

No! But when the earth quakes and is pounded,

# 6015

and your Lord comes with the angels, rank upon rank,

# 6016

and Gehenna (Hell) is brought near on that Day the human will remember, and how shall the Reminder be for him?

# 6017

He will say: 'Would that I had forwarded (good works) for my life!'

# 6018

But on that Day none will punish as He (Allah) will punish,

# 6019

nor will any bind as He binds.

# 6020

O satisfied soul,

# 6021

return to your Lord wellpleased, wellpleasing.

# 6022

Join My worshipers and

# 6023

enter My Paradise!

# 6024

No, I swear by this country (Mecca),

# 6025

and you are a lodger in this country.

# 6026

And by the giver of birth, and whom he fathered,

# 6027

We created the human in fatigue.

# 6028

Does he think that none has power over him!

# 6029

He will say: 'I have destroyed a vast wealth'

# 6030

Does he think that none has observed him?

# 6031

Have We not given him two eyes,

# 6032

a tongue, and two lips,

# 6033

and guided him on the two paths (of good and evil)?

# 6034

Yet he has not scaled the height.

# 6035

What could let you know what the height is!

# 6036

(It is) the freeing of a slave,

# 6037

the giving of food upon the day of hunger

# 6038

to an orphaned relative

# 6039

or to a needy person in distress;

# 6040

so that he becomes one of those who believe, charge each other to be patient, and charge each other to be merciful.

# 6041

Those are the Companions of the Right.

# 6042

But those who disbelieve in Our verses, they are the Companions of the Left,

# 6043

with the Fire closed above them.

# 6044

By the sun and its midmorning,

# 6045

by the moon, which follows it,

# 6046

by the day, when it displays it,

# 6047

by the night, when it envelops it!

# 6048

By the heaven and Who built it,

# 6049

by the earth and Who spread it,

# 6050

by the soul and Who shaped it

# 6051

and inspired it with its sin and its piety,

# 6052

prosperous is he who purified it,

# 6053

and failed is he who buried it!

# 6054

Thamood belied in their pride

# 6055

when the most wicked of them broke forth,

# 6056

the Messenger of Allah said to them: '(This is) the shecamel of Allah, let her drink'

# 6057

But they belied him, and hamstrung her. So their Lord crushed them for their sin and leveled it (their village).

# 6058

He does not fear the result (of their destruction).

# 6059

By the night, when it envelops,

# 6060

and by the day when it unveils.

# 6061

And by Who created the male and female,

# 6062

your striving is indeed to different ends!

# 6063

For him that gives and fears (Allah)

# 6064

and believes in the finest,

# 6065

We shall surely ease him to the Path of Easing;

# 6066

but for him that is a miser, and sufficed,

# 6067

and he belied the finest

# 6068

We shall surely ease for him the Path of Hardship (the Fire).

# 6069

When he falls (into Hell), his wealth will not help him.

# 6070

Indeed, Guidance is Ours,

# 6071

and to Us belong the Last and the First.

# 6072

I have now warned you of the Blazing Fire,

# 6073

in which none shall be roasted except the most wretched sinner,

# 6074

who belied and turned away,

# 6075

and from which the cautious shall be distanced.

# 6076

He who gives his wealth to be purified,

# 6077

and confers no favor upon anyone for recompense

# 6078

seeking only the Face of his Lord, the Most High,

# 6079

surely, he shall be satisfied.

# 6080

By the midmorning,

# 6081

and by the night when it covers,

# 6082

your Lord has not forsaken you (Prophet Muhammad), nor does He hate you.

# 6083

The Last shall be better for you than the First.

# 6084

Your Lord will give you, and you will be satisfied.

# 6085

Did He not find you an orphan and give you shelter?

# 6086

Did He not find you a wanderer so He guided you?

# 6087

Did He not find you poor and suffice you?

# 6088

Do not oppress the orphan,

# 6089

nor drive away the one who asks.

# 6090

But tell of the favors of your Lord!

# 6091

Have We not expanded your chest for you (Prophet Muhammad),

# 6092

and relieved you of your burden

# 6093

that weighed down your back?

# 6094

Have We not raised your remembrance?

# 6095

Indeed, hardship is followed by ease,

# 6096

indeed, hardship is followed by ease!

# 6097

So, when you have finished (your prayer), labor (in supplication),

# 6098

and let your longing be for your Lord (in humility).

# 6099

By the fig and the olive!

# 6100

and the Mount, Sinai,

# 6101

and this safe country (Mecca)!

# 6102

Indeed, We created the human with the fairest stature

# 6103

and We shall return him to the lowest of the low,

# 6104

except the believers who do good works, for theirs shall be an unfailing recompense.

# 6105

So, what then shall belie you concerning the Recompense?

# 6106

Is Allah not the Most Just of judges!

# 6107

Read (Prophet Muhammad) in the Name of your Lord who created,

# 6108

created the human from a (blood) clot.

# 6109

Read! Your Lord is the Most Generous,

# 6110

who taught by the pen,

# 6111

taught the human what he did not know.

# 6112

Indeed, surely the human is very insolent

# 6113

that he sees himself sufficed.

# 6114

Indeed, to your Lord is the returning.

# 6115

What do you think? Have you seen he who forbids

# 6116

a worshiper when he prays.

# 6117

Have you seen if he was upon guidance

# 6118

or orders piety?

# 6119

What do you think? Have you seen if he belies and turns away,

# 6120

does he not know that Allah sees?

# 6121

Indeed, if he does not desist, We will seize him by the forelock,

# 6122

a lying, sinful forelock.

# 6123

So, let him call upon his way!

# 6124

We, will call the Zabania (the harsh angels of Hell).

# 6125

No, indeed; do not obey him! Prostrate and come nearer (to Allah).

# 6126

We sent this (the Holy Koran) down on the Night of Honor.

# 6127

What could let you know what the Night of Honor is!

# 6128

The Night of Honor is better than a thousand months,

# 6129

in it the angels and the Spirit (Gabriel) descend by the permission of their Lord upon every command.

# 6130

Peace it is, till the break of dawn.

# 6131

The unbelievers among the People of the Book and the idolaters would never desist until the Clear Proof came to them.

# 6132

A Messenger from Allah reciting Purified Pages

# 6133

in which there are valuable Books.

# 6134

Those to whom the Book was given did not divide themselves until the Clear Proof came to them.

# 6135

Yet they were ordered to worship Allah alone, making the Religion His sincerely, upright, and to establish their prayers and to pay the obligatory charity. That is indeed the Religion of Straightness.

# 6136

The unbelievers among the People of the Book and the idolaters shall be for ever in the Fire of Gehenna (Hell). They are the worst of all creatures.

# 6137

But those who believe and do good deeds are the best of all creatures.

# 6138

Their recompense is with their Lord; Gardens of Eden, underneath which rivers flow, where they shall live for ever. Allah is wellpleased with them, and theyare wellpleased with Him. That is for he who fears his Lord!

# 6139

When the earth is shaken with its mighty shaking,

# 6140

and when the earth brings forth its burdens

# 6141

and the human asks: "What is the matter with it?"

# 6142

On that Day it shall proclaim its news,

# 6143

for your Lord will have revealed to it.

# 6144

On that Day mankind shall issue in scatterings to see their deeds.

# 6145

Whosoever has done an atom's weight of good shall see it,

# 6146

and whosoever has done an atom's weight of evil shall see it.

# 6147

By the snorting runners (the horses),

# 6148

by the strikers of fire,

# 6149

by the dawnraiders,

# 6150

raising a trail of dust,

# 6151

dividing the gathering.

# 6152

Indeed, the human is ungrateful to his Lord.

# 6153

To this he himself shall bear witness.

# 6154

And indeed he is ardent for the love of good (wealth, becoming greedy).

# 6155

Does he not know that when that which is in the graves is overthrown,

# 6156

and that which is in the chest is brought out,

# 6157

indeed, on that Day their Lord will be aware of them!

# 6158

The Clatterer (the Day of Judgement)!

# 6159

What is the Clatterer.

# 6160

What shall let you know what the Clatterer is!

# 6161

On that Day people shall become like scattered moths

# 6162

and the mountains like tufts of carded wool.

# 6163

Then he whose deeds weigh heavy in the Scale

# 6164

shall live in a life which is pleasing,

# 6165

but he whose weight is light in the Scale,

# 6166

his head will be in the Plunging

# 6167

What shall let you know what the Plunging is?

# 6168

(It is) a Fire which is extremely hot.

# 6169

The excessive gathering (of increase and boasting) occupied you (from worshipping and obeying)

# 6170

until you visit the graves.

# 6171

But no, indeed, you shall soon know.

# 6172

Again, no indeed, you shall soon know.

# 6173

Indeed, did you know with certain knowledge

# 6174

that you shall surely see Hell?

# 6175

Again, you shall surely see it with the sight of certainty.

# 6176

On that Day, you shall be questioned about the pleasures.

# 6177

By the time of the afternoon!

# 6178

Surely, the human is in a (state of) loss,

# 6179

except those who believe and do good works and charge one another with the truth and charge one another with patience.

# 6180

Woe to every backbiter, slanderer

# 6181

who amasses wealth and counts it,

# 6182

thinking his wealth will render him immortal!

# 6183

On the contrary! He shall be flung to the Crusher.

# 6184

What shall let you know what the Crusher is?

# 6185

(It is) the kindled Fire of Allah,

# 6186

which shall oversee the hearts,

# 6187

closed around them

# 6188

in extended columns.

# 6189

Have you not seen how Allah dealt with the companions of the Elephant?

# 6190

Did He not cause their schemes to go astray?

# 6191

And He sent against them flights of birds

# 6192

pelting them with stones of baked clay,

# 6193

so that He made them like straw eaten (by cattle).

# 6194

For the custom of the Koraysh,

# 6195

their custom of the winter and summer journey.

# 6196

Therefore let them worship the Lord of this House

# 6197

who fed them from hunger and secured them from fear.

# 6198

Have you seen he who belied the Recompense?

# 6199

It is he who turns away the orphan

# 6200

and does not urge others to feed the needy.

# 6201

Woe to those who pray,

# 6202

who are heedless of their prayers (delaying them from their prescribed times),

# 6203

who show off,

# 6204

and prevent the utensils of assistance.

# 6205

Indeed, We have given you (Prophet Muhammad) the abundance (Al Kawthar: river, its pool and springs).

# 6206

So pray to your Lord and sacrifice.

# 6207

Surely, he who hates you, he is the most severed.

# 6208

Say: 'O unbelievers,

# 6209

I do not worship what you worship,

# 6210

nor do you worship what I worship.

# 6211

Nor am I worshiping what you have worshipped,

# 6212

neither will you worship what I worship.

# 6213

To you your religion, and to me my Religion'

# 6214

When the victory of Allah and the opening comes,

# 6215

and you see people embracing the Religion of Allah in throngs,

# 6216

exalt with the praise of your Lord and ask forgiveness from Him. For indeed, He is the Turner (for the penitent).

# 6217

Perish the hands of AbiLahab, and perish he!

# 6218

His wealth will not suffice him, neither what he has gained;

# 6219

he shall roast at a Flaming Fire,

# 6220

and his wife, laden with firewood

# 6221

shall have a rope of palmfiber around her neck!

# 6222

Say: 'He is Allah, the One,

# 6223

the called upon.

# 6224

Who has not given birth, and has not been born,

# 6225

and there is none equal to Him'

# 6226

Say: 'I take refuge with the Lord of Daybreak

# 6227

from the evil of what He has created,

# 6228

from the evil of the darkness when it gathers

# 6229

from the evil of the blowers on knots;

# 6230

from the evil of the envier when he envies'

# 6231

Say: 'I take refuge with the Lord of people,

# 6232

the King of people,

# 6233

the God of people,

# 6234

from the evil of the slinking whisperer.

# 6235

who whispers in the chests of people,

# 6236

both jinn and people.'

