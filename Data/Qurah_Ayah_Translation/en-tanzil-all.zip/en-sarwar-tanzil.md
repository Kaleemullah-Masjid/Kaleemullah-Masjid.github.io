<!--
Quran Translation
Name: Sarwar
Translator: Muhammad Sarwar
Language: English
ID: en.sarwar
Last Update: July 30, 2012
Source: Tanzil.net
-->

# 1

In the Name of Allah, the Beneficent, the Merciful

# 2

All praise belongs to God, Lord of the Universe,

# 3

the Beneficent, the Merciful

# 4

and Master of the Day of Judgment

# 5

(Lord), You alone We do worship and from You alone we do seek assistance

# 6

(Lord), guide us to the right path,

# 7

the path of those to whom You have granted blessings, those who are neither subject to Your anger nor have gone astray.

# 8

Alif. Lam. Mim.

# 9

There is no doubt that this book is a guide for the pious;

# 10

the pious who believe in the unseen, attend to prayer, give in charity part of what We have granted them;

# 11

who have faith in what has been revealed to you and others before you and have strong faith in the life hereafter.

# 12

It is the pious who follow the guidance of their Lord and gain lasting happiness.

# 13

Those who deny your message will not believe whether you warn them or not

# 14

God has sealed their hearts and hearing and their vision is veiled; a great punishment awaits them.

# 15

Some people say, "We believe in God and the Day of Judgment," but they are not true believers.

# 16

They deceive God and the believers. However, they have deceived no one but themselves, a fact of which they are not aware.

# 17

A sickness exists in their hearts to which God adds more sickness. Besides this, they will suffer a painful punishment as a result of the lie which they speak.

# 18

When they are told not to commit corruption in the land, they reply, "We are only reformers".

# 19

They, certainly, are corrupt but do not realize it.

# 20

When they are told to believe as everyone else does, they say, "Should we believe as fools do?" In fact, they themselves are fools, but they do not know it.

# 21

To the believers they declare belief and, in secret to their own devils, they say, "We were only mocking".

# 22

God mocks them and gives them time to continue blindly in their transgressions.

# 23

They have traded guidance for error, but their bargain has had no profit and they have missed the true guidance.

# 24

(Their case) is like that of one who kindles a fire and when it grows bright God takes away its light leaving him in darkness (wherein) he cannot see (anything).

# 25

They are deaf, blind, and dumb and cannot regain their senses.

# 26

Or it is like that of a rain storm with darkness, thunder, and lightning approaching. They cover their ears for fear of thunder and death. God encompasses those who deny His words.

# 27

The lightning almost takes away their vision. When the lightning brightens their surroundings, they walk and when it is dark, they stand still. Had God wanted, He could have taken away their hearing and their vision. God has power over all things.

# 28

People, worship your Lord who created you and those who lived before you, so that you may become pious.

# 29

Worship God who has rendered the earth as a floor for you and the sky as a dome for you and has sent water down from the sky to produce fruits for your sustenance. Do not knowingly set up anything as an equal to God.

# 30

Should you have any doubt about what We have revealed to Our servant, present one chapter comparable to it and call all your supporters, besides God, if your claim is true.

# 31

If you do not produce such a chapter and you never will then guard yourselves against the fire whose fuel will be people and stones and is prepared for those who hide the Truth.

# 32

(Muhammad), tell the righteously striving believers of the happy news, that for them there are gardens wherein streams flow. Whenever they get any fruit from the gardens as food, they will say, "This is just what we had before (we came here). These fruits are produced very much like them (those we had before)." They will have purified spouses and it is they who will live forever.

# 33

God does not hesitate to set forth parables of anything even a gnat. The believers know that it is the truth from their Lord, but those who deny the truth say, "What does God mean by such parables?" In fact, by such parables God misleads and guides many. However, He only misleads the evil doers

# 34

who break their established covenant with Him and the relations He has commanded to be kept and who spread evil in the land. These are the ones who lose a great deal.

# 35

How dare you deny the existence of God Who gave you life when you initially had no life. He will cause you to die and bring you to life again. Then you will return to His Presence.

# 36

It is He who created everything on earth for you. Then, directing His order towards the realm above, He turned it into seven heavens. He has knowledge of all things.

# 37

When your Lord said to the angels, "I am appointing someone as my deputy on earth," they said (almost protesting), "Are you going to appoint one who will commit corruption and bloodshed therein, even though we (are the ones who) commemorate Your Name and glorify You?" The Lord said, "I know that which you do not know".

# 38

He taught Adam all the names. Then He introduced (some intelligent beings) to the angels, asking them to tell Him the names of these beings, if the angels were true to their claim (that they more deserved to be His deputies on earth).

# 39

The angels replied, "You are glorious indeed! We do not know more than what You have taught us. You alone are All-knowing and All-wise".

# 40

The Lord said to Adam, "Tell the names of the beings to the angels." When Adam said their names, the Lord said, "Did I not tell you (angels) that I know the secrets of the heavens and the earth and all that you reveal or hide?"

# 41

When We told the angels to prostrate before Adam, they all obeyed except Iblis (Satan) who abstained out of pride and so he became one of those who deny the truth.

# 42

We told Adam to stay with his spouse (Eve) in the garden and enjoy the foods therein, but not to go near a certain tree lest he become one of the transgressors.

# 43

Satan made Adam and his spouse err and caused them to abandon the state in which they had been living. Then We said, "Descend, you are each other's enemies! The earth will be a dwelling place for you and it will provide you with sustenance for an appointed time.

# 44

Adam was inspired by some words (of prayer) through which he received forgiveness from his Lord, for He is All-forgiving and All-merciful.

# 45

We ordered them all to get out of the garden and told them that when Our guidance came to them, those who would follow it would have neither fear nor grief.

# 46

But those who would deny the Truth and reject Our revelations would be the companions of the Fire in which they would live forever.

# 47

Children of Israel, recall My favors which you enjoyed. Fulfill your covenant with Me and I shall fulfill Mine. Revere only Me.

# 48

Believe in My revelations (Quran) that confirms what I revealed to you (about Prophet Muhammad in your Scripture). Do not be the first ones to deny it nor sell My revelations for a small price, but have fear of Me.

# 49

Do not mix truth with falsehood and do not deliberately hide the truth

# 50

Be steadfast in prayer, pay the religious tax (zakat) and bow down in worship with those who do the same.

# 51

Would you order people to do good deeds and forget to do them yourselves even though you read the Book? Why do you not think?

# 52

Help yourselves (in your affairs) with patience and prayer. It is a difficult task indeed, but not for the humble ones

# 53

who are certain of their meeting with their Lord and their return to Him.

# 54

Children of Israel, recall My favors to you and the preference that I gave to you over all nations.

# 55

Have fear of the day when every soul will be responsible for itself. No intercession or ransom will be accepted and no one will receive help.

# 56

(Children of Israel, recall My favor) of saving you from the Pharaoh's people who afflicted you with the worst kind of cruelty, slaying your sons and sparing your women. Your suffering was indeed a great trial from your Lord.

# 57

We parted the sea to save you and drowned Pharaoh's people before your very eyes.

# 58

Then We called Moses for an appointment of forty nights. You began to worship the calf in his absence, doing wrong to yourselves.

# 59

Afterwards, We forgave you so that you would perhaps appreciate Our favors.

# 60

We gave Moses the Book and the criteria (of discerning right from wrong) so that perhaps you would be rightly guided.

# 61

Moses said to his people, "My people, you have done wrong to yourselves by worshipping the calf. Seek pardon from your Lord and slay yourselves." He told them that it would be best for them in the sight of their Lord, Who would forgive them, for He is All-forgiving and All-merciful.

# 62

When you argued with Moses, saying that you were not going to believe him unless you could see God with your own eyes, the swift wind struck you and you could do nothing but watch.

# 63

Then We brought you back to life in the hope that you might appreciate Our favors.

# 64

We provided you with shade from the clouds and sent down manna and quails as the best pure sustenance for you to eat. They (children of Israel) did not wrong Us but wronged themselves.

# 65

(Children of Israel, recall My favors) when We told you, "Enter this city, enjoy eating whatever you want therein, prostrate yourselves and ask forgiveness when passing through the gate, and We shall forgive your sins, and add to the rewards of the righteous ones".

# 66

The unjust ones among you changed what they were told to say. Then, We afflicted them with a torment from the heavens for their evil deeds.

# 67

When Moses prayed for rain, We told him to strike the rock with his staff. Thereupon twelve fountains gushed out of the rock and each tribe knew their drinking place. The Lord told them, "Eat and drink from God's bounties and do not abuse the earth with corruption."

# 68

When you demanded Moses to provide you with a variety of food, saying, "We no longer have patience with only one kind of food, ask your Lord to grow green herbs, cucumbers, corn, lentils, and onions for us," Moses replied, "Would you change what is good for what is worse? Go to any town and you will get what you want." Despised and afflicted with destitution, they brought the wrath of God back upon themselves, for they denied the evidence (of the existence of God) and murdered His Prophets without reason; they were disobedient transgressors.

# 69

However, those who have become believers (the Muslims), and the Jews, the Christians and the Sabaeans who believe in God and the Day of Judgment and strive righteously will receive their reward from the Lord and will have nothing to fear nor will they be grieved.

# 70

Children of Israel, recall when We made a covenant with you, raised Mount Tur (Sinai) above you and told you to receive earnestly what We had given to you and bear it in mind so that you would protect yourselves against evil.

# 71

Again you turned away. Had God's Grace and His Mercy not existed in your favor, you would certainly have been lost.

# 72

You certainly knew about those among you who were transgressors on the Sabbath. We commanded them, "Become detested apes,"

# 73

in order to set up an example for their contemporaries and coming generations and to make it a reminder for the pious.

# 74

When Moses said to his people, "God commands you to sacrifice a cow," they asked, "Are you mocking us?" "God forbid, how would I be so ignorant," said Moses.

# 75

They demanded, "Ask your Lord to describe the kind of cow He wants us to slaughter." Moses explained, "It must be neither too old nor too young, thus do whatever you are commanded to do." Moses then told them to do as they were ordered.

# 76

They further demanded Moses to ask the Lord what color the cow has to be. Moses answered, "The Lord says that the cow must be yellow, a beautiful yellow".

# 77

They said, "We are confused about the cow, for to us all cows look alike. Ask your Lord to tell us exactly what the cow looks like, so that God willing, we shall have the right description."

# 78

(Moses) said, "The Lord says that it must not have even tilled the soil nor irrigated the fields and it must be free of blemishes and flaws." They said, "Now you have given us the right description." After almost failing to find it, they slaughtered the cow.

# 79

When you murdered someone, each one of you tried to accuse others of being guilty. However, God made public what you were hiding.

# 80

We said, "Strike the person slain with some part of the cow." That is how God brings the dead to life and shows you His miracles so that you might have understanding.

# 81

Thereafter, your hearts turned as hard as rocks or even harder for some rocks give way to the streams to flow. Water comes out of some rocks when they are torn apart and others tumble down in awe before God. God does not ignore what you do.

# 82

Do you, the believers in truth, desire the unbelievers to believe you? There was a group among them who would hear the word of God and understand it. Then they would purposely misinterpret it.

# 83

On meeting the believers, they would declare belief but to each other they would say, "How would you (against your own interests) tell them (believers) about what God has revealed to you (in the Bible of the truthfulness of the Prophet Muhammad)? They will present it as evidence to prove you wrong before your Lord. Do you not realize it?"

# 84

Do they not know that God knows whatever they conceal or reveal?

# 85

Some of them are illiterate and have no knowledge of the Book except for what they know from legends and fantasy. They are only relying on conjecture.

# 86

Woe to those who write the Book themselves and say, "This is from God," so that they may sell it for a small price! Woe unto them for what they have done and for what they have gained!

# 87

They have said, "Hell fire will never harm us except for just a few days." (Muhammad), ask them, "Have you made such agreements with God Who never breaks any of His agreements or you just ascribe to Him that which you do not know?

# 88

There is no doubt that evil doers who are engulfed in sins are the companions of hell fire wherein they will live forever.

# 89

As for the righteously striving believers, they will be among the people of Paradise wherein they will live forever.

# 90

We made a covenant with the children of Israel that they should not worship anyone except Me, that they should serve their parents, relatives, orphans, and the destitute, that they should speak righteous words to people, and that they should be steadfast in their prayers and pay the religious tax. But soon after you made this covenant, all but a few of you broke it heedlessly.

# 91

We made a covenant with you that you should not shed each other's blood or expel each other from your homeland. You accepted and bore witness to this covenant,

# 92

yet you murdered each other and forced a number of your people out of their homeland, helping each other to commit sin and to be hostile to one another. When you had expelled people from their homeland and later they had been made captives (of other people), you then paid their ransom (thinking that it was a righteous deed). God forbade you to expel these people in the first place. Do you believe in one part of the Book and not in the other? Those who behave in this way shall reap disgrace in this world and severe punishment on the Day of Resurrection. God is not unaware of things that you do.

# 93

They have traded the life hereafter in exchange for their worldly life. Their punishment will not be eased nor will they receive help.

# 94

We gave the Book to Moses and made the Messengers follow in his path. To Jesus, the son of Mary, We gave the miracles and supported him by the Holy Spirit. Why do you arrogantly belie some Messengers and murder others whenever they have brought you messages that you dislike?

# 95

They have said that their hearts cannot understand (what you, Muhammad, say). God has condemned them for their denial of the Truth. There are a very few of them who have faith.

# 96

When a Book came to them from God which confirms what is with them (the fact of truthfulness of the Prophet Muhammad in their Scripture), and, despite the fact that they had been praying for victory over the disbelievers (by the help of the truthful Prophet), they refuse to accept this book, even though they know it (to be the Truth). May God condemn those who hide the Truth!

# 97

Evil is that for which they have sold their souls: They have refused to accept God's revelations in rebellion against the servant of God whom He has, by His Grace, chosen to grant His message. They have brought upon themselves God's wrath in addition to the wrath that they had incurred upon themselves for their previous sins. The disbelievers will suffer a humiliating torment.

# 98

When they are told to believe n God's revelations, they reply, "We believe only in what God has revealed to us," but they disbelieve His other true revelations, even though these revelations confirms their own (original) Scripture. (Muhammad) ask them, "Why did you murder God's Prophets if you were true believers?"

# 99

(Moses) brought you certain miracles. Not very long after, you began worshipping the calf which was nothing but senseless cruelty to yourselves.

# 100

(Children of Israel) when We made a covenant with you, raised Mount Tur (Sinai) above you, and told you to receive devotedly what We had revealed to you and to listen to it, you said that you had listened but you disobeyed. They denied the truth and became totally devoted and full of love for the calf. (Muhammad) tell these people, "If, in fact, you are true believers, then what your faith commands you to do is evil."

# 101

(Muhammad), tell them, "If your claim is true that the home with God in the everlasting life hereafter is for you alone, you should have a longing for death".

# 102

But they can never have a longing for death because of what they have done. God knows the unjust well.

# 103

However, you will find them the greediest of all men, even more than the pagans, for life. They would each gladly live for a thousand years, but such a long life would not save them from the torment. God sees what they do.

# 104

(Muhammad), tell the people, whoever is an enemy to Gabriel who has delivered the Book to your heart as a guide and as joyful news to the believers,

# 105

and as a confirmation of (original) Scripture and whoever is the enemy of God, His angels, His Messenger, Gabriel and Michael, should know that God is the enemy of those who hide the Truth..

# 106

(Muhammad) We have given you enlightening authority. Only the wicked sinners deny it.

# 107

Why is it that every time they (the Jews) make a covenant, some of them abandon it. Most of them do not even believe.

# 108

When a Messenger of God came to them confirming the (original) revelation that they already had received, a group of those who had the Scripture with them, threw the Book of God behind their backs as if they did not know anything about it.

# 109

They followed the incantations that the devils used against the kingdom of Solomon. Solomon did not hide the truth but the devils did. They taught magic to the people and whatever was revealed to the two angels, Harut and Marut, in Babylon. The two angels did not teach anything to anyone without saying, "Our case is a temptation for the people, so do not hide the truth." People learned something from the two angels that could cause discord between a man and his wife. However, they could harm no one except by the permission of God. In fact, the (people) learned things that would harm them and render them no benefit. They knew very well that one who engaged in witchcraft would have no reward in the life hereafter. Would that they had known that they had sold their souls for that which is vile!

# 110

Would that they had known that if they had embraced the faith and avoided evil, they would have received better rewards from God.

# 111

Believers, do not address the Prophet as ra'ina (whereby the Jews, in their own accent, meant: Would that you would never hear, but call him unzurna) (meaning: Please speak to us slowly so that we understand), and then listen. The unbelievers will face a painful torment.

# 112

(Muhammad) the disbelievers among the People of the Book and the pagans do not like to see anything good revealed to you from your Lord. God reserves His mercy for whomever He chooses. The generosity of God is great.

# 113

For whatever sign We change or eliminate or cause to recede into oblivion, We bring forth a better sign, one that is identical. Do you not know that God has power over all things?

# 114

Do you not know that the kingdom of the heavens and the earth belongs to God and that no one is your guardian or helper besides Him?

# 115

Do you want to address the Prophet in the same manner in which Moses was addressed? Anyone who exchanges belief for disbelief has certainly gone down the wrong path.

# 116

Once you have accepted the faith, many of the People of the Book would love, out of envy, to turn you back to disbelief, even after the Truth has become evident to them. Have forgiveness and bear with them until God issues His order. God has power over all things.

# 117

Be steadfast in your prayer and pay the religious tax. You will receive a good reward from God for all your good works. God is Well-aware of what you do.

# 118

They have said that no one can ever go to Paradise except the Jews or Christians, but this is only what they hope. Ask them to prove that their claim is true.

# 119

However, one who accepts Islam in submission to God and does good, will have his reward with God. Such people will have nothing to fear nor to grieve about.

# 120

The Jews accuse the Christians of having no basis for their religion and the Christians accuse the Jews of having no basis for their religion, even though both sides read the Scripture. The ignorant ones say the same thing. God will issue His decree about their dispute on the Day of Judgment.

# 121

Who is more unjust than those who strive to destroy the mosques and prevent others from commemorating the Name of God therein who could not enter the mosques except with fear. They, (the unjust ones), will be disgraced in this life and will receive great torment in the life hereafter.

# 122

The East and the West belong to God. Wherever you turn, you are always in the presence of God. God is Munificent and Omniscient.

# 123

They, (the People of the Book), have said that God has taken for Himself a son. He is too glorious to have a son. To Him belongs all that is in the heavens and the earth. All pray in obedience to Him.

# 124

God is the Originator of the heavens and the earth. Whenever He decides to do anything, He just commands it to exist and it comes into existence.

# 125

The ignorant have asked, "Why does He not speak to us and why has no evidence come to show us (that He exists)?" People before them had also asked such questions. They all think in the same way. We have already made the evidence very clear for those who have certainty.

# 126

We have sent you (Muhammad) for a genuine purpose to proclaim glad news and warnings. You will not be blamed for the dwellers of blazing hell.

# 127

The Jews and Christians will never be pleased with you unless you follow their faith. (Muhammad) tell them that the guidance of God is the only true guidance. If you follow their wishes after all the knowledge that has come to you, you will no longer have God as your guardian and helper."

# 128

Those (of the People of the Book) who have received Our Book (Quran), and read it thoroughly, believe in it. Those who disbelieve the Book are certainly losers.

# 129

Children of Israel, recall My favor to you and the preference that I gave to you over all the other nations.

# 130

Have fear of the day when every soul will be responsible for itself, no ransom will be accepted for it, no intercession will be of any benefit to it and no one will receive any help.

# 131

When his Lord tested Abraham's faith, (by His words) and he satisfied the test, He said, "I am appointing you as the leader of mankind." Abraham asked, "Will this leadership also continue through my descendants?" The Lord replied, "The unjust do not have the right to exercise My authority."

# 132

We made the house (in Mecca) as a place of refuge and sanctuary for men. Adopt the place where Abraham stood as a place for prayer. We advised Abraham and Ishmael to keep My house clean for the pilgrims, the worshippers and for those who bow down and prostrate themselves in worship.

# 133

When Abraham prayed to the Lord saying, "Lord, make this town a place of security and provide those in the town who believe in God and the Day of Judgement, with plenty," God replied, "I shall allow those who hide the truth to enjoy themselves for a while. Then I shall drive them into the torment of hell fire, a terrible destination!"

# 134

While Abraham and Ishmael were raising the foundation of the house, they prayed, "Lord, accept our labor. You are All-hearing and All-knowing.

# 135

Lord, make us good Muslims (one who submits himself to God) and from our descendants make a good Muslim nation. Teach us the rules of worship and accept our repentance; You are All-forgiving and All-merciful.

# 136

Lord, send to them (our descendants) a Messenger of their own who will recite to them Your revelations, teach them the Book, give them wisdom, and purify them. You alone are the Majestic and the Most Wise."

# 137

No one turns away from Abraham's Tradition except one who makes a fool of himself. To Abraham We have granted distinction in this world and in the life hereafter he will be among the righteous ones.

# 138

When God commanded Abraham to submit, he replied, "I have submitted myself to the Will of the Lord of the universe."

# 139

Abraham left this legacy to his sons and, in turn, so did Jacob saying, "God has chosen this religion for you. You must not leave this world unless you are a Muslim (submitted to the will of the Lord of the Universe)."

# 140

Were you (believers) there when death approached Jacob? When he asked his sons, "Whom will you worship after my death?" They replied, "We will worship your Lord, the Lord of your fathers, Abraham, Ishmael, and Isaac. He is the only Lord, and to Him we have submitted ourselves."

# 141

That nation (children of Abraham) is gone. They have reaped what they sowed, and the same applies to you. You are not responsible for their deeds.

# 142

The Jews and the Christians have asked the Muslims to accept their faith to have the right guidance. (Muhammad) tell them, "We would rather follow the upright religion of Abraham who was not a pagan".

# 143

(Muslims), say, "We believe in God and what He has revealed to us and to Abraham, Ishmael, Isaac, and their descendants, and what was revealed to Moses, Jesus, and the Prophets from their Lord. We make no distinction among them and to God we have submitted ourselves."

# 144

If they have faith in all that you believe, they will have the right guidance, but if they turn away, it would be for no reason other than their own malice. God is a Sufficient defender for you against them; He is All-hearing and All-knowing.

# 145

Say, "Belief in God and following the guidance of Islam are God's means of purification for us. Islam is the baptism of God. No one is a better baptizer than He and we Muslims worship Him."

# 146

(Muhammad), ask the People of the Book, "Why should you argue with us about God, Who is our Lord as well as yours, when we are sincere in our belief in God?

# 147

Everyone will be responsible for his own deeds. Do you (People of the Book) claim that Abraham, Ishmael, Isaac, and their descendants were Jews or Christians?" Ask them, "Who possesses greater knowledge, you or God? Who is more unjust than one who refuses to testify to the truth that God has given to him?" God is not unaware of what you do.

# 148

That nation is gone, they have reaped what they sowed and the same applies to you. You are not responsible for their deeds.

# 149

Fools will soon say, "What has made them (Muslims) change the direction to which they had been facing during their prayers (the qibla)?" (Muhammad), tell them, "Both the East and West belong to God and He guides (whomever He wants), to the right direction."

# 150

We have made you (true Muslims) a moderate nation so that you could be an example for all people and the Prophet an example for you. The direction which you had been facing during your prayers (the qibla) was only made in order that We would know who would follow the Messenger and who would turn away. It was a hard test but not for those to whom God has given guidance. God did not want to make your previous prayers worthless; God is Compassionate and All-merciful.

# 151

We certainly saw you (Muhammad) often turn your face to the sky, so We shall instruct you to face a qibla that you will like. (Muhammad) during prayer, turn your face towards the Sacred Mosque (in Makkah). Muslims, also, wherever you are, during your prayers, turn your faces towards the Sacred Mosque. The People of the Book certainly know that this command (to change the qibla) is truly from their Lord. God is not unaware of what they do.

# 152

Even if you were to bring all kinds of authoritative proof to the People of the Book, they still would not accept your qibla, nor would you accept theirs, nor would they accept each others. Were you to follow their desires after all the knowledge that has come to you, you would certainly have been one of the unjust.

# 153

Those to whom We have given the Book (Bible), know you (Muhammad) just as a well as they know their sons. It is certain that some of them deliberately hide the truth.

# 154

Never doubt that the essence of truth comes from your Lord

# 155

Every one pursues his goal. Compete with each other in performing good deeds. Wherever you are, God will bring you all together. God has power over all things.

# 156

(Muhammad), wherever you go, turn your face towards the Sacred Mosque (in Mecca). This is the truth from your Lord who is not unaware of what you do

# 157

(Muhammad) wherever you go, turn your face to the Sacred Mosque and Muslims, wherever you are, turn your faces in the same direction so that no group of people, except the unjust among them, would have any reason against you and so that I may establish My commandments for your people to have proper guidance. (The unjust may criticize you) but do not fear them, fear only Me.

# 158

As We have sent a Messenger from your own people to show you evidence about Me, to purify you from sins, to teach you the Book, give you wisdom and instruct you in that which you did not know,

# 159

therefore, remember Me and I shall remember you. Thank Me and do not hide the truth about Me.

# 160

Believers, help yourselves (in your affairs) through patience and prayer; God is with those who have patience.

# 161

Do not consider those who are slain for the cause of God to be dead. They are alive but you are unaware of them.

# 162

We shall test you through fear, hunger, loss of life, property, and crops. (Muhammad), give glad news to the people who have patience

# 163

and in difficulty say, "We are the servants of God and to Him we shall all return".

# 164

It is they who will receive blessings and mercy from God and who follow the right guidance.

# 165

Safa and Marwah (names of two places in Mecca) are reminders of God. It is no sin for one who visits the Sacred House (in Mecca) to walk seven times between (Safa and Marwah.) Whoever willingly does a good deed in obedience to God, will find God All-knowing and Fully Appreciative.

# 166

Those who hide the authoritative proofs and the guidance that We have revealed, after it has been made clear for the People of the Book, will be condemned by God and those who have the right to condemn.

# 167

However, I shall accept the repentance of those of them who repent for their sins, reform their manners, and preach the truth; I am All-forgiving and All-merciful.

# 168

Those who deny My existence and die with such attitude will be subject to the condemnation of God, the angels, and all people.

# 169

They will live condemned forever, will have no relief from the torment, and no attention will be paid to them.

# 170

Our Lord is the only Lord. There is no God but He, the Beneficent and Merciful.

# 171

The creation of the heavens and the earth, the alternation of nights and days, the ships that sail in the sea for the benefit of the people, the water that God sends from the sky to revive the dead earth where He has scattered all kinds of animals, the winds of all directions, and the clouds rendered for service between the sky and the earth are all evidence (of His existence) for those who use their reason.

# 172

Some people consider certain things equal to God and love them just as one should love God. However, the strongest of the believers' love is their love of God. Had the unjust been able to reflect about their condition, when facing the torment, they would have had no doubt that to God belongs All-power and that He is stern in His retribution.

# 173

When the leaders see the torment and lose all their resources, they will denounce their followers.

# 174

The followers will say, "Had we had the chance we also would have denounced our leaders." That is how God will show them their regrettable deeds. They will not be able to escape from hell fire.

# 175

People, eat of the good and lawful things on earth. Do not follow the footsteps of Satan; he is clearly your enemy.

# 176

He tries to make you do evil and shameful things and speak against God without knowledge.

# 177

When some people are asked to follow the revelations of God, they say, "We would rather follow what our fathers have followed," even though their fathers had no understanding and could not find the true guidance.

# 178

Preaching to unbelievers is like talking to someone who cannot hear anything except yells and shouts. They are deaf, dumb, and blind; they have no understanding.

# 179

Believers, eat from the good things that We have given you and give thanks to God if you worship only Him.

# 180

God has forbidden you to eat that which has not been properly slaughtered, blood, pork, and the flesh of any animal which has not been consecrated with a mention of the Name of God. However, in an emergency, without the intention of transgression or repeating transgression, one will not be considered to have committed a sin. God is All-forgiving and All-merciful.

# 181

Those who receive some small gain by hiding the Books which God has revealed, have, in fact, filled up their stomachs with fire. God will not speak with them on the Day of Judgment, nor will He purify them; instead, they will face a painful torment.

# 182

They have exchanged guidance for error and forgiveness for torment. What makes them seek the fire so earnestly (for they are doomed to be punished)?

# 183

God has revealed the Book in all Truth and those who dispute it are filled with malice which has taken them far away from the truth.

# 184

Righteousness is not determined by facing East or West during prayer. Righteousness consists of the belief in God, the Day of Judgment, the angels, the Books of God, His Prophets; to give money for the love of God to relatives, orphans, the destitute, and those who are on a journey and in urgent need of money, beggars; to set free slaves and to be steadfast in prayer, to pay the religious tax (zakat) to fulfill one's promises, and to exercise patience in poverty, in distress, and in times of war. Such people who do these are truly righteous and pious.

# 185

Believers, in case of murder, the death penalty is the sanctioned retaliation: a free man for a free man, a slave for a slave, and a female for a female. However, if the convicted person receives pardon from the aggrieved party, the prescribed rules of compensation must be followed accordingly. This is a merciful alteration from your Lord. Whoever transgresses against it will face a painful punishment.

# 186

People of understanding, the law of the death penalty as retaliation grants you life so that perhaps you will have fear of God.

# 187

If one of you facing death can leave a legacy, he should bequeath it to his parents and relatives, according to the law. This is the duty of the pious.

# 188

Whoever intentionally changes the will of a deceased person, he has committed a sin. God is All-hearing and All-knowing.

# 189

One who is afraid of the testator's deviations and sin and settles the matter among the parties involved, he has not committed a sin. God is All-forgiving and All-merciful.

# 190

Believers, fasting has been made mandatory for you as it was made mandatory for the people before you, so that you may have fear of God.

# 191

Fasting is only for a certain number of days. One who is sick or on a journey has to fast the same number of days at another time. Those who can afford a redemption should feed a poor person. Good deeds performed on one's own initiative will be rewarded. However, fasting is better and will be rewarded. Would that you knew this!

# 192

The month of Ramadan is the month in which the Quran was revealed; a guide for the people, the most authoritative of all guidance and a criteria to discern right from wrong. Anyone of you who knows that the month of Ramadan has begun, he must start to fast. Those who are sick or on a journey have to fast the same number of days at another time. God does not impose any hardship upon you. He wants you to have comfort so that you may complete the fast, glorify God for His having given you guidance, and that, perhaps, you would give Him thanks.

# 193

(Muhammad), if any of My servants ask you about Me, tell them that the Lord says, "I am near; I accept the prayers of those who pray." Let My servants answer My call and believe in Me so that perhaps they may know the right direction.

# 194

It is made lawful for you, during the nights of fasting, to have carnal relations with your wives. They are your garments and you are their garments. God knew that you were deceiving yourselves. He relented towards you and forgave you. Now it is lawful for you to have carnal relations with your wives and follow what God has commanded. Eat and drink until the white streak of dawn becomes distinguishable from darkness. Complete your fast, starting from dawn to dusk. It is not lawful to have carnal relations with your wives during i'tikaf in the mosque. Such are the limits of the laws of God. Do not come close to transgressing them. Thus has God explained His evidence to men so that perhaps they will have fear of God.

# 195

Do not use your property among yourselves in illegal ways and then deliberately bribe the rulers with your property so that you may wrongly acquire the property of others.

# 196

(Muhammad), they ask you about the different phases of the moon. Tell them that they are there to indicate to people the phases of time and the pilgrimage season. It is not a righteous act to enter houses from the back. Righteousness is to be pious and enter the houses from the front door. Have fear of God so that perhaps you will have lasting happiness.

# 197

Fight for the cause of God, those who fight you, but do not transgress, for God does not love the transgressors.

# 198

Slay them wherever you may catch them and expel them from the place from which they expelled you. The sin of disbelief in God is greater than committing murder. Do not fight them in the vicinity of the Sacred Mosque in Mecca unless they start to fight. Then slay them for it is the recompense that the disbelievers deserve.

# 199

If they give up disbelief and fighting, God is All-forgiving and All-merciful.

# 200

Fight them so that there will be no disbelief in God and God's religion will become dominant. If they change their behavior, there would be no hostility against anyone except the unjust.

# 201

It is because of their disrespect of a sacred month that you are also allowed to retaliate against them in a sacred month. If any one transgresses against you, you also may retaliate against them to an equal extent. Have fear of God and know that He supports the pious.

# 202

Give money for the cause of God but do not push yourselves into perdition. Do good; God loves the people who do good deeds.

# 203

Complete the hajj and umrah (two parts of the rituals of pilgrimage to Makka) in obedience to God. If you are prevented from completing the duty of hajj, offer whatever sacrifice is possible and do not shave your heads before the sacrificial animal is delivered to the prescribed place. If one of you is ill or is suffering because of some ailment in your head, you must redeem the shaving of the head by fasting, or paying money, or offering a sheep as a sacrifice. When all is well with you and you want to complete the umrah in the hajj season, offer whatever sacrifice is possible. If you do not find an animal, you have to fast for three days during the days of the pilgrimage rituals and seven days at home to complete the required ten fasting days. This rule is for those who live beyond (a distance of twelve miles from) the Sacred Mosque in Mecca. Have fear of God and know that He is stern in His retribution.

# 204

The months of the hajj (pilgrimage) season are well known. Whoever undertakes to complete the hajj rituals, must know that, after commencing the acts of Hajj, he is not allowed to have carnal relations or to lie or to swear by the Name of God. God knows all your good deeds. Supply yourselves for the journey. The best supply is piety. People of understanding have fear of Me.

# 205

It is not a sin if you try to make a profit out of the bounty of your Lord (by trading during hajj). When you leave Arafah, commemorate the name of your Lord in Mash'ar, the sacred reminder of God. Commemorate His name as He has given you guidance while prior to that you had been in error.

# 206

Then leave Mash'ar as the rest of the people do and ask forgiveness from God; He is All-forgiving and All-merciful.

# 207

After you complete the acts of your Hajj, also commemorate God, just as you would remember your father, or even more earnestly. Some people say, "Lord, give us what we want in this life," but in the life hereafter they have no beneficial share.

# 208

Others pray, "Lord, give us good things both in this life as well as in the life hereafter and save us from the torment of fire".

# 209

They will have their share of the reward for their deeds. God's reckoning is swift.

# 210

Commemorate (the names of) God in the prescribed days. For one who observes piety, it is not a sin to be hasty or tardy during the two days. Have fear of God and know that before Him you will all be raised after death.

# 211

There are some people whose words about this life may please you. They say that God knows what they have in their hearts. But, in fact, they are the most quarrelsome opponents.

# 212

As soon as they leave you, they quickly commit evil in the land, destroying the farms and people. God does not love evil.

# 213

When they are asked to have fear of God, sinful pride prevents them from paying heed to such advice. It is enough for them to have hell as a terrible dwelling place.

# 214

There are those among people who give their lives to seek God's pleasure. God is Affectionate to His servants.

# 215

Believers, submit yourselves to the will of God as a whole. Do not follow the footsteps of Satan; he is your sworn enemy.

# 216

If you are seduced after you have received the authoritative guidance, know that God is Majestic and Wise.

# 217

Have they decided not to believe until God comes down in a shadow of clouds with the angels so that then the matter is settled? To God do all matters return.

# 218

(Muhammad), ask the children of Israel about how many visible miracles We had shown them. God is certainly stern in His retribution to those who change the bounty of God (His revelation), after having received His guidance.

# 219

The worldly life is made to seem attractive to the disbelievers who scoff at the faithful, but the pious, in the life hereafter, will have a position far above them. God grants sustenance (without account) to anyone He wants.

# 220

At one time all people were only one nation. God sent Prophets with glad news and warnings. He sent the Book with them for a genuine purpose to provide the people with the ruling about disputed matters among them. No one disputed this matter except those who had already received evidence before. Their dispute was only because of their own hostility. To deal with this dispute, God, through His will, sent guidance to the believers. God guides to the right path whomever He wants.

# 221

Would you think that you could go to Paradise without experiencing the kind of suffering others have experienced before you? Distress and afflictions battered them until the Messenger and the believers said, "When will God send help?" Certainly God's help is near.

# 222

They ask you what to spend for the cause of God. (Muhammad) tell them that whatever you spend, give it to your parents, the orphans, the destitute, and those who may be in urgent need of money whilst on a journey. Whatever good you do, God certainly is Aware of it.

# 223

Fighting is made mandatory for you, but you dislike it. You may not like something which, in fact, is for your good and something that you may love, in fact, may be evil. God knows, but you do not know.

# 224

(Muhammad), they ask you about fighting in the sacred month. Tell them that it is a great sin. However, creating an obstacle in the way of God, disbelief in Him and the Sacred Mosque, and driving away the neighbors of the Sacred Mosque is an even greater sin in the sight of God: Disbelief in God is worse than committing murder. (The pagans) still try to fight you to make you give up your religion. The deeds in this life of those of you who give up their religion and who die disbelievers will be made void and in the life hereafter. These people will be the dwellers of Hell wherein they will remain forever.

# 225

The believers and the Emigrants from Mecca who fight for the cause of God, indeed have hope in receiving the mercy of God; God is All-forgiving and All-merciful.

# 226

(Muhammad), they ask you about wine and gambling. Tell them that there is great sin in them. Although they have benefits for men, the sin therein is far greater than the benefit. They ask you about what they should give for the cause of God. Tell them, "Let it be what you can spare." This is how God explains for you His guidance so that perhaps you will think

# 227

about this life and the life hereafter. They ask you about the orphans. Tell them, "The best thing to do is what is for their good. They are your brethren if you would associate with them. God knows who is corrupt or a reformer. Had God wanted He would have brought upon you hardship. God is Majestic and All-wise.

# 228

Do not marry pagan women unless they believe in God. A believing slave girl is better than an idolater, even though the idolaters may attract you. Do not marry pagan men unless they believe in God. A believing slave is better than an idolater, even though the idolater may attract you. The pagans invite you to the fire, but God invites you to Paradise and forgiveness through His will. God shows His evidence to people so that they may take heed.

# 229

They ask you about women's menses. Tell them, "It is an ailment. Avoid having carnal relations with them until their period is over." Then you may have carnal relations with them according to the rules of God. God loves those who repent and those who purify themselves.

# 230

Your wives are as fields for you. You may enter your fields from any place you want. Reserve something good for your souls (for the life hereafter). Have fear of God and know that you are going to meet Him. (Muhammad) give the glad news to the believers.

# 231

Do not swear by God not to do good things, or have piety, or make peace among people. God is All-hearing and All-knowing.

# 232

God will not take into account your inattentive oath. However, He will question you about what your hearts have gained. God is All-forgiving and Lenient.

# 233

Those who swear by God not to ever have any carnal relations with their wives (will not be punished), if they decide to resume marital relations again within four months. God is All-forgiving and All-merciful.

# 234

If they choose divorce, God is All-hearing and All-knowing.

# 235

The divorced women must wait up to three menstrual cycles before another marriage. If they believe in God and the Day of Judgment, it is not lawful for them to hide what God has created in their wombs. Within their waiting period their husbands have the right to resume marital relations, if they want reconciliation. Women have benefits as well as responsibilities. Men have a status above women. God is Majestic and Wise.

# 236

A marital relation can only be resumed after the first and second divorce, otherwise it must be continued with fairness or terminated with kindness. It is not lawful for you to take back from women what you have given them unless you are afraid of not being able to observe God's law. In this case, it would be no sin for her to pay a ransom to set herself free from the bond of marriage. These are the laws of God. Do not transgress against them; those who do so are unjust.

# 237

After a divorce for the third time, it is not lawful for the husband to resume marital relations with her or remarry her until she has been married and divorced by another husband. In that case, there is no sin for the former husband to marry her if they (both) think that they can abide by the law. These are the laws of God. He explains them for the people of knowledge.

# 238

When you divorce your wives and their waiting period has almost ended, you may resume marital relations with honor or leave them with kindness. Do not force them to live with you in suffering to satisfy your hostility. Whoever commits such transgressions, he has only harmed himself. Do not make jest of God's words. Remember the favors that God has done to you and the Book and wisdom He has revealed for your guidance. Have fear of God and know that God has knowledge of all things.

# 239

When the waiting period of the divorced women has ended, you (her relatives) must not prevent them from marrying their (previous) husbands again if they might reach an honorable agreement. This is an advice for those of you who believe in God and the Day of Judgment. It is the most beneficial and pure way of treating each other. God knows but you do not know.

# 240

Mothers will breast feed their babies for two years if the fathers want them to complete this term. The father has to pay them reasonable expenses. No soul is responsible for what is beyond its ability. None of the parents should suffer any loss from the other because of the baby. The heirs are responsible to look after the children of a deceased. It is no sin for the parents to have a mutual agreement about weaning the baby. There is no sin in hiring a woman to breast feed your children for a reasonable payment. Have fear of God and know that God is well aware of what you do.

# 241

The wives of those of you who die have to wait for a period of four months and ten days. After this appointed time, it is no sin for the relatives of the deceased to let the widows do what is reasonable. God knows well what you do.

# 242

It is not a sin if you make an indirect marriage proposal or have such an intention in your hearts. God knows that you will cherish their memories in your hearts. Do not have secret dates unless you behave lawfully. Do not decide for a marriage before the appointed time is over. Know that God knows what is in your hearts. Have fear of Him and know that He is All-forgiving and All-merciful.

# 243

Also, it is not a sin if you divorce your wives before the consummation of the marriage or the fixing of the dowry. But the dowry will be due from a husband whether he is rich or poor. It is payable in a reasonable amount according to the husband's financial ability. This is an obligation for the righteous ones.

# 244

If you divorce your wives before the consummation of the marriage and the amount of dowry has been fixed, pay your wives half of the amount of their dowry unless she or her guardians drop their demand for payment. To drop such a demand is closer to piety. Be generous to each other. God is Well-Aware of what you do.

# 245

Pay due attention to your prayers, especially the middle prayer and stand up while praying, in obedience to God.

# 246

In an emergency you may say your prayers while walking or riding; but when you are safe, remember God, as He has taught you what you did not know before.

# 247

Those who are about to die and leave widows behind should bequeath for their wives the expenses of one year's maintenance. The widows must not be expelled from the house for up to one year. It is no sin for the relatives of the deceased to permit the widows to leave the house before the appointed time and do what is reasonable. God is Majestic and Wise.

# 248

The divorced women have the right to receive reasonable provisions. It is an obligation for the pious.

# 249

Thus does God explain His revelations to you so that perhaps you will have understanding.

# 250

(Muhammad), consider the thousands who left their homes for fear of death, who were then caused by God to die and brought back to life. God is generous to men but most people are not grateful.

# 251

Fight for the cause of God and know that God is All-hearing and All-knowing.

# 252

One who generously lends to God will be paid back in many multiples of the loan. It is God who reduces and expands things and to Him you will all return.

# 253

(Muhammad), remember that group of the Israelites after Moses who demanded a Prophet of their own to appoint a king for them who would lead them in the fight for the cause of God. Their Prophet then said, "What if you are ordered to fight and you disobey?" They said, "Why should we not fight for the cause of God when we and our sons have been expelled from our homes?" However, when they were ordered to fight, all refused except a few among them. God knows well the unjust.

# 254

Their Prophet said, "God has appointed Saul as a king for you." They replied, "How can he dominate us when we deserve more to be king than he. Besides, he does not have abundant wealth." Their Prophet said, "God has chosen him as your ruler and has given him physical power and knowledge. God grants His authority to anyone whom He wants. God is Provident and All-knowing.

# 255

Their Prophet further told them, "As the evidence of his authority, he will bring to you the Ark which will be a comfort to you from your Lord and a legacy of the household of Moses and Aaron. It will be carried by the angels. This is the evidence for you if you have faith."

# 256

When Saul set forth with the army he said, "God will test you with a river. Those who drink its water will not be of my people and those who do not even taste the water or who only taste some of it from within the hollow of their hand, will be my friends. They all drank the water except a few of them. When Saul and those who believed in him crossed the river, his people said, "We do not have the strength to fight against Goliath and his army." Those who thought that they would meet God said, "How often, with God's permission, have small groups defeated the large ones?" God is with those who exercise patience.

# 257

Advancing towards Goliath and his army, they prayed to God for patience, steadfastness in battle, and for victory over the unbelievers.

# 258

They defeated their enemy through God's will. David slew Goliath and God granted David the kingdom and wisdom and also taught him whatever He wanted. Had God not made one group of people repel the other, the earth would have become full of corruption, but God is generous to His creatures.

# 259

(Muhammad), these are the revelations which We recite to you for a genuine purpose. Certainly you are one of Our Messengers.

# 260

We gave some of Our Messengers preference over others. To some of them God spoke and He raised the rank of some others. We gave authoritative proofs to Jesus, son of Mary, and supported him by the Holy Spirit. Had God wanted, the generations who lived after those Messengers would not have fought each other after the authority had come to them. But they differed among themselves, some of them believed in the authority and others denied it. They would not have fought each other had God wanted, but God does as He wills.

# 261

Believers, out of what We have given you, spend for the cause of God before the coming of the day when there will be no trading, no friendship, and no intercession. Those who deny the Truth are unjust.

# 262

God exists. There is no God but He, the Everlasting and the Guardian of life. Drowsiness or sleep do not seize him. To Him belongs all that is in the heavens and the earth. No one can intercede with Him for others except by His permission. He knows about people's present and past. No one can grasp anything from His knowledge besides what He has permitted them to grasp. The heavens and the earth are under His dominion. He does not experience fatigue in preserving them both. He is the Highest and the Greatest.

# 263

There is no compulsion in religion. Certainly, right has become clearly distinct from wrong. Whoever rejects the devil and believes in God has firmly taken hold of a strong handle that never breaks. God is All-hearing and knowing.

# 264

God is the Guardian of the believers and it is He who takes them out of darkness into light. The Devil is the guardian of those who deny the Truth and he leads them from light to darkness. These are the dwellers of hell wherein they will live forever.

# 265

(Muhammad), have you heard about the one who argued with Abraham about his Lord for His granting him authority? Abraham said, "It is only my Lord who gives life and causes things to die." His opponent said, "I also can give life and make things die." Abraham said, "God causes the sun to come up from the East. You make it come from the West." Thus the unbeliever was confounded. God does not guide the unjust people.

# 266

(Or have you heard) of the one who, on passing through an empty and ruined town, said, "When will God bring it to life?" God caused him to die and brought him back to life after a hundred years and then asked him, "How long have you been here?" He replied, "One day or part of a day." The Lord said, "No, you have been here for one hundred years. Look at your food and drink. They have not yet decayed. But look at your donkey and its bones. To make your case evidence (of the Truth) for the people, see how we bring the bones together and cover them with flesh." When he learned the whole story, he said, "Now I know that God has power over all things."

# 267

When Abraham prayed, "Lord, show me how you bring the dead back to life," the Lord said, "Do you not yet believe?" Abraham replied, "I believe but want more confidence for my heart." God told him, "Take four birds, induce them to come to you, cut and scatter their bodies leaving parts on every mountain top, then call them and they will swiftly come to you." Know that God is Majestic and Wise.

# 268

Spending money for the cause of God is as the seed from which seven ears may grow, each bearing one hundred grains. God gives in multiples to those whom He wants. God is Munificent and All-knowing.

# 269

Those who spend their property for the cause of God and do not make the recipient feel obliged or insulted shall receive their reward from God. They will have no fear nor will they be grieved.

# 270

Instructive words and forgiveness are better than charity that may cause an insult to the recipient. God is Rich and Forbearing.

# 271

Believers, do not make your charities fruitless by reproachfully reminding the recipient of your favor or making them feel insulted, like the one who spends his property to show off and who has no faith in God or belief in the Day of Judgment. The example of his deed is as though some soil has gathered on a rock and after a rain fall it turns hard and barren. Such people can not benefit from what they have earned. God does not guide the unbelievers.

# 272

The example of those who spend their property to please God out of their firm and sincere intention is as the garden on a fertile land which, after a heavy rainfall or even a drizzle, yields double produce. God is Well-Aware of what you do.

# 273

(What do you think of the case) of one of you who wishes to have a garden of palm-trees and grapes with water flowing therein and producing all kinds of fruits, especially if he is well advanced in age and has weak children who need support, and then a hurricane with fire in it strikes the garden and burns it to the ground? This is how God explains to you His evidence so that you may think.

# 274

Believers, spend for the cause of God from the good things that you earn and from what we have made the earth yield for you. Do not even think of spending for the cause of God worthless things that you yourselves would be reluctant to accept. Know that God is Self-sufficient and Glorious.

# 275

Satan threatens you with poverty and commands you to commit sin. God promises you forgiveness and favors. God is Munificent and All-knowing.

# 276

God gives wisdom to anyone whom He wants. Whoever is given wisdom, certainly, has received much good. Only people of reason can grasp this.

# 277

God knows all about whatever you spend for His cause or any vows that you make. The unjust people have no helper.

# 278

It is not bad to give alms in public. However if you give them privately to the poor, it would be better for you and an expiation for some of your sins. God is Well-Aware of what you do.

# 279

(Muhammad), you do not have to guide them. God guides whomever He wants. Whatever you spend for the cause of God is for your own good, provided you do not spend anything but to please God. For anything good that you may give for the cause of God, you will receive sufficient reward and no injustice will be done to you.

# 280

(If the recipients of charity are) the poor whose poverty, because of their striving for the cause of God, has become an obstacle for them, and who do not have the ability to travel in the land, they seem rich compared to the ignorant, because of their modest behavior. You would know them by their faces. They would never earnestly ask people for help. God knows well whatever wealth you spend for the cause of God.

# 281

Those who spend their property for the cause of God, any time during the day or night, in public or in private, will receive their reward from their Lord. There will be no fear for them nor will they grieve.

# 282

Those who take unlawful interest will stand before God (on the Day of Judgment) as those who suffer from a mental imbalance because of Satan's touch; they have said that trade is just like unlawful interest. God has made trade lawful and has forbidden unlawful interest. One who has received advice from his Lord and has stopped committing sins will be rewarded for his previous good deeds. His affairs will be in the hands of God. But one who turns back to committing sins will be of the dwellers of hell wherein he will live forever.

# 283

God makes unlawful interest devoid of all blessings and causes charity to increase. God does not love sinful unbelievers.

# 284

The righteously striving believers who are steadfast in their prayers and pay the zakat, will receive their reward from God. They will have no fear nor will they grieve.

# 285

Believers, have fear of God and give up whatever unlawful interest you still demand from others, if you are indeed true believers.

# 286

If you will not give up the unlawful interest which you demand, know that you are in the state of war with God and His Messenger. But if you repent, you will have your capital without being wronged or having done wrong to others.

# 287

One who faces hardship in paying his debts must be given time until his financial condition improves. Would that you knew that waiving such a loan as charity would be better for you!

# 288

Safeguard yourselves against the day when you will return to God and every soul will be rewarded according to its deeds without being wronged.

# 289

Believers, if you take a loan for a known period of time, have a just scribe write it down for you. The scribe should not refuse to do this as God has taught him. The debtor should dictate without any omission and have fear of God, his Lord. If the debtor is a fool, a minor, or one who is unable to dictate, his guardian should act with justice as his representative. Let two men or one man and two women whom you choose, bear witness to the contract so that if one of them makes a mistake the other could correct him. The witness must not refuse to testify when their testimony is needed. Do not disdain writing down a small or a large contract with all the details. A written record of the contract is more just in the sight of God, more helpful for the witness, and a more scrupulous way to avoid doubt. However, if everything in the contract is exchanged at the same time, there is no sin in not writing it down. Let some people bear witness to your trade contracts but the scribe or witness must not be harmed; it is a sin to harm them. Have fear of God. God teaches you. He has knowledge of all things.

# 290

If you are on a journey where you cannot find a scribe, finalize your contract in the form of a deposit in which the goods are already given to the parties. If you trust each other in such a contract, let him pay back what he has entrusted you with and have fear of God, his Lord. Do not refuse to testify to what you bore witness. Whoever does so has committed a sin. God knows what you do.

# 291

God belongs whatever is in the heavens and the earth. God will call you to account for all that you may reveal from your souls and all that you may conceal. God will forgive or punish whomever He wants. God has power over all things.

# 292

The Messengers and the believers have faith in what was revealed to them from their Lord. Everyone of them believed in God, His angels, His Books, and His Messengers, saying, "We find no difference among the Messengers of God." They also have said, "We heard God's commands and obeyed them. Lord, we need Your forgiveness and to You we shall return."

# 293

God does not impose on any soul a responsibility beyond its ability. Every soul receives whatever it gains and is liable for whatever it does. Lord, do not hold us responsible for our forgetfulness and mistakes. Lord, do not lay upon us the burden that You laid on those who lived before us. Lord, do not lay on us what we cannot afford. Ignore and forgive our sins. Have mercy on us. You are our Lord. Help us against the unbelievers.

# 294

Alif. Lam. Mim.

# 295

God exists. He is the only Lord, the Everlasting and the Guardian of life.

# 296

He has sent the Book (Quran) to you (Muhammad) in all Truth. It confirms the original Bible. He revealed the Torah and the Gospel

# 297

before as a guide for the people and now He has revealed the criteria of discerning right from wrong. Those who reject the revelations of God will face the most severe torment. God is Majestic and capable to revenge.

# 298

Nothing in the heavens or the earth is hidden from God.

# 299

It is God who shapes you in the wombs as He wills. He is the only Lord, the Majestic, and All-wise.

# 300

It is God who has revealed the Book to you in which some verses are clear statements (which accept no interpretation) and these are the fundamental ideas of the Book, while other verses may have several possibilities. Those whose hearts are perverse, follow the unclear statements in pursuit of their own mischievous goals by interpreting them in a way that will suit their own purpose. No one knows its true interpretations except God and those who have a firm grounding in knowledge say, "We believe in it. All its verses are from our Lord." No one can grasp this fact except the people of reason.

# 301

They say, "Lord, do not cause our hearts to deviate from Your guidance, and grant us mercy. You are the Most Awarding One.

# 302

Lord, it is certain that one day You will gather all the people together. God does not break His promise."

# 303

The wealth and children of the unbelievers will never serve them as a substitute for their belief in God. Such people will be the fuel for the fire.

# 304

They do as the people of Pharaoh and those who lived before them did. They called Our revelations mere lies. God punished them for their sins. God is stern in His retribution.

# 305

(Muhammad), tell the unbelievers that they will soon be defeated and driven into Hell, a terrible dwelling.

# 306

There, certainly, is evidence (of the existence of God) for you in the case of the two armies. One of them fought for the cause of God. The other were disbelievers. The disbelievers appeared to be twice the size of the believers. However, God supports through His help whomever He wants. It is a good lesson for the people of true vision.

# 307

Worldly desires, wives, children, accumulated treasures of gold and silver, horses of noble breed, cattle, and farms are all made to seem attractive to men. All these are the bounties of the worldly life but in the life to come God has the best place for people to dwell.

# 308

(Muhammad), ask them, "Shall I tell you what is far superior to worldly pleasures? Those who have fear of God will have (as their reward) gardens wherein streams flow and wherein they will live forever with their purified spouses and with the consent of God. God knows all about His servants."

# 309

(Such will be the reward of) those who say, "Lord, we have believed in you. Forgive us our sins and save us from the torment of fire,"

# 310

who exercise patience, speak the truth, who are devoted in prayer, spend their property for the cause of God and seek forgiveness from God during the last part of the night.

# 311

God Himself testifies that He is the only Lord. The angels and the men of knowledge and justice testify that God is the only Lord, the Majestic, and All-wise.

# 312

In the sight of God Islam is the religion. The People of the Book created differences in the matters (of religion) because of their hostility among themselves, only after knowledge had come to them. Let whoever denies the revelations of God know that the reckoning of God is swift.

# 313

(Muhammad), if the People of the Book argue against you, say, "I and those who follow me have submitted ourselves to God." Ask the People of the Book and the illiterate ones, "Have you embraced Islam?" If they embrace Islam, they will find guidance but if they turn away, your task is just to preach. God knows all about His servants.

# 314

Warn those who deny the revelations of God and unjustly slay the Prophets and those who call people to be just, that they will suffer a painful torment.

# 315

The deeds of such people are made devoid of all virtue in both this life and the life to come. There will be no one to help them.

# 316

(Muhammad), consider those who have received a share of the Book. When they refer to the Book in order to judge amongst themselves, a group of them turn away with disregard

# 317

because of their belief that the fire will only touch them for a few days. This fabricated belief has deceived them in matters of their religion.

# 318

What will happen to their belief when We bring them together on the Inevitable Day when every soul will be justly recompensed for its deeds?

# 319

(Muhammad), say, "Lord, Owner of the Kingdom, You give authority to whomever You want and take it away from whomever You want. You give honor to whomever You want and humiliate whomever You want. In Your hands is all virtue and You have power over all things.

# 320

You cause the day to enter into the night and the night to enter into the day. You cause the living to come out of the dead and the dead to come out of the living. You give sustenance to whomever You want without keeping an account.

# 321

The believers must not establish friendship with the unbelievers in preference to the faithful. Whoever does so has nothing to hope for from God unless he does it out of fear or taqiyah (pious dissimulation). God warns you about Himself. To God do all things return.

# 322

(Muhammad), tell them, "God knows all that you may conceal in your hearts or you may reveal. He knows all that is in the heavens and the earth. He has power over all things.

# 323

On the day when every soul will see its good and bad deeds right before its very eyes, it will wish for the longest period of time to separate it from its bad deeds. God warns you about Himself. God is Compassionate to His servants.

# 324

(Muhammad), tell them, "If you love God, follow me. God will love you and forgive your sins. God is All-forgiving and All-merciful."

# 325

Tell them, "Obey God and the Messenger." If they turn away (let it be known) that God does not love the unbelievers.

# 326

God chose (and gave distinction to) Adam, Noah, the family of Abraham, and Imran over all the people of the world.

# 327

They were the offspring of one another. God is All-hearing and All-seeing.

# 328

Remember when Imran's wife prayed to her Lord saying, "I have made a vow to dedicate to Your service whatever is in my womb. Lord, accept it from me. You are All-hearing and All-knowing".

# 329

When the baby was born she said, "Lord, it is a female." God knew this. Male and female are not alike. "I have named her Mary. I pray that You will keep her and her offspring safe from Satan, the condemned one."

# 330

Her Lord graciously accepted the offer and made Mary grow up, pure, and beautiful. Zachariah took custody of her. Whenever he went to visit her in her place of worship, he would find with her some food. He would ask her, "Where did this food come from?" She would reply, "God has sent it." God gives sustenance to whomever He wants without keeping an account.

# 331

Zachariah prayed to his Lord there, saying, "Lord, grant me, by Your Grace, virtuous offspring. You hear all prayers".

# 332

When he was standing during prayer in his place of worship, the angels called him saying, "God gives you the glad news of the birth of your son, John who will be a confirmation of (Jesus) the Word of God. He will become a chaste, noble leader and one of the righteous Prophets.

# 333

He said, "How can there be a son for me when I am already senile and my wife is barren." The angel replied, "God does as He wills."

# 334

Zachariah prayed to God saying, "Lord, show me the evidence (that it is Divine revelation)." The Lord replied, "You must not speak to people for three days except with gestures. Commemorate your Lord often and glorify Him in the early mornings and the evenings."

# 335

"Behold," the angels told Mary, "God had chosen you, purified you, and given you distinction over all women.

# 336

Mary, pray devotedly to your Lord, prostrate yourself before Him and bow down with those who bow down before Him."

# 337

(Muhammad), that was some of the news about the unseen, that We have revealed to you. You were not among those who cast lots by throwing their arrows to find out who would take custody of Mary, nor were you among those who disputed the matter.

# 338

"Behold," the angels told Mary, "God has given you the glad news of the coming birth of a son whom He calls His Word, whose name will be Messiah, Jesus, son of Mary, who will be a man of honor in this life and the life to come, and who will be one of the ones nearest to God.

# 339

He will speak to the people while in his cradle and preach to them when he will be a man. He will be one of the righteous ones.

# 340

(Mary) said, "How can there be a son for me when no mortal has touched me?" The angel replied, "That is how God creates whatever He wants. When He decides to do something He just orders it to exist and it comes into existence."

# 341

God will give (Jesus) wisdom and teach him the Book, the Torah, and the Gospel.

# 342

He will be a Messenger of God to the Israelites to whom he will say, "I have brought you a miracle from your Lord. I can create for you something from clay in the form of a bird. When I blow into it, it will become a real bird, by the permission of God. I can heal the blind and the lepers and bring the dead back to life, by the permission of God. I can tell you about what you eat and what you store in your homes. This is a miracle for you if you want to have faith.

# 343

"I testify to what is true in the Torah and make lawful for you some of the things that were made unlawful. I have brought you a miracle from your Lord. Have fear of God and obey me.

# 344

God is my Lord as well as yours. Worship Him for this is the right path."

# 345

When Jesus found them denying the truth, he said, "Who will help me in the cause of God?" The disciples replied, "We are the helpers of God. We believe in Him. Jesus, bear witness that we have submitted ourselves to His will."

# 346

They prayed, "Lord, we have believed in what You have revealed to Your Messenger and we have followed him. Write down our names with those who testify in support of the Truth."

# 347

The unbelievers plotted and God planned, but God is a much better planner;

# 348

He told Jesus, "I will save you from your enemies, raise you to Myself, keep you clean from the association with the disbelievers, and give superiority to your followers over the unbelievers until the Day of Judgment. On that day you will all return to Me and I shall resolve your dispute.

# 349

I shall sternly punish the unbelievers in this life and in the life to come and no one will help them.

# 350

However, to the righteously striving believers I shall give their reward in full measure." God does not love the unjust.

# 351

(Muhammad), what we recite to you are revelations and words of wisdom.

# 352

To God the case of Jesus is as that of Adam whom He created from the earth and then said, "Exist," and Adam came into existence.

# 353

(Muhammad, the essence of) the Truth is from your Lord. Never have any doubt about it.

# 354

If anyone disputes (your prophesy) after knowledge has come to you, say, "Let each of us bring our children, women, our people, and ourselves to one place and pray to God to condemn the liars among us."

# 355

This is the true story (of Jesus). There is no Lord but God. It is God who is Majestic and All-wise.

# 356

If they turn away (from the Truth, let it be known that) God knows well the evil-doers.

# 357

(Muhammad), say to the People of the Book, "We must come to a common term. Let us worship no one except God, nor consider anything equal to Him, nor regard any of us as our Lord besides God." However, if they turn away from (the Truth), tell them, "Bear witness that we have submitted ourselves to the will of God."

# 358

Ask the People of the Book, "Why do you argue about Abraham? The Torah and Gospel were revealed only after him. Why do you not understand?

# 359

You even argue about what is already known to you. What can you learn from arguing about that which you have no knowledge? God knows but you do not know."

# 360

Abraham was not a Jew or a Christian. He was an upright person who had submitted himself to the will of God. Abraham was not a pagan.

# 361

The nearest people to Abraham, among mankind, are those who followed him, this Prophet (Muhammad) and the true believers. God is the Guardian of the true believers.

# 362

A group among the People of the Book would love to mislead you but they mislead no one but themselves. However, they do not realize it.

# 363

(Muhammad), say, "People of the Book, why do you deny the revelation of God (the Quran) even though you know very well that it is from God?.

# 364

Why do you mix truth with falsehood and knowingly hide the truth?"

# 365

Some of the People of the Book say, "Believe in what is revealed to the Muslims during the day only and abandon it in the evening. This will perhaps make them give up their religion".

# 366

They also say, "Do not believe anyone except those who follow your religion, so that no one may have what you have received or may argue with you before your Lord." (Muhammad), tell them, "The only guidance is the guidance of God. All favors are in the hands of God. He grants His favors to whomever He wants. He is Munificent and All-knowing".

# 367

God grants priority in granting mercy to whomever He wants. God's favors are great.

# 368

If you entrust some of the People of the Book, with a large quantity of gold, they will return it to you while if you entrust others among them with a small quantity of gold, they will not give it back to you unless you keep insisting on its return. For they say, "We are not bound to keep our words with the illiterate people," and they themselves knowingly ascribe false statements to God.

# 369

Those who keep their promise and observe piety should know that God certainly loves the pious ones.

# 370

Those who sell their covenant with God and their promises for a small price will have no share in the life hereafter. God will not speak to them nor will He look at them on the Day of Judgment nor will He purify them. They will face a painful torment.

# 371

A group among the People of the Book when reading the Bible, deliberately mispronounce words in order to change their meaning, try to show that what they have read is from the true Bible. In fact, what they have read is not from the true Bible. They say, "What we read is from God." In reality, it is not from God. They knowingly ascribe false statements to God.

# 372

God would never give the Book, authority, or prophesy to any person who would tell others to be his servants instead of being the servants of God. He would rather tell them to worship God for they had been teaching and studying the Book.

# 373

A Prophet would never order you to take the angels and the Prophets as your Lords. Would he order you to disbelieve after you have submitted yourselves to God?

# 374

When God made a covenant with the Prophets, saying, "When I give you the Book and wisdom and a Messenger comes to you who will testify to the guidance which you have received from Me, you must believe in him and help him, then He asked them, "Do you affirm and accept my covenant?" They replied, "Yes, we affirm it." The Lord said, "Then bear witness to this and I shall bear witness with you".

# 375

After this, whoever turns away will be of the evil-doers.

# 376

Do they want a religion other than the religion of God when all that is in the heavens and the earth have submitted themselves to His will, either by their own free will or by force? To God do all things return.

# 377

(Muhammad), say, "We believe in God and in that which has been revealed to us and in that which was revealed to Abraham, Ishmael, Isaac, Jacob, and their descendants. We believe in that which was given to Moses, Jesus, and the Prophets by their Lord. We make no distinction between them and we have submitted ourselves to the will of God".

# 378

No religion other than Islam (submission to the will of God) will be accepted from anyone. Whoever follows a religion other than Islam will be lost on the Day of Judgment.

# 379

Why would God guide a people who disbelieves after having had faith, who have found the Messenger to be truthful, and who have received authoritative evidence? God does not guide the unjust.

# 380

What they will gain will be the condemnation of God, the angels, and all people,

# 381

with which they will live forever. Their torment will not be relieved and no attention will be paid to them.

# 382

However, to those who repent afterwards and reform themselves, God is All-forgiving and All-merciful.

# 383

Those who disbelieve, after having been believers and increase their disbelief, are lost and their repentance will not be accepted.

# 384

From those who have rejected the truth and died in disbelief, no ransom will be accepted even though they may pay a whole earth of gold. They will suffer a painful torment and no one will help them.

# 385

You can never have extended virtue and righteousness unless you spend part of what you dearly love for the cause of God. God knows very well whatever you spend for His cause.

# 386

All food was lawful for the children of Israel except for what Israel had deemed unlawful for himself before the Torah was revealed. (Muhammad), ask them to bring the Torah and read it, if they are true in their claim (that all food was not unlawful for the children of Israel).

# 387

Whoever ascribes falsehood to God despite of all the evidence is unjust.

# 388

(Muhammad), say, "God has spoken the Truth. Follow the upright tradition of Abraham who was not an idolater."

# 389

The first house (of worship) that God assigned to men was in Bakka (another name of Mecca). It is a blessed one and a guide for all people.

# 390

In (Bakka), there are many clear signs (evidence of the existence of God). Among them is the spot where Abraham stood. Whoever seeks refuge therein will be protected by the laws of amnesty. Those who have the means and ability have a duty to God to visit the House and perform the hajj (pilgrimage) rituals. The unbelievers should know that God is Independent of all creatures.

# 391

(Muhammad), ask the People of the Book, "Why do you deny the revelations of God when He is Well-Aware of your dealings?".

# 392

Ask them, "Why do you create obstacles in the way of God for those who believe in Him, trying to make His way seem crooked when you know that it is straight? God is not unaware of what you do.

# 393

Believers, if you obey a certain group among the People of the Book, they will turn you back to disbelief.

# 394

How could you turn back to disbelief when the words of God are recited to you and you have in your midst His Messenger? Those who seek the protection of God will certainly be guided to the right path.

# 395

Believers, have fear of God as you should and die only as Muslims (having submitted to the will of God).

# 396

All of you united hold fast to the rope of God (the Quran and His Messenger), and recall how He favored you when your hostility to each other had torn you apart. He united your hearts in one faith and through His Grace you became brothers. You were on the verge of falling headlong into the abyss of fire, but God saved you. This is how God explains to you His revelations so that you may have the right guidance.

# 397

Let there be a group among you who will invite others to do good deeds, command them to obey the Law, and prohibit them from committing sins. These people will have eternal happiness.

# 398

Do not be like those who turned into quarrelling sects after receiving clear authoritative evidence. They will suffer a great torment.

# 399

On the day when some faces will become white and others black, God will ask the people with the faces which have become black, "Why did you give up your faith? Now suffer the torment for your disbelief".

# 400

The people whose faces have become white will enjoy the mercy of God with which they will live forever.

# 401

Such are God's revelations which We explain to you, (Muhammad), for a genuine purpose. God does not want injustice for any of His creatures.

# 402

To God belongs all that is in the heavens and the earth and to Him do all things return.

# 403

You are the best nation that ever existed among humanity. You command people to good and prohibit them from evil, and you believe in God. Had the People of the Book accepted the faith (Islam), it would certainly have been better for them. Some of them have faith, but most of them are evil doers.

# 404

They can never harm you beyond annoyance. In a fight, they will turn back in defeat and they will not be helped.

# 405

Humiliation will strike them wherever they seek protection, except when they seek protection from God and the people. They have incurred the wrath of God unto themselves and have been struck with destitution for their rejection of the revelations of God and for unjustly murdering the Prophets. It is all because of their transgression and rebellion.

# 406

The People of the Book are not all the same. Some of them are straightforward. They recite the words of God in prostration at night.

# 407

They believe in God and the Day of Judgment. They command people to follow good, prohibit others from committing evil and compete with each other in doing good deeds. These are the righteous ones.

# 408

They will never be denied the rewards of their good deeds. God knows well about the pious.

# 409

The wealth and the children of the unbelievers can never make them independent of God. They are the dwellers of hell wherein they will live forever.

# 410

What they spend in this life is like the freezing wind that may strike and destroy the farms of the people who have wronged themselves. God has not done injustice to them, but they have wronged themselves.

# 411

Believers, do not expose your privacy to the unbelievers. They like to mislead you and see that you are seriously harmed. Signs of animosity from their mouths have already become audible, but what they hide in their heads is even worse. We have certainly made Our evidence clear, if only you would consider it.

# 412

There are people whom you love, but they do not love you, despite your belief in all the (heavenly) Books. On meeting you They proclaim belief on meeting you, but in private, bite their fingers at you in anger. Tell them, "Perish in your rage! God knows well what is in everyone's hearts".

# 413

They hate to see your success and rejoice if any misfortune befalls you. If you will be patient and pious, their plots can cause no harm to you. God has control over all their actions.

# 414

(Muhammad), remember the morning when you left home to show the believers their position in the battle? God is All-hearing and All-knowing.

# 415

Two groups among you almost lost courage despite having God as their Guardian. The believers should always have trust in God.

# 416

God gave you victory in the battle of Badr where your forces were much weaker than those of the enemy. Have fear of God so that you may give Him thanks.

# 417

Also, remember when you said to the believers, "Is it not enough that your Lord is helping you with a force of three thousand angels sent (from the heavens)?"

# 418

Certainly, if you have patience and piety, even if the enemy attacks immediately after this, God will help you with another force of five thousand angels, all splendidly (and or distinctly marked) dressed.

# 419

The sending of the angels is a glad news from your Lord so that you would have more confidence in Him. No victory is real unless it is from God, the Majestic and All-wise.

# 420

(They are sent) to break the power of the unbelievers or disgrace them and make them return after having lost all hope."

# 421

(Muhammad), it is not your concern whether He forgives them or punishes them for they are unjust.

# 422

To God belongs all that is in the heavens and the earth. He may forgive or punish whomever He wants. God is All-forgiving and All-merciful.

# 423

Believers, do not accept illegal interest in order to increase your wealth many times over. Have fear of God so that you will have everlasting happiness.

# 424

Save yourselves from the fire which is prepared for the unbelievers.

# 425

Obey God and the Messenger so that you may receive mercy.

# 426

Hasten to obtain forgiveness from your Lord and to qualify yourselves for Paradise. Paradise, vast as the heavens and the earth, is prepared for the pious

# 427

who spend their property for the cause of God in prosperity as well as in adversity and who also harness their anger and forgive the people. God loves the righteous ones.

# 428

(Paradise) is also for those who, when committing a sin or doing injustice to themselves, remember God and ask Him to forgive their sins. Who can forgive sins besides God? And who do not knowingly persist in their mistakes?

# 429

Their reward will be forgiveness from their Lord and gardens wherein streams flow and wherein they will live forever. How blessed is the reward of those who labor.

# 430

Different traditions existed in the past. Travel in the land and find out about the fate of those who rejected the Truth.

# 431

This (Quran) is a reminder for the people and a guide and advice for the pious.

# 432

Do not be discouraged or grieved. You alone will have true dignity if you only are true believers.

# 433

If you get hurt, certainly others have also experienced injuries. We have made people pass through the different turns of history so that God would know the true believers, have some of you bear witness to the people's deeds, {God does not love the unjust}

# 434

test the faith of the believers, and deprive the unbelievers of (His) blessings.

# 435

Did you think that you could go to Paradise before God knew which of you fought for His cause and which of you bore patience?

# 436

You certainly wished to die (for the cause of God) before you actually faced death. Then you faced death (in the battlefield and only a few of you had the true desire to die).

# 437

Muhammad is only a Messenger. There lived other Messengers before him. Should (Muhammad) die or be slain, would you then turn back to your pre-Islamic behavior? Whoever does so can cause no harm to God. God will reward those who give thanks.

# 438

No one can die without the permission of God. This is a written decree of the appointed term for life. We shall give worldly gains to whoever wants them. Those who want rewards in the life hereafter will also receive them. We reward those who give thanks.

# 439

Many godly people fought to help the Prophets in the cause of God. They did not lose courage, show weakness, or give in when facing hardships in their fight for the cause of God. God loves those who have patience.

# 440

The only words that they spoke were, "Lord, forgive our sins and our excess in our dealings, make us steadfast (in the fight for Your cause), and grant us victory over the unbelievers."

# 441

God gave them their reward in this world and the best reward of the life to come. God loves the righteous ones.

# 442

Believers, if you obey the unbelievers, they will turn you back to disbelief and you will become lost.

# 443

God is your Guardian and the best Helper.

# 444

We shall cause terror to enter the hearts of the faithless for their considering things equal to God without authoritative evidence. Their abode will be fire, a terrible dwelling for the unjust.

# 445

God certainly fulfilled His promise to you when you were fighting the unbelievers, by His permission. Even after We showed you what you wanted, you began to lose courage, started quarreling with each other, and disobeyed God's orders. Some of you want worldly gains and others of you want rewards in the hereafter. Then He let you face defeat in order to test you. However, He forgave you. God is Gracious to the believers.

# 446

(Believers remember) when you were fleeing without even glancing to either side even though the Messengers were calling you back, God made you suffer sorrow upon sorrow to make you forget your grief of what you had lost and the injuries you had suffered. God is Well-Aware of what you do.

# 447

After the sorrows you suffered, He sent you relief and some of you were encompassed by slumber. To some others of you, your lives were so important that you, like ignorant people, began thinking suspiciously of God saying, "Do we have any say in the matter?" (Muhammad), tell them, "All matters belong to God." They try to hide within their souls what they do not reveal to you. They say, "Had we had the matter in our hands, we would not have been killed there." Tell them, "Even if you had stayed in your own homes, your sworn enemies could have attacked you and slain you while you were in your beds. God wanted to test you and purge what existed in your hearts.

# 448

God knows what the hearts contain. Because of some of your bad deeds, those of you who ran away, when you faced the enemy, were misled by Satan. God forgave you for He is All-forgiving and Forbearing."

# 449

Believers, do not be like the unbelievers, who said of their brothers who travelled in the land or took part in a fight, "Had they stayed with us, they would not have died or been killed." God will only cause regret to enter their hearts. It is God who gives life and causes people to die. God is Well Aware of what you do.

# 450

If you were to die or to be killed for the cause of God, certainly His forgiveness and mercy is far better than your worldly gains.

# 451

If you die or are slain, certainly you will all be brought before God.

# 452

Only through the Divine Mercy have you (Muhammad) been able to deal with your followers so gently. If you had been stern and hard-hearted, they would all have deserted you a long time ago. Forgive them and ask God to forgive (their sins) and consult with them in certain matters. But, when you reach a decision, trust God. God loves those who trust Him.

# 453

If God is your helper, no one can defeat you. However, if He abandons you, who would help you? The true believers trust in God.

# 454

No Prophet can ever be treacherous. A treacherous person will be brought before God on the Day of Judgment with his treacherous deeds. Then every soul will be recompensed for its works without being wronged.

# 455

Are those who seek God's pleasure equal to those who incur His wrath and whose dwelling will be hell, the terrible destination?

# 456

People are of various grades in the sight of God. God is Well-Aware of all that they do.

# 457

God granted a great favor to the believers by sending a Messenger from their own people to recite to them God's revelations, to purify them of moral defects, to teach them the Book, and to give them wisdom. Before this they had lived in manifest error.

# 458

If misfortune befell you (the believers) your enemies had suffered twice as much (in the battle of Badr) but you asked, "Where did the misfortune come from?" (Muhammad), tell them, "It came from yourselves. God has power over all things.

# 459

What befell you, when the two armies confronted each other, was by the permission of God so that He would know who were the true believers

# 460

and who were the hypocrites. When the hypocrites were asked to fight for the cause of God or to defend the city, they replied, "Had we known before that you would fight, we would certainly not have followed you." At that time they were closer to disbelief than to faith. They speak words that do not come from their hearts. God knows well whatever they try to hide.

# 461

There are those who themselves did not join the others in fighting for the cause of God and said about their brothers, "Had they listened to us and stayed at home, they would not have been killed." (Muhammad), tell them to save themselves from death if they are true in their claim.

# 462

Do not think of those slain for the cause of God as dead. They are alive with their Lord and receive sustenance from Him.

# 463

They are pleased with the favor from their Lord and have received the glad news that those who follow them will have no fear nor will they be grieved,

# 464

that they will be rewarded with bounties and favors from their Lord and that God will not neglect the reward of the true believers.

# 465

The righteous and pious of those who have pledged obedience to God and the Messenger, after injury had befallen them, will receive a great reward.

# 466

Such people, when warned to fear those who are gathered against them, are strengthened in their faith and say, "God is All-sufficient as our Guardian."

# 467

They returned with the favors and the bounties of God untouched by evil and followed by the pleasure of God. God's favor is great.

# 468

It is Satan who frightens his friends. Do not be afraid of them (enemies) but have fear of Me if you truly believe.

# 469

(Muhammad), do not be grieved because of some people's haste to disbelieve. They can do no harm to God. God has decided not to give them any share in the life hereafter. There will be a great torment for them.

# 470

Those who have traded faith in exchange for disbelief can never do any harm to God. There will be a painful torment for them.

# 471

The unbelievers must not think that Our respite is for their good. We only give them time to let them increase their sins. For them there will be a humiliating torment.

# 472

God left the believers in their existing state for no other reason than to distinguish the evil-doers from the virtuous ones. God does not inform you of the unseen. He chooses for such information anyone of His Messengers that He wants. Have faith in God and in His Messengers. If you have faith and are pious, there will be a great reward for you.

# 473

Those who are avaricious of the favors that God has given them should not think that this is good for them. Avarice is evil and whatever they are avaricious about will be tied to their necks on the Day of Judgment. To God belongs the heritage of the heavens and the earth. God is Well Aware of what you do.

# 474

God certainly has heard the words of those who said, "God is poor and we are wealthy". We shall write down what they have said and their murder of the Prophets without reason and We shall tell them to suffer the burning torment.

# 475

This is only the result of their deeds. God is not unjust to His servants.

# 476

(Muhammad), say to those who say, 'God has commanded us not to believe any Messenger unless he offers a burnt offering,' (Muhammad) say, "Messengers came to you before me with certain miracles and with that which you had asked for (burnt offering). Why, then, did you slay them if you were true in your claim?"

# 477

If they reject you, they had certainly rejected the Messengers who lived before you and who showed them authoritative evidence, smaller Books, and the Book of enlightenment.

# 478

Every soul is destined to experience the agony of death. You (Muslims) will receive the recompense for your deeds on the Day of Judgment. To be saved from the fire and admitted to Paradise is certainly a great triumph. The worldly life is no more than a deceitful possession.

# 479

You (believers) will certainly be tested by the loss of your property and lives and you will hear a great many grieving words from the People of the Book and the pagans. If you will have patience and piety, it will be a sign of firm determination and steadfastness (in life).

# 480

When God made a covenant with the People of the Book saying, "Tell the people about it (Muhammad's prophesy) without hiding any part, therefrom, they threw it behind their backs and sold it for a very small price. What a miserable bargain!

# 481

Do not think that those who are happy with their possessions and positions and those who love to be praised for what they themselves have not done can ever be saved from torment. For them there will be a painful punishment.

# 482

To God belongs all that is in the heavens and the earth and He has power over all things.

# 483

The creation of the heavens and the earth and the alternation of the day and the night are evidence (of the existence of God) for people of reason.

# 484

It is these who commemorate God while standing, sitting, or resting on their sides and who think about the creation of the heavens and the earth and say, "Lord, you have not created all this without reason. Glory be to you. Lord, save us from the torment of the fire".

# 485

Those whom You submit to the fire are certainly disgraced. There is no helper for the unjust.

# 486

"Lord, we have heard the person calling to the faith and have accepted his call. Forgive our sins, expiate our bad deeds, and let us die with the righteous ones.

# 487

Lord, grant us the victory that You have promised your Messenger and do not disgrace us on the Day of Judgment; You are the One who never ignores His promise."

# 488

Their Lord answered their prayers saying, "I do not neglect anyone's labor whether the laborer be male or female. You are all related to one another. Those who migrated from Mecca, those who were expelled from their homes, those who were tortured for My cause, and those who fought and were killed for My cause will find their sins expiated by Me and I will admit them into the gardens wherein streams flow. It will be their reward from God Who grants the best rewards."

# 489

(Muhammad), do not be deceived by the changing activities of the unbelievers in different parts of the land.

# 490

Their gains are only a means of enjoyment in this life. However, their destination is hell, the terrible dwelling.

# 491

For those who have fear of their Lord, there will be gardens wherein streams flow and they will live therein forever as a gift from their Lord. God has the best reward for the virtuous people.

# 492

There are some among the People of the Book who believe in God and what is revealed to you and to them. They are humble before God and do not trade God's revelations for a small price. They will receive their reward from their Lord. God's reckoning is swift.

# 493

Believers, have patience, help each other with patience, establish good relations with one another, and have fear of God so that you may have everlasting happiness.

# 494

People, have fear of your Lord who has created you from a single soul. From it He created your spouse and through them He populated the land with many men and women. Have fear of the One by whose Name you swear to settle your differences and have respect for your relatives. God certainly keeps watch over you.

# 495

Give to the orphans their property. Do not exchange the pure for the filthy and do not spend the property of orphans along with your own; this would be a great sin.

# 496

With respect to marrying widows, if you are afraid of not being able to maintain justice with her children, marry another woman of your choice or two or three or four (who have no children). If you cannot maintain equality with more than one wife, marry only one or your slave-girl. This keeps you from acting against justice.

# 497

Pay the women their dowry as though it were a gift. However, if they allow you to keep a part of it as a favor to you, you may spend it with pleasure.

# 498

Do not give to people weak of understanding your property for which God has made you to supervise. Feed and clothe such people and speak to them in a reasonable way.

# 499

Before returning orphan's property to them, make sure that they have reached maturity. Do not consume their property wastefully until such a time. The rich (guardian) should not take any of his ward's property. However, a poor (guardian) may use a reasonable portion. When you return their property, make sure you have witness. God is a perfect in taking accounts.

# 500

Male and female are entitled to their legal share in the legacy of their parents and relatives, whether it be small or large.

# 501

If relatives, orphans or destitute people, are present at the distribution of the legacy, give them something and speak kindly to them.

# 502

Those who are concerned about the welfare of their own children after their death, should have fear of God (when dealing with the orphans) and guide them properly.

# 503

Those who wrongfully consume the property of orphans are, in fact, consuming fire in their bellies and they will suffer the blazing fire.

# 504

This is a commandment from your Lord: After the payment of debts or anything bequeathed, let the male inherit twice as much as the female. If there are more than two girls, they will have two-thirds of the legacy. If there is only one girl, she will inherit half of the legacy. Parents of the deceased will each inherit one-sixth of the legacy, if the deceased has a surviving child, however, if no children survive the deceased, and the heirs are the parents, the mother will receive one-third of the legacy. The mother will receive one-sixth of the legacy if the deceased has more than one surviving brother. These are the decreed shares according to the laws of God. Regardless of how you feel about your parents or children, you do not know which of them is more beneficial to you. God is All-knowing and All-wise.

# 505

If your wives die without any surviving children, you will inherit half of their legacy. If they have children, you will inherit one-fourth of their legacy after the debts and things bequeathed have been excluded from the legacy. After the payment of debts and things bequeathed have been excluded from the legacy, your wives will inherit one-fourth of your legacy if you have no surviving children. If you leave a child, they will inherit one eighth of your legacy. If the deceased, either male or female, has no surviving heirs such as parents or children but has a brother or a sister, the brother or sister will each inherit one-sixth of the legacy. If there are more than just a brother or a sister, they will share one-third of the legacy. This is after the payment of any debts and things bequeathed have been excluded from the legacy, so that no one will be caused to suffer any loss. It is a guide from God, the All-knowing and Forbearing.

# 506

These are the laws of God. Whoever obeys God and His Messenger will be admitted to the gardens wherein streams flow and wherein they will live forever. This is the greatest triumph.

# 507

Whoever disobeys God and His Messenger and breaks His rules will be admitted to the fire wherein they will live forever, suffering a humiliating torment.

# 508

Those of your women who commit fornication, let four (Muslim) witness testify to their act. If there is sufficient testimony, confine them to their homes until they die, or until God provides a way for their freedom.

# 509

If any two people commit fornication, punish them. If they repent and reform, let them go. God is All-forgiving and All-merciful.

# 510

God will only accept the repentance of those who commit evil in ignorance, if they repent immediately. God is All-knowing and All-wise.

# 511

There is no forgiveness for those who commit sin and do not repent until the last moment of their lives nor for those who die as unbelievers. For these people We have prepared a painful torment.

# 512

Believers, it is not lawful for you to inherit women against their will as part of the legacy. Do not create difficulties for your wives in order to force them to give-up part of what you had given to them to set themselves free from the bond of marriage, unless they have clearly committed adultery. Always treat them reasonably. If you dislike them, you could be disliking that which God has filled with abundant good.

# 513

If you want to divorce a woman so that you can marry another, do not take back the dowry which you had paid even if what you paid was a large amount of gold. To do this is a slanderous act and a manifest sin.

# 514

How can you take it back when you have had intimate relations and made a solemn agreement with each other?

# 515

Do not marry, from now on, the ex-wives of your fathers for that custom was sinful, loathsome, and abominable.

# 516

You are forbidden to marry your mothers, daughters, sisters, paternal aunts, maternal aunts, nieces, your foster-mothers, your foster-sisters, your mothers-in-law, your step-daughters whom you have brought up and with whose mothers you have had carnal relations. It would not be a sin to marry her if you did not have carnal relations with her mother. You are forbidden to marry the wives of your own sons and to marry two sisters at the same time without any adverse affect to the such relations of the past. God is All-forgiving and All-merciful.

# 517

You are forbidden to marry married women except your slave-girls. This is the decree of God. Besides these, it is lawful for you to marry other women if you pay their dower, maintain chastity and do not commit indecency. If you marry them for the appointed time you must pay their dowries. There is no harm if you reach an understanding among yourselves about the dowry, God is All-knowing and All-wise.

# 518

If any of you do not have the means to marry a chaste believing woman, marry your believing slave-girls. God knows best about your faith. You have the same faith. Marry them with the permission of their masters and if they are chaste and have avoided fornication and amorous activities, give them their just dowries. If after marriage they commit adultery, they should receive half of the punishment of a free woman who has committed the same crime. This is for those who fear falling into evil. It is better for you to have self-control. God is All-forgiving and All-merciful.

# 519

God wants to guide you, explain to you the customs of those who lived before you, and grant you forgiveness. He is All-knowing and All-wise.

# 520

God wants to be merciful to you but those who follow their evil desires seek to lead you astray.

# 521

God wants to relieve you of your burden; all human beings were created weak.

# 522

Believers, do not exchange your property in wrongful ways unless it is in trade by mutual agreement. Do not kill one another. God is All-merciful to you.

# 523

Whoever commits murder out of animosity and injustice will be burnt in hell fire. This is a very easy thing for God to do.

# 524

If you avoid violating that which has been prohibited, your (lesser) sins will be forgiven and you will be admitted into an exalted dwelling.

# 525

Do not envy the favors which God has granted to some of you. Men and women will both be rewarded according to their deeds, rather pray to God for His favors. God knows all things.

# 526

We have chosen heirs for every legacy that parents and relatives may leave. Let those who have been promised a bequest receive their share of the legacy. God is Omnipresent.

# 527

Men are the protectors of women because of the greater preference that God has given to some of them and because they financially support them. Among virtuous women are those who are steadfast in prayer and dependable in keeping the secrets that God has protected. Admonish women who disobey (God's laws), do not sleep with them and beat them. If they obey (the laws of God), do not try to find fault in them. God is High and Supreme.

# 528

If there appears to be discord between a wife and her husband and if they desire reconciliation choose arbiters from the families of both sides. God will bring them together; God is All-knowing and All-aware.

# 529

Worship God and consider no one equal to Him. Be kind to your parents, relatives, orphans, the destitute, your near and distant neighbors, your companions, wayfarers, and your slaves. God does not love the proud and boastful ones,

# 530

the stingy ones who try to make others stingy or those who hide the favors that God has bestowed on them. We have prepared a humiliating torment for the disbelievers,

# 531

those who spend their property out of a desire to show off and not because of their belief in God and the Day of Judgment, and (lastly) those who choose Satan for a friend; what an evil friend!

# 532

How could it have harmed them if they had believed in God and the Last Day and spent their property for the cause of God? God knows them very well

# 533

God does not do even an atom's weight of injustice. A good deed is multiplied by God and richly rewarded.

# 534

How will it be when We call for a witness from every nation and have you, (Muhammad), testify against them all?

# 535

At that time the disbelievers who disobeyed the Messenger will wish that they could be turned into dust and they will be able to hide nothing from God.

# 536

Believers, do not pray when you are drunk, but, instead, wait until you can understand what you say. Also, do not pray when you have experienced a seminal discharge until after you have taken a bath, unless you are on a journey. If, while sick or on a journey, you can find no water after having defecated or after having had carnal relations, perform tayammum by touching your palms on the pure earth and wipe the (upper part of) your face and the backs of your hands. God is Gracious and All-forgiving.

# 537

Have you seen those who had received a portion of the Book trade misguidance and try to make you, too, go astray?

# 538

God knows who are your enemies. You need to have no guardian or helper other than God.

# 539

Some Jews take certain words out of context and by twisting their tongues to make a jest out of the true religion, say, "We heard and (in our hearts) disobeyed. (Muhammad) ra\`ina (be kind to us) but they intend thereby (the meaning in their own language): "Listen! May God turn you deaf." They should have said, "We heard and obeyed. (Muhammad) listen and consider our question." This would have been better for them and more righteous. God has condemned them for their disbelief, thus, no one, except a few among them, will have faith.

# 540

People of the Book, have faith in the Quran that We have revealed to confirm your Book, before certain faces are changed and turned back. We shall condemn them as We did the people of the Sabbath about whom God's decree had decisively been ordained.

# 541

God does not forgive the sin of considering others equal to Him, but He may choose to forgive other sins. Whoever believes in other gods besides Him has indulged in a great sin.

# 542

(Muhammad), have you seen those who try to purify themselves? They should know that God only purifies whomever He wants and that the slightest wrong will not be done to such people.

# 543

Consider how they create lies about God? This alone is a grave sin.

# 544

Have you seen how those who had been given a share of the Book believe in idols and Satan and who say, "The disbelievers are better guided than the believers".

# 545

God has condemned them. No one can help one who has been condemned by God.

# 546

Even if they had a share in the Kingdom (Divine authority), they would not have given the smallest thing to anyone.

# 547

Are they jealous of the favors that God has done to some people? We have given to the family of Abraham the Book, Wisdom, and a great Kingdom.

# 548

Some have believed, others have disbelieved and tried to prevent people from believing. For these people, only the intense fire of hell is a sufficient punishment.

# 549

We will make the rejectors of Our revelations suffer in hell fire. As soon as the fire destroys their skins, We will give them new skins so that they may suffer more of the torment. God is Majestic and All-wise.

# 550

We will admit the righteously striving believers into the gardens wherein streams flow. They will live therein forever in a cool shade with their pure spouses.

# 551

God commands you to return that which had been entrusted to you to the rightful owners. Be just when passing judgment among people. God's advice is the most noble. He sees and hears everything.

# 552

Believers, obey God, His Messenger, and your (qualified) leaders. If you have faith in God and the Day of Judgment, refer to God and His Messenger concerning matters in which you differ. This would be a more virtuous and a better way of settling differences.

# 553

(Muhammad), have you seen those who think that they have faith in what is revealed to you and to others before you, yet choose to take their affairs to Satan for judgment even though they are commanded to deny him. Satan wants to lead them far away from the right path.

# 554

When the (hypocrites) are told to refer to God's revelations and to the Messenger, they try to find excuses to stay away from you (Muhammad).

# 555

What would happen if they were to be afflicted by a disaster brought about by their own hands? They would then come to you swearing by God, "We only wanted to bring about friendship and reconciliation."

# 556

God knows what is in their hearts. (Muhammad), ignore their faults, advise them, and tell them frankly about what is in their souls.

# 557

We did not send any Messengers for any reason other than to be obeyed because of the will of God. If they ever do injustice to themselves and come to you (Muhammad) asking for God's forgiveness and if the Messenger also was to ask God to forgive them, they would certainly find God All-forgiving and All-merciful.

# 558

I swear by your Lord that they will not be considered believers until they let you judge their disputes and then they will find nothing in their souls to prevent them from accepting your judgment, thus, submitting themselves to the will of God.

# 559

Had We commanded them to kill themselves or abandon their homes, only a few of them would have done it. If they had done what they had been advised to do, it would have strengthened their faith,

# 560

We would have given them a great reward

# 561

and guided them to the right path.

# 562

One who obeys God and the Messenger is the friend of the Prophets, saints, martyrs, and the righteous ones to whom God has granted His favors. They are the best friends that one can have.

# 563

The favors of God are such, and He knows very well (how to reward you).

# 564

Believers, always be well prepared and on your guard. March in small groups or all together.

# 565

There are some among you who lag behind (in battle) and if you were to experience hardship, they would say, "It was certainly due to God's favors to us that we were not present with them,"

# 566

but if you were to receive a favor from God, they would certainly say, "(We have been ignored) as if there was no friendship among us. Would that we had been there with them for we would have had a great success."

# 567

Those who want to buy the life hereafter with this life should fight for the cause of God. We will give them a great reward whether they are killed or whether they are victorious.

# 568

Why do you not fight for the cause of God or save the helpless men, women, and children who cry out, "Lord, set us free from this town of wrong doers and send us a guardian and a helper?"

# 569

The believers fight for the cause of God. The unbelievers fight for the cause of the Satan. So fight against the friends of Satan for the evil plans of Satan are certainly weak.

# 570

Have you not seen those who were told to stop fighting, to say their prayers, and pay the religious tax? When they were ordered to fight, some of them feared other men as much as or more than they feared God and so they said, "Lord, why have you ordered us to fight? If only you would give us a little time." (Muhammad), tell them, "The pleasures of the worldly life are trivial. The life hereafter is best for the pious ones. You will not be treated the slightest bit unjustly.

# 571

Wherever you are, death will find you even if you hide yourselves in firmly constructed towers. Whenever people experience good fortune, they say that it is from God but whenever they experience misfortune, they say it is because of you, (Muhammad). Tell them, "Everything is from God." What is wrong with these people that they do not even try to understand?

# 572

Whatever good you may receive is certainly from God and whatever you suffer is from yourselves. We have sent you, (Muhammad), as a Messenger to people. God is a Sufficient witness to your truthfulness.

# 573

One who obeys the Messenger has certainly obeyed God. You have not been sent to watch over those who turn away from you.

# 574

They proclaim obedience to you but as soon as they leave at night, a group of them make secret plans to do the contrary of what you have told them to do. God keeps the record of their nocturnal plans. Therefore, leave them alone and put your trust in God; He is Sufficient for you as your Guardian.

# 575

Will they not ponder on the Quran? Had it not come from someone other than God, they would have certainly found therein many contradictions.

# 576

When they receive any news of peace or war, they announce it in public. Had they told it to the Messenger or to their (qualified) leaders, they could have used that information more properly. Were it not for the favor and mercy of God, all but a few of them would have followed Satan.

# 577

Thus, (Muhammad), fight for the cause of God. You are only responsible for yourself. Rouse the believers and perhaps God will stop the evil designs of the unbelievers. God's punishment and retribution is the most severe.

# 578

Whoever intercedes for a good purpose will receive his share of the reward but the intercession for an evil purpose only adds more to one's burden. God has control over all things.

# 579

Answer a greeting in kinder words than those said to you in the greeting or at least as kind. God keeps account of all things.

# 580

God exists. He is the only Lord. He will gather you all together on the Day of Judgment which will certainly come. Who is more truthful than God?

# 581

Why are you divided into two different parties concerning the hypocrites, when God Himself has turned them to disbelief because of their misdeeds. Do you want to guide those whom God has caused to go astray? You cannot find guidance for those whom God has made to err.

# 582

They wish you to become unbelievers as they themselves are. Do not establish friendship with them until they have abandoned their homes for the cause of God. If they betray you, seize them and slay them wherever you find them. Do not establish friendship with them or seek their help

# 583

except with those who attach themselves to your allies or come to you with no desire to fight you or their own people. God could have given them power to fight you. Thus, if they retreat, stop fighting and come forward expressing faith in Islam God will not allow you to fight them.

# 584

You will soon find others who seek security from you as well as from their own people, but when they are invited to return to idol worship, they do so enthusiastically. Thus, if they do not keep away from you nor come forward with a peace proposal nor desist from harming you, apprehend and slay them wherever you find them, for We have given you full control over them.

# 585

A believer cannot slay another believer except by mistake for which the retaliation is to set free a believing slave and pay the appointed blood money to the relatives of the deceased unless the relatives wave aside the payment. If the person slain is from your enemies but himself is a believer, the penalty is to set free a believing slave. If the person slain is one of those with whom you have a peace treaty, the penalty is the same as that for a slain believer. If this is not possible, the defendant has to fast for two consecutive months, asking God to accept his repentance. He is All-knowing and All-wise.

# 586

The punishment for one who purposely slays a believer will be to live in hell fire forever. God is angry with him and has condemned him. He has prepared for him a great torment.

# 587

Believers, if you march with arms for the cause of God, make sure that you know whom to fight. Do not accuse anyone who claims himself to be a Muslim of disbelief just for worldly gains. There is abundant bounty with God. Before, you were also like them, but God bestowed His favors upon you. Thus, make sure that you know whom to fight. God is Well Aware of what you do.

# 588

Among the believers, those who stay at home without a good reason are not equal to those who strive for the cause of God in person or with their property. To those who strive for His cause in person or with their property, God has granted a higher rank than to those who stay at home. God has promised that everyone will receive his proper share of the reward but He will grant a much greater reward to those striving for His cause than to those who stay home (for no reason).

# 589

God will grant those who strive high ranks, forgiveness, and mercy. He is All-forgiving and All-merciful.

# 590

When the angels take away from their bodies the souls of those who have wronged themselves, they will ask them, "How did you live?" They will reply, "We lived on earth in weakness and oppression." The angels will say, "Was not God's land vast enough for you to go wherever you could live in peace?" The dwelling of these people will be hell fire, a terrible destination.

# 591

As for the really weak and oppressed men, women, and children who were not able to find any means of obtaining their freedom or of having the right guidance,

# 592

perhaps God will forgive them; He is All-merciful and All-forgiving.

# 593

One who abandons his home for the cause of God will find many places of refuge in the vast land and one who dies, after having abandoned his home to get near to God and His Messenger, will receive his reward from God. God is All-forgiving and All-merciful.

# 594

When you are on a journey, it is no sin to shorten your prayers if you are afraid of the mischief of the unbelievers. The unbelievers have always been your sworn enemies

# 595

(Muhammad), if you are among them (your followers during a battle) and you call them for prayer, let a group of them carry their arms during prayer. After they have made their prostrations, let them go back to watch the enemy and let the other group who has not yet prayed, join you, carrying their arms with due precaution. The unbelievers would love to find you neglecting your arms and property and would attack you suddenly. If rain or illness make you suffer, you may place your arms aside during prayer but still observe due precaution. God has prepared a humiliating torment for the unbelievers.

# 596

When you complete your prayer, remember God all the time while standing, sitting, or reclining. When you are safe, say your prayers properly. It is a constant duty of the believers.

# 597

Do not neglect the pursuit of the enemy. If you have suffered, they too have suffered but you can, at least, expect from God what they can never expect. God is All-knowing and All-wise.

# 598

We have revealed to you the Book in all Truth so that you judge among people by the laws of God. However, never defend the treacherous ones.

# 599

Seek forgiveness from God. He is All-forgiving and All-merciful.

# 600

Do not defend those who deceive themselves; God does not love those who are treacherous and sinful.

# 601

They hide their sins from other people but they cannot hide themselves from God who is constantly with them, even when they hold nocturnal meetings, a thing which God does not like. God comprehends all that they do.

# 602

You defend them in this life but who will defend them against God on the Day of Judgment and who will be their attorney?

# 603

One who commits a sin or does wrong to himself and then seeks forgiveness from God, will find God All-forgiving and All-merciful.

# 604

One who commits sins has committed them against his own soul. God is All-knowing and All-wise.

# 605

One who makes a mistake or commits a sin and ascribes it to an innocent person, he only burdens himself with slander and a grave sin.

# 606

Were it not for the favor and mercy of God, some of them would have certainly tried to make you (Muhammad) go astray. However, they cannot lead any one astray but themselves nor can they harm you. God has revealed the Book to you, has given you wisdom, and has taught you what you did not know. Certainly God's favor to you has been great.

# 607

There is nothing good in much of their secret talks except for that which is for charity, justice, or for reconciliation among people to seek thereby the pleasure of God for which We will give a great reward.

# 608

Whoever gives the Messenger a hard time, even after having received clear guidance, and follows a path other than that of the believers, will be left alone. We will cast him into hell, a terrible destination.

# 609

God will not forgive the sin of considering something equal to Him, but He may forgive the other sins of whomever He wants. One who considers anything equal to God has certainly gone far away from the right path.

# 610

They (the pagans) only worship idols and Satan, the persistent rebel.

# 611

God condemned Satan when he said, "I will certainly take my revenge from Your servants.

# 612

I will lead them astray, induce in their hearts prolonged, worldly desires, command them to pierce the ears of their animals, sacrificed for the idols, and order them to change the religion of God." One who accepts Satan as his guardian, instead of God, has certainly incurred a great loss upon himself.

# 613

Satan gives them false promises and tempts them to develop longings which can never be realized.

# 614

Such people will dwell in hell fire from which they will not be able to escape.

# 615

We will admit the righteously striving believers to Paradise wherein streams flow and they will live therein forever. God's promise is true for no one is more truthful than Him.

# 616

Believers and People of the Book, wishes alone can never provide you with salvation. Whoever commits evil will be punished accordingly and no one besides God will be his guardian or helper.

# 617

Any believer, male or female, who acts righteously, will enter Paradise and will not suffer the least bit of injustice.

# 618

Whose religion is better than that in which one submits himself to God, behaves righteously, and follows the upright religion of Abraham, God's chosen friend?

# 619

To God belongs all that is in the heavens and the earth and He has control over all things.

# 620

(Muhammad), they ask you concerning women. Tell them, "God will instruct you about them, besides that which can be read in the Book, about widows with children, whom you wanted to marry without giving them their due rights and He will instruct you about the rights of the weak and oppressed children. God commands you to maintain justice with the orphans. God knows all about whatever good you do.

# 621

If a woman is afraid of her husband's ill treatment and desertion, it will be no sin for both of them to reach a reconciliation. Reconciliation is good even though men's souls are swayed by greed. If you act righteously and be pious, God is Well Aware of what you do.

# 622

You will never be able to maintain justice among your wives and love them all equally, no matter how hard you try. Do not give total preference to one of them, leaving the other as if in suspense. If you do bring about reconciliation and maintain piety, God is All-forgiving and All-merciful.

# 623

If the marriage is terminated, God will make each one of them financially independent. God is Munificent and Wise.

# 624

To God belongs all that is in the heavens and the earth. We have told you and the People of the Book to have fear of God. If you all refuse to believe in Him, know that to God belongs all that is in the heavens and the earth. God is Self-sufficient and Praiseworthy.

# 625

To God belongs all that is in the heavens and the earth. God is a totally Sufficient Guardian.

# 626

Had God wanted He could have destroyed you all and replaced you by another people; He has the power to do so.

# 627

Be it known to those who want worldly rewards that God holds the rewards for this life as well as the life to come. God is All-hearing and All-seeing.

# 628

Believers, be the supporters of justice and the testify to what you may have witnessed, for the sake of God, even against yourselves, parents, and relatives; whether it be against the rich or the poor. God must be given preference over them. Let not your desires cause you to commit injustice. If you deviate from the truth in your testimony, or decline to give your testimony at all, know that God is Well Aware of what you do.

# 629

Believers, have faith in God and His Messenger, the Book which is revealed to him, and the Bible which has been revealed before. Whoever refuses to believe in God, His angels, Books, Messengers and the Day of Judgment, has gone far away from the right path.

# 630

God will not forgive or guide to the right path those who first believe, then disbelieve, again believe and disbelieve, and then increase their disbelief.

# 631

Tell the hypocrites that for them there will be a painful torment.

# 632

Do those who establish friendship with the disbelievers instead of the believers seek honor? Let them know that all honor belongs to God.

# 633

God has told you (believers) in the Book that when you hear people disbelieving and mocking God's revelations, do not sit with them unless they change the subject. You will become like them. God will gather all the hypocrites and the disbelievers together in hell fire.

# 634

(The hypocrites) wait and watch. If God grants you victory, they say, "Did we not help you?" If the unbelievers are victorious, they say, "Did we not encourage you not to surrender to the believers and did we not protect you from them?" God will judge among you on the Day of Judgment. He will never help the disbelievers against the believers.

# 635

The hypocrites try to deceive God but He, in fact, deceives them. They stand up in prayer lazily just to show that they pray, but, in truth they remember God very little.

# 636

They are hesitant people belonging to neither side. You can find no other way for one whom God has caused to go astray.

# 637

Believers, do not make unbelievers your intimate friends and supporters rather than believers. Do you want to establish clear evidence against yourselves before God?

# 638

The hypocrites will be placed in the lowest bottom of the fire and none of you will ever find a helper for them, except

# 639

those (hypocrites) who have repented, put their trust in God, and sincerely followed only His religion will live with the believers to whom God will give a great reward.

# 640

Why should God punish you if you give thanks and believe in Him? God is All-rewarding and All-forgiving.

# 641

God does not love public accusation unless one is truly wronged. God is All-hearing and All-knowing.

# 642

Whether you act virtuously, in public or in private, or pardon (people's) faults, God is All-forgiving and All-powerful.

# 643

Those who disbelieve in God and His Messengers try to create differences between God and His Messengers (by rejecting their message). They say, "We believe in some but not in others." Thus, they try to find a middle way

# 644

but, in fact, they are unbelievers, and for them We have prepared a humiliating torment.

# 645

As for those who believe in God and make no distinction between His Messengers, they will receive His reward. God is All-forgiving and All-merciful.

# 646

(Muhammad), the People of the Book ask you to make a Book descend to them from the heavens. However, they had asked Moses for things much harder to do than this, by saying, "Show us God in person." Thunder and lightning struck them because of their unjust demands. Despite all the evidence that had come to them, they started to worship the calf, but We forgave them for their sins and gave Moses clear authority.

# 647

We raised Mount (Sinai) above them because of Our solemn promise to them. Also, We told them to prostrate themselves when entering the gate (of the holy house) and not to commit transgression on the Sabbath. We made a solemn covenant with them.

# 648

However, because of their disbelief, disregard of their covenant, denial of God's revelations, murdering the Prophets without reason, and their saying that their hearts were covered, We sealed up their hearts. Only a few of them believe.

# 649

Their hearts were also sealed because of their lack of faith, their gravely slanderous accusation against Mary,

# 650

and their statement that they murdered Jesus, son of Mary, the Messenger of God, when, in fact, they could not have murdered him or crucified him. They, in fact, murdered someone else by mistake. Even those who disputed (the question of whether or not Jesus was murdered) did not have a shred of evidence. All that they knew about it was mere conjecture. They certainly could not have murdered Jesus.

# 651

God raised him up to Himself. God is Majestic and All-wise.

# 652

There will be no one among the People of the Book who will not believe (a belief of no value) in him (Jesus) before their deaths. On the Day of Judgment, (Jesus) will testify against them.

# 653

We made unlawful for the Jews certain pure things which had been lawful for them before, because of the injustice which they had committed, their obstructing many people from the way of God,

# 654

their taking usury which was prohibited for them, and their consuming people's property unjustly. For the unbelievers among them, We have prepared a painful torment.

# 655

However, the learned among them (the Jews) and the faithful believe in what God has revealed to you (Muhammad) and to the others before you and those who are steadfast in prayer, pay their religious tax, and believe in God and the Day of Judgment. They all will receive a great reward from Us.

# 656

(Muhammad), We have sent revelations to you just as were sent to Noah and the Prophets who lived after him and to Abraham, Ishmael, Isaac, Jacob, his descendants, Jesus, Job, Jonah, Aaron, and Solomon. We gave the Psalms to David.

# 657

(We sent revelations to) the Messengers mentioned to you before and also to Messengers who have not been mentioned to you. God spoke to Moses in words.

# 658

The Messengers were sent to give people the glad news (of God's mercy) and warn them (of His punishment) so that the human being would not have any objections against God, after the coming of the Messengers, (that they did not have any knowledge of His mercy and punishment). God is Majestic and All-wise.

# 659

God testifies that whatever He has revealed to you (Muhammad) He has revealed it on purpose and the angels also testify to it but God's testimony alone is Sufficient.

# 660

Those who have rejected the faith and have obstructed people from the way of God, have certainly gone far away from the right path.

# 661

God will not forgive those who have rejected the faith and committed injustice, nor will He guide them to any way

# 662

other than that of hell wherein they will live forever. For God this is not in the least bit difficult.

# 663

Mankind, the Messenger has come to you from your Lord in all Truth. It is for your own good to believe in him, but if you disbelieve, know that to God belongs all that is in the heavens and the earth. God is All-knowing and All-wise.

# 664

People of the Book, do not exceed the limits of devotion in your religion or say anything about God which is not the Truth. Jesus, son of Mary, is only a Messenger of God, His Word, and a spirit from Him whom He conveyed to Mary. So have faith in God and His Messengers. Do not say that there are three gods. It is better for you to stop believing in the Trinity. There is only One God. He is too glorious to give birth to a son. To God belongs all that is in the heavens and the earth. God alone is a Sufficient Guardian for all.

# 665

Jesus never disdained the worship of God nor did the nearest angels to God. Whoever, out of pride, disdains the worship of God should know that everyone will be brought before Him.

# 666

The righteously striving believers will receive the reward for their deeds and extra favors from God. But those who disdain the worship of God out of pride will suffer the most painful torment. They will find no guardian or helper besides God.

# 667

Mankind, an undeniable proof has certainly come to you and We have sent you a shining light

# 668

Those who believe in God and seek His protection will receive His mercy, favors, and His guidance to the right path.

# 669

(Muhammad), they seek your verdict. Tell them, "God commands this concerning your kindred: If a man dies childless but has a sister, she will receive half of the legacy. If a woman dies childless, her brother will receive the whole legacy. If a childless man leaves only two sisters, both will receive two-thirds of the legacy. If the heirs are both sisters and brothers, the share of a male will be twice as much as the share of the female. God explains His Laws to you so that you will not go astray. God knows all things.

# 670

Believers, stand by your contracts (and obligations). Of all animals, cattle has been made lawful for you as food with certain exceptions. Hunting is not lawful for you during ihram (a part of the rituals during pilgrimage). God decrees as He wills.

# 671

Believers, do not disrespect the reminders of God, the sacred months, the animals brought for sacrifice, or what is marked for sacrificial offering or the people heading to the precinct of the Sacred House to seek the favor and pleasure of their Lord. Once the restrictions of ihram are over, you may hunt. Do not let the hostility of a group of people keep you away from the Sacred Mosque or make you express animosity. Co-operate with each other in righteousness and piety, not in sin and hostility. Have fear of God; He is stern in His retribution.

# 672

It is unlawful for you to consume the following as food: an animal that has not been properly slaughtered, blood, pork, an animal slaughtered and consecrated in the name of someone other than God, an animal killed by strangulation or a violent blow, an animal killed by falling down, an animal which has been gored to death, an animal partly eaten by a wild beast before being properly slaughtered, an animal which has been sacrificed on the stone blocks (which pagans worshipped), and any flesh divided by casting superstitious and gambling arrows (a pagan tradition), which is a sin. Today, the unbelievers have lost hope about your religion. Do not be afraid of them but have fear of Me. On this day I have perfected your religion, completed My favors to you, and have chosen Islam as your religion. If anyone not (normally) inclined to sin is forced by hunger to eat unlawful substances instead of proper food, he may do so to spare his life. God is All-forgiving and All-merciful.

# 673

(Muhammad), they ask you what has been made lawful for them (as food). Tell them, "All pure things are made lawful for you." If you train dogs or other beasts for hunting, you should train them according to what God has taught you. It, then, is lawful for you to eat the animals that they hunt, provided you mention the Name of God over the prey. Have fear of God. Certainly God's reckoning is swift.

# 674

On this day, all pure things are made lawful for you (as food). The food of the People of the Book is made lawful for you and your food is made lawful for them. It is lawful for you to marry chaste Muslim women and chaste women of the People of the Book, provided, you pay their dowry, maintain chastity, and avoid fornication or lustful relations outside of marriage. The deeds of anyone who rejects the faith, certainly, become fruitless. He will be of those who lose on the Day of Judgment.

# 675

Believers, when you are about to pray, wash your face and your hands along with the elbows and wipe your head and your feet to the ankles. If you experience a seminal discharge, manage to take (the required) bath. If you are sick, or on a journey, or have just defecated, or have had intercourse with women and cannot find any water, perform a tayammum by: touching clean natural earth with both palms and wiping (the upper part) of your face and (the back of) your hands. God does not want you to suffer hardship. He wants you to be purified. He wants to complete His favors to you so that perhaps you would give Him thanks.

# 676

Remember God's favors to you and the firm covenant that He has made with you. You said because of this covenant, "We have heard (the words of the Lord) and have obeyed Him." Have fear of God; He knows well all that the hearts contain.

# 677

Believers, be steadfast for the cause of God and just in bearing witness. Let not a group's hostility to you cause you to deviate from justice. Be just, for it is closer to piety. Have fear of God; God is Well Aware of what you do.

# 678

God has promised forgiveness and a great reward to the righteously striving believers.

# 679

However, the unbelievers who have called Our revelations lies will have hell for their dwelling.

# 680

Believers, recall God's favors to you when a group of people were about to harm you and God made their evil plots against you fail. Have fear of God. Believers, only trust in God.

# 681

God certainly made a solemn covenant with the children of Israel and raised among them twelve elders. God said to them, "I am with you if you will be steadfast in your prayers, pay (zakat) religious tax, believe in My Messengers, support them with reverence, and give a generous loan for the cause of God." We shall expiate your bad deeds and admit you to the gardens wherein streams flow. Whichever of you turns to disbelief after this has certainly gone astray (from the right path)."

# 682

For their disregard of their solemn covenant with God, We condemned the Israelites and made their hearts hard as stone. Now they displace the words of God and have forgotten their share of the guidance that they had received. Still you receive news of the treachery of all but a few of them. Forgive and ignore them. God loves the righteous ones.

# 683

We had made a solemn covenant with those who call themselves Christians, but they forgot their share of the guidance that was sent to them. We have induced hatred and animosity among them which will remain with them until the Day of Judgment when God will tell them about what they had done.

# 684

People of the Book, Our Messenger has come to you. He tells you about the many things that you had been hiding of the Book and forgives you much. A light and a clarifying Book has come to you from God

# 685

to show the way of peace to those who seek His pleasure, to bring them out of darkness into light through His will and to guide them to the right path.

# 686

Those who have said that the Messiah, son of Mary, is God, have, in fact, committed themselves to disbelief. (Muhammad), ask them, "Who can prevent God from destroying the Messiah, his mother and all that is in the earth?" To God belongs all that is in the heavens, the earth, and all that is between them. God creates whatever He wants and He has power over all things.

# 687

The Jews and Christians call themselves the beloved sons of God. (Muhammad), ask them, "Why does God punish you for your sins? In fact, you are mere human beings whom He has created. He forgives and punishes whomever He wants. To Him belongs all that is in the heavens, the earth, and all that is between them and to Him do all things return.

# 688

People of the Book, Our Messenger has come to you to guide you at a time when none of Our other Messengers are living among you. (We sent him) so that you will not complain about having no one to tell you of what is good or warn you of what is bad. Now a bearer of good news has come to you. God has power over all things.

# 689

When Moses told his people, "Recall God's favors to you. He made Messengers and Kings out of your own people and gave you what He had not given to others-

# 690

Enter the sacred promised land which God has designated for you. Do not return to disbelief lest you become lost".

# 691

They said, "Moses, a giant race of people is living there. We shall never go there unless they leave the land first. If they leave it then we will enter."

# 692

Two God-fearing men on whom God had bestowed favors told them, "Proceed through the gates and when you enter the city you will be victorious. Have trust in God if you are true believers".

# 693

They said, "(Moses), as long as they are in the land, we shall never go there. Go with your Lord to fight them but we shall stay where we are".

# 694

(Moses) said, "Lord, I can only speak for myself and my brother; keep us away from the evil-doers".

# 695

The Lord said, "The land will be prohibited to them for forty years (during all such time) they will wander in the land. Do not feel sad for the evil-doing people."

# 696

(Muhammad) tell them the true story of the two sons of Adam (Abel and Cain). Each one of them offered a sacrifice. God accepted the sacrifice of one of them (Abel) but not that of the other (Cain) who then said to his brother, "I shall certainly kill you." (Abel) replied, "God only accepts the offerings of the pious ones.

# 697

Even if you try to kill me, I certainly shall not try to kill you. I have fear of God, the Lord of the creation.

# 698

I would prefer you to take sole responsibility for both our sins and thus become a dweller of hell; this is what an unjust person deserves."

# 699

(Cain's) soul prompted him to kill his own brother. In doing so he became of those who lose.

# 700

God sent down a raven which started to dig up the earth to show the killer how to bury the corpse of his brother. On seeing the raven, (Cain) said, "Woe to me! Am I less able than a raven to bury the corpse of my brother?" He became greatly remorseful.

# 701

For this reason, We made it a law for the children of Israel that the killing of a person for reasons other than legal retaliation or for stopping corruption in the land is as great a sin as murdering all of mankind. However, to save a life would be as great a virtue as to save all of mankind. Our Messengers had come to them with clear authoritative evidence but many of them (Israelites) thereafter started doing wrong in the land.

# 702

The only proper recompense for those who fight against God and His Messenger and try to spread evil in the land is to be killed, crucified, or either to have one of their hands and feet cut from the opposite side or to be sent into exile. These are to disgrace them in this life and they will suffer a great torment in the life hereafter.

# 703

As for those who repent before you (the legal authorities) have control over them (by proving their guilts). They should know that God is All-forgiving and All-merciful.

# 704

Believers, have fear of God. Find the means to reach Him and strive hard for His cause so that you may have everlasting happiness.

# 705

Had the unbelievers had twice as much as the wealth of the whole earth in order to ransom themselves from the torment in the life hereafter, still their ransom would not have been accepted. For them there will be a painful torment.

# 706

They will wish to get out of the fire but they will not have such a choice. Their torment will be constant.

# 707

Cut off the hands of a male or female thief as a punishment for their deed and a lesson for them from God. God is Majestic and All-wise.

# 708

However, God will accept the repentance of whoever repents and reforms himself after committing injustice; He is All-forgiving and All-merciful.

# 709

Do you not know that to God belongs the Kingdom of the heavens and the earth and that He punishes or forgives whomever He wants? God has power over all things.

# 710

Messenger, do not be grieved about the people who run back to disbelief. They only say that they believe but, in fact, they have no faith in their hearts. Some Jews knowingly listen to lies and accept the lies which come from others, (Jews), who have no relation with you and who distort certain words of the Bible and say to the people, "Accept only those words which are the same as what We have told you. If you do not, then beware!" You can not help those whom God wants to try. God does not want to cleanse the hearts of such people. They lead a disgraceful life in this world and in the life hereafter they will suffer a great torment.

# 711

They deliberately listen to lies (for deceitful purposes) and live on usury. If they come to you (seeking your judgment to settle their differences), you may settle their disputes or keep aloof from them. Should you choose not to bother with them, it will not harm you in the least. If you decide to issue your decree, decide their case with justice. God loves those who are just.

# 712

How can they come to you for judgment when they already have the Torah which contains the decree of God! It does not take them long to disregard your judgment; they are not true believers.

# 713

We had revealed the Torah, containing guidance and light. The Prophets who had submitted themselves to the will of God, judged the Jews by the laws of the Torah. So did the godly people and the Jewish scholars who remembered some parts of the Book of God and bore witness to it. Mankind, do not be afraid of people but have fear of Me. Do not sell My revelations for a paltry price. Those who do not judge by the laws of God are disbelievers.

# 714

In the Torah We made mandatory for the Jews these rules of retaliation: Capital punishment for the murder of a person; an eye for an eye, a nose for a nose, an ear for an ear, a tooth for a tooth, and a just compensation for a wound. If the perpetrator is forgiven by the affected party, this will be an expiation of his crime. Those who do not judge according to what God has revealed are unjust.

# 715

We made Jesus, son of Mary, follow in the footsteps (of the earlier Prophets) and confirm what existed in the Torah in his time. We gave him the Gospel containing guidance and light, as a confirmation of the Torah and instruction and advice for the pious ones.

# 716

The followers of the Gospels (the New Testament) must judge according to what God has revealed in it. Those who do not judge by the laws of God are evil doers.

# 717

We have revealed the Book to you (Muhammad) in all Truth. It confirms the (original) Bible and has the authority to preserve or abrogate what the Bible contains. Judge among them by what God has revealed to you and do not follow their desires instead of the Truth which has come to you. We have given a law and a way of life to each of you. Had God wanted, He could have made you into one nation, but He wanted to see who are the more pious ones among you. Compete with each other in righteousness. All of you will return to God who will tell you the truth in the matter of your differences.

# 718

(Muhammad), you must judge among them by what God has revealed. Do not follow their desires. Beware of their mischievous deception concerning some of the matters that God has revealed to you. If they turn away, know that what God wants is to punish them for some of their sins. Many human beings are evil-doers.

# 719

Do they want judgments that are issued out of ignorance? Who is a better judge for the people whose belief is based on certainty, than God?

# 720

Believers, do not consider the Jews and Christians as your intimate friends for they are only friends with each other. Whoever does so will be considered as one of them. God does not guide the unjust people.

# 721

(Muhammad), you have seen those whose hearts are sick, running around among the people (Jews) saying, "We are afraid of being struck by disaster." But if God were to grant you victory or some other favors, they would then regret for what they had been hiding in their souls.

# 722

The believers say, "Are these the people who proclaimed themselves to be our sworn friends?" Their deeds have become devoid of all virtue and they themselves have become lost.

# 723

Believers, whichever of you turns away from his faith should know that God will soon raise a people whom He loves and who love Him, who are humble towards the believers, dignified to the unbelievers, who strive hard for the cause of God, and who have no fear of anyone's accusations. This is a favor from God. He bestows His favors upon whomever He wants. God is Munificent and All-knowing.

# 724

Only God, His Messenger, and the true believers who are steadfast in prayer and pay alms, while they kneel during prayer, are your guardians.

# 725

One whose guardians are God, His Messenger, and the true believers should know that God's party will certainly triumph.

# 726

Believers, do not consider those among the People of the Book and the unbelievers who mock at your religion and treat it as useless, as your protectors. Have fear of God if you are true believers.

# 727

Because they are devoid of understanding, they ridicule your call for prayers saying that it is a useless act.

# 728

(Muhammad), say to the People of the Book, "Do you take revenge on us because of our belief in God and what He has revealed to us and to others before us? Most of you are evil-doers".

# 729

Say, "Should I tell you who will receive the worst punishment from God? Those whom God has condemned, afflicted with His anger, made apes out of them, swine and worshippers of Satan, will have the worst dwelling and will wander far away from the right path."

# 730

When they come to you (believers), they say, "We have accepted your faith." However, they entered into your faith as unbelievers and left it as unbelievers. God knows best what they were hiding.

# 731

You can see many of them competing with each other in sin, hostility, and in taking usury. What they had been doing is certainly evil.

# 732

Why did the men of God and rabbis not forbid them from following their sinful words and their consuming of unlawful gains. Evil was their (rabbis and priests) profession!

# 733

The Jews have said, "God's hands are bound." May they themselves be handcuffed and condemned for what they have said! God's hands are free and He distributes His favors to His creatures however He wants. The rebellion and disbelief of many of them will be intensified against you because of what has been revealed to you from your Lord. We have induced hostility and hatred among them which will remain with them up until the Day of Judgment. Whenever they kindle the fire of war, God extinguishes it. They try to destroy the land but God does not love the evil-doers.

# 734

Had the People of the Book accepted the faith and observed piety, certainly, We would have redeemed their bad deeds and admitted them into a blissful Paradise.

# 735

Had they followed the Laws of the Old and New Testaments and what was revealed to them from their Lord, they would have received Our bounties from above and below in abundance. Some of them are modest people, but many of them commit the worst sins.

# 736

Messenger, preach what is revealed to you from your Lord. If you will not preach, it would be as though you have not conveyed My message. God protects you from men. He does not guide the unbelieving people.

# 737

(Muhammad), tell the People of the Book, "You have nothing unless you follow the Old and New Testaments and that which (the Quran) God has revealed to you." Whatever has been revealed to you (Muhammad) from your Lord will only increase their disbelief and rebellion (against you). Do not grieve for the unbelieving people.

# 738

The believers, Jews, Sabaeans, and the Christians who believe in God and the Day of Judgment and who do what is right will have nothing to fear nor will they be grieved.

# 739

We made a covenant with the Israelites and sent Messengers to them. Whenever a Messenger came to them with a message which did not suit their desires, they would reject some of the Messengers and kill others.

# 740

They were blind and deaf in their pride, thinking themselves (to be the chosen nation of God) and thus safe from calamities. God forgave them but many of them out, of pride, again became blind and deaf. God is Well Aware of what they do.

# 741

Those who say that Jesus, the son of Mary, is God, have, in fact, turned to disbelief. Jesus said to the Israelites, "Worship God, my Lord and yours. God will deprive anyone who considers anything equal to God of Paradise and his dwelling will be fire. The unjust people have no helpers."

# 742

Those who say that God is the third of the Three, have, in fact, turned to disbelief. There is no Lord but God, the only One Lord. If they will not give-up such belief, the disbelievers among them will suffer a painful torment.

# 743

Should they not repent and ask Him for forgiveness? God is All-forgiving and All-merciful.

# 744

Jesus, the son of Mary, was no more than a Messenger before whom there lived many other Messengers. His mother was a truthful woman and both of them ate earthly food. Consider how We explain the evidence (of the Truth) to them and see where they then turn.

# 745

(Muhammad), say to them, "Do you worship things besides God which can neither harm or benefit you?" It is only God who is All-hearing and All-knowing.

# 746

Say to the People of the Book, "Do not wrongly exceed the proper limit of devotion to your religion or follow the desires of the people who have erred. They have misled many others and have themselves stayed far away from the right path.

# 747

The unbelievers among the Israelites, because of their disobedience and transgression, were condemned by David and Jesus, the son of Mary for their disobedience; they were transgressors.

# 748

They did not prevent each other from committing sins nor would they themselves stay away from them. Evil was what they had done!

# 749

You have seen many of them establishing friendship with the unbelievers. Vile is what their souls have gained! They have invoked the wrath of God upon themselves and they will live forever in torment.

# 750

Had they had faith in God, the Prophet, and what was revealed to him, they would not have been the friends of the unbelievers. However, many of them are evil-doers.

# 751

You find Jews and pagans among the worst of the enemies of the believers. (Of the non-believers) nearest to them (the believers) in affection you find those who say, "We are Christians," for among them are the priests and monks who are not proud.

# 752

When they hear what is revealed to the Messenger, you can see their eyes flood with tears, as they learn about the Truth. They say, "Lord, we believe (in this faith). Write our names down as bearing witness to it.

# 753

Why should we not believe in God and the Truth that has come to us and hope that the Lord will admit us into the company of the righteous people?"

# 754

Thus, God has given them as their reward, gardens wherein streams flow and wherein they will live forever. Such will be the recompense of the righteous people.

# 755

Those who disbelieved and denied Our revelations will be the dwellers of Hell.

# 756

Believers, do not make unlawful the pure things which God has made lawful for you. Do not transgress for God does not love the transgressors.

# 757

Eat from the pure and lawful things that God has given to you. Have fear of God in Whom you believe.

# 758

God will not hold you responsible for your thoughtless oaths. However, He will question you about your deliberate oaths. The expiation for breaking an oath is to feed ten needy people with food, typical of that which you feed to your own people, to clothe them or to set a slave free. One who cannot pay this, he must fast for three days to expiate his oaths. Keep your oaths. Thus, does God explain His Laws so that you will give Him thanks.

# 759

Believers, wine, gambling, the stone altars and arrows (that the pagans associate with certain divine characters) are all abominable acts associated with satanic activities. Avoid them so that you may have everlasting happiness.

# 760

Satan wants to induce hostility and hatred among you through wine and gambling and to prevent you from remembering God and prayer. Will you then avoid such things?

# 761

Obey God and the Messenger and be cautious (of the harmful things). If you turn away (from Our laws), know that the duty of the Messenger is only to preach in clear words.

# 762

The righteously striving believers will not be blamed for what they have eaten, if they maintain piety, do good deeds, have faith, and be charitable. God loves the generous people.

# 763

Believers, God will test you (to see the strength of your obedience) concerning what you hunt by hand or spear, so that He would know who has fear of Him in private. Whoever transgresses will suffer a painful torment.

# 764

Believers, do not hunt when you are in the holy precinct. Whichever of you purposely kills game in the holy precinct has to offer, as an expiation, a sacrifice in the holy precinct which two just people among you would consider equal to the prey or food to a destitute person or has to fast (for an appointed time) to bear the burden of the penalty for his deed. God forgives whatever was done in the past, but He will take revenge on whoever returns to transgression, for He is Majestic and Capable of taking revenge.

# 765

It is lawful for you to hunt from the sea and to eat seafood. This is for your benefit and for the benefit of travellers. However, it is not lawful for you to hunt on land as long as you are in the sacred precinct. Have fear of God before whom you will all be raised.

# 766

God has made the Kabah, the Sacred House, the sacred months, the unmarked and marked sacrificial animals for the welfare of men and in order to inform you that God knows all that is in the heavens and the earth. He has the knowledge of all things.

# 767

Know that God is stern in His retribution and He is All-forgiving and All-merciful.

# 768

The duty of the Messenger is only to preach. God knows what you reveal or hide.

# 769

(Muhammad), say to them, "The pure and filthy are not the same even though the abundance of filth may attract you. Men of reason, have fear of God so that you may have eternal happiness."

# 770

Believers, do not ask about things which, if revealed to you, would disappoint you. If you ask about such things when the Prophet is receiving revelations, they will also be revealed to you. God has exempted you (from the responsibilities of the things you wanted to know). He is All-forgiving and Forbearing.

# 771

People living before you had asked about such things, but then rejected them.

# 772

God has not instituted the rites of Bahirah, Sa'ibah, Wasilah, nor of Hami (names of certain animals that the pagans would offer as sacrifice). It is the pagans who have attributed falsehood to God. Many of them have no understanding.

# 773

When they are told to refer to the guidance of God and to the Messenger, they say, "The tradition of our fathers is sufficient for our guidance," even though, in fact, their fathers had neither knowledge nor proper guidance.

# 774

Believers, save your own souls, for if you have the right guidance, no one who strays can harm you. You will all return to God who will tell you about what you have done.

# 775

Believers, when death approaches any one of you, let two just men from your own people (Muslims) or any two other men (People of the Book) if death befalls you on a journey, bear witness to the bequest. If you have any doubts as to their honesty, detain them and let them take an oath after the prayer, each one of them saying, "I swear by God that my testimony is true. I am not selling the Truth for a paltry price even though the beneficiary would be one of my relatives. I do not hide the testimony which is the right of God, for then I would be one of the sinners."

# 776

If their honesty is challenged, two others from the relatives of the deceased should swear in the same way and testify to the bequest saying, "We swear by God that our testimony is the true one. We do not transgress in the matter lest we become unjust ones."

# 777

This will help preserve a proper testimony because the witness will be afraid of the denial of their own testimony by a second pair of witness. Have fear of God and listen (properly). God does not guide the evil doing people.

# 778

Have fear of the day when God will bring all the Messengers together and ask them, "What was the response of men to your call?" They will reply, "We have no knowledge. You are the only One who has knowledge of the unseen."

# 779

When God said, "Jesus, son of Mary, recall My favors to you and your mother. (Recall) how I supported you by the holy spirit, made you speak to people from your cradle and when you grew up, taught you the Book, gave you wisdom, the Torah, and the Gospel. (Recall) when, by My will, you made a sculpture of a bird out of clay, blew into it, and it turned into a real bird by My Will. (Recall) how, by My will, you healed the deaf, the lepers, and raised the dead. (Recall) when you came to the Israelites in the house with clear miracles and I saved you from their mischief, even though the disbelievers among them said, "This is obviously magic".

# 780

(Recall) when I inspired the disciples to have faith in Me and My Messenger. They said, "We have accepted the faith. Lord, bear witness that we have submitted ourselves to Your will"

# 781

(Recall) when the disciples said, "Jesus, son of Mary, can your Lord send us a table full of food from heaven?" and you replied, "Have fear of God if you are true believers".

# 782

They said, "We only wish to eat therefrom to comfort our hearts, to know that you have spoken the Truth to us, and to bear witness to it along with the others."

# 783

When Jesus prayed, "Lord, send us a table full of food from heaven so that it will make a feast for us and for those who are yet to come in this world and an evidence from You. Give us sustenance, for You are the best Provider,"

# 784

God replied, "I am sending it to you, but if anyone of you turns back to disbelief, I will make him suffer a torment that no one has ever suffered."

# 785

When God asked Jesus, son of Mary "Did you tell men to consider you and your mother as their gods besides God?" he replied, "Glory be to you! How could I say what I have no right to say? Had I ever said it, You would have certainly known about it. You know what is in my soul, but I do not know what is in Yours. It is You who has absolute knowledge of the unseen.

# 786

"I did not tell them anything except what You commanded me to tell them. I told them that they must worship God who is everyone's Lord. I watched them as long as I was among them until You raised me to Yourself and You Yourself had also watched over them; You are Omnipresent.

# 787

You may punish Your servants or forgive them for You are Majestic and Wise."

# 788

God will say, "This is the Day when the truthful ones will benefit from their truthfulness. For them there are gardens wherein streams flow and they will live therein forever. God is pleased with them and they will be pleased with God in their supreme triumph.

# 789

To God belongs the kingdom of the heavens and the earth and all that is between them and He has power over all things.

# 790

Only God Who has created the heavens, the earth, darkness, and light deserves all praise. The disbelievers consider other things equal to Him.

# 791

It is He who has created you from clay to live for a life-time and the span of your life is only known to Him. You are still suspicious!.

# 792

He is God of the heavens and the earth and He knows whatever you conceal, reveal, or gain.

# 793

(The unbelievers) have always turned away from the revelations and the evidence (of the Truth) that has been sent to them from time to time.

# 794

They have refused the Truth (Muhammad's message) that has come to them but they will soon learn the consequences of their mocking.

# 795

Why do they not consider how many generations living before them We have destroyed. We established those nations in the land with abilities far beyond those given to you. We sent down plenty of rain from the sky for them and made streams flow therein, but, then, We destroyed them for their sins and established other nations after them.

# 796

(Muhammad), had We sent you a Book on paper, the unbelievers would have touched it with their hands but would still have said, "It is no more than plain sorcery".

# 797

They have said, "Why has not an angel come to him (Muhammad)?" Had We sent an angel to them, the matter would have inevitably been out of their hands, and they would have been given no more time.

# 798

Were We to have made him (Our Messenger) an angel, We would have made him resemble a human being and they would have again complained that the matter was as confusing to them as it is to them now.

# 799

They mocked the Messengers who lived before you (Muhammad), but those who received warnings of punishment and mocked the warnings, all suffered their torments accordingly.

# 800

(Muhammad), tell them to travel in the land and see what happened to those who rejected the Truth.

# 801

Ask them, "Who is the owner of the heavens and the earth besides God, the All-merciful, who will gather you all together on the Day of Judgment? That day will certainly come. Those who have lost their souls will not believe.

# 802

To Him belongs all that rests during the night and the day. He is All-hearing and All-knowing."

# 803

(Muhammad), ask them, "Should I take a guardian other than God, the Originator of the heavens and the earth, who feeds everyone and who needs no food Himself?" Say, "I have been commanded to be the first Muslim (submitted to the will of God). Thus, people, do not be pagans."

# 804

(Muhammad), say, "Because of the torment of the Great Day, I am afraid to disobey my Lord".

# 805

One who will be saved from the torment on the Day of Judgment will certainly have received God's mercy and this will be a manifest triumph.

# 806

(Muhammad), if God afflicts you with hardship, no one besides Him will be able to relieve you. If He bestows a favor on you, know that He has power over all things.

# 807

He is Wise, Well Aware and Dominant over all His creatures.

# 808

(Muhammad), ask them, "What is the greatest testimony? God testifies of my truthfulness to you. He has revealed this Quran to me to warn you and the coming generations (against disobeying God). Do you believe that other gods exist besides God? I solemnly declare that He is the only Lord and that I am not guilty of believing in what the pagans believe."

# 809

The People of the Book know him (Muhammad) just as well as they know their own children, but those who have lost their souls will not believe.

# 810

Who are more unjust than those who ascribe falsehood to God or reject His revelations? The unjust will certainly have no happiness.

# 811

On the Day of Judgment when We will gather all people together, We will ask the pagans, "Where are those whom you believed to be your gods?"

# 812

Attempting to answer, they will say, "Lord, we swear by Your Name that we were not pagans".

# 813

Consider, how they have lied against their own souls and have lost their gods.

# 814

Some of them listen to you, but We have veiled their hearts so that they cannot understand and made them deaf. They disbelieve all the evidence (of Our existence) that they may have seen. They only come to you for the sake of argument and the disbelievers say that (whatever Muhammad says) is no more than ancient legends.

# 815

They keep away from the faith and forbid others to accept it. They destroy no one except themselves, yet they do not realize it.

# 816

If only you could see them standing in the fire saying, "Would that we could return to the worldly life. We would never reject any of our Lord's revelations and we would be true believers."

# 817

Whatever they had concealed will be revealed to them. If they were to return to (the worldly life), they would again worship idols, for they are liars.

# 818

They have said that this life is the only life and that there will be no Resurrection.

# 819

Would that you could see them standing before their Lord who would ask them, "Is not the Resurrection true?" They would reply, "Yes, Lord, there is a Resurrection." The Lord would then say, "For your disbelief, suffer the torment."

# 820

Those who do not believe in the Day of Judgment have incurred upon themselves a great loss. When the Day of Judgment suddenly comes upon them, they will sink under the burden of their sins in grief for their neglecting that day. Terrible indeed will be their burden!

# 821

The worldly life is but useless amusement and sport (compared to) the life hereafter which is far better and is only for the pious. Will you not then understand?

# 822

We certainly know that you (Muhammad) are sad about what they (the unbelievers) say. It is not you (alone) who has been accused of lying. The unjust have always rejected God's revelations.

# 823

The Messengers who lived before you were also accused of lying, but they exercised patience. They were cruelly persecuted before We gave them victory. No one can change the words of God. You have already received news about the Messengers.

# 824

(Muhammad), if their refusal of the faith is so grievous to you and if you can dig up the earth or ascend into the sky in search of further evidence to inevitably make them believe you, you should have done so, but note that had God wanted, He could have made them all follow the same guidance. Do not ever be unaware (of this fact).

# 825

Only those who have understanding will accept your faith. (Those who have no understanding) are like the dead whom God will resurrect and to Him will all return.

# 826

They say, "Why have not some miracles been given to him, (Muhammad), from his Lord." Tell them, (Muhammad), "God certainly has the Power to show such miracles but many of them are ignorant."

# 827

All the beasts on land and flying birds have different communities, just as you (people) do. Nothing is left without a mention in the Book. They will all be brought into the presence of their Lord.

# 828

Those who disbelieve Our revelations are, in fact, deaf and dumb. They wander in darkness. God leads astray or guides to the right path whomever He wants.

# 829

(Muhammad), say to them, "Should God afflict you with torment, or should the Day of Judgment arrive, if what you claim is true, could you then seek help from any one other than God?

# 830

You will certainly ask Him for help. He will save you from hardship if He decides to do so and you will forget all about your gods."

# 831

We had sent (Our guidance) to the nations who lived before you and afflicted them with distress and adversity so that they might submit themselves (to God).

# 832

Why did they not submit themselves (to God) when Our torment struck them. Instead, their hearts were hardened and Satan made their evil deeds seem attractive to them.

# 833

When they forgot (all) the advice that they had received, We granted them all means of happiness but they were left in despair when We suddenly took Our bounties back from them.

# 834

Thus, the transgressing people were destroyed. It is only God, the Lord of creation who deserves all praise.

# 835

(Muhammad), ask them, "Have you ever considered that if God was to disable your hearing and vision and veil your hearts, could anyone besides Him restore them?" Look at how plainly We show them the evidence (of the Truth) but they always ignore it.

# 836

Tell them, "Have you considered that if God's torment was to befall you suddenly or in public, would anyone else be destroyed except the unjust?"

# 837

We did not send the Messengers for any other reason than to bring (people) the glad news (of God's mercy) and to warn (them of the torment brought on by disobedience to God). Whoever accepts the faith and lives a righteous life will have nothing to fear, nor will he be grieved.

# 838

Those who reject Our revelations will certainly be punished for their evil deeds.

# 839

(Muhammad), tell them, "I do not claim to have all the treasures of God in my hands, nor to know the unseen, nor do I claim to be an angel. I follow only what is revealed to me (from God)." Say to them, "Are the blind and the seeing equal?" Why then do you not think?

# 840

Preach the Quran to those who are concerned about the Day of Judgment at which time they will be brought before their Lord. Tell them that their only guardian and intercessor is God so that they may become pious.

# 841

Do not disregard those who pray to their Lord in the mornings and evenings, seeking their Lord's pleasure. You will not be held responsible for them nor will they be held responsible for you. Do not disregard them lest you become unjust.

# 842

We test some of them by the conditions of the others so that the rich and proud ones (seeing your poor and humble followers) would say, "Are these the ones from among all of us whom God has chosen to favor?" Does not God know those who give thanks (much better than others do).

# 843

When the faithful come to you, say to them, "Peace be upon you. Your Lord has decreed for Himself to be All-merciful. Anyone of you who commits a sin out of ignorance, then repents, and reforms himself will find that God is All-forgiving and All-merciful."

# 844

Thus do We explain Our revelations so that the sinful way can be plainly discerned.

# 845

(Muhammad), tell them, "I am commanded not to worship the idols instead of God. I do not follow your desires lest I go astray and miss the true guidance"

# 846

Say, "I have received enough authoritative evidence from my Lord but you have rejected it. Whatever (torment that God has threatened you with for your disbelief) and that which you insist on to experience without delay, is not in my hands. The (final) Judgment is in the hands of God. He reveals the Truth and He is the best Judge.

# 847

Say, "If I had in my hands what you demand to experience without delay, the matter would have been ended all together. God knows best about the unjust."

# 848

He has with Him the keys to the unseen which no one knows besides Him. He knows all that is in the land and the sea. Not a single leaf falls which He would not know. No single seed exists even in the darkest places of the land, nor anything in the world either wet or dry, that is not kept recorded in the self-evident Book (the tablet preserved in the heavens).

# 849

It is He who keeps you alive in your sleep at night and knows all that you do during the day. He wakes you up from your sleep to complete your worldly life, after which you will all return to Him. He will let you know all about what you had done in your worldly life.

# 850

He is Dominant over all His creatures and He sends guards to watch over you until death approaches you. Then His angelic Messengers will, without fail, take away your souls.

# 851

(After death) you will all be returned to God, your true Guardian. Know that judgment will be in His Hands and that His reckoning is swift.

# 852

(Muhammad), ask them, "Who would save you from the darkness of the land and sea if you were to pray humbly and secretly saying, 'Would that we were saved from this, for we would certainly then give thanks".

# 853

Say, "It is God who always saves you from (such hardship) and from all kinds of distress. Even then, you consider idols equal to God."

# 854

Say, "God has the power to send torment on you from above or below your feet, or to divide you into different groups quite hostile to one another, and make you suffer from each other's animosity." Consider how plainly We show them a variety of evidence (of the Truth) so that they may have understanding.

# 855

(Some of) your people have rejected the Quran, although it is the Truth. Tell them that you are not their guardian

# 856

and that for every prophecy (about you which comes from God) there is an appointed time (to come true) and that they will soon experience it.

# 857

When you see people mocking Our revelations, turn away from them so that they may change the subject. If Satan causes you to forget this, do not sit with the unjust people when you remember.

# 858

But those who observe piety (commit no sin) by sitting with the (unbelievers) in order to preach (the Truth) so that they, too, may become pious.

# 859

(Muhammad), leave alone those to whom their religion is no more than a useless plaything and who are deceived by the lure of the worldly life. Remind them of Our revelation so that a soul will not bring about its own destruction because of its deeds. No one besides God will be its guardian or intercessor, nor will any kind of ransom be accepted from it. Those who have entangled themselves in their evil deeds will drink boiling water and live in painful torment for their hiding the Truth.

# 860

Say to them, "Should we, instead of asking for God's help, seek help from that which can neither benefit nor harm us, but would only turn us back to disbelief after God had granted us guidance? To do so would be to act like (those who have been) seduced by Satan, leaving them wandering aimlessly here and there, even though their friends call them, 'Come to the right guidance that has come to us.' " Say, "God's guidance is the only true guidance and we are commanded to submit ourselves to the Lord of the Universe.

# 861

Be steadfast in prayer and have fear of God; before Him alone you will all be brought together.

# 862

It is He Who has created the heavens and the earth for a genuine purpose. When He commands the Day of Judgment to take place, it will come into existence. His Word is the Truth. The kingdom will be His alone on the day when the trumpet will be sounded. He has all knowledge of the unseen as well as the seen. He is All-wise and All-aware.

# 863

Consider when Abraham asked his father, Azar, "Why do you believe idols to be your gods? I find you and your people in absolute error".

# 864

Also, We showed (Abraham) the kingdom of the heavens and the earth to strengthen his faith.

# 865

When it became dark at night, he (Abraham) saw a star and said, "This is my lord." But when it disappeared, he said, "I do not love those who fade away".

# 866

When Abraham saw the rising moon, he said, "This is my lord." But when it faded away, he said, "If my Lord does not guide me I shall certainly go astray."

# 867

When he saw the rising sun, he said, "This is my Lord for it is greater (than the others)." But when this too faded away, (Abraham) said, "My people, I disavow whatever you consider equal to God.

# 868

I have up-rightly submitted myself to the One who has created the heavens and the earth and I am not an idol worshipper."

# 869

In an argument with his people, (Abraham) asked them, "Why do you argue with me about God who has given me guidance? Your idols can do no harm to me unless God wills. God knows all things. Why, then, do you not consider this?

# 870

Why should I be afraid of your idols when you are not afraid of worshipping them without any authority from heaven? Would that you knew which of us is more deserving to receive amnesty".

# 871

Those who have accepted the faith and have kept it pure from injustice, have achieved security and guidance.

# 872

Such was the authoritative reasoning that We gave Abraham over his people. We raise whomever We want to a higher rank. Your Lord is All-wise and All-knowing.

# 873

We gave (Abraham) Isaac and Jacob. Both had received Our guidance. Noah received Our guidance before Abraham and so did his descendants: David, Solomon, Job, Joseph, Moses, and Aaron. Thus is the reward for the righteous people.

# 874

We also gave guidance to Zacharias, John, Jesus, and Elias, who were all pious people,

# 875

and Ishmael, Elisha, Jonah, and Lot whom We exalted over all people.

# 876

From their fathers, descendants, and brothers, We chose (certain) people and guided them to the right path.

# 877

Such is the guidance of God by which He guides whichever of His servants He wants. If people worship idols, their deeds will be turned devoid of all virtue.

# 878

These were the people to whom We gave the Book, Authority, and Prophesy. If some people do not accept Our guidance, it should not grieve you, (Muhammad), for We have made others who accept and protect Our guidance.

# 879

We had guided the Prophets. (Muhammad), follow their guidance and say (to the people), "I do not ask any reward for what I have preached to you. It is my duty to awaken the world."

# 880

They have no true respect of God when they say, "God has not sent anything to a mortal being." (Muhammad), tell them, "Who revealed the Book containing a light and guidance for the people which Moses brought? You wrote down only some parts of the original on paper and hid much, even after having learnt from it, that which neither you nor your fathers knew." Tell them, "God has (revealed the Quran)," and then leave them alone to pursue their useless investigations.

# 881

We have blessed this Book (the Quran) and revealed it to confirm that which was revealed to the Prophets who lived before you and to warn the people of the mother land (Mecca) and those living around it. Those who believe in the Day of Judgment accept this and are steadfast in their prayers.

# 882

Who are more unjust than those who ascribe lies to God or say that God has sent them revelations when nothing has been sent to them, or those who say that they can also bring down (from heaven) a book like that which God has revealed? Would that you could see the unjust in the agonies of death when the angels will come forward with their hands outstretched to take their souls out of their bodies and say, "This is the day when you will face humiliating torment for the falsehood that you ascribed to God and for your contemptuously disregarding of His revelations."

# 883

God will say, "You have come to Us alone just as We created you at first. You have left behind all those whom We made your friends and We do not see with you any of the intercessors whom you believed to be your partners. Your relations with them have certainly been destroyed and your belief in them has left you (in the dark)."

# 884

It is God who makes all kinds of seeds grow, brings forth the living from the dead, and the dead from the living. It is God who does such things, so how can you turn away from Him?

# 885

It is He who kindles the light of dawn, and has made the night for you to rest, and the sun and moon as a means of calculation. This is the design of the Majestic and All-knowing God.

# 886

It is God who created the stars so that you could find your way thereby in the darkness of the land and sea. We have explained Our evidence to the people of knowledge.

# 887

It is He who has created you from a single soul. Some of you are settled (on earth) and some are still in the depository system of (their parents). We have shown the evidence (of Our existence) to the people who understand.

# 888

It is He who has sent water down from the sky to let all kinds of plants grow; the vegetables with accumulated grains; palm-trees from which appear clusters of dates within easy reach; vineyards, olive groves, and pomegranates of all types. See the fruits when they are growing and when they are ripe. This, too, is evidence (of the existence of God) for those who believe.

# 889

(Some) people considered the jinn to be equal to God even though God created them and they unknowingly ascribed to Him children, both boys and girls. God is too glorious to have the attributes which they ascribe to Him.

# 890

How could the One Who is the Originator of the heavens and the earth and who has no companion, have a son? He created all things and has absolute knowledge of all things.

# 891

He is God your Lord. There is no God but He. He has created all things. Worship Him for He is the Guardian of all things.

# 892

No mortal eyes can see Him, but He can see all eyes. He is All-kind and All-aware.

# 893

(Muhammad), tell them, "Clear proofs have certainly come to you from your Lord. Whoever tries to understand it will gain much but those who ignore it will only harm themselves. I am not (supposed) to watch over you (all the time)".

# 894

Thus do We explain Our revelations to them. Let them say,"You have learned (those statements) from other people." We want to explain Our revelations only to those who have knowledge.

# 895

(Muhammad), follow what has been revealed to you from your Lord; there is no God but He, and stay away from pagans.

# 896

Had God wanted, they would not consider anything equal to Him. God has not appointed you to watch over them nor are you their guardian.

# 897

Believers, do not say bad words against the idols lest they (pagans) in their hostility and ignorance say such words against God. We have made every nation's deeds seem attractive to them. One day they will all return to their Lord who will inform them of all that they have done.

# 898

The unbelievers solemnly swear by God that if they were to be shown some miracle, they would certainly believe. (Muhammad), tell them, "Only with God are all the miracles." Even if a miracle was to take place, they still would not believe.

# 899

We will turn their hearts and vision away (from a miracle); they did not have faith (in miracles) at the first time, and We will leave them blind in their rebellion.

# 900

Had We sent the angels to them, made the dead speak to them, and resurrected all things before their very eyes, they still would not believe unless God willed it to be so. But, in fact, most of them ignore (the evidence).

# 901

We have made devilish enemies for every Prophet from among people and jinn. They whisper attractive but and deceitful words to each other. Had your Lord wanted, the devils would not have seduced people. Keep away from them and the falsehood which they invent.

# 902

Let those who do not believe in the Day of Judgment listen to the deceitful words with pleasure and indulge in whatever sins they want.

# 903

(Muhammad), say, "Should I seek any judge other than God? It is He Who has revealed this Book (Quran) to you with all its intricate details." Those to whom We have given the Bible know that the Quran has been revealed to you from your Lord in all Truth. Thus, you (people) must have no doubts about it.

# 904

(After having revealed the Quran to you) in all truth and justice, your Lord's Word has been completed. No one can change His Words. He is All-hearing and All-knowing.

# 905

Most of the people in the land will lead you away from God's guidance if you follow them; they only follow their own conjecture and preach falsehood.

# 906

Your Lord knows best those who have gone astray from His path and those who are rightly guided.

# 907

If you have faith in God's revelations, eat the flesh of the animal which has been slaughtered with a mention of His Name.

# 908

Why should you not eat such flesh when God has told you in detail what is unlawful to eat under normal conditions. Most people, out of ignorance, are led astray by their desires. Your Lord knows best those who transgress.

# 909

Stay away from both public and secret sins for a sinner will suffer for whatever he has committed.

# 910

Do not eat the flesh of an animal which has been slaughtered without a mention of the Name of God; it is a sinful deed. Satan teaches his friends to argue with you. If you obey them, you will certainly be idol worshippers.

# 911

Can the dead to whom We have given life and light so that they may walk among the people, be considered equal to those who can never come out of darkness? The deeds of the unbelievers are made to seem attractive to them.

# 912

In every town We have placed some sinful leaders who always make evil plans. These plans will only work against their own souls but they do not realize this.

# 913

When a miracle is shown to them, they say, "We will not believe unless we are shown a miracle like that shown to the messengers of God." God knows best whom to appoint as His Messenger. The sinful ones are worthless in the sight of God and they deserve a severe punishment for their evil plans.

# 914

God will open the hearts of whomever He wants to guide to Islam, but He will tighten the chest of one whom He has led astray, as though he was climbing high up into the sky. Thus, God places wickedness on those who do not accept the faith.

# 915

This is the path of your Lord and it is straight. We have explained Our revelations to those who take heed.

# 916

They will live in peace with God. God protects them as a reward for their deeds; He is their Guardian.

# 917

On the day when every one will be resurrected and the jinn will be told that they have made many people go astray, their friends from among people will say, "Lord, we benefitted from each other until death approached us." They will be told that their dwelling will be fire wherein they will live forever unless God wills it to be otherwise. Your Lord is All-wise and All-knowing.

# 918

Thus do We make the unjust friends of one another because of their evil deeds.

# 919

When people and jinn are asked, "Did not Messengers from your own people come to you to convey Our revelations and to warn you of the Day of Resurrection?" They will reply, "(Yes indeed)." The worldly life deceived them. They will testify that they were unbelievers.

# 920

Your Lord did not want to destroy the towns, unjustly, without informing their inhabitants (of His guidance).

# 921

People's deeds are of different degrees and your Lord is not unaware of what people do.

# 922

Your Lord is Self-sufficient and Merciful. Had He wanted, He could have destroyed you and replaced you by other people, just as He had created you from the offspring of others.

# 923

Whatever you are promised will inevitably come true and you can do nothing to prevent it.

# 924

(Muhammad), tell your people, "I shall do whatever I can and you may do whatever you want, but you will soon know who will be victorious. It is certain that the unjust will never have happiness."

# 925

They set aside a share of the left-overs of their farming produce and cattle saying, "This is for God and that is for the idols." God does not receive the share of the idols but the share of God is given totally to the idols. How terrible is their decision!

# 926

To many of the pagans, the murder of their children was made to seem attractive by the idols. This led them (the pagans) to confusion in their religion and to face their own destruction. Had God wanted, they would not have murdered their children. Keep away from them and their evil gains.

# 927

They, (the pagans), have said that their cattle and farms are dedicated to private idols and that no one can consume (the produce) except those whom We wanted, in their opinion. They prohibited the riding of certain animals and they ate the flesh of certain animals slaughtered without a mention of the Name of God. Instead, they ascribed falsehood to Him. They will all be given an evil recompense for their sinful invention.

# 928

They have also said, "Whatever exists in the wombs of these animals belongs to our people alone and it is not lawful for our women." However, if they are born dead, then everyone will have a share. God will give them what they deserve for (their unjust laws). God is All-merciful and All-knowing.

# 929

Those who foolishly and ignorantly murdered their children, ascribed falsehood to God and made unlawful what He had given to them for their sustenance, have certainly lost much. They had gone far away from the right guidance.

# 930

It is He who has created all kinds of gardens, those raised on trellises and those without, palm-trees and the crops of different seasons, and olives and pomegranates of all types. You may eat their fruits that they produce but pay God's share on the harvest day. Do not be excessive for God does not love those who are excessive.

# 931

God has created animals, both small and large. Eat from what God has given you for your sustenance and do not follow in the footsteps of Satan. He is your sworn enemy.

# 932

(Supposing) that there are eight pairs of cattle, two pairs of sheep, and two pairs of goats. Tell Me (which is lawful and which is not)? Are the two males unlawful (to eat) or the two females or those that are in the wombs of the females? If you are truthful, then, answer Me exactly.

# 933

Of the two pairs of camels and cows, are the males unlawful (to eat) or the females or that which exists in the wombs of the females? Were you present when God commanded you to do this? Who are more unjust than those who ascribe falsehood to God and out of ignorance make others go astray? God does not guide the unjust.

# 934

(Muhammad), tell them, "I do not find anything which has been made unlawful to eat in what has been revealed to me except carrion, blood flowing from the body, pork \[for pork is absolutely filthy\] and the flesh of the animals slaughtered without the mention of the name of God. However, in an emergency, when one does not have any intention of rebelling or transgressing against the law, your Lord will be All-forgiving and All-merciful.

# 935

We made unlawful for the Jews all the claw-footed animals, fat of the cows, sheep and goats except what is found on their backs, intestines and whatever is mixed with their bones. Thus, did We recompense them for their rebellion and We are certainly truthful.

# 936

They reject you. (Muhammad), tell them, "Your Lord's mercy is completely overwhelming, but no one can save the sinful from His wrath."

# 937

The pagans will say, "Had God wanted, we would not have worshipped idols, nor would our fathers, nor would we have made anything unlawful." Others before them had also spoken such lies until they experienced the severity of Our wrath. (Muhammad), ask them, "Do you possess any knowledge? If so, tell us about it. You follow only conjectures and preach falsehood."

# 938

Say, "Final authority belongs only to God. Had He wanted, He would have given you all guidance".

# 939

Ask them to call their witness who will testify that God has made certain things unlawful. Even if they do testify, do not testify with them. Do not follow the desires of those who have rejected Our revelations and the pagans who do not believe in the Day of Judgment.

# 940

(Muhammad), say, "Let me tell you about what your Lord has commanded: Do not consider anything equal to God; Be kind to your parents; Do not murder your children out of fear of poverty, for We give sustenance to you and to them. Do not even approach indecency either in public or in private. Take not a life which God has made sacred except by way of justice and law. Thus does He command you that you may learn wisdom.

# 941

Do not handle the property of the orphans except with a good reason until they become mature and strong. Maintain equality in your dealings by the means of measurement and balance. No soul is responsible for what is beyond it's ability. Be just in your words, even if the party involved is one of your relatives and keep your promise with God. Thus does your Lord guide you so that you may take heed.

# 942

This is My path and it is straight. Follow it and not other paths which will lead you far away from the path of God. Thus does God guide you so that you may become pious.

# 943

We gave Moses the Book to complete (Our favor) for the righteous ones, the Book that contained a detailed explanation of all things, a guide and a mercy so that perhaps they would have faith in the Day of Judgment.

# 944

This Book (Quran) which We have revealed is a blessed one. Follow its guidance and have piety so that you perhaps may receive mercy

# 945

and will not say that the Book was revealed only to two groups of people before you, or that you were ignorant of its knowledge,

# 946

or proclaim, "Had the Book been revealed to us, we would have followed its guidance better than the (Jews and Christians). Evidence, guidance, and mercy have already come to you from your Lord. Who are more unjust than those who reject God's revelations and turn away from them? We will give an evil recompense to those who turn away from Our revelations and a terrible torment for their disregard (of Our guidance)

# 947

Are they waiting until the angels or your Lord come to them or for some miracles to take place? On the day when some miracles of God will take place, the belief of any soul will be of no avail to it unless some good deeds have been done with it, or it has been formed before the coming of such a day. (Muhammad), tell them, "Wait and we, too, are waiting."

# 948

Some of those who have divided their religion into different sects are not your concern. Their affairs are in the hands of God Who will show them all that they have done.

# 949

For a single good deed, one will be rewarded tenfold. But the recompense for a bad deed will be equal to that of the deed and no injustice will be done to anyone.

# 950

(Muhammad), tell them, "My Lord has guided me to the right path, a well established religion and the upright tradition of Abraham who was not a pagan".

# 951

Say, "My prayer, sacrifice, life, and death are all for God, the Lord of the Universe.

# 952

Nothing is equal to Him. Thus are the commandments which I have received and he is the first Muslim (submitted to the will of God)."

# 953

(Muhammad), tell them, "Should I take a lord besides God when He is the Lord of all things?" All one's evil deeds are against one's own soul. No one will be considered responsible for another's sins. You will all be returned to your Lord who will tell you what is right and wrong in disputed matters among you.

# 954

On earth, We have made each of your generations the successors of their predecessors; We have made some of you do good deeds of a higher degree than others. He will test you in this way through what He has revealed to you. Your Lord's retribution is swift and He is certainly All-forgiving and All-merciful.

# 955

Alif. Lam. Mim. Sad.

# 956

A book has been revealed to you, (Muhammad). You should not hesitate to convey its warning and its good advice to the believers.

# 957

(People), follow whatever is revealed to you from your Lord and do not follow other guardians besides Him. However, you pay very little attention (to Our words)

# 958

How many cities have We destroyed! Our wrath struck their people at night or during their midday siesta.

# 959

When Our wrath struck them, they could do nothing but confess to their sins.

# 960

We will certainly question the people and the Messengers sent to them.

# 961

We will tell them with absolute certainty (what they had done) for We had never been absent from them (during their lifetime).

# 962

(Everyone's deeds) will certainly be weighed (and evaluated) on the Day of Judgment. Those whose good deeds weigh heavier than their bad deeds will have everlasting happiness.

# 963

As for those whose bad deeds weigh heavier, they will lose their souls for their injustice to Our revelations.

# 964

We have made you inhabit the land and provided you with the means of sustenance. Only a few of you give thanks.

# 965

We created and shaped you, then told the angels to prostrate themselves before Adam. All the angels obeyed except Satan who did not.

# 966

God asked, "What made you disobey Me?" Satan replied, "I am better than Adam, for You have created me out of fire and Adam out of clay."

# 967

The Lord ordered Satan to get out (of Paradise) saying, "This is no place for you to be proud. Get out of this place, for you are worthless".

# 968

Satan asked the Lord to give him respite (keep him alive) until the Day of Resurrection.

# 969

The Lord told him, "We will grant you this respite."

# 970

Then Satan said, "Because you have made me go astray, I shall certainly try to seduce people into straying from the right path.

# 971

I shall attack them from all directions and You will not find many of them giving You thanks".

# 972

The Lord told Satan, "Get out of this garden, for you are banished and despised. Hell will be filled with all of those who follow you."

# 973

Then the Lord said, "Adam, stay in the garden with your spouse and eat whatever you want therein, but do not go near this tree lest you transgress".

# 974

Satan tempted them to reveal that which was kept private from them and said, "Your Lord has not prohibited you (to eat the fruits of this tree) unless you want to be angels or immortal."

# 975

Satan swore before them that he was giving them good advice.

# 976

Thus, he deceitfully showed them (the tree). When they had tasted (fruits) from the tree, their private parts became revealed to them and they began to cover their private parts with leaves from the garden. Their Lord then called out to them saying, "Did I not forbid you to eat (fruits) from the tree and tell you that Satan was your sworn enemy?"

# 977

They replied, "Lord, we have done injustice to our souls. If You will not forgive us and have mercy on us, we shall certainly have incurred a great loss."

# 978

The Lord told them to leave the garden as each other's enemies and go to earth to dwell and benefit from the means therein for an appointed time.

# 979

He told them that, on earth, they would live, die, and be resurrected.

# 980

Children of Adam, We have given you clothing to cover your private parts and for beauty, but the robe of piety is the best. Thus is the guidance of God so that you may take heed.

# 981

Children of Adam, do not let Satan seduce you, as he caused your parents to be expelled from the garden and made them take off their clothes in order to show them their private parts. Satan and those like him see you but you do not see them. We have made the Satans as friends for those who have no faith.

# 982

When (The faithless) commit indecent acts they say, "We found our fathers doing this and God has commanded us to do the same." (Muhammad) tell them that God does not command anyone to commit indecency. Do you speak for God, saying things of which you have no knowledge?

# 983

Say, "My Lord has ordered me to maintain justice. (People), pay due attention (when worshipping God). Pray to Him sincerely and be devoted in your religion. Just as He gave you life, He will bring you back to life again (after you die.)"

# 984

He has guided one group (of people) and the other group go is doomed to astray; the latter group took Satan as their guardian instead of God and thought that they were rightly guided.

# 985

Children of Adam, dress well when attending the mosques, eat and drink but do not be excessive for God does not love those who are excessive (in what they do).

# 986

(Muhammad), ask them, "Who has made it unlawful to maintain beauty and to eat the pure foods which God has created for His servants? They are made for the believers in this world and are exclusively for them in the life hereafter." Thus do We explain Our revelations to the people who have knowledge.

# 987

(Muhammad), tell them, "My Lord has only prohibited indecent acts committed in public or in secret, all sins, unjust rebellion, considering things equal to God without any heavenly authority, and speaking for God without having any knowledge (of what He has said)."

# 988

All people can only live for an appointed time. When their term ends, they will not remain (alive) even for a single hour, nor will they die before the appointed time.

# 989

Children of Adam, when Messengers from among your own people come to you to preach My revelations, those who choose piety and reform themselves will have nothing to fear nor will they be grieved.

# 990

But those who have rejected Our revelations out of pride will be the dwellers of hell fire wherein they will live forever.

# 991

Who are more unjust than those who invent falsehoods against God and reject His revelations? These will have their share (of torment) which is ordained for them and when Our (angelic) Messengers come to them to cause them to die and ask them, "Where are those whom you had been worshipping besides God?" they will reply, "We had gone astray from the path of God." Thus, they will testify against their own souls by confessing their disbelief.

# 992

(On the Day of Judgment) the Lord will say to them, "Join the group of jinn and people who lived before you, in hell." Each group, on entering hell, will curse the other dwellers, until all of them are brought together therein. The last group will accuse the first saying, "Lord, they made us go astray. Therefore, double their torment in the Fire." The Lord will reply, "For everyone of you there is a double torment, but you do not know it".

# 993

The first will then say, "You are no better than us; suffer the torment as the result of your deeds.

# 994

For those who have rejected Our revelations out of pride, no door to the heavens will be opened, nor will they be admitted into Paradise until a camel passes through the eye of a sewing needle. Thus do We recompense the criminals.

# 995

For them, hell will be both a cradle and a blanket. Thus do We punish the unjust.

# 996

The righteously striving believers - We do not impose on any soul that which is beyond its ability - are the dwellers of Paradise wherein they will live forever.

# 997

We shall remove all grudges from their hearts. They will enjoy the flowing streams in the garden and will say, "God who guided us to this, deserves all praise. Had He not guided us, we would never have been able to find the right direction. The (angelic) Messengers of our Lord came to us with the Truth." They shall be told, 'This is the Paradise which you have inherited because of your good deeds."

# 998

The people of Paradise will say to the dwellers of the fire, "We have found whatever our Lord promised has come true. Have you found whatever the Lord promised you to be true?" They will reply, "Yes, we have also found it to be true." Thereupon, someone will cry out, "God has condemned the unjust,

# 999

who prevented others from the way of God, sought to make (the path) appear crooked, and had no belief in the Day of Judgment."

# 1000

There will be a barrier between the people of Paradise and hell. There will be people on the heights who know everyone by their faces and who will say to the people of Paradise, "Peace be upon you." They hope to enter Paradise but are not yet therein.

# 1001

When their eyes turn to the dwellers of hell, they will pray, "Lord, do not place us among the unjust."

# 1002

The people of the Heights will say to those (in hell) whose faces they recognize, "Why did your supporters and your pride not help you?"

# 1003

They will also say, "Are these (the people of Paradise) the ones of whom you swore would receive no mercy from God?" They will continue, " People of Paradise, live therein without any fear or grief."

# 1004

The dwellers of the fire will ask the people of Paradise to give them some water or other things which God has granted to them. They will reply, "God has deprived the unbelievers of the blessings of Paradise."

# 1005

On that Day We will neglect those who were deceived by the worldly life and who treated their religion as a useless game, because they had forgotten such a day and rejected Our revelations.

# 1006

We have revealed the Book of guidance and mercy to the believers and We know all of its details.

# 1007

(Despite the clear details of Our guidance in the Book) do they still wait for further interpretations? On the Day (of Judgment) when its interpretations will be revealed, those who had ignored its guidance will confess, saying, "The Messengers of our Lord had certainly come to us with the Truth. Will anyone intercede for us or send us back (to life) so that we would be able to act in a different manner to that which we had done before?" These people have certainly lost their souls and their evil inventions (which they had used for false excuses) will vanish.

# 1008

Your Lord is God who established His dominion over the Throne (of the realm) after having created the heavens and the earth in six days. He made the night darken the day which it pursues at a (considerable) speed and He made the sun and the moon submissive to His command. Is it not He Who creates and governs all things? Blessed is God, the Cherisher of the Universe.

# 1009

Pray to your Lord humbly and privately. God does not love the transgressors.

# 1010

Do not destroy the land after it has been well established but pray to God, have fear of Him, and hope to receive His mercy. God's mercy is close to the righteous people.

# 1011

God sends the wind bearing the glad news of His mercy. When heavy clouds are formed, We drive them unto a barren country and rain down on it water to cause all kinds of fruits to grow. In the same way do We bring the dead to life again. Perhaps you would take heed.

# 1012

A good land produces plants, by the permission of its Lord, but a wicked land produces only miserable, bitter plants. Thus do We show a variety of evidence for those who give thanks.

# 1013

We sent Noah to his people. He told them, "Worship God for He is your only Lord. I am afraid of the punishment that you might suffer on the great Day (of Judgment)".

# 1014

A group of his people said to him, "You are absolutely wrong."

# 1015

(Noah) said, "My people, I am not in any error, rather I am a Messenger from the Lord of the Universe,

# 1016

sent to preach to you the message of my Lord and to give you good advice. I know what you do not know about God.

# 1017

Does it seem strange to you that a reminder from your Lord should be sent to a man, from among you, to warn you so that you might receive mercy?"

# 1018

They accused him of telling lies. So We saved him and his companions in an ark and drowned those who called Our revelations mere lies. They were, no doubt, a blind people.

# 1019

We sent Hud to his brethren, the tribe of \`Ad, who told them, "Worship God for He is your only Lord. Will you not become pious?"

# 1020

A group of the unbelievers among his people said, "You look to us like a fool and we think that you are a liar".

# 1021

He replied, "My people, I am not a fool but a Messenger of the Lord of the Universe.

# 1022

I preach the message of my Lord to you and am a trustworthy advisor for you.

# 1023

Does it seem strange to you that a reminder from your Lord should be sent to a man among you so that He may warn you? Recall when God appointed you as successors of the people of Noah and increased your power over other people. Give thanks to God for His blessings so that perhaps you will have everlasting happiness."

# 1024

They said, "Have you come to make us worship God alone and give up what our fathers worshipped? If you are truthful, let the torment with which you have threatened us, strike us".

# 1025

He replied, "You will certainly be afflicted by wickedness and the wrath of God. Do you dispute with me about the names of that which you and your fathers have invented? God has given no authority to those names. Wait for God's decree and I, too, am waiting with you."

# 1026

Through Our mercy, We saved him and his companions and destroyed the unbelievers who called Our revelations mere lies.

# 1027

We sent Salih to his brethren, the tribe of Thamud, who told them, "Worship God your only Lord. Authoritative evidence has come to you from your Lord and this she-camel is the evidence for you from God. Let her graze in the land of God. Do not give her any trouble lest a painful torment will strike you.

# 1028

Recall (the time) when We settled you in the land as the heirs of the tribe of Ad and how you established mansions in the plains and carved homes out of the mountains. Give thanks to God for His favors and do not commit evil in the land."

# 1029

The proud ones among Salih's people asked his oppressed followers, "Do you (really) know that Salih is a Messenger of his Lord?" They replied, "We have faith in the Message which he preaches".

# 1030

The proud oppressors said, "We reject that which you believe in".

# 1031

They then slew the camel and rebelled against the orders of their Lord saying, " Salih, if you are truly a Messenger, let that torment with which you have threatened us come to pass."

# 1032

Suddenly, an earthquake jolted them and they were left motionless in their homes.

# 1033

He turned away from them saying, "My people, I preached the Message of my Lord to you and gave you good advice, but you do not love advisors."

# 1034

Lot told his people, "Why do you commit such indecent acts that have never been committed by anyone before?

# 1035

You engage in lustful activities with people instead of women. You have become transgressing people.

# 1036

His people had no answer to his remarks but to tell one another, "Expel him from our town; he and his people want to purify themselves."

# 1037

We saved (Lot) and his family except his wife who remained with the rest.

# 1038

We sent a torrential rain unto the (unbelievers). Consider how disastrous the end of the criminals was!

# 1039

We sent to the people of Midian their brother Shu'ayb who also told his people to worship God their only Lord. He said, "A guidance has come to you from your Lord. Maintain proper measures and weights in trade. Do not cause any deficiency in people's property or destroy the land after it has been reformed. This is for your own good, if you have any faith.

# 1040

Do not ambush the believers or hinder them from every path that leads them to God just because you wish to make such ways seem crooked. Recall the time when you were just a few in number and God multiplied you. Consider how terrible the end of the evil-doers was!

# 1041

If there are some of you who believe in the Message that I have been commanded to preach and there are others who do not, exercise patience until God judges among us. He is the best Judge."

# 1042

A proud group among Shu'ayb's people said, "We must expel you (Shu'ayb) and your followers from our town unless you give-up your faith and live as our own people." Shu'ayb asked them, "Will you use force against us?

# 1043

We would certainly be inventing falsehoods against God if we were to accept your way of life, when God has already saved us from it. We do not have to accept it unless God, our Lord, wills it. Our Lord's knowledge covers all things. We trust in Him and ask Him to judge among us and our people, for He is the best Judge."

# 1044

A group of the unbelievers among his people told the others, "If you follow Shu'ayb, you will certainly lose a great deal."

# 1045

Suddenly, an earthquake struck them and left them motionless in their homes.

# 1046

Those who called Shu'ayb a liar were destroyed as though they never existed. They certainly were the ones to lose a great deal.

# 1047

He turned away from them saying, "My people, I preached the Message of my Lord to you and gave you good advice. How could I be sorry for the unbelievers?"

# 1048

To every town that We sent a Prophet, We tested its inhabitants through distress and adversity so that perhaps they would submit themselves to Us.

# 1049

We then replaced their misfortune with well-being until they were relieved and began saying, "Our fathers had also experienced good and bad days." Suddenly, We struck them (with torment) while they were all unaware (of what was happening).

# 1050

Had the people of the towns believed (in Our revelations) and maintained piety, We would have certainly showered on them Our blessings from the sky and the earth. But they called Our revelations lies, thus Our torment struck them for their evil deeds.

# 1051

Did the people of the towns think themselves secure from Our wrath that could strike them at night during their sleep

# 1052

or that which could seize them during their busy hours of the day?

# 1053

Did they consider themselves secure from the retribution of God? No one can have such attitude except those who are lost.

# 1054

Is it not a lesson for the successors of the past generations that had We wanted, We could have punished them for their sins, sealed their hearts and deprived them of hearing?

# 1055

(Muhammad), such were the stories of the people who lived in (different) towns in the past. We had sent Our Messengers to them with (certain) miracles but the people still did not believe in what they had rejected before. Such is how God seals the hearts of the unbelievers.

# 1056

We did not find many among them keeping their promises. However, We did find many evil-doers among them.

# 1057

After the time of those people, We sent Moses with Our miracles to Pharaoh and his people, but they too rejected Our miracles. Consider, how terrible the end of the evil-doers is!

# 1058

Moses told the Pharaoh, "I am a Messengers from the Lord of the Universe.

# 1059

I must only speak what is true about God. I have brought you miracles from your Lord; therefore, let the children of Israel go free".

# 1060

The Pharaoh asked Moses to show his miracles if he was telling the truth.

# 1061

So Moses threw down his staff and suddenly it turned into a real serpent.

# 1062

Then he uncovered his hand and it appeared sheer white to the onlookers.

# 1063

Some of the Pharaoh's nobles considered him to be no more than a skillful magician

# 1064

and said, "He wants to expel you from your land." They asked (others), " what is your opinion in the matter?

# 1065

The others suggested holding Moses and his brother off and sending to all the cities

# 1066

to bring together at the Pharaohs court all the skillful magicians.

# 1067

The magicians came to the Pharaoh and said, "We must have our reward if we are to gain a victory over him (Moses)".

# 1068

The Pharaoh replied, "In addition to your rewards, you will become my close friends thereafter."

# 1069

The magicians asked Moses, "Will you throw your staff first or shall we?"

# 1070

He replied, "Throw yours first." Their great magic bewitched people's eyes and terrified them.

# 1071

We inspired Moses to throw his staff, and suddenly it began to swallow-up all that the magicians had (falsely) invented.

# 1072

Thus the Truth prevailed and their false art was banished.

# 1073

The magicians who were defeated on the spot and were proved to be worthless,

# 1074

threw themselves down in prostration

# 1075

saying, "We declare our belief in the Lord of the Universe,

# 1076

the Lord of Moses and Aaron."

# 1077

The Pharaoh said to the magicians, "You declared your belief in him (Moses) without my permission. This is a plot to throw my people out of their city. But you will soon know.

# 1078

I will cut off your hands and feet on the alternate sides and crucify you all."

# 1079

The magicians said, "We will certainly return to Our Lord.

# 1080

You only take revenge on us because we believed in the Lord when we saw His miracles. Lord, grant us patience and let us die Muslims (submitted to God)."

# 1081

Some of the Pharaohs people said, "Will you let Moses and his people destroy the land and disregard you and your gods?" The Pharaoh said, "We will kill their sons and leave their women alive; they are under our domination."

# 1082

Moses told his people to seek help from God and exercise patience. The earth belongs to Him and He has made it the heritage of whichever of His servants He chooses. The final victory is for the pious ones.

# 1083

His people said, "We suffered a great deal before you came and we are still suffering even after you have come." Moses (tried to encourage them) by saying, "There is hope that your Lord will destroy your enemies and make you (their) successors in the land. So consider how you act."

# 1084

For years We afflicted Pharaoh's people with shortages in food so that perhaps they would take heed.

# 1085

But they would always ascribe their well-being to themselves and the misfortunes that they would experience to Moses and his people. Their fate is certainly in the hands of God but many of them do not know.

# 1086

They said to Moses, "No matter what miracle you show to bewitch us, we will not believe you."

# 1087

We sent upon them widespread calamities: floods of locusts, lice, frogs, and blood. All were distinct miracles but these criminals all the time remained proud.

# 1088

When the torment would strike them, they would ask Moses, "Pray for us to your Lord through your covenant with Him. If He saves us from the torment, we shall certainly believe in you and permit you and the children of Israel to leave".

# 1089

But when We relieved them from the torment for a given time, they again broke their promise.

# 1090

We took revenge on them for their rejecting Our miracles, by drowning them in the sea, but they were not aware of (reality).

# 1091

We gave the suppressed people the blessed eastern and western regions as their inheritance. Thus, the promises of your Lord to the children of Israel all came true because of the patience which they exercised. He destroyed all the establishments of the Pharaoh and his people.

# 1092

We helped the children of Israel to cross the sea. They came to a people who worshipped idols. The Israelites demanded Moses to make gods for them like those of the idol-worshippers. Moses told them, "You are an ignorant people.

# 1093

What these people worship is doomed to be destroyed and their deeds are based on falsehood.

# 1094

Should I choose for you a lord other than God who has favored you above all other people?

# 1095

"Children of Israel, when I saved you from the Pharaoh and his people who made you suffer the worst kinds of torment, killing your sons and keeping your women alive, it was a great trial for you from your Lord."

# 1096

We told Moses to stay with Us for thirty nights (in the mountains) but added ten nights more so his appointment with his Lord came to an end after forty nights. Moses had appointed his brother Aaron as his deputy among his people during his absence saying, "Try to reform them and do not follow the way of the evil-doers."

# 1097

During the appointment, the Lord spoke to Moses. He asked the Lord to show Himself so that he could look at Him. The Lord replied, "You can never see Me. But look at the mountain. If the mountain remains firm only then will you see Me." When the Lord manifested His Glory to the mountain, He turned it into dust and Moses fell down upon his face senseless. After regaining his senses, Moses said, "Lord, You are all Holy. I repent for what I asked you to do and I am the first to believe in You."

# 1098

The Lord said to Moses, "I have given you distinction above the people by speaking to you and giving you My Message. Receive what I have given to you and give Us thanks."

# 1099

We wrote advice and laws for him on Tablets about all kinds of things, saying, "Follow them and command your people to follow the good advice therein, and I will show you the dwellings of the evil-doers."

# 1100

We will deprive those who are wrongly proud in the land of the blessing of revelations. Even if they would see all kinds of miracles, they would not have faith, or even to see the right path, they would not follow it. They would follow the rebellious way if they were to find one; in their ignorance, they have called Our revelations mere lies.

# 1101

The deeds of those who have called Our revelations and belief in the Day of Judgment mere lies, will be turned devoid of all virtue. Can they expect to receive a reward for their deeds other than that which is the result of their deeds?

# 1102

In Moses' absence, his people manufactured a hollow sounding calf out of their ornaments. Could they not see that it could not speak to them or provide them with any guidance? They gained only evil by worshipping the calf.

# 1103

When they found that they had believed in the wrong thing, they regretfully said, "If our Lord will not have mercy on us and forgive us, we will certainly be lost."

# 1104

When Moses returned to his people with anger and sorrow, he said, "What you have done in my absence is certainly evil. Why were you hasty about the commandments of your Lord?" He threw away the Tablets (which contained the commandments of God), grabbed his brother and started to pull him to himself. His brother begged him saying, "Son of my mother, the people suppressed me and almost killed me. Do not humiliate me before the enemies or call me unjust".

# 1105

Moses prayed, "Lord, forgive me and my brother and admit us into Your mercy; you are the most Merciful."

# 1106

(The Lord said), "Those who worshipped the calf will be afflicted by the wrath of their Lord and disgraced in their worldly life. Thus, We will recompense those who invent falsehood.

# 1107

To those who commit bad deeds, but, then, repent and believe (in God), Your Lord will certainly be All-forgiving and All-merciful."

# 1108

When Moses' anger calmed down, he collected the Tablets. On one of them was written, "God's mercy and guidance are for those who have fear of Him."

# 1109

Moses selected seventy men from his people to attend Our appointment. (In Our presence). When an earthquake jolted them to death, Moses said, "Lord, had You wanted to destroy them, why did You not destroy them and me before. Are You destroying us for what the fools among us have done? This (destruction) is only a trial through which You cause some to go astray and guide others. You are our Guardian. Forgive us and have mercy on us; You are the best of those who forgive.

# 1110

"Grant us well-being in this life and in the life hereafter for we have turned ourselves to You." The Lord replied, "My torment only afflicts those whom I want to punish, but My mercy encompasses all things. I shall grant mercy to those who maintain piety, pay their religious tax, and those who have faith in Our revelations."

# 1111

There are those who follow the Messengers, the illiterate Prophet (not conventionally educated), whose description they find written in the Torah and the Gospel. \[He (the Messengers) enjoins them to do good and forbids them to do all that is unlawful, makes lawful for them all that is pure and unlawful all that is filthy, removes their burdens and the entanglements in which they are involved\]. Those who believe in him, honor and help him, and follow the light which is sent down to him, will have everlasting happiness.

# 1112

(Muhammad), tell them, "People, I have come to you all as the Messengers of God, to whom the Kingdom of the heavens and the earth belongs. There is no God but He. In His hands are life and death. Have faith in God and His Messengers, the unlettered Prophet who believes in God and His words. Follow him so that you will perhaps have guidance."

# 1113

Among the people of Moses are some whose guidance and Judgment are based on the Truth.

# 1114

We divided the descendants of Israel into twelve tribes and told Moses to strike the rock with his staff to let twelve fountains gush out therefrom; his people had asked him to supply them with water. The twelve flowing springs were divided among them (a spring for each tribe) and each tribe knew its drinking place well. We provided them with shade from the clouds, sent down manna and quails to them for food, and told them to eat the pure things which We had given them. They did not do injustice to Us but they wronged themselves.

# 1115

When they were told, "Settle down in this town, eat as you wish, seek forgiveness and enter the gate prostrating yourselves (in obedience to the Lord) and We will forgive you your sins and increase the reward of the righteous people,

# 1116

the unjust among them changed the words which they were told to say (in the prayer). Therefore, We sent upon them torment from the sky for their wrong deeds.

# 1117

(Muhammad), ask them about the (people of the) towns on the seashore. They had transgressed by catching fish on the Sabbath. Each Sabbath the fish came openly within their reach but not so on other days. Thus, We were testing them because of their evil deeds.

# 1118

When a group of them questioned another group saying, "Why do you preach to those whom God has decided to destroy or punish by a severe torment?" they replied, "We preach to them for we are responsible in the sight of your Lord and so that perhaps they may have fear of God."

# 1119

When they (the unjust people) forgot what was preached to them, We saved the preachers from evil and afflicted the unjust for their evil deeds, with a dreadful torment.

# 1120

When they crossed the limit of the prohibition, We made them turn into detested apes.

# 1121

(Muhammad), consider, when your Lord declared to the (Israelites) His decision to raise a people above them who would make them suffer the worst kinds of torments until the Day of Judgment. Certainly your Lord's retribution is swift. He is All-forgiving and All-merciful.

# 1122

We divided them into nations on the earth; some are righteous and others are not. We tested them with well-being and hardship so that they might return (to the right path).

# 1123

Their descendants who inherited the Book gained (by bribery only) worthless things from the worldly life saying, "We shall be forgiven (for what we have done). They would have even doubled such gains if they could have received more. Did they not make a covenant (with God) in the Book not to speak any thing other than the Truth about God and to study its contents well? The life hereafter is much better for the pious ones. Will you not then think?

# 1124

Those who devote themselves to the teachings of the Book and are steadfast in prayer (should know that) the reward of those who reform themselves will not be lost.

# 1125

When We raised the mount above them as a shadow and made it speak to them, they thought that it would fall on them. We told them to devote themselves decisively to what was given to them and follow its guidance so that they would have fear of God.

# 1126

When your Lord asked all the offspring of Adam (before their birth), "Am I not your Lord?" All of them testified and bore witness to their testimony that on the Day of Judgment they would not say, "We were not aware of this (fact),"

# 1127

or say, "Our fathers worshipped idols before us and we as their descendants followed them. Would you then destroy us because of what the followers of falsehood have done?"

# 1128

Thus do We explain Our revelations so that they might return to (the right path).

# 1129

(Muhammad), tell them the story of the person whom We inspired with Our guidance, but who detached himself from it and who was then pursued by Satan until he turned into a rebel.

# 1130

Had We wanted, We could have raised him to an exalted position but he clung to his earthly life and followed his own (evil) desires. Such person's bad habits are like those of a lazy dog (in a warm climate) who always has its tongue hanging out whether you chase it away or leave it alone. Such are the people who have called Our revelations mere lies. (Muhammad), tell them such stories so that perhaps they will think.

# 1131

How terrible is the example of those who have rejected Our revelations and have done injustice only to themselves!

# 1132

Those whom God has guided have the true guidance, but those whom He has caused to go astray are certainly lost.

# 1133

We have destined many men and jinn for hell. They have hearts but do not understand, eyes but do not see. They have ears but do not hear. They are worse than lost cattle. These are the heedless ones.

# 1134

God has the most blessed Names. You should address Him in your worship by these Names and keep away from those who pervert them. They will be recompensed for their (evil) deeds.

# 1135

Among Our creatures are a group who guide and judge with the Truth.

# 1136

We gradually lead those who have called Our revelations mere lies, to destruction. Their destruction will be such that they will not even notice how it seized them.

# 1137

Though I have given them a respite, My plan against them is well established.

# 1138

Why will they not understand that their companion (Muhammad) is not possessed by jinn. (Muhammad) is only a (Divinely) authorized preacher.

# 1139

Have they not considered the Kingdom of the heavens and the earth and everything that God has created? Perhaps death approaches them. In what kind of guidance can they have faith besides that of the Quran?

# 1140

No one can guide those whom God has caused to go astray and has left to continue blindly in their rebellion.

# 1141

They ask you (Muhammad), "When will the Day of Judgment be?" Tell them, "My Lord knows best. It is He who has appointed its time. It will be a grave hour both in the heavens and the earth. It will only approach you suddenly." They say, "It seems that you know about the coming of the Day of Judgment." Tell them, "Only God knows about it and most people do not know."

# 1142

(Muhammad), say, "I have no control over my benefits or sufferings, without the will of God. Had I known about the unseen, I would have gained much good and would have faced no suffering. I am only a warner and I preach the glad news to the believing people."

# 1143

It is God Who created you from a single soul and out of it made its spouse to bring it comfort. When he (man) engaged in carnal relations with her, she conceived a light burden which she had to carry. When the baby grew in her womb, they (husband and wife) both prayed to their Lord, "If You grant us a healthy son we shall certainly give you thanks."

# 1144

When they were given a healthy son, they began to love him as much as they loved God. God is too exalted to be loved equally to anything else.

# 1145

Do they (the pagans) consider things that do not create anything but are themselves created equal to God?

# 1146

The idols are things that are not able to help others or even themselves.

# 1147

Believers, even if you invite them to true guidance, they will not follow you. It makes no difference whether you invite them or whether you keep quiet.

# 1148

Those whom you (pagans) worship besides God, are themselves servants just like yourselves. If your claim was true, they should answer your prayers.

# 1149

Do they (the idols) have feet to walk, hands to hold things, eyes to see, and ears to hear? (Muhammad), tell them (the pagans) to call on their idols for help and to plan against Me without delay.

# 1150

The (true) Guardian is certainly God who has revealed the Book and is the Guardian of the righteous ones.

# 1151

The idols which you (the pagans) worship besides God can neither help you nor themselves.

# 1152

(Muhammad), if you invite them to the right guidance, they will not listen to you. You will see them looking at you but they do not really see.

# 1153

Have forgiveness, preach the truth, and keep away from the ignorant ones.

# 1154

If Satan will try to seduce you, seek refuge from God. God is All-hearing and All-knowing.

# 1155

When a satanic thought starts to bother the pious ones, they understand and see the light

# 1156

while their brethren ceaselessly try to drag them into error.

# 1157

If you, (Muhammad), do not show them a miracle, they will keep on insisting that you must show them one. Say, "I only follow what is revealed to me from my Lord. This (Quran) contains wisdom for you from your Lord. It contains guidance and mercy for those who have faith.

# 1158

Whenever the Quran is recited (to you), listen to it quietly so that you may receive mercy.

# 1159

Remember your Lord deep within yourselves, humbly and privately - instead of shouting out loud - (in prayer) in the mornings and evenings and do not be of the heedless ones.

# 1160

Those who are near to your Lord do not disdain from worshipping Him. They glorify Him and prostrate themselves (in obedience to Him).

# 1161

They (the believers) ask you (Muhammad) about the booty captured (from the enemies) during a war. Tell them, "It belongs to God and the Messengers. If you have faith, have fear of God. Settle the disputes among yourselves and obey God and His Messengers."

# 1162

When God is mentioned, the true believers begin to feel fear of Him in their hearts and when His revelations are recited to them their faith strengthens. In God alone do they trust.

# 1163

They are steadfast in prayer and spend part of what We have given them for the cause of God.

# 1164

Such are the true believers. Their reward from their Lord will be high ranks, forgiveness, and a generous provision.

# 1165

A group among the believers dislike (God's decree about the booty captured in war) as well as His command that you come out of your home for a truthful purpose (to fight for justice).

# 1166

Knowing it well (that a fight in which they are to take part is about to take place), they act as though they are being driven to death which they can see before their very eyes. Despite their knowledge of the truth, they still argue with you.

# 1167

When God promised to grant you (believers) victory over either one of the two groups, you wished to have control over the unarmed one. God decided to prove (to you) the truth of His promises and to destroy the unbelievers

# 1168

so that the truth would stand supreme and falsehood would exist no more, even though the criminals dislike it.

# 1169

When you (believers) begged for assistance from your Lord, He said, "I am helping you with a thousand angels, all in rows marching one after the other".

# 1170

God has sent this glad news to comfort your hearts. Victory is in the hands of God alone. God is Majestic and All-wise.

# 1171

The slumber that overcame you was from God that brought you peace. He showered water from the sky over you to clean you, remove satanic wickedness from you, strengthen your hearts, and grant you steadfastness.

# 1172

Your Lord inspired the angels saying, "I am with you. Encourage the believers. I shall cast terror into the hearts of the unbelievers and you will strike their heads and limbs;

# 1173

they have opposed God and His Messengers." For those who oppose God and His Messengers, God has prepared a severe retribution.

# 1174

We will say to them, "Endure the torment (as a consequence of your evil deeds); the unbelievers deserve nothing better than (the torment) of fire."

# 1175

Believers, do not retreat when facing the marching army of the unbelievers, for no believer will turn back at that time except for strategic reasons or to join another band.

# 1176

(Whoever deserts the believers) will incur the wrath of God and will dwell in hell, a terrible dwelling.

# 1177

It was not you (believers) but God who slew the pagans. It was not you (Muhammad) but God who threw dust at them. He did this as a favorable test for the believers. God is All-hearing and All-knowing.

# 1178

This is how God causes the (evil) plans of the unbelievers to fail.

# 1179

If you (the pagans) are looking for conquest, you certainly had a great chance (at the battle of Badr). But if you were to give up such a desire, it would be better for you. If you again wage war against Us, We will be ready for such a confrontation. Your man-power will be of no help to you no matter how much you have; God is with the believers.

# 1180

Believers, obey God and His Messengers and do not turn away from Him when you hear (His commands).

# 1181

Do not be like those who said that they have heard (the Messenger's commands) but do not pay any attention to them.

# 1182

The most wicked beasts in the sight of God are the deaf and the dumb who have no understanding.

# 1183

Had they possessed any virtue, God would certainly have made them hear. Even if God were to make them hear, they would still turn away from (the words of God).

# 1184

Believers, listen to God and the Messengers when they call you to that which gives you life. Know that God is between a man and his heart and that before Him you will all be brought together.

# 1185

Guard yourselves against discord among yourselves so that it will not mislead anyone of you, especially the unjust, and know that God's retribution is most severe.

# 1186

Recall the time when you (the believers) were only a few suppressed people in the land, afraid of being terrorized by the people. God gave you shelter, supported you with His help, and bestowed on you pure provisions so that perhaps you would give Him thanks.

# 1187

Believers, do not be dishonest to God and the Messengers or knowingly abuse your trust.

# 1188

Know that your possessions and children are a temptation for you and that God has the greatest reward (for the righteous ones).

# 1189

Believers, if you fear God, He will give you guidance, will expiate your bad deeds and forgive you. God's favors are the greatest.

# 1190

The unbelievers planned to imprison, murder or expel you (Muhammad) from your city. They make evil plans but God too plans and God's plans are the best.

# 1191

When Our revelations are recited to them (the unbelievers), they say, "We have heard them. Had we wanted, we could also have composed such statements; they are no more than ancient legends."

# 1192

They also say, "Lord, if this (Quran) is the Truth from you, shower down stones on us from the sky instead of rain or send us a painful punishment".

# 1193

God would not punish them while you were among them nor while they were asking for forgiveness.

# 1194

Why should God not punish them when they hinder people from entering the sacred mosque? They are not its true patrons. Only the righteous ones are its patrons, but most of the pagans do not know.

# 1195

Their (unbelievers) prayer at the mosque is nothing but whistling and clapping of hands. We shall tell them, "Suffer torment for your disbelief."

# 1196

The disbelievers spend their wealth to turn men away from the way of God. They will continue to spend but it will become a source of regret for them and they will be defeated (because of their evil plans). The disbelievers will be gathered all togdher in Hell.

# 1197

God will separate the wicked from the pure and will pile the wicked ones on top of one anothcr to be cast into hell. They are indeed lost.

# 1198

Muhammad, tell the unbelievers, if you give up your evil behavior, God will forgive whatever you have done in the past. But if you transgras again, your fate will be the same as that of those (unbelievers) who lived before you."

# 1199

Fight them so that idolatry will not exist any more and God's religion will stand supreme. If theygive up the idols), God will be Well Aware of what they do.

# 1200

If the (unbelievers) turn away from the faith, God is you (believers) best Guardian and best Helper.

# 1201

Know that whatever property you may gain, one fifth belongs to God, the Messenger, the kindred, orphans, the needy and those who need money while on a journey. (This is the law) if you believe in God and what We revealed to Our Servant on the Day of Distinction (Badr) when the armies confronted each other. God has power over all things.

# 1202

Recall when your army was positioned at the less defensible brink of the valley, (the pagans') army had the more defensible higher side of the valley and the caravan was led (out of your reach) below. This situation did not take place according to your previous plans, otherwise, everything would have been different. (It was God's plan) to place you in a vulnerable position, exposed to the enemy and it was His plan to lead the caravan out of your reach) so that His decree that you would be granted a victory by a miracle would become a doubtless fact and so that those who were to be destroyed would face destruction with a clear knowledge of the Truth and those who were to survive would also survive with a clear knowledge of the Truth. God is All-hearing and All-knowing.

# 1203

In your dream, God showed (the pagans' army) as being only a few in number, for if He had showed them as a great number, you would have lost courage and would have started to quarrel among yourselves concerning this matter. But God saved you from that condition; He knows what is in your hearts.

# 1204

When you met the pagans' army, God made them appear fewer in your eyes and you appear fewer in their eyes so that His miracle of granting you (an incredible) victory could easily be fulfilled. To God do all things return.

# 1205

Believers, stand firm when you meet a band of your enemy and remember God often so that you may have everlasting happiness.

# 1206

Obey God and His Messenger. Do not quarrel with each other lest you fail or lose honor. Exercise patience; God is with those who have patience.

# 1207

Do not be like those who marched out boastfully to show off their strength to people and hinder people from the way of God. God encompasses everyone's activities.

# 1208

Satan made their (pagans') deeds seem attractive to them and said to them, "No one today is more powerful than you and I am your supporter." But when the two armies confronted one another and the pagans were defeated, then satan betrayed his friends saying, "I am not with you any more; I see what you do not see and I am afraid of God." God is severe in His retribution.

# 1209

The hypocrites and those whose hearts are sick, say, "The (believers') religion has deceived them." Those who trust in God will find Him Majestic and All-wise.

# 1210

Would that you could have seen the angels taking the souls of the unbelievers away from their bodies and smiting their faces and their backs saying, "Suffer the burning torment.

# 1211

This is the result of their deeds. God is not unjust to His servants."

# 1212

The same thing happened to the people of Pharaoh and those who lived before them. They rejected the revelations of God and, because of their sins, His retribution struck them. God is All-powerful and stern in His retribution.

# 1213

God does not change the favor that He has bestowed on a nation unless that nation changes what is in its soul. God is All-hearing and All-knowing.

# 1214

Like the people of the Pharaoh and those who lived before them, (the unbelievers) rejected the revelations of God. We destroyed them for their sins and drowned the people of Pharaoh. They were all unjust.

# 1215

The most wicked creatures in the sight of God are the unbelievers who never have faith,

# 1216

who make promises but break them every time, and who have no piety.

# 1217

When you capture the (unbelievers) during a fight, teach them a lesson so that they thereafter will always be aware of the threat of your power.

# 1218

If you are afraid of the treachery of some of your allies, you may disregard your treaty with them. God does not love the treacherous ones.

# 1219

The unbelievers should not think that they can really escape Us or that they can never be defeated.

# 1220

Mobilize your (defensive) force as much as you can to frighten the enemies of God and your own enemies. This also will frighten those who are behind them whom you do not know but God knows well. Whatever you spend for the cause of God, He will give you sufficient recompense with due justice.

# 1221

If they (the unbelievers) propose peace, accept it and trust in God. God is All-hearing and All-knowing.

# 1222

If they want to deceive you, God is All-sufficient for you. It is God who supported you with His own help and with that of the believers,

# 1223

among whose hearts He has placed affection and unity. If you were to spend the wealth of the whole earth, you would not have been able to unite their hearts but God has been able to unite them. God is Majestic and All-wise.

# 1224

Prophet, God and the believers who follow you are sufficient support for you.

# 1225

Prophet, mobilize the believers for the battle. It will take only twenty of your men who are steadfast (in prayer) to defeat two hundred unbelieving men. Your two hundred men would defeat their two thousand; the unbelievers have no understanding.

# 1226

Now that God has eased your burden, He has found you to be weak. A hundred of your steadfast men would defeat two hundred of theirs and a thousand of yours would defeat two thousand of the unbelievers, by the will of God. God is with those who have patience.

# 1227

The Prophet is not supposed to take any captives to strengthen his position on the earth. You want worldly gains but God wants the life hereafter for you. God is Majestic and All-wise.

# 1228

(Had you taken captives) before being allowed by God's revelations, a great torment would have struck you for what you had done.

# 1229

Use what you have acquired (from the battle) as your own good, lawful property. Have fear of God; He is All-forgiving and All-merciful.

# 1230

Prophet, tell the captives with you, "If God finds anything good in your hearts, He will give you a better reward than that which was taken from you and will forgive you. God is All-forgiving and All-merciful.

# 1231

Do not be surprised that they want to be dishonest with you; they have always been dishonest with God. However, He has power over them. God is All-knowing and All-wise.

# 1232

The believers who left their homes and strove for the cause of God, through their property and in person and those who gave refuge to them and helped them will be each other's guardians. The believers who did not leave their homes are not your guardians until they too leave their homes. If they ask you for help in a religious cause, you must help them against their enemies unless their enemies have a peace treaty with you. God is Well Aware of what you do.

# 1233

The unbelievers are each other's friends. If you (the believers) do not keep the same among yourselves in the land, there will come into being widespread idolatry and great evil.

# 1234

The believers who left their homes, and strove for the cause of God and those who gave them refuge and helped them, are true believers. They will have forgiveness (from their Lord) and (will be granted) honorable provisions.

# 1235

Those who accepted the faith later, left their homes and strove with you for the cause of God are also your people. They relatives are nearer to each other according to the Book of God. God has knowledge of all things.

# 1236

God and His Messenger declare the abrogation of the peace treaty that existed between them and the pagans.

# 1237

However, during the four sacred months, they (pagans) may travel peacefully through the land. Know (pagans) that you cannot make God helpless, but it is God who has the power to disgrace the unbelievers.

# 1238

This Announcement from God and His Messenger is to be made to the people on the day of the great Pilgrimage; God and His Messenger have declared no amnesty for the pagans. If you (pagans) repent, it would be better for you, but if you turn away (from God), know that you cannot make God helpless. (Muhammad) tell the unbelievers that a painful punishment has been prepared for them.

# 1239

This does not apply to the pagans with whom you have a valid peace treaty and who have not broken it from their side or helped others against you. You (believers) must fulfill the terms of the peace treaty with them. God loves the pious ones.

# 1240

When the sacred months are over, slay the pagans wherever you find them. Capture, besiege, and ambush them. If they repent, perform prayers and pay the religious tax, set them free. God is All-forgiving and All-merciful.

# 1241

If any of the pagans ask you to give them refuge, give them asylum so that they may hear the words of God. Then, return them to their towns for they are an ignorant people.

# 1242

How can the pagans, except those with whom you have established a peace treaty in the precinct of the Sacred Mosque, have a covenant with God and His Messenger? If they respect the pact, you too should also follow its terms. God loves the pious ones.

# 1243

How could God and His Messenger grant them (pagans) peace when if they were to acquire superiority over you, they would respect none of the peace treaties nor their kindred relations with you! They only try to please you by paying lip-service to you but their hearts are against you and most of them are evil-doers.

# 1244

They have sold God's revelations for a paltry price and have created obstacles in the way of God. What they have done is evil.

# 1245

They do not respect their promises nor their family ties with the believers. They are transgressors.

# 1246

If they repent, perform their prayers, pay religious tax, they would be your brothers in the religion. We explain Our revelations to people of knowledge.

# 1247

Fight against the leaders of the unbelievers if they violate their established peace treaty with you and revile your faith, to force them to stop their aggression against you. You do not have to bind yourselves to such a treaty.

# 1248

Why will you not fight against a people who have broken their peace treaty with you, have decided to expel the Messenger (from his home town), and who were the first to disregard the peace treaty? If you are true believers, you should only have fear of God.

# 1249

Fight them. May God punish them by your hands, humiliate them, give you victory over them, delight the hearts of the believers

# 1250

and appease their anger. God forgives whomever He wants and He is All-knowing and All-wise.

# 1251

Do you think that God will not make any distinction between those of you who have fought for His cause and have relied on no one other than God, His Messenger, and the faithful ones, and other people? God is Well Aware of what you do.

# 1252

The pagans do not have any right to establish (and patronize) the mosque of God while they testify against their souls to its disbelief. Their deeds are devoid of all virtue and they will live forever in hell fire.

# 1253

Only those who believe in God, the Day of Judgment, perform their prayers, pay the religious tax, and have fear of God alone have the right to establish and patronize the mosque of God so that perhaps they will have the right guidance.

# 1254

Do you (pagans), because you served water to the pilgrims and constructed the Sacred Mosque, consider yourselves equal to those who have believed in God, the Day of Judgment, and have fought for the cause of God? In the sight of God you (pagans) are not equal to the believers. God does not guide the unjust.

# 1255

To those who have believed in God, left their homes, and fought for His cause with their possessions and in person, God will grant high ranks and success.

# 1256

Their Lord will give the glad news of His granting mercy to them, His pleasure, and His admitting them to a Paradise full of everlasting bounties wherein they will live forever.

# 1257

The reward that God will bestow on His servants is the greatest.

# 1258

Believers, do not accept your fathers and brothers as your guardians if they prefer disbelief to faith, lest you be unjust.

# 1259

(Muhammad), tell them, "If your fathers, children, brothers, spouses, relatives, the property that you possess, the trade you fear may have no profit and the homely life are more beloved to you than God, His Messenger and fighting for His cause, wait until God fulfills His decree (of making the right distinct from the wrong). God does not guide the evil-doers."

# 1260

God has helped you on many occasions including the day of Hunayn (name of a place near Mecca). When you were happy with the number of your men who proved to be of no help to you and the whole vast earth seemed to have no place to hide you (from your enemies) and you turned back in retreat.

# 1261

God gave confidence to His Messenger and the believers and helped them with an army which you could not see. God punished the unbelievers; this is the only recompense that the unbelievers deserve.

# 1262

After that occasion God forgave those whom He wanted. God is All-knowing and All-merciful.

# 1263

Believers, the pagans are filthy. Do not let them come near to the Sacred Mosque after this year. If you are afraid of poverty, He will make you rich if He wishes, by His favor. God is All-knowing and All-wise.

# 1264

Fight against those People of the Book who have no faith in God or the Day of Judgment, who do not consider unlawful what God and His Messenger have made unlawful, and who do not believe in the true religion, until they humbly pay tax with their own hands.

# 1265

Some of the Jews have said that Ezra is the son of God and Christians have said the same of Jesus. This is only what they say and it is similar to what the unbelievers who lived before them had said. May God destroy them wherever they exist!

# 1266

They (unconditionally) obeyed the rabbis and the monks and worshipped the Messiah, son of Mary, as they should have obeyed God. They were commanded to worship no one besides God who is the only God and who is too exalted to be considered equal to any idols.

# 1267

They would like to extinguish the light of God with a blow from their mouths, but even though the unbelievers may dislike it, God has decided to let His light shine forever.

# 1268

It is God Who sent His Messenger with guidance and a true religion that will prevail over all other religions, even though the pagans may dislike it.

# 1269

Believers, many rabbis and monks consume other people's property by false means and create obstacles in the way of God. Those who horde gold and silver and do not spend (anything out of it) for the cause of God, should know that their recompense will be a painful torment

# 1270

on the Day of Judgment and that their treasures will be heated by the fire of hell and pressed against their foreheads, sides and back with this remark, "These are your own treasures which you hoarded for yourselves. See for yourselves what they feel like."

# 1271

According to the Book of God, from the day He created the heavens and the earth, the number of months are twelve, four of which are sacred. (This is part of the law) of the religion. Do not commit injustice against your souls during the sacred months but fight all the pagans just as they fight against all of you. Know that God is with the pious ones.

# 1272

To disregard the observation of the sacred months and to observe it during the non-sacred months is to add more to one's disbelief. This causes the unbelievers to go further astray. One year they (the pagans) consider a sacred month not sacred, (and observe it during a non-sacred month) but the next year they consider it sacred at the right time. By dealing with the sacred months in such a manner, they think that they have observed the laws of God, but, in fact, they have changed them. Their evil deeds seem attractive to them but God does not guide the unbelieving people.

# 1273

Believers, why is it that when you are told to march for the cause of God, you seem to linger at home. Have you given preference to the worldly life over the life hereafter? The worldly gains compared to those of the next life are but very little.

# 1274

If you do not march for His cause, He will afflict your with a painful punishment and replace you by another nation and your (destruction) will not harm Him at all. God has power over all things.

# 1275

If you do not help him, (Muhammad), God has already helped him. When the unbelievers expelled him and he was one of the two people in the cave telling his friend, "Do not worry; God is with us," then God gave him confidence and supported him with an army which you did not see and He defeated the cause of the disbelievers and made His own cause stand supreme. God is Majestic and All-wise.

# 1276

Whether unarmed or well equipped, march and fight for the cause of God with your possessions and in person. This would be better for you, if only you knew it.

# 1277

Had the gain been immediate or the journey shorter, they (hypocrites) would certainly have followed you, (Muhammad), but it was too far for them. They will swear by God, "Had we had the ability, we would certainly have marched with you." They destroy only themselves and God knows that they are lying.

# 1278

May God forgive you! (Muhammad), why did you not let them join the army so that you could discern the liars from the truthful ones?

# 1279

Those who believe in God and the Day of Judgment do not ask you whether they should fight for the cause of God with their property and in person, or not. God knows all about the pious ones.

# 1280

Only those who do not believe in God and the Day of Judgment ask you such questions because their hearts are full of doubts and they cannot make any final decisions.

# 1281

Had they (the hypocrites) wanted to join your army, they would have prepared themselves, but God did not wish to motivate them, so He caused them to linger behind with those whose joining you in battle would be of no use.

# 1282

Had they joined you, they would have been of no help to you but would have just caused confusion and trouble among you by sneaking through the ranks where some of you would be ready to listen to them. God knows best the unjust.

# 1283

Even prior to this, they tried to cause trouble and to turn your affairs upside-down until the truth came and the cause of God triumphed against their desires.

# 1284

Some of them ask you, "Make us exempt from taking part in the battle and do not try to tempt us by telling us what we may gain from the battle; many people have died in the battle." Hell certainly encompasses the unbelievers.

# 1285

If you gain success, it grieves them but if you suffer hardship, they turn away from you saying, "It's good that we took our affairs into our own hands".

# 1286

(Muhammad), say, "Nothing will happen to us besides what God has decreed for us. He is our Guardian. In God alone do the believers trust."

# 1287

For us, you can anticipate nothing other than Paradise if we are killed or success if we triumph. However, what we can anticipate for you is either punishment by the hands of God or by ours. Wait and we, too, are waiting with you.

# 1288

Say, "Whether you spend your wealth for the cause of God, willingly or reluctantly, it will never be accepted from you; you are an evil doing people."

# 1289

What prevents their offerings from being accepted is their disbelief in God and His Messenger, their lack of interest in prayer and spending for the cause of God reluctantly.

# 1290

Let not their property and children tempt you; God wants to punish them through their things in this life so that their souls will depart while they are unbelievers.

# 1291

They swear by God that they are believers like you but they are not believers. They are a people who only cause differences.

# 1292

They are so afraid of you that had there been a place for them to seek refuge, a cave or some entrance in which to hide themselves from you, they would have madly rushed therein.

# 1293

They blame you about the distribution of the welfare funds. They are pleased when you give them something from it, but if they receive nothing, they become angry with you.

# 1294

Would that they had been pleased with what God and His Messenger had given them and had said, "God is All-Sufficient for us. God and His Messenger will soon do us more favors and we have hope in God's mercy."

# 1295

Welfare funds (zakat) are only for the poor, the destitute, the tax collectors, those whose hearts are inclined (towards Islam), the slaves, those who cannot pay their debts, for the cause of God, and for those who have become needy on a journey. Paying zakat is an obligation that God has decreed. God is All-knowing and All-wise.

# 1296

Some of them speak ill of the Prophet, saying, "He listens to everything and believes what he hears." (Muhammad), tell them, "He only listens to what is good for you, believes in God, and has trust in the believers. He is a mercy for the believers among you. Those who speak ill of the Messenger of God will face a painful punishment."

# 1297

They (hypocrites) swear by God in their effort to please you, but if they were true believers (they would know) that God and His Messenger deserve more to be pleased than anyone else.

# 1298

Do they not know that for displeasing God and His Messenger, one would be admitted to Hell wherein he would live forever. This indeed is a great humiliation.

# 1299

The hypocrites are afraid that some revelation will be revealed, thus, making public what is in their hearts. (Muhammad), tell them, "Continue in your mockery; God will certainly let whatever causes you worry to take place".

# 1300

If you question them about their manners, they say, "We were only arguing for the sake of amusement." Ask them, "Were you mocking God, His revelations, and His Messenger?"

# 1301

Make no excuses. You have certainly turned back to disbelief. If We forgive one group of you, We must punish the other for they are guilty.

# 1302

Be they male or female hypocrites, they are the same. They make others commit sins, prevent them from doing good deeds, and restrain their hands (from spending for the cause of God). They have forgotten all about God who also has ignored them. The hypocrites indeed are evil-doers.

# 1303

For the hypocrites and the unbelievers, God has prepared hell wherein they will live forever. Hell is their proper punishment. God has condemned them and they will suffer a permanent torment

# 1304

like that of those who lived before you, whose power, wealth, and children were much greater than yours. They enjoyed their share of the worldly gains and you, also, like them, have enjoyed yours. You have been sneaking among the people to cause trouble, just as they had been doing before you. Such people's deeds are devoid of all virtue both in this life and in the life hereafter. They indeed are lost.

# 1305

Have they not heard the stories of the people of Noah, the tribe of Ad, Thamud, the people of Abraham, the dwellers of the city of Midian, and those of the Subverted Cities? God's Messengers came to each of them with miracles. God did not do any injustice to them, but they wronged themselves.

# 1306

The believers, both male and female, are each other's guardians. They try to make others do good, prevent them from committing sins, perform their prayers, pay the religious tax, and obey God and His Messenger. God will have mercy on them; He is Majestic and All-wise.

# 1307

God has promised the believers gardens wherein streams flow and wherein they will live forever in the excellent mansions of the garden of Eden. What is more important than all this for them is that God is pleased with them. Such is the supreme triumph.

# 1308

Prophet, fight the unbelievers and hypocrites vehemently for the cause of God. Their dwelling is hell, a terrible destination!

# 1309

They (the hypocrites) swear by the Name of God (to make others believe in what they are saying). They have spoken the testimony of disbelief and have then turned back to disbelief. They have made unsuccessful attempts to cause trouble. There is no other reason for their ungratefulness except that God and His Messenger enriched them through their favors. If they repent, it will be better for them, but if they turn away (from the faith), God will make them suffer a painful punishment both in this life and in the life hereafter. They will find no guardian nor any helper in the land.

# 1310

Some of them have promised God that if He will favor them, they will certainly spend for His cause and be righteous ones.

# 1311

But when His favors were bestowed on them, they became niggardly and in disregard broke their promise.

# 1312

God will, for their disregard of their promise and their telling lies, place hypocrisy in their hearts which will not leave them until they face the consequences of their deeds.

# 1313

Were they not aware that God knows all that they hide or whisper and that He has absolute knowledge of the unseen?

# 1314

God mocks those (hypocrites) who blame and mock the rich or poor believers who donate to the welfare funds, and He has prepared a painful torment for them.

# 1315

(Muhammad), whether you ask God to forgive them or not, He will never do so, even if you were to beg seventy times; they have disbelieved in God and His Messenger and God does not guide the evil-doers.

# 1316

Those who did not take part in the battle (of Tabuk), were glad about their staying home against the order of the Messenger of God. They did not want to fight for the cause of God with their property and in person and said, "Do not march (to the battle) on the hot days." (Muhammad), tell them, "The heat of hell fire is much more severe, if only you would understand."

# 1317

They should laugh less and weep more as a recompense for what they have gained.

# 1318

When God brings you back safely and a group of hypocrites ask you to make them exempt from taking part in the battle, tell them, "Never march with me and never fight with us against any of the enemies (of God). You chose to linger behind the first time, so this time stay behind with those who are of no help in the battle."

# 1319

Should any of them die, never pray for him or stand on his grave. They have disbelieved in God and His Messenger and have died while committing evil.

# 1320

Their wealth or children should not tempt you; God wants to punish them through these things in this life so that they will die as disbelievers.

# 1321

When a chapter of the Quran is revealed telling them to believe in God and fight along with His Messenger for His cause against His enemies, the healthy and rich ones of them ask you to exempt them from taking part in the battle for the cause of God and to let them stay home with the people who are of no help in the battle.

# 1322

They are happy to stay home with those who are of no help in the battle, thus, their hearts were sealed and they were left with no understanding.

# 1323

But the Messenger of God and the believers with him fought for the cause of God with their possessions and in person and their reward will be all good things and everlasting happiness.

# 1324

God has established gardens for them wherein streams flow and wherein they will live forever. This indeed is the greatest triumph.

# 1325

Some of the dwellers of the desert (who were not able to join the army) came to the Prophet seeking exemption from taking part in the battle. Those who called God and His Messengers liars also stayed home (with those who were truly exempt). The disbelievers will soon receive a painful punishment.

# 1326

People who are weak or sick and those who do not have the means to take part in the fighting are exempt from this duty if their intention remains sincere about God and His Messenger. Righteous people shall not be blamed. God is All-forgiving and All-merciful.

# 1327

Those who come to you, (Muhammad), asking to be taken to the battle, but you cannot find the necessary means for them, are exempt from the duty of fighting for the cause of God, even though they leave you with their eyes flooded with tears because of not being able to help the cause of God.

# 1328

The blameworthy ones are those who ask for exemption despite their ability and who preferred to stay at home with those who are truly exempt. God has placed a seal on their hearts but they do not know.

# 1329

They will apologize to you on your return. Tell them, "Do not ask for pardon. We will never believe you. God has already told us everything about you. God and His Messenger will soon make your deeds public, then you will return to Him who has absolute knowledge of the unseen and the seen and He will inform you of what you have done.

# 1330

When you return they will appeal to you in the Name of God to leave them alone. So leave them alone. They are filthy and their dwelling will be hell as a recompense for what they had gained.

# 1331

They swear in the Name of God to please you. Even if you were to be pleased with them, God is not pleased with evil-doing people.

# 1332

The desert dwelling Arabs are far worse than the others in their disbelief and hypocrisy and have more reason to be ignorant of the revelations that God revealed to His Messenger. God is All-knowing and All-wise.

# 1333

Whatever some of the desert dwelling Arabs spend for the cause of God, they consider it a loss to themselves. They wish to see you in trouble. Trouble has struck them already. God is All-hearing and All-knowing.

# 1334

Some of the desert dwelling Arabs believe in God and the Day of Judgment. Whatever they spend for the cause of God they consider it as a means of getting nearer to God and have the prayers of the Messenger in their favor. This, certainly is a means to get nearer to God. God will admit them into His mercy. God is All-forgiving and All-merciful.

# 1335

God is well pleased with the foremost ones of those who left their homes for the cause of God, those who helped them after their arrival in Medina and those who nobly followed these two groups. He has prepared gardens for them wherein streams flow and wherein they will live forever. This, certainly is the supreme triumph.

# 1336

Some of the desert dwelling Arabs around you are hypocrites as are some of the inhabitants of Medina. They are persisting in their hypocrisies. You do not know them but We know them well and will punish them twice over. Then they will be brought to the great torment (on the Day of Judgment).

# 1337

Some of them have already confessed their sins and have mixed virtuous deeds with sinful ones. Perhaps God will forgive them. God is All-forgiving and All-merciful.

# 1338

Collect religious tax (zakat) from them to purify and cleanse them and pray for them; your prayers give them comfort. God is All-hearing and All-knowing.

# 1339

Do they not know that it is God who accepts the repentance of His servants and receives the welfare funds and that it is God who is All-forgiving and All-merciful?

# 1340

(Muhammad), tell them, "Act as you wish. God, His Messenger and the believers will see your deeds. You will be brought before the One who has absolute knowledge of the unseen and the seen. He will let you know about all that you have done.

# 1341

Besides those who have confessed their sins, there are others who have no good deeds for which they may receive any reward or sins for which they may be punished. Their fate will be in the hands of God." God is All-knowing and All-wise.

# 1342

The mosque which some of the hypocrites have established is only to harm people, to spread disbelief, to create discord among the believers, to wait for the one who fought against God and His Messenger, and to make others believe that it has been established with their good intentions. But God testifies that they are liars.

# 1343

(Muhammad), never stay in that mosque. The mosque which was established for a pious purpose and before all other mosques is more virtuous for your prayer. In this mosque, there are people who love to be purified. God loves those who purify themselves.

# 1344

Which is better, the mosque that is founded for pious purposes and for achieving God's pleasure or that which is based on the brink of a crumbling bank and which may crumble into hell at any moment? God does not guide the unjust.

# 1345

The building (mosque) which they have built always motivates mischief in their hearts until their hearts are cut into pieces. God is All-knowing and All-wise.

# 1346

God has purchased the souls and property of the believers in exchange for Paradise. They fight for the cause of God to destroy His enemies and to sacrifice themselves. This is a true promise which He has revealed in the Torah, the Gospel, and the Quran. No one is more true to His promise than God. Let this bargain be glad news for them. This is indeed the supreme triumph.

# 1347

(The believers) who repent for their sins, worship God, praise Him, travel through the land (for pious purposes), kneel down and prostrate themselves in obedience to God, make others do good and prevent them from sins and abide by the laws of God, will receive a great reward. Let this be glad news for the believer.

# 1348

After it was made clear that the pagans are to be the dwellers of hell, the Prophet and the believers should not have sought forgiveness from God for them even though they may have been relatives.

# 1349

There was no other reason for Abraham to seek forgiveness from God for his father except the promise that he had made with him. When Abraham knew that his father was an enemy of God, he disowned his father. Abraham was very tender-hearted and forbearing.

# 1350

God does not misguide a nation after having given them guidance until the means of piety are made known to them. God knows all things.

# 1351

To God belongs the Kingdom of the heavens and the earth. He grants life and causes death. God is your only Guardian and Helper.

# 1352

God pardoned the Prophet, the Emigrants, the Helpers, and those who followed them, when the hearts of some of them almost deviated (from the truth) in their hour of difficulty. God forgave them because of His Compassion and Mercy.

# 1353

God also forgave the three people who lagged behind. Grief made them feel as though there was no place in the whole vast earth to hide them or in their souls to conceal their sorrow. They began to believe that no one could save them from (the wrath of God) except He Himself. God pardoned them so that they would also repent for their sins. God is All-forgiving and All-merciful.

# 1354

Believers, have fear of God and always be friends with the truthful ones.

# 1355

The inhabitants of the city of Medina and the desert Arabs dwelling around it were not supposed to disobey the Messenger of God or to give priority to their own lives above that of the Prophet. For if they had given priority to the life of the Messenger of God, they would not have experienced the hardships of thirst, fatigue, or hunger in their struggle for the cause of God, nor would their travelling have enraged the disbelievers and they would not have received any injury from enemies that God would not record for them as a virtuous deed. God does not ignore the reward of those who do good.

# 1356

Also, they would not have spent anything, great or small, for the cause of God or travel through a valley without God decreeing a reward for them far better than whatever they had done.

# 1357

Not all believers have to become specialists in religious learning. Why do not some people from each group of believers seek to become specialists in religious learning and, after completing their studies, guide their group so that they will have fear of God.

# 1358

Believers, fight the unbelievers near you for the cause of God so that they realize your strength and know that God is with the pious ones.

# 1359

When a chapter (of the Quran) is revealed, some people ask others, "Whose faith among you people has received strength from this (revelation)?" It (the revelation) certainly strengthens the faith of the believers and they consider it to be a glad news.

# 1360

But to those whose hearts are sick, it adds more filth to their hearts and they die as disbelievers.

# 1361

Do they not realize that God tests them once or twice a year but, nevertheless, they do not repent and give it proper thought?

# 1362

When a chapter (of the Quran) is revealed, (it upsets them). They look at one another and their eyes silently ask this question, "Has any one noticed the disappointment on our faces?" Then they walk away. In fact, God has turned their hearts away (from the truth); they are a people who have no understanding.

# 1363

A Messenger from your own people has come to you. Your destruction and suffering is extremely grievous to him. He really cares about you and is very compassionate and merciful to the believers.

# 1364

(Muhammad), if they turn away from you, say, "God is Sufficient (support) for me. There is no God but He. In Him do I trust and He is the Owner of the Great Throne."

# 1365

Alif. Lam. Ra. These are the verses of the Book of wisdom.

# 1366

Why should it seem strange to mankind that We sent revelations to a mortal among them, who would warn others and give to the believers the glad news of their high rank in the sight of God. The unbelievers have said, "He (Muhammad) is certainly a magician."

# 1367

God is your Lord who has created the heavens and the earth in six days and established His Dominion over the Throne. He maintains order over the creation. No one can intercede for others without His permission. It is God who is your only Lord. Worship only Him. Will you then not think?

# 1368

People, you will all return to God. The promise of God is true; He creates all things and (after their death) brings them to life again so that He may justly reward the righteously striving believers. The disbelievers will drink boiling filthy water and suffer painful torment as a recompense for their disbelief.

# 1369

It is God who has made the sun radiant and the moon luminous and has appointed for the moon certain phases so that you may compute the number of years and other reckonings. God has created them for a genuine purpose. He explains the evidence (of His existence) to the people of knowledge.

# 1370

The alternation of the day and night and all that God has created in the heavens and earth are evidence (of the existence of God) for the pious people.

# 1371

Those who do not have hope of receiving Our mercy in the life hereafter who are pleased and satisfied with the worldly life and who pay no attention to Our revelations

# 1372

will all have the Fire as their dwelling for that which they had done.

# 1373

The righteously striving believers receive, through their faith, guidance from their Lord to the bountiful gardens wherein streams flow.

# 1374

Their prayer shall be, "Glory be to you Lord," and their greeting, "Peace be with you," and the only other words (of worldly speech) they will speak will be, "It is God, Lord of the Universe, who deserves all praise."

# 1375

Had God been as hasty to punish people as they were hasty to achieve good, their life would have already ended. We will leave those who have no hope of receiving Our mercy, in the life hereafter, to continue blindly in their transgression.

# 1376

When the human being is affected by hardship, he starts to pray while lying on his side, sitting or standing, but when We relieve him from hardship, he starts to act as though he had never prayed to Us to save him from the misfortune. This is how transgressors' deeds are made attractive to them.

# 1377

We destroyed certain generations who lived before you because of their injustice. Our Messengers came to them and showed them miracles, but they would not believe. Thus do We punish the criminals.

# 1378

We have made you their successors in the land so that We could see how you behaved.

# 1379

Whenever Our authoritative revelations are recited to those who do not wish to meet Us in the life hereafter, say, "Bring us another book besides this one or change it." (Muhammad), tell them, "I can not change it myself. I only follow what is revealed to me. I fear that for disobeying my Lord I shall be punished on the great (Day of Judgment).

# 1380

(Muhammad), tell them, "Had God wanted I would not have recited it (the Book) to you nor would I have told you anything about it. I lived among you for a whole life-time before it was revealed. Will you then not understand?

# 1381

Who is more unjust than one who invents falsehood against God or calls His revelations lies? The criminals will certainly have no happiness.

# 1382

(Some people) worship things other than God which harm nor benefit them. They say, "These (idols) are our intercessors before God." (Muhammad), tell them, "Are you trying to tell God about something that He does not find in the heavens or earth? God is too Glorious to be considered equal to idols."

# 1383

All people (once) followed one belief. Then they began to follow different beliefs. Had not a word of your Lord (His decision to give every one time and free will) been decreed, God would already have settled their differences.

# 1384

They (unbelievers) say, "Why has his Lord not given him some miracles to (support his claim of being His Messenger)?" Say "(The knowledge) of the unseen certainly belongs to God. Wait and I too shall be waiting with you.

# 1385

When people are granted mercy after having suffered hardship, they begin to plot against Our revelations. Say, "God is the most swift in His plans." Our angelic messengers record all that you plot.

# 1386

When you are rejoicing in a boat, a favorable breeze and a violent storm arises with waves surrounding you from all sides. Thinking that you will not survive, you start to pray sincerely to God. In prayer, you say, "If You rescue us from this we shall certainly be grateful".

# 1387

When We saved you, you started to rebel unjustly in the land. People, your rebellion will only harm yourselves. You may enjoy the worldly life but to Us you will all return and We will let you know all that you had done.

# 1388

The example of the worldly life is like the water sent down from the sky which becomes mixed with the earth's produce that people and cattle consume. When the land becomes fertile and pleasant, people think that they have control over it. At Our command during the night or day, the land becomes as barren as if it had no richness the day before. Thus, do We explain the evidence (of the truth) for the people who reflect.

# 1389

God invites every one to the House of Peace and guides whomever He wants to the right path.

# 1390

The righteous will receive good reward for their deeds and more. Their faces will suffer no disgrace or ignominy. They will be the dwellers of Paradise wherein they will live forever.

# 1391

The recompense for the evil deeds will be equally evil (not more) and the faces of the evil-doers will suffer from disgrace. No one can protect them from the wrath of God. Their faces will become dark as if covered by the pitch-darkness of night. They will be the dwellers of hell wherein they will remain forever.

# 1392

We will tell the pagans on the day when every one is resurrected, "Stand with your idols wherever you are." Then We will separate them (from their idols) and their idols will protest against them saying, "You did not worship us.

# 1393

God is Sufficient Witness for us that we were not aware of your worship".

# 1394

There every soul will experience the result of all that it had done. They will be brought into the presence of God, their true Lord, and all that they falsely invented will vanish.

# 1395

(Muhammad), ask them, "Who gives you sustenance from the heavens and earth, who truly possesses (your) hearing and seeing abilities, who brings the living out of the dead and the dead out of the living and who regulates (the whole Universe)? They will reply, "God." Ask them, "Why, then, do you not have fear of Him?"

# 1396

Thus is God your true Lord. In the absence of truth there is nothing but falsehood. Then where are you turning?

# 1397

The decree of your Lord that the evil-doers will not have faith has already been issued.

# 1398

(Muhammad), ask them,"Can any of your idols create something (cause it to die), and then bring it back to life again?" Say, "Only God can originate the creation and bring it to life again. Where have you strayed?"

# 1399

(Muhammad), ask them, "Can any of your idols guide you to the Truth?" Say, "Only God guides to the Truth." Is the one who guides to the Truth a proper guide or one who himself cannot find guidance unless he is guided (by others)? What is wrong with you that you judge (so unjustly)?

# 1400

Most of the unbelievers follow only conjecture which certainly cannot serve as a substitute for the Truth. God knows well what they do.

# 1401

No one could have composed this Quran besides God. This confirms the existing Book (the Bible) and explains itself. There is no doubt that it is from the Lord of the Universe.

# 1402

Do they say that Muhammad has invented it? (Muhammad), tell them, "If your claim is true, compose only one chapter like it and call on anyone besides God for help.

# 1403

They call a lie something that is beyond the limit of their knowledge and whose interpretation has not yet been revealed. Some people who lived before them also called Our revelations lies. Consider how terrible was the end of the unjust people!

# 1404

Some of them believe in the Quran and others do not. Your Lord knows best the evil doers.

# 1405

If they call you a liar, tell them, "Let each one of us follow his own way. You will not be responsible for what I do and I will not be responsible for what you do".

# 1406

Some of them will listen to you, but are you supposed to make the deaf hear even if they have no understanding?

# 1407

Some of them will look at you, but are you supposed to guide the blind even if they have no vision?

# 1408

God does not do the least bit of injustice to anyone but people wrong themselves.

# 1409

On the day when they will be resurrected, their worldly life will seem to them only as an hour of a day and they all will recognize each other. Those who called the receiving of mercy from God a lie are certainly lost. They did not have the right guidance.

# 1410

When if We show you them suffering Our retribution or you die before their suffering, (they will not be able to escape Our punishment) they will all return to Us. God bears witness to whatever they do.

# 1411

A Messenger is appointed for all people. When the Messenger for them came he judged among them fairly and they were not wronged.

# 1412

They ask, "If you (believers) speak the truth, when will your promise (about the Day of Judgment) be fulfilled?"

# 1413

(Muhammad), tell them, "I have no control over my suffering or benefits unless God wills. Every nation is destined to live for an appointed time. They can neither delay that time nor can they cause it to come sooner.

# 1414

Ask them, "What benefit can criminals get from their demand that God must punish them immediately if His words are true?" Whether His punishment befalls them during the day or night (they will not be able to escape).

# 1415

Besides, if He was to send them the punishment which they want to quickly experience, would they then have faith?

# 1416

The unjust will be told, "Suffer the everlasting torment. Do you expect a recompense other than what you deserve?

# 1417

They ask you, "Is that (punishment) true?" Tell them, "It certainly is. I swear by my Lord. You can not escape from (God's retribution)".

# 1418

(On the Day of Judgment) to redeem oneself of one's injustice, one would gladly spend the wealth of the whole earth if it were possible. On seeing the torment one will try to hide his regret. They will all be judged fairly and no wrong will be done to them.

# 1419

All that is in the heavens and the earth certainly belongs to God and His promise is true, but many people do not know this.

# 1420

It is God who gives life and causes things to die. To Him you will all return.

# 1421

People, good advice has come to you from your Lord a (spiritual) cure, a guide and a mercy for the believers.

# 1422

(Muhammad), tell them, "To be happy with the favors and mercy of God is better than whatever you accumulate".

# 1423

Ask them, "Have you considered that out of the sustenance which God has given you, you made some of it lawful and some unlawful? Did God permit you to do this or are you ascribing falsehood to Him?"

# 1424

What do those who ascribe falsehood to God think of the Day of Judgment? God is generous to the human being, yet many do not give thanks.

# 1425

(Muhammad), We bear witness to all your affairs; whatever you recite from the Quran and whatever you (people) do. Nothing in the heavens or the earth is hidden from your Lord, even that which is as small as an atom's weight or greater or smaller. All is recorded in the glorious Book.

# 1426

The friends of God will certainly have nothing to fear, nor will they be grieved.

# 1427

Those who have faith and fear God

# 1428

will receive glad news both in this life and in the life hereafter. The words of God do not change. This alone is the supreme triumph

# 1429

(Muhammad), let not their words disappoint you; all dignity belongs to God. He is All-hearing and All-knowing.

# 1430

Does not all that is in the heavens and the earth belong to God? (The unbelievers) who worship the idols instead of God follow only conjecture. What they preach are mere lies.

# 1431

It is God who has made the night for you to rest and has filled the day with light (as a means of visibility). In this there is evidence (of the existence of God) for the people who hear.

# 1432

Some people have said that God has begotten a son. God is too Glorious to have a son! God is Self-sufficient and to Him belongs all that is in the heavens and the earth. In this, you (people) have no authority. Do you ascribe to God things of which you have no knowledge?

# 1433

(Muhammad), tell them, "Those who invent falsehood against God will have no happiness".

# 1434

They may consider it a means of enjoyment in this life but (on the Day of Judgment) they will all return to Us. Then they will suffer for their disbelief the most severe punishment.

# 1435

(Muhammad), tell them the story of Noah who told his people, "Even if my belief and my preaching of the revelation of God seem strange to you, I put my trust in Him. Unite yourselves and seek help from your idols. You should not regret what you want to do, but should execute your plans against me without delay

# 1436

If you turn away from my preaching, it will not harm me; I shall receive my reward from God who has commanded me to become a Muslim."

# 1437

They rejected Noah. Then We saved him and his people in the Ark to make them the successors of the rest. The others, who had called Our revelations lies, were drowned. Consider the fate of those who (rejected) Our warnings!

# 1438

After (Noah) We sent other Messengers to their people with clear authoritative evidence proving their prophetic claims). But how could the people believe what they had previously called lies? Thus do We seal the hearts of the transgressors.

# 1439

Then We sent Moses and Aaron with Our miracles to the Pharaoh and his people. These people also proved to be arrogant. They were wicked people.

# 1440

When the Truth from Us came, they called it simply magic.

# 1441

Moses asked, "Why do you call the Truth which has come to you magic? Magicians, certainly, will not have happiness".

# 1442

They asked Moses, "Have you come to turn us away from the faith of our fathers and to make yourselves the rulers in the land? We shall never accept your faith."

# 1443

The Pharaoh ordered every skillful magician to come into his presence.

# 1444

When all the magicians were brought to his court, Moses asked them to cast down what they wanted to.

# 1445

When the magicians had thrown theirs, Moses said, "What you have performed is magic. God will certainly prove it to be false; He will not make the deeds of the corrupt people righteous.

# 1446

God will make the Truth stand supreme by His words, even though the wicked people dislike it."

# 1447

No one believed in Moses except some young people of his own tribe who were at the same time very afraid of the persecution of the Pharaoh and his people. The Pharaoh was certainly a tyrant and a transgressor.

# 1448

Moses told his people, "If you have submitted yourselves to God and have faith in Him, put your trust in Him".

# 1449

They said, "In God do we trust. Lord, do not subject us to the persecution of the unjust ones,

# 1450

Lord, save us, through Your mercy, from the disbelieving people."

# 1451

We sent a revelation to Moses and his brother to build houses for their people in the Pharaoh's town and to build them facing one another. (We told him) that therein they should pray and that Moses should give the glad news (of God's mercy) to the faithful ones.

# 1452

Moses said, "Lord, You have given the Pharaoh and his people great riches and splendor in this life and this makes them stray from Your path. Lord, destroy their wealth and harden their hearts in disbelief so that they will suffer the most painful torment".

# 1453

The Lord replied, "Moses, the prayer of your brother and yourself has been heard. Both of you must be steadfast (in your faith) and must not follow the ignorant ones."

# 1454

We helped the children of Israel cross the sea safely. The Pharaoh and his army pursued the children of Israel with wickedness and hate until the Pharaoh was drowned. As he was drowning the Pharaoh said, "I declare that there is no God but the One in whom the children of Israel believe and I have submitted to the Word of God".

# 1455

(God replied), "Now you declare belief in Me! but before this you were a disobedient rebel.

# 1456

We will save your body on this day so that you may become evidence (of Our existence) for the coming generations; many people are unaware of such evidence."

# 1457

We settled the children of Israel in a blessed land and provided them with pure sustenance. They did not create differences among themselves until after the knowledge had come to them. God will judge their differences on the Day of Judgment.

# 1458

If you (people) have any doubt about what We have revealed to you (about the Day of Judgment and other matters of belief), ask those who read the Book that was revealed (to the Prophets who lived) before you. The truth has certainly come to you from your Lord. Thus, do not doubt it (in your heart),

# 1459

nor be of those who have called God's revelations lies lest you become lost.

# 1460

(Even though all kinds of miracles will be shown to them) those about whom the word of your Lord has been ordained, will not have faith

# 1461

until they face the most painful torment.

# 1462

Why did no one except the people of Jonah believe (in their punishment before their death) so that they could have benefitted from their faith? When the people of Jonah believed, We saved them from a disgraceful torment in this life and provided them with the means of enjoyment for an appointed time.

# 1463

Had your Lord wished, the whole of mankind would have believed in Him. (Muhammad), do you force people to have faith?

# 1464

No one can have faith without the permission of God. God will cast down filth on those who have no understanding.

# 1465

(Muhammad), tell them to consider that which is in the heavens and the earth. Evidence and warnings are of no avail to the disbelieving people.

# 1466

What can they expect other than the kind of (punishment that befell the disbelieving people) who had gone before them? (Muhammad), tell them, "Wait and I too will be waiting with you."

# 1467

We saved Our Messengers and those who believed; We must save the believers.

# 1468

(Muhammad), say, "People, if you have doubt about my religion, know that I, certainly, do not worship the idols which you worship instead of God, but I worship God who causes you to die. I am commanded to believe (in His existence),

# 1469

to have firm belief in the up-right religion and not to be an idolater

# 1470

nor to seek help from anyone other than God \[who can neither benefit nor harm me\], lest I become of the unjust.

# 1471

(Muhammad), if God afflicts you with hardship, no one besides Him can save you. If God grants you a favor, no one can prevent you from receiving His favors. God bestows His favors upon whichever of His servants He wants. God is All-forgiving and All-merciful.

# 1472

(Muhammad), say, "People, truth has certainly come to you from your Lord. One who seeks guidance does so for his own good and One who goes astray will find himself lost. I am not your keeper".

# 1473

(Muhammad), follow what is revealed to you and have patience until God issues His Judgment; He is the best Judge.

# 1474

Alif. Lam. Ra. This is a Book from One who is All-wise and All-aware. Its verses are well composed and distinctly arranged (from one another)

# 1475

(It teaches), "People, do not worship anyone besides God. I, (Muhammad), am His Messenger sent to warn you and to give you the glad news.

# 1476

"Seek forgiveness from your Lord and turn to Him in repentance for your sins. He will provide you good sustenance for an appointed time and will reward everyone according to his merits. I am afraid that you will suffer torment on the great Day (of Judgment) if you turn away (from God).

# 1477

To God you will all return. God has power over all things."

# 1478

(The unbelievers) cover their breasts to try to hide their disbelief from God. But He knows very well whatever they conceal or reveal even when they cover themselves with their garments. God certainly knows the inner-most (secrets) of the hearts.

# 1479

There is no living creature on earth that does not receive sustenance from God. He knows its dwelling and resting place. Everything is recorded in the glorious Book.

# 1480

God created the heavens and the earth in six days. His Throne existed on water so that He could test you and find out those among you who do good deeds. (Muhammad), if you were to tell them that after death they would be brought back to life again, the unbelievers would say, "This is nothing but obvious magic."

# 1481

If We delay in afflicting them with Our punishment for an appointed time, they ask, "What is preventing it (the punishment) from taking place?" On the day when it (punishment) befalls them, no one will be able to escape from it and that which they have mocked will surround them from all sides.

# 1482

We grant a favor to the human being and then take it away from him. He becomes despairing and ungrateful.

# 1483

If after his hardship, We grant him a blessing, he grows proud and rejoicing and says, "All my hardships have gone".

# 1484

But those who exercise patience and do good works do not behave as such. They will receive forgiveness and a great reward (from the Lord).

# 1485

Perhaps you, (Muhammad), may by chance leave (untold) a part of that which is revealed to you and feel grieved because they say, "Why has some treasure not been sent to him or an angel sent down with him?" Say, "I have come only to warn you." God is the Guardian of all things.

# 1486

Do they, (the unbelievers), say that (Muhammad) has falsely ascribed (the Quran) to God? Ask them, "Compose ten chapters like (those of the Quran) and call on whomever you can for help besides God if you are true in your claim.

# 1487

If they will not respond to you, know that God has sent it with His knowledge and that He is the only God. Will you then become Muslims?"

# 1488

Those who choose the worldly life and its pleasures will be given proper recompense for their deeds in this life and will not suffer any loss.

# 1489

Such people will receive nothing in the next life except Hell fire. Their deeds will be made devoid of all virtue and their efforts will be in vain.

# 1490

Should they be compared with those whose Lord has given them a guidance which is testified by a witness from among their own people and by the Book of Moses, a guide and a mercy. Such people do believe in this guidance (in the Quran). Those who disbelieve (in the Quran) will have hell as their dwelling place. Thus, (Muhammad), have no doubt about it (the Quran). It is certainly the truth from your Lord, yet many people do not have faith.

# 1491

Who are more unjust than those who ascribe falsehood to God? When such people are brought into the presence of their Lord, the witness will say, "These are the ones who told lies about their Lord. Certainly God will condemn the unjust

# 1492

who prevent others from the way of God, seek to make it appear crooked, and who have no faith in the life hereafter.

# 1493

Such people will never weaken God's (power) on earth nor will they find any guardian besides God. Their punishment will be doubled and they will not be able to hear or see.

# 1494

They have lost their souls and their false deities will turn away from them.

# 1495

In the life to come they will certainly lose a great deal.

# 1496

The righteously striving believers who are humble before their Lord, will be the dwellers of Paradise wherein they will live forever.

# 1497

Can the two groups, the blind and the deaf, be considered equal to those who have vision and hearing? Will you then not take heed?

# 1498

We sent Noah to his people to give them the clear warning

# 1499

that they should not worship anyone besides God. (Noah warned them), "I am afraid that you will suffer the most painful torment".

# 1500

The disbelievers among his people said, "We do not believe that you are any better than the rest of us; we see that only the worthless hasty ones, the lowliest among us follow you. Thus, we do not think that you are superior to us, rather you are all liars."

# 1501

Noah replied, "My people do you think - that if my Lord has sent me a miracle and granted me mercy but your ignorance has obscured them from your sight - we can force you to believe when you do not want to?

# 1502

My people I do not ask any payment for what I preach to you. No one except God has to give me any reward. I do not drive away those who have faith (in my teaching); they will all receive mercy from their Lord. I know that you are ignorant people.

# 1503

My people, who would protect me against God if I were to drive these people away? Will you then not take heed?

# 1504

I do not say that God's treasures belong to me, that I know the unseen, or that I am an angel. Nor do I say about those whom you disdain that God will not give them any reward. God knows best what is in their hearts, for then I would be unjust."

# 1505

They said, "Noah, you have argued with us a great deal. Bring down on us whatever torment with which you have been threatening us if what you say is true".

# 1506

(Noah) replied, "God will bring torment down on you whenever He wants and you will not be able to make His (plans) fail.

# 1507

My advice will be of no benefit to you if God wants to let you go astray. He is your Lord and to Him you will all return."

# 1508

Do they say that Muhammad has falsely ascribed (the Quran) to God? (Muhammad), tell them "Had I falsely ascribed it to God, I shall be responsible for my own sins. I am certainly not responsible for whatever sins you commit!

# 1509

It was revealed to Noah that besides those who had already accepted his faith, no one from his people would ever believe him. He was told not to be disappointed about what his people had done,

# 1510

but to build the Ark under the supervision and guidance of his Lord. He was also told not to address any words to Him concerning the unjust for they were all to be drowned.

# 1511

(Noah) started to build the Ark but whenever some of his people passed by, they would mock him. He in return would reply, "Mock us, but just as you mock us, we, too, will mock you.

# 1512

You will soon learn who will face a humiliating punishment and will be encompassed by an everlasting torment."

# 1513

When at last Our decree was fulfilled, water gushed forth from the Oven (in Noah's house). We told him to carry in the Ark a pair (male and female) from every species, his family - except those who were destined to perish - and the believers. No one believed in him, except a few.

# 1514

(Noah) said, "Embark in it. It will sail in the name of God, in His Name it will sail and in His Name it will cast anchor. My Lord is All-forgiving and All-merciful".

# 1515

When the Ark sailed on with them amid the mountainous waves, Noah called out to his son who kept away from them, "My son, embark with us. Do not stay with the unbelievers."

# 1516

His son replied, "I shall climb up a mountain and this will save me from the flood." Noah said, "No one can escape on this day from God's command except those on whom He has mercy." The waves separated Noah from his son who was then drowned with the rest (of the unbelievers).

# 1517

Then the earth was told to swallow-up its water and the sky was ordered to stop raining. The water abated and God's command had been fulfilled. The Ark came to rest on Mount Judi. A voice said, "The unjust people are far away from the mercy of God."

# 1518

Noah prayed to his Lord saying, "Lord, my son is a member of my family. Your promise is always true and you are the best Judge".

# 1519

His Lord replied, "He is not one of your family. He is a man of unrighteous deeds. Do not ask me about that which you have no knowledge. I advise you not to become an ignorant person."

# 1520

Noah said, "Lord, I ask You to prevent me from asking You ignorant questions and beg you for pardon and mercy or else I shall certainly be lost".

# 1521

Noah was told, "Get down from the Ark. Your Lord's peace and blessings are upon you and your followers. Your Lord will grant favors to other nations and then afflict them with a painful torment."

# 1522

That which We have revealed to you (Muhammad) is news of the unseen. This was not known to you and to your people. Have patience. The pious will triumph in the end.

# 1523

To the tribe of Ad We sent their brother Hud who told them, "Worship God; He is your only Lord. The idols that you worship are plainly false.

# 1524

My people, I do not ask any reward for what I have preached to you. No one can give me my reward except my Creator. Will you then not take heed?

# 1525

"My people, seek forgiveness from your Lord and turn to Him in repentance. He will send you abundant rain from the sky and will increase your power. Do not sinfully turn away from Him."

# 1526

They said, "Hud, you have not shown us any miracles. We shall not give up our idols because of what you say and we shall not have any faith in you.

# 1527

We believe that some of our gods have afflicted you with evil." Hud said, "God is my witness and so are you that I have no association

# 1528

with the idols that you worship besides God. So plan against me without delay.

# 1529

I trust God who is my Lord as well as yours. It is God who controls the destiny of all living creatures. It is my Lord who knows the right path.

# 1530

If you turn away from Him (since I have already preached to you the message that I carry), He will replace you with another nation. You cannot harm Him the least. My Lord is the Protector of all things."

# 1531

When Our decree (of destroying them) was fulfilled, We mercifully saved Hud and his believing followers. We saved them from the intense torment.

# 1532

It was the tribe of \`Ad who denied the miracles of their Lord, disobeyed His Messenger and followed the orders of every transgressing tyrant.

# 1533

They were condemned in this life and will be condemned in the life hereafter. The tribe of Ad had certainly rejected their Lord. God kept the tribe of Ad, the people of Hud, away from His mercy.

# 1534

To Thamud We sent their brother Salih who told them, "My people, worship God; He is your only Lord. It is He who has created you from the earth and has settled you therein. Seek forgiveness from Him and turn to Him in repentance. My Lord is certainly close to everyone and He hears all prayers."

# 1535

They said, "Salih, we had great hope in you before this. Do you forbid us to worship that which our fathers had worshipped? We are doubtful and uncertain about what you have told us to worship."

# 1536

He said, "My people, think. I have received authoritative evidence and mercy from my Lord, so who will protect me from God if I disobey Him? You certainly want to destroy me.

# 1537

My people, this is the she-camel of God, a miracle (to support the truth which has been brought) to you. Leave her to graze in the land of God. Do not harm her with your evil deeds lest torment will suddenly strike you."

# 1538

When they slew the she-camel, Salih told them, "You have only three days to enjoy living in your homes (before you will be struck by the torment). This is an inevitable prophecy."

# 1539

When Our decree came to pass. We mercifully saved Salih and his faithful followers from that day's ignominy. Your Lord is certainly Mighty and Majestic.

# 1540

A blast struck the unjust and they were found lying motionless on their faces

# 1541

as though they had never existed. The people of Thamud denied the existence of their Lord. How distant from the mercy of God had the people of Thamud gone!

# 1542

Our Messengers came to Abraham with glad news. They said, "Peace be with you." He replied similarly. After a short time he presented them with a roasted calf

# 1543

but when he saw that their hands did not reach out for it, he could not know who they were and became afraid of them. They said, "Do not be afraid; we are God's angelic Messengers sent to the people of Lot."

# 1544

His wife who was standing nearby, smiled and so We gave her the glad news that she would give birth to Isaac who would have a son, Jacob.

# 1545

She said, "Woe is me! How can I have a baby when I am barren and my husband is very old? This is certainly strange".

# 1546

They replied, "Would you be surprised at God's decree? People of the house, may God's mercy and blessings be with you. God is Appreciative and Glorious."

# 1547

When Abraham had controlled his fear and received the glad news, he started to plead with Us for the people of Lot;

# 1548

Abraham was certainly a forbearing, compassionate, and tender-hearted person.

# 1549

We said, "Abraham, avoid asking Us such questions. Your Lord's decree has already been issued and an inevitable torment will strike these people."

# 1550

When Our Messengers came to Lot, he became sorrowful and felt totally helpless. He said, "This is indeed a distressful day".

# 1551

His people, who had constantly indulged in evil deeds, came running to him. He said, "My people, here are my pure daughters. Have fear of God and do not humiliate me before my guests. Is there no person of understanding among you?"

# 1552

They said, "You certainly know that we have no right to your daughters and you know what we want".

# 1553

He said, "Would that I had the power (to overcome you) or could seek strong protection."

# 1554

Our Messengers said, "Lot, we are the Messengers of your Lord. They will never harm you. Leave the town with your family in the darkness of night and do not let any of you turn back. As for your wife, she will suffer what they (unbelievers) will suffer. Their appointed time will come at dawn. Surely dawn is not far away!

# 1555

When Our decree came to pass, We turned the town upside-down and showered unto it lumps of baked clay,

# 1556

marked by your Lord. Such a punishment is not far away from the unjust people.

# 1557

To the people of Midian We sent their brother Shu'ayb who told them, "My people, worship God; He is your only Lord. Do not be dishonest in your weighing and measuring. I can see you are safe and prosperous, but I am afraid for you of the overwhelming torment of the (appointed) day.

# 1558

My people, be just in your weighing and measuring. Do not defraud people or spread evil in the land.

# 1559

If you are true believers then know that the profit which God has left for you is better for you (than what you may gain through deceitful ways). I am not responsible for your deeds."

# 1560

They asked him, "Shu'ayb, do your prayers tell you that we must give up the worship of what our fathers had worshipped and that we must not deal with our properties as we like? We still believe that you are a person of forbearance and understanding."

# 1561

He said, "My people, do you not realize that I have received authoritative evidence from my Lord and have been granted a noble gift from Him? I do not want to oppose or ignore what I have prohibited you not to do. I only intend to reform you as much as I can. My success is in the hands of God. I trust Him and turn to Him in repentance.

# 1562

My people, do not let your opposition to me lead you to commit sins or make you suffer what the people of Noah, Hud, and Salih suffered. Remember that the people of Lot were destroyed not very long ago.

# 1563

Seek forgiveness from your Lord and turn to Him in repentance. My Lord is certainly All-merciful and Loving."

# 1564

They said, "Shu'ayb, we do not understand much of what you say, but we know that you are weak among us. Had it not been for our respect of your tribe, we would have stoned you to death; you are not very dear to us".

# 1565

He asked them, "My people, is my tribe more respectable to you than God whom you have completely ignored? My Lord certainly has full control over your deeds.

# 1566

My people, do as you wish and I will do (as I believe). You will soon know who will suffer a humiliating torment and who was the one telling lies. Wait and I too will be waiting with you."

# 1567

When Our decree came to pass, We mercifully saved Shu'ayb and his faithful followers. A blast struck the unjust and left them in their homes, lying motionless on their faces,

# 1568

as though they had never existed. How far from (the mercy of God) had the people of Midian gone, just as those of Thamud?

# 1569

We sent Moses to the Pharaoh and his nobles with Our miracles and a clear authority.

# 1570

They followed the order of the Pharaoh but Pharaoh's orders were evil.

# 1571

On the Day of Judgment he will lead his people down into the hell fire. His leadership is evil and terrible is the place to which he leads!

# 1572

They are condemned in this world and in the life to come. Evil is the gift and the recipient!

# 1573

Such were the stories of the nations of the past which We tell to you, (Muhammad). Some of them were destroyed and some of them have survived.

# 1574

We were not unjust to them but they were unjust to themselves. The idols which they worshipped instead of God were of no help to them when Our decree came to pass. The idols only brought about their destruction.

# 1575

Thus was the punishment of your Lord when He punished the unjust people of the towns. The punishment of your Lord is certainly severe.

# 1576

In this there is, certainly, a lesson for those who fear the torment of the next life in which all people will be gathered together

# 1577

during a single day. We have deferred this day for an appointed time.

# 1578

On the Day of Judgment no one will speak without the permission of God. Some will be condemned and others blessed.

# 1579

The condemned ones will live in hell fire, sighing and groaning

# 1580

for as long as the heavens and the earth exist, unless your Lord decides otherwise. Your Lord will certainly accomplish whatever He wants.

# 1581

The blessed ones will live in Paradise as long as the heavens and the earth exist, unless your Lord decides to grant endless rewards to whomever He wants.

# 1582

Have no doubt that these people worship (idols). They worship what their fathers had worshipped before them. We will give them the exact recompense that they deserve.

# 1583

We gave the Book to Moses but people had different views about it. Had the Word of your Lord not been already ordained, He would have settled their differences (there and then). They are still in doubt about this.

# 1584

God will certainly recompense everyone according to their deeds; He knows well all that you do.

# 1585

(Muhammad), be steadfast (in your faith) just as you have been commanded. Those who have turned to God in repentance with you, should also be steadfast in their faith. Do not indulge in rebellion. God is certainly aware of what you do.

# 1586

Do not be inclined towards the unjust ones lest you will be afflicted by the hell fire. Besides God, no one can be your protector nor will anyone be able to help you.

# 1587

Say your prayers in the morning, the last portion of the day, and at the beginning of the night. Good deeds do away with the bad deeds. This is a reminder for those who take heed.

# 1588

Exercise patience; God does not ignore the reward of those who do good.

# 1589

Why were there no people of understanding among those people of the destroyed towns of the past except for a few, whom we saved from destruction, to prevent people from committing evil in the land? The unjust among them indulged in worldly pleasures and so became guilty.

# 1590

Your Lord would not have destroyed those people (of the towns) for their injustice if they had tried to reform themselves.

# 1591

Had your Lord wanted, He would have made all people one united nation. They still have different beliefs

# 1592

except those upon whom God has granted His mercy. God has created them to receive mercy. The decree of your Lord that He will fill hell with both jinn and human beings has already been ordained.

# 1593

(Muhammad), We tell you all the stories of the Messengers which will strengthen your heart. In the Quran We have revealed the Truth to you with good advice and reminders for the faithful ones.

# 1594

Tell the unbelievers, "Do as you wish and I will do as I believe.

# 1595

Wait, and I, too, will be waiting with you."

# 1596

To God belongs the knowledge of the unseen in the heavens and the earth and to Him do all affairs return. Worship Him and trust Him. Your Lord is not unaware of what you do.

# 1597

Alif. Lam. Ra. These are the verses of the illustrious Book.

# 1598

We have revealed it in the Arabic language so that you (people) would understand it.

# 1599

In revealing this Quran to you, We tell you the best of the stories of which you were unaware.

# 1600

When Joseph said, "Father, in my dream I saw eleven stars, the sun and the moon prostrating before me,"

# 1601

his father said, "My son, do not tell your dream to your brothers lest they plot against you; satan is the sworn enemy of man.

# 1602

Thus, your Lord will select you, teach you the interpretation of dreams, and grant His favors to you and the family of Jacob, just as He granted His favors to your fathers, Abraham and Isaac. Your Lord is certainly All-knowing and All-wise."

# 1603

In the story of Joseph and his brothers, there is evidence (of the truth) for those who seek to know.

# 1604

Joseph's brothers said to one another, "There is no doubt that Joseph and his brother are more loved by our father, even though we are all his offspring. He (our father) is certainly in manifest error."

# 1605

Some of them suggested, "Let us kill Joseph or leave him somewhere far away from the presence of our father. Only then shall we receive equal treatment and thereafter can become righteous people".

# 1606

One of them said, "Do not kill Joseph, but if you must, throw him into a dark well so that perhaps some caravan will take him away."

# 1607

Then they asked their father, "Why do you not trust us with Joseph? We are his well-wishers.

# 1608

Send him with us tomorrow to play with us and enjoy himself. We shall carefully protect him".

# 1609

Jacob replied, "I shall be grieved if you take him with you; I fear that some wild-beast will harm him in your absence."

# 1610

They said, "If some wild-beast would be able to harm him, despite the presence of our strong group, it would certainly be a great loss to us!"

# 1611

When they took Joseph with them, they agreed to throw him into the well. We revealed to Joseph that (sometime) in the future at a time when they would not recognize him, he would remind them of all this.

# 1612

In the evening they returned to their father weeping

# 1613

and saying, "Father, we went playing and left Joseph with our belongings. A wild-beast came and devoured him. We realize that you will not believe us even though we are telling the truth".

# 1614

They presented him with a shirt stained with false blood. Jacob said, "Your souls have tempted you in this matter. Let us be patient and beg assistance from God if what you say is true."

# 1615

A caravan came by and sent their water carrier out to the well. When he drew out Joseph in his bucket, he shouted, "Glad news, a young boy!" The people of the caravan hid him amongst their belongings. God knows well what they do.

# 1616

In selling him they asked for a very small price and even then no one wanted to buy him.

# 1617

The Egyptian who bought him said to his wife, "Be kind to him, perhaps he will be of some benefit to us or we may adopt him." Thus, We settled Joseph in the land so that We could teach him the interpretation of dreams. God has full control over His affairs but most people do not know.

# 1618

When he attained maturity, God gave him strength, wisdom and knowledge. Thus, do We reward those who do good.

# 1619

His master's wife then tried to seduce him. She locked the doors and said to him, "Come on." He said, "I seek refuge in God who has given me a good place of shelter. The unjust will certainly have no happiness."

# 1620

She was determined to have him and were it not for his faith in God, he would certainly have yielded to her. Thus did We protect him from evil and indecency. He was certainly one of Our sincere servants.

# 1621

She chased him to the door, grabbed him from behind, and tore off his shirt. Suddenly, they were face to face with her husband. (Looking accusingly at Joseph) she asked her husband, "What punishment is more fitting for those who have evil desires towards your household other than imprisonment and painful torment?"

# 1622

Joseph said, "It was she who tried to seduce me." Someone from the household in confirmation of Joseph's statement said, "If his shirt it torn from the front, she has spoken the truth and he is lying,

# 1623

but if his shirt is torn from behind, she is lying and he is speaking the truth."

# 1624

When the master saw that Joseph's shirt was torn from behind, he told his wife, "This is some of your womanly guile in which you are certainly skillful.

# 1625

Joseph, stay away from such affairs and you, woman, ask forgiveness for your sin; the guilt is yours."

# 1626

Some of the women in the town started to gossip saying, "The King's wife has tried to seduce her servant and has fallen madly in love with him. We think that she is in manifest error".

# 1627

When she heard their gossiping, she invited them to her house for a banquet and gave a knife to each of them. Then she told Joseph to appear before them. When they saw Joseph, they were so amazed that they cut their hands and said, "Goodness gracious! He is not a mortal but is a charming angel!"

# 1628

She said, "This is the one on whose account you subjected me to all this blame. I tried to seduce him but he abstained. If he does not yield to me, I shall order him to be locked up in prison to make him humble."

# 1629

Joseph said, "Lord, prison is dearer to me than that which women want me to do. Unless You protect me from their guile, I shall be attracted to them in my ignorance".

# 1630

His Lord heard his prayers and protected him from their guile; He is All-hearing and All-knowing.

# 1631

Even after Joseph had been found innocent of any crime, the King and his people decided to imprison him for an appointed time (so that people would forget the incident).

# 1632

Two young men were also sent to serve prison sentences (for different reasons). One of them said, "I had a dream in which I was brewing wine." The other one said, "In my dream I was carrying some bread on my head and birds were eating that bread." They asked Joseph if he would interpret their dreams. They said, "We believe you to be a righteous person."

# 1633

(Joseph) said, "To prove that my interpretation of your dream is true, I can tell you what kind of food you will receive even before it comes to you. My Lord has given me such talents. I have given up the tradition of the people who do not believe in God and the Day of Judgment

# 1634

and I have embraced the religion of my fathers, Abraham, Isaac, and Jacob. We are not supposed to consider anything equal to God. This is part of God's blessing to us and the people, but most people do not give thanks.

# 1635

"My fellow-prisoners can many different masters be considered better than One All-dominant God?

# 1636

What you worship instead of God are no more than empty names that you and your fathers have given to certain things. God has not given any authority to such names. Judgment belongs to no one but God. He has commanded you to worship nothing but Him. This is the only true religion, but most people do not know.

# 1637

"Fellow-prisoners, your dreams tell that one of you will serve wine to his master and the other will be crucified and his head consumed by the birds. Judgment has already been passed about the meaning of the dreams that you asked about."

# 1638

Joseph asked the one, whom he knew would not be executed, to mention his case to his Lord. Satan caused that man to forget all about Joseph and his case. Thus, Joseph remained in prison for some years.

# 1639

(Sometimes later), the King dreamt that seven lean cows were eating seven fat ones and that there were seven green ears of corn and seven dry ones. He asked the nobles to tell him the meaning of his dream if they were able to.

# 1640

They replied, "It is a confused dream and we do not know the meaning of such dreams."

# 1641

The man who was in prison with Joseph and who was released, recalled after so many years Joseph's (ability to interpret dreams) and said, "I can tell you the meaning of this dream if you allow me to go (to the prison and ask the man who knows the meanings of dreams)."

# 1642

(He went to the prison) and said to Joseph, "You are a man of truth. Would you tell me the meaning of a dream in which seven fat cows eat up seven lean ones and the meaning of seven green ears of corn and seven dry ones? I hope you can tell me the right meaning and save people from confusion."

# 1643

(Joseph) said, "Cultivate your lands for seven years as usual and preserve the produce with its ears each year except the little amount that you will consume.

# 1644

After this will ensue seven years of famine in which all the grain that you have stored will be consumed except a small quantity.

# 1645

Then there will be a year with plenty of rain and people will have sufficient milk and other produce."

# 1646

The King ordered his people to bring Joseph into his presence. When the messenger came to Joseph, he (Joseph) said, "Ask your master about the women who cut their hands. My Lord knows all about their guile".

# 1647

The King asked the women about their attempt to seduce Joseph. They replied, "God forbid! We do not know of any bad in Joseph." The wife of the King said, "Now the truth has come to light. It was I who tried to seduce Joseph. He is, certainly, a truthful man."

# 1648

(Joseph said), "This proves that I was not disloyal to the King in his absence. God does not grant success to the efforts of disloyal people.

# 1649

"I do not think that I am free from weakness; all human souls are susceptible to evil except for those to whom my Lord has granted mercy. My Lord is certainly All-forgiving and All-merciful."

# 1650

The King ordered his men to bring Joseph before him. He wanted to grant him a high office. The King said to Joseph, "From now on you will be an honored and trusted person among us".

# 1651

Joseph said, "Put me in charge of the treasuries of the land. I know how to manage them."

# 1652

Thus, We settled Joseph in the land to live wherever he wanted. We grant a due share of Our mercy to whomever We want and We do not ignore the reward of the righteous ones.

# 1653

The reward in the next life is certainly better for the faithful ones who have observed piety in this life.

# 1654

Joseph's brothers came to him. When they entered his court, he recognized them. They did not know him.

# 1655

When he had furnished them with provisions, he said, "Next time, bring me your other brother from your father. As you can see, I give each of you a certain amount of grain; I am a polite host.

# 1656

If you do not bring him, do not come to us for we shall not give you any more grain."

# 1657

Joseph's brothers said, "We shall try to influence his father to send him with us and we shall be successful".

# 1658

Then Joseph told his people to put his brothers' money back into their bags so that perhaps they would recognize it, when at home, and come back to Egypt once again.

# 1659

When they returned to their father, they told him, "Father, (unless we take our brother) they will refuse us one further measure of grain. Send our brother with us so that we can obtain that measure. We shall watch over him carefully".

# 1660

Jacob replied, "How can I trust you after what happened to his brother before? Only God is the best Protector. His mercy is far greater than that of others."

# 1661

When they opened their baggage, they found that their money had been returned to them. They said, "Father, what more do we want? Our money has been given back to us. We can buy more provisions with this for our family. We shall protect our brother and have one more camel load of grain which is easy to get".

# 1662

(Jacob) said, "I shall not send him with you until you solemnly promise me before God to return him to me unless you are prevented from doing so." When they gave their promise, he said, "God is the Witness of what we have said".

# 1663

Jacob then told his sons, "Do not enter the town all together by a single gate, but each of you enter separately. I cannot help you against (the decree of) God. Everyone's destiny is in His hands. I put my trust in Him. Whoever needs a trustee must put his trust in God."

# 1664

Even though they entered the town as their father had told them, it would not have been of any avail to them against the decree of God. It only served to satisfy Jacob's desire and judgment. He was certainly well versed by Our instruction, but most people do not know.

# 1665

When they entered Joseph's court, he gave lodging to his own brother (Benjamin) and said, "I am your brother. Do not feel sad about whatever they had done".

# 1666

When he had furnished them with provisions, he placed the King's drinking cup in his own brother's baggage. Then someone shouted, "People of the caravan, you are thieves!"

# 1667

Joseph's brothers turned around and asked, "What is missing?"

# 1668

They were told, "The King's drinking cup is missing and whoever brings it will receive a camel's load of grain. I promise you that".

# 1669

Joseph's brothers said, "We swear by God, as you know, that we have not come to spread evil in the land and that we have not committed any theft."

# 1670

The Egyptians said, "What do you suggest should be the punishment for the thief, if it is proved that you are lying?"

# 1671

Joseph's brothers replied, "In whosoever baggage it is found, that person will be your bondsman. Thus is the punishment of the unjust."

# 1672

They searched their baggage before that of Joseph's real brother where at last they found it. Thus, We showed Joseph how to plan this; he would not have been able to take his brother under the King's law unless God had wanted it to be so. We give a high rank to whomever We want. Over every knowledgeable person is one more knowing.

# 1673

(Joseph's) brothers said, "It's no wonder that he steals; a brother of his had stolen before him." Joseph noted their remarks, but did not utter a word. He said (to himself), "You are in a worse position. God knows best what you allege."

# 1674

They said, "Noble Prince, his father is very old so please take one of us in his place. We believe that you are a righteous person".

# 1675

He replied, "God forbid! How could I take someone in place of the thief? In doing so I would be committing injustice."

# 1676

When they lost all hope (of convincing the Prince), they moved into a corner whispering to each other. The eldest among them said, "Do you not remember that you had solemnly promised our father to return Benjamin to him and that before this you had broken your promise concerning Joseph? I shall never leave this land until my father gives me permission or God decides for me; He is the best Judge.

# 1677

"Go to our father and tell him, 'Father, your son committed theft. We say only what we have seen and we have no control over the unseen.

# 1678

You can ask the people of the town where we were and the caravan we met there. We are certainly telling the truth."

# 1679

(When he heard this), Jacob said, "Your souls have tempted you to make up the whole story. Let us be patient for perhaps God will bring them all back to me. God is certainly All-knowing and All-wise".

# 1680

(Jacob) turned away from them saying, "Alas, Joseph is lost!" He wept continuously in his grief until, in suppressing his anger, his eyes turned white.

# 1681

They said, "You are always remembering Joseph. By God, it will either make you sick or you will die".

# 1682

He replied, "I only complain of my sorrow and grief to God. I know about God what you do not know.

# 1683

My sons, go and search for Joseph and his brother and do not despair of receiving comfort from God; only the unbelievers despair of receiving comfort from Him."

# 1684

When they entered Joseph's court, they said, "Noble Prince, hardship has struck us and our people. We have come with a little money, so give us a measure of grain and be charitable to us. God will give the reward to those who give charity".

# 1685

Joseph asked them, "Do you know what you did to Joseph and his brother in your ignorance?"

# 1686

Then they inquired, "Are you Joseph?" He said, "Yes, I am Joseph and this is my brother. God has indeed been gracious to us. One who exercises patience and observes piety should know that God does not ignore the reward of the righteous ones."

# 1687

They said, "We swear by God that He has given preference to you over us and we have sinned".

# 1688

(Joseph) said, "No one will blame you on this day. God will forgive you; He is more Merciful than others.

# 1689

Take my shirt and place it unto my father's face. This will restore his eye-sight. Then bring the whole family to me."

# 1690

When the caravan left the town, their father said, "I smell Joseph's scent. I hope that you will not accuse me of senility".

# 1691

His people said, "By God, you are still making the same old error".

# 1692

When someone brought him the glad news, Joseph's shirt was placed on his face and his eye-sight was restored, he said, "Did I not tell you that I know about God that which you do not know?"

# 1693

They said, "Father, ask God to forgive our sins; we have certainly sinned".

# 1694

He said, "I shall ask my Lord to forgive you; He is All-forgiving and All-merciful."

# 1695

When they all came to Joseph, he welcomed his parents and said, "Enter the town in peace, if God wants it to be so."

# 1696

He raised his parents on the throne and they prostrated themselves before him (Joseph). He said, "This is the meaning of my dream which God has made come true. He has granted me many favors. He set me free from prison and brought you to me from the desert after having ended the enmity which satan sowed between my brothers and I. My Lord is certainly kind to whomever He wants. It is He who is All-forgiving and All-wise.

# 1697

"My Lord, You have given me the kingdom and taught me the meaning of dreams. You are the Creator of the heavens and the earth. You are my Guardian in this world and in the life to come. Make me die as one who has submitted to the Will of God and unite me with the righteous ones."

# 1698

This is some of the news of the unseen which We reveal to you, (Muhammad). You were not with them when Joseph's brothers agreed on devising their evil plans.

# 1699

However hard you try, most people will not believe.

# 1700

You do not ask any reward for your preaching (of Our guidance to them). This (Quran) is a guide for the people of the world (human beings and jinn).

# 1701

There is much evidence (of the existence of God) in the heavens and the earth which they see, but ignore.

# 1702

Most of them do not believe in God; they are but pagans.

# 1703

Do they feel safe from God's overwhelming torment or of the sudden approach of the Day of Judgment while they are unaware?

# 1704

(Muhammad), say, "This is my way. I and all my followers invite you to God with proper understanding. God is most Glorious. I am not a pagan."

# 1705

The Messengers whom We sent before you were mere men of the people of the towns. We gave them revelations. Have they (the unbelievers) not travelled sufficiently through the land to see how terrible the end was of those who lived before. The next life is, certainly, better for the pious ones. Will you not then take heed?

# 1706

When at last the Messengers lost all hope of achieving success in their task and thought that everyone had called them liars, We gave them victory and saved whomever We chose to save. The guilty ones can not escape Our wrath.

# 1707

In their story, there is a lesson for the people of understanding. It is not a legend but a confirmation of what exists (in the Torah). It (the Quran) has details about everything. It is a guide and mercy for those who have faith.

# 1708

Alif. Lam. Mim. Ra. These are the verses of the Book. Whatever is revealed to you from your Lord is the Truth, but most people do not believe.

# 1709

God is the One Who raised the heavens without a pillar as you can see. Then He established his control over the realm and made the sun and moon subservient to Him. Each of them will remain in motion for an appointed time. He regulates all affairs and explains the evidence (of His existence) so that perhaps you will be certain of your meeting with your Lord.

# 1710

It is God who spread out the earth and fixed mountains and placed rivers therein. He made a pair of every fruit and made the night cover the day. All this is evidence (of the existence of God) for the people who think.

# 1711

In the earth there are adjacent pieces of land, vineyards, farms, date-palms of single and many roots which are all watered by the same water. We have made some yield a better food than others. All this is evidence (of the existence of God) for the people who understand.

# 1712

If there is anything to make you wonder, it would be the words of those who say, "When we become dust, shall we be brought back to life again?" They are disbelievers in their Lord and will wear heavy fetters around their necks. They are the dwellers of the hell fire wherein they will live forever.

# 1713

They ask you to bring upon them punishment before they ask you for mercy. Such punishments were already brought upon the people who lived before them. Your Lord, certainly, has forgiveness for the injustice of the people. He is also stern in His retribution.

# 1714

The unbelievers say, "Why has God not sent him, (Muhammad), some miracles." (Muhammad), you are only a warner. For every nation there is a guide.

# 1715

God knows well what every female conceives. He knows what the wombs spoil and dispose of. In His plans everything has been designed proportionately.

# 1716

He knows all the unseen and seen. He is the most Great and High.

# 1717

It is all the same to Him whether you speak in secret or out loud, try to hide in the darkness of night or walk in the brightness of day.

# 1718

Everyone is guarded and protected on all sides by the order of God. God does not change the condition of a nation unless it changes what is in its heart. When God wants to punish a people, there is no way to escape from it and no one besides God will protect them from it.

# 1719

It is God who flashes lightning to frighten you and to give you hope. It is He who forms the heavy clouds.

# 1720

Both the thunder and the angels glorify Him and out of His fear always praise Him. He sends down thunder-bolts to strike whomever He wants, while they are busy arguing about the existence of God. His punishment is stern.

# 1721

Prayer to Him is the true prayer. Those to whom they pray instead of God will answer none of their prayers. It is as though one stretches his hands out to the water that can never reach his mouth. The prayers of the unbelievers will get nowhere.

# 1722

All in the heavens and the earth prostrate themselves before God, either of their own free will or by force, just as do their shadows in the mornings and evenings.

# 1723

(Muhammad), ask them, "Who is the Lord of the heavens and the earth?" Say, "It is God." Ask them, "Why then have you taken guardians other than God when such guardians can neither benefit nor harm themselves?" Ask them, "Are the seeing and the blind equal? Is light equal to darkness?" Do they consider that their idols have created anything like that of God, thus, both creations appear to them to be alike?" Say, "God alone is the Creator of all things and He is the One, the All-Dominant."

# 1724

When God sends down water from the sky and floods run through the valleys, certain quantities of foam rise on the surface of the flood water. This is similar to that foam which rises when you expose something to the heat of a fire to manufacture ornaments or for other reasons. To God Truth and falsehood are like these examples. The foam disappears but what is profitable to the human being stays in the land. Thus, does God coin His parables.

# 1725

Those who answer the call of their Lord will receive good rewards. Whatever those who have not answered the call of their Lord offer to redeem themselves, even if they offer double the wealth of the whole earth, will not be accepted. They will face a terrible reckoning and their dwelling will be hell, a terrible place to rest!

# 1726

Can a person, who knows that what is revealed to you from your Lord is the truth, be considered equal to a blind person? Only those who have understanding take heed.

# 1727

Those who fulfill their promise to and covenant with God,

# 1728

who maintain all the proper relations that God has commanded them to maintain, who have fear of their Lord and the hardships of the Day of Judgment,

# 1729

who exercise patience to gain God's pleasure, who are steadfast in prayer, who spend for the cause of God privately and in public, and who keep away evil with good will have a blissful end.

# 1730

They will be admitted to the gardens of Eden wherein they will live forever with their righteous fathers, spouses, and offspring. The angels will come to them through every gate

# 1731

saying, "Peace be with you for all that you have patiently endured. Blessed is the reward of Paradise."

# 1732

Those who disregard their covenant with God after He has taken such a pledge from them, who sever the proper relations that God has commanded them to establish, and those who spread evil in the land will have God's condemnation instead of reward and will face the most terrible end.

# 1733

God gives abundant sustenance to whomever He wants and determines everyone's destiny. Some people are very happy with the worldly life. Compared to the life to come it is only a temporary means.

# 1734

The unbelievers say, "Why have not some miracles been sent to him, (Muhammad), from his Lord." Say, "God causes whomever He wants to go astray and He guides those who turn to Him in repentance

# 1735

and the faithful ones whose hearts are comforted by the remembrance of God. Remembrance of God certainly brings comfort to all hearts.

# 1736

The righteously striving believers will receive abundant blessings and the best eternal dwelling.

# 1737

We have sent you to a nation before whom there lived many nations so that you would read to them what We have revealed to you. They still deny the existence of the Beneficent God. Say, "He is my Lord besides whom there is no other God. I trust Him and turn to Him in repentance."

# 1738

Even if the Quran would make mountains move, cut the earth into pieces and make the dead able to speak, (the unbelievers still would not believe). All affairs are in the hands of God. Do the believers still hope that they will believe? Had God wanted he could have guided the whole of mankind to the right path. The unbelievers will always suffer afflictions that result from their deeds or the affliction which occur near their homes, until God's promise of punishing them will be fulfilled. God does not disregard His promise.

# 1739

(Muhammad), people have mocked the Messengers who lived before you. I gave a respite to the unbelievers (so that they would repent, but they did not). Then I struck them with a terrible retribution.

# 1740

(Can anyone be considered equal to) the One who is the Guardian of every soul and the Watcher of what it has gained? Yet, the unbelievers have considered their idols equal to God. Say, "Name the attributes of your idols. Are you trying to tell God about something that does not exist on the earth? Do you only mention empty names? Evil plans have attracted the unbelievers and have misled them from the right path. No one can guide those whom God has caused to go astray.

# 1741

The unbelievers will face torment in this world and their punishment in the life hereafter will be even greater. No one can save them from the wrath of God.

# 1742

The gardens which have been promised to the pious have flowing streams, everlasting fruits, and perpetual shade. Such is the blissful end of the pious, but hell fire is the terrible end for the unbelievers.

# 1743

The People of the Book are happy with what has been revealed to you. Among the different parties, there are some who dislike part of what has been revealed to you. (Muhammad), tell them, "I have been commanded to worship God alone, not to consider anything equal to Him. To Him do I pray and to Him shall I return."

# 1744

We revealed it (the Quran) as a code of conduct in the Arabic language. (Muhammad), if you follow their desires after the knowledge has been revealed to you, know that no one will be able to guard or protect you from the wrath of God.

# 1745

We sent Messengers before you (Muhammad) and gave them wives and offspring. No Messenger was to show miracles without the permission of God.

# 1746

For every event God has ordained His decree. God establishes or effaces whatever He wants and with Him is the original of the Book.

# 1747

Whether We show them (the unbelievers) to you facing the punishment with which We had threatened them, or make you die first (before its fulfillment), your duty is only to preach. It is up to Us to call them to account (for their deeds).

# 1748

Have they not considered that We have taken over the land and reduced its borders? It is God who issues the irreversible decree and His reckoning is swift.

# 1749

Certain people who lived before plotted evil plans but God is the Master of all plans. He knows what every soul does. The unbelievers will soon learn who will achieve the blissful end.

# 1750

(Muhammad), the unbelievers say, "You are not a Messenger." Say, "God and those who have the knowledge of the Book are sufficient witness (to my prophethood)."

# 1751

Alif. Lam. Ra. A Book has been revealed to you, (Muhammad), so that, by the permission of their Lord, you would be able to lead people from darkness into light along the path of the Majestic, Praised One.

# 1752

To God belongs whatever is in the heavens and the earth. Woe to the disbelievers; they will face the most severe punishment!

# 1753

It is they who have given preference to the worldly life over the life to come. They create obstacles in the way that leads to God and try to make it seem crooked. They are in manifest error.

# 1754

All the Messengers that We sent spoke the language of their people so that they could explain (their message to them). God guides or causes to go astray whomever He wants. He is Majestic and All-wise.

# 1755

We sent Moses and gave him miracles in order to lead his people from darkness into light and to remind them of the days of God. In this there is evidence (of the truth) for those who exercise patience and give thanks.

# 1756

Moses told his people, "Remember the favors that God granted you when He saved you from the people of the Pharaoh who had punished you in the worst manner by murdering your sons and keeping your women alive. It was a great trial for you from your Lord.

# 1757

"Remember when your Lord said to you, 'If you give thanks, I shall give you greater (favors), but if you deny the Truth, know that My retribution is severe ".

# 1758

Moses told his people, "If you and everyone on the earth turn to disbelief, know that God is Self-sufficient and Praiseworthy."

# 1759

Have you (believers) ever heard the news about those who lived before you, like the people of Noah, Ad, Thamud, and those who lived after them? No one knows about them except God. Messengers were sent to them with miracles, but they put their hands to their mouths and said, "We do not believe in whatever you preach and we are also doubtful and uncertain about that to which you invite us."

# 1760

The Messengers asked them, "Could there be any doubt about the existence of God who has created the heavens and the earth? He calls you to Himself to forgive your sins. He gives you respite only until the appointed time." They said, "You are mere mortals like us. What you want is to prevent us from worshipping that which our fathers worshipped. Show us clear proof (if what you say is true)."

# 1761

The Messengers replied, "We are certainly mere mortals like you, but God bestows His favors on whichever of His servants He wants. We can not bring you authority without the permission of God. The faithful should trust in God alone.

# 1762

Why should we not trust in God when He has shown us the right way? We shall exercise patience against the troubles with which you afflict us. Whoever needs a trustee should trust in God."

# 1763

The disbelievers told the Messengers, "We shall expel you from our land unless you revert to our religion." Their Lord then sent them (the messengers) a revelation, "We have decided to destroy the unjust

# 1764

and settle you in the land thereafter. This is for those who are afraid of Me and of My warning."

# 1765

They prayed for victory and the haughty transgressors were defeated.

# 1766

Thereafter they will face hell fire wherein they will drink boiling water.

# 1767

As they sip the unpleasant water, death will approach them from all sides, but they will never die. In addition to this, they will experience the most intense torment.

# 1768

The deeds of those who deny the existence of their Lord are like ashes blown about by a strong wind on a stormy day. They will achieve nothing from their deeds. (What they have done) is a manifest error.

# 1769

Do you not realize that God has created the heavens and the earth for a genuine purpose

# 1770

and that it is not at all difficult for God to replace you with another creature if He so wills?

# 1771

(On the Day of Judgment) everyone will appear before God and those who have been suppressed will say to their oppressors, "We were your followers, can you do anything to rescue us from the torment of God?" They will reply, "Had God guided us, we would also have guided you. It makes no difference whether we cry for help or exercise patience; there is no escape for us."

# 1772

When the decree of God is issued, satan will say, "God's promise to you was true, but I, too, made a promise to you and disregarded it. I had no authority over you. I just called you and you answered. Do not blame me but blame yourselves. I cannot help you and you cannot help me. I did not agree with your belief that I was equal to God." The unjust will face a painful punishment.

# 1773

The righteously striving believers will be admitted to the gardens wherein streams flow and they will live therein forever, by the permission of their Lord. Their greeting to each other will be, "Peace be with you."

# 1774

Consider (Muhammad) how God (in a parable) compares the blessed Word to that of a blessed tree which has firm roots and branches rising up into the sky

# 1775

and yields fruits in every season, by the permission of its Lord? God sets forth parables for people so that they may take heed.

# 1776

An evil word is compared to an evil tree with no firm roots in the land and thus has no stability.

# 1777

God strengthens the faith of the believers by the true Words in this world and in the life to come. He causes the unjust to go astray and does whatever He pleases.

# 1778

Have you not seen those who changed the Word of God through disbelief and led their people to destruction?

# 1779

They will suffer in Hell. What a terrible place to stay!

# 1780

To lead people astray, they claimed their idols were equal to God. (Muhammad), tell them, "Enjoy yourselves and know that the only place for you to go will be hell fire."

# 1781

Tell My believing servants to be steadfast in prayer and to spend for the cause of their Lord, both in private and in public, out of what We have given them. Let them do this before the coming of the day when there will be no merchandising or friendship.

# 1782

God is the One who created the heavens and the earth, sent down water from the sky by which He produced fruits for your sustenance, enabled you to use boats to sail on the sea, and placed the rivers at your disposal, all by His command.

# 1783

He made the sun and moon, each following its course, and the day and the night all subservient to you.

# 1784

He has given you everything that you asked Him for. Had you wanted to count the bounties of God, you would not have been able to do it. The human being is unjust and disbelieving.

# 1785

(Muhammad), consider when Abraham prayed, "Lord, make this (Mecca) a peaceful territory and save me and my offspring from worshipping idols.

# 1786

Lord, the idols have misled many people. Whoever follows me is my friend. As for those who disobey, You are certainly All-forgiving and All-merciful.

# 1787

"Lord, I have settled some of my offspring in a barren valley near your Sacred House so that they could be steadfast in prayer. Lord, fill the hearts of the people with love for them and produce fruits for their sustenance so that they may give thanks.

# 1788

Lord, You know all that we conceal or reveal. Nothing in the heavens or the earth is hidden from God.

# 1789

It is only God who deserves all praise. I praise Him for His giving me my sons Ishmael and Isaac during my old age. My Lord, certainly, hears all prayers.

# 1790

Lord, make me and my offspring steadfast in prayer and accept our worship.

# 1791

Lord, on the Day of Judgment, forgive me and my parents and all the believers."

# 1792

(Muhammad), do not think that God is unaware of what the unjust people do. He only gives them a respite until the day when the eyes will stare fixedly,

# 1793

when people will hurry in fright, their heads raised, their eyes unable to look around, and their hearts stunned due to the confusion (which will prevail on that Day).

# 1794

(Muhammad), warn the people of the day when torment will approach them and the unjust will say, "Lord, give us respite for a little time so that we may answer your call and follow the Messengers." (The answer to their prayer will be), "Did you not swear before that you would never perish?

# 1795

You lived in the dwellings of those who wronged themselves, even though it was made clear to you how We dealt with them. We also showed you examples."

# 1796

They devised evil plans which were so sinful that even the mountains could not endure them. All these were known to God.

# 1797

You must not even think that God will disregard His promise to His messengers. God is Majestic and Revengeful.

# 1798

On the day when the earth and the heavens will be replaced by another earth and heavens and everyone will be brought before the One Almighty God,

# 1799

you will see the guilty ones bound in chains,

# 1800

with garments of pitch and faces covered by fire.

# 1801

This is how God will recompense each soul for its deeds. God's reckoning is swift.

# 1802

This is an admonition for the people that they will be warned and know that He is the only God, and so that the people of understanding may take heed.

# 1803

Alif. Lam. Ra. These are the verses of the Book and the glorious Quran.

# 1804

How strongly the unbelievers will wish that they had been Muslims.

# 1805

(Muhammad), leave them alone to eat and enjoy themselves and let their desires deceive them; they will soon know (the Truth).

# 1806

We never destroyed any town without pre-ordaining the fate of its people.

# 1807

Every nation can only live for the time appointed for it.

# 1808

(The unbelievers have said), "You to whom the Quran has been revealed are insane.

# 1809

Why do you not bring down the angels if what you say is true".

# 1810

We do not send down angels except for a genuine purpose, at which time none will be given any further respite.

# 1811

We Ourselves have revealed the Quran and We are its Protectors.

# 1812

We sent Messengers to the ancient people who lived before you.

# 1813

No Messenger went to them whom they did not mock.

# 1814

This is how We cause the hearts of the guilty ones to behave.

# 1815

They do not believe in the Truth and they exactly follow the tradition of the ancient (unbelievers)

# 1816

Had We opened a door for them in the sky through which they could easily pass,

# 1817

they would have said, "Our eyes are bewildered and we have been affected by magic."

# 1818

We have made constellations in the sky and decorated them for the onlookers.

# 1819

We have protected them from every condemned devil,

# 1820

except for those who stealthily try to listen to the heavens, but who are chased away by a bright flame.

# 1821

We have spread out the earth, fixed mountains thereupon and caused everything to grow to its proper weight

# 1822

to provide you and those for whose sustenance you are not responsible, with the necessities of life.

# 1823

With Us is the source of everything and We do not send it down except in a known quantity.

# 1824

We send impregnating winds and send down water from the sky for you to drink and you have no (control over its) storage.

# 1825

It is We who give life and cause things to die and We are the sole Heirs.

# 1826

We know the people who lived before you and those who will come into existence after you.

# 1827

Your Lord will resurrect them all; He is All-wise and All-knowing.

# 1828

We have created the human being out of pure mud-moulded clay

# 1829

and the jinn before (the human being) of smokeless fire.

# 1830

When your Lord said to the angels, "I will create the human being out of pure mud-moulded clay.

# 1831

When it is properly shaped and I have blown My Spirit into it, you should then bow down in prostration".

# 1832

All the angels prostrated before Adam

# 1833

except Iblis who refused to join with the others in prostration.

# 1834

God asked Iblis, "What made you not join the others in prostration?"

# 1835

Iblis replied, "I did not want to prostrate before a human being whom You have created out of mud-moulded clay".

# 1836

God told him, "Get out of the garden; you are rejected

# 1837

and will be subjected to condemnation until the Day of Judgment."

# 1838

Iblis prayed, "Lord, grant me respite until the Day of Judgment".

# 1839

The Lord said, "Your request is granted

# 1840

for an appointed time."

# 1841

Iblis said, "Lord, because you have caused me to go astray, I shall make earthly things attractive to (people) and mislead all of them

# 1842

except Your sincere servants".

# 1843

God said, "The path which leads to Me is a straight

# 1844

and you have no authority over My servants except the erring ones who follow you.

# 1845

Hell is the promised place for them all.

# 1846

It has seven gates and each gate is assigned for a certain group of people.

# 1847

The pious will live in gardens with streams

# 1848

and they will be told to enter there in peace and safety.

# 1849

We shall remove all hatred from their breasts and make them as brothers reclining on thrones facing one another.

# 1850

No fatigue will touch them nor will they be expelled therefrom."

# 1851

(Muhammad), tell My servants that I am All-forgiving and All-merciful

# 1852

and that My punishment is a painful one.

# 1853

Tell them about the guests of Abraham

# 1854

who came to him saying, "Peace be with you." Abraham said, "We are afraid of you".

# 1855

They replied, "Do not be afraid. We have brought you the glad news of (the birth) of a learned son".

# 1856

Abraham asked, "Are you giving me the glad news of a son in my old age? What reason can you give for such glad news?"

# 1857

They said, "We have given you the glad news for a true reason so do not despair".

# 1858

He said, "No one despairs of the mercy of his Lord except those who are in error.

# 1859

Messengers, what is your task?"

# 1860

They said, "We are sent to a sinful people.

# 1861

Only the family of Lot will all be saved,

# 1862

except his wife who is doomed to be left behind."

# 1863

When the Messengers came to the family of Lot,

# 1864

he said, "You seem to be strangers".

# 1865

They replied, "We have come to you about the matter which the (unbelievers) have rejected.

# 1866

We have come to you for a genuine purpose and We are true in what we say.

# 1867

Leave the town with your family sometime during the night. Walk behind them and let no one turn around. Proceed as you are commanded."

# 1868

We informed him that the unbelievers would be utterly destroyed.

# 1869

The people of the town rejoicingly

# 1870

rushed towards the house of Lot. Lot said to them, "These are my guests. Do not disgrace me.

# 1871

Have fear of God and do not humiliate me".

# 1872

They replied, "Did we not forbid you to bring anyone to your house?"

# 1873

Lot said, "These are my daughters if you want them."

# 1874

By your life! In their drunkenness they were truly blind.

# 1875

An explosion struck them at sunrise.

# 1876

We turned the town upside-down and showered on them lumps of baked clay.

# 1877

In this there is evidence (of the Truth) for the prudent ones.

# 1878

That town lies on a road which still exists.

# 1879

In this there is evidence (of the Truth) for the believers.

# 1880

Since the People of the Forest were unjust,

# 1881

We afflicted them with punishment. Both people had clear (divine) authority among them.

# 1882

People of Hijr rejected the Messengers.

# 1883

We showed them miracles but they ignored them.

# 1884

They would carve secure houses out of the mountains.

# 1885

An explosion struck them in the morning.

# 1886

Out of what they had gained, nothing proved to be of any benefit to them.

# 1887

We have created the heavens and the earth and all that is between them, for a genuine purpose. The Day of Judgment will certainly approach, so (Muhammad) forgive them graciously.

# 1888

Your Lord is certainly the All-knowing Creator.

# 1889

(Muhammad), We have given you the seven most repeated (verses) and the great Quran.

# 1890

Do not yearn for other people's property and wives and do not grieve (that they do not believe). Be kind to the believers.

# 1891

Say, "Indeed, I am simply one who warns."

# 1892

(We have given you the Quran) as We had given (the Bible) to those who divided themselves into groups

# 1893

and also divided the Quran believing in some parts and rejecting others.

# 1894

By the Lord, We will hold them all responsible

# 1895

for what they have done

# 1896

Preach what you have been commanded to and stay away from the pagans.

# 1897

We shall help you against those who mock you

# 1898

and believe other things to be equal to God. They will soon know the truth.

# 1899

We certainly know that you feel sad about what they say against you.

# 1900

Glorify and praise your Lord and be with those who prostrate themselves before God.

# 1901

Worship your Lord until you achieve the ultimate certainty.

# 1902

God's help will certainly support (the believers), so pagans do not (seek) to hasten it. God is too Glorious and Exalted to be considered equal to idols.

# 1903

He sends the angels with the Spirit to carry His orders to whichever of His servants He wants so that they would warn people that He is the only God and that people must have fear of Him.

# 1904

He has created the heavens and the earth for a genuine purpose. He is too Exalted to be considered equal to anything else.

# 1905

He created the human being from a drop of fluid but the human being openly disputes His Word.

# 1906

He created cattle which provide you with clothes, food, and other benefits.

# 1907

How beautiful you find them when you bring them home and when you drive them out to graze.

# 1908

They carry your heavy loads to lands which you would not have been able to reach without great difficulty. Your Lord is certainly Compassionate and All-Merciful.

# 1909

He created horses, mules, and donkeys for you to ride and as a means of beauty. He has also created things that you do not know.

# 1910

Some paths lead away from God but one must follow the path that leads to God. Had God wanted, He could have guided (all to the right path).

# 1911

It is God who sends down water from the sky for you to drink and produces plants as pasture for your cattle.

# 1912

(With this water) He causes corn, olives, palm-trees, vines, and all kinds of fruits to grow. In this there is evidence (of the existence of God) for the people of understanding.

# 1913

God has made the day and the night, the sun and the moon, and all the stars subservient to you by His command. In this there is evidence of the truth for people of understanding.

# 1914

All that He has created for you on the earth are of different colors. In this there is evidence of the Truth for the people who take heed.

# 1915

It is God who put the oceans at your disposal so that you could find therein fresh fish for food and ornaments with which to deck yourselves with. You will find ships that sail for you so that you may travel in search of the bounties of God and give Him thanks.

# 1916

God has fixed the mountains on earth lest you should be hurled away when it quakes. Therein He has also made rivers and roads so that you will find your way.

# 1917

The stars and other signs also help people to find their way.

# 1918

Is the One who can create equal to the one who cannot create anything? Why, then, will you not consider?

# 1919

Even if you wanted to count up all of God's blessings, you would not be able to. God is All-forgiving and All-merciful.

# 1920

God knows all that you conceal or reveal.

# 1921

Whatever (idols) they worship besides God can create nothing for they are themselves created.

# 1922

They are not living but are dead. They can not know when they will be raised.

# 1923

Your Lord is only One. The hearts of those who do not believe in the life hereafter dislike (the truth). They are puffed up with pride.

# 1924

God certainly knows whatever you conceal or reveal. He does not love the proud ones.

# 1925

When they are asked, "What has your Lord revealed to you?" they say, "Only ancient legends".

# 1926

Besides their own burdens, on the Day of Judgment, they will have to carry on the burdens of those whom they have misled without knowledge. How evil that burden will be!

# 1927

Those who went before them had also devised evil plans. God demolished their houses, destroying their very foundations. Their ceilings toppled on their heads and torment struck them from a direction which they had never expected.

# 1928

God will humiliate them on the Day of Judgment and ask them, "Where are the idols which you had considered equal to Me and which were the cause of hostility and animosity among you?" The people who were given knowledge will say, "It is the unbelievers who face disgrace and trouble on this day."

# 1929

The unjust, who will be seized by the angels, will submit themselves, obey, and say, "We were not evil-doers." But God certainly knows what they had been doing.

# 1930

They will be commanded to enter hell to live therein forever. How terrible will be the place of the proud ones!

# 1931

The pious ones will be asked, "What did your Lord reveal to you?" They will reply, "He revealed only good." The share of the righteous ones is virtue in this world and greater virtue in the life to come. How blessed will be the dwelling of the pious ones!

# 1932

They will be admitted into the gardens of Eden wherein steams flow and they will have therein whatever they want. This is how God will reward the pious ones.

# 1933

They will be received by the angels of mercy with the greeting, "Peace be with you. Enter Paradise as a reward for your good deeds."

# 1934

Are they (the disbelievers) waiting for the angels and the decree of your Lord to be fulfilled before they believe? The people who lived before them had also done the same thing. God did not do injustice to them, but they wronged themselves.

# 1935

The evil consequences of their deeds afflicted them and they were surrounded by what they had mocked.

# 1936

The pagans had said, "Had God wanted we would not have worshipped anything other than Him, nor would our fathers. We would not have forbidden anything without (a command from) Him." The same thing was said by the people who lived before them. Are the Messengers expected to do more than just preach?

# 1937

To every nation We sent a Messenger who told its people, "Worship God and stay away from satan." Some of them were guided by God and others were doomed to go astray. Travel through the land and see how terrible was the end for those who rejected the truth!

# 1938

(Muhammad), even though you have a strong desire to guide them, be sure that God will not guide those who have gone astray and no one will be able to help them.

# 1939

They strongly swear by God that God will not bring the dead to life. God's promise (of the Resurrection) will certainly come true but many people do not know.

# 1940

(Through the resurrection) God wants to make a clear distinction between right and wrong and make the unbelievers know that they were liars.

# 1941

When We want to bring something into existence, Our command is, "Exist," and it comes into existence.

# 1942

God settles those who leave their homes for His cause after having suffered injustice, in a prosperous dwelling in this life and greater rewards will be theirs in the life to come. Would that they knew this.

# 1943

(It is they) who have exercised patience and trust in their Lord.

# 1944

The Messengers whom We sent before you were mere mortals to whom We had sent with miracles and revelations. Ask those who know about the heavenly Books if you do not know about this.

# 1945

We have revealed the Quran to you so that you could tell the people what has been revealed to them and so that perhaps they will think.

# 1946

Can they who have devised evil plans expect to be safe from the command of God to the earth to swallow them up, or from a torment which might strike them from an unexpected direction?

# 1947

Are they confident that God will not seize them while they are on a journey? They will not be able to escape from God.

# 1948

Are they confident that God will not slowly destroy them? Your Lord is Compassionate and All-merciful.

# 1949

Can they not see that the shadows of whatever God has created turn to the right and to the left in prostration and submission to Him?

# 1950

Whatever is in the heavens and the earth, the cattle and the angels prostrate themselves before God without pride.

# 1951

They (angels) have fear of their Lord above them and fulfill His commands.

# 1952

God says, "Do not worship two gods. There is only One God. Have fear of Me".

# 1953

To Him belongs all that is in the heavens and the earth. God's retribution is severe. Should you then have fear of anyone other than God?

# 1954

Whatever bounties you have are from God. When hardship befalls you, you begin to cry out to Him.

# 1955

When He saves you from the hardship, some of you start to believe in idols.

# 1956

In the end you will reject Our bounties. Enjoy yourselves; you will soon know (the consequences of your deeds).

# 1957

They give to unknown images a share out of the sustenance that We gave them. By God, you will be questioned about that which you have falsely invented.

# 1958

They ascribe daughters to God, God is too Exalted to have daughters, but they can have whatever they want.

# 1959

When the glad news of the birth of their daughter is brought to them, their faces turn gloomy and black with anger.

# 1960

They try to hide themselves from the people because of the disgrace of such news. Will they keep their new born despite the disgrace or bury it alive? How sinful is their Judgment!

# 1961

Those who do not believe in the life to come are evil examples. To God belongs all the exalted attributes; He is the Majestic and the All-wise.

# 1962

Was God to seize people immediately for their injustice, no living creature would be left on earth. He gives them respite for an appointed time. When their term is over, they will not be able to change the inevitable.

# 1963

They ascribe to God that which even they themselves do not like and their lying tongues say that their end will be virtuous. Their share will certainly be hell fire to which they are earnestly heading.

# 1964

By God, We sent (Messengers) to nations who lived before you. Satan made their deeds seem attractive to them and, on the Day of Judgment, satan will be their guardian. For them there will be a painful punishment.

# 1965

We have sent you the Book for no other reason than to settle their differences and to be a guide and mercy for those who believe.

# 1966

God has sent down water from the sky and has brought the dead earth to life. In this there is evidence (of the truth) for those who listen (carefully).

# 1967

There is a lesson for you to learn concerning cattle. We provide pleasant milk for you to drink within the delicate system of their veins and arteries.

# 1968

The fruit of palm trees and vines which provide you with sugar and delicious food also provide a lesson and evidence (of the Truth) for the people of understanding.

# 1969

Your Lord inspired the bees, "Make hives in the mountains, in the trees and in the trellises,

# 1970

then eat of every fruit and follow the path of your Lord submissively." From out of their bellies comes a drink of different color in which there is a cure for the human being. In this there is evidence (of the truth) for the people of understanding.

# 1971

God has created you and He causes you to die. Some of you will grow to an extremely old age and lose your memory. God is All-knowing and Almighty.

# 1972

God has made some of you richer than others. The rich ones do not have to give away their property to their slaves to make them equally rich. Do they reject the bounties of God?

# 1973

God has created spouses for you from your own selves. He has created your sons and grandsons from your spouses and has given you pure things for your sustenance. Do they then believe in falsehood and reject the bounties of God?

# 1974

Do they worship things other than God which neither provide them with any sustenance from the heavens and the earth nor have the ability to do so?

# 1975

Do not consider anything equal to God. God knows that which you do not know.

# 1976

God tells a parable about a helpless servant and one to whom He has given honorable provisions and who has spent for the cause of God privately and in public. Can these two people be considered equal? It is only God who deserves all praise, but most people do not know.

# 1977

God tells a parable about two men. One of them is dumb and useless and a burden on his friend. Wherever he goes, he returns with nothing. Can he be considered equal to the one who maintains justice and follows the right path?

# 1978

To God belongs all the secrets of the heavens and the earth. It only takes God a twinkling of an eye or even less to make it the Day of Judgment. God has power over all things.

# 1979

When God brought you out of your mothers wombs, you knew nothing. He gave you ears, eyes, and hearts so that perhaps you would give Him thanks.

# 1980

Have you not considered the free movements of the birds high in the sky above? What keeps them aloft except God? In this there is evidence (of the truth) for the believing people.

# 1981

God has made your house the place for you to rest. He has also made homes for you out of the skins of cattle which are easy to carry along on a journey or at a camp. He has made wool, fur and the hair of cattle a temporary means of enjoyment for you.

# 1982

God has provided shade for you out of what He has created and places of retreat out of mountains. He has given you garments to protect you from the heat and cover your private parts. This is how He perfects His bounties to you so that perhaps you would submit to His will.

# 1983

(Muhammad), if they turn away, your only duty is to clearly preach to them.

# 1984

They recognize the bounties of God but they refuse them and most of them are unbelievers.

# 1985

On the day when We will call a witness from every nation, the disbelievers will not be given permission for anything, nor will they be allowed to seek solicitation.

# 1986

There will be no relief for them when the torment approaches the unjust nor will they be given any respite.

# 1987

When the idolators see their idols, they will say, "Lord, these are the idols whom we worshipped instead of you." But the idols will say, "They are liars."

# 1988

(On the Day of Judgment) the disbelievers will submit themselves to God and whatever they had falsely invented will disappear.

# 1989

The disbelievers who had created obstacles in the way leading to God will face manifold torments as a result of their evil deeds.

# 1990

On the day when We call a witness against every nation from their own people, We will call you, (Muhammad), as a witness against them all. We have sent you the Book which clarifies all matters. It is a guide, a mercy, and glad news to the Muslims.

# 1991

God commands (people) to maintain justice, kindness, and proper relations with their relatives. He forbids them to commit indecency, sin, and rebellion. God gives you advice so that perhaps you will take heed.

# 1992

(He commands people) to keep their established covenants with God, not to disregard their firm oaths; they have already appointed God as their Guarantor. God certainly knows what you do.

# 1993

Do not be like the lady behind the spinning wheel who has broken the yarn by pulling it with unnecessary force. You must not consider your oaths as means of deceit to benefit one party and incur loss upon the other. God tests your faith by your oaths. He will make clear to you who was right and who was wrong on the Day of Judgment.

# 1994

Had God wanted, He would have made you one single nation but He guides or causes to go astray whomever He wants. You will certainly be questioned about what you have done.

# 1995

Do not consider your oaths as a means of deceit lest you damage the firmness of your faith, suffer from evil by creating obstacles in the way that leads to God, and incur a great torment upon yourselves.

# 1996

Do not sell your covenant with God for a small price. The reward which you will receive from God is better for you, if only you knew it.

# 1997

Whatever you possess is transient and whatever is with God is everlasting. We will recompense those who exercise patience with their due reward and even more.

# 1998

All righteously believing male or female will be granted a blessed happy life and will receive their due reward and more.

# 1999

(Muhammad), when you recite the Quran, seek refuge in God from the mischief of satan.

# 2000

Satan has certainly no authority over the believers who have trust in their Lord.

# 2001

The only authority which he has is over his friends and those who consider things equal to God.

# 2002

When God replaces one revelation with another, He knows best what to reveal. But they say, "(Muhammad), you have falsely invented it." Most people are ignorant.

# 2003

(Muhammad), say, "The Holy Spirit has brought the Quran from your Lord to you in all truth to strengthen the faith of the believers and to be a guide and glad news for the Muslims".

# 2004

We know that they say a mere mortal has taught it (the Quran) to him (Muhammad). The language of the person whom they think has taught it to him is not Arabic. This (the Quran) is in illustrious Arabic.

# 2005

God will not guide those who do not believe in His miracles. They will suffer a painful punishment.

# 2006

Those who do not believe in the miracles of God invent lies and they are liars.

# 2007

No one verbally denounces his faith in God - unless he is forced - but his heart is confident about his faith. But those whose breasts have become open to disbelief will be subject to the wrath of God and will suffer a great torment.

# 2008

This is because they have given preference to this life over the life to come and God does not guide disbelieving people.

# 2009

God has sealed their hearts, ears and eyes and they are not aware of it.

# 2010

On the Day of Judgment they will certainly be lost.

# 2011

Those who left their homes for the cause of God after they had been persecuted, strove hard for His cause and exercised patience should know (even though they had verbally renounced their faith) that your Lord is All-forgiving and All-merciful.

# 2012

On the Day of Judgment every soul shall try to defend itself and every soul will be justly recompensed.

# 2013

God tells a parable about a secure and peaceful town surrounded by abundant sustenance. Its inhabitants rejected the bounties of God and He caused them to suffer hunger and fear as a result of their deeds.

# 2014

A Messenger from their own people came to them and they called him a liar. Torment struck them because of their injustice.

# 2015

(People), consume the pure and lawful sustenance which God has given to you and thank God for his bounty if you are His true worshippers.

# 2016

The only things which are made unlawful for you are the flesh of dead animals, blood, pork and that which is not consecrated with the Name of God. But in an emergency, without the intention of transgression and rebellion, (it is not an offense for one to consume such things). God is certainly All-forgiving and All-merciful.

# 2017

(Unbelievers), do not follow whatever your lying tongues may tell you is lawful or unlawful to invent lies against God. Those who invent lies against God will have no happiness.

# 2018

(Such an invention) will bring only a little enjoyment but will be followed by painful torment.

# 2019

We had made unlawful for the Jews all that we told you before. We did not do any wrong to them but they wronged themselves.

# 2020

To those who commit sins in their ignorance then repent and reform, your Lord is certainly All-forgiving and All-merciful.

# 2021

Abraham was, certainly, an obedient and upright person. He was not a pagan.

# 2022

He was thankful to God for His bounties. God chose him and guided him to the right path.

# 2023

We granted him virtue in this life and he shall be among the righteous ones in the life to come.

# 2024

We sent you, (Muhammad), a revelation that you should follow the tradition of Abraham, the upright one, who was not a pagan.

# 2025

(The observance) of the Sabbath was only sanctioned for those who disputed it. Your Lord will certainly issue His decree about their dispute on the Day of Judgment.

# 2026

Call (the pagans) to the path of your Lord through wisdom and good advice and argue with them in the best manner. God knows well about those who stray from His path and those who seek guidance.

# 2027

If you want retaliation, let it be equal to that which you faced. But if you exercise patience it will be better for you.

# 2028

Exercise patience and let it be only for the cause of God. Do not be grieved about them nor disappointed at their evil plans.

# 2029

God is certainly with the pious and the righteous ones.

# 2030

God is the Exalted One who took His servant one night for a visit from the Sacred Mosque (in Mecca) to the Aqsa Mosque (in Jerusalem). God has blessed the surroundings of the Aqsa Mosque. He took His servant on this visit to show him (miraculous) evidence of His (existence). It is He who is All-hearing and All-aware.

# 2031

To Moses We gave the Book and made it a guide for the children of Israel, so that they would not have any one as their guardian other than Me

# 2032

(We made it a guide for) the offspring of those whom We carried in the Ark with Noah, a thankful servant (of God).

# 2033

We made it known to the Israelites through the Torah that they would twice commit evil in the land with great transgression and rebellion.

# 2034

(We told them) during your first uprising of evil We shall send to you

# 2035

Our Mighty servants, who will chase you from house to house. This is a decree already ordained. We, then, gave you a chance to defeat your enemies with the help of increasing your wealth and offspring.

# 2036

(We told you), "If you do good, it will be for your own benefit, but if you do bad, it will be against your souls. When the prophecy of your second transgression will come to pass, sadness will cover your faces. They (your enemies) will enter the mosque as they did the first time to bring about utter destruction.

# 2037

Perhaps your Lord will have mercy on you. If you return to disobedience We will also punish you again. We have made hell a prison for the disbelievers."

# 2038

This Quran shows the way to that which is the most upright and gives to the righteous believers the glad news of a great reward.

# 2039

(It also declares) that for the disbelievers We have prepared a painful torment in the life to come.

# 2040

People pray as earnestly to gain evil as one should to gain virtue. But people are hasty.

# 2041

We have made the day and night each as evidence (of Our existence). The night is invisible and the day is visible so that you may seek favors from your Lord and determine the number of years and mark the passing of time. For everything We have given a detailed explanation.

# 2042

We have made every person's actions cling to his neck. On the Day of Judgment, We will bring forth the record of his actions in the form of a wide open book.

# 2043

We will tell him, "Read it and judge for yourself."

# 2044

One who follows guidance does so for himself and one who goes astray does so against his soul. No one will suffer for the sins of others. We have never punished anyone without sending them Our Messenger first.

# 2045

When We decide to destroy a town We warn the rich ones therein who commit evil. Thus it becomes deserving to destruction and We destroy its very foundations.

# 2046

We have destroyed many generations after the time of Noah. Your Lord is All knowing and Well Aware of the sins of His servants.

# 2047

Whoever desires (only) the enjoyment of this life will receive it if We want it to be so. Then We will make Hell his reward wherein he will suffer, despised and driven away from Our mercy.

# 2048

The effort of one who faithfully strives hard for the (happiness) of the life to come will be appreciated (by God).

# 2049

Each group will receive its share of your Lord's generosity. Your Lord's generosity is not limited.

# 2050

Consider how We have given preference to some people above others, yet the life to come has more honor and respect.

# 2051

Do not consider anything equal to God lest you will become despised and neglected.

# 2052

Your Lord has ordained that you must not worship anything other than Him and that you must be kind to your parents. If either or both of your parents should become advanced in age, do not express to them words which show your slightest disappointment. Never yell at them but always speak to them with kindness.

# 2053

Be humble and merciful towards them and say, "Lord, have mercy upon them as they cherished me in my childhood."

# 2054

Your Lord knows what is in your souls. If you would be righteous, know that He is All-forgiving to those who turn to Him in repentance.

# 2055

Give the relatives, the destitute and those who when on a journey have become needy, their dues.

# 2056

Do not be a wasteful spender. Squanderers are the brothers of satan. Satan was faithless to his Lord.

# 2057

If you are not able to assist them, at least speak to them in a kind manner.

# 2058

Do not be stingy nor over generous lest you become empty handed and bankrupt.

# 2059

Your Lord increases and determines the sustenance of whomever He wants. He is Well Aware and watches over His servants.

# 2060

Do not kill your children for fear of poverty. We will give sustenance to all of you. To kill them is certainly a great sin.

# 2061

Do not even approach adultery. It is indecent and an evil act.

# 2062

Do not kill a respectable soul without a just cause. If anyone is wrongfully killed, we have given the heirs of that person the right (to demand satisfaction or to forgive). He must not exceed the law in having vengeance; his victim shall also be assisted (by law).

# 2063

Do not get close to the property of the orphans (unless it is for a good reason) until they are mature and strong. Keep your promise; you will be questioned about it.

# 2064

While weighing, use proper measurements in the exchange of your property. This is fair and will be better in the end.

# 2065

Do not follow what you do not know; the ears, eyes, and hearts will all be held responsible for their deeds.

# 2066

Do not walk proudly on the earth; your feet cannot tear apart the earth nor are you as tall as the mountains.

# 2067

All such things are sins and detestable in the sight of your Lord.

# 2068

(Muhammad), these are words of wisdom which your Lord has revealed to you. Do not consider anything equal to God lest you be thrown into hell, despised, and driven away from God's mercy.

# 2069

(Pagans) has your Lord given you preference over Himself by granting you sons and taking the angels as His own daughters? What you say is a monstrous utterance.

# 2070

We have given you various facts (about the Truth in this Quran) so that they (unbelievers) would take heed, but this has only increased their aversion (to the truth).

# 2071

(Muhammad), ask them, "Had there been many other gods besides Him, as they say, they should have found a way to the Lord of the Throne

# 2072

(to challenge Him). God is too Glorious and Exalted to be considered as they believe Him to be. He is the most High and Great.

# 2073

The seven heavens, the earth, and whatever is between them all glorify Him. There is nothing that does not glorify Him and always praise him, but you do not understand their praise and glorification. He is All-forbearing and All-forgiving.

# 2074

When you recite the Quran We place a curtain as a barrier between you and those who do not believe in the life to come.

# 2075

We put a veil over their hearts so that they cannot understand it. We deafen their ears. When you mention your Lord in this Quran as One (Supreme Being), they run away.

# 2076

We know what they want to hear when they listen to you. They whisper to each other and say, "You are only following a bewitched person".

# 2077

Consider what they have called you. They have certainly gone astray and cannot find the right path.

# 2078

The pagans say, "When we become mere bones and dust, shall we then be brought back to life again?"

# 2079

(Muhammad), say "Yes, even if you become rocks, iron,

# 2080

or anything that you think is harder to be brought to life." They will soon ask, "Who will bring us back to life?" Say,"The One who created you in the first place." They will shake their heads and say, "When will He bring us back to life?" Say, "Perhaps very soon.

# 2081

On the day when He will call you, you will answer Him with praise and think that you have tarried for only a little while."

# 2082

(Muhammad), tell My servants to say what is best. Satan sows dissension among them; he is the sworn enemy of human beings.

# 2083

Your Lord knows better than you (people). He will have mercy on you or will punish you as He wills. We have not sent you to watch over them. Your Lord knows best about those in the heavens and the earth.

# 2084

We have given preference to some Prophets over others and We gave the psalms to David.

# 2085

(Muhammad), tell them, "Seek help from those whom you consider equal to God. They are not able to remove or change your hardships".

# 2086

Those whom they worship seek to find intercessors for themselves with God. (They try to find out which of the intercessors) are closer to God. They have hope for His mercy and fear of His punishment; the punishment of your Lord is awesome.

# 2087

The decree that all the towns were to be destroyed or afflicted with severe punishment was already written in the Book before the Day of Judgment.

# 2088

We did not abstain from sending miracles to any of Our Messengers. These miracles were called lies by the people who lived in ancient times. To the people of Thamud, We sent the she-camel as a visible miracle and they did injustice to it. We only send miracles as warnings.

# 2089

(Muhammad), We told you that your Lord has encompassed all mankind. We made the vision which We showed you and the condemned tree, mentioned in the Quran, as a trial for the human being. Even though We warn them, it only increases their rebellion.

# 2090

When We told the angels to prostrate before Adam, they all obeyed, except Iblis who said, "Should I prostrate before one whom You have created out of clay?"

# 2091

He continued, "Remember, this one whom you have honored more than me I shall bring him and most of his offspring under my sway if you will give me respite until the Day of Judgment."

# 2092

God said, "Go away. All those who follow you will have hell as ample recompense for their deeds.

# 2093

Draw anyone of them you can into sin by your voice and by your cavalry and infantry, share their property and children with them and make promises to them. Your promises are all lies.

# 2094

You have no authority over My servants. Your Lord is a Sufficient Protector."

# 2095

Your Lord who causes the ships to sail on the sea so that you may seek His bounty is certainly All-merciful to you.

# 2096

If you are afflicted by hardships in the middle of the sea, it would be an error to call anyone other than Him for help. When God saves you from such difficulties, you turn away from Him. The human being has always been ungrateful.

# 2097

Do you feel secure that We will not cause a part of the land to sink or engulf you with sand storms when you would find no one to protect you?

# 2098

Do you feel secure that We will not drive you back to the sea, send a fierce gale to you, and cause you to drown because of your disbelief when you would not be able to find anyone who would intercede for you with Us?

# 2099

We have honored the children of Adam, carried them on the land and the sea, given them pure sustenance and exalted them above most of My creatures.

# 2100

On the day when We call every nation with their leaders, those whose record of deeds are given to their right hands will read the book and the least wrong will not be done to them.

# 2101

Those who are blind in this life will also be blind in the life to come and in terrible error.

# 2102

(Such blind ones) try to confuse what We have revealed to you so that they may falsely ascribe to Us something other than the true revelation and thus establish friendship with you.

# 2103

Had We not strengthened your faith you might have relied on them some how.

# 2104

Had you done so, We would certainly have made you face double punishment in this life and after your death and you would have found none to help you.

# 2105

They try to annoy you so that they can expel you from the land. Had they been successful, no one would have been left behind except a few.

# 2106

This was Our tradition with Our Messengers who lived before you, and you will find no change in Our tradition.

# 2107

Say your prayer when the sun declines until the darkness of night and also at dawn. Dawn is certainly witnessed (by the angels of the night and day).

# 2108

Say your special (tahajjud) prayer during some part of the night as an additional (obligatory) prayer for you alone so that perhaps your Lord will raise you to a highly praiseworthy position.

# 2109

(Muhammad), say, "Lord, make me enter through a path that will lead to the Truth and come out of an exit that will take me to the Truth. Give me helpful authority.

# 2110

Say, 'Truth has come and falsehood has been banished; it is doomed to banishment.'"

# 2111

We reveal the Quran which is a cure and mercy for the believers but does nothing for the unjust except to lead them to perdition.

# 2112

When We do favors to the human being, he disregards it and turns away from it. When evil afflicts him, he becomes despairing.

# 2113

Say, "Everyone does as he wants. Your Lord knows best who has the right guidance."

# 2114

They ask you about the Spirit. Say, "The Spirit comes by the command of my Lord. You have been given very little knowledge.

# 2115

Had We wanted, We could have removed the Spirit through whom We sent you revelation. Then you would not have found anyone to intercede with Us for you

# 2116

except by the mercy of your Lord. He has certainly bestowed great favors on you.

# 2117

Say, "If all human beings and jinn were to come together to bring the equivalent of this Quran, they could not do so, even if they all were to help each other.

# 2118

We have mentioned in this Quran all kinds of examples for the human being, but most human beings turn away in disbelief.

# 2119

They have said, "We shall never believe you until you cause a spring to gush forth from the earth,

# 2120

or you (show) us that you have your own garden of palm trees and vines with flowing streams therein,

# 2121

or cause the sky to fall into pieces on us - as you believe you can - or bring God and the angels face to face with us,

# 2122

or (show us) that you have a well adorned house of your own, or climb into the sky. We shall never believe that you have climbed into the sky until you bring us a book that we can read." Say, "All glory belongs to my Lord. Am I more than a mortal Messenger?"

# 2123

What keeps people from belief that guidance has come to them, but they question, "Why has God sent a mortal Messenger?"

# 2124

(Muhammad), say, "Had the earth been inhabited by angels who would walk serenely therein, only then would We have sent to them angelic Messengers".

# 2125

Say, "God is a sufficient Witness between me and you. He certainly sees and knows all about His servants.

# 2126

Whomever God has guided has the proper guidance. You will never find any guardian besides God for the one whom He has caused to go astray. On the Day of Judgment, We will gather them lying on their faces, blind, dumb and deaf. Hell will be their dwelling. As hell fire abates, We will increase its blazing force.

# 2127

This will be the recompense for their disbelief of Our revelations and for their saying, "Shall we be brought to life again after becoming bones and dust?"

# 2128

Do they not realize that God, who has created the heavens and the earth, has the power to create their like? He has given them life for an appointed time of which there is no doubt. The unjust turn away in disbelief (from Our revelation).

# 2129

Say, "Had you owned the treasures of the Mercy of my Lord, you would have locked them up for fear of spending them. The human being has always been stingy.

# 2130

To Moses We gave nine illustrious miracles. Ask the Israelites; Moses came to them. The Pharaoh said to him,"Moses, I believe that you are bewitched".

# 2131

He replied, "Certainly you have come to know that these have been sent by the Lord of the heavens and the earth as lessons to people. Pharaoh, I believe that you are doomed to perdition.

# 2132

The Pharaoh wanted to expel the Israelites from the land so We drowned him and all who were with him.

# 2133

We told the Israelites after this to settle in the land until Our second promise will come true. We would then gather them all together (on the Day of Judgment).

# 2134

We sent it (the Quran) in all Truth and in all Truth it came. (Muhammad), We have sent you for no other reason than to be a bearer of glad news and a warner.

# 2135

We have divided the Quran into many segments so that you would read them to the people in gradual steps as We reveal them to you from time to time.

# 2136

Say, "It does not matter whether you believe in it or not, for when it is read to those who had received the knowledge (heavenly Books) that were sent before, they bow down and prostrate themselves before the Lord.

# 2137

They say, "Our Lord is too Glorious to disregard His promise".

# 2138

They bow down in prostration and weep and it makes them more humble (before the Lord).

# 2139

(Muhammad), tell them, "It is all the same whether you call Him God or the Beneficent. All the good names belong to Him." (Muhammad), do not be too loud or slow in your prayer. Choose a moderate way of praying.

# 2140

Say, "It is only God who deserves all praise. He has not begotten a son and has no partner in His Kingdom. He does not need any guardian to help Him in His need. Proclaim His greatness.

# 2141

Praise be to God. He has sent the Book to His servant and has made it a flawless guide (for human beings)

# 2142

so that he could warn them of His stern retribution, give the glad news of the best and everlasting reward to the righteously striving believers,

# 2143

wherein they shall remain forever,

# 2144

and admonish those who say that God has begotten a son.

# 2145

Neither they nor their fathers had any knowledge of such utterance (that God has begotten a son). Whatever they say about (this matter) is vicious blasphemy and plain lies.

# 2146

Perhaps you will destroy yourself out of grief because they disbelieve this Book.

# 2147

We have caused earthly things to seem attractive so that We can see who will excel in good deeds.

# 2148

Let it be known that We will turn all things on earth into dust.

# 2149

Do you not think that the story of the Companions of the Cave and the Inscription was one of Our marvelous miracles?

# 2150

When the youth sought refuge in the cave they prayed "Lord, grant us mercy and help us to get out of this trouble in a righteous way".

# 2151

We sealed their ears in the cave for a number of years.

# 2152

Then We roused them to find out which of the party had the correct account of the duration of their sleep in the cave.

# 2153

We tell you this story for a genuine purpose. They were young people who believed in their Lord and We gave them further guidance.

# 2154

We strengthened their hearts when they stood up against the idols and said, "Our Lord is the Lord of the heavens and the earth. We shall never worship anyone other than Him lest we commit blasphemy.

# 2155

Our people have considered other things equal to God. Why cannot they present clear proof in support of their claim. Who is more unjust than one who invents falsehood against God?"

# 2156

(They were told), "Now that you have abandoned them and what they worship instead of God, seek refuge in the cave. God will, certainly, grant you mercy and provide you with help to safely get out of this trouble."

# 2157

No sunlight could reach them during their sleep in the cave. One could see the rising sun decline to the right of their cave and the setting sun move its way to the left whilst they were sleeping in an opening of the cave. This is one of the miracles of God. Whomever God guides receives the right guidance and you will never find a guardian or guide for those whom He causes to go astray.

# 2158

One would think them (the youths) awake while, in fact, they were sleeping. We turned their bodies from right to left and their dog stretched its front legs on the ground. Had one looked them over, he would have run away from them in terror.

# 2159

We roused them from their sleep so that they would question each other about their stay in the cave. One of them said, "How long do you think we have stayed here?" They replied, "A day or part of a day." They added, " Your Lord knows better how long we have stayed here. Let us send one of us with this money to the city to get some pure food so that we might eat. He should be careful so that no one will know about us. If they were to recognize us,

# 2160

they would certainly stone us to death or force us to follow their religion. Then we shall never be able to have everlasting happiness."

# 2161

We caused their story to become public so that people would know that God's promise was true and that there is no doubt about the coming of the Day of Judgment. They started to argue with each other about the matter (Resurrection) and some of them said, "Let us establish a building at the youths' sleeping place (to hide them). Their Lord knew best their intentions about them. The majority prevailed in their suggestion of the establishment of a mosque in that place.

# 2162

(With regard to the number of the youths) some say, "There were three and the dog was the fourth one," Others say, "There were five and the dog was the sixth one." In reality, they are just feeling around in the dark. Still some of them say, "There were seven and the dog was the eighth one." (Muhammad), say, "My Lord has the best knowledge of their number. You know very little about it." Do not insist on arguing with them, but merely tell them the story as it has been revealed to you and do not ask anyone about them.

# 2163

Never say of something, "I shall do it tomorrow,"

# 2164

without adding, "if God wills." Recall your Lord if you forget to do something. Say, "I hope that my Lord will provide me better guidance."

# 2165

They, in fact, stayed in the cave for three hundred plus nine further years.

# 2166

(Muhammad), say, "God knows best how long they stayed there; to Him belongs the unseen of both the heavens and the earth. How clear is His sight and how keen His hearing! No one other than Him is their guardian and no one shares His Judgment.

# 2167

Read whatever is revealed to you from the Book of your Lord. No one can change His words and you can never find any refuge other than Him.

# 2168

Be patient with those who worship their Lord in the mornings and evenings to seek His pleasure. Do not overlook them to seek the worldly pleasures. Do not obey those whom We have caused to neglect Us and instead follow their own desires beyond all limits.

# 2169

Say," Truth comes from your Lord. Let people have faith or disbelieve as they chose." For the unjust We have prepared a fire which will engulf them with its (flames). Whenever they cry for help they will be answered with water as hot as molted brass which will scald their faces. How terrible is such a drink and such a resting place!

# 2170

The righteously striving believers should know that We do not neglect the reward of those who do good deeds.

# 2171

They will be admitted to the gardens of Eden wherein streams flow. They will rest on soft couches, decked with bracelets of gold and clothed in green silk garments and shining brocade. How blissful is such a reward and resting place!

# 2172

(Muhammad), tell them the parable of the two men. To one of them We had given two gardens of vines surrounded by the palm trees with a piece of farm land between them

# 2173

and a stream flowing through the middle of the gardens.

# 2174

Both gardens would yield fruits to their fullest capacity. Whatever was produced belonged to him. To his friend he exclaimed, "I have more wealth and greater man-power than you."

# 2175

He unjustly entered his garden and said, "I do not think this (property) will ever perish

# 2176

nor do I think that there will be a Day of Judgment. Even if I shall be brought before my Lord, I certainly deserve to have a better place than this."

# 2177

His friend said to him, "How can you disbelieve in the One who turned clay into sperm out of which He created you?

# 2178

I believe that He is God my Lord and I do not consider anything equal to Him."

# 2179

When entering your garden, you should have said, "This is what God willed; All Power belongs to Him. Even if you consider me inferior to yourself in wealth and offspring,

# 2180

perhaps my Lord will give me a garden better than yours and strike your garden with a thunderbolt from the sky to turn it into a barren ground,

# 2181

or cause the streams in your garden to disappear under the ground such that you will never be able to find them.

# 2182

(Sure enough the rich person's) fruits were all destroyed and he began to wring his hands in grief for all that he had invested in his garden. He found his garden tumbled to its trellises and said, "Would that I had not considered anything equal to my Lord".

# 2183

He had no one besides God to help him, nor could he himself achieve any success.

# 2184

In such helplessness, the human being realizes that it is God who is the true Guardian and His rewards and recompense are the best.

# 2185

(Muhammad), tell them, "The worldly life resembles the (seasonal) plants that blossom by the help of the water which God sends from the sky. After a short time all of them fade away and the winds scatter them (and turns them into dust). God has power over all things.

# 2186

Children and property are the ornaments of the worldly life, but for deeds which continually produce virtue one can obtain better rewards from God and have greater hope in Him.

# 2187

On the day when We will cause the mountains to travel around and the earth to turn into a levelled plain, We will also bring all human beings together. No one will be left behind.

# 2188

They will all be lined up in the presence of your Lord who will tell them, "Despite your belief that there would never be a Day of Judgment, all of you are brought in Our presence just as though We had created you for the first time. You believed that our promise could never come true."

# 2189

When the record of every one's deeds is placed before him, you will see the criminals terrified from what the record contains. They will say, "Woe to us! What kind of record is this that has missed nothing small or great?" They will find whatever they have done right before their very eyes. Your Lord is not unjust to any one.

# 2190

When We told the angels to prostrate before Adam they all obeyed except Iblis. He was a jinn and he sinned against the command of his Lord. Why do you (people) obey him and his offspring instead of Me, even though they are your enemies? How terrible will be the recompense that the wrong doers will receive!

# 2191

I did not call (the unjust) to witness the creation of the heavens and earth nor to witness their own creation nor did I want to be helped by those who lead people astray.

# 2192

On the day when God asks the idolators to seek help from their idols, they will call their idols for help. But the idols will not answer them; We shall separate the two parties from each other by a destructive gulf.

# 2193

When the criminals see hell fire, they will have no doubt about falling (headlong) therein, nor of finding anyone to save them.

# 2194

We have given various examples in this Quran for people to learn a lesson, but the human being is the most contentious creature.

# 2195

What prevents people from having faith when guidance comes to them or from asking for forgiveness from their Lord before they face the kind of torment that the ancient people experienced or a new form of torment.

# 2196

The only reason for Our sending the Messengers is to give the human being the glad news of Our mercy and to warn him about Our wrath. The disbelievers argue by false means to refute the Truth. They mock My miracles and warnings.

# 2197

Who are more unjust than those who are reminded of the revelations of their Lord but have disregarded them and have forgotten their deeds? We have veiled their hearts and sealed their ears so that they cannot understand. Even if you call them to the right path, they will never accept guidance.

# 2198

Your Lord is All-forgiving and All-merciful. Had He wanted to punish them for their sins, He would have been prompt to torment them. For their punishment there is an appointed time, after which there will be no way for them to escape.

# 2199

We only destroyed the inhabitants of certain towns when they had committed injustice and did not repent before Our deadline.

# 2200

(Consider) when Moses said to his young companion, "I shall continue travelling until I reach the junction of the two seas or have travelled for many years".

# 2201

When they reached the junction of the two seas they found out that they had forgotten all about the fish (which they had carried for food). The fish found its way into the sea.

# 2202

Moses asked his young companion when they crossed this point, "Bring us our food; the journey has made us tired."

# 2203

His companion replied, "Do you remember the rock on which we took rest? Satan made me forget to mention to you the story of the fish and how it miraculously made its way into the sea.

# 2204

Moses said, "That is exactly what we are seeking. They followed their own foot prints back (to the rock)."

# 2205

There they met one of Our servants who had received blessings and knowledge from Us.

# 2206

Moses asked him, "Can I follow you so that you would teach me the guidance that you have received?"

# 2207

He replied, "You will not be able to have patience with me.

# 2208

"How can you remain patient with that which you do not fully understand?"

# 2209

Moses said, "If God wishes, you will find me patient and I shall not disobey any of your orders."

# 2210

He said to Moses, "If you will follow me, do not ask me about anything until I tell you the story about it."

# 2211

They started their journey and some time latter they embarked in a boat in which he made a hole. Moses asked him, "Did you make the hole to drown the people on board? This is certainly very strange".

# 2212

He said, "Did I not tell you that you would not be able to remain patient with me?"

# 2213

Moses said, "Please, forgive my forgetfulness. Do not oblige me with what is difficult for me to endure."

# 2214

They continued on their journey until they met a young boy whom he killed. Moses said, "How could you murder an innocent soul? This is certainly a horrible act".

# 2215

He responded, "Did I not tell you that you will not be able to remain patient with me?"

# 2216

Moses said, "If I ask you such questions again, abandon me; you will have enough reason to do so."

# 2217

They continued on their journey again until they reached a town. They asked the people there for food, but no one accepted them as their guests. They found there a wall of a house which was on the verge of tumbling to the ground. The companion of Moses repaired that wall. Moses said, "You should have received some money for your labor."

# 2218

He replied, "This is where we should depart from one another. I shall give an explanation to you for all that I have done for which you could not remain patient.

# 2219

"The boat belonged to some destitute people who were using it as a means of their living in the sea. The king had imposed a certain amount of tax on every undamaged boat. I damaged it so that they would not have to pay the tax.

# 2220

"The young boy had very faithful parents. We were afraid that out of love for him they would lose their faith in God and commit rebellion

# 2221

so We decided that their Lord should replace him by a better and more virtuous son.

# 2222

"The tumbling wall belonged to two orphans in the town whose father was a righteous person. Underneath the wall there was a treasure that belonged to them. Your Lord wanted the orphans to find the treasure through the mercy of your Lord when they mature. I did not repair the wall out of my own desire. These were the explanations of my deeds about which you could not remain patient."

# 2223

(Muhammad), they will ask you about Dhu 'l-Qarnayn. Say, "I shall tell you something about him".

# 2224

We had given him great power in the land and all kinds of resources.

# 2225

With these he traveled

# 2226

to the West where he found the sun setting into a warm source (spring) of water and a people living near by. We asked him, "Dhu 'l-Qarnayn, you may punish them or treat them with kindness?"

# 2227

He replied, "I shall punish the unjust ones among them and then they will return to their Lord, who will punish them more sternly".

# 2228

As for those who believe and do good, they will receive virtuous rewards and We will tell them to do only what they can.

# 2229

He travelled again

# 2230

to the East where he found the sun rising upon a people whom We had exposed to its rays.

# 2231

This indeed was true. We knew all that he did there.

# 2232

He travelled

# 2233

after this to the middle of two mountains where he found a people who could hardly understand a single word.

# 2234

They said, "Dhu 'l-Qarnayn, Gog and Magog are ravaging this land. Would you establish a barrier between us and them if we pay you a certain tax?"

# 2235

He replied, "The power that my Lord has granted me is better (than your tax). Help me with your man-power and I shall construct a barrier between you and Gog and Magog.

# 2236

Bring me blocks of iron to fill up the passage between the two mountains." He told them to ply their bellows until the iron became hot as fire. Then he told them to pour on it molten brass."

# 2237

(Thus he constructed the barrier which) neither Gog nor Magog were able to climb nor were they able to dig a tunnel through the iron and brass barrier.

# 2238

Dhu l-Qarnayn said, "This barrier is a blessing from my Lord but when His promise comes to pass He will level it to the ground; His promise always comes true."

# 2239

On the day when the barrier is demolished, We will leave human beings in chaos. We will leave them like the waves of the sea striking against each other. Then the trumpet will be sounded and We will bring them all together.

# 2240

We will fully expose the view of hell on that Day to the disbelievers,

# 2241

whose eyes had been veiled against Our Quran and who were not able to hear (its recitation).

# 2242

Do the unbelievers think they can make My servants as their guardians instead of Me? We have prepared hell as a dwelling place for the disbelievers.

# 2243

(Muhammad), tell them, "Should I tell you who will face the greatest loss as a result of their deeds?

# 2244

It will be those who labor a great deal in this life but without guidance, yet think that they are doing a great many good deeds.

# 2245

They have rejected the revelations of their Lord and their meeting with Him. Thus, their deeds will be made devoid of all virtue and will be of no value on the Day of Judgment.

# 2246

For their disbelief and their mocking Our revelations and Messengerss, their recompense will be hell.

# 2247

The righteously striving believers will have the gardens of Paradise as their dwelling place and therein they will live forever,

# 2248

without any desire to change their abode.

# 2249

(Muhammad), tell them, "Had the seas been used as ink to write down the words of my Lord, they would have all been consumed before the words of my Lord could have been recorded, even though replenished with a like quantity of ink.

# 2250

Say, "I am only a mortal like you but I have received revelation that there is only one Lord. Whoever desires to meet his Lord should strive righteously and should worship no one besides Him.

# 2251

Kaf. Ha. Ya. Ain. Sad.

# 2252

This is the story of the blessing of your Lord to His servant Zachariah.

# 2253

When he quietly called his Lord

# 2254

and said, "My Lord, my bones have become feeble and my hair has turned white with age. Yet I have never been deprived in receiving from You the answer to my prayers.

# 2255

I am afraid of what my kinsmen will do after (my death) and my wife is barren. Lord, grant me a son

# 2256

who will be my heir and the heir of the family of Jacob. Lord, make him a person who will please you".

# 2257

We answered his prayers with the glad news of the birth of a son by the name of John and told him, "We have never given such a name to anyone else."

# 2258

He said, "Lord, how can I have a son? My wife is barren and I have reached an extremely old age".

# 2259

(The angel) said, "This is true, but your Lord says, 'For Me it is easy; I created you when you did not exist".

# 2260

Zachariah asked, " Lord, show me evidence (if this is a heavenly news)." The Lord said, "The evidence for it is that you must not speak (to any mortal) though you are in good health for three nights (and days)."

# 2261

Zachariah came out to his people from place of worship and inspired them to glorify the Lord both in the morning and evening.

# 2262

We commanded John, Zachariah's son, to follow the guidance of the Lord with due steadfastness. To John We gave knowledge and wisdom to John during his childhood.

# 2263

We gave him compassion and purity. He was a pious human being,

# 2264

kind to his parents, not arrogant or a rebellious person.

# 2265

He was born and died in peace and will be brought back to life again in peace.

# 2266

(Muhammad), mention in the Book (the Quran) the story of Mary how she left her family and started living in a solitary place to the East

# 2267

out of her people's sight. We sent Our Spirit to her, who stood before her in the shape of a well formed human being.

# 2268

Mary said, "Would that the Beneficent God would protect me from you. Leave me alone if you are a God fearing person".

# 2269

He said, "I am the Messengers of your Lord. I have come to give you a purified son".

# 2270

She said, "How can I have a son when no mortal has touched me nor am I an unchaste woman".

# 2271

He said, "This is true but your Lord says, "It is very easy for Me. We have decided to give you a son as evidence (of Our existence) for human beings and a mercy from Us. This is a decree already ordained."

# 2272

She conceived the child and retreated with him to a distant and solitary place.

# 2273

When she started to experience (the pain of) of childbirth labor, by the trunk of a palm tree in sadness she said, "Would that I had died long before and passed into oblivion."

# 2274

Then she heard the baby saying, "Do not be sad. Your Lord has caused a stream to run at your feet.

# 2275

If you shake the trunk of the palm tree, it will provide you with fresh ripe dates.

# 2276

Eat, drink, and rejoice. Should you see a person going by, tell him that on this day you have promised the Beneficent God to fast and never talk to any human being."

# 2277

She took him to her people and they said, "Mary, this is indeed an strange thing.

# 2278

Aaron's sister, your father was not a bad man nor was your mother unchaste".

# 2279

She pointed to the baby (and referred them to him for their answer). They said, "How can we talk to a baby in the cradle?"

# 2280

He said, "I am the servant of God. He has given me the Book and has appointed me to be a Prophet.

# 2281

He has blessed me no matter where I dwell, commanded me to worship Him and pay the religious tax for as long as I live.

# 2282

He has commanded me to be good to my parents and has not made me an arrogant rebellious person.

# 2283

I was born with peace and I shall die and be brought to life again with peace."

# 2284

Such was the true story of Jesus, the son of Mary, about which they dispute bitterly.

# 2285

God is too Exalted to have a son. When He decides to bring some thing into existence He needs only command it to exist and it comes into existence.

# 2286

(Baby Jesus said), "Worship God who is my Lord as well as yours. This is the straight path".

# 2287

(The followers of Jesus) turned themselves into quarrelling sects. The disbelievers shall face a woeful condition on the great Day (of Judgment).

# 2288

(Muhammad), how clearly they will hear and see on the day when they will be brought into Our presence. Today the wrong doers are in manifest error.

# 2289

Warn them of the woeful day when the final decree will be issued; they are neglectful and faithless.

# 2290

We are the heirs of the earth and those living in it will all return to Us.

# 2291

Mention the story of Abraham, the truthful Prophet, in the Book (the Quran)

# 2292

who asked his father, "Father, why do you worship something that can neither hear nor see nor help you at all?

# 2293

Father, I have received the knowledge which has not been given to you. Follow me; I shall guide you to the right path.

# 2294

Father, do not worship satan; he has disobeyed the Beneficent God.

# 2295

Father, I am afraid that the Beneficent God's torment will strike you and you will become a friend of satan."

# 2296

His father replied, "Abraham, are you telling me to give-up my gods? If you will not stop this, I shall stone you to death. Leave my house and do not come back again".

# 2297

Abraham said, "Peace be with you. I shall ask my Lord to forgive you; He has been gracious to me.

# 2298

I shall stay away from you and what you worship instead of God. I worship my Lord and hope that my prayers will not be ignored."

# 2299

When (Abraham) rejected his people and what they worshipped instead of God, We gave him Isaac and Jacob and made both of them Prophets.

# 2300

We granted them Our blessing and high renown.

# 2301

(Muhammad), mention in the Book (the Quran) the story of Moses. Moses was a sincere person, a Messengers and a Prophet.

# 2302

We called him from the right side of Mount Sinai and drew him close for communication.

# 2303

Out of Our mercy We gave him his brother Aaron who himself was a Prophet.

# 2304

Mention in the Book (the Quran) the story of Ishmael; he was true to his promise, a Messengers and a Prophet.

# 2305

He would order his people to worship God and pay the religious tax. His Lord was pleased with him.

# 2306

Mention in the Book (the Quran) the story of Idris (Enoch); he was a truthful Prophet.

# 2307

We granted him a high position.

# 2308

These were the Prophets from the offspring of Adam, from those who embarked with Noah and from the offspring of Abraham and Israel. God guided them and chose them for His favor. Whenever they would hear the revelations of the Beneficent God they would bow down in prostration with tears.

# 2309

They were succeeded by a generation who neglected their prayers and followed their worldly desires. They will certainly be lost,

# 2310

but those among them who repent and become righteously striving believers will be admitted to the gardens without experiencing any injustice.

# 2311

They will be admitted to the garden of Eden which is the unseen promise of the Beneficent God to His servants. The promise of God will certainly come true.

# 2312

They will not hear therein any meaningless words. They will be greeted (by the angels) with "Peace be with you," and they will receive their sustenance both in the mornings and evenings.

# 2313

Such are the gardens which We will give to Our God-fearing servants as their inherited property.

# 2314

(Muhammad), we (the angels) do not come to you without being commanded by your Lord to do so. To Him belongs all that is before us, behind us, and in between. Your Lord is not forgetful.

# 2315

He is the Lord of the heavens and the earth and all that is between them. Worship Him and be steadfast in your worship of Him; none is equal to Him.

# 2316

The human being says, "Shall I be brought to life again after I will die?"

# 2317

Does he not remember that We created him when he did not exist?

# 2318

By your Lord, We will bring them back to life with satan and gather them around hell in large groups.

# 2319

Then We will separate from every group those who were strongly rebellious against the Beneficent God.

# 2320

We know best who deserves greater suffering in hell fire.

# 2321

It is the inevitable decree of your Lord that every one of you will be taken to hell.

# 2322

We will save the pious ones from the hell fire and leave the unjust people therein in crowded groups.

# 2323

When Our revelations are recited to them, the unbelievers say to the faithful ones, "Which of us is more prosperous?"

# 2324

How many generations of greater prosperity and splendor have We destroyed before them?

# 2325

(Muhammad), tell them, "The Beneficent God gives respite to those who have gone astray only until they face the torment with which they were threatened or to the Day of Judgment. Then they will find out who will have the most miserable place and the weakest forces.

# 2326

God further enlightens those who seek guidance. To those who do charitable deeds which produce continuing benefits, your Lord will give a better reward and a better place in Paradise.

# 2327

Note the words of the disbeliever, "I shall certainly be given wealth and children?"

# 2328

Has he the knowledge of the unseen or has the Beneficent God established such a binding agreement with Him?

# 2329

Absolutely not, We will record his words and prolong his punishment.

# 2330

All that he speaks of will belong to Us, and he will come into Our presence all alone.

# 2331

They have sought honor from other gods instead of God.

# 2332

In fact, they can have no honor; their gods will renounce their worship of idols and will turn against them.

# 2333

Do you not realize that We have sent Satan to incite the unbelievers to sin.

# 2334

(Muhammad), exercise patience; We have given them respite only for an appointed time.

# 2335

On the Day of Judgment, when the pious people will be brought into the presence of the Beneficent God as the guests of honor

# 2336

and the criminals will be driven and thrown into hell,

# 2337

no one will be able to intercede for the others except those whom the Beneficent God has given authority.

# 2338

They have said that the Beneficent God has given birth to a son.

# 2339

This is certainly a monstrous lie!

# 2340

This would almost cause the heavens to rent apart, the earth to cleave asunder and the mountains to crumble down in fragments,

# 2341

to ascribe a son to the Beneficent God.

# 2342

The Beneficent God is too Exalted to have a son.

# 2343

All that is in the heavens and the earth will return to the Beneficent God as His submissive servants.

# 2344

He has counted and enumerated them one by one.

# 2345

Everyone on the Day of Judgment will individually come into the presence of God.

# 2346

To the righteously striving believers God will grant love.

# 2347

(Muhammad), We have given you the Book (the Quran) in your own language so that you could easily give the glad news to the pious ones and warn the quarrelsome ones.

# 2348

How many generations living before them did We destroy? Do you find anyone of them around or do you even hear any word from them?

# 2349

Ta Ha.

# 2350

We have sent the Quran only as reminder

# 2351

for those who have fear (of disobeying God), not to make you, (Muhammad), miserable.

# 2352

It is a revelation from the Creator of the earth and the high heavens.

# 2353

The Beneficent God is dominant over the Throne (of the realm).

# 2354

To Him belongs all that is in the heavens and the earth, all that lies between them, and lies below the earth.

# 2355

Whether or not you express (your thoughts) in words, God certainly knows all unspoken thoughts and all that is even more difficult to find.

# 2356

God is the only Lord and to Him belong all the exalted Names.

# 2357

(Muhammad), have you heard the story of Moses?

# 2358

When he saw the fire, he said to his family, "Wait here for I can see a fire. Perhaps I shall bring you a burning torch or find a way to some fire".

# 2359

When he came near the fire he was called, "Moses,

# 2360

I Am your Lord. Take off your shoes; you are in the holy valley of Tuwa.

# 2361

I have chosen you as My Messengers. Listen to the revelation.

# 2362

I Am the only God. Worship Me and be steadfast in prayer to have My name always in your mind.

# 2363

Although it is certain that the Day of Judgment will come, I prefer to keep it almost a secret so that every soul will receive the recompense for what it has done (on its own).

# 2364

Let not the unbelievers who follow their vain desires make you forget the Day of Judgment, lest you will perish."

# 2365

The Lord asked, "Moses, what is in your right hand?"

# 2366

He replied, "It is my staff. I lean on it, bring down leaves for my sheep with it and I need it for other reasons.

# 2367

The Lord said, "Moses, throw it on the ground".

# 2368

Moses threw it on the ground and suddenly he saw that it was a moving serpent.

# 2369

The Lord said, "Hold the serpent and do not be afraid; We will bring it back to its original form."

# 2370

"Now - as another Sign - place your hand under your arm and it will come out sheer white without harm (or stain).

# 2371

This We have done to show you some of Our greater miracles.

# 2372

Go to the Pharaoh; he has become a rebel."

# 2373

Moses said, "Lord, grant me courage.

# 2374

Make my task easy

# 2375

and my tongue fluent

# 2376

so that they may understand me.

# 2377

Appoint a deputy (for me) from my own people.

# 2378

Let it be my brother Aaron

# 2379

to support me.

# 2380

Let him be my partner in this task

# 2381

so that we may glorify

# 2382

and remember you often.

# 2383

You are Well Aware of our situation."

# 2384

The Lord said, "Moses, your request is granted.

# 2385

It is the second time that We have bestowed upon you Our favor.

# 2386

Remember when We inspired your mother with a certain inspiration

# 2387

to lace her child in a chest and throw it into the sea which would hurl it towards the shore. Then an enemy of Mine who was also the enemy of the child would pick it up from there. I made you attractive and loveable so that you would be reared before My own eyes.

# 2388

Your sister went to them and said, "May I show you someone who will nurse this child?" We returned you to your mother to make her rejoice and forget her grief. You slew a man and We saved you from trouble. We tried you through various trials. Then you stayed some years with the people of Midian (Shu'ayb and his family) and after that you came back to Egypt as was ordained.

# 2389

I chose you for Myself.

# 2390

"Go with your brother. Take My miracles and do not be reluctant in preaching My message.

# 2391

Go both of you to the Pharaoh; he has become a rebel.

# 2392

Both of you must speak with him in a gentle manner so that perhaps he may come to himself or have fear (of God)."

# 2393

They said, "Lord, we are afraid of his transgression and rebellion against us".

# 2394

The Lord replied them, "Do not be afraid; I Am with you all the time, listening and seeing."

# 2395

They came to the Pharaoh and told him that they were the Messengerss of his Lord and that they wanted him to let the Israelites go with them and stop afflicting the Israelites with torment. They told the Pharaoh, "We have brought miracles from Our Creator. Peace be with those who follow the right guidance.

# 2396

It is revealed to us that those who call our message a lie or turn away from it will face the torment."

# 2397

The Pharaoh asked them, "Who is your Lord?"

# 2398

They replied, "Our Lord is the One Who has created all things and has given guidance".

# 2399

He then asked, "What do you know about the past generations?"

# 2400

Moses replied, "The knowledge about it is with my Lord in the Book. My Lord is free from error and forgetfulness.

# 2401

It is God who has made the earth as a cradle for you with roads for you to travel. He has sent water from the sky to produce various pairs of plants.

# 2402

Consume them as food or for grazing your cattle. In this there is evidence (of the existence of God) for the people of reason".

# 2403

We have created you from the earth to which We will return you and will bring you back to life again.

# 2404

We showed the Pharaoh all of Our miracles, but he called them lies and turned away from them.

# 2405

He said to Moses, "Have you come to expel us from our land through your magic?

# 2406

We shall also answer you by magic. Let us make an appointment for a contest among us and let each of us be present at a certain time in the appointed place".

# 2407

Moses said, "Let the contest take place on the Day of Feast so that all the people can come together during the brightness of the day."

# 2408

The Pharaoh returned to organize his plans and then attended the appointment.

# 2409

Moses told them, (the magicians) "Woe to you if you invent falsehood against God; you will be destroyed by the torment. Whoever invents falsehood against God will certainly be lost."

# 2410

They started arguing and whispering to each other

# 2411

and said, "These two people are magicians. They want to expel you from your land through their magic and to destroy your own tradition.

# 2412

Bring together your devices and come forward in ranks; the winner will, certainly, have great happiness".

# 2413

They said, "Moses, would you be the first to show your skill or should we be the first to throw down our devices?"

# 2414

Moses said, "You throw first." When they did, their ropes and staffs through their magic seemed to be moving.

# 2415

Moses felt afraid within himself.

# 2416

We told him, "Do not be afraid for you will be the winner.

# 2417

Throw down what is in your right hand and it will swallow up all that they have performed; theirs is only a magical performance. Magicians can find no happiness in whatever they do."

# 2418

The magicians bowed down in prostration saying, "We believe in the Lord of Moses and Aaron".

# 2419

The Pharaoh said, "Since you believed in him without my permission, then Moses certainly must be your chief who has taught you magic. I shall cut your hands and feet on alternate sides and crucify you on the trunk of the palm-tree. You shall certainly find which among us can afflict a more severe and lasting punishment".

# 2420

They (the magicians) said, "We would never prefer you to the miracles that we have seen or to our Creator. Do what you want. This life is only for a short time.

# 2421

We have faith in our Lord so that He will forgive our sins and our magical performances that you forced us to show. God is better than all things and His rewards last longer."

# 2422

The dwelling place of one who comes into the presence of his Lord as a criminal will be hell wherein he will never die nor enjoy his life.

# 2423

One who comes into the presence of his Lord with faith and righteous deeds

# 2424

will be rewarded by high status in the gardens of Eden wherein streams flow. Such will be the reward of those who purify themselves.

# 2425

We sent revelations to Moses telling him, "Travel with My servants during the night and strike a dry road across the sea (for them). Have no fear of being overtaken (by the Pharaoh) nor of anything else".

# 2426

The Pharaoh and his army chased Moses and his people but were drowned by the sea.

# 2427

The Pharaoh and his people had gone away from guidance.

# 2428

Children of Israel, We saved you from your enemy and promised to settle you on the right side of the peaceful Mount Tur (Sinai)

# 2429

and We sent you manna and quails.

# 2430

I allowed you to consume the pure sustenance which We had given you but not to become rebels, lest you become subject to My wrath. Whoever becomes subject to My wrath will certainly be destroyed. I am All-forgiving to the righteously striving believers who repent and follow the right guidance.

# 2431

The Lord asked, "Moses, what made you attend your appointment with Me before your people?"

# 2432

Moses replied, "They are just behind me. I came earlier to seek Your pleasure".

# 2433

The Lord said, "We tested your people after you left them and the Samiri made them go astray."

# 2434

Moses, sad and angry, returned to his people saying, "My people, did not the Lord make you a gracious promise? Why did you disregard your appointment with me? Was it because of the long time or did you want to become subject to the wrath of your Lord?"

# 2435

They replied, "We did not go against our promise with you out of our own accord. We were forced to carry people's ornaments. We threw them away and so did the Samiri.

# 2436

Then the Samiri forged the body of a motionless calf which gave out a hollow sound." The people said, "This is your Lord and the Lord of Moses whom he (Moses) forgot to mention".

# 2437

Did they not consider that the calf could not give them any answer, nor it could harm or benefit them?

# 2438

Aaron had told them before, "My people, you are deceived by the calf. Your Lord is the Beneficent God. Follow me and obey my orders".

# 2439

They said, "We shall continue worshipping the calf until Moses comes back."

# 2440

Then Moses asked Aaron, "What made you not follow me when you saw them in error?

# 2441

Did you disobey my orders?"

# 2442

Aaron replied, "Son of my mother, do not seize me by my beard or head. I was afraid that you might consider me responsible for causing discord among the children of Israel and would not pay attention to my words."

# 2443

Moses asked, "Samiri, what were your motives?"

# 2444

He replied, "I had the skill (of carving) which they did not have. I followed some of the Messengers's (Moses) tradition, but I then ignored it. Thus, my soul prompted me (to carve a golden calf with an artificial hollow sound).

# 2445

Moses said, "Go away! Throughout your life you will not be able to let anyone touch you. This will be your punishment in this life. The time for your final punishment is inevitable. You will never be able to avoid it. Look at your god which you have been worshipping. We will burn it in the fire and scatter its ashes into the sea."

# 2446

Your Lord is the One who is the only God and He has the knowledge of all things.

# 2447

Thus We tell you, (Muhammad), the stories of the past and We have given you the Quran.

# 2448

Whoever disregards (the Quran) will be heavily burdened with sin on the Day of Judgment

# 2449

with which he will live forever. On the Day of Judgment it will be a terrible load for him to carry.

# 2450

On the day when the trumpet will be sounded We will raise the criminals from their graves and their eyes will be turned blue and blind.

# 2451

They will slowly talk to each other and say, "Our life on earth was as short as ten days".

# 2452

We know best what they say. The moderate ones among them will say, "You did not live on earth for more than a day."

# 2453

(Muhammad), they will ask you about the mountains. Tell them, "My Lord will grind them to powder

# 2454

and leave them so smoothly levelled

# 2455

that you will see no depression or elevation in it".

# 2456

On that day they will follow their caller without deviation. Their voices will be low in the presence of the Beneficent God. You will hear nothing but the tread of the marching feet.

# 2457

On that day no one's intercession will be of any benefit unless he has received permission from the Beneficent God and whose word is acceptable to Him.

# 2458

God knows all that is in front of them and behind them and they can not encompass His knowledge.

# 2459

Faces will be humble before the Everlasting and the Self-existing God. Despair will strike those who are loaded with the burden of injustice.

# 2460

The righteously striving believers should have no fear of being treated with injustice or inequity.

# 2461

We have revealed the Quran in the Arabic language containing various warnings so that it may cause them to have fear (of God) or take heed.

# 2462

God is the Most High and the True King. (Muhammad), do not be hasty in reading the Quran to the people before the revelation has been completed. "Say, My Lord, grant me more knowledge."

# 2463

We had commanded Adam (certain matters). He forgot Our commandment and We did not find in him the determination to fulfil Our commandments.

# 2464

When We told the angels to prostrate before Adam they all obeyed except Iblis (satan) who refused.

# 2465

We said, "Adam, this (satan) is your enemy and the enemy of your spouse. Let him not expel you and your spouse from Paradise lest you plunge into misery.

# 2466

In Paradise you will experience no hunger, nakedness,

# 2467

thirst, or exposure to the hot Sun."

# 2468

Satan, trying to seduce him, said, "Adam, do you want me to show you the Tree of Eternity and the Everlasting Kingdom?"

# 2469

Adam and his wife ate (fruits) from the tree and found themselves naked. Then they started to cover themselves with the leaves from the garden. Adam disobeyed his Lord and went astray.

# 2470

His Lord forgave him, accepted his repentance, and gave him guidance.

# 2471

God then told them, "Get out of here all of you; you are each other's enemies. When My guidance comes to you, those who follow it will not go astray nor will they endure any misery.

# 2472

Whoever ignores My guidance will live a woeful life and will be brought in Our presence blind on the Day of Judgment.

# 2473

He will say, "My Lord, why have you brought me back to life blind; before I could see?"

# 2474

The Lord will say, "This is true. But just as you forgot Our revelations that had come to you, so, too, are you forgotten on this day."

# 2475

Thus We recompense those who are unjust and have no faith in Our revelations. The torment in the life to come will be more severe and last longer.

# 2476

Is it not a warning for them to see how many generations living before them We destroyed and how they are now walking in their ruins? In this there is the evidence (of the Truth) for the people of reason.

# 2477

Had not the word of your Lord been decreed (otherwise), the unbelievers deserved immediate punishment. The appointed time for their punishment will inevitably come.

# 2478

(Muhammad), have patience with what they say, glorify your Lord, and always praise Him before sunrise, sunset, in some hours of the night and at both the beginning and end of the day, so that perhaps you will please your Lord.

# 2479

Do not be envious of what We have given to some people as means of enjoyment and worldly delight. Such means are a trial for them, but the reward that you will receive from your Lord will be far better and everlasting.

# 2480

Instruct your family to pray and to be steadfast in their worship. We do not ask any sustenance from you; it is We who give you sustenance. Know that piety will have a happy end.

# 2481

They have said, "Why has he, (Muhammad), not brought some miracle from his Lord?" Have they not received the previously revealed heavenly Books as the evidence of the Truth.

# 2482

Had We destroyed them with a torment before the coming of Muhammad they would have said, "Lord, would that you had sent us a Messengers so that we could have followed Your revelations before being humiliated and disgraced."

# 2483

(Muhammad), tell them, "Everyone is waiting. Wait and you shall know very soon who will be the followers of the right path with the right guidance."

# 2484

The people's day of reckoning is drawing closer, yet they are heedlessly neglectful.

# 2485

Whenever a new revelation comes to them from their Lord, they listen to it in a playful manner,

# 2486

and their hearts are preoccupied with trivial matters. The unjust ones whisper to each other and say, "Is he (Muhammad) more than a mere mortal like you? How can you follow that which you know is only a magic?"

# 2487

The Lord said, "Tell them (Muhammad), 'My Lord knows all that is said in the heavens and the earth. He is All-hearing and All-knowing ".

# 2488

They have said, "It, (the Quran), is only the result of some confused dreams. He is only a poet. He should show us some miracles, as the ancient Prophets had done."

# 2489

The people of the town whom We had destroyed also had no faith. Will these people then believe in God?

# 2490

The messengers that We had sent before you were only men to whom We had given revelation. Ask the People of the Book if you do not know.

# 2491

We had not made them such bodies that would not eat any food nor were they immortal.

# 2492

Our promise to them came true and We saved them and those whom We wanted, but destroyed the unjust people.

# 2493

We have sent a Book, (the Quran), which is an honor for you. Will you then not understand?

# 2494

How many unjust towns did We destroy and replace them with other nations?

# 2495

When they found Our torment approaching them they started to run away from the town.

# 2496

We told them, "Do not run away. Come back to your luxuries and your houses so that you can be questioned".

# 2497

They said, "Woe to us! We have been unjust".

# 2498

Such was what they continued to say until We mowed them down and made them completely extinct.

# 2499

We did not create the heavens and the earth just for fun.

# 2500

Had We wanted to play games, We could have certainly done so with things at hand.

# 2501

We bring forward the Truth to crush and destroy falsehood; it is doomed to be banished. Woe to you for your way of thinking about God!

# 2502

To Him belongs all those who are in the heavens and the earth. Those who are closer to Him are not too proud to worship Him, nor do they get tired of worshipping.

# 2503

They glorify Him day and night without fail.

# 2504

Have they chosen deities from earth? Can such deities give life to anyone?

# 2505

Had there been other deities in the heavens and the earth besides God, both the heavens and the earth would have been destroyed. God, the Lord of the Throne, is too Glorious to be as they think He is.

# 2506

He will not be questioned about anything He does, but all people will be questioned about their deeds.

# 2507

Have they chosen other gods besides God? (Muhammad), ask them, "Show the proof (in support of such belief). This is (the Quran) which tells us about the (beliefs of the people) in my time and those who lived before me." Most of them do not know. Moreover, the truth is that they neglect (the question of belief altogether).

# 2508

To all the Messengers that were sent before you We revealed that I am the only God to be worshipped.

# 2509

They said, "The Beneficent God has given birth to a son. He is too Exalted to give birth to a son." (Those whom they think are God's sons) are only His honorable servants.

# 2510

These servants do not speak before He speaks. They simply act according to His orders.

# 2511

He knows all that is in front of them and all that is behind them. (These servants of God) will not intercede with Him for anyone without His permission and they tremble in awe (before His greatness).

# 2512

The recompense of those of them who say that they are the Lord instead of God will be hell; thus, do We recompense the unjust ones.

# 2513

Have the unbelievers not ever considered that the heavens and the earth were one piece and that We tore them apart from one another. From water We have created all living things. Will they then have no faith?

# 2514

We placed firm mountains on earth lest it would shake them away. We made wide roads for them so that they might have the right guidance.

# 2515

We made the sky above them as a well-guarded ceiling, but they have neglected the evidence (of Our existence) therein.

# 2516

It is God who has created the night, the day, the Sun, and Moon and has made them swim in a certain orbit.

# 2517

We made no mortal before you immortal. Will they become immortal after you die?

# 2518

Every soul has to experience the taste of death. We test you with both hardships and blessings. In the end you will all return to Us.

# 2519

(Muhammad), whenever the unbelievers see you, they think that you deserve nothing more than to be mocked. They say, "Is it he, (Muhammad), who speaks against your gods?" But they themselves have no faith at all in the Beneficent God.

# 2520

The human being is created hasty. Tell them, "Do not be hasty, for God will soon show you the evidence of His existence".

# 2521

They say, "When shall the Day of Judgment come to pass if you are true in your claim?"

# 2522

Would that the unbelievers knew that no one would protect their faces and backs against the fire, nor they would be helped.

# 2523

The fire will suddenly strike and confound them. They will not be able to repel it, nor will they be given any respite.

# 2524

They mocked the Messengers who were sent before you; thus, the torment which they had ridiculed encompassed them all.

# 2525

Ask them, "Who can protect them from (the wrath of) the Beneficent God during the night and day?" Yet they are neglectful about their Lord.

# 2526

Can their gods protect them against Us? Their gods have no power even to help themselves, nor are they safe from Our retribution.

# 2527

We have been providing these men and their fathers with the means of enjoyment for a long time. Have they not ever considered that We populated the earth and then caused many of the inhabitants to pass away? Can they have any success (in their wickedness)?

# 2528

(Muhammad), tell them, "I am warning you by revelation alone." The deaf do not hear any call when they are warned.

# 2529

If a blast of the torment of your Lord strikes them, they will say, "Woe to us! We have been unjust people."

# 2530

We shall maintain proper justice on the Day of Judgment. No soul will be wronged the least. For a deed even as small as a mustard seed one will duly be recompensed. We are efficient in maintaining the account.

# 2531

To Moses and Aaron We granted the criteria of discerning right from wrong, and We gave them the light and a reminder to the pious ones

# 2532

who fear their unseen Lord and are anxious about the Day of Judgment.

# 2533

This (Quran) which We have revealed is a blessed reminder. Will you then deny it?

# 2534

To Abraham We gave the right guidance and We knew him very well.

# 2535

Abraham asked his father and his people, "What are these statues which you worship?"

# 2536

They replied, "We found our fathers worshipping them".

# 2537

He said, "Both you and your fathers have certainly been in error."

# 2538

They exclaimed, "Have you brought the Truth or are you joking?"

# 2539

He said, "Your Lord is the Lord of the heavens and the earth. It was He who created them and I testify to this fact".

# 2540

Abraham said to himself, "By God! I will devise a plan against their idols when they are away."

# 2541

He broke all the idols into pieces, except the biggest among them so that perhaps people would refer to it.

# 2542

(When the people came to the temple and saw the broken idols) they asked each other, "Who has done this to our gods? He certainly is an unjust person".

# 2543

Some of them said, "We heard a youth called Abraham speaking against the idols".

# 2544

Their chiefs said, "Bring him before the eyes of the people and let them testify that he has spoken against the idols."

# 2545

They asked, "Abraham, did you do this to our idols?"

# 2546

He replied, "I think the biggest among them has broken the smaller ones. Ask them if they are able to speak".

# 2547

Thereupon they realized their own foolishness and said, "We ourselves are wrong-doers".

# 2548

With their heads cast down they said, "Abraham, you know that idols do not speak. How then can you ask such a question?"

# 2549

He said, "Do you, instead of God, worship things that can neither harm nor benefit you?"

# 2550

Woe to you for what you worship instead of God. Have you no understanding?"

# 2551

They said, "Burn him to ashes if you want to help your gods".

# 2552

We said to the fire, "Be cool and peaceful (with Abraham)".

# 2553

They had devised an evil plan (against Abraham), but We turned it into failure."

# 2554

We took Abraham and Lot safely to the land in which We had sent blessings to the worlds.

# 2555

We granted him Isaac and Jacob as a gift and helped both of them to become righteous people.

# 2556

We appointed them as leaders to guide the people through Our command and sent them revelation to strive for good deeds, worship their Lord, and pay religious tax. Both of them were Our worshipping servants.

# 2557

To Lot We gave knowledge and wisdom and saved him from the people of the town who were committing indecent acts. They were certainly a bad and sinful people.

# 2558

We encompassed him in Our mercy; he was a righteous man.

# 2559

We answered the prayer of Noah who had prayed to Us before and saved him and his followers from the great disaster.

# 2560

We helped him against the people who said Our revelations were mere lies. They were a bad people and We drowned them all.

# 2561

David and Solomon were trying to settle the case of the people's sheep that grazed in a corn-field at night. We witnessed their decree in that matter.

# 2562

We made Solomon understand the law about the case and gave both David and Solomon knowledge and wisdom. We made the mountains and birds glorify the Lord along with David. We had also done to him such favors before.

# 2563

We taught him the art of making coats of mail so that you could protect yourselves during a war. Will you then give thanks?

# 2564

We made subservient to Solomon the swift wind that blew on his command to the land in which We had sent blessings. We have the knowledge of all things.

# 2565

We subdued the devils who would dive into the sea for him and perform other tasks for Solomon. We kept them in his service.

# 2566

When Job prayed, "Lord, I have been afflicted with hardships. Have mercy on me; You are the Most Merciful of those who have mercy,

# 2567

"We answered his prayer, relieved him from his hardships, brought his family (back to him) and gave him twice as much property as that (which was destroyed). It was a mercy from Us and a reminder for the worshippers.

# 2568

Ismael, Idris and Dhul Kifl all were people of great patience.

# 2569

We encompassed them in Our mercy; they were righteous people.

# 2570

Dhun Nun went away in anger and thought that We would never have power over him, but in darkness he cried, "Lord, You are the Only God whom I glorify. I have certainly done wrong to myself (so forgive me)".

# 2571

We answered his prayer and saved him from his grief. Thus We save the faithful ones.

# 2572

Zachariah prayed, "Lord, do not leave me alone without offspring, although you are the best heir".

# 2573

We answered his prayer and granted him his son, John, by making his wife fruitful. They were people who would compete with each other in good deeds and pray to Us with love and reverence. With Us they were all humble people.

# 2574

Into the woman who maintained her chastity We breathed Our Spirit and made her and her son a miracle for all people.

# 2575

People, you are one nation and I am your Lord. Worship Me.

# 2576

People have divided themselves into many sects, but all will return to Us.

# 2577

The reward of the righteously striving believers will not be neglected. We are keeping the record of their good deeds.

# 2578

The people whom We destroyed can never return to this world

# 2579

until Gog and Magog are let loose to rush down from the hills.

# 2580

The Day of Judgment will then draw near and the unbelievers will stare amazedly and cry, "Woe to us! We had neglected this day. We have done wrong".

# 2581

They will be told, "You and what you had worshipped instead of God will be the fuel of hell".

# 2582

Had the idols been true lords, they would not have gone to hell. "All of you will live therein forever".

# 2583

They will groan in pain therein, but no one will listen to them.

# 2584

But those to whom We have already promised blessings will be far away from hell.

# 2585

They will not even hear the slightest sound from it while enjoying the best that they can wish for in their everlasting life.

# 2586

They will not be affected by the great terror. The angels will come to them with this glad news: "This is your day which was promised to you."

# 2587

(This will happen) on the day when We roll up the heavens as if it were a written scroll and bring it back into existence just as though We had created it for the first time. This is what We have promised and We have always been true to Our promise.

# 2588

We have written in the psalms which We had revealed after the Torah that the earth will be given to Our righteous servants as their inheritance.

# 2589

This is a lesson for those who worship (God).

# 2590

(Muhammad), We have sent you for no other reason but to be a mercy for mankind.

# 2591

Say, "It is revealed to me that there is only one Lord. Will you then submit yourselves to His will?"

# 2592

If they turn away, tell them, "I have warned every one of you equally. I do not know when the torment which you have to suffer will take place.

# 2593

God knows well all that is spoken aloud and all that you hide.

# 2594

I do not know (why God has commanded me to warn you of the torment). Perhaps it is a trial for you and a respite for an appointed time".

# 2595

He also said, "Lord, judge (us) with Truth. Our Lord is the Beneficent One whose help I ask against the blasphemies you say about Him".

# 2596

People, have fear of your Lord; the quake (of the physical realm) at the Hour of Doom will be terribly violent.

# 2597

When that hour comes, every breast-feeding mother will drop her baby out of fear and every pregnant female will cast off her burden. You will see the people behaving as though they were drunk, while, in fact, they are not drunk. They only will look such because of the severity of God's torment.

# 2598

Some people argue about God without knowledge and follow every rebellious devil.

# 2599

It has been decided that satan will mislead and submit anyone who establishes friendship with him to the torment of the burning fire.

# 2600

People, if you have doubts about the Resurrection, you must know that We created you from clay that was turned into a living germ. This was developed into a clot of blood, which was made into a well formed and partly shapeless lump of flesh. This is how We show you that resurrection is not more difficult for Us than your creation. We cause whatever We want to stay in the womb for an appointed time, We then take you out of the womb as a baby, so that you may grow up and receive strength. Some of you may then die and others may grow to a very old age and lose your memory. You may see the earth as a barren land, but when we send rain, it starts to stir and swell and produce various pairs of attractive herbs.

# 2601

This is because God is the Supreme Truth who gives life to the dead and who has power over all things.

# 2602

There is no doubt about the coming of the Hour of Doom and that God will raise every one from their graves.

# 2603

Some people argue about God without knowledge, guidance, and an enlightening Book.

# 2604

They turn away (from the Truth) to lead people away from the path of God. Their share in this world will be disgrace and on the Day of Judgment a burning torment.

# 2605

(They will be told), "This is the result of what your hands have wrought. God is certainly not unjust to His servants."

# 2606

Some people worship God to achieve worldly gains. They are confident when they are prosperous, but when they face hardships they turn away from (worship). They are lost in this life and will be lost in the life to come. Such loss is indeed destructive.

# 2607

They worship things instead of God which can neither harm them nor benefit them. This is indeed to stray far away from the right path.

# 2608

Their worship of such things, in which there is no hope for any benefit, can only harm them. How terrible is such a guardian and companion!

# 2609

God will admit the righteously striving believers to the gardens wherein streams flow. God has all the power to do whatever He wants.

# 2610

Those who thought that God would never grant victory to (Muhammad), in this world nor in the life hereafter (and now that he is victorious) should hang themselves by the necks from the ceiling, then cut the rope and see if this can do away with what has enraged them.

# 2611

We have revealed the Quran which contains authoritative verses. God guides only those whom He wants.

# 2612

On the Day of Judgment, God will make truth and falsehood clearly distinct from each other to the believers, the Jews, the Sabeans, the Christian, the Zoroastrians, and the Pagans on the Day of Judgment. God is a Witness to all things.

# 2613

Have you not considered that those in the heavens and the earth, the Sun, the Moon, the Stars, the mountains, the trees, the animals, and many people, all bow down to God? But many people deserve His torment. No one can give honor to whomever God has insulted. God has all the power to do what He wants.

# 2614

(Those who prostrate themselves before God and those who do not) are two groups who dispute with each other about their Lord. For the unbelievers the garment of fire has already been prepared. Boiling water will be poured upon their heads.

# 2615

It will melt their skins and all that is in their bellies.

# 2616

They will be subdued by iron rods.

# 2617

Whenever in anguish they will try to come out of hell they will be returned therein to suffer the burning torment.

# 2618

God will admit the righteously striving believers to the gardens wherein streams flow. There they will be decked with gold bracelets, pearls, and garments of silk,

# 2619

for they were guided to speak the noblest words and follow the praiseworthy path.

# 2620

A painful torment awaits the pagans who create obstacles in the way that leads to God and the Sacred Mosque - which We have made for those who dwell nearby and foreigners alike - and those who commit evil and injustice therein.

# 2621

When We prepared for Abraham the place to build the Sacred House, We told him not to consider anything equal to Me and to keep the House clean for those walking around it, those standing, bowing down, and prostrating in prayer.

# 2622

(We commanded Abraham), "Call people for hajj - an act of worship accomplished by visiting the sacred sites in Mecca." They will come on foot and on lean camels from all the distant quarters

# 2623

to see their benefits, commemorate the name of God during the appointed days, and offer the sacrifice of the cattle that God has given them. They themselves should consume part of the sacrificial flesh and give the rest to the destitute and needy people.

# 2624

Let the pilgrims then neatly dress themselves, fulfil their vows, and walk seven times around the Kabah.

# 2625

Such are the regulations of hajj. To respect the prohibitions of God is a virtuous deed in the sight of one's Lord. Consuming the flesh of certain animals is made lawful for you. Stay away from wickedness, idols, and false words.

# 2626

As the upright servants of God, do not consider anything equal to God. To consider things equal to God is like one falling from the sky who is snatched away by the birds or carried away by a strong wind to a far distant place.

# 2627

To respect the symbols of God is the sign of a pious heart.

# 2628

There are benefits for you in the (sacrificial offerings) of God until the appointed time when you slaughter them as your offering near the Ancient House.

# 2629

To every nation We have given certain sacrificial rituals. Let them consecrate their sacrificial animals with His Name. Your God is One God and you must submit yourselves to His will. (Muhammad), give the glad news (of God's mercy) to the devoted servants of God:

# 2630

Those whose hearts are filled with awe on hearing about God, who exercise patience in hardships, who are steadfast in prayer, and who spend their property for the cause of God.

# 2631

For you We have made the sacrificial camel one of the reminders of God. It also has other benefits for you. Consecrate it with the Name of God when it is steadily standing. When it is slaughtered, consume its flesh and give part of it to the needy who do and those do not ask for help from others. Thus We have made the camel subservient to you so that perhaps you may give thanks.

# 2632

It is not the flesh and blood of your sacrifice that pleases God. What pleases God is your piety. God has made subservient to you the sacrificial animals so that perhaps you will glorify Him; He is guiding you. (Muhammad), give the glad news (of God's mercy) to the righteous people.

# 2633

God defends the believers but He does not love any of the treacherous, ungrateful ones.

# 2634

Permission to take up arms is hereby granted to those who are attacked; they have suffered injustice. God has all the power to give victory

# 2635

to those who were unjustly expelled from their homes only because they said, "God is our Lord." Had it not been for God's repelling some people through the might of the others, the monasteries, churches, synagogues, and mosques in which God is very often worshipped would have been utterly destroyed. God shall certainly help those who help Him. He is All-powerful and Majestic.

# 2636

He will certainly help those who, if given power in the land, will worship God through prayer, pay the religious tax, enjoin others do good, and prevent them from committing evil. The consequence of all things is in the hands of God.

# 2637

If they have called you, (Muhammad), a liar, (remember that) the people of Noah, Ad, Thamud,

# 2638

and the people of Abraham, Lot,

# 2639

Midian, and Moses had also called their Prophets liars. I gave respite to the unbelievers, then sized them with torment. How terrible was that torment!

# 2640

How many were the unjust dwellers of the towns that We destroyed. From their trellises to their lofty mansions, all were toppled and their wells were abandoned.

# 2641

Have they not travelled (sufficiently) in the land to have understanding hearts and listening ears? It is their hearts which are blind, not their ears.

# 2642

They want you to bring upon them their punishment without delay. God never disregards His promise. One day for God is equal to a thousand years for you.

# 2643

To how many unjust towns have We given respite and then sized with torment. To Me do all things return.

# 2644

(Muhammad), tell them, "People, I am giving you a clear warning.

# 2645

The righteously striving believers will receive forgiveness and honorable sustenance.

# 2646

Those who try to challenge Our miracles will be the dwellers of hell."

# 2647

Satan would try to tamper with the desires of every Prophet or Messenger whom We sent. Then God would remove Satan's temptations and strengthen His revelations. God is All-knowing and All-wise.

# 2648

He would make Satan's temptations a trial for those whose hearts are hard and sick. The wrong-doers are far away from the Lord,

# 2649

so that those who have received knowledge would know and believe that whatever happens with the Prophets and Messengers is the Truth from their Lord and will believe it. This will cause their hearts to become filled with awe. God guides the believers to the right path.

# 2650

The unbelievers will continue to doubt the Quran until the Hour of Doom suddenly sizes them or the torment of the last day strikes them.

# 2651

On that day it is God who will be the Absolute King and Judge of (mankind). The righteously striving believers will go to Paradise

# 2652

and the unbelievers who called Our revelations lies will suffer humiliating torment.

# 2653

Those who abandoned their homes for the cause of God and who then died or were murdered will receive honorable sustenance from God; He is the Most Generous and Munificent.

# 2654

God will certainly admit them to a pleasant dwelling. God is All-knowing and Forbearing.

# 2655

One who is wronged and who retaliates by that which is equal to his suffering, God will certainly help him; He is All-pardoning and All-forgiving.

# 2656

God causes the night to enter the day and the day to enter the night. He is All-hearing and All-aware.

# 2657

God is the Supreme Truth and whatever they worship instead of Him is falsehood. God is most Exalted and most Great.

# 2658

Have you not seen that God has sent water from the sky and has made the earth green all over. He is Kind and All-aware.

# 2659

To Him belongs all that is in the heavens and the earth. God is Self-sufficient and Praiseworthy.

# 2660

Have you not seen that God, through His command, has made all that is in the earth and the ships that sail on the sea subservient to you? He prevents the sky from falling on the earth unless He decides otherwise. God is Compassionate and Merciful to mankind.

# 2661

It is He who has given you life, He will make you die and will make you live again. Surely the human being is ungrateful.

# 2662

We enjoined every nation with certain worship acts which they perform. The unbelievers must not dispute with you about the manner of your worship. Invite them to follow the right path of the Lord.

# 2663

If they still dispute with you about your worship, tell them, "God knows best what you do.

# 2664

He will issue His decree about your differences on the Day of Judgment."

# 2665

Do you not know that God knows all that is in the heavens and the earth? His decree is already recorded in the Book and issuing such a Judgment is not difficult for Him at all.

# 2666

They worship things instead of God that have received no authority (from the heavens) nor have they any knowledge of such authority. The unjust people will have no one to help them.

# 2667

When Our authoritative revelations are recited to the unbelievers, you can clearly read the dislike on their faces. They almost attack those who read Our revelations to them. Say to them, "Should I tell you about what is the worst thing for you than these revelations? It is the fire which God has prepared for the unbelievers. What a terrible destination!

# 2668

People, listen to this parable: Those whom you worship instead of God do not have the power to create even a fly, even though all of them would come together for the task. If the fly was to snatch something from them they would not be able to rescue it from the fly. How feeble are such worshippers and that which they worship.

# 2669

They have not revered God properly. God is All-powerful and Majestic.

# 2670

God chooses Messengers from both angels and human beings. God is All-hearing and All-aware.

# 2671

God knows all that they have and all that is behind them, and to Him do all things return.

# 2672

Believers, worship your Lord, bow down and prostrate yourselves before Him and do virtuous deeds so that perhaps you will have everlasting happiness.

# 2673

Strive steadfastly for the Cause of God. He has chosen you but has not imposed on you hardship in your religion, the noble religion of your father, Abraham. God named you Muslims before and in this Book, so that the Messenger will witness (your actions) and will be the witness over mankind. Be steadfast in your prayer, pay the religious tax, and seek protection from God; He is your Guardian, a gracious Guardian and Helper.

# 2674

Triumphant indeed are the believers,

# 2675

who are submissive to God in their prayers,

# 2676

who avoid impious talks,

# 2677

pay their religious tax

# 2678

and restrain their carnal desires

# 2679

except with their spouses and slave-girls. The practice of carnal relations is lawful with them.

# 2680

Those who desire to go beyond such limits they commit transgression,

# 2681

those who are true to their trust,

# 2682

to their promise,

# 2683

and who are steadfast in their prayer.

# 2684

These are the heirs of Paradise wherein they will live forever.

# 2685

We have created the human being from an extract of clay

# 2686

which was then turned into a living germ and placed in safe depository.

# 2687

The living germ, then, was turned into a shapeless lump of flesh from which bones were formed. The bones, then, were covered with flesh. At this stage, We caused it to become another creature. All blessings belong to God, the best Creator.

# 2688

Thereafter you will certainly die

# 2689

and you will be brought back to life again on the Day of Resurrection.

# 2690

We have created seven heavens above you and have never been neglectful to Our Creation.

# 2691

We have sent a measure of water from the sky to stay on earth and We have the power to take it away.

# 2692

We have established for you gardens of palm trees and vineyards with this water with many fruits for you to consume.

# 2693

We have also created for you the tree that grows on Mount Sinai which produces oil and relish for those who use it.

# 2694

There is a lesson for you concerning cattle. We provide you with drink from their bellies and many other benefits. You can consume them as meat.

# 2695

You are carried by the animals on land and by the ships in the sea.

# 2696

We sent Noah to his people who said, "My people, worship God for He is your only Lord. Will you then not have fear of Him?"

# 2697

The chiefs of the unbelievers said to the others, "He is a mere mortal like you. He wants only to be superior to you. Had God wanted He would have sent the angels (instead of him). We have never heard from our fathers anything like what he says.

# 2698

He is only an insane person. Wait for some time. Perhaps he will come to his senses."

# 2699

Noah prayed, "Lord, help me; they have called me a liar".

# 2700

We inspired him, saying, "Build the Ark before Our eyes and by the instruction of Our revelation. When our decree comes to pass and water comes forth from the Oven, embark in the Ark with a pair of every kind of animals and your family except those already doomed (to perish). Do not plead with Me for the unjust; they will be drowned."

# 2701

When all of you settle in the Ark, say, "Only God Who has saved us from the unjust people deserves all praise".

# 2702

Say, "Lord, grant us a blessed landing from the Ark; You are the One who provides the safest landing".

# 2703

In this story there is enough evidence (of the Truth); thus do We try (mankind)

# 2704

We brought another generation into existence after the people of Noah.

# 2705

We sent to them a Messenger from among their own people who told them, "Worship God; He is your only Lord. Will you then not have fear of Him?"

# 2706

A group of his people who disbelieved him and had called the Day of Judgment a lie and whom We had made prosperous in this life, said, "He is a mere mortal like you. He eats and drinks as you do.

# 2707

If you follow a mortal like yourselves you will certainly be lost.

# 2708

Does he promise you that after you die and become dust and bones you will be brought back to life again?

# 2709

Such a promise will never come true.

# 2710

This is our only life. We live and will die but we will never be brought back to life again.

# 2711

He is only a man who invents lies against God, so have no faith in him".

# 2712

The Messenger prayed, "Lord, help me; they have called me a liar".

# 2713

God replied, "After a very short time they will certainly regret for their deeds."

# 2714

A blast struck them for a just cause, and We made them look like withered leaves. God keeps the unjust people away from His mercy.

# 2715

After them We brought another generation into existence.

# 2716

Every nation has an appointed life span.

# 2717

We sent Our messengers one after the other but whenever a Messenger would come to a nation, its people would call him a liar and We would destroy one nation after the other, thus, only their stories were left behind them. God keeps the unbelievers far away from His Mercy.

# 2718

Then We sent Moses and his brother Aaron with Our miracles and clear authority

# 2719

to the Pharaoh and his nobles. But they behaved proudly and thought themselves superior people.

# 2720

They said, "Should we believe in two mere mortals who are like ourselves and whose people are our slaves?"

# 2721

They called them liars and consequently were destroyed.

# 2722

We gave the Book to Moses so that perhaps they may have guidance.

# 2723

We made the son of Mary and his mother a miracle and settled them on a high land, quite secure and watered by a spring.

# 2724

I told them, "Messengers, eat from the pure things and act righteously; I know all that you do.

# 2725

Your religion is one and I am your Lord. Have fear of Me".

# 2726

The people divided themselves into many sects, each with their own book and each happy with whatever they had.

# 2727

(Muhammad), leave them alone in their dark ignorance for an appointed time.

# 2728

Do they think that We are helping them by giving them children and property?

# 2729

We provide them with the means of competing with each other in virtuous deeds, but they do not realize this.

# 2730

Only those who are, out of fear of Him, humble before their Lord,

# 2731

who believe in the revelations of their Lord,

# 2732

who consider nothing equal to their Lord,

# 2733

who spend their property for the cause of God, and whose hearts are afraid of their return

# 2734

to God, these are the ones who really compete with each other in virtuous deeds and are the foremost ones in the task.

# 2735

We do not impose on any soul what is beyond its capacity. We have the Book which speaks the truth and no injustice will be done to it.

# 2736

In fact, the hearts of the unbelievers are in the dark because of their ignorance of real virtue; they act against it.

# 2737

But when We will strike with torment those (unbelievers) who are rich, they will start to cry for help.

# 2738

We shall tell them, "Do not cry for help on this day; you will receive none from Us".

# 2739

Our revelations had certainly been recited to you, but you turned your backs to them

# 2740

and arrogantly mocked and reviled them.

# 2741

Was it that you did not give any thought to it (the Quran)? Was it different from what was revealed to your fathers?

# 2742

Or did you not recognize your Messenger and, thus, denied him (Muhammad)

# 2743

or you said that he is possessed by satan? In fact, he has brought you the truth, but most of you dislike it.

# 2744

Had the truth followed their desires, the heavens and the earth and all that is in them would have been destroyed. We sent them the Quran but they ignored it.

# 2745

(Do they disbelieve because) you asked them for payment? The reward that you will receive from your Lord is the best. He is the best Provider.

# 2746

(Muhammad), you certainly have called them to the right path,

# 2747

but those who disbelieve the life hereafter deviate from the right path.

# 2748

Even if We were to grant them mercy and rescue them from hardship, they would still blindly persist in their rebellion.

# 2749

We struck them with torment, but they did not submit themselves to their Lord, nor did they make themselves humble

# 2750

until We opened the gate of greater torment (death) and they suddenly found themselves in despair.

# 2751

It is God who has created ears, eyes, and hearts for you. Little are the thanks that you give.

# 2752

It is God who has settled you on the earth and before Him you will all be assembled.

# 2753

It is He who gives life and causes death and it is He who alternates night and day. Will you not then understand?

# 2754

They say exactly the same thing as the people who lived before.

# 2755

They say, "When we die and become dust and bones, shall we then be raised up again?

# 2756

Our fathers and we have been given such promises before. These are no more than ancient legends."

# 2757

(Muhammad), say to them, "Tell me, if you know, to whom does the earth and its contents belong?"

# 2758

They will quickly reply, "It belongs to God." Say, "Will you not, then, take heed?"

# 2759

Ask them, "Who is the Lord of the seven heavens and the Great Throne?"

# 2760

They will quickly say, "It is God." Say, "Will you not then have fear of Him?"

# 2761

Ask them, "If you have any knowledge, in whose hands is the ownership of all things? Who is the one who gives protection and yet He Himself is never protected?"

# 2762

They will reply spontaneously, "It is God." Ask them, "Why has falsehood bewitched you?"

# 2763

We have sent them the truth and they, certainly, are liars.

# 2764

God has never given birth to a son and there is no other god besides Him. If there were, each god would have taken away his creatures and claimed superiority over the others. God is too exalted to be as they believe Him to be.

# 2765

He has the knowledge of all seen and unseen things. He is too exalted to be considered equal to anything else.

# 2766

Say, "Lord, if you will afflict them with punishment,

# 2767

exclude me from the unjust people".

# 2768

We have the Power to strike them with torment before your very eyes.

# 2769

Respond to the injustice (done to you) with the better deed. We know best what they attribute to God.

# 2770

Say, "Lord, I seek your protection against the strong temptations of the devils.

# 2771

I seek your protection should they approach me."

# 2772

When death approaches one of the unbelievers, he says, "Lord, send me back again

# 2773

so that perhaps I shall act righteously for the rest of my life." Although he will say so but his wish will never come true. After death they will be behind a barrier until the day of their resurrection.

# 2774

There will be no kindred relations nor any opportunity to ask about others or seek their assistance after the trumpet has sounded.

# 2775

If the side of ones good deeds weighs heavier on a scale, he will have everlasting happiness,

# 2776

but if it weighs less, one will be lost forever in hell.

# 2777

The fire will scorch their faces and they will be groaning therein in pain.

# 2778

(They will be told), "Were Our revelations not recited to you and did you not call them lies?"

# 2779

They will reply, "Lord, our hard-heartedness overcame us and we went astray.

# 2780

Lord, take us out of this and if we sin again, we shall certainly be unjust".

# 2781

He will say, "Be quiet and say nothing."

# 2782

There was a group of my servants among you who always prayed: Lord, forgive us and grant us mercy; You are the best of those who show mercy.

# 2783

"You mocked and laughed at them until you forgot all about Me.

# 2784

On this day I have given them their reward for their exercising patience and it is they who have triumphed."

# 2785

God will ask them, "How many years did you live in your graves?"

# 2786

They will reply. "We remained for about a day or part of it, but ask those who have kept count".

# 2787

God will say, "You have indeed remained there for a short time. Would that you knew it during your life time.

# 2788

Did you think that We had created you for a playful purpose and that you were not to return to Us?"

# 2789

God is the most exalted King and the Supreme Truth. He is the only God and the Lord of the Gracious Throne.

# 2790

One who worships things besides God has no proof of the authority of such things. God is certainly keeping the record of his deeds. The unbelievers will not have everlasting happiness.

# 2791

(Muhammad), say, "Lord, forgive me and grant me mercy; You are the best of the Merciful Ones.

# 2792

This is a chapter which We have revealed to you and made obligatory for you to follow its guidance. We have revealed clear verses in it so that perhaps you may take heed.

# 2793

Flog the fornicatress and the fornicator with a hundred lashes each. Let there be no reluctance in enforcing the laws of God, if you have faith in God and the Day of Judgment. Let it take place in the presence of a group of believers.

# 2794

No one should marry a fornicator except a fornicatress or a pagan woman. No one should marry a fornicatress except a fornicator or a pagan man. Such (marriage) is unlawful to the believers.

# 2795

Those who accuse married women of committing adultery - but are not able to prove their accusation by producing four witness - must be flogged eighty lashes. Never accept their testimony thereafter because they are sinful,

# 2796

except that of those who afterwards repent and reform themselves; God is All-forgiving and All-merciful.

# 2797

Those who accuse their spouses of committing adultery but have no witness except themselves, should testify four times saying, "God is my witness that I am telling the truth".

# 2798

They should say on the fifth time, "Let God's curse be upon me if I am a liar".

# 2799

The spouse will be acquitted of the punishment if she challenges his testimony by saying four times, "God is my witness that he is a liar".

# 2800

On the fifth time she should say, "Let the curse of God be upon me if what he says is true."

# 2801

Had it not been for God's favors and mercy upon you (your life would have been in chaos). God accepts repentance and He is All-wise.

# 2802

Those of you who have brought forward a false report (against Aisha) do not think that it will harm you. Rather it will be a benefit to you. Each one of you will face the result of his sin. The one among the group who was the chief instigator will face a great torment.

# 2803

Would that on your hearing this report, the believing men and woman among you had a favorable attitude towards it, and had said, "This report is clearly false".

# 2804

Would that they had brought four witness to testify to their report. Since they brought none, they are liars before God.

# 2805

Were it not for the favors and mercy of God upon you, in this world and in the life to come, a great torment would strike you for your involvement in this false report.

# 2806

Your tongues moved and your mouths spoke of something of which you had no knowledge. You thought it to be a trivial matter, while in the eyes of God it is blasphemy.

# 2807

Would that on hearing this report, you had said, "We have nothing to say about it. God forbid! It is a serious accusation."

# 2808

God advises you never to do such things again if you have any faith.

# 2809

God explains to you His revelations. He is All-knowing and All-wise.

# 2810

Those who like to publicize indecency among the believers will face painful torment in this world and in the life to come. God knows what you do not know.

# 2811

Were it not for the favor and mercy of God upon you (you would have faced painful punishment in this world and the life to come). God is Compassionate and Merciful.

# 2812

Believers, do not follow the footsteps of satan; whoever does so will be made by satan to commit indecency and sin. Were it not for the favor and mercy of God, none of you would ever have been purified. God purifies whomever He wants. God is All-hearing and All-knowing.

# 2813

The well-to-do and the rich among you should not fail to give to relatives, the destitute, and Emigrants for the cause of God. Be considerate and forgiving. Do you not want God to forgive you? God is All-forgiving and All-merciful.

# 2814

Those who slander the unaware but chaste and believing women (of committing unlawful carnal relations) are condemned in this life and in the life hereafter. They will suffer a great punishment

# 2815

on the day when their tongues, hands, and feet will testify to what they had done.

# 2816

On that day God will give them due recompense and they will know that God is the Supreme Judge.

# 2817

Indecent woman are for indecent men and indecent men are for indecent woman. Decent women are for decent men and decent men are for decent women. The decent people are innocent of what people allege. They will receive mercy and honorable sustenance.

# 2818

Believers, do not enter other's houses until you have asked permission and have greeted the people therein. This is best for you so that perhaps you may remember (God's guidance).

# 2819

If you do not find anyone therein, do not enter until you are given permission. If you are told to go away, do so; this is more decent of you. God knows all that you do.

# 2820

There is no harm for you to enter uninhabited houses where you have some goods. God knows whatever you reveal or hide.

# 2821

(Muhammad), tell the believing men to cast down their eyes and guard their carnal desires; this will make them more pure. God is certainly aware of what they do.

# 2822

Tell the believing woman to cast down their eyes, guard their chastity, and not to show off their beauty except what is permitted by the law. Let them cover their breasts with their veils. They must not show off their beauty to anyone other than their husbands, father, father-in-laws, sons, step-sons, brothers, sons of brothers and sisters, women of their kind, their slaves, immature male servants, or immature boys. They must not stamp their feet to show off their hidden ornaments. All of you believers, turn to God in repentance so that perhaps you will have everlasting happiness.

# 2823

Marry the single people among you and the righteous slaves and slave-girls. If you are poor, God will make you rich through His favor; He is Bountiful and All-knowing.

# 2824

Let those who cannot find someone to marry maintain chastity until God makes them rich through His favors. Let the slaves who want to buy their freedom have an agreement with you in writing if you find them to be virtuous. Give them money out of God's property which He has given to you. Do not force your girls into prostitution to make money if they want to be chaste. If they have been compelled to do so, God will be All-merciful and All-forgiving to them.

# 2825

We have revealed to you illustrious revelations, stories of the past generations, and good advice for the pious people.

# 2826

God is the light of the heavens and the earth. A metaphor for His light is a niche in which there is a lamp placed in a glass. The glass is like a shining star which is lit from a blessed olive tree that is neither eastern nor western. Its oil almost lights up even though it has not been touched by the fire. It is light upon light. God guides to His light whomever He wants. God uses various metaphors. He has the knowledge of all things.

# 2827

(This niche) is in the houses that God has declared to be highly respected and His Name be mentioned therein in glory in the morning and evening

# 2828

by people, who can neither be diverted by merchandise nor bargaining from worshipping God, saying their prayers and paying religious tax. They do these things, for they are afraid of the day when all hearts and eyes will undergo terrible unrest and crisis.

# 2829

(They worship Him) so that God will reward their best deeds and give them more through His favors. God gives sustenance to whomever He wants without account.

# 2830

The deeds of the unbelievers are like a mirage which a thirsty man thinks is water until he goes near and finds nothing. Instead he finds God who gives him his due recompense. God's reckoning is swift.

# 2831

Or it (the deeds of the unbelievers) are like the darkness of a deep, stormy sea with layers of giant waves, covered by dark clouds. It is darkness upon darkness whereby even if one stretches out his hands he can not see them. One can have no light unless God gives him light.

# 2832

Have you not considered that all that is between the heavens and the earth glorifies God and that the birds spread their wings in the air to glorify God? He knows everyone's prayers and praising; God has absolute knowledge of what they do.

# 2833

To God belongs the kingdom of the heavens and the earth, and to Him do all things return.

# 2834

Do you not see that God moves the clouds gently, brings them together, piles them up, and then you can see the rain coming from them. He sends down hailstones from the mountains in the sky. With them He strikes or protects from them whomever He wants. The lightening can almost take away the sight.

# 2835

God alternates the night and the day. In this there is a lesson for the people of understanding.

# 2836

God has created every living being from water: Some of them creep on their bellies; some walk on two feet and some of them walk on four legs. God creates whatever He wants. He has power over all things.

# 2837

We have revealed illustrious revelations. God guides to the right path whomever He wants.

# 2838

They say, "We have believed in God and the Messenger and we have obeyed them." Then a group of them turn away from their (belief). They are not believers.

# 2839

When they are called to God and His Messenger so that they will judge among them, suddenly, some of them turn away.

# 2840

If right was on their side, they would come quickly.

# 2841

Are their hearts sick? Do they have doubts or are they afraid that God and His Messenger may do injustice to them? In fact, they, themselves, are unjust.

# 2842

When the believers are called to God and His Messenger to be judged, their only words are, "We have listened and obeyed." They will have everlasting happiness.

# 2843

Those who obey God and His Messenger, who are humble before Him, and who have fear of Him will, certainly, be successful.

# 2844

They strongly swear by God that they would march to fight (for the cause of God) if you were to order them to. Tell them, "You do not need to swear; fighting for the cause of God is a virtuous deed and God is Well Aware of what you do".

# 2845

Say to them, "Obey God and His Messenger. If you turn away, the Messenger and the people will each be responsible for their own obligations. If you follow the Messenger, you will have the right guidance. The responsibility of the Messenger is only to preach."

# 2846

God has promised the righteously striving believers to appoint them as His deputies on earth, as He had appointed those who lived before. He will make the religion that He has chosen for them to stand supreme. He will replace their fear with peace and security so that they will worship God alone and consider no one equal to Him. Whoever becomes an unbeliever after this will be a sinful person.

# 2847

Be steadfast in prayer, pay the religious tax and obey the Messenger so that perhaps you will receive mercy.

# 2848

The unbelievers should not think that they can defeat God on earth. Their dwelling will be hell, the most terrible abode.

# 2849

Believers, your slaves and the immature people must ask your permission three times a day before entering your house: before the morning prayer, at noon time and after the late evening prayer; these are most private times. After your permission has been granted, there is no harm if they come into your presence from time to time. This is how God explains His revelations to you. God is All-knowing and All-wise.

# 2850

When your children become mature, they must ask your permission before entering your house, as the rest of the mature people do. Thus does God explain to you His revelations. God is All-knowing and All-wise.

# 2851

Elderly women who have no hope of getting married are allowed not to wear the kind of clothing that young woman must wear, as long as they do not show off their beauty. It is better for them if they maintain chastity. God is All-hearing and All-knowing.

# 2852

It is no sin for the blind, the lame, the sick ones, and yourselves to eat at your own homes, or the homes of your father, mothers, brothers, sisters, your paternal and maternal uncles, aunts, or at the homes of your friend, and the homes with which you are entrusted. It makes no difference whether you eat all together or one person at a time. When you enter a house, say the blessed greeting which God has instructed you to say. Thus does God explain to you His revelations so that perhaps you will understand.

# 2853

The true believers are those who have faith in God and His Messenger and when they are dealing with the Messenger in important matters, they do not leave without his permission. (Muhammad), those who ask your permission believe in God and His Messenger. When they ask your leave to attend to their affairs, you may give permission to anyone of them you choose and ask forgiveness for them from God. God is All-forgiving and All-merciful.

# 2854

Do not address the Messenger as you would call each other. God knows those who secretly walk away from you and hide themselves. Those who oppose the Messengers should beware, lest some trouble or a painful torment should befall them.

# 2855

The heavens and the earth, certainly, belong to God. He surely knows all about you in this life. On the day when you return to Him, He will tell you all about whatever you have done. God has the knowledge of all things.

# 2856

Blessed is He who has revealed the criteria (for discerning truth from falsehood) to His servant so that He could warn mankind.

# 2857

To Him belongs the kingdom of the heavens and the earth. He has not begotten any sons, nor does He have any partner in His kingdom. He has created all things with precisely accurate planning.

# 2858

Yet they have chosen for themselves other deities besides Him, who do not create anything but rather are themselves created, who have no power over their own benefits, or trouble, and who have no control over life, death, and resurrection.

# 2859

The unbelievers say, "This (Quran) is no more than a slanderous statement which he (Muhammad), with the help of some other people, has falsely invented." Certainly, this statement is unjust and sinful.

# 2860

They have also said, "It, (the Quran), is only ancient legends, which were written down while they were dictated to him in the mornings and the evenings".

# 2861

(Muhammad), tell them, "The One who knows all the secrets of the heavens and the earth has revealed it; He is All-forgiving and All-merciful."

# 2862

They say, "Why does this Messenger eat food, and walk in the streets? Why has not an angel been sent to him so that they could preach the message together?

# 2863

Why has a treasure not been laid out for him or a garden from which he could eat been given to him." The unjust ones say, "You are merely following a bewitched person".

# 2864

Look at their various views about you! They have gone astray and are not able to find the right path.

# 2865

Blessed is He who could give you palaces and gardens wherein streams would flow, far better than what they want you to have.

# 2866

They deny the Hour of Doom so We have prepared for them a burning fire.

# 2867

Even if they were to see \[this fire\] from a distant place, they would only listen to its raging and roaring.

# 2868

When they are thrown, bound, into a narrow place therein, then only will they wish for their death.

# 2869

They will be told, "Do not pray to die only once but pray to die many times."

# 2870

(Muhammad), ask them, "Is what you want better or the eternal garden promised to the pious ones as their reward and dwelling?

# 2871

Therein they will eternally have whatever they want. This is a binding promise from your Lord."

# 2872

On the day when the unbelievers and whatever they had been worshipping besides God will be resurrected, He will ask the idols, "Did you mislead My servants or did they themselves go astray from the right path?"

# 2873

They will reply, "Lord, You alone deserve all glory! We were not supposed to choose any guardian other than you. Since you have been benevolent to these people and their fathers, they forgot Your guidance and, thus, became subject to perdition."

# 2874

God will say (to the idolaters), "Your idols have rejected your faith. You cannot avoid their rejection nor can you find any help. Anyone of you who commits injustice will be made to suffer a great torment."

# 2875

All the Messengerss whom We sent before, certainly, ate food and walked through the streets. We have made some of you (people) a trial for the others. Would you then exercise patience? Your Lord is All-aware.

# 2876

Those who have no desire to meet Us have said, "Would that the angels had been sent to us or that we could see our Lord." They are really filled with pride and have committed the greatest and worst kind of rebellion and hostility.

# 2877

On the day when the criminals see the angels, there will, certainly, be no rejoicing for them. Rather, they will plead to the angels, "Please keep away from us (do not drive us into hell)."

# 2878

We shall call their deeds into Our presence and scatter them into the air as dust (turn them devoid of all virtue).

# 2879

The dwellers of Paradise on that day will have the best residence and resting place.

# 2880

On that day the sky will be crystal blue, clear of clouds. The angels will descend in groups

# 2881

and the Absolute kingdom will belong to the Beneficent God.

# 2882

It will be a hard day for the unbelievers. It will be a day when the unjust will bite their fingers, (regretfully) saying, "Would that we had followed the path of the Messengers.

# 2883

Woe to us! Would that we had not been friends with so and so.

# 2884

He led me away from the true guidance after it had come to us. Satan is a traitor to people."

# 2885

The Messengers will say, "Lord, my people had abandoned this Quran."

# 2886

Thus, from the sinful people We made enemies for every Prophet. Your Lord is a Sufficient Guide and Helper.

# 2887

The unbelievers have said, "Why was the whole Quran not revealed to him at once?" We have revealed it to you in gradual steps to strengthen your hearts and give you explanations.

# 2888

We will support you with the Truth and the best interpretation whenever the infidels argue against you.

# 2889

Those who will be driven headlong into hell will have a terrible dwelling; they have certainly gone astray.

# 2890

We gave the Book to Moses and made his brother Aaron his Minister.

# 2891

We told them, "Both of you go to the people who have rejected Our revelations." We completely destroyed these unbelievers.

# 2892

We drowned the people of Noah because of their rejection of the Messengers and made them evidence of the Truth for mankind. We have prepared a painful torment for the unjust ones.

# 2893

To each of the tribes of Ad, Thamud, the settlers around the well and many generations in between

# 2894

We gave guidance and drove each to destruction.

# 2895

Our Messengers came into the town which was struck by a fatal rain. Did they (unbelievers), not see what had happened to this town? In fact, they had no faith in the Resurrection.

# 2896

(Muhammad), when they see you, they will only mock you and say, "Has God really sent him as a Messengers?

# 2897

Had we not been steadfast he would almost have led us astray from our gods." On facing torment they will soon know who had really gone astray.

# 2898

How can you be the guardian of those who have chosen their own desires as their Lord?

# 2899

Do you think that most of them listen and understand? They are like cattle or even more, straying and confused.

# 2900

Have you not seen that your Lord increases the shadow. Had He wanted He would have made it stationary\], and has made the sun their guide.

# 2901

Then He reduces it in gradual steps.

# 2902

It is He who has made the night as a covering for you, sleep as a rest for you, and the day for you to rise again.

# 2903

It is He who sends the winds to you with the glad news of His mercy and who sends purifying rain from the sky

# 2904

to revive the barren land and provide water for many creatures, cattle, and people.

# 2905

We send them rain from time to time so that they may take heed. Many people have responded, but ungratefully.

# 2906

Had We wanted We could have sent a Prophet to every town.

# 2907

Do not yield to the unbelievers but launch a great campaign against them with the help of the Quran.

# 2908

It is He who has joined the two seas; one palatable and sweet, the other bitterly salty and has established a barrier between them as a partition.

# 2909

It is He who has created the human being from water to have relationships of both lineage and wedlock. Your Lord has all power.

# 2910

They worship besides God things that can neither benefit nor harm them. The unbelievers are defiant against their Lord.

# 2911

We have sent you for no other reason but to be a bearer of glad news and warning.

# 2912

Tell them, "I ask no recompense for my preaching to you, except the fact that whoever wants should choose the way of God."

# 2913

Also trust in the Living One who never dies and glorify Him with His praise. He has sufficient knowledge of the sins of His servants.

# 2914

It is He who created the heavens and the earth and all that is between them in six days and then He established His domination over the Throne. He is the Beneficent God. Refer to Him as the final authority.

# 2915

When they are told to prostrate themselves before the Beneficent God, they say, "Who is the Beneficent God? Why should we prostrate ourselves before the one whom you have commanded us to?" This only increases their rebelliousness.

# 2916

Blessed is He who has established constellations in the sky and made therein a lamp and a shining moon.

# 2917

It is He who has made the night and the day, one proceeding the other, for whoever wants to take heed or give thanks.

# 2918

(Among) the servants of the Beneficent God are those who walk gently on the earth and when addressed by the ignorant ones, their only response is, "Peace be with you."

# 2919

They are those who spend the night worshipping their Lord, prostrating, and standing,

# 2920

who pray, "Lord, protect us from the torment of hell; it is a great loss.

# 2921

It is a terrible abode and an evil station,"

# 2922

who in their spending are neither extravagant nor stingy but maintain moderation,

# 2923

who do not worship idols besides God, nor without a just cause murder a soul to whom God has granted amnesty, who do not commit fornication, for those who do so have committed a sin

# 2924

and on the Day of Judgment their torment will be double. They will suffer forever in disgrace.

# 2925

But only those who repent and believe and act righteously will have their sins replaced by virtue; God is All-forgiving and All-merciful.

# 2926

Those who repent and act righteously have truly returned to God,

# 2927

those who do not testify falsely and when they come across something impious, pass it by nobly,

# 2928

who, when reminded of the revelations of their Lord, do not try to ignore them as though deaf and blind. Rather, they try to understand and think about them.

# 2929

They pray, "Lord, let our spouses and children be the delight of our eyes and ourselves examples for the pious ones."

# 2930

They will all receive Paradise as their reward for their forbearance and patience, where they will be greeted with, "Peace be with you."

# 2931

They will live therein forever, the best abode and place of rest.

# 2932

(Muhammad), say (to the disbeliever) "It does not matter to my Lord whether you worship Him or not. You have rejected His guidance and your punishment is inevitable."

# 2933

Ta. Sin. Mim.

# 2934

These are the verses of the illustrious Book.

# 2935

You will perhaps kill yourself with anguish because they are not accepting the faith.

# 2936

Had We wanted, We would have sent them a miracle from the sky to make their heads hang down in submission.

# 2937

Whenever a new message comes to them from the Beneficent God, they turn away from it.

# 2938

They have called (our revelation) lies. They will soon learn the consequences of what they mocked.

# 2939

Have they not seen the earth in which We have made gracious plants grow?

# 2940

In this there is, certainly, evidence (of the Truth). But most of them have no faith.

# 2941

Your Lord is the Majestic and the All-merciful.

# 2942

When Your Lord told Moses to go to the unjust people of the Pharaoh

# 2943

and ask them, "Why do you not fear God?"

# 2944

He replied, "Lord, I am afraid that they will call me a liar.

# 2945

I feel nervous and my tongue is not fluent, so send Aaron with me.

# 2946

They have charged me \[with a crime\] for which I am afraid they will kill me."

# 2947

The Lord said, "Have no fear, both of you go with Our miracles. We shall closely listen to you."

# 2948

They came to the Pharaoh and said, "We are the Messengerss of the Lord of the Universe.

# 2949

Send the Israelites with us".

# 2950

The Pharaoh said, "Did we not bring you up in our home as an infant and did you not live with us for many years

# 2951

and you did the deed which you did. You are certainly ungrateful."

# 2952

Moses said, "I did do it and I made a mistake.

# 2953

Then I ran away from you in fear, but my Lord granted me the law and has appointed me as a Messenger.

# 2954

And this is the favor with which you oblige me: You have made the Israelites your slaves.

# 2955

The Pharaoh asked, "Who is the Lord of the Universe?"

# 2956

Moses replied, "The Lord of the heavens and the earth and all that is between them, if you want to be certain".

# 2957

The Pharaoh said to the people around him, "Did you hear that?"

# 2958

Moses continued, "He is the Lord and the Lord of your forefathers."

# 2959

The Pharaoh said, "The Messengers who has been sent to you is certainly insane".

# 2960

Moses continued, "He is the Lord of the East and West and all that is between them, if only you would think".

# 2961

Pharaoh said, "If you put forward any god other than me, I will surely put you in prison".

# 2962

Moses asked, "What if I were to bring you clear proof (of the existence of God)?"

# 2963

The Pharaoh replied, "Bring it, if you are telling the truth."

# 2964

Moses threw his staff and suddenly it became a serpent.

# 2965

Then he uncovered his hand and it was sheer white to the onlookers.

# 2966

The Pharaoh said to the people around him, "He is certainly a skillful magician.

# 2967

He wants to expel you from your land through his magic. What is your opinion?"

# 2968

They said, "Hold him and his brother off for a while

# 2969

and summon every skillful magician from all the cities."

# 2970

So all the magicians gathered together

# 2971

at the appointed time

# 2972

and the people were asked, "Will you all be there so that we may follow the magicians if they become victorious?"

# 2973

When the magicians came, they asked the Pharaoh, "Will there be any reward for us if we win?"

# 2974

He replied, "You will then be my closest associates".

# 2975

(Moses) asked the magicians, "Cast down what you want to".

# 2976

So they cast down their ropes and staffs saying, "By the honor of the Pharaoh we shall certainly become the winners".

# 2977

Then Moses cast down his staff and suddenly it swallowed up what they had falsely invented.

# 2978

The magicians fell down in adoration

# 2979

saying, "We believe in the Lord of the Universe

# 2980

and the Lord of Moses and Aaron."

# 2981

The Pharaoh said, "You believed without my permission? He seems to be your chief who has taught you magic. But you will soon know (the result of what you have done).

# 2982

I shall certainly cut off your hands and feet on opposite sides and crucify you all together."

# 2983

They said, "It does not matter. We shall be returning to our Lord.

# 2984

We hope that our Lord will forgive us for our sins; we were not believers at first."

# 2985

We sent a revelation to Moses telling him to leave with our servants during the night; they would be pursued (by the Pharaoh).

# 2986

The Pharaoh sent word to all the cities saying,

# 2987

"There is a small group of people

# 2988

who have enraged us greatly.

# 2989

We are warning all of you about them."

# 2990

We deprived them (the unbelievers) of gardens, springs,

# 2991

treasures, and graceful dwellings.

# 2992

Thus we let the Israelites inherit them all.

# 2993

The people of the Pharaoh pursued them at sunrise.

# 2994

When the two groups came close to each other, the companions of Moses said, "We will be caught".

# 2995

Moses said, "Certainly not. My Lord is with me and He will certainly guide me."

# 2996

We sent a revelation to Moses saying, "Strike the sea with your staff." The sea was rent asunder and each side stood high up like a huge mountain.

# 2997

Then We brought the two parties closer.

# 2998

We saved Moses and all the people with him

# 2999

and drowned the other party.

# 3000

In this there was certainly evidence (of the Truth), but most of them did not have any faith.

# 3001

Your Lord is certainly Majestic and All-merciful.

# 3002

Tell them the story of Abraham,

# 3003

when he asked his father and others, "What do you worship?"

# 3004

They replied, "We worship idols and shall continue to worship them".

# 3005

He asked them, "Can the idols hear you when you pray to them

# 3006

or can they benefit or harm you?"

# 3007

They said, "No, but our fathers worshipped them."

# 3008

(Abraham) said, "Do you know that what you worship and what your grandfathers worshipped

# 3009

are my enemies? Not so the Lord of the Universe.

# 3010

He created me and He will guide me.

# 3011

It is He who gives me food and drink

# 3012

and heals me when I am sick.

# 3013

He will cause me to die and will bring me back to life.

# 3014

It is He whom I expect to forgive my sins on the Day of Judgment.

# 3015

Lord, grant me authority. Join me to the righteous ones.

# 3016

Make my words come true in the future.

# 3017

Make me inherit the bountiful Paradise.

# 3018

Forgive my father. He has gone astray.

# 3019

Do not betray me

# 3020

on the Day of Judgment when neither wealth nor children will be of any benefit

# 3021

except what is done in obedience to God with a submissive heart.

# 3022

On the Day of Judgment Paradise will be brought near

# 3023

the pious and hell will be left open for the rebellious ones

# 3024

who will be asked, "What did you worship

# 3025

besides God? Will the idols help you? Can they help themselves?"

# 3026

The idol worshippers, the idols, the rebellious ones,

# 3027

and the army of satan will all be thrown headlong into hell.

# 3028

"Quarrelling therein with each other,

# 3029

they will say, "By God, we were in clear error

# 3030

when we considered you equal to the Lord of the Universe.

# 3031

Only the sinful ones made us go astray.

# 3032

We have no one to intercede for us before God

# 3033

nor a loving friend.

# 3034

Would that we could have a chance to live again so that we might become believers."

# 3035

In this there is evidence (of the truth), but many of them do not have any faith.

# 3036

Your Lord is certainly Majestic and All-merciful.

# 3037

The people of Noah rejected the Messengerss.

# 3038

span class="col">Their brother Noah asked them, "Why do you not fear God?

# 3039

I am a trustworthy Messengers sent to you.

# 3040

Have fear of God and obey me.

# 3041

I ask no payment from you for my preaching. The Lord of the Universe will give me my reward.

# 3042

Have fear of God and obey me."

# 3043

They said, "Should we believe in you when no one has followed you except the lowest ones".

# 3044

(Noah) said, "I have no knowledge of their deeds.

# 3045

If only you would realize, their account is with my Lord.

# 3046

I do not drive away the believers.

# 3047

I am only a Prophet.

# 3048

They said, "Noah, if you do not desist, you will, certainly, be stoned to death."

# 3049

Then Noah said, "Lord, my people have rejected me.

# 3050

Judge among us and save me and the believers with me".

# 3051

We saved him and those who were with him in a fully laden Ark,

# 3052

and drowned the others.

# 3053

In this there is evidence (of the truth) but most of them do not have any faith.

# 3054

Your Lord is Majestic and All-merciful.

# 3055

The tribe of Ad rejected the Messengers.

# 3056

Their brother Hud asked them, "Why do you not have fear of God?

# 3057

I am a trustworthy Messengers sent to you.

# 3058

Have fear of God and obey me.

# 3059

I do not ask for any payment for my preaching. I shall receive my reward from the Lord of the Universe.

# 3060

"Do you build useless monuments on every mountain

# 3061

and raise strong mansions as if you were to live forever?

# 3062

When you attack, you attack as tyrants do.

# 3063

Have fear of God and obey me.

# 3064

Have fear of the One who has bestowed upon you all that you know.

# 3065

He has given you cattle, children,

# 3066

gardens, and springs.

# 3067

I am afraid that you will suffer the torment of the Day of Judgment."

# 3068

They said, "Whether you preach to us or not,

# 3069

your preaching is nothing but ancient legends and we shall not face any torment".

# 3070

They rejected him and We destroyed them.

# 3071

In this there is evidence (of the Truth), yet most of them do not have any faith.

# 3072

Your Lord is Majestic and All-merciful.

# 3073

The tribe of Thamud rejected the Messengers.

# 3074

Their brother Salih asked them, "Why do you not fear God?

# 3075

I am a trustworthy Messengers sent to you.

# 3076

Have fear of God and obey me.

# 3077

I do not ask for any payment for my preaching. I shall receive my reward from the Lord of the Universe.

# 3078

"Do you think that you will remain here peacefully forever

# 3079

amidst the gardens, springs,

# 3080

farms, and palm-trees in thick groves,

# 3081

carving comfortable houses out of the mountains?

# 3082

Have fear of God and obey me.

# 3083

Do not obey the orders of the transgressors

# 3084

who spread evil in the land with no reform."

# 3085

They said, "You are only bewitched and insane.

# 3086

You are a mere mortal like us. Show us a miracle if you are telling the Truth".

# 3087

He said, "This is a she-camel. She will have her share of water as you have your share, each on a certain day.

# 3088

Do not cause her to suffer lest you become subject to the torment of the great day (of Judgment)."

# 3089

They slew the she-camel, but later became regretful

# 3090

and torment struck them. In this there is evidence of the Truth, yet many people do not have any faith.

# 3091

Your Lord is Majestic and All-merciful.

# 3092

The people of Lot rejected the Messengers.

# 3093

Their brother Lot asked them, "Why do you not have fear of God?

# 3094

I am a trustworthy Messengers.

# 3095

Have fear of God and obey me.

# 3096

I do not ask any payment for my preaching. I shall receive my reward from the Lord of the Universe.

# 3097

Do you, in the world, want to have carnal relations with males

# 3098

instead of your wives, whom your Lord has created specially for you? You are a transgressing people."

# 3099

They said, "Lot, if you do not give up preaching, you will certainly be expelled (from this town)".

# 3100

He said, "I certainly hate what you practice.

# 3101

Lord, save me and my family from their deeds."

# 3102

We saved him and all of his family

# 3103

except an old woman who remained behind.

# 3104

We destroyed the others

# 3105

by pouring upon them a terrible shower of rain. How evil was the rain for those who had been warned!

# 3106

In this there is an evidence of the Truth, but many of them did not have any faith.

# 3107

Your Lord is Majestic and All-merciful.

# 3108

The dwellers of the forest also rejected the Messengers.

# 3109

Shu'ayb asked them, "Why do you not have fear of God?

# 3110

I am a trustworthy Messengers.

# 3111

Have fear of God and obey me.

# 3112

I do not ask any payment for my preaching. I shall receive my reward from the Lord of the Universe.

# 3113

"Maintain just measure in your business and do not cause loss to others.

# 3114

Weigh your goods with proper balance

# 3115

and do not defraud people in their property or spread evil in the land.

# 3116

Have fear of the One who has created you and the generations that lived before you."

# 3117

They said, "You are no more than a bewitched and insane man

# 3118

and a mere mortal like us. We think you are a liar.

# 3119

Let a part of the sky fall on us if what you say is true".

# 3120

He said, "My Lord knows all that you do."

# 3121

They rejected him and then the torment of the gloomy day struck them. It was certainly a great torment.

# 3122

In this there is an evidence of the Truth, but many of them did not have any faith.

# 3123

Your Lord is Majestic and All-merciful.

# 3124

This, (Quran), is certainly the revelation from the Lord of the Universe.

# 3125

It has been revealed through the trustworthy Spirit

# 3126

to your heart, so that you will warn (the people of the dangers of disobeying God).

# 3127

It has been revealed in plain Arabic.

# 3128

Its news was also mentioned in the ancient Books.

# 3129

Is not the fact (that the Israelite scholars already knew about the Quran through their Book) sufficient evidence for the pagans of the truthfulness (of the Quran)?

# 3130

Had We revealed it to a non-Arab

# 3131

who would have read it to them, they (pagans) would not have believed in it.

# 3132

Thus it passes through the hearts of the criminals.

# 3133

They will not believe in it until they suffer the painful torment.

# 3134

The torment will strike them suddenly without their knowledge.

# 3135

They will say, "Can we be granted any respite?"

# 3136

Do they want to hasten Our torment?

# 3137

Do you not see that even if We give them respite for years

# 3138

and then Our torment will strike them,

# 3139

none of their luxuries will be able to save them from the torment?

# 3140

We never destroyed any town without first sending to them warning and guidance.

# 3141

We have never been unjust to anyone.

# 3142

The satans have not revealed the Quran;

# 3143

they are not supposed to do so. Nor do have they the ability for such a task.

# 3144

The satans are barred from listening to anything from the heavens.

# 3145

(Muhammad), do not worship anything besides God lest you suffer the punishment.

# 3146

Warn your close relatives

# 3147

and be kind to your believing followers.

# 3148

If they disobey you, tell them, "I condemn your disobedient deeds".

# 3149

Have trust in the Majestic and All-merciful God,

# 3150

who can see whether you stand up

# 3151

or move during your prostration with the worshippers.

# 3152

He is All-hearing and All-knowing."

# 3153

Should I tell you to whom the satans come?

# 3154

They come to every sinful liar.

# 3155

The satans try to listen to the heavens but many of them are liars.

# 3156

Only the erring people follow the poets.

# 3157

Have you not seen them wandering and bewildered in every valley

# 3158

and preaching what they themselves never practice.

# 3159

The righteously striving believers among them who remember God very often and use their talent to seek help after they have been wronged are the exceptional. The unjust will soon know how terrible their end will be.

# 3160

Ta. Sin. These are the verses of the Quran and of the illustrious Book

# 3161

They are glad news and guidance for the believers

# 3162

who are steadfast in prayer, who pay the religious tax, and who have strong faith in the life hereafter.

# 3163

We have made the deeds of those who do not believe in the life to come, attractive to them and they wander about blindly.

# 3164

They will suffer the worst kind of torment and will be lost in the life to come.

# 3165

(Muhammad), you have certainly received the Quran from the All-wise and All-knowing One.

# 3166

Moses said to his family, "I have seen some fire. I shall bring you some news about it or some fire so that you can warmyourselves".

# 3167

When he approached the fire, he was told, "Blessed is the one in the fire and those around it. All glory belongs to God, the Lord of the Universe.

# 3168

Moses, I am God, the Majestic and All-wise.

# 3169

Throw down your staff." When Moses saw his staff on the ground moving like a living creature, he stepped back and did not come forward again. The Lord said,"Moses, do not be afraid. Messengers do not become afraid in My presence".

# 3170

Only the unjust become afraid in My presence. Even to these people who replace their bad deeds by good ones, I am All-forgiving and All-merciful.

# 3171

Put your hand into your pocket. It will come out sheer white but unharmed. This is one of the nine miracles which shall be showing to the Pharaoh and his people; they are truly wicked men."

# 3172

When Our miracles were visibly shown to them, they said, "It is plain magic".

# 3173

They rejected the evidence because of their arrogance and injustice, although their souls knew it to be true. Think how terrible the end of the sinful ones was!

# 3174

We gave knowledge to David and Soloman. They said, "It is only God who deserves all praise. He has exalted us above many of His believing servants."

# 3175

Solomon became the heir to David. He said, "People, we have been taught the language of the birds and have been granted a share of everything. This indeed is a manifest favor (from God)".

# 3176

Soloman's army, consisting of human beings, jinn, and birds were gathered together in his presence in ranks.

# 3177

When they arrived in the valley of the ants, one ant said to the others, "Enter your dwellings lest you be carelessly crushed by Soloman and his army."

# 3178

(Solomon) smiled at the ant's remarks and said, "Lord, inspire me to thank you for Your favors to me and my parents and to act righteously so as to please you. Admit me, by your mercy into the company of Your righteous servants".

# 3179

(Solomon) inspected the birds and said, "How is it that I cannot see the hoopoe. Is he absent?

# 3180

I shall certainly punish him severely or slaughter him unless he has a good reason for his absence."

# 3181

Not long after the hoopoe came forward and said, "I have information which you do not have. I have come from the land of Sheba with a true report.

# 3182

I found a woman ruling the people there and she possessed something of (almost) everything and a great throne.

# 3183

I found her and her people prostrating before the sun instead of God. Satan has made their deeds attractive to them. He has kept them away from the right path and they have no guidance.

# 3184

(Satan has done this) so that they will not worship God who brings forth whatever is hidden in the heavens and the earth and knows whatever you conceal or reveal.

# 3185

God is the only Lord and master of the Great Throne."

# 3186

Solomon said, "We shall see whether you are truthful or a liar.

# 3187

Take this letter of mine and deliver it to them, then return and see what their reply will be."

# 3188

(The Queen of Sheba) said to her officials, "A gracious letter has been dropped before me.

# 3189

It reads, 'From Soloman. In the Name of God, the Beneficent and the Merciful.

# 3190

Do not consider yourselves superior to me but come to me as Muslims (in submission)".

# 3191

She said, "My officials, what are your views on this matter? I will not decide until I have your views.

# 3192

They replied, "We have great power and valor. You are the commander, so decide as you like".

# 3193

She said, "When Kings enter a town they destroy it and disrespect its honorable people. That is what they will do, too.

# 3194

I will send a gift and we shall see what response the Messengers will bring."

# 3195

When her Messengers came to Soloman, he said, "Have you brought me wealth? What God has given to me is far better than what He has given to you, but you are happy with your gifts.

# 3196

Go back to your people and we shall soon come there with an army which they will not be able to face. We shall drive them from their town, humble, and disgraced."

# 3197

Solomon asked his people, "Who among you can bring her throne before (she, the queen of Sheba) comes to me submissively?"

# 3198

A monstrous jinn said, "I can bring it before you even stand up. I am powerful and trustworthy".

# 3199

The one who had knowledge from the Book said, "I can bring it to you before you even blink your eye." When Solomon saw the throne placed before him, he said, "This is a favor from my Lord by which He wants to test whether I am grateful or ungrateful. Whoever thanks God does so for his own good. Whoever is ungrateful to God should know that my Lord is Self-Sufficient and Benevolent."

# 3200

Then he said, "Make a few changes to her throne and let us see whether she will recognize it or not."

# 3201

When she came she was asked, "Is your throne like this?" She replied, "It seems that this is it. We had received the knowledge before this and were submissive (to Solomon's power)".

# 3202

Her idols prevented her from believing in God and she was an infidel.

# 3203

She was told to enter the palace. When she saw it, she thought that it was a pool and raised her clothe up to her legs. Solomon said, "This is a palace constructed with glass." She said, "My Lord, indeed I have wronged myself and I submit myself with Solomon to the will of God, the Lord of the Universe."

# 3204

We sent to the tribe of Thamud their brother Salih so that they would worship God, but they became two quarrelling groups.

# 3205

Salih said, "My people, why do you commit sins so quickly before doing good? Would that you ask forgiveness from God so that perhaps He will have mercy upon you."

# 3206

They said, "We have an ill omen about you and your followers." Salih replied, God has made your ill fortune await you. You are a people on trial."

# 3207

There were nine tribes in the city spreading evil without any reform in the land.

# 3208

They said, "Let us swear by God to do away with him and his family during the night then tell his guardian that we did not see how he and his family had been destroyed, and we shall be telling the truth."

# 3209

They plotted and We planned without their knowledge. Consider the result of their plot.

# 3210

We destroyed them and their people altogether.

# 3211

Those are their empty houses which We ruined because of their injustice. In this there is evidence (of the truth) for the people of knowledge.

# 3212

We saved the faithful God-fearing believers.

# 3213

Lot asked his people, "Do you understandably commit indecency?

# 3214

Do you have carnal relations with men rather than women? You are ignorant people".

# 3215

His people had no answer but to say, "Expel Lot and his family from the town for they want to be pure."

# 3216

We saved (Lot) and his family except his wife who was destined to remain behind.

# 3217

We sent to them a terrible rainstorm. How horrible was the rain for the people who had already received warning.

# 3218

(Muhammad), say, "It is only God who deserves all praise. Peace be upon His chosen servants. Which is better God or the idols?

# 3219

"(Are the idols worthier or) the One who has created the heavens and the earth, who has sent water from the sky for you, who has established delightful gardens and you could not even plant one tree? Is there any Lord besides God? In fact, the unbelievers are the ones who deviate from the right path.

# 3220

"(Are the idols worthier or) the One who has made the earth a resting place, the rivers flow from its valleys, the mountains as anchors and a barrier between the two seas? Is there any lord besides God? In fact, most people do not know.

# 3221

"(Are the idols worthier or) the One who answers the prayers of the distressed ones, removes their hardship, and makes you the successors in the land? Is there any lord besides God? In fact, you take very little heed.

# 3222

"(Are the idols worthier or) the One who guides you in the darkness of the land and sea and sends the winds bearing the glad news of His mercy? Is there any lord besides God? God is too exalted to be considered equal to anything else.

# 3223

"(Are the idols worthier or) the One who began the creation and who will turn it back, who gives you sustenance from the heavens and the earth? Is there any lord besides God? Say, "Bring your proof if what you say is true."

# 3224

(Muhammad) say, "No one in the heavens or the earth knows the unseen except God, and no one knows when they will be resurrected.

# 3225

Their knowledge of the next life is no more than doubts. In fact, they are blind about it.

# 3226

The unbelievers have said, "Shall we and our fathers be brought out of the graves after we become dust?

# 3227

It was promised to us and to our fathers before us. It is only ancient legends."

# 3228

Say, "Travel through the land and see how terrible was the end of the criminal ones".

# 3229

(Muhammad), do not be grieved (about their disbelief) nor distressed about their evil plans against you.

# 3230

They ask, "When the Day of Judgment will come, if it is true at all?"

# 3231

Say, "Perhaps some of the things which you wish to experience immediately are very close to you."

# 3232

Your Lord has many favors for mankind but most of them are ungrateful.

# 3233

Your Lord certainly knows whatever their hearts conceal or reveal.

# 3234

All the secrets in heavens and earth are recorded in the illustrious Book.

# 3235

This Quran tells the Israelites most of the matters about which they had disputes among themselves.

# 3236

It is a guide and mercy for the believers.

# 3237

Your Lord will judge among them according to His own decree. He is Majestic and All-Knowing.

# 3238

Trust in God for you follow the manifest truth.

# 3239

You cannot make the dead listen and the deaf are unable to hear calls. Thus, they turn back on their heels.

# 3240

You cannot guide the straying blind ones. You can only make hear those who believe in Our revelations submissively.

# 3241

When the word about them comes true We shall make a creature appear to them on earth who will tell them that people had no faith in Our revelations.

# 3242

On the day when We resurrect from every nation a group from among those who had rejected Our revelations, they will be kept confined in ranks.

# 3243

When they will be brought into the presence of God, He will ask them, "Did you reject My revelations without fully understanding them. What did you know about them if you had any knowledge at all?

# 3244

They will become subject to punishment because of their injustice. Thus, they will not speak.

# 3245

Have they not seen that We have created the night for them to rest and the day for them to see. In this there is evidence for the believing people.

# 3246

Everyone in the heavens and earth will be terrified on the day when the trumpet will be sounded except those whom God will save. Everyone will humbly come into the presence of God.

# 3247

You think the mountains are solid. In fact, they move like clouds. It is God's technique which has established everything perfectly. He is well Aware of what you do.

# 3248

Whoever does a good deed will receive a better reward than what he has done. He will be secure from the terror of the Day of Judgment.

# 3249

Those who commit evil will be thrown headlong into hell fire. (It will be said to them) can you expect any recompense other than what you deserve for your deeds?

# 3250

I am commanded to worship the Lord of this town which He has made sacred. To Him belong all things. I am commanded to be a Muslim

# 3251

and recite the Quran. Whoever seeks guidance will find it for his own soul. Say to whoever goes astray, "I am only a warner".

# 3252

Say, "It is only He who deserves all praise. He will soon show you His signs and you will recognize them. Your Lord is not unaware of what you do.

# 3253

Ta. Sin. Mim.

# 3254

These are the verses of the illustrious Book.

# 3255

We recite to you some of the story of Moses and the Pharaoh for a genuine purpose, and for the benefit of the believing people.

# 3256

The Pharaoh dominated the land and divided its inhabitants into different groups, suppressing one group by killing their sons and keeping their women alive. He was certainly an evil-doer.

# 3257

But We have decided to grant a favor to the suppressed ones by appointing them leaders and heirs of the land,

# 3258

give them power in the land and make the Pharaoh, Haman (his Minister), and their armies to experience from their victims what they feared most.

# 3259

We inspired Moses' mother saying, "Breast-feed your son. When you become afraid for his life, throw him into the sea. Do not be afraid or grieved for We shall return him to you and make him a Messenger."

# 3260

The people of the Pharaoh picked him up (without realizing) that he would become their enemy and a source of their sorrow. The Pharaoh, Haman, and their army were sinful people.

# 3261

The Pharaoh's wife said, "He, (Moses), is the delight of our eyes. Do not kill him. Perhaps he will benefit us or we may adopt him." They were unaware of the future.

# 3262

The heart of Moses' mother was relieved and confident. But she would almost have made the whole matter public had We not strengthened her heart with faith.

# 3263

She told Moses' sister to follow her brother. His sister watched him from one side and the people of the Pharaoh did not notice her presence.

# 3264

We had decreed that the infant must not be breast-fed by any nurse besides his mother. His sister said to the people of the Pharaoh, "May I show you a family who can nurse him for you with kindness?"

# 3265

Thus did We return Moses to his mother that We would delight her eyes, relieve her sorrows, and let her know that the promise of God was true, but many people do not know.

# 3266

When he become matured and grow to manhood, We granted him wisdom and knowledge. Thus do We reward the righteous ones.

# 3267

He entered the city without the knowledge of its inhabitants and found two men fighting each other. One was his follower and the other his enemy. His follower asked him for help. Moses struck his enemy to death, but later said, "It was the work of satan; he is the sworn enemy of the human being and wants to mislead him".

# 3268

(Moses) said, "Lord, I have wronged myself. Forgive me!" The Lord forgave him; He is All-forgiving and All-merciful.

# 3269

He said, "Lord, in appreciation for Your favor to me I shall never support the criminals".

# 3270

He remained in the city but very afraid and cautious. Suddenly the person who asked him for help the previous day asked him for help again. Moses said, "You are certainly a mischievous person".

# 3271

When Moses was about to attack their enemy, he said, "Moses, do you want to kill me as you slew a soul the other day? Do you want to become a tyrant in the land, not a reformer?"

# 3272

A man came running from the farthest part of the city saying, "Moses, people are planning to kill you. I sincerely advise you to leave the city.

# 3273

So he left the city afraid and cautious, saying, "Lord, protect me against the unjust people".

# 3274

When he started his journey to Midian he said, "Perhaps my Lord will show me the right path."

# 3275

When he arrived at the well of Midian, he found some people watering (their sheep) and two women keeping the sheep away from the others. He asked the two women, "What is the matter with you?" They replied, "We cannot water our sheep until all the shepherds have driven away their flocks. Our father is an old man".

# 3276

Moses watered their flocks and then sought shelter under a shadow praying, "Lord, I need the means to preserve (the power) that You have granted me."

# 3277

One of the women, walking bashfully, came to Moses and said, "My father calls you and wants to pay you for your watering our flocks." When Moses came to the woman's father and told him his whole story, he said, "Do not be afraid. Now you are secure from the unjust people."

# 3278

One of the women said to her father, "Father, hire him; the best whom you may hire is a strong and trustworthy one."

# 3279

He (Shu'ayb) said to (Moses), "I want to give one of my daughters to you in marriage on the condition that you will work for me for eight years, but you may continue for two more years only out of your own accord. I do not want it to become a burden for you. God willing, you will find me a righteous person".

# 3280

(Moses) said, "Let it be a binding contract between us and I shall be free to serve for any of the said terms. God will bear witness to our agreement."

# 3281

When Moses completed the term of the contract and departed from his employer with his family, he saw a fire (on his way) on one side of the Mount (Sinai). He asked his wife, "Stay here. I can see some fire. Perhaps I will be able to bring some news of it or some fire for you to warm-up yourselves."

# 3282

He was called from a tree of the blessed spot of the bank of the right side of the valley when he appraoched it, "Moses, I am God, the Lord of the Universe.

# 3283

Throw down your staff." When Moses saw his staff moving on the ground like a living being he fled with no desire to step forward. He was told, "Moses, step forward. Do not be afraid; you will be safe and secure.

# 3284

Place your hand in your pocket; it will come out sheer white but not sick. Be humble for fear of God and show these two miracles of your Lord to the Pharaoh and his officials; they are an evil-doing people."

# 3285

(Moses) said, "Lord, I have killed a man from their people and I am afraid that they will kill me.

# 3286

My brother Aaron is more fluent then I am. Send him with me to assist me and express my truthfulness; I am afraid they will reject me".

# 3287

The Lord said, "We will support you by your brother and will grant you such prestige that no one will dare to approach anyone of you. By the help of Our miracles both you and your follower will certainly triumph."

# 3288

When Moses came to them with Our miracles, they said, "These are only invented magic. We have never heard of such things from our fathers".

# 3289

Moses said, "My Lord knows best who has received guidance from Him and who will achieve a happy end. The unjust ones certainly will have no happiness."

# 3290

The Pharaoh said, "My people, I know no one who could be your lord besides myself. Haman, construct for me a tower of baked bricks so that I may climb on it and see the God of Moses; I think he is a liar."

# 3291

The Pharaoh and his army were puffed-up with pride in the land for no true cause. They thought that they would never return to Us.

# 3292

We sized him and his army and threw them into the sea. See how terrible was the end of the unjust people!

# 3293

We made them the kinds of leaders who would invite people to the fire and who would receive no help on the Day of Judgment.

# 3294

We made them to be mentioned with condemnation in this life and they will be disgraced on the Day of Judgment.

# 3295

After destroying the people of the ancient towns We gave the Book to Moses to be a source of knowledge, a guidance, and mercy for mankind so that perhaps they would take heed.

# 3296

(Muhammad), you were not present at the west bank to witness when We gave the commandments to Moses.

# 3297

But We raised many generations after Moses and they lived for many years. You did not dwell with the people of Midian reciting Our revelations to them, but We had certainly sent Messengers to them.

# 3298

You had not been present at the side of the Mount (Sinai) when We called Moses (from the tree), but through Our mercy we told you his story so that you might warn the people

# 3299

to whom no warner had been sent that perhaps they might take heed, and that, on experiencing afflictions because of their own deeds, they may not say, "Lord, would that You had sent to us a Messenger so that we could follow Your revelations and become believers".

# 3300

When the Truth from Us came to them they said, "Would that he, (Muhammad), had received what was given to Moses (by his Lord)." Did not they reject what Moses had brought to them saying, "These two, Moses and Aaron, are two magicians who support each other. We do not have any faith in them."

# 3301

(Muhammad), tell them, "Bring a Book if you are able to, from God better in its guidance than the Torah and the Quran; I shall follow it".

# 3302

If they cannot meet such a challenge, know that they are only following their (evil) desires. Who strays more than one who follows his desires without guidance from God? God does not guide the unjust people.

# 3303

We sent Our guidance to them so that perhaps they might take heed.

# 3304

(Some of) the followers of the Bible believe in the Quran.

# 3305

When it is recited to them, they say, "We believe in it. It is the Truth from our Lord. We were Muslims before it was revealed".

# 3306

These will receive double reward for their forbearance, replacing evil by virtue, and for their spending for the cause of God.

# 3307

When they hear impious words, they ignore them, saying, "We shall be responsible for our deeds and you will be responsible for yours. Peace be with you. We do not want to become ignorant."

# 3308

(Muhammad), you cannot guide whomever you love, but God guides whomever He wants and knows best those who seek guidance.

# 3309

They, (the pagans), say, "If we were to follow your guidance we would be snatched away from our land. Have We not given them the secure, holy precinct wherein all types of fruits are brought to them as a sustenance from Us? However, many of them do not know it.

# 3310

How many nations, who had enjoyed great prosperity, had We destroyed? Those are their homes which were not inhabited thereafter except for a short time. Only We were their heirs.

# 3311

Your Lord did not destroy the people of the towns without first sending a Messenger to the mother town who would recite His revelations to them. We did not want to destroy the towns if the people therein were not unjust.

# 3312

Whatever you (people) have been given are only the means for enjoyment and beauty of the worldly life, but the means of enjoyment (which you will receive from God) in the life to come will be better and everlasting. Will you then not take heed?

# 3313

Is the case of those to whom We have promised good things - which they will certainly receive in the life to come - equal to the case of those to whom We have granted the means of enjoyment in the worldly life and who will certainly be questioned about them in the life to come?

# 3314

On the day when He will ask (the latter group), "Where are those whom you had considered equal to Me?"

# 3315

Those who have become subject to punishment will say, "Lord, they seduced us." Their idols will say, "We seduced them but we renounce their worshipping us for it was not us whom they worshipped".

# 3316

They will be told to call their idols. They will call them but will receive no answer. They will see the torment approaching and wish that they had sought guidance.

# 3317

On the day when God will call them and ask them, "What answer did you give to (Our) messengers?"

# 3318

The door to all answers will be closed to them and they will not even be able to ask one another.

# 3319

However, those who have repented and have become righteously striving believers will perhaps have everlasting happiness.

# 3320

Your Lord creates and chooses (to grant mercy) to whomever He wants. (In matters of guidance) they (unbelievers) do not have the choice to choose whatever they want. God is too exalted to be considered equal to anything else.

# 3321

Your Lord knows all that their hearts hide or reveal.

# 3322

He is the only God and it is only He who deserves to be given thanks in this world and in the life to come. Judgment is in His hands and to Him you will all return.

# 3323

(Muhammad), ask them, "Think, if God were to cause the night to continue until the Day of Judgment which Lord besides Him could bring you light? Will you then not listen to (His revelations)?"

# 3324

Say, "Do you not think that if God were to cause the day to continue until the Day of Judgment, which Lord besides Him could bring you the night to rest. Do you not see (His signs)?"

# 3325

He has made the night and day for you to rest as a mercy to you and seek His favor and that perhaps you will give Him thanks.

# 3326

God will call the unbelievers on the Day of Judgment and ask them, "Where are your idols in which you had faith?

# 3327

We shall call from every nation a witness and shall ask them to bring proof (in support of their belief). They will know that truth belongs to God and that whatever they had falsely invented has abandoned them.

# 3328

Korah was a man from the people of Moses. This man rebelled against them. We had given him so much treasure that the keys of the stores of his treasures could hardly even be carried by a group of strong people. His people told him, "Do not be proud of your wealth; God does not love those who are proudly happy of their wealth.

# 3329

Seek the gains of the life to come through your wealth without ignoring your share of this life. Do favors to others just as God has done favors to you. Do not commit evil in the land for God does not love the evil-doers."

# 3330

He said, "I have received this wealth because of my knowledge." Did he not know that God had destroyed many generations that lived before him who were stronger than him in power and people? (There will be no need) to ask the criminals what sins they have committed, (for the angels already know them)

# 3331

Korah would bedeck himself to show off his wealth. Those who wanted worldly gains would say, "Would that we were given that which Korah has received. He has certainly received a great share."

# 3332

The people who had received knowledge would tell them, "Woe to you! The reward of God is far better for the righteously striving believers. No one can receive such reward except those who exercise patience."

# 3333

We caused the earth to swallow up him and his home. No one besides God could help him nor could he himself achieve victory.

# 3334

The people who the other day had wished to be like him, began saying, "Woe to us! God gives abundant wealth only to those of His servants whom He wants and He determines everyone's share. Had it not been for God's favor to us, He would have caused the earth to swallow us up. Woe to the unbelievers who will have no happiness."

# 3335

There is the life hereafter which We have prepared for those who do not want to impose their superiority over the others in the land nor commit evil therein. The happy end certainly belongs to the pious ones.

# 3336

The reward for a good deed will be greater than the deed itself and the recompense for an evil deed will be equivalent to the deed.

# 3337

(Muhammad), God, Who has commanded you to follow the guidance of the Quran, will certainly return you victoriously to your place of birth. Say, "My Lord knows best who has brought guidance and who is in plain error."

# 3338

You had no hope of receiving the Book except by the mercy of your Lord. Do not be a supporter of the unbelievers.

# 3339

Let them not prevent you from following the revelations of God after they are revealed to you. Call (mankind) to your Lord and do not be a pagan.

# 3340

Do not worship anything besides God. He is the only God. Everything will be destroyed except God. To Him belongs Judgment and to Him you will all return.

# 3341

Alif. Lam. Mim.

# 3342

Do people think they will not be tested because they say, "We have faith?"

# 3343

We had certainly tried those who lived before them to make sure who were truthful in their faith and who were liars.

# 3344

Do the evil-doers think they can escape Us? How terrible is their judgment?

# 3345

Let those who have the desire to be in the presence of God on the Day of Judgment know that their day will certainly be coming. God is All-Hearing and All-Knowing.

# 3346

Whoever strives hard should know that it is for his own good. God is independent of the whole world.

# 3347

We shall expiate the sins of the righteously striving believers and shall reward them better than their deeds.

# 3348

We have advised the human being, "Be kind to your parents. Do not obey them if they force you to consider equal to Me things which you do not know are such." You will all return (to Me) and I shall show all that you have done.

# 3349

We shall admit the righteously striving believers into the company of the pious ones.

# 3350

Some people say, "We have faith in God." But when they face some hardship for His cause, they begin to consider the persecution that they have experienced from people as a torment from God. When your Lord grants you a victory, they say, "We were with you." Does God not know best what is in the hearts of every creature?

# 3351

God certainly knows all about the believers and the hypocrites.

# 3352

The unbelievers say to the believers. "Follow our way. We shall take the responsibility for your sins." They cannot take responsibility for any of the sins. They are only liars.

# 3353

Besides the other burdens that they will have to carry, they will certainly be loaded with the burden of their own sins. They will be questioned on the Day of Judgment about what they had falsely invented.

# 3354

We sent Noah to his people and he lived with them for nine hundred and fifty years, then the flood engulfed them for their injustice.

# 3355

We saved Noah and the people in the Ark and made (their case) a miracle for the world.

# 3356

Abraham told his people, "Worship God and have fear of Him. It is better for you if only you knew it.

# 3357

You worship idols besides God and you create falsehood. Whatever you worship besides Him cannot provide you with anything for your sustenance. Seek your sustenance from the bounties of God. Worship Him. Give Him thanks. To Him you will all return."

# 3358

If you, (pagans), call our (revelations) lies, certainly many generations living before you have also done the same thing. The duty of a Messenger is only to preach clearly.

# 3359

Have they not seen how God begins the creation and then turns it back? This is not difficult at all for God.

# 3360

(Muhammad), say to them, "Travel through the land and see how He has begun the creation and how He will invent the next life. God has power over all things.

# 3361

He punishes or grants mercy to whomever He wants and to Him you will all return.

# 3362

You cannot challenge God in the heavens or in the earth. No one besides God is your guardian or helper.

# 3363

Those who have rejected God's revelations have no hope in receiving His mercy. They will face a painful torment.

# 3364

(Abraham's) people had no answer except suggesting, "Kill him or burn him." But God saved him from the fire. In this there is evidence (of truth) for the believing people.

# 3365

Abraham said, "You believe in idols besides God only out of worldly love, but on the Day of Judgment you will reject and condemn each other. Your dwelling will be fire and no one will help you."

# 3366

Only Lot believed in (Abraham) and said, "I seek refuge in my Lord, for He is Majestic and All-wise".

# 3367

We granted Isaac and Jacob to Abraham and We bestowed upon his offspring, prophethood and the Book. We gave him his reward in this world and in the next life, he will be among the pious ones.

# 3368

Lot told his people, "You are certainly committing the kind of indecency which no one in the world has committed before".

# 3369

Do you engage in carnal relations with men, rob the travellers, and commit evil in your gatherings? His people had no answer but to say, "Bring upon us the torment of God if you are truthful".

# 3370

He prayed, "Lord help me against the evil-doing people."

# 3371

When Our angelic Messengers brought glad news to Abraham, they told him, "We are about to destroy the people of this town for their injustice".

# 3372

Abraham said, "Lot is there in that town!" They said, "We know everyone there. We shall certainly save him and his family except his wife who will remain behind."

# 3373

When Our angelic Messengers came to Lot, he was grieved and depressed to see them. They told him, "Do not be afraid or grieved. We will rescue you and your family except your wife who will remain behind.

# 3374

We will bring torment from the sky on this town because of the evil-deeds of its inhabitants".

# 3375

We left manifest evidence (of the truth) there for the people of understanding.

# 3376

We sent to the people of Midian their brother Shu\`ayb. He told them, "Worship God. Have hope in the life to come. Do not spread evil in the land".

# 3377

They rejected him so We jolted them with a violent earthquake and they were left motionless in their houses.

# 3378

How the people of Ad and Thamud were destroyed is evident to you from their homes. Satan made their deeds seem attractive to them and prevented them from the right path, even though they had visions.

# 3379

Korah, the Pharaoh, and Haman were also destroyed. Moses had brought them illustrious miracles, but they were puffed-up with pride in the land and they could not defeat Us.

# 3380

We punished all of these people because of their sin. Some of them were struck by a violent sand-storm, some by a blast of sound, others were swallowed up by the earth, and some were drowned (in the sea). God did not do injustice to them, but they had wronged themselves.

# 3381

The belief of considering other things as one's guardians besides God is as feeble as a spider's web. The spider's web is the frailest of all dwellings, if only they knew it.

# 3382

God knows whatever they worship besides Him; He is the Majestic and All-wise.

# 3383

These are parables which We tell to human being, but only the learned ones understand them.

# 3384

God has created the heavens and the earth for a genuine purpose. In this there is evidence (of the truth) for the believers.

# 3385

(Muhammad), recite to them what has been revealed to you in the Book and be steadfast in prayer; prayer keeps one away from indecency and evil. It is the greatest act of worshipping God. God knows what you do.

# 3386

Do not argue with the People of the Book except only by the best manner, except the unjust among them. Tell them, "We believe in what is revealed to us and to you. Our Lord and your Lord is one. We have submitted ourselves to His will".

# 3387

We have revealed the Book to you. Some of the People of the Book and some of the pagans also believe in it. No one rejects Our revelations except the infidels.

# 3388

You were not able to read or write before the Quran was revealed to you; otherwise, the followers of falsehood would have tried to confuse the matter.

# 3389

In fact, the Quran consists of illustrious verses that exist in the hearts of those who have knowledge. No one rejects Our revelations except the unjust ones.

# 3390

They say, "Why a miracle is not sent to him from his Lord." Say, "Miracles are in the hands of God. I am simply a warner."

# 3391

Is it not enough for them that We have revealed the Book to you to be recited to them. It is a mercy and a reminder for the believers.

# 3392

Say, "God is sufficient as a witness between me and you. He knows all that is in the heavens and the earth." Those who have faith in falsehood and disbelieve in God are certainly lost.

# 3393

They demand you to bring upon them torment immediately. Had not the time been fixed, the torment would certainly have approached them. It would have come to them suddenly and they would not have even realized how it came.

# 3394

They demand you to bring upon them the torment immediately. Hell will certainly engulf the unbelievers.

# 3395

They will be told on the Day of Judgment, when the torment will surround them from all sides, "Suffer the consequences of your deeds."

# 3396

My believing servants, My land is vast. Worship Me alone.

# 3397

Every soul will experience the agony of death and to Me you will all return.

# 3398

We shall give mansions in Paradise wherein streams flow to the righteously striving believers and therein they will live forever. How blessed is the reward of the hard working people

# 3399

who have exercised patience and who have had trust in their Lord.

# 3400

There are many living creatures which do not carry their sustenance, but God provides them and you with sustenance. He is All-hearing and All-knowing.

# 3401

If you ask them, "Who has created the heavens and the earth and has subdued the sun and moon?" They will say, "God has done it." So why are they wandering about!?

# 3402

God increases the sustenance of whichever of His servants He wants and He determines their share. God has the knowledge of all things.

# 3403

If you ask them, "Who has sent down water from the sky to revive the dead earth?" They will say, "God has done it." Say, "It is only God who deserves all praise, but many of them do not understand."

# 3404

The worldly life is not more than a childish game. It is the life hereafter which will be the real life, if only they knew it.

# 3405

When they sail in a boat, they sincerely pray to God with pure faith. But when We bring them safely to land, they start considering things equal to God.

# 3406

Let them be ungrateful to what We have granted them. Let them enjoy themselves, but they will soon know (the consequences of their deeds).

# 3407

Have the (pagans) not seen that We have made the holy precinct a safe place while all the people around are suffering terror. Do they believe in falsehood and disbelieve in God's bounties?

# 3408

Who is more unjust than one who invents falsehood against God or rejects the Truth after it has come to him? Is not hell the dwelling for the disbelievers.

# 3409

We shall certainly guide those who strive for Our cause to Our path. God is certainly with the righteous ones.

# 3410

Alif. Lam. Mim.

# 3411

The Romans have been defeated in a nearby land and after this defeat,

# 3412

(within a few years) they will be victorious.

# 3413

All matters of the past and future are in the hands of God. The believers will enjoy the help of God on that Day.

# 3414

He helps whomever He wants. He is Majestic and All-merciful.

# 3415

This is the promise of God. God does not ignore His promise, but many people do not know.

# 3416

They only know the superficial realities of the worldly life and they are unaware of the life to come.

# 3417

Have they not thought that God has not created the heavens and the earth and all that is between them but for a genuine purpose to exist for an appointed term? Many people do not believe in their meeting with their Lord.

# 3418

Have they not travelled through the land to see how terrible was the end of the people who lived before them. The people who lived before them were stronger than them in might, in tilling, and in developing the earth. Our Messengers came to them with clear miracles. God did not do an injustice to them but they wronged themselves.

# 3419

The end of the evil-doers was terrible, for they had rejected the revelations of God and mocked them.

# 3420

God begins the creation then causes it to turn back and to Him you will all return.

# 3421

On the day when the Hour of Doom comes, the criminals will despair.

# 3422

None of the idols will intercede for them and they will reject their idols.

# 3423

When that day comes, (people) will be separated from one another.

# 3424

The righteously striving believers will happily live in paradise.

# 3425

However, the disbelievers, who called Our revelations and the Day of Judgment lies, will be brought into torment.

# 3426

Glory belongs to God all the time, in the evening and in the morning.

# 3427

To Him belongs all the thanks giving which takes place in the heavens and the earth, in the evenings and the noontime.

# 3428

He brings forth the living from the dead, takes out the dead from the living, and revives the earth from its death. Thus, you will all be brought back to life again.

# 3429

Some evidence of His existence are His creating you from clay and from that you became human beings scattered all around;

# 3430

His creating spouses for you out of yourselves so that you might take comfort in them and His creating love and mercy among you. In this there is evidence (of the truth) for the people who (carefully) think.

# 3431

Other evidence of His existence are the creation of the heavens and the earth and the differences of languages and colors. In this there is evidence (of the truth) for the worlds (mankind).

# 3432

Your sleeping during the night and in the day your seeking His favors are evidence (of the truth) for the people who have hearing.

# 3433

Also, of the evidence of His existence are His showing you lightening which gives you fear and hope and His sending water down from the sky which revives the earth after its death. In this there is evidence (of the truth) for the people of understanding.

# 3434

Some other evidence of His existence is that both the heavens and the earth stand firm at His command. When He will call you from the earth, you will start to come out.

# 3435

Everyone in the heavens and the earth belongs to Him and is subservient to Him.

# 3436

It is He who begins the creation, then, turns it back. For Him this is very easy. All the exalted attributes in the heavens and the earth belong to Him. He is the Majestic and All-wise.

# 3437

God has told you this parable about yourselves: Could your slaves share your wealth equally with you and could you fear them as you fear yourselves? Thus, do We clarify the evidence (of the truth) for the people of understanding.

# 3438

In fact, the unjust have followed their desires without knowledge. Who will guide those whom God has caused to go astray? No one will be their helper.

# 3439

(Muhammad), be devoted to the upright religion. It is harmonious with the nature which God has designed for people. The design of God cannot be altered. Thus is the upright religion, but many people do not know.

# 3440

Turn in repentance to Him. Have fear of Him. Be steadfast in your prayer. Do not be like the pagans

# 3441

who have divided themselves into various religious sects, each one happy with their own belief.

# 3442

When people face hardship, they begin praying to their Lord and turn in repentance to Him. When they receive mercy from Him, a group of them begin to consider things equal to God,

# 3443

because of their ingratitude for what We have given them. Let them enjoy themselves, but they will soon know (the consequences of their deeds).

# 3444

Have We sent them any authority to speak in support of their idols?

# 3445

When people receive mercy, they are happy with it. However, when hardship befalls them because of their own deeds, they despair.

# 3446

Have they not seen how God increases the livelihood of whomever He wants and determines his share. In this there is evidence (of the truth) for the believing people.

# 3447

Give the relatives, the destitute, and the needy travellers their share (of charity). It is better for those who want to please God and they will have everlasting happiness.

# 3448

God will not allow to increase whatever illegal interest you try to receive in order to increase your wealth at the expense of people's property. Whatever amount of zakat you give to please God will be doubled (for you).

# 3449

It is God who has created you and given you sustenance. He will make you die and will bring you back to life. Can any of your idols do such things? God is too Exalted to be considered equal to anything else.

# 3450

Evil has spread over the land and the sea because of human deeds and through these God will cause some people to suffer so that perhaps they will return to Him.

# 3451

(Muhammad), tell them, "Travel through the land to see how terrible was the end of those who lived before. Many of them were pagans.

# 3452

Be devoted to the upright religion before the coming of the inevitable day when no one can escape from God and people will either be sent to Paradise or hell."

# 3453

Those who disbelieve do so against their own souls. Those who do good pave the way for their own benefit.

# 3454

God will reward the righteously striving believers through His favor. He does not love the unbelievers.

# 3455

Some evidence of His existence is His sending the glad-news-bearing winds so that He would let you to receive His mercy, cause the ships to sail by His command, and let you seek His favor so that perhaps you would give Him thanks.

# 3456

(Muhammad), We had sent before you Our Messengers to their people. The Messengers showed them clear miracles and We took revenge on the criminals. It was necessary for Us to help the believers.

# 3457

It is God who sends the winds to raise the clouds. He spreads them in the sky as He wants, then He intensifies them, and then you can see the rain coming down from the cloud. When He sends it down upon whichever of His servants He wants, they rejoice

# 3458

at the rainfall, though before that they had been in despair.

# 3459

Look at the traces of the mercy of God, how He has revived the dead earth. God revives the dead; He has power over all things.

# 3460

Even if We had sent the wind and caused (the plants) to turn yellow and to fade away, they would still have remained in disbelief.

# 3461

You cannot make the dead listen, nor the deaf hear. Thus, they, (the disbelievers), turn away on their heels.

# 3462

You cannot guide the straying blind. You can make no one listen except those who believe in Our revelations and are Muslims.

# 3463

It is God who has created you weak, then, given you strength after your weakness and caused you to become weak and old after being strong. He creates whatever He wants. He is All-knowing and All-powerful.

# 3464

On the day when the Hour of Doom comes, the criminals will swear that they have remained (in their graves) for no more than an hour. They had been inventing lies in this way.

# 3465

Those who have received knowledge and have faith will say, "By the decree of God, you have remained for the exact period which was mentioned in the Book of God about the Day of Resurrection. This is the Day of Resurrection, but you did not know."

# 3466

The excuses of the unjust on this day will be of no avail to them and they will not be able to please God.

# 3467

We have told people various parables in this Quran. Even if you had shown them a miracle, the unbelievers would have said, "You are only the followers of falsehood".

# 3468

Thus does God seal the hearts of those who do not know.

# 3469

Be patient. The promise of God is certainly true. Let not the faithless make you despair of the promise of God.

# 3470

Alif. Lam. Mim.

# 3471

These are the verses of the Book of wisdom.

# 3472

A guidance and mercy for the righteous

# 3473

people who are steadfast in prayer, pay the religious tax, and have firm belief in the life to come.

# 3474

They follow the guidance of their Lord and they will have everlasting happiness.

# 3475

(In an attempt to show that God's revelations are only ancient legends) some people pay for meaningless tales to draw others attention away from the Quran without knowledge and treat as a matter of fun. They will suffer a humiliating torment.

# 3476

When Our revelations are recited to them, they turn back on their heels out of pride as if they did not hear them or their ears had been sealed off. Warn them of the painful torment.

# 3477

The righteously striving believers will enter Paradise

# 3478

wherein they will live forever. It is the true promise of God. He is Majestic and All-wise.

# 3479

He has created the heavens without pillar as you can see, fixed the mountains on earth so that it may not shake you away, and settled therein all types of living creatures. We have sent down water from the sky and made all kinds of plants grow in gracious pairs.

# 3480

This is the creation of God. Show me what those whom you consider equal to God have created. In fact, the unjust ones are in plain error.

# 3481

We gave wisdom to Luqman so that he would give thanks to God. Those who give thanks to God do so for their own good. Those who are ungrateful should know that God is Self-sufficient and Praiseworthy.

# 3482

Luqman advised his son telling him, "My son, do not consider anything equal to God, for it is the greatest injustice."

# 3483

(Concerning his parents), We advised the man, whose mother bears him with great pain and breast-feeds him for two years, to give thanks to Me first and then to them, to Me all things proceed.

# 3484

If they try to force you to consider things equal to Me, which you cannot justify, equal to Me, do not obey them. Maintain lawful relations with them in this world and follow the path of those who turn in repentance to Me. To Me you will all return and I shall tell you all that you have done.

# 3485

"My son, God keeps the records of all the good and evil deeds, even if they are as small as a grain of mustard seed, hidden in a rock or in the heavens or the earth. God is subtle and All-aware.

# 3486

My son, be steadfast in prayer. Make others do good. Prevent them from doing evil. Be patient in hardship. Patience comes from faith and determination.

# 3487

Do not scornfully turn your face away from people. Do not walk around puffed-up with pride; God does not love arrogant and boastful people.

# 3488

Be moderate in your walking and your talking. The most unpleasant sound is the braying of donkeys."

# 3489

Have you not seen that God has made all that is in the heavens and the earth, subservient to you (human beings), and has extended and perfected for you His apparent and unseen bounties? Some people argue about God without knowledge, guidance, or an enlightening book.

# 3490

When they are told to follow what God has revealed to them, they say, "We shall only follow our father's way of life." Will they follow it even if it is Satan who is calling them to the burning torment?

# 3491

Whoever submits himself to the will of God in righteousness has certainly achieved a strong-hold. The end of all things is in the hands of God.

# 3492

(Muhammad), do not let the disbelievers grieve you. To Us they will all return and We shall tell them all about what they have done. God knows best what is in everyone's hearts.

# 3493

We shall allow them to enjoy themselves for a short while, then force them into severe torment.

# 3494

If you ask them, "Who has created the heavens and the earth," they will certainly say, "God has created them." Say, "It is only God who deserves all praise, but most of them do not know".

# 3495

To God belongs all that is in the heavens and the earth. He is Self-sufficient and Praiseworthy.

# 3496

If all the trees in the earth were pens and the ocean, with seven more oceans, were ink still these could not suffice to record all the Words of God. God is Majestic and All-wise.

# 3497

For God your creation and your resurrection are only like the creation and resurrection of one soul. God is All-hearing and All-seeing.

# 3498

Have you not seen that God causes the night to enter into the day and the day into the night. He has made the sun and moon subservient (to Himself). Each moves (in an orbit) for an appointed time. God is certainly All-aware of what you do.

# 3499

This is because God is the supreme Truth and whatever they worship besides Him is falsehood. God is the Most High and the Most Great.

# 3500

Have you not seen that the ships sail in the ocean through the bounty of God so that He may show you the evidence (of His existence). There is evidence (of the truth) in this for every forbearing and grateful one.

# 3501

When the waves cover them like shadows, they pray to God with sincerity in their religion, but when We bring them safely to land, only some of them follow the right path. No one rejects Our revelations except the treacherous ungrateful ones.

# 3502

Mankind, have fear of your Lord and the day when a father will be of no avail to his son, nor will a son carry any part of the burden of his father. The promise of God is true. Do not let the worldly life deceive you nor let your pride deceive you about God.

# 3503

Only God has the knowledge of the coming of the Hour of Doom. He sends down the rain and knows what is in the wombs. No soul is aware of what it will achieve tomorrow and no soul knows in which land it will die. God is All-knowing and All-aware.

# 3504

Alif. Lam. Mim.

# 3505

There is no doubt that this Book is revealed by the Lord of the Universe.

# 3506

Do they say that he, (Muhammad), has invented it? No, it is the truth from your Lord so that you will warn the people who have not received a warning before you. Perhaps they will seek guidance.

# 3507

God is the one who created the heavens and the earth and all that is between them in six days, then He established His dominion over the Throne. No one besides Him is your guardian or intercessor. Will you then not take heed?

# 3508

He sends the regulation of the affair from the heavens to the earth, then on the day which is equal to one thousand years of yours, it will ascend to Him.

# 3509

He knows the unseen and the seen. He is Majestic and All-merciful.

# 3510

It is He Who created everything in the best manner and began the creation of the human being from clay.

# 3511

He made His offspring come into existence from an extract of insignificant fluid,

# 3512

then He gave it proper shape and blew His spirit in it. He made ears, eyes and hearts for you, but you give Him very little thanks.

# 3513

They have said, "How can we be brought to life again after we have been lost in the earth?" In fact, they have no faith in the Day of Judgment

# 3514

(Muhammad), say, "The angel of death, who is appointed over everyone of you, will cause you to die and to your Lord you will all return."

# 3515

Would that you could see (on the Day of Judgment) that criminals, with their heads hanging down before their Lord, saying, "Our Lord, we have seen and heard. Send us back to act righteously. Now we have strong faith".

# 3516

Had We wanted, We could have given guidance to every soul, but My decree, that hell will be filled-up with jinn and people, has already been executed.

# 3517

They will be told, "Suffer on this Day of Judgment. For your having ignored it, We have ignored you. Suffer everlasting torment for your evil deeds."

# 3518

The only people who believe in Our revelations are those who, when reminded about them, bow down in prostration and glorify their Lord with His praise without pride.

# 3519

Their sides give-up rest in beds in order to pray before their Lord in fear and hope. They spend for the cause of God out of what we have given them.

# 3520

No soul knows what delight awaits them as the reward for their deeds.

# 3521

Is a believer equal to an evil-doer? They are not equal at all.

# 3522

The righteously striving believers will have Paradise for their dwelling as the reward of their good deeds.

# 3523

However, the dwelling of the sinful ones will be hell fire. Each time they try to come out, they will be turned back with this remark, "Suffer the torment of the fire which you had called a lie".

# 3524

We shall certainly make them suffer worldly torment before suffering the great torment so that perhaps they may return to Us.

# 3525

Who are more unjust than those who are reminded of the revelation of their Lord, but have ignored them? We will take revenge on the criminal.

# 3526

We gave the Book to Moses - do not have any doubt about the Day of Judgment - and made it a guide for the children of Israel.

# 3527

We appointed some of the Israelites as leaders for their exercising patience to guide the others to Our commands. They had firm belief in Our revelations.

# 3528

Your Lord will issue His decree about their (believers and disbeliever's) differences on the Day of Judgment.

# 3529

Was it not a lesson for them, (the unbelievers), that We destroyed the many generations living before them among whose ruined dwellings they are now walking. In this there is many evidence (of the truth). Will they not then listen?

# 3530

Have they not seen that We drive the water to the barren land and cause crops to grow which they and their cattle consume? Why, then, they will not see?

# 3531

They say, "If what you say is true, when will the final triumph come?"

# 3532

Say, "On the day of the final triumph, the faith of the disbelievers will be of no avail to them, nor will they be given any respite".

# 3533

Turn away from them and wait. They are, also, waiting.

# 3534

Prophet, have fear of God and do not yield to the infidels and hypocrites. God is All-knowing and All-wise.

# 3535

Follow what has been revealed to you from your Lord. God is All-aware of what you do.

# 3536

Trust in God and be sure that He is a Sufficient Guardian.

# 3537

God has not created two hearts inside any one human being. God does not consider your wives whom you renounce by zihar as your mothers nor those whom you adopt as your sons. These are only words of your mouth. God tells the Truth and shows the right path.

# 3538

Call them sons of their own fathers. It is more just in the eyes of God. If you do not know their fathers, they are your brothers and friends in religion. You will not be responsible for your mistakes, but you will be responsible for what you do intentionally. God is All-forgiving and All-merciful.

# 3539

The Prophet has more authority over the believers than themselves. His wives are their mothers. The relatives are closer to each other, according to the Book of God, than the believers and the emigrants. However, you may show kindness to your guardians. This also is written in the Book.

# 3540

We had a solemn covenant with you (Muhammad), and the Prophets: Noah, Abraham, Moses, and Jesus, the son of Mary.

# 3541

This was a firm agreement. God will ask the truthful ones about their truthfulness and prepare a painful torment for the disbelievers.

# 3542

Believers, recall God's favor to you when the army attacked you. We sent a wind and the armies, which you did not see, to support you. God sees all that you do.

# 3543

Eyes became dull and hearts almost reached the throat when they attacked you from above and below and you started to think of God with suspicion.

# 3544

There the believers were tested and tremendously shaken.

# 3545

It was there that the hypocrites and those whose hearts were sick, said, "The promise of God and His Messenger has proved to be nothing but deceit".

# 3546

It was there that a group of them said, "People of Yathrib, turn back for there is no place for you to stay." Another group, asking for the Prophet's permission, said, "Our homes are defenseless." In fact, they were not defenseless. They only wanted to run away.

# 3547

Had the army of the enemies invaded their homes and asked them to give-up their religion, they would have yielded to them without delay.

# 3548

They had certainly promised God that they would not turn away. To promise God is certainly a (great) responsibility.

# 3549

(Muhammad), tell them, "Running away will never be of any benefit to you even if you run away from death or being killed. Still you would not be able to enjoy yourselves except for a short while."

# 3550

Say, "Who can prevent God from punishing you or granting you mercy? They will not find anyone besides God as their guardian or helper."

# 3551

God certainly knows those among you who create obstacles (on the way that leads to God) and those who say to their brothers, 'Come quickly to us' and very rarely take part in the fighting.

# 3552

They are niggardly in spending for you. When fear comes, you can see them looking at you, their eyes rolling about like to faint because of the agony of death. When their fear subsides, they start to bite you with their sharp tongues. They are miserly in spending for a virtuous cause and have no faith. God has turned their deeds devoid of all virtue. This was not at all difficult for God.

# 3553

They think that the confederate tribes have not yet gone. If the confederate tribes were to attack them, they would have wished to be left alone among the bedouin Arabs where they would only follow the news about you. Even if they were with you, only a few of them would take part in the fight.

# 3554

The Messenger of God is certainly a good example for those of you who have hope in God and in the Day of Judgment and who remember God very often.

# 3555

On seeing the confederate tribes, the believers said, "This is what God and His Messenger had promised us. The promise of God and His Messenger is true." This only strengthens their faith and their desire of submission to the will of God.

# 3556

Among the believers there are people who are true in their promise to God. Some of them have already passed away and some of them are waiting. They never yield to any change.

# 3557

God will certainly reward the truthful ones for their truthfulness and punish or pardon the hypocrites as He wishes. God is All-forgiving and All-merciful.

# 3558

God repelled the unbelievers in their rage. They could not achieve anything good. God rendered sufficient support to the believers in fighting. God is All-powerful and Majestic.

# 3559

God brought down those among the People of the Book who had supported the confederate tribes from their castles and struck their hearts with terror. You did away with some of them and captured the others.

# 3560

God made you inherit their land, houses, property, and a land on which you had never walked. God has power over all things.

# 3561

Prophet, tell your wives, "If you want the worldly life and its beauty, I shall allow you to enjoy it and set you free in an honorable manner,

# 3562

but if you want the pleasure of God, His Messenger, and the life hereafter, know that God has prepared a great reward for the righteous ones among you."

# 3563

Wives of the Prophet, if anyone among you commits indecency, her torment will be double. This is not at all difficult for God.

# 3564

To whoever of you obeys God and His Messenger and acts righteously, We will give double reward and a honorable sustenance.

# 3565

Wives of the Prophet, you are not like other women. If you have fear of God, do not be tender in your speech lest people whose hearts are sick may lust after you.

# 3566

Do not display yourselves after the manner of the (pre-Islamic) age of darkness. Be steadfast in the prayer, pay the religious tax, and obey God and His Messenger. People of the house, God wants to remove all kinds of uncleanliness from you and to purify you thoroughly.

# 3567

Wives of the Prophet, remember the revelations of God and Words of wisdom that are recited in your homes. God is Most Kind and All-aware.

# 3568

God has promised forgiveness and great rewards to the Muslim men and the Muslim women, the believing men and the believing women, the obedient men and the obedient women, the truthful men and the truthful women, the forbearing men and the forbearing women, the humble men and the humble women, the alms-giving men and the alms-giving women, the fasting men and the fasting women, the chaste men and the chaste women, and the men and women who remember God very often.

# 3569

The believing men and women must not feel free to do something in their affairs other than that which has been already decided for them by God and His Messenger. One who disobeys God and His Messenger is in plain error.

# 3570

Say to the person to whom you and God have granted favor, "Keep your wife and have fear of God. You hide within yourself what God wants to make public. You are afraid of people while it is God whom one should fear." When Zayd set her free, We gave her in marriage to you so that the believers would not face difficulties about the wives of their adopted sons when they are divorced. God's decree has already been issued.

# 3571

The Prophet cannot be blamed for carrying out the commands of God. It was the tradition of God with those who lived before. The command of God has already been decreed and ordained.

# 3572

Those who preach the message of God and are humble before Him should not be afraid of anyone besides God. God is Sufficient in keeping the account.

# 3573

Muhammad is not the father of any of your males. He is the Messenger of God and the last Prophet. God has the knowledge of all things.

# 3574

Believers, remember God very often

# 3575

and glorify Him both in the mornings and in the evenings.

# 3576

It is He who forgives you and His angels pray for you so that He will take you out of darkness into light. God is All-merciful to the believers.

# 3577

On the day when they will be brought into the presence of their Lord, their greeting to each other will be, "Peace be with you." God has prepared an honorable reward for them.

# 3578

Prophet, We have sent you as a witness, a bearer of glad news, a warner,

# 3579

a preacher for God by His permission and as a shining torch.

# 3580

Give glad news to the believers of their receiving great favor from God.

# 3581

Do not yield to the disbelievers or the hypocrites. Ignore their annoying you. Trust in God. God is your all Sufficient Protector.

# 3582

Believers, if you marry believing women and then divorce them before the consummation of the marriage, they do not have to observe the waiting period. Give them their provisions and set them free in an honorable manner.

# 3583

Prophet, We have made lawful for you your wives whom you have given their dowry, slave girls whom God has given to you as gifts, the daughters of your uncles and aunts, both paternal and maternal, who have migrated with you. The believing woman, who has offered herself to the Prophet and whom the Prophet may want to marry, will be specially for him, not for other believers. We knew what to make obligatory for them concerning their wives and slave girls so that you would face no hardship (because we have given distinction to you over the believers). God is All-forgiving and All-merciful.

# 3584

You may refuse whichever (of the woman who offer themselves to you) as you want and accept whichever of them you wish. There is no blame on you if you marry (one whom you had refused previously). This would be more delightful for them. They should not be grieved but should be happy with whatever you have given to every one of them. God knows what is in your hearts. God is All-knowing and All-forbearing.

# 3585

Besides these, other women are not lawful for you to marry nor is it lawful for you to exchange your wives for the wives of others (except for the slave girls), even though they may seem attractive to you. God is watchful over all things.

# 3586

Believers, do not enter the houses of the Prophet for a meal without permission. if you are invited, you may enter, but be punctual (so that you will not be waiting while the meal is being prepared). When you have finished eating, leave his home. Do not sit around chatting among yourselves. This will annoy the Prophet but he will feel embarrassed to tell you. God does not feel embarrassed to tell you the truth. When you want to ask something from the wives of the Prophet, ask them from behind the curtain. This would be more proper for you and for them. You are not supposed to trouble the Prophet or to ever marry his wives after his death, for this would be a grave offense in the sight of God.

# 3587

Whether you reveal something or hid it, God has the knowledge of all things.

# 3588

It will not be an offense for the wives of the Prophet (not to observe the modest dress) in the presence of their fathers, sons, brothers, sons of their brothers and sisters, their own women, and their slave-girls. They should have fear of God. God witness all things.

# 3589

God showers His blessings upon the Prophet and the angels seek forgiveness for him. Believers, pray for the Prophet and greet him with, "Peace be with you."

# 3590

Those who annoy God and His Messenger will be condemned by God in this life and in the life to come. He has prepared for them a humiliating torment.

# 3591

Those who annoy the believing men and women without reason will bear the sin for a false accusation, a manifest offense.

# 3592

Prophet, tell your wives, daughters, and the wives of the believers to cover their bosoms and breasts. This will make them distinguishable from others and protect them from being annoyed. God is All-forgiving and All-merciful.

# 3593

If the hypocrites, those whose hearts are sick and those who encourage the spread of evil in the city, will not desist, We shall arouse you against them and they will only be allowed to be your neighbors for a short while.

# 3594

They will be condemned wherever they are and will be sized and done away with for good.

# 3595

This was the tradition of God with those who lived before. There will never be any change in the tradition of God.

# 3596

(Muhammad), people ask you about the Day of Judgment. Say, "Only God has knowledge about it. Perhaps the Hour of Doom will soon come to pass."

# 3597

God has condemned the unbelievers and prepared for them a burning torment

# 3598

wherein they will live forever without being able to find any guardian or helper.

# 3599

On the day when their faces will be turned from side to side on the fire, they will say, "Would that we had obeyed God and the Messenger!"

# 3600

They will say, "Lord, we obeyed our chiefs and elders and they caused us to go astray.

# 3601

Lord, make them to suffer double torment and subject them to the greatest condemnation."

# 3602

Believers, do not be like those who annoyed Moses. God proved him to be innocent of what they had said about him. Moses was a honorable person in the sight of God.

# 3603

Believers, have fear of God and speak righteous words.

# 3604

God will reform your deeds and forgive your sins. One who obeys God and His Messenger will certainly achieve a great success.

# 3605

We offered Our Trust (Our deputation) to the heavens, to the earth, and to the mountains, but they could not bear this burden and were afraid to accept it. Mankind was able to accept this offer but he was unjust to himself and ignorant of the significance of this Trust.

# 3606

(As a result of this) God will punish the hypocrites and the pagans, but He will accept the repentance of the believers. God is All-forgiving and All-merciful.

# 3607

It is only God who deserves all praise. To Him belongs all that is in the heavens and the earth and it is only He who deserves to be praised in the life to come. He is All-wise and All-aware.

# 3608

He knows all that enters the earth, all that comes out of it, all that descends from the sky and all that ascends to it. He is All-merciful and All-forgiving.

# 3609

The disbelievers have said, "There will be no Hour of Doom." Say, "By my Lord, it certainly will come. My Lord knows the unseen. Not even an atom's weight in the heavens or the earth remains hidden from Him. Nothing exists greater or smaller than this without its record in the illustrious Book.

# 3610

God will certainly reward the righteously striving believers. These are the ones who will receive forgiveness and honorable sustenance.

# 3611

However, those who try to challenge Our revelations will face the most painful torment.

# 3612

Those who have been given knowledge will see that whatever has been revealed to you from your Lord is the truth and that it guides to the straight path of the Majestic and Praiseworthy One.

# 3613

The unbelievers have said, "Should we tell you about a man who says that you will be brought back to life again after your having been completely disintegrated?

# 3614

Has he invented this falsehood against God or is he possessed by jinn?" However, those who do not have any faith in the life to come will suffer torment for their serious error.

# 3615

Have they not seen the heavens and the earth in front and behind them. Had We wanted, We could have caused the earth to swallow them up or made a part of the sky fall upon them. In this there is evidence (of the truth) for every repenting person.

# 3616

We granted David a favor by commanding the mountains and birds to sing Our praise along with him and softened iron for him

# 3617

so that he could make coats of mail and properly measure their rings. We told him and his people to act righteously. We are Well-Aware of what you do.

# 3618

(We made subservient to) Solomon the wind that travelled a month's journey in the morning and a month's journey in the evening. We made a stream of brass flow for him and some of the jinn worked for him by his Lord's command. We would make whichever of them (jinn) who turned away from Our command to suffer a burning torment.

# 3619

They would make for him anything that he wanted like fortresses, statues, large basins like reservoirs, and huge immovable cooking pots. It was said, "Family of David, worship and act gratefully. Only few of my servants are grateful."

# 3620

When We decreed that Solomon should die, no one knew of his death except for a creeping creature of the earth who ate-up his staff. When he fell down, the jinn realized that if they had known about the unseen, they would not have remained in such a humiliating torment for so long.

# 3621

There was evidence (of the truth) for the people of Sheba in their homeland. (We gave them) two gardens, one on the left and one on the right and (told them), "Consume the sustenance which your Lord has given to you and give Him thanks. You have a blessed land and an All-forgiving Lord".

# 3622

They ignored (the evidence) and We sent to them a flood, arising from a broken dam. Nothing was left in their gardens but bitter fruits, some tamarisk and a few lotus trees.

# 3623

This was how We recompensed them for their ungratefulness and thus do We recompense the ungrateful ones.

# 3624

We established between them and the town that We had blessed, other towns nearby, and thus made it easier to travel. We told them, "Travel there safely day and night".

# 3625

They said, "Lord, make the distances of our journeys longer." They did injustice to themselves and We turned their existence into ancient tales by making them disintegrate totally. In this there is evidence (of the truth) for every forbearing and grateful person.

# 3626

Iblis (satan) made his judgment about them to come true. They all followed them except a believing group among them.

# 3627

He did not have any authority over them except to the extent that would allow Us to know who had faith in the life to come and who had doubts about it. Your Lord is a Guard over all things.

# 3628

Say, (Muhammad), "Ask help from those whom you worship besides God. They do not possess an atom's weight in the heavens and the earth, have no share therein, nor will any of their idols be able to support them."

# 3629

No intercession with Him will be of any benefit except that of those whom He has granted permission. The angels cannot intercede. They are always submissive to their Lord. Fear vanishes from their heart when (they receive a message from their Lord). They ask each other, "What did your Lord say?" Others answer, "He spoke the Truth. He is the Most High and the Most Great."

# 3630

Say, "Who provides you with sustenance from the heavens and the earth?" Say, "It is God. Only one group among us has the true guidance. The others must certainly be in plain error".

# 3631

Say, "You will not be questioned about our sins nor shall we about your deeds".

# 3632

Say, "Our Lord will gather us all together and issue the true Judgment about our differences. He is the Best Judge and All-knowing."

# 3633

Say, "Show me those whom you have related to God as His partner. He is too Exalted to have any partners. He is the Majestic and All-wise God."

# 3634

We have sent you as a bearer of glad news and a warner to the whole of mankind, but most people do not know.

# 3635

They say, "When will the Day of Judgment be if what you say is true?"

# 3636

Say, "That day has already been decreed for you and you cannot change the time of its coming even by a single hour."

# 3637

The unbelievers have said, "We shall never believe in this Quran nor in the Bible." Would that you could see the unjust having been halted in the presence of their Lord, exchanging words among themselves. The oppressed among them will say to their oppressors, "Had it not been for you, we would certainly have been believers."

# 3638

The suppressing ones will say to the oppressed ones, "Did we prevent you from having guidance after it had come to you? In fact, you yourselves were criminals."

# 3639

The oppressed ones will say to them, "It was you who planned night and day, ordering us to disbelieve God, and consider other things equal to Him." They will hide their regret on seeing their torment. We shall chain the necks of the disbelievers. Can they be recompensed with other than what they deserved for their deeds?

# 3640

Every time We sent a warner to a town, the rich ones therein said (to Our Messenger), "We have no faith in what you have brought (to us).

# 3641

We are the ones who have more wealth and children and we shall suffer no punishment".

# 3642

Say, "My Lord increases and determines the sustenance of whomever He wants, but most people do not know."

# 3643

Your property and children cannot bring you closer to Us. Only those who believe and act righteously will have double reward for their deeds and will live in secure mansions.

# 3644

Those who try to challenge Our revelations will be driven into torment.

# 3645

Say, "It is my Lord who determines and increases the sustenance of whomever He wants. He will replace whatever you spend for His cause and He is the best Sustainer."

# 3646

On the day when God will rise them all together and ask the angels, "Had these people been worshipping you?"

# 3647

They will reply, "All glory belongs to you. You are our guardian, not they. They had been worshipping the jinn and most of them had strong faith".

# 3648

None of them can help or harm each other on this day. We shall tell the unjust ones, "Suffer the torment of the fire which you had called a lie."

# 3649

When Our illustrious revelations are recited to them, they say, "This man only wants to prevent you from worshipping what your father's had worshipped." They say "This, (the Quran), is a mere invented lie." The unbelievers have said about the truth when it came to them, "This only is plain magic."

# 3650

We did not send to them, (the pagans), any books to study nor a Messenger to warn them, and those who lived before them had rejected the Truth.

# 3651

These people have not one tenth of power or wealth that we had given to those who lived before them. They called Our Messengers liars. Thus, how terrible was My vengeance.

# 3652

Say, "I advise you to believe only in One God and worship Him individually or two people together." Think carefully; your companion is not possessed by jinn. He is only warning you of the coming severe torment.

# 3653

Say, "Whatever reward I ask you (for my preaching) will be for your own good. No one can reward me except God. He is the Witness over all things."

# 3654

Say, "My Lord speaks the Truth. He has the knowledge of the unseen".

# 3655

Say, "The truth has come. Falsehood has vanished and it will not come back again".

# 3656

Say, "If I go astray it will only be against my own soul, but if I receive guidance, it will be through my Lord's revelations." He is All-hearing and Omnipresent.

# 3657

Would that you could see how the unbelievers will be terrified by death from which they cannot escape. They will be seized from a nearby place

# 3658

and then they will say, "We have faith in the Quran." How can they have any faith when they are far away from this world.

# 3659

They had rejected it in their worldly life and expressed disbelief at the unseen (Day of Judgment), considering it less than a remote possibility.

# 3660

A gulf will exist between them and their desires on the Day of Judgment like the similar people who lived before. They, too, had lived in doubt and uncertainty (about the life hereafter).

# 3661

All praise belongs to God, the creator of the heavens and the earth who has made the angels Messengers of two or three or four wings. He increases the creation as He wills. God has power over all things.

# 3662

No one can withhold whatever mercy God grants to the human being, nor can one release whatever He withholds. He is Majestic and All-wise.

# 3663

People, remember the bounty of God that He has granted to you. Is their any creator besides God who could provide you with sustenance from the heavens and the earth? He is the only God. Where then can you turn away?

# 3664

If they reject you, other Messengers had certainly been rejected before you. All decisions are in the hands of God.

# 3665

People, the promise of God is true. Let not the worldly life deceive you. Let not the devil deceive you about God

# 3666

Satan is your enemy. Thus, consider him as your enemy. His party only calls you to make you the dwellers of the burning fire.

# 3667

The unbelievers will suffer a severe torment, but the righteously striving believers will receive forgiveness and a great reward.

# 3668

Can one whose evil deeds seem attractive and virtuous to him (be compared to a truly righteous person)? God guides or causes to go astray whomever He wants. (Muhammad), do not be grieved because of their disbelief. God knows well whatever they do.

# 3669

It is God who sends the winds to raise the clouds. We then drive them unto barren areas and revive the dead earth. (The Resurrection) will also be executed in the same way.

# 3670

Whoever seeks honor should know that all honor belongs to God. Good words (worship) will be presented before Him and He will accept good deeds. Those who make evil plans will suffer intense torment. Their evil plans are doomed to destruction.

# 3671

God created you from clay which He then turned into a living germ and made you into pairs. No female conceives or delivers without His knowledge. No one grows older nor can anything be reduced from one's life without having its record in the Book. This is not at all difficult for God.

# 3672

The two oceans, one sweet and the other salty, are not alike. From each you can eat fresh meat and obtain ornaments to use. You see ships ploughing their way through them so that you may seek His favor and give Him thanks.

# 3673

He causes the night to enter into the day and the day to enter into the night. He has made subservient to Himself the sun and moon, each moving in an orbit for an appointed time. Such is God, your Lord, to whom belongs the kingdom. Those whom you worship besides Him do not posses even a single straw.

# 3674

They will not listen to your prayers if you pray to them. Even if they would listen, they would not be able to answer you. On the Day of Judgment they will reject your worship of them. Not even an expert reporter can tell you the truth in the way that God can do.

# 3675

People, you are always in need of God and God is Self-sufficient and Praiseworthy.

# 3676

He could replace you by a new creation if He decided to.

# 3677

This would not cost God dear at all.

# 3678

No one will bear the burden of another. Even if an overburdened soul should ask another to bear a part of his burden, no one, not even a relative, will do so. (Muhammad), you can only warn those who have fear of their Lord without seeing Him and who are steadfast in prayer. Whoever purifies himself, does so for his own good. To God do all things return.

# 3679

The blind and the seeing are not alike

# 3680

nor are darkness and light

# 3681

nor shade and heat

# 3682

nor are the living and the dead. God makes to listen whomever He wants. (Muhammad), you cannot make people in the graves to listen.

# 3683

You are simply a warner.

# 3684

We have sent you in all truth as a bearer of glad news and a warner. No nation who lived before was left without a warner.

# 3685

If they reject you, (know that) others who lived before them had also rejected their Messengers, Messengers who had brought them miracles, scriptures, and the enlightening Book

# 3686

so I seized the unbelievers and how terrible was their torment.

# 3687

Have you not seen that God has sent water down from the sky, has produced fruits of various colors, and has made streaks of various colors in the mountains, white, red, and intense black.

# 3688

He has also created people, beasts, and cattle of various colors. Only God's knowledgeable servants fear Him. God is Majestic and All-pardoning.

# 3689

Those who recite the Book of God, who are steadfast in prayer and, who spend out of what We have given them for the cause of God, both in public and in private, have hope in an indestructible bargain

# 3690

and in receiving their reward from God and in further favors. He is All-forgiving and All-appreciating.

# 3691

Whatever We have revealed to you from the Book is all truth. It confirms what was revealed before. God sees His servants and is All-aware of them.

# 3692

We gave the Book as an inheritance to Our chosen servants, among whom some are unjust against their souls, some are moderate, and some are exceedingly virtuous by the permission of God. This is indeed a great favor.

# 3693

They will enter the gardens of Eden wherein they will be decked with bracelets of gold, pearls, and silk garments.

# 3694

They will say, "It is only God who deserves all praise. He has removed all of our suffering. Our Lord is certainly All-forgiving and All-appreciating.

# 3695

It is He who has granted us, through His favor, an everlasting dwelling wherein we shall experience no hardship nor any fatigue."

# 3696

The unbelievers will dwell in hell. It will not be decreed for them to die nor will their torment be relieved. Thus do We recompense the ungrateful ones.

# 3697

Therein they will cry-out, "Lord, take us out of here. We shall act righteously and behave different to what we did before." They will be told, "Did We not allow you to live long enough for you to seek guidance? Did We not send a warner to you? Suffer (the torment). There is no one to help the unjust."

# 3698

God has knowledge of whatever is unseen in the heavens and the earth. He knows best what the hearts contain.

# 3699

It is He who has made you each other's successors on earth. Whoever disbelieves, does so against his own self. The disbelief of the unbelievers will only increase the anger of their Lord and will only cause them greater loss.

# 3700

(Muhammad), ask them, "Think about the idols which you worship besides God. Show me what part of the earth they have created. Do they have any share in the heavens? Has God sent them a Book to confirm their authority? In fact, whatever the unjust promise each other is nothing but deceit."

# 3701

God prevents the heavens and the earth from falling apart. If they do fall apart, then, no one besides Him can restore them. He is All-forbearing and All-forgiving.

# 3702

They solemnly swear that if a warner were to come to them, they would certainly have been better guided than any other nation. But when a warner came to them, it only increased their hatred

# 3703

because of their pride in the land and their evil plots. Evil plots only affect the plotters. Do they expect anything other than (God's) tradition (torment) with those who lived before. You will never find any change in the tradition of God nor will you find any alteration in it.

# 3704

Have they not travelled (sufficiently) through the land to see how terrible was the end of the mightier people who lived before them. Nothing in the heavens or the earth can challenge God. God is All-knowing and All-powerful.

# 3705

Were God to punish people for their deeds immediately, not one creature would have survived on earth. However, He has given them a respite for an appointed time and when their term comes to an end, let it be known that God watches over His servants.

# 3706

I swear by Ya Sin

# 3707

and the Quran, the Book of wisdom,

# 3708

that you (Muhammad) are a Messenger

# 3709

and that you follow the right path.

# 3710

This is a revelation sent down from the Majestic and All-merciful

# 3711

so that you may warn a people who are unaware because their fathers were not warned.

# 3712

(I swear) that most of them are doomed to be punished. They have no faith.

# 3713

We have enchained their necks up to their chins. Thus, they cannot bend their heads (to find their way).

# 3714

We have set-up a barrier in front of and behind them and have made them blind. Thus, they cannot see.

# 3715

Whether you warn them or not, they will not believe.

# 3716

You should only warn those who follow the Quran and have fear of the Beneficent God without seeing Him. Give them the glad news of their receiving forgiveness and an honorable reward (from God).

# 3717

It is We who bring the dead to life and records the deeds of human beings and their consequences (of continual effects). We keep everything recorded in an illustrious Book.

# 3718

Tell them the story of the people of the town to whom Messengers came.

# 3719

We sent them two Messengers whom they rejected. We supported them by sending a third one who told the people, "We are the Messengers (of God) who have been sent to you".

# 3720

The people said, "You are mere mortals like us and the Beneficent God has sent nothing. You are only liars."

# 3721

They said, "Our Lord knows that We are Messengers

# 3722

who have been sent to you. Our only duty is to preach clearly to you".

# 3723

The people said, "We have ill omens about you. If you will not desist, we shall stone you and make you suffer a painful torment".

# 3724

The Messengers said, "This ill omen lies within yourselves. Will you then take heed? In fact, you are a transgressing people."

# 3725

A man came running from the farthest part of the city saying, "My people, follow the Messengers.

# 3726

Follow those who do not ask you for any reward and who are rightly guided.

# 3727

"Why should I not worship God who has created me? To him you will all return.

# 3728

Should I worship other gods besides Him? If the Beneficent God was to afflict me with hardship, the intercession of the idols can be of no benefit to me nor could it rescue me from hardship.

# 3729

(Had I worshipped things besides God, I would have been in manifest error).

# 3730

Messengers, listen to me. I believe in your Lord."

# 3731

(Having been murdered by the disbelievers) he was told to enter paradise

# 3732

(wherein he said), "Would that people knew how my Lord has granted me forgiveness and honor".

# 3733

We did not send an army against his people from the heaven after his death nor did We need to send one.

# 3734

It was only a single blast which made them extinct.

# 3735

Woe to human beings! Whenever a Messenger came to them, they mocked him.

# 3736

Have they not seen how many generations, living before them, had We destroyed and they cannot ever come back to them?

# 3737

They will all be brought into Our presence together.

# 3738

Evidence (of the truth) for them is how We revived the dead earth

# 3739

and produced therein grains from which they eat and established therein gardens of palms trees and vineyards and have made streams flow therein

# 3740

so that they may consume the fruits and whatever their hands prepare. Will they not then be grateful?

# 3741

All glory belongs to the One Who has created pairs out of what grow from the earth, out of their soul and out of that which they do not know.

# 3742

Of the signs for them is how We separated the day from the night and thus they remained in darkness;

# 3743

how the sun moves in its orbit and this is the decree of the Majestic and All-knowing God;

# 3744

how We ordained the moon to pass through certain phases until it seems eventually to be like a bent twig;

# 3745

how the sun is not supposed to catch-up with the moon, nor is the night to precede the day. All of them are to float in a certain orbit;

# 3746

how We carried them and their offspring inside the laden Ark

# 3747

and created for them similar things to ride.

# 3748

Had We wanted, We could have drowned them and nothing would have been able to help or rescue them

# 3749

except Our mercy which could enable them to enjoy themselves for an appointed time.

# 3750

Whenever they are told to guard themselves against sin and the forth coming torment so that perhaps they could receive mercy

# 3751

and whenever a revelation out of their Lord's revelations comes to them, they ignore it.

# 3752

When they are told to spend for the cause of God out of what He has provided for them for their sustenance, the disbelievers say to the believers, "Should we feed those whom God has decided to feed? You are in plain error."

# 3753

The unbelievers say, "When will the Day of Judgment come if what you say is at all true?"

# 3754

They will not have to wait long. When the Day of Judgment comes, it will only take a single blast of sound to strike them while they are quarrelling with one another.

# 3755

Then they will not be able to make a will or return to their families.

# 3756

When the trumpet is sounded, they will be driven out of their grave into the presence of their Lord.

# 3757

They will say, "Woe to us! Who has raised us up from our graves? This is what the Beneficent God has promised. The Messengers have also spoke the truth".

# 3758

Only after a single blast of sound, they will all be brought into Our presence.

# 3759

No soul will be in the least bit wronged on that Day and no one will receive any recompense other than what he deserves for his deeds.

# 3760

The dwellers of Paradise on that day will enjoy themselves.

# 3761

They and their spouses will recline on couches in the shade therein.

# 3762

They will have fruits and whatever they desire.

# 3763

"Peace be with you," will be a greeting for them from the Merciful Lord.

# 3764

(The Lord will command), "Criminals, stand away from the others on this day."

# 3765

Children of Adam, did We not command you not to worship satan. He was your sworn enemy.

# 3766

Did We not command you to worship Me and tell you that this is the straight path?"

# 3767

Satan misled a great multitude of you. Did you not have any understanding?

# 3768

This is hell with which you were threatened.

# 3769

Suffer therein on this day for your disbelief.

# 3770

We shall seal your mouths on that Day, let your hands speak to us and your feet testify to what you had achieved.

# 3771

We could have blinded them had We wanted. Then they would have raced along to cross the Bridge but how could they have seen (their way)?

# 3772

We could have turned them into other creatures on the spot had We wanted and they would not have been able to precede or turn back.

# 3773

The physical growth of those whom We grant a long life will be reversed. Will you then not understand?

# 3774

We did not teach him (Muhammad) poetry, nor was he supposed to be a poet. It is only the word (of God) and the illustrious Quran

# 3775

by which he may warn those who are living and may let the words of God come true against the unbelievers.

# 3776

Have they not seen what We have created from the labor of Our own hands? We have given them cattle.

# 3777

We have made the cattle subservient to them so they ride and consume them.

# 3778

From cattle they get milk and other benefits. Will they not then give thanks?

# 3779

They chose idols besides God in the hope of receiving help from them, but they will not be able to help them.

# 3780

Instead, the disbelievers will be brought into the presence of God as the soldiers of the idols.

# 3781

Muhammad, let not their words annoy you. We certainly know whatever they conceal or reveal.

# 3782

Has the human being not considered that We have created him from a drop of fluid. He is openly quarrelsome.

# 3783

He questions Our Resurrection of him, but has forgotten his own creation. He has said, "Who will give life to the bones which have become ashes?"

# 3784

(Muhammad), tell him, "He who gave them life in the first place will bring them back to life again. He has the best knowledge of all creatures.

# 3785

He has created fire for you out of the green tree from which you can kindle other fires.

# 3786

Is the One who has created the heavens and the earth not able to create another creature like the human being? He certainly has the power to do so. He is the Supreme Creator and is All-knowing.

# 3787

Whenever He decides to create something He has only to say, "Exist," and it comes into existence.

# 3788

All glory belongs to the One in whose hands is the control of all things. To Him you will all return.

# 3789

I swear by (the angels) who stand in ranks,

# 3790

by those who drive away the devil (to protect Our revelation),

# 3791

and those who recite Our revelations,

# 3792

that your Lord is the only Lord.

# 3793

He is the Lord of the heavens and the earth and all that is between them, the Lord of the Eastern regions.

# 3794

We have decked the lower heavens with stars

# 3795

to protect them from the rebellious satan.

# 3796

The devils cannot hear those high above. They would be struck from all sides

# 3797

and driven away to suffer the necessary torment.

# 3798

Some of them who stealthily steal words from the heavens are pursued by a glistening flame.

# 3799

(Muhammad), ask them, "Have they (people) been created stronger than what We have created?" We have created them from moist clay.

# 3800

(Muhammad), you will be surprised that they still mock (God's revelations).

# 3801

They pay no attention when they are reminded

# 3802

and when they see a miracle, they mock

# 3803

it and say, "It is only plain magic".

# 3804

They say, "Shall we be brought to life again after we die and turn into dust and bones?

# 3805

Will our forefathers also be brought to life again?"

# 3806

Say, "You will certainly be brought back to life in disgrace".

# 3807

The Day of Judgment will come within a single roar and they will remain gazing at it.

# 3808

They will say, "Woe to us!" (They will be told), "This is the day of receiving recompense".

# 3809

This is the Day of Judgment in which you disbelieved.

# 3810

(God will command the angels), "Gather together the unjust, their spouses, and what they had worshipped

# 3811

besides God, and show them the way of hell.

# 3812

Stop them. They must be questioned."

# 3813

They will be asked, "Why do you not help each other?"

# 3814

In fact, on that day they will be submissive.

# 3815

They will turn to each other saying,

# 3816

"It was you who tried to mislead us from righteousness".

# 3817

Others will respond, "It was you who did not want to have any faith.

# 3818

We had no authority over you, in fact, you were a rebellious people.

# 3819

Thus, the words of Our Lord about us have come true and now we are suffering the torment.

# 3820

We mislead you and we ourselves had also gone astray."

# 3821

On that day they will all share the torment.

# 3822

This is how We deal with the criminals.

# 3823

They were the ones, who on being told, "God is only One," become puffed-up with pride

# 3824

and said, "Should we give up our idols for the sake of an insane poet".

# 3825

In fact, he had brought them the truth and had acknowledged the Messengers (who were sent before him).

# 3826

(They will be told), "You will certainly suffer the painful torment

# 3827

and will be recompensed only for what you deserve.

# 3828

But the sincere servants of God

# 3829

will have their determined sustenance

# 3830

and fruits while they are honored.

# 3831

(They will live) in the bountiful gardens,

# 3832

on couches facing each other.

# 3833

They will be served with a cup full of crystal clear wine,

# 3834

delicious to those who drink it

# 3835

but not harmful or intoxicating.

# 3836

They will have with them loving wives with big black and white eyes

# 3837

who are as chaste as sheltered eggs.

# 3838

They will turn to each other and ask questions.

# 3839

One of them will say, "I had a companion who asked me,

# 3840

'Do you believe in the Day of Judgment?

# 3841

Shall we be recompensed for our deeds after we die and become bones and dust?

# 3842

Do you want to see him?' "

# 3843

He will look down and see him in hell.

# 3844

He will say to his friend in hell, "By God, you almost destroyed me.

# 3845

Had I not the guidance of my Lord, I would certainly have been brought into torment".

# 3846

He will ask his companion, "Did you not say that there would only be one death

# 3847

and that we would not be punished?"

# 3848

This is certainly the greatest triumph

# 3849

for which one must strive hard.

# 3850

Is this not a better reward than the tree of Zaqqum

# 3851

which We have made as a torment for the unjust?

# 3852

(Zaqqum) is a tree which grows from the deepest part of hell,

# 3853

and its fruits are like the heads of devils.

# 3854

The dwellers of hell will eat that fruit and fill-up their bellies.

# 3855

Then they will have on top of it a mixture of boiling water.

# 3856

They can only return to hell.

# 3857

They found their father going astray

# 3858

and rushed to follow them.

# 3859

Most of the ancient people had also gone astray.

# 3860

We had certainly sent warners to them.

# 3861

See how terrible was the end of those who were warned.

# 3862

Only Our sincere servants were saved.

# 3863

Noah called for help. How blessed was the answer which he received.

# 3864

We rescued him and his people from the greatest affliction

# 3865

and We made his offspring the only survivors.

# 3866

We perpetuated his praise in later generations.

# 3867

Peace be with Noah among all men in the worlds.

# 3868

Thus do We reward the righteous ones.

# 3869

He was one of Our believing servants.

# 3870

We drowned all the others (besides Noah and his people).

# 3871

Abraham was one of his followers.

# 3872

He turned to his Lord with a sound heart

# 3873

and asked his father and his people, "What is that you worship?

# 3874

Do you want to worship false idols as your lords besides God?

# 3875

What do you think about the Lord of the Universe?"

# 3876

The people invited him to attend their feast). Then he looked at the stars

# 3877

and said, "I am sick!"

# 3878

All the people turned away from him

# 3879

and he turned to their idols and asked them, "Do you eat?

# 3880

Why do you not speak?"

# 3881

He struck them with his right hand.

# 3882

Thereupon the people came running to him.

# 3883

He said, "How can you worship what you yourselves have carved

# 3884

even though God created both you and that which you have made?"

# 3885

They said, "Let us build a fire and throw him into the flames".

# 3886

They plotted against him, but We brought humiliation upon them.

# 3887

(Abraham) said, "I will go to my Lord who will guide me".

# 3888

Abraham prayed, "Lord, grant me a righteous son".

# 3889

We gave him the glad news of the birth of a forbearing son.

# 3890

When his son was old enough to work with him, he said, "My son, I have had a dream that I must sacrifice you. What do you think of this?" He replied, "Father, fulfill whatever you are commanded to do and you will find me patient, by the will of God".

# 3891

When they both agreed and Abraham had lain down his son on the side of his face (for slaughtering),

# 3892

We called to him, "Abraham,

# 3893

you have fulfilled what you were commanded to do in your dream." Thus do We reward the righteous ones.

# 3894

It was certainly an open trial.

# 3895

We ransomed his son with a great sacrifice

# 3896

and perpetuated his praise in later generations.

# 3897

Peace be with Abraham.

# 3898

Thus, do We reward the righteous ones.

# 3899

He was one of Our believing servants.

# 3900

We gave him the glad news of the birth of Isaac, one of the righteous Prophets.

# 3901

We had blessed him and Isaac. Some of their offspring were righteous and others were openly unjust to themselves.

# 3902

We certainly bestowed Our favor upon Moses and Aaron

# 3903

and saved them and their people from great distress.

# 3904

We helped them and they were victorious.

# 3905

We gave them the enlightening Book,

# 3906

guided them to the right path,

# 3907

and perpetuated their praise in later generations.

# 3908

Peace be with Moses and Aaron.

# 3909

Thus do We reward the righteous ones.

# 3910

They were two of Our believing servants.

# 3911

Elias was certainly a Messenger.

# 3912

He told his people, "Why do you not have fear of God?

# 3913

Do you worship Ba\`al and abandon the Best Creator.

# 3914

who is your Lord and the Lord of your forefathers?"

# 3915

They called him a liar. Thus, all of them will suffer torment

# 3916

except the sincere servants of God.

# 3917

We perpetuated his praise in the later generations.

# 3918

Peace be with the followers of Elias.

# 3919

In this way do We reward the righteous ones.

# 3920

He was one of Our believing servants.

# 3921

Lot was certainly a Messenger.

# 3922

We rescued him and his whole family,

# 3923

except for an old woman who remained behind.

# 3924

Then We totally destroyed the others.

# 3925

You pass by (their ruined town) in the morning and at night.

# 3926

Will you then not understand?

# 3927

Jonah was certainly a Messenger.

# 3928

He abandoned his people

# 3929

and sailed away in a laden ship, wherein people cast lots. Because he lost, he was thrown into the water.

# 3930

The fish swallowed him up and he deserved (all this).

# 3931

Had he not glorified God,

# 3932

he would certainly have remained inside the fish until the Day of Resurrection.

# 3933

We cast him out of the fish unto dry land and he was sick.

# 3934

We made a plant of gourd grow up for him.

# 3935

We sent him to a hundred thousand or more people.

# 3936

They believed in him so We granted them enjoyment for an appointed time.

# 3937

(Muhammad), ask them, "Do daughters belong to your Lord and sons to them?

# 3938

Have We created the angels as females before their very eyes?

# 3939

It is only because of their false invention that they say,

# 3940

'God has begotten a son.' They are certainly liars.

# 3941

Has He chosen daughters in preference to sons?

# 3942

Woe to you! How terrible is your Judgment.

# 3943

Do you not understand?

# 3944

Do you have clear authority?

# 3945

Bring your book if what you say is true.

# 3946

They have said that there is a relationship between Him and the jinn. The jinn certainly know that they will all be brought to suffer torment.

# 3947

God is too glorious to be described as they describe Him

# 3948

except the servants of God, sincere and devoted.

# 3949

You and whatever you worship

# 3950

cannot mislead anyone

# 3951

except those who are doomed to enter hell.

# 3952

The angels say, "Each of us has an appointed place.

# 3953

We stand in ranks (for prayer)

# 3954

and we glorify God".

# 3955

Even though they (unbelievers) say,

# 3956

"Had we received guidance from the people living before us,

# 3957

we would have certainly been sincere servants of God".

# 3958

They have rejected the Quran. They will soon know the consequences (of their disbelief).

# 3959

We decreed that Our Messenger servants

# 3960

will certainly be victorious

# 3961

and that Our army will be triumphant.

# 3962

(Muhammad), stay away from them for a while

# 3963

and watch them. They, too, will watch.

# 3964

Do they want to suffer Our torment immediately?

# 3965

When it descends into their courtyard, it will be terrible for those who have already been warned.

# 3966

Stay away from them for a while

# 3967

and watch. They, too, will watch.

# 3968

Your Lord, the Lord of Honor, is too exalted to be considered as they describe Him.

# 3969

Peace be with the Messengers (of God).

# 3970

It is only God, the Lord of the Universe, who deserves all praise.

# 3971

Sad. I swear by the Quran, which is full of reminders of God, (that you are a Messenger).

# 3972

In fact, the unbelievers are the ones who are boastful and quarrelsome.

# 3973

How many ancient generations did We destroy? (On facing Our torment) they cried out for help, but it was too late for them to escape.

# 3974

It seems strange to the pagans that a man from their own people should come to them as a Prophet. The unbelievers have said, "He is only a lying magician".

# 3975

They say, "Has he condemned all other gods but One? This is certainly strange".

# 3976

A group of the pagans walked out of a meeting with the Prophet and told the others, "Let us walk away. Be steadfast in the worship of your gods. This man wants to dominate you.

# 3977

We have heard nothing like this in the latest religion. This is only his own false invention.

# 3978

Can it be that he alone has received the Quran?" In fact, they have doubts about My Quran and this is because they have not yet faced (My) torment.

# 3979

Do they possess the treasures of the mercy of your, (Muhammad's), Lord, the Majestic and Munificent God?

# 3980

Do they own the heavens and the earth and all that is between them? Let them try on their own to block (the ways of heavens so that Our revelations cannot come to you).

# 3981

They are only a small band among the defeated confederate tribes.

# 3982

The people of Noah, Ad and the dominating Pharaoh had rejected Our revelations.

# 3983

So also did the people of Thamud, Lot, and the dwellers of the Forest.

# 3984

Each of them who rejected the Messenger become subject to Our punishment.

# 3985

They had only to wait for the single inevitable blast.

# 3986

They scornfully said, "Lord, show us the record of our deeds before the day when everyone must present the account of their deeds.".

# 3987

(Muhammad), bear patiently what they say and recall Our servant, David, who had strong hands and who was most repentant.

# 3988

We made the mountains join him in glorifying Us in the evening and in the morning.

# 3989

We made the birds assemble around him in flocks.

# 3990

We strengthened his kingdom, giving him wisdom and the power of sound Judgment.

# 3991

Have you heard the news of the disputing parties who climbed the walls of the prayer room

# 3992

and entered where David was (praying). He was frightened, so they said, "Do not be afraid. We are only two disputing parties of which one of us has transgressed against the other. Judge between us with truth and justice and guide us to the right path".

# 3993

One of them said, "This is my brother who has ninety-nine ewes when I have only one. He has demanded me to place that one in his custody; he had the stronger argument".

# 3994

David said, "He has certainly been unjust in demanding your ewe from you. Most partners transgress against each other except for the righteously striving believers who are very few." David realized that it was a test from Us so he asked forgiveness from his Lord and knelt down before him in repentance.

# 3995

We forgave him for this. In Our eyes he certainly has a good position and the best share (of the world to come).

# 3996

We told him. "David, We have appointed you as Our deputy on earth so judge among the people with truth. Do not follow (worldly) desires lest you go astray from the way of God. Those who go astray from the way of God will suffer severe torment for forgetting the Day of Reckoning.

# 3997

We have not created the heavens and the earth and all that is between them without purpose, even though this is the belief of the disbelievers. Woe to the disbelievers; they will suffer the torment of fire

# 3998

Do We consider the righteously striving believers equal to the evil-doers in the land? Are the pious ones equal to those who openly commit sin?

# 3999

It is a blessed Book which We have revealed for you so that you will reflect upon its verses and so the people of understanding will take heed.

# 4000

We granted Solomon to David, a blessed servant of Ours and certainly the most repentant person.

# 4001

When the noble galloping horses were displayed to him one evening,

# 4002

he said, "My love of horses for the cause of God has made me continue watching them until sunset, thus making me miss my prayer".

# 4003

He said, "Bring them back to me." Then he started to rub their legs and necks.

# 4004

We tested Solomon by (causing death to his son) and leaving his body on Solomon's chair. Then he turned to Us in repentance,

# 4005

saying, "Lord, forgive me and grant me a kingdom that no one after me can have the like. You are All-munificent".

# 4006

We made the wind subservient to him, to blow gently wherever he desired at his command

# 4007

and all the devils who built and dived for him.

# 4008

The rest of the devils were bound in chains.

# 4009

We told him, "This is Our gift to you so give them away free or keep them as you like".

# 4010

In Our eyes he certainly has a high position and the best place to return.

# 4011

(Muhammad), recall Our servant Job. When he prayed to his Lord saying, "Satan has afflicted me with hardship and torment,"

# 4012

(We answered his prayer, healed his sickness, and told him), "Run on your feet. This is cool water (for you) to wash and drink".

# 4013

We gave him back his family and doubled their number as a blessing from Us and as a reminder to the people of understanding.

# 4014

We told him, "Take a handful of straw. Strike your wife with it to fulfill your oath." We found him to be patient. What an excellent servant he was. He was certainly most repenting.

# 4015

(Muhammad), recall Our servants Abraham, Isaac, and Jacob, all of whom possessed virtuous hands and clear visions.

# 4016

We gave them this pure distinction because of their continual remembrance of the Day of Judgment.

# 4017

In Our eyes they were of the chosen, virtuous people.

# 4018

Recall Ismael, Elisha, and Dhulkifl (Ezekiel) who were all virtuous people.

# 4019

Such is their noble story. The pious ones will certainly have the best place to return.

# 4020

They will enter gardens of Eden with their gates open for them.

# 4021

They will be resting therein and will be able to ask for many kinds of fruit and drink.

# 4022

They will have bashful wives of equal age with them.

# 4023

This is what they had been promised for the Day of Judgment.

# 4024

Our provision (for you) will never be exhausted.

# 4025

However, the rebellious ones will have the worst place to return.

# 4026

They will suffer in hell. What a terrible dwelling!

# 4027

(They will be told), "This is your recompense.

# 4028

Taste the scalding water, pus, and other putrid things".

# 4029

Their leaders will be told, "This band will also be thrown headlong with you into hell." Their leaders will exclaim, "May condemnation fall upon them! Let them suffer the torment of fire".

# 4030

Their followers will say, "In fact, it is you who deserve condemnation. It was you who led us to hell, a terrible dwelling".

# 4031

They will continue saying, "Lord, double the torment of fire for those who led us into this.

# 4032

But why is it that we cannot see men whom we had considered as wicked

# 4033

and whom we mocked? Have they been rescued or can our eyes not find them?"

# 4034

Such disputes will certainly take place among the dwellers of hell fire.

# 4035

(Muhammad) say, "I am only a warner. The only Lord is God, the Almighty.

# 4036

He is the Lord of the heavens, the earth, and all that is between them, the Majestic and All-forgiving".

# 4037

Say, "It (facts about the supremacy of God) is the greatest message,

# 4038

but you have turned away from it.

# 4039

I have no knowledge of the dispute among the angels (concerning their attitude towards Adam).

# 4040

I have only received revelation to give you plain warning.

# 4041

When your Lord told the angels, "I will create a mortal out of clay,

# 4042

and when I give it proper shape and blow My spirit into it, bow down in prostration to him,"

# 4043

all the angel then prostrated themselves

# 4044

except Iblis who puffed himself up with pride and became a disbeliever.

# 4045

The Lord said, "Iblis, what prevented you from prostrating before what I have created with My own hands? Was it because of your pride or are you truly exalted?"

# 4046

He said, "I am better than him. You have created me from fire and him out of clay".

# 4047

The Lord said, "Get out of here. You deserve to be stoned!

# 4048

My condemnation will be with you until the Day of Judgment!"

# 4049

He said, "Lord, grant me respite until the Day of Resurrection".

# 4050

The Lord said, "You will only be given a respite

# 4051

for an appointed time".

# 4052

He said, "By Your Glory, I shall seduce all of them (children of Adam).

# 4053

except Your sincere servants among them".

# 4054

The Lord said, "I swear by the Truth - and I speak the Truth -

# 4055

that I shall certainly fill hell with you and your followers all together".

# 4056

(Muhammad), say, "I do not ask any reward for my preaching to you for I am not a pretender.

# 4057

It, (the Quran), is nothing but a reminder to you from the Lord of the Universe.

# 4058

You will certainly know its truthfulness after a certain time.

# 4059

This Book is a revelation from God, the Majestic and All-Wise.

# 4060

We have revealed the Book to you in all truth. Worship God and be devoted to His religion.

# 4061

The religion of God is certainly pure. Concerning those whom they consider as their guardians besides God, they say, "We only worship them so that they may make our positions nearer to God." God will certainly issue His decree about their differences. God does not guide the liars and the disbelievers.

# 4062

Had God wanted to have a son, He would have chosen one from His creatures according to His will. God is too Exalted to have a son. He is One and Almighty.

# 4063

He has created the heavens and the earth for a genuine purpose. He covers the night with the day and the day with the night and has subdued the sun and the moon, each of which floats for an appointed time. God is certainly Majestic and All-Forgiving.

# 4064

He has created you from a single soul. Out of this He created your spouse. He sent you eight pairs of cattle. He creates you for a second time in the wombs of your mothers behind three curtains of darkness. He is your Lord to whom belongs the Kingdom. He is the only Lord. Where then will you turn away?

# 4065

If you disbelieve, know that God is certainly independent of you. He does not want disbelief for His servants. If you give thanks, He will accept it from you. No one will be responsible for the sins of others. To your Lord you will all return and He will tell you about what you have done. He knows best what the hearts contain.

# 4066

When the human being is afflicted with hardship, he starts to pray to his Lord and turns to Him in repentance. When God grants him a favor, he forgets the hardship about which he had prayed to God and starts to consider equal to God things that lead him astray from His path. (Muhammad), tell him, "You can only enjoy in your disbelief for a short time. You will certainly be a dweller of hell fire".

# 4067

Can this one be considered equal to one who worships God during the night, prostrating and standing, who has fear of the Day of Judgment, and who has hope in the mercy of his Lord? Say, "Are those who know equal to those who do not know? Only the people of reason take heed".

# 4068

Say to My believing servants, "Have fear of your Lord. Those who act righteously in this life will receive good reward. The land of God is vast. God will recompense the deeds of those who have exercised patience, without keeping an account".

# 4069

Say, "I am commanded to worship God and be devoted to His religion

# 4070

and I am commanded to be the first Muslim".

# 4071

Say, "I am afraid that for disobeying my Lord I shall suffer the torment of the great day".

# 4072

Say, "I worship God alone and devote myself to His religion.

# 4073

Worship besides Him whatever you want. The greatest losers are those whose souls and family members will be lost on the Day of Judgment for this is certainly a great loss".

# 4074

Above and below them their will be shadows of fire. This is how God frightens His servants. My servants have fear of Me.

# 4075

Those who have avoided worshipping idols and have turned in repentance to God will receive the glad news.

# 4076

(Muhammad), give the glad news to those of Our servants who listen to the words and only follow the best ones. Tell them that they are those whom God has guided. They are the people of understanding.

# 4077

How can you rescue the one who is destined to suffer the torment?

# 4078

Those who have fear of their Lord will have lofty mansions built upon mansions beneath which streams flow. It is the promise of God. God does not disregard His promise.

# 4079

Have you not seen that God has sent down water from the sky and made it flow as springs out of the earth? He makes crops of different colors grow with this water and flourish, which then turn yellow and wither away. In this there is a reminder for the people of understanding.

# 4080

One whose chest (heart and mind) is left open for Islam (submission to His will) shall receive light from God. Woe to those whose hearts have become like stone against the remembrance of God. They are clearly in error.

# 4081

God has revealed the best reading material in the form of a Book with similar passages which refer to each other and make the skins of those who fear their Lord shiver. Then their skins and hearts incline to the remembrance of God. This is the guidance of God. He guides whomever He wants. No one can guide those whom God has caused to go astray.

# 4082

Is there anyone who is afraid of the torment of the Day of Judgment when the unjust will be told, "Suffer the result of your deeds?"

# 4083

Those who lived before them had also rejected Our revelations. Thus, the torment struck them and they did not even realize where it came from.

# 4084

God made them suffer humiliation in this life. Would that they knew that the torment for them in the next life will be even greater.

# 4085

We have given all kinds of examples for the human being in this Quran so that perhaps he may take heed.

# 4086

This Quran is a flawless reading text in the Arabic language. Perhaps they will have fear of God.

# 4087

God tells a parable in which there is a company of quarrelsome people and only one of them is well disciplined. Can they be considered as equal? It is only God who deserves all praise. In fact, most of them do not know.

# 4088

(Muhammad), you will die and all of them will also die.

# 4089

Then, on the Day of Judgment, all of you will present your disputes before your Lord.

# 4090

Who is more unjust then one who invents falsehood against God and rejects the truth after it has come to them. Is not hell a dwelling for the disbelievers?

# 4091

Those who have brought the truth and have acknowledged it are those who have fear of God.

# 4092

They will receive whatever they want from their Lord. Thus is the reward of the righteous ones.

# 4093

God will certainly expiate their bad deeds and reward them much more for what they have done.

# 4094

Is God not sufficient (support) for His servants? They frighten you with what they worship besides God. Who can guide one whom God has caused to go astray?

# 4095

Who can mislead one whom God has guided? Is God not Majestic and Revengeful?

# 4096

If you ask them, "Who has created the heavens and the earth?" They will certainly say, "God has created them." Ask them, "Do you think that you can rescue me from the punishment of God with which He may afflict me? Can you prevent His mercy if He wants to grant it to me?" Say, "God is Sufficient (support) for me. In Him alone one must trust".

# 4097

Say, "My people, act as you wish. I shall do as I like and you will soon know

# 4098

who will face the humiliating torment and suffer everlasting retribution".

# 4099

(Muhammad), We have revealed the Book to you for mankind in all truth. Whoever seeks guidance does so for his own good. Whosoever goes astray goes against his own soul. You are not their representative.

# 4100

God will receive their souls when they die. Their souls do not die when they are sleeping. During people's sleep He withholds those souls which He has decreed to die and releases the others for an appointed time. In this there is evidence (of the Truth) for the thoughtful people.

# 4101

Have they chosen intercessors besides God? Say, "Would you choose them as your intercessors even though they do not possess anything and have no understanding?"

# 4102

Say, "Intercession belongs to God. To Him belongs the heavens and the earth and to Him you will all return."

# 4103

When one God is mentioned, the hearts of those who do not believe in the Day of Judgment begin to shrink, but when the idols are mentioned, they rejoice.

# 4104

Say, "Lord, the Creator of the heavens and the earth, knower of the seen and unseen, it is You who will issue Your decree about the differences of Your servants."

# 4105

Had the unjust possessed double the amount of the wealth of the whole earth, they would certainly have liked to offer it on the Day of Resurrection as redemption from the torment of Our scourge when God would make public what they had never expected.

# 4106

Their bad deeds will become public and they will be surrounded by the torment which they had mocked during their worldly life.

# 4107

When the human being is afflicted with hardship, he cries out to us for help. When We grant him a favor, he says, "I knew that I deserved it." In fact, it is only a test for him, but most people do not know this.

# 4108

People who lived before them had also said, "Our wealth has been earned by our own merits." What they had earned was of no benefit to them

# 4109

They were afflicted by the terrible result of whatever they gained. Besides this affliction, the unjust among them will also suffer the consequence of their deeds. They will not be able to challenge God.

# 4110

Did they not know that God determines and increases the sustenance of whomever He wants. In this there is evidence (of the truth) for the believing people.

# 4111

(Muhammad), tell my servants who have committed injustice to themselves, "Do not despair of the mercy of God. God certainly forgives all sins. He is All-forgiving and All-merciful."

# 4112

Turn in repentance to your Lord and submit to His will before you are afflicted with the torment after which you can receive no help.

# 4113

Follow the best of what is revealed to you from your Lord before the torment suddenly approaches you and you will not realize how it came about.

# 4114

Turn to God in repentance before a soul says, "Woe to me because of my failure to fulfill my duties to God. Woe to me for mocking God's guidance!"

# 4115

Or before the soul says, "Had God guided me, I could have been a pious man".

# 4116

Or, on seeing the torment, it would say, "Would I have the opportunity, this time I would certainly become a pious person".

# 4117

God will reply to the soul, "My revelations had certainly come to you but you rejected them. You were puffed-up with pride and you became an unbeliever".

# 4118

On the Day of Judgment you will see the faces of those who had invented falsehood against God blackened. Is not hell the dwelling of the arrogant ones?

# 4119

God will save the pious ones because of their virtuous deeds. No hardship will touch them nor will they be grieved.

# 4120

God is the Creator and Guardian of all things.

# 4121

In His hands are the keys of the treasuries of the heavens and the earth. Those who reject God's revelations will be lost.

# 4122

(Muhammad), say, "Ignorant ones, do you command me to worship things other than God

# 4123

even though God has said, "It has been revealed to you and to those who lived before you that if you consider other things equal to God, your deeds will be made devoid of all virtue and you will certainly be lost?"

# 4124

(Muhammad), You must worship God alone and give Him thanks.

# 4125

They have not paid due respect to God. The whole earth will be gripped in His hands on the Day of Judgment and the heavens will be just like a scroll in His right hand. God is too Glorious and High to be considered equal to their idols.

# 4126

Everyone in the heavens and the earth will faint in terror except for those whom God will save when the trumpet is sounded. They will all stand up and wait when the trumpet sounds for the second time.

# 4127

The earth will become bright from the light of your Lord. The Book of Records will be presented and the Prophets and witness will be summoned. All will be judged with justice and no wrong will be done to anyone.

# 4128

Every soul will be recompensed for its deeds. God knows best whatever they have done.

# 4129

The disbelievers will be driven to hell in hordes. Its gates will be opened when they are brought nearby and the keepers will ask them, "Did Messengers from your own people not come to you to recite your Lord's revelations and to warn you about this day?" They will reply, "Yes, the Messengers did come to us, but the unbelievers were doomed to face the torment".

# 4130

They will be told, "Enter the gates of hell to live therein forever. What a terrible dwelling for the arrogant ones!"

# 4131

The pious ones will be led to Paradise in large groups. Its gates will be opened to them when they are brought nearby and its keepers will say, "Welcome! Peace be with you. Enter the gates of Paradise to live therein forever".

# 4132

They will say, "It is only God who deserves all praise. He has made His promise come true and has given the earth as an inheritance to us. Now we live in the gardens as we wished. Blessed is the reward of those who labor.

# 4133

(Muhammad), on that day you will see the angels circling around the Throne, glorifying and praising their Lord. Judgment with justice will be decreed between the people of Paradise and hell and it will be said, "It is only God, Lord of the Universe who deserves all praise."

# 4134

Ha. Mim.

# 4135

This Book is a revelation from God, the Majestic and All-knowing

# 4136

who forgives sins, who accepts repentance, whose punishment is severe, and whose bounty is universal. He is the only Lord and to Him all things proceed.

# 4137

No one disputes the revelations of the Lord except the disbelievers. Let not their activities in the land deceive you.

# 4138

The people of Noah who lived before and the Confederate tribes who lived after them rejected Our revelations. Every nation schemed against its Messengers to seize them and disputed against them to defeat the truth. But torment struck them and how terrible was their retribution!

# 4139

The word of your Lord that the disbelievers will be the dwellers of hell fire has already been decreed.

# 4140

The bearers of the Throne glorify their Lord with His praise. They believe in Him and ask Him to forgive the believers. They say, "Our Lord, Your mercy and knowledge encompass all things. Forgive those who turn to You in repentance and follow Your path. Lord, save them from the torment of hell.

# 4141

Lord, admit them and their fathers, spouses, and offspring who have reformed themselves to the gardens of Eden which You have promised them. You are Majestic and All-wise.

# 4142

Lord, keep them away from evil deeds. Whomever You have saved from evil on the Day of Judgment has certainly been granted Your mercy and this is the greatest triumph.

# 4143

The disbelievers will be told, "God's hatred towards you is much greater than your hatred of your own selves. You were called to the faith but you disbelieved".

# 4144

They say, "Lord, You have caused us to die twice and You have brought us back to life twice. We have confessed our sins, so is there any way out of this (hell)?"

# 4145

They will be answered, "Your suffering is only because you disbelieved when One God was mentioned. When other things were considered equal to Him, you believed in them. Judgment belongs to God, the Most High, the Most Great.

# 4146

It is He who has shown you the evidence of His existence and has sent you sustenance from the sky, yet only those who turn to God in repentance take heed.

# 4147

Worship God and be devoted to His religion even though the disbelievers dislike this.

# 4148

God is the promoter of His servants and the owner of the Throne. He sends His spirit by His command to whichever of His servants He wants to warn them of the Day of Judgment.

# 4149

Nothing will remain hidden from God concerning them on the day when they appear before God (from their graves) (It will be asked), "To whom does the kingdom belong on this Day?" (It will be answered), "The kingdom belongs to the Almighty One God".

# 4150

Every soul will be recompensed for its deeds on this Day. There will be no injustice. Certainly God's reckoning is swift.

# 4151

(Muhammad), warn them of the approaching day when because of hardship and frustration their hearts will almost reach up to their throats. The unjust will have no friends nor any intercessor who will be heard.

# 4152

God knows the disloyalty of the eyes and what the hearts conceal.

# 4153

God judges with Truth but those whom they worship besides God can have no Judgment. God is certainly All-hearing and All-aware.

# 4154

Have they not travelled through the land to see the terrible end of those who lived before them. They had been mightier than them in power and in leaving their traces on earth. God punished them for their sins. They had no one to save them from God's torment.

# 4155

Messengers had come to them with illustrious miracles but they disbelieved and thus God struck them with His torment. He is Mighty and Severe in His retribution.

# 4156

We sent Moses with Our miracles and clear authority.

# 4157

to the Pharaoh, Haman, and Korah, who said, "He is only a lying magician.".

# 4158

When We sent him to them for a genuine purpose, they said, "Kill the sons of those who have believed in him but keep their women alive." The plots of the unbelievers can only result in failure.

# 4159

The Pharaoh said, "Let me kill Moses and let him call for help from his Lord. I am afraid that he will change your religion or spread evil through the land.".

# 4160

Moses said, "I seek protection from your and my Lord against every arrogant person who has no faith in the Day of Judgment."

# 4161

A believing person from the people of the Pharaoh who concealed his faith said, "Would you kill a man just because he says God is my Lord? He has brought you illustrious miracles from your Lord. If he speaks lies, it will only harm him, but if he speaks the Truth, some of his warnings may affect you. God does not guide a transgressing liar.

# 4162

My people, today you have the kingdom and the power on earth but who will help us against the wrath of God if it will befall us?" The Pharaoh said, "I show you only what I think is proper and guide you only to the right direction".

# 4163

The believing man said, "I am afraid that you will face a (terrible) day like that of the groups:

# 4164

people of Noah, Ad, Thamud, and those after them. God did not want injustice for His servants.

# 4165

My people, I am afraid for you on (the Day of Judgment), when people will cry for help.

# 4166

On that day you will run away, but no one will be able to protect you from (God's Judgment). No one can guide one whom God has caused to go astray.

# 4167

Joseph came to you before with illustrious evidence but you still have doubts about what he brought. When he passed away, you said, "God will never send any Messenger after him." Thus does God causes to go astray the skeptical transgressing people,

# 4168

those who dispute the revelations of God without having received clear authority. This act greatly angers God and the believers. Thus does God seal the hearts of every arrogant oppressor."

# 4169

Pharaoh said, "Haman, build a tower of baked bricks for me so that I shall have access.

# 4170

to the heavens and be able to climb up to the Lord of Moses. I think that Moses is lying." Thus, Pharaoh's evil deeds seemed attractive to him and prevented him from the right path. The Pharaoh's plots only led him to his own destructor.

# 4171

The believing man said, "My people, follow me and I shall show you the right guidance.

# 4172

My people, this worldly life is only the means (to an end), but the life hereafter will be the everlasting abode.

# 4173

Whoever commits evil deeds will be recompensed to the same degree. The righteously striving believer, male or female, will enter Paradise wherein they will receive their sustenance without any account being kept.

# 4174

My people, "How strange is it that I invite you to salvation when you invite me to the fire.

# 4175

You call me to disbelieve in God and to believe other things equal to Him about which I have no knowledge. I call you to the Majestic and All-forgiving One.

# 4176

The idols to which you invite me certainly have no claim to be deities in this world or in the life to come. Our return is to God and the transgressors will be the dwellers of hell fire.

# 4177

You will soon recall what I have told you. I entrust God with my affairs. God is Well Aware of His servants."

# 4178

God protected him against their evil plans and the people of the Pharaoh were struck by the most horrible torment.

# 4179

They will be exposed to the fire in the mornings and the evenings and on the Day of Judgment, they will be told, "People of the Pharaoh, suffer the most severe torment."

# 4180

During a dispute in the fire, the suppressed ones will say to those who had dominated them, "We were your followers. Can you now relieve us of our suffering in the fire?"

# 4181

The ones who had dominated them will say, "All of us are now in hell. God has already issued His Judgment of His servants (and no one can change this)."

# 4182

The dwellers of hell fire will ask its keepers, "Pray to your Lord to relieve us from the torment at least for one day".

# 4183

The keepers will ask them, "Did your Messengers not come to you with illustrious evidence (of the Truth)? They will reply, "Yes, they did." The keepers will then say, "You may pray but the prayer of the disbelievers will not be answered".

# 4184

We shall help Our Messengers and the believers, in this life and on the day when witness will come forward.

# 4185

The excuses of the unjust will be of no benefit to them on that day. They will be condemned to live in a most terrible abode.

# 4186

To Moses We had given guidance and to the children of Israel We had given the Book

# 4187

as their inheritance and as a guide and a reminder to the people of understanding.

# 4188

(Muhammad), exercise patience. The promise of God is true. Seek forgiveness for your sins and glorify your Lord with His praise in the evenings and in the early mornings.

# 4189

Those who dispute the revelations of God without having received any authority do so because of their arrogance, but their arrogance cannot bring them any success. Seek protection from God for He is All-hearing and All-aware.

# 4190

The creation of the heavens and the earth is certainly greater than the creation of mankind, but most people do not know.

# 4191

Just as the blind and the seeing are not equal, so are the righteously striving believers and the sinners are not equal. How little to this you pay attention.

# 4192

The Hour of Doom will inevitably come, but most people do not have faith.

# 4193

Your Lord has said, "Pray to Me for I shall answer you prayers. Those who are too proud to worship Me will soon go to hell in disgrace".

# 4194

It is God Who has made the night for you to rest and the day for you to see. God is Benevolent to the human being, but most people do not give Him due thanks.

# 4195

It is God, your Lord, Who has created all things. He is the only Lord. Why then do you turn away from His worship to the worshipping of idols?

# 4196

Thus are indeed those who have rejected the revelations of God.

# 4197

It is God who has created the earth as a place for you to live and the sky as a dome above you. He has shaped you in the best form and has provided you with pure sustenance. This is God, your Lord. Blessed is God, the Lord of the Universe.

# 4198

He is the Everlasting and the only Lord. So worship Him and be devoted to His religion. It is only God, the Lord of the Universe who deserves all praise.

# 4199

(Muhammad), say, "I have been forbidden to worship whatever you worship besides God after receiving clear evidence from my Lord. I have been commanded to submit myself to the will of the Lord of the Universe".

# 4200

It is He Who created you from clay, turning it into a living germ, then into a clot of blood, and then brings you forth as a child. He then made you grow into manhood and become old. He causes some of you to live for the appointed time and some of you to die before so that perhaps you may have understanding.

# 4201

It is He Who gives life and causes things to die. When He decides to do something, He only says, "Exist," and it comes into existence.

# 4202

Have you not seen how those who dispute the revelations of God, turn away from Truth to falsehood?

# 4203

Those who rejected the Book and the message which was given to Our Messenger will soon know (the consequences of their evil deeds).

# 4204

when fetters will be placed around their necks and chains will drag them

# 4205

into boiling water and then they will be burned in the fire.

# 4206

Then they will be asked, "Where are the idols which you worshipped besides God?"

# 4207

They will reply, "They have abandoned us. In fact, we had worshipped nothing" Thus does God cause the disbelievers to go astray.

# 4208

They will be told, "This (torment) is the result of your unreasonable happiness on the earth and of your propagation of falsehood.

# 4209

Enter the gates of hell to live therein forever. How terrible is the dwelling of the arrogant ones.

# 4210

(Muhammad), exercise patience. The promise of God is true. Whether We let you witness the suffering with which they were threatened or because of your death (you do not see them suffering,), We shall still punish them when they return to Us (on the Day of Judgment).

# 4211

We have told you the stories of some of Our Messengers whom We had sent before you and We have not told you the stories of some others. A Messenger is not supposed to show a miracle without the permission of God. When God's decree of punishment comes to pass, He will judge truthfully and the supporters of the falsehood will perish when God's decree of punishemnt comes to pass.

# 4212

It is God Who has created cattle for you to ride and to consume as food.

# 4213

You may also obtain other benefits from them. You may ride them to seek whatever you need or be carried by them as ships carry you by sea.

# 4214

God shows you the evidence (of His existence). How can you then deny such evidence?

# 4215

Have they not travelled through the land to see the terrible end of those who lived before them? They were far mightier in both number and power and in what they had established. Their (worldly) gains were of no benefit to them.

# 4216

They were far too content with their own knowledge (to pay attention to the Messengers) when Our Messengers came to them with illustrious evidence. They were encompassed by the torment for mocking Our guidance.

# 4217

They said, "We believe in One God and disbelieve in whatever we had considered equal to Him," when they experienced Our wrath.

# 4218

Their faith proved to be of no benefit to them when they became subject to Our torment. Such was God's prevailing tradition among His servants in the past. Thus were the unbelievers destroyed.

# 4219

Ha. Mim.

# 4220

This is the revelations from the Beneficent, Merciful God.

# 4221

The verses of this Book have been fully expounded. It is a reading in the Arabic language for the people of knowledge.

# 4222

It contains glad news and warnings (for the people), but most of them have ignored it and do not listen.

# 4223

They say, "Our hearts are covered against and our ears are deaf to whatever you (Muhammad) invite us to. There is a barrier between us and you. So act as you please and we shall act as we please".

# 4224

(Muhammad), say, "I am a mere mortal like you. I have received a revelation that your Lord is the only One. So be up-right and obedient to Him and seek forgiveness from Him.

# 4225

Woe to the pagans, who do not pay zakat and have no faith in the life to come.

# 4226

The righteously striving believers will have a never-ending reward".

# 4227

Say, "Do you really disbelieve in the One Who created the earth in two days? Do you consider things equal to Him? He is the Lord of the Universe.

# 4228

In four days He placed the mountains on it, blessed it, and equally measured out sustenance for those who seek sustenance.

# 4229

He established His dominance over the sky, which (for that time) was like smoke. Then He told the heavens and the earth, "Take your shape either willingly or by force" They said, "We willingly obey".

# 4230

He formed the seven heavens in two days and revealed to each one its task. He decked the sky above the earth with torches and protected it from (intruders).. Such is the design of the Majestic and All-knowing God".

# 4231

If they ignore (your message), tell them, "I have warned you against a destructive blast of sound like that which struck the people of \`Ad and Thamud.

# 4232

When Messengers from all sides came to them saying, "Do not worship anything besides God, " they said, "Had our Lord wanted, He would have sent us angelic Messengers. We do not believe in your message".

# 4233

The people of Ad unjustly sought dominance on earth saying, "Who is more powerful than us?" Did they not consider that God created them and that He is more powerful than they were?" They rejected Our revelations.

# 4234

We sent upon them a violent wind during a few ill-fated days to make them suffer a disgraceful torment in this life. Their torment in the life to come will be even more disgraceful and they will not receive any help.

# 4235

We sent guidance to the people of Thamud but they preferred blindness to guidance so a humiliating blast of torment struck them for their evil deeds.

# 4236

We only rescued the believers who had fear of God.

# 4237

They will be spurred on

# 4238

until (on the brink of it) their eyes, ears and skin will testify to their deeds on the Day when the enemies of God are driven to the fire.

# 4239

They will ask their own skin, "Why did you testify against us?" They will reply, "God, who has made everything speak, made us also speak. It was He Who created you in the first place and to Him you have returned.

# 4240

You did not (think) to hide your deeds from your ears, eyes and skin and you felt that God would not know all that you had been doing.

# 4241

This was how you considered your Lord, but He knows you better than you know yourselves. Thus, you are now lost".

# 4242

Even if they were to exercise patience, their dwelling would still be hell fire. Even if they were to seek favors, they would receive none.

# 4243

We assigned for them companions who would make their past and present (deeds) seem attractive to them. Thus, they became subject to what the jinn and human beings before were destined to suffer. They were certainly lost.

# 4244

The disbelievers say, "Do not listen to this Quran but make a lot of unnecessary noise while it is being read so that perhaps you will defeat it".

# 4245

We shall certainly make the unbelievers suffer severe torment and will punish them far worse than what they deserve for their deeds.

# 4246

The recompense of the enemies of God for their rejection of Our revelations will be fire as their eternal dwelling.

# 4247

The disbelievers will say, "Lord, show us the human beings and jinn who caused us to go astray. We shall put them under our feet to lower them".

# 4248

To those who have said, "God is our Lord, " and who have remained steadfast to their belief, the angels will descend saying, "Do not be afraid or grieved. Receive the glad news of the Paradise which was promised to you.

# 4249

We are your guardians in this world and in the life to come, where you will have whatever you call for,

# 4250

a hospitable welcome from the All-forgiving and All-merciful God".

# 4251

Who speaks better than one who invites human beings to God, acts righteously and says, "I am a Muslim".

# 4252

Virtue and evil are not equal. If you replace evil habits by virtuous ones, you will certainly find that your enemies will become your intimate friends.

# 4253

Only those who exercise patience and who have been granted a great share of God's favor can find such an opportunity.

# 4254

(Muhammad), seek God's protection if satan's temptation grieves you, for God is All-hearing and All-knowing.

# 4255

(Some evidence of His existence) are the night, day, sun, and moon. Do not prostrate before the sun and the moon, but prostrate before God Who has created them if you want to worship Him alone.

# 4256

However, if people are too proud to prostrate before God, let them know that God's other creatures glorify Him both day and night without fatigue.

# 4257

Further evidence is that (at times) you find the earth to be barren. When it is watered it moves and swells (to let the plants grow). The One who brings it back to life will also bring the dead back to life. He has power over all things.

# 4258

Those who deviate from Our revelations are not hidden from Us. Is the one who will be thrown into hell fire better than the one who will be brought safely into the presence of God on the Day of Judgment? Act as you wish; God is Well-Aware of whatever you do.

# 4259

The disbelievers (do not know) that the Quran which was sent to them is certainly a glorious Book.

# 4260

Falsehood can not reach it from any direction. It is the revelation from the All-wise, Praiseworthy One.

# 4261

Nothing has been said to you which was not said to the Messengers who lived before you. Your Lord is certainly All-forgiving, but stern in His retribution.

# 4262

Had We sent down this Quran in a non-Arabic language, they would have said, "Why have its verses not been well expounded?" Could a non-Arabic Book be revealed to an Arabic speaking person? (Muhammad), say, "It is a guide and a cure for the believers. As for those who do not believe, they are deaf and blind. It is as though they had been called from a distant place".

# 4263

We had given the Book to Moses about which people greatly disagreed. Had the word of your Lord not been decreed, He would have certainly settled their differences (there and then). They were greatly suspicious and doubtful about the Book of Moses.

# 4264

Whoever acts righteously does so for his own good and whoever commits evil does so against his soul. Your Lord is not unjust to His servants.

# 4265

It is He who has the knowledge of the Hour of Doom and the fruits that will come out of their covering. He knows what the females conceive and deliver. On the day when the unbelievers will be asked, "Where are the idols which you considered equal to God?," they will reply, "We declare that none of us have seen them".

# 4266

Whatever they had worshipped before will disappear and they will then know that there is no way for them to escape.

# 4267

The human being never tires of asking for good, but if he is afflicted by hardship, he despairs and gives up all hope.

# 4268

When We grant him mercy after his suffering, he (boldly) says, "This is what I deserved. I do not think that there will ever be a Day of Judgment. Even if I will be returned to my Lord, I shall still deserve to receive better rewards from Him." We shall certainly tell the unbelievers about their deeds and cause them to suffer a severe punishment.

# 4269

When We grant the human being a favor, he ignores it and turns away but when he is afflicted by hardship, he starts lengthy prayers.

# 4270

Say, "Think, if the (Quran) is from God and you have rejected it, then who has gone farther astray than the one who has wandered far from the truth?

# 4271

We shall (continue to) show them Our evidence in the world and within their souls until it becomes clear that the Quran is the truth. Is it not sufficient for you that your Lord witness all things?

# 4272

They are certainly doubtful about their meeting with their Lord. God indeed encompasses all things.

# 4273

Ha. Mim.

# 4274

Ayn. Sin. Qaf.

# 4275

(Muhammad), this is how God, the Majestic and All-wise, sends revelations to you and sent them to those who lived before you.

# 4276

To Him belongs all that is in the heavens and the earth. He is the Most High and the Most Great.

# 4277

(When the revelation passes through) the heavens, they almost break apart. At that time the angels glorify their Lord with His praise and seek forgiveness for those who live on earth. God is certainly All-forgiving and All-merciful.

# 4278

God is the guardian of even those who have chosen others (idols) besides Him as their guardians (Muhammad), you will not have to answer for them.

# 4279

We have revealed the Quran to you in the Arabic language so that you could warn the people of the Mother Town (Mecca) and those around it of the inevitable Day of Resurrection when some will go to Paradise and others to hell.

# 4280

Had God wanted, He could have made them all one single nation, but He grants mercy to whomever He wills. The unjust will have no guardian or helper.

# 4281

Have they chosen other guardians besides Him? God is the real Guardian and it is He who will bring the dead back to life. He has power over all things.

# 4282

Whatever differences you may have about the Quran, the final decision rests with God. In Him do I trust and to Him do I turn in repentance.

# 4283

He is the Originator of the heavens and the earth. He has made you and the cattle in pairs and has multiplied you by His creation. There is certainly nothing like Him. He is All-hearing and All-aware.

# 4284

In His hands are the keys of the heavens and the earth. He increases and determines the sustenance of whomever He wants. He has the knowledge of all things.

# 4285

He has plainly clarified the religion which is revealed to you and that which Noah, Abraham, Moses, and Jesus were commanded to follow (He has explained it) so that you would be steadfast and united in your religion. What you call the pagans to is extremely grave for them. God attracts to (the religion) whomever He wants and guides to it whoever turns to Him in repentance.

# 4286

Only after receiving the knowledge did people divide themselves into different groups because of rebellion among themselves. Had it not been for your Lord's giving them respite for an appointed time, He would certainly have settled their differences once and for all. Those who inherited the Book, from their quarrelsome predecessors, also have doubts and suspicions about it.

# 4287

Thus, (Muhammad), preach (My revelation) to the people and be steadfast (in your faith) as you have been commanded. Do not follow their desires but say, "I believe in the Book which God has sent down and I have been commanded to exercise justice among you. God is our Lord and your Lord. Each of us will be responsible for his own deeds. Let there be no disputes among us. God will bring us all together and to Him we shall all return".

# 4288

The disputes of those who quarrel about God, after pledging obedience to Him, will be void in the eyes of their Lord. Such people will be subject to His wrath and will suffer a severe torment.

# 4289

It is God who revealed the Book and the Balance for a truthful purpose. You never know. Perhaps the Hour of Doom is close at hand.

# 4290

The disbelievers want you to show them the Day of Judgment immediately while the believers are afraid of it for they know it to be the truth. Those who insist on disputing the Hour of Doom are certainly in plain error.

# 4291

God is kind to His servants. He gives sustenance to whomever He wants. He is All-powerful and Majestic.

# 4292

We shall increase the harvest of those who seek a good harvest in the life hereafter. However, those who want to have their harvest in this life will be given it but will have no share in the hereafter.

# 4293

Do they have idols who have established a religion without the permission of God? Had not it been for your Lord's giving them respite for an appointed time, He would certainly have settled their differences once and for all. The unjust will certainly suffer a painful torment.

# 4294

You can see that the unjust are afraid of the consequences of their deeds which will inevitably strike them. However, the righteously striving believers will live in the gardens wherein they will have whatever they want from their Lord. This is certainly the greatest reward.

# 4295

This is the glad news which God gives to His servants, the righteously striving believers. (Muhammad), say, "I do not ask you for any payment for my preaching to you except (your) love of (my near) relatives." Whoever achieves virtue will have its merit increased. God is All-forgiving and Appreciating.

# 4296

Do they say that he, (Muhammad), has invented falsehood against God? Had God wanted, He could have sealed up your heart. God causes falsehood to vanish and, by His words, firmly establishes the truth. He has full knowledge of what the hearts contain.

# 4297

It is He who accepts the repentance of His servants, forgives their evil deeds and knows all about what you do.

# 4298

He answers the prayers of the righteously striving believers and grants them increasing favors. The unbelievers will suffer a severe punishment.

# 4299

Had God given abundant sustenance to His servants, they would have certainly rebelled on earth, but He sends them a known measure of sustenance as He wills. He is All-aware of His servants and watches over them all.

# 4300

It is He who sends down the rain after they had lost hope and spreads out His mercy. He is the Guardian and the Most Praiseworthy.

# 4301

Some of the evidence (of His existence) are His creation of the heavens and the earth and the beasts which inhabit it. He has all the power to bring them together if He wishes this to be so.

# 4302

Whatever hardship befalls you is the result of your own deeds. God pardons many of your sins.

# 4303

You cannot challenge God on earth and you will have no one besides Him as your guardian or helper.

# 4304

Further evidence (of His existence) are the ships which stand as mountains in the sea.

# 4305

Had He wanted, He could have stopped the wind and let the ships remain motionless on the surface of the sea, in this there is evidence (of the Truth) for all those who are patient and grateful,

# 4306

or He could have destroyed them as punishment for the human being's deeds. However, God pardons many sins.

# 4307

He knows all those who dispute His revelations. They will find no way to escape from (His torment).

# 4308

Whatever you have received is just a means of enjoyment for this life but the reward of God for the believers and those who trust in their Lord will be better and everlasting.

# 4309

(This reward will be for) those who keep away from major sins and indecency, who forgive when they are made angry,

# 4310

who have pledged their obedience to the Lord, who are steadfast in prayer, who conduct their affairs with consultation among themselves, who spend for the cause of God out of what We have given them,

# 4311

and those who, when suffering a great injustice, seek to defend themselves.

# 4312

The recompense for evil will be equivalent to the deed. He who pardons (the evil done to him) and reforms himself, will receive his reward from God. God certainly does not love the unjust.

# 4313

Those who successfully defend themselves after being wronged will not be questioned.

# 4314

Only those who do injustice to people and commit rebellion on earth for no reason will be questioned. They will suffer a painful torment.

# 4315

To exercise patience and forgive (the wrong done to one) is the proof of genuine determination.

# 4316

Whomever God has caused to go astray will find no guardian after this. You will see the unjust, on facing the torment, say, "Is there any way to turn back?

# 4317

You will see them exposed to the fire, subdued in humiliation, looking sideways at it pleadingly. However, at the same time, the believers will say, "The true losers are those who will lose their souls and families on the Day of Judgment. The unjust will certainly suffer everlasting torment.

# 4318

They will have no guardian or helper besides God. Whoever God has caused to go astray will never find the right direction".

# 4319

Pledge obedience to your Lord before the coming of the inevitable Day when you will find no refuge to escape from God's wrath and no one to defend you.

# 4320

(Muhammad), if they turn away from your message, know that We have not sent you as their keeper. Your duty is only to deliver the message. When We grant mercy to the human being, he becomes joyous, but when he is afflicted by evil as a result of his own deeds, he proves to be ungrateful.

# 4321

To God belongs the heavens and the earth. He created whatever He wanted. He grants males, female, or pairs of.

# 4322

offspring to whomever He wants. He causes whomever He wants to be childless. He is All-Knowing and All-Powerful.

# 4323

To no mortal does God speak but through revelation, from behind a curtain, or by sending a Messenger who reveals, by His permission whatever He pleases. He is the Most High and the All-wise.

# 4324

Thus, We have revealed a Spirit to you, (Muhammad), by Our command. Before, you did not even know what a Book or Faith was, but We have made the Quran as a light by which We guide whichever of Our servants We want. You certainly guide (people) to the right path,

# 4325

the path of God who is the owner of all that is in the heavens and the earth. To God certainly do all matters return.

# 4326

Ha. Mim.

# 4327

I swear by the illustrious Book.

# 4328

We have made it an Arabic reading text so that perhaps you may understand.

# 4329

It (the Quran) exists in the original Book with Us which is certainly Most Exalted, full of wisdom and (beyond linguistic structures).

# 4330

Can We ignore sending you the Quran just because you are a transgressing people?

# 4331

How many Messengers did We send to the ancient people?

# 4332

No Prophet came to them whom they did not mock.

# 4333

We destroyed the strongest among them in power. The stories of the ancient people have already been mentioned.

# 4334

(Muhammad), if you ask them, "Who has created the heavens and the earth?" They will certainly say, "The Majestic and All-knowing God has created them".

# 4335

It is He who has made the earth for you as a cradle and has made roads therein so that you will perhaps seek guidance.

# 4336

It is He who has sent down water from the sky in a known measure by which He has given life to the dead earth. In the same way will you also be resurrected.

# 4337

It is He who has created everything in pairs and the ships and cattle for you to ride,

# 4338

so that perhaps when you ride them, you will recall the bounties of your Lord and when you establish your control over it you would say, "Glory belongs to Him who has made it subservient to us when we would not have been able to do so ourselves.

# 4339

To our Lord we shall all return".

# 4340

The pagans have considered some of His servants as His children. There is no doubt that the human being is simply ungrateful.

# 4341

Has God chosen some of His own creatures as daughters for Himself and has given you the preference of having sons?

# 4342

When one of them is given the glad news of the birth of a daughter, which they believe to be the only kind of child that the Beneficent God can have, his face blackens with anger.

# 4343

Does God choose for Himself the kind of children who grow up wearing ornaments and who are not strong enough to defend their rights?

# 4344

Do they say that the angels, who are the servants of the Beneficent God, are females? Have they witnessed their creation? Their words as such will be recorded and they will be questioned for it.

# 4345

The pagans say, "Had the Beneficent God wanted, we would not have worshipped them (idols)." Whatever they say is not based on knowledge. It is only a false conjecture.

# 4346

Had We, before sending the Quran, given them a book to which they now refer as an authority?

# 4347

In fact, they say, "We found our fathers following a certain belief and we now follow in their footsteps for our guidance".

# 4348

In the same way, whenever We had sent a Messenger before you to warn a town, the rich ones therein said, "We found our fathers following a certain belief and we follow in their footsteps.

# 4349

The Messengers would say, "Would you still follow in the footsteps of your fathers even if I was to bring you better guidance?" They would say, "We have no faith in your message".

# 4350

We took revenge on them. See how terrible the end of those who rejected (Or revelations) was!

# 4351

When Abraham said to his father and his people, "I boldly renounce what you worship

# 4352

except for the One who has created me and will guide me".

# 4353

God made (belief in one God) an everlasting task for his successors, so that perhaps they would return (to Him).

# 4354

In fact, We allowed them and their fathers to enjoy themselves until the truth and a strong Messenger came to them.

# 4355

When the truth came to them, they said, "This is magic and we have no faith in it".

# 4356

Then they said, "Why this Quran had not been revealed to a man from either of the two great towns".

# 4357

Do they distribute the mercy of your Lord? It is We who have distributed their sustenance in this world and raised the positions of some of them above the others so that they would mock each other. The mercy of your Lord is better than what they can amass.

# 4358

Were it not for the fear that all people would become one in disbelief, We would have made for the disbelievers in the Beneficent God ceilings out of silver and ladders by which they would climb up,

# 4359

doors for their houses, couches on which to recline,

# 4360

and other ornament of gold. All these are only the means of enjoyment in this world, but the pious will receive their reward from your Lord in the life hereafter.

# 4361

We shall make satan the companion of whoever ignores the remembrance of the Beneficent God.

# 4362

Satan will prevent them from the right path while they think that they have the right guidance.

# 4363

When he returns to us, he will say (to satan), "Would that there had been as long a distance between me and you as that between the East and West. What a terrible companion you have been".

# 4364

They will be told on the Day of Judgment, "Regret will never be of any benefit to you. You have done injustice to your souls and you will share the torment".

# 4365

(Muhammad), can you make the deaf hear or guide the blind or the one who is clearly in error?

# 4366

We shall revenge them either after your death

# 4367

or show them to you suffering the torment with which We had threatened them. We are certainly dominant over them all.

# 4368

Follow devotedly that which is revealed to you. You are certainly on the right path.

# 4369

The Quran is a reminder to you and to your people and you will soon be questioned about it.

# 4370

You can ask Our Messengers whom We sent before you if We had commanded them to worship other gods besides the Beneficent God?"

# 4371

We sent Moses to the Pharaoh and his nobles with Our miracles and he said, "I am the Messenger of the Lord of the Universe".

# 4372

When he showed them Our miracles, they started to laugh at them.

# 4373

Of all the miracles which We showed to them the latter ones were greater than the former. We struck them with torment so that perhaps they would return to Us.

# 4374

They said, "Magician, pray to your Lord for us through your covenant with Him (If he saves us from the torment), we shall certainly seek guidance".

# 4375

When We relieved them from the torment they suddenly turned back on their heels.

# 4376

The Pharaoh shouted to his people, "My people, is the kingdom of Egypt not mine? and can you not see that the streams flow from beneath my palace?

# 4377

Am I not better than this lowly man who can barely express himself?

# 4378

Why have bracelets of gold not been given to him and why have some angels not accompanied him?"

# 4379

Thus, he made dimwits out of his people and they followed him. They, certainly, were a sinful people. When they invoked Our anger,

# 4380

We took revenge on them by drowning them all together.

# 4381

We made them become of the people of the past and an example for the coming generations.

# 4382

When the son of Mary was mentioned as an example, you people cried out in protest, saying,

# 4383

"Are our gods any better than Jesus (for according to Muhammad), if our gods go to hell so too will Jesus. What they say is only a false argument. In fact, they are a quarrelsome people.

# 4384

Jesus was a servant of Ours to whom We had granted favors and whom We made as an example for the Israelites.

# 4385

Had We wanted, We could have made the angels as your successors on the earth.

# 4386

(Muhammad), tell them, "Jesus is a sign of the Hour of Doom. Have no doubt about it and follow me; this is the straight path.

# 4387

Let satan not prevent you from the right path. He is your sworn enemy".

# 4388

When Jesus came with clear proof (in support of his truthfulness), he said, "I have come to you with wisdom to clarify for you some of the matters in which you have disputes. Have fear of God and obey me.

# 4389

God is your Lord and my Lord, so worship Him. This is the right path".

# 4390

But certain groups created differences among themselves. Woe to the unjust. They will face a painful torment.

# 4391

Are they waiting for the Hour of Doom when the torment will suddenly strike them and they will not even realize from where it came?

# 4392

All intimate friends on that day will become each others enemies except for the pious,

# 4393

whom God will tell, "My servants, you need have no fear on this day, nor will you be grieved".

# 4394

Those who have faith in Our revelations and have submitted themselves to Our will,

# 4395

will be told, "Enter Paradise with your spouses in delight.

# 4396

Golden dishes and cups will be passed among them. All that the souls may desire and that may delight their eyes will be available therein. You will live therein forever.

# 4397

This is the Paradise which you have received as your inheritance by virtue of what you have done.

# 4398

You will have abundant fruits therein to consume".

# 4399

The criminals will live forever in the torment of hell. Their torment will not be relieved and they will despair of escaping.

# 4400

We had not done any injustice to them but they had wronged themselves.

# 4401

They will cry out, "Guard, let your Lord destroy us".

# 4402

The angelic guard will say, "You will have to stay.

# 4403

We brought you the truth but most of you disliked it".

# 4404

If the disbelievers persist in their disbelief, We shall also persist in punishing them.

# 4405

Do they think that We do not hear their secrets and whispers? We certainly can hear them and Our Messengers record it all.

# 4406

(Muhammad), say, "Had the Beneficent God really had a son, I would certainly have been the first one to worship him.

# 4407

The Lord of the heavens and the earth and the Throne is too glorious to be described in the way they describe Him.

# 4408

Leave them (to indulge) in their desires and play around until they face that day which has been promised to them.

# 4409

It is God who is the Lord of the heavens and is the Lord on earth. He is All-wise and All-knowing.

# 4410

Blessed is He to whom belongs the heavens, the earth and all that is between them and who has the knowledge of the Hour of Doom. To Him you will all return.

# 4411

Those whom they worship besides God are not able to intercede, except for those among them who believe in the Truth (God) and who know whom to intercede for.

# 4412

(Muhammad), if you ask them, "Who had created the idols?" They will certainly say, "God has created them." Why do you then turn away from God?

# 4413

(God has knowledge of Muhammad's words when he complains to Him), "My Lord, these, my people, do not believe".

# 4414

We have told him, "Ignore them and say to them 'farewell'. They will soon know the consequences of their deeds

# 4415

Ha. Mim.

# 4416

I swear by the illustrious Book.

# 4417

that We have revealed the Quran on a blessed night to warn mankind.

# 4418

On this night, every absolute command coming from Us becomes distinguishable.

# 4419

The command that We have been sending

# 4420

as a mercy (for the human being) from your Lord. Your Lord is All-hearing and All-knowing.

# 4421

He is the Lord of the heavens and the earth and all that is between them, if only you would have strong faith.

# 4422

There is only One Lord. It is He who gives life and causes things to die. He is your Lord and the Lord of your forefathers.

# 4423

In fact, the unbelievers have doubts because of excessive involvement in worldly affairs.

# 4424

Wait for the day (which will come before the Day of Judgment) when the sky will give out dense smoke

# 4425

which will smother the people. They will say, "This is a painful torment.

# 4426

Lord, remove this torment from us for we are believers".

# 4427

How could this punishment bring them to their senses when a Messenger evidently had come to them,

# 4428

and they turned away, saying, "He is a trained and insane person".

# 4429

We shall remove the torment for a while but you will revert to your old ways.

# 4430

However, We shall truly take Our revenge on the day when the great seizure takes place.

# 4431

We had certainly tested the people of the Pharaoh before them to whom a noble Messengers had come, saying,

# 4432

"Send the servants of God with me. I am a trustworthy Messenger sent to you.

# 4433

Do not consider yourselves above God? I shall show you a manifest authority (in support of my truthfulness).

# 4434

I seek protection from my Lord and your Lord from your decision of stoning me.

# 4435

If you do not want to believe, leave me alone".

# 4436

Moses addressed his Lord, saying, "Lord, these people are sinners".

# 4437

We told him, "Leave the city with My servants during the night. You will be pursued.

# 4438

Cross the sea by cutting a path through it. Pharaoh's army will be drowned.

# 4439

How many were the gardens, springs,

# 4440

corn-fields, gracious mansions,

# 4441

and other bounties which they enjoyed yet left behind!

# 4442

We gave these as an inheritance to other people.

# 4443

The sky nor the earth cried for them, nor were they given respite.

# 4444

We rescued the Israelites from the humiliating torment

# 4445

and from the Pharaoh. He was the chief of the transgressors.

# 4446

We gave preference to the Israelites over the other people with Our knowledge

# 4447

and sent them revelations of which some were a clear trial for them.

# 4448

These people say,

# 4449

"After we die, we shall never be raised to life again.

# 4450

Bring back to life our fathers if what you say is true".

# 4451

Are they better than the tribe of Tubba (name of a Yemenite tribal chief) and those who lived before them? We destroyed them. They were criminals.

# 4452

We have not created the heavens and the earth and all that is between them for Our own amusement.

# 4453

We have created them for a genuine purpose, but most people do not know.

# 4454

The appointed time for all of them will be the Day of Judgment

# 4455

(when wrong will be distinguished from right). On this day friends will be of no benefit to one another, nor will they receive any help

# 4456

except for those to whom God grants mercy. He is Majestic and All-merciful.

# 4457

The tree of Zaqqum

# 4458

is food for the sinner.

# 4459

It will be like molted brass which will boil in the bellies

# 4460

like water.

# 4461

(It will be said of such sinners), "Seize them and drag them into the middle of hell.

# 4462

Then pour unto their heads the boiling water to torment them".

# 4463

They will be told, "Suffer the torment. You had thought yourselves to be majestic and honorable.

# 4464

This is the torment that you persistently doubted".

# 4465

The pious ones will be in a secure place

# 4466

amid gardens and springs,

# 4467

clothed in fine silk and rich brocade, sitting face to face with one another.

# 4468

We shall unite them to maidens with big black and white lovely eyes.

# 4469

They will be offered all kinds of fruits, in peace and security.

# 4470

They will not experience any death other than that which they have already been through.

# 4471

God will protect them from the torment of hell as a favor from your Lord. (Muhammad), this is certainly the greatest triumph.

# 4472

We have made the Quran easy for you to recite so that perhaps they may take heed.

# 4473

Wait (for God's decree) and they too will be waiting.

# 4474

Ha. Mim.

# 4475

This Book is revealed from God, the Majestic and All-wise.

# 4476

In the heavens and the earth there is evidence (of the Truth) for the believers.

# 4477

In your creation and in that of the beasts living on earth there is evidence of the Truth for the people who have strong faith.

# 4478

In the alternation of the night and the day, the sustenance which God has sent down from the sky to revive the barren earth, and in the changing of the direction of the winds there is evidence of the truth for the people of understanding.

# 4479

These are the revelations of God which We recite to you for a genuine purpose. In what statements other than God's and His revelations will they then believe?

# 4480

Woe to every sinful liar!

# 4481

He hears the revelations of God which are recited to him, then persists in his arrogance as if he had not even heard them. Tell him that he will suffer a painful torment.

# 4482

When he learns about some of Our revelations, he mocks them. Such people will suffer a humiliating torment.

# 4483

Hell is awaiting them and none of their deeds will be of any benefit to them, nor will any guardian whom they have chosen besides God. They will suffer a great torment.

# 4484

This (Quran) is a guidance. Those who reject the revelations of their Lord will suffer the most painful punishment.

# 4485

God has made the sea subservient to you so that ships sail on by His command and you seek His favors. Perhaps you will be grateful.

# 4486

He has also made subservient to you all that is in the heavens and the earth. In this there is evidence (of the Truth) for those who use their minds.

# 4487

Tell the believers to forgive those who do not have faith in the days of God (Day of Judgment) and Resurrection. God will give due recompense to all the people for their deeds.

# 4488

One who acts righteously does so for his own benefit and one who commits evil does so against his own soul. To your Lord you will all return.

# 4489

We gave the Book to the Israelites, the commandments, and prophethood, granted them pure sustenance, and gave them preference above all people.

# 4490

We also gave them clear evidence in support of the true religion. Only after having received knowledge did they create differences among themselves because of their rebelliousness. Your Lord will issue His decree concerning their differences on the Day of Judgment.

# 4491

We have established for you a code of conduct and a religion. Follow it and do not follow the desires of the ignorant people.

# 4492

They will never be sufficient (protection) for you in place of God. The unjust are each other's friends, but God is the guardian of the pious ones.

# 4493

This (Quran) is an enlightenment for the people and a guide and mercy for the people who have strong faith.

# 4494

Do the people who commit evil think that We shall make their life and death like that of the righteously striving believers? How terrible is their Judgment!

# 4495

God has created the heavens and the earth for a genuine purpose so that every soul will be duly recompensed for its deeds without being wronged.

# 4496

Have you seen the one who has chosen his desires as his lord? God has knowingly caused him to go astray, sealed his ears and heart and veiled his vision. Who besides God can guide him? Will they, then, not take heed?

# 4497

They have said, "The only life is this worldly life and here we shall live and die. It is only time which will destroy us" They have no knowledge about this. It is only their guesswork.

# 4498

When Our enlightening revelations are recited to them, their only argument against it is, "Bring our forefathers back to life if what you say is true".

# 4499

(Muhammad), say, "It is God who gives you life and causes you to die. He will bring you together on the inevitable Day of Judgment," but most people do not know.

# 4500

To God belongs the kingdom of the heavens and the earth. On the day when the Hour of Doom arrives, the followers of falsehood will be lost.

# 4501

You will see all the people kneeling down. Everyone will be summoned to the Book (containing the record of their deeds). They will be told, "On this day you will be recompensed for what you have done".

# 4502

This is Our Book. It will tell you the truth. We have made a copy of all that you have done.

# 4503

The Lord will admit the righteously striving, believing people into His mercy. This is certainly a clear victory.

# 4504

To the unbelievers the Lord will say, "Were not Our revelations recited to you and did not you arrogantly reject them? You were a sinful people".

# 4505

When it was said that the promise of God is true and that the Hour would inevitably come, you said, "We do not know what the Hour of Doom is, we are suspicious about it and we are not convinced".

# 4506

Their evil deeds will be revealed to them and (the torment) which they had mocked will surround them.

# 4507

They will be told, "On this day We shall forget you in the same way that you had forgotten your coming into Our presence. Your dwelling will be hell fire and no one will help you.

# 4508

This is only because you had mocked the revelations of God and the worldly life had deceived you. On this day they will not be taken out of hell, nor will they be granted any favors.

# 4509

It is only God, Lord of the heavens and the earth and Lord of the Universe who deserves all praise.

# 4510

It is His greatness that dominates the heavens and the earth. He is the Majestic and All-wise.

# 4511

Ha. Mim.

# 4512

This Book is revealed from God the Majestic and All-wise.

# 4513

We have created the heavens and the earth and all that is between them ONLY for a genuine purpose and an appointed time. The unbelievers ignore that of which they have been warned.

# 4514

(Muhammad), ask them, "Have you thought about what you worship besides God? Show me which part of the earth they have created. Do they have a share in the creation of the heavens? Bring me a Book, revealed before this Quran, or any other proof based on knowledge to support your belief, if indeed you are truthful".

# 4515

Who is more astray than one who prays to things besides God; things that would not be able to answer his prayers even if he would wait till the Day of Judgment. They are not even aware of his prayers.

# 4516

When people will be resurrected, such gods will become their enemies and will reject their worship.

# 4517

When Our enlightening revelations are recited to them, the disbelievers, of the truth which has come to them, say, "This is plain magic".

# 4518

They say, "(Muhammad) has invented it (Quran) by himself." Say, "Had I invented it, you would not have been able to rescue me from God. He knows best what you say about it. He is our witness and He is All-forgiving and All-merciful".

# 4519

Say, "I am not the first Messenger. I do not know what will be done to me or to you. I follow only what has been revealed to me and my duty is only to give clear warning".

# 4520

Say, "What do you think will happen if this Quran is from God and you have rejected it? Besides, a witness from among the Israelites has testified to the divinity of a Book like it and believed in it (Quran) while you have arrogantly denied it. God does not guide the unjust.

# 4521

The disbelievers have said about the believers, "Had there been anything good in it (Quran), they could not have accepted it before us" Since they do not benefit from its guidance, they say, "It (Quran) is only a fabricated legend".

# 4522

Before this (Quran), the Book of Moses was a guide and a blessing. This Book confirms the Torah. It is in the Arabic language so that it may warn the unjust people, and give glad news to the righteous ones.

# 4523

Those who have said, "Our Lord is God," and are steadfast in their belief need have no fear or be grieved.

# 4524

They will be the dwellers of Paradise wherein they will live forever as a reward for what they have done.

# 4525

We have advised the human being to be kind to his parents; his mother bore him with hardship and delivered him while suffering a great deal of pain. The period in which his mother bore and weaned him lasted for thirty months. When he grew-up to manhood and became forty years old, he then said, "Lord, inspire me to give You thanks for the bounties you have granted to me and my parents, and to act righteously to please You. Lord, make my offspring virtuous. Lord I turn to you in repentance; I am a Muslim".

# 4526

These are the ones from whom We accept righteous deeds and ignore their bad deeds. They will be among the dwellers of Paradise. It is the true promise which was given to them.

# 4527

There are people who say to their parents, "Fie upon you! Are you telling us that we shall be raised from our graves? So many people have died before us and (none of them have been raised)" Their parents plead to God and say to their child, "Woe to you! Have faith; the promise of God is certainly true" They reply, "What you say is only ancient legends".

# 4528

Such people will be subject to the punishment of God, which was also decreed for many human beings and jinn before them. These people are certainly lost.

# 4529

Everyone will have a position proportionate to the degree of his deeds. Finally, God will recompense them for their deeds and they will not be wronged.

# 4530

On the day when the disbelievers will be exposed to the fire, they will be told, "You have spent your happy days during your worldly life and enjoyed them. On this day you will suffer a humiliating torment for your unreasonably arrogant manners on earth and for the evil deeds which you have committed".

# 4531

(Muhammad), recall the brother of the people of Ad, when he warned his people in the valley of al-ahqaf saying, "There existed many warners before and after him. Do not worship anything other than God. I am afraid for you about the torment of the great Day".

# 4532

They said, "Have you come to turn us away from our gods? Show us that with which you threaten us if you are truthful".

# 4533

He said, "Only God has the knowledge (of the coming of such torment). I preach to you the message that I have brought, but I can see that you are an ignorant people".

# 4534

When they saw the torment as a cloud proceeding to their valleys, they said, "This cloud will bring us rain." He said, "No, it is the torment which you wanted to suffer immediately. It is a wind bearing and painful torment.

# 4535

It will destroy everything by the will of its Lord" (Not very long after) nothing could be seen of them except their dwellings. Thus do We recompense the sinful people.

# 4536

We had established them more firmly in the land than you are. We had given them ears, eyes, and hearts but none of their ears, eyes, and hearts proved to be of any benefit to them; they rejected the revelations of God and the torment which they mocked brought upon them utter destruction.

# 4537

We destroyed some towns around you and showed you the evidence (of the Truth) so that perhaps you would turn (to God).

# 4538

Why did the idols, whom they worshipped as a means of pleasing God, not help them? In fact, they proved to be the cause of their going astray and it were lies which they had falsely invented lies.

# 4539

We turned a party of jinn towards you to listen to the Quran. When they attended a Quranic recitation, they said to each other, "Be silent," and, when it was over, they turned back to their people, in warning,

# 4540

and said, "Our people, we have listened to the recitation of a Book revealed after Moses. It confirms the Books revealed before and guides to the Truth and the right path.

# 4541

Our people, respond favorably to the Messenger of God and believe in Him. He will forgive your sins and rescue you from the painful torment.

# 4542

Those who do not favorably respond to the Messenger of God should know that they cannot challenge God on earth and will not have anyone as their guardian besides Him. Such people are in plain error".

# 4543

Have they not seen that God has created the heavens and the earth and that He experienced no fatigue in doing this. He has the power to bring the dead back to life. Certainly He has power over all things.

# 4544

On the day when the disbelievers will be exposed to the fire, they will be asked, "Is this not real?" They will say, "Yes, Our Lord, it is real" He will say, "Suffer the torment for your disbelief".

# 4545

(Muhammad), exercise patience as did the steadfast Messengers. Do not try to make them suffer the torment immediately; on the day when they will see the torment with which they were threatened, they will think that they had lived no more than an hour. The message has been delivered. No one else will be destroyed except the evil doing people.

# 4546

God has made devoid of all virtue the deeds of those who have disbelieved and prevented others from the way of God.

# 4547

God forgives the sins and reforms the hearts of the righteously striving believers who have faith in what is revealed to Muhammad - which is the Truth from his Lord.

# 4548

This is because the disbelievers have followed falsehood and the believers have followed the Truth from their Lord. Thus God explains to the human being their own prospects.

# 4549

If you encounter the disbelievers in a battle, strike-off their heads. Take them as captives when they are defeated. Then you may set them free as a favor to them, with or without a ransom, when the battle is over. This is the Law. Had God wanted, He could have granted them (unbelievers) victory, but He wants to test you through each other. The deeds of those who are killed for the cause of God will never be without virtuous results.

# 4550

God will lead them to everlasting happiness and improve their condition.

# 4551

He will admit them into the Paradise which He has made known to them.

# 4552

Believers, if you help God, He will help you and make you steadfast (in your faith).

# 4553

The fate of the disbelievers will be to stumble and their deeds will have no virtuous results;

# 4554

they have hated God's revelation, and thus, He has made their deeds devoid of all virtue.

# 4555

Have they not travelled through the land and seen the terrible end of those who lived before them? God brought upon them utter destruction and the disbelievers will also faced similar perdition.

# 4556

God is the guardian of the believers, but the disbelievers have no guardian.

# 4557

God will admit the righteously striving believers into the gardens wherein streams flow. However, the disbelievers who enjoyed themselves and ate like cattle will have for their dwelling hell fire.

# 4558

(Muhammad), how many towns, much more powerful than the one from which you have been expelled, have We destroyed and left helpless?

# 4559

Can the one who follows the authority of his Lord be considered equal to the one whose evil deeds are made to seem attractive to him and who follows his own desires?

# 4560

The garden, which is promised to the pious, is like one in which there are streams of unpolluted water, streams of milk of unchangeable taste, streams of delicious wine, and streams of crystal clear honey. Therein they will have all kinds of fruits and forgiveness from their Lord. On the other hand (can these people be considered like), those who will live forever in hell fire and will drink boiling water which will rip their intestines to bits?

# 4561

(Muhammad), some of them listen to you, but when they leave you they ask those who have received knowledge, "What did he say a few moments ago?" God has sealed the hearts of such people who have followed their worldly desires.

# 4562

God will increase the guidance and piety of those who seek guidance.

# 4563

Are they waiting for the Hour of Doom to suddenly approach them? Its signs have already appeared. How will they then come to their senses when the Hour itself will approach them?

# 4564

Know that God is the only Lord. Ask forgiveness for your sins and for the sins of the believing men and women. God knows when you move and when you rest.

# 4565

The believers say, "Why is a chapter about jihad - fighting for the cause of God - not revealed?" But when such a chapter, with clear commands and a mention of jihad is revealed, you will see those whose hearts are sick look at you as if suffering the agony of death. One can expect nothing better from them!

# 4566

Since they have (pledged) Us obedience and to speak reasonably, it would be more proper for them, when it is decided (that everyone must take part in the battle), to remain true (in their pledge to God).

# 4567

If you ignore the commands of God would you then also spread evil in the land and sever the ties of kinship?

# 4568

God has condemned these people and made them deaf, dumb, and blind.

# 4569

Is it that they do not think about the Quran or are their hearts sealed?

# 4570

Those who have reverted to disbelief after guidance has become manifest to them, have been seduced and given false hopes by satan.

# 4571

This is because they have said to those who hate God's revelation, "We shall obey you in some matters." But God knows all their secrets.

# 4572

How terrible it will be for them when the angels take away their souls by striking their faces and their backs.

# 4573

for their following that which had incurred God's anger, and their hatred to please God. Thus, God has made their deeds devoid of all virtue.

# 4574

Do those whose hearts are sick think that God will never make their malice public?

# 4575

Had We wanted, We could have made you recognize their faces. You will certainly recognize them by the tone of their speech. God knows all your deeds.

# 4576

We shall certainly test you until We know those who strive hard for the cause of God and those who exercise patience. We will also examine your deeds.

# 4577

The disbelievers who prevent others from the way of God and give the Messengers a hard time - even after the guidance has been made clear to them - will never be able to cause any harm to God, and He will turn their deeds devoid of all virtue.

# 4578

Believers, obey God and the Messenger and do not invalidate your deeds.

# 4579

God will never forgive the disbelievers who prevent others from the way of God and who die as disbelievers.

# 4580

Do not be weak hearted and do not appeal for an (unjust) settlement; you have the upper hand. God is with you and He will never reduce the reward for your deeds.

# 4581

The worldly life is only a childish game. If you have faith and piety, you will receive your rewards and God will not ask you to pay for them.

# 4582

Should He ask for your possessions you would be niggardly as it would be hard for you to give. Thus, He would make your malice become public.

# 4583

It is you who are asked to spend for the cause of God, but some of you behave in a niggardly way. Whoever behaves miserly does so against his own soul. God is Self-sufficient and you are poor. If you were to turn away from Him, He would just replace you with another people, who will not be like you.

# 4584

We have granted to you, (Muhammad), a manifest victory,

# 4585

so that God will redeem the sins (which the pagans think you have committed against them) in the past or (you will commit) in the future. He will complete His favors to you, guide you to the right path,

# 4586

and grant you a majestic triumph.

# 4587

It is God who has given confidence to the hearts of the believers to increase and strengthen their faith. To God belongs the armies of the heavens and the earth. He is All-knowing and All-wise.

# 4588

So that He would admit the believers (both male and female) to the gardens wherein streams flow, to live therein forever. He will redeem them. This is the greatest triumph in the sight of God,

# 4589

so that He would punish the hypocrites and the pagans who have evil suspicions about God. It is they who are surrounded by evil and have become subject to the wrath and condemnation of God. He has prepared for them hell, a terrible place to live.

# 4590

To God belong the armies of the heavens and the earth. God is Majestic and All-wise.

# 4591

We have sent you as a witness, a bearer of glad news, and a warner,

# 4592

so that you (people) may believe in God and His Messenger, help, and respect God and glorify Him in the morning and the evening.

# 4593

Those who pledge obedience to you are, in fact, pledging obedience to God. The hands of God are above their hands. As for those who disregard their pledge, they do so only against their own souls. Those who fulfill their promise to God will receive a great reward.

# 4594

The bedouins who lag behind in taking part in the battle say to you, "Ask forgiveness for us; we were busy with our property and household." They speak what is not in their hearts. (Muhammad), tell them, "Who will help you against God, if He intends to harm you, who will prevent Him from benefitting you? In fact, God is Well Aware of whatever you do".

# 4595

You thought the Messenger and the believers would never ever return to their families and this attracted your hearts and caused you to develop evil suspicions. You are a wrong doing people.

# 4596

Those who do not believe in God and His Messenger should know that We have prepared hell for the disbelievers.

# 4597

To God belongs the kingdom of the heavens and the earth. He forgives or punishes whomever He wants. God is All-forgiving and All-merciful.

# 4598

The laggardly Bedouins will say, "When you leave to collect the spoils, let us follow you." They want to alter the command of God (that only the participating believers are entitled to such benefit). Tell them, "You can never follow us for such a purpose. God has said before and He will say again (what type of people you are). In fact, you are jealous of us." The truth is that they understand very little.

# 4599

Tell the laggardly Bedouins, "You will be called to face strong people whom you will fight right to the end or who will submit to you. If you obey the Messenger, God will give you a good reward. But if you turn away as you did before, God will make you suffer a painful torment.

# 4600

It is not an offense for the blind, the lame, or the sick not to take part in the battle. Whoever obeys God and His Messenger will be admitted to the gardens wherein streams flow. God will make whoever turns away suffer a painful torment.

# 4601

God is pleased with the believers for their pledging obedience to you under the tree. He knew whatever was in their hearts, thus, He granted them confidence and rewarded them with an immediate victory

# 4602

and the booty which they received from it (the Battle). God is Majestic and All-wise.

# 4603

God has promised that you will receive much booty. He has enabled you to receive this at this time and has protected you from enemies to make it an evidence (of the Truth) for the believers. He will guide you to the right path.

# 4604

Besides these, there were other gains which you could not receive, but God has full control over them. God has power over all things.

# 4605

Had the disbelievers fought against you, they would have run away from the battle and would have found no guardian or helper.

# 4606

This is the tradition of God which existed before, and you will never find any change in His tradition.

# 4607

It is He who kept peace between you and the people of the valley of Mecca after having given you a victory over them. God is Well Aware of what you do.

# 4608

It was the disbelievers who kept you from the Sacred Mosque and prevented your sacrificial offering from reaching its proper place. God would not have kept you from fighting the disbelievers, had there not been believing men and women (among them) whom you did not know and whom you might have unknowingly harmed. God did this because He grants mercy to whomever He wants. Had they been distinguishable from the believers, We would certainly have punished them with a painful torment.

# 4609

Since the disbelievers held zealous ignorance in their hearts, like that of the pre-Islamic age of darkness, God gave confidence to His Messenger and to the believers, binding them to the principle of piety which they deserve. God has the knowledge of all things.

# 4610

God made the dream of His Messenger come true for a genuine purpose. (In this he was told), "If God wills You (believers) will enter the Sacred Mosque, in security, with your heads shaved, nails cut, and without any fear in your hearts." He knew what you did not know. Besides this victory, He will give you another immediate victory.

# 4611

It is He who has sent His Messenger with guidance and the true religion to make it prevail over all other religions. God is a Sufficient witness to this Truth".

# 4612

Muhammad is the Messenger of God and those with him are stern to the disbelievers yet kind among themselves. You can see them bowing and prostrating before God, seeking His favors and pleasure. Their faces (foreheads) are marked due to the effect of their frequent prostrations. That is their description in the Torah and in the Gospel they are mentioned as the seed which shoots out its stalk then becomes stronger, harder and stands firm on its stumps, attracting the farmers. Thus, God has described the believers to enrage the disbelievers. God has promised forgiveness and a great reward to the righteously striving believers.

# 4613

Believers, do not be presumptuous with the Messenger of God (in your deeds and in your words). Have fear of God; He is All-hearing and All-knowing.

# 4614

Believers, do not raise your voices above the voice of the Prophet, do not be too loud in speaking to him \[as you may have been to one another\], lest your deeds will be made devoid of all virtue without your realizing it.

# 4615

The hearts of those who lower their voices in the presence of the Messenger of God are tested by God through piety. They will have forgiveness and a great reward.

# 4616

Most of those who call you from behind the private chambers do not have any understanding.

# 4617

Had they exercised patience until you had come out, it would have been better for them. God is All-forgiving and All-merciful.

# 4618

Believers, if one who publicly commits sins brings you any news, ascertain its truthfulness carefully, lest you harm people through ignorance and then regret what you have done.

# 4619

Know that the Messenger of God is with you. Had he yielded to you on many of the matters, you would have been in great trouble. But God has endeared the faith to you and has made it attractive to your hearts. He has made disbelief, evil deeds and disobedience hateful to you. Such people will have the right guidance

# 4620

as a favor and a blessing from God. God is All-knowing and All-wise.

# 4621

If two parties among the believers start to fight against each other, restore peace among them. If one party rebels against the other, fight against the rebellious one until he surrenders to the command of God. When he does so, restore peace among them with justice and equality; God loves those who maintain justice.

# 4622

Believers are each other's brothers. Restore peace among your brothers. Have fear of God so that perhaps you will receive mercy.

# 4623

Believers, let not a group of you mock another. Perhaps they are better than you. Let not women mock each other; perhaps one is better than the other. Let not one of you find faults in another nor let anyone of you defame another. How terrible is the defamation after having true faith. Those who do not repent are certainly unjust.

# 4624

Believers, stay away from conjecture; acting upon some conjecture may lead to sin. Do not spy on one another or back-bite. Would any of you like to eat the disgusting dead flesh of your brother? Have fear of God; God accepts repentance and is All-merciful.

# 4625

People, We have created you all male and female and have made you nations and tribes so that you would recognize each other. The most honorable among you in the sight of God is the most pious of you. God is All-knowing and All-aware.

# 4626

The bedouin Arabs have said, "We are believers." Tell them, "You are not believers, but you should say that you are Muslims. In fact, belief has not yet entered your hearts. If you obey God and His Messenger, nothing will be reduced from your deeds. God is All-forgiving and All-merciful.

# 4627

The believers are those who believe in God and His Messenger, who do not change their belief into doubt and who strive hard for the cause of God with their property and persons. They are the truthful ones".

# 4628

(Muhammad), say, "Do you teach God about your religion? God knows whatever is in the heavens and the earth. He has the knowledge of all things".

# 4629

(The bedouins tell you that) you owe them (a great deal) for their embracing Islam. Tell them, "You are not doing me any favors by embracing Islam. In fact, it is God who has done you a great favor by guiding you to the faith. (Think about this) if you are people of truth.

# 4630

God knows whatever is unseen in the heavens and in the earth. He is Well Aware of what you do".

# 4631

By Qaf and the glorious Quran, (you are the Messenger of God).

# 4632

In fact, it seems odd (to the pagans) that a warner from their own people has come to them. The disbelievers have said, "It is very strange

# 4633

that after we die and become dust, we shall be brought back to life again. This seems far from reality".

# 4634

We already know how much of them (of their bodies) the earth will consume. With Us there is a Book that contains all records.

# 4635

In fact, they have rejected the truth that has come to them, thus, they live in confusion.

# 4636

Have they not seen how We have established the sky above them and decked it without gaps and cracks?

# 4637

(Have they not seen) how We have spread out the earth, placed on it firm mountains and have made all kinds of flourishing pairs of plants grow?

# 4638

This is a reminder and it sharpens the insight of every servant of God who turns to Him in repentance.

# 4639

We have sent blessed water down from the sky to grow gardens, harvestable crops

# 4640

and tall palm-trees with clusters of dates

# 4641

as sustenance for My servants. With this We have brought the dead land back to life. Thus, will also be your resurrection.

# 4642

The people of Noah, dwellers of the Ra's, Thamud,

# 4643

Ad, the Pharaoh, Lot,

# 4644

dwellers of the forest, and the people of Tubba had all rejected the Prophets. Thus, they became subject to Our torment.

# 4645

Did We fail to accomplish the first creation? Of course, We did not; We have all power over all things. Yet they are confused about a new creation.

# 4646

We swear that We have created the human being and We know what his soul whispers to him. We are closer to him than even his jugular vein.

# 4647

Since the two scribes are sitting on each of his shoulders, he does not utter a word which is not recorded immediately by the watchful scribes.

# 4648

The human being will certainly experience the agony of death

# 4649

and (the human being will be told), "This is what you had been trying to run away from".

# 4650

The trumpet will certainly be sounded. This will be the day (about which you) were threatened.

# 4651

Every soul will be accompanied (by an angel) behind him and another as a witness.

# 4652

(He will be told), "You were completely heedless of this day. We have removed the veil from your eyes and your vision will now be sharp and strong".

# 4653

His (angelic) companion will say, "(Lord), the record of his deeds is with me and is all ready".

# 4654

(They will be told,) "Throw into hell every persistent disbelievers,

# 4655

who is an opponent of good, a suspicious transgressor

# 4656

and an idol worshipper. Throw him into severe torment".

# 4657

His satanic companion will say, "Our Lord, I did not mislead him, but he himself went astray".

# 4658

The Lord will say, "Do not argue in My presence; I had certainly sent you a warning.

# 4659

No word is to be exchanged in My presence. I am not unjust to My servants".

# 4660

On that day We shall ask hell, "Are you full?" It will say, "Are there any more?"

# 4661

Paradise will be brought near for the pious ones

# 4662

(and they will be told), "This is what you were promised. It is for everyone who turned in repentance to God, kept his promise,

# 4663

feared the Beneficent God in secret, and turned to Him with a repenting heart".

# 4664

(They will be told), "Enter Paradise in peace and, therein, you will live forever".

# 4665

They will have therein whatever they want and will receive from Us more rewards

# 4666

How many an ancient town who were much stronger than them (unbelievers) did We destroy. (In vain), they wandered through the land in search of a place of refuge from Our torment.

# 4667

This is a reminder for everyone who understands, listens, and sees.

# 4668

We created the heavens, the earth, and all that is between them in six days without experiencing any fatigue.

# 4669

(Muhammad), exercise patience against what they say. Glorify your Lord with His praise before sunrise and sunset.

# 4670

Glorify Him during the night and also glorify Him after prostration.

# 4671

Wait for the day when the trumpet will be sounded from a nearby place.

# 4672

On that day they will certainly hear the sound of the trumpet and that will be the Day of Resurrection.

# 4673

We give life and cause things to die. To Us all things will return.

# 4674

On the day when the earth is rent asunder, they will quickly come out of their graves. This is how easy it is for Us to bring about the Day of Resurrection.

# 4675

We know best what they say and you cannot compel them. Remind, by way of the Quran, those who have fear of My warnings.

# 4676

By the winds which carry dust particles,

# 4677

by the clouds which are heavily loaded with water,

# 4678

by the ships which smoothly sail on the oceans,

# 4679

by the angels which distribute the affairs,

# 4680

that what you are promised is certainly true

# 4681

and the Day of Judgment will inevitably take place.

# 4682

By the beautiful heavens,

# 4683

your ideas are confused.

# 4684

Let whoever wishes, turn away from Our Quran.

# 4685

Death to those whose opinions are merely baseless conjectures.

# 4686

and who wander in the abyss of confusion.

# 4687

They ask, "When it will be the Day of Judgment?"

# 4688

On the Day of Judgment they will be punished by the fire

# 4689

and will be told, "Suffer the torment which you wanted to experience immediately".

# 4690

The pious ones will live amidst gardens and springs,

# 4691

receiving their reward from their Lord. They had been righteous people before the Day of Judgment.

# 4692

They slept very little during the night

# 4693

and asked for forgiveness in the early morning.

# 4694

They assigned a share of their property for the needy and the destitute.

# 4695

In the earth there is evidence (of the Truth) for those who have strong faith.

# 4696

There is also evidence of the Truth within your own selves. Will you then not see?

# 4697

In the heavens there is your sustenance and that which you were promised (Paradise).

# 4698

This, by the Lord of the heavens and the earth is as certain as your ability to speak.

# 4699

Have you heard the story of the honorable guests of Abraham?

# 4700

When they came to him saying, "Peace be with you," he replied to their greeting in the same manner and said to himself, "These are a strange people".

# 4701

He went quietly to his wife and returned to his guests with a fat, roasted calf.

# 4702

He placed it before them. Then he said, "Why are you not eating?"

# 4703

He began to feel afraid. They said, "Do not be afraid," and then gave him the glad news of the birth of a knowledgeable son.

# 4704

His wife came forward, crying and beating her face, saying, "I am an old barren woman!"

# 4705

They said, "This is true but your Lord has said, (that you will have a son); He is All-wise and All-knowing".

# 4706

Abraham asked, "Messengers, what is your task?"

# 4707

They replied, "We have been sent to a sinful people

# 4708

to bring down upon them showers of marked lumps of clayy.

# 4709

They are transgressors in the presence of your Lord".

# 4710

We saved the believers among them,

# 4711

but We found only one Muslim house.

# 4712

We left therein evidence for those who fear the painful torment.

# 4713

There is also evidence (of the Truth) in the story of Moses when We sent him to the Pharaoh with clear authority.

# 4714

The Pharaoh and his forces turned away from him, saying, "He is either a magician or an insane person".

# 4715

We seized him and his army and threw them into the sea. He himself was to be blamed.

# 4716

There is also evidence of the Truth in the story of Ad whom We struck with a violent wind

# 4717

which turned everything it approached into dust.

# 4718

There is also evidence (of the Truth) in the story of the Thamud, who were told to enjoy themselves for an appointed time.

# 4719

They transgressed against the command of their Lord. So a blast of sound struck them and they were unable to do anything but stare.

# 4720

They were unable to stand up, nor were they helped.

# 4721

The people of Noah who lived before them were also evil doing people.

# 4722

We have made the heavens with Our own hands and We expanded it.

# 4723

We have spread out the earth and how brilliantly it is spread!

# 4724

We have created everything in pairs so that perhaps you may take heed.

# 4725

(Muhammad), tell them,"Seek refuge in God. I have been sent from Him to plainly warn you.

# 4726

Do not choose other gods besides Him. I have been sent from Him to plainly warn you".

# 4727

In the same way no Messenger came to those who lived before them without his people calling him a magician or an insane person.

# 4728

Have they inherited such dealings with the Prophets from their predecessors or are they a rebellious people?

# 4729

(Muhammad), leave them alone and you will not be blamed.

# 4730

Keep on reminding them. This benefits the believers.

# 4731

We have created jinn and human beings only that they might worship Me.

# 4732

I do not expect to receive any sustenance from them or that they should feed Me.

# 4733

It is God Who is the Sustainer and the Lord of invincible strength.

# 4734

The unjust will bear a burden like that of their unjust predecessors. Let them not make Me bring immediate punishment upon them.

# 4735

Woe to the disbelievers when the day with which they have been threatened comes!

# 4736

By the Mount (Sinai),

# 4737

by the book (Torah) written

# 4738

on parchment for distribution,

# 4739

by the established House (Mecca),

# 4740

by the high ceiling (heaven),

# 4741

and by the swelling ocean,

# 4742

the torment of your Lord will inevitably take place

# 4743

and no one will be able to prevent it.

# 4744

On the day when the heavens will swiftly fly

# 4745

and the mountains quickly move.

# 4746

Woe will be to those who rejected the Truth

# 4747

and who indulged in false disputes against (God's revelations).

# 4748

On that day they will be violently pushed into the fire

# 4749

and they will be told, "This is the fire which you called a lie.

# 4750

Is it magic or do you not still see?

# 4751

Burn in its heat. It is all the same for you whether you exercise patience or not; This is the recompense for your deeds".

# 4752

The pious will live in bountiful Paradise,

# 4753

talking of what they have received from their Lord and of how their Lord has saved them from the torment of hell.

# 4754

They will be told, "Eat and drink to your heart's delight for what you have done".

# 4755

They will recline on couches arranged in rows and We shall couple them with maidens with large, lovely eyes.

# 4756

The offspring of the believers will also follow them to Paradise. So shall We join their offspring to them because of their faith. We shall reduce nothing from their deeds. Everyone will be responsible for his own actions.

# 4757

We shall provide them with fruits and the meat of the kind which they desire.

# 4758

They will pass cups of un-intoxicating and unsinful wine to one another.

# 4759

They will be served by youths who will be as beautiful as pearls.

# 4760

They will turn to one another ask questions,

# 4761

saying, "We were afraid while in the world.

# 4762

But God has granted us favors and saved us from the scorching heat of the torment.

# 4763

We had prayed to Him; He is Kind and All-merciful".

# 4764

(Muhammad), remind them, by the Grace of your Lord, that you are neither a soothsayer or an insane person.

# 4765

Do they say, "He is only a poet and we are waiting to see him die!?"

# 4766

Say, "Wait, I too am waiting with you".

# 4767

Does their reason tell them to say this or is it because they are a rebellious people?

# 4768

Do they say, "He has falsely invented it (the Quran)?" In fact, they themselves have no faith.

# 4769

Let them produce a discourse like it if they are true in their claim.

# 4770

Have they been created from nothing or are they themselves their own creators?

# 4771

Have they created the heavens and the earth? In fact, they have no strong faith.

# 4772

Do they own the treasures of your Lord? Have they any authority over God?

# 4773

Do they have a ladder (by which they can climb up to the heavens) and listen (to the angels) and come back to the rest of the people with clear authority?

# 4774

Do the daughters belong to Him and the sons to you?

# 4775

Do you (Muhammad) ask them for any payment (for your preaching) which they cannot afford?

# 4776

Do they have knowledge of the unseen, thus, are able to predict (the future)?

# 4777

Do they design evil plans? The disbelievers themselves will be snared by their evil plots.

# 4778

Do they have another god besides God? God is too exalted to be considered equal to the idols.

# 4779

Even if they were to see a part of the heavens falling down upon them, they would say, "It is only dense cloud".

# 4780

So leave them alone until they face the day when they will be struck dead from terror

# 4781

and when their evil plans will be of no benefit to them nor will they be helped.

# 4782

The unjust will suffer other torments besides this but most of them do not know.

# 4783

Wait patiently for the command of your Lord. We are watching over you. Glorify your Lord when you rise during the night

# 4784

and glorify Him after the setting of the stars.

# 4785

By the declining star,

# 4786

your companion is not in error nor has he gone astray.

# 4787

He does not speak out of his own desires.

# 4788

It is a revelations which has been revealed to him

# 4789

and taught to him

# 4790

by the great mighty one (Gabriel),

# 4791

the strong one who appeared on the uppermost horizon.

# 4792

He (Gabriel) then came nearer and nearer.

# 4793

until he was as close to him as the distance of two bows, or even less.

# 4794

He revealed to God's servant whatever he wanted.

# 4795

His (Muhammad's) heart did not lie to him about what his eyes had seen.

# 4796

Will you then argue with him about what he saw?

# 4797

He certainly saw him (Gabriel) during his other ascent

# 4798

to the Lot-tree (in the seven heavens)

# 4799

near which is Paradise.

# 4800

When the tree was covered with a covering,

# 4801

(Muhammad's) eyes did not deceive him, nor did they lead him to falsehood.

# 4802

He certainly saw the greatest (signs) of the existence of his Lord.

# 4803

(Can anything as such be considered true) of al-Lat, al-Uzza,

# 4804

and your third idol al-Manat (whom you considered as God's daughters)?

# 4805

Do sons belong to you and daughters to God?

# 4806

This is an unfair distinction!

# 4807

These are only names given by yourselves and your fathers. God has not given them any authority. They, (unbelievers), only follow mere conjecture and the desires of their souls, even though guidance has already come to them from their Lord.

# 4808

Can the human being have whatever he wishes?

# 4809

All that is in the life to come and all that is in this life belongs only to God.

# 4810

There are many angels in the heavens whose intercession will be of no benefit unless God grants such permission to whichever of them He wants.

# 4811

Only those who do not believe in the life hereafter call the angels, females. They have no knowledge about it.

# 4812

They only follow mere conjecture which can never sufficiently replace the Truth.

# 4813

(Muhammad), stay away from those who turn away from Our guidance and who do not desire anything except the worldly life.

# 4814

This is what the extent of their knowledge amounts to. Your Lord knows best who has gone astray from His path and who has been rightly guided.

# 4815

To God belongs whatever is in the heavens and the earth. In the end God will re-compense the evil doers for their deeds and reward the righteous ones for their deeds.

# 4816

Those who stay away from grave sins and indecency (should know that) for their trivial sins your Lord's forgiveness is vast. He knows best about you. When He created you from the earth and when you were embryos in your mother's wombs. Do not consider yourselves very great. God knows best who is the most righteous person.

# 4817

(Muhammad), have you ever seen the one who has turned away (from guidance),

# 4818

and grudgingly spends very little for the cause of God?

# 4819

Does he possess the knowledge of the unseen, thus, he sees (all things)?

# 4820

Has not he been informed of the contents of the Book of Moses

# 4821

and about Abraham who fulfilled his duty (to God)?

# 4822

Certainly no one will bear the responsibility of the sins of another,

# 4823

nor can man achieve anything without hard labor.

# 4824

He will certainly see the result of his labor

# 4825

and will be fully recompensed for his deeds.

# 4826

To your Lord will all things eventually return.

# 4827

It is He who causes laughter and weeping.

# 4828

It is He who causes death and gives life.

# 4829

It is He who has created spouses, male and female,

# 4830

from a discharged living germ

# 4831

and on Him depends the life hereafter.

# 4832

It is He who grants people temporary and durable wealth.

# 4833

It is He who is the Lord of Sirius.

# 4834

It is He who utterly destroyed the ancient tribes of Ad,

# 4835

Thamud,

# 4836

and the people of Noah; they were the most unjust and rebellious people.

# 4837

It is He who turned upside down the people of Lot

# 4838

and covered them with torment.

# 4839

About which of the bounties of your Lord can they persistently dispute?

# 4840

This is a (Prophet) like that of the ancient warners (Prophets).

# 4841

The Day of Judgment is drawing nearer.

# 4842

No one besides God can rescue a soul from hardship.

# 4843

Does this statement seem strange to them

# 4844

and do they laugh instead of weeping,

# 4845

indulging in carelessly idle games?

# 4846

So prostrate yourselves before God and worship him.

# 4847

The Hour of Doom is drawing near and the moon is rent asunder.

# 4848

Whenever they see a miracle, they turn away from it and say, "This is just a powerful magic".

# 4849

They have rejected it and have followed their own desires, but all matters will be settled (by God).

# 4850

They have certainly received the kind of news in which there is a lesson and strong words of wisdom,

# 4851

but the warnings have proved to have no effect on them.

# 4852

(Muhammad), leave them alone. On the day when they will be called to a terrible punishment,

# 4853

they will come out of their graves, their eyes cast down, hastening towards their Summoner as locusts rushing about.

# 4854

These disbelievers will say, "This is a hard day".

# 4855

The people of Noah, who lived before them, had also rejected (Our guidance). They rejected Our servant and said, "He is an insane person so let us drive him away".

# 4856

Noah prayed, "Lord, help me; I am defeated".

# 4857

We opened the gates of the sky and water started to pour down.

# 4858

We caused the earth to burst forth with springs so that the waters could come together for a predestined purpose.

# 4859

We carried him, (Noah), on a vessel built with boards fixed together with nails,

# 4860

which floated on the water before Our very eyes. The flood was a recompense for the deeds of the disbelievers.

# 4861

We made (the story of Noah) as evidence of the Truth. However, is there anyone who would take heed?

# 4862

How terrible was My torment and the result of (their disregard) of My warning.

# 4863

We have made the Quran easy to understand, but is there anyone who would pay attention?

# 4864

The people of \`Ad rejected Our guidance. How terrible was My torment and the result (of their disregard) of My warning.

# 4865

On an unfortunate day We sent upon them a continuous violent wind

# 4866

which hurled people around like uprooted trunks of palm-trees.

# 4867

How terrible was Our torment and the result of (their disregard) of Our warning.

# 4868

We have made the Quran easy to understand, but is there anyone who would pay attention?

# 4869

The people of Thamud rejected Our warnings.

# 4870

They said, "Should we follow only one person among us. We shall be clearly in error and in trouble (if we do so).

# 4871

How is it that he has received guidance? In fact, he is the most untruthfull and arrogant person".

# 4872

(We told Salih), "Tomorrow they will know who is the most arrogant liar.

# 4873

We are sending the she-camel to them to test them. So watch them and be patient.

# 4874

Tell them that each one of them has the right to have a certain share of water".

# 4875

They called together their companions and agreed to slay the she-camel.

# 4876

How terrible was My punishment and warning.

# 4877

We sent upon them a single blast of sound and they were left like hay to be used by the cattle.

# 4878

We made the Quran easy to understand, but is there anyone who would take heed?

# 4879

The people of Lot rejected Our warning.

# 4880

We sent down upon them a violent sandstorm (which destroyed them all) except for the family of Lot, whom We saved in the early morning by Our favor.

# 4881

Thus do We recompense the grateful ones.

# 4882

Lot warned them against Our torment, but they persistently disputed it.

# 4883

They demanded that he turn over his guests to them.

# 4884

We struck their faces, blinded them and said, "Suffer Our torment of which you were warned".

# 4885

One early morning Our torment brought upon them utter destruction. We said, "Suffer Our torment of which you were warned".

# 4886

We have made the Quran easy to understand, but is there anyone who would pay attention?

# 4887

The Pharaoh and his people had also received Our warning,

# 4888

but they rejected all Our miracles. So We seized them in the way that a Majestic and All-powerful One would.

# 4889

Are you disbelievers mightier than those of the nations which We destroyed before or have you received amnesty through the ancient Scriptures?

# 4890

Do they say, "We shall be victorious because we are united?"

# 4891

(Let them know that) this united group will soon run away in defeat.

# 4892

In fact, the Hour of Doom is the time for them to suffer. The suffering of this hour is the most calamitous and the most bitter (of all suffering).

# 4893

The sinful ones will face the destructive torment of hell

# 4894

when they will be dragged on their faces into the fire and will be told, "Feel the touch of hell".

# 4895

We have created everything to fulfill a certain purpose.

# 4896

It takes only a single command from Us (to bring the Day of Judgment) and that can be achieved within the twinkling of an eye.

# 4897

We destroyed many people like you (disbelievers) but is there anyone who would take heed (of Our warning)?

# 4898

Whatever they have done has been recorded in the Books (records of the deeds).

# 4899

Every small or great deed is written down.

# 4900

The pious ones will live in Paradise wherein streams flow,

# 4901

honorably seated in the presence of the All-dominant King.

# 4902

The Beneficent (God)

# 4903

has taught the Quran to (Muhammad).

# 4904

He created the human being

# 4905

and has taught him intelligible speech.

# 4906

The sun and moon rotate in a predestined orbit.

# 4907

The plants and trees prostrate before Him.

# 4908

He raised the heavens and set up everything in balance,

# 4909

so that you would maintain justice.

# 4910

Therefore, maintain just measure and do not transgress against the Balance.

# 4911

He spread out the earth for the people.

# 4912

There exists all kinds of fruits, palm-trees with sheathed blossoms,

# 4913

grain with its husk and aromatic herbs.

# 4914

(Jinn and mankind) - which of the favors of your Lord do you deny?

# 4915

He created the human being from clay like that used for pottery

# 4916

and jinn from the many colored flames of fire.

# 4917

(Jinn and mankind) - which of the favors of your Lord do you deny?

# 4918

He is the Lord of the East and West through all seasons.

# 4919

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4920

He has made the two oceans meet each other,

# 4921

but has created a barrier between them so that they will not merge totally.

# 4922

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4923

From the two oceans comes pearls and coral.

# 4924

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4925

By His command, the ships with raised masts sail on the sea like mountains.

# 4926

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4927

Everyone on earth is destined to die.

# 4928

Only the Supreme Essence of your Glorious and Gracious Lord will remain forever.

# 4929

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4930

Everyone in the heavens and the earth depends on Him. His task in preserving His creation is continuous.

# 4931

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4932

Jinn and mankind, We shall certainly settle your accounts.

# 4933

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4934

Jinn and mankind, if you can penetrate the diameters of the heavens and the earth, do so, but you cannot do so without power and authority.

# 4935

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4936

Flames of fire and molten brass will be released against you and you will not be able to protect yourselves.

# 4937

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4938

(On the Day of Judgment) when the heavens are rent asunder they will have a flowery color and flow like oil.

# 4939

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4940

On that day there will be no need to ask mankind or jinn about his sin

# 4941

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4942

The guilty ones will be recognized by their faces and will be seized by their forelocks and feet.

# 4943

(Jinn and mankind) - which of the favors of your Lord do you then deny?

# 4944

(The guilty ones will be told), "This is hell which the sinful ones denied".

# 4945

They will run around in blazing fire and boiling water.

# 4946

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4947

Those who fear their Lord will have two gardens

# 4948

(jinn and mankind) - which of the favors of your Lord would you then deny?

# 4949

full of various trees.

# 4950

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4951

In the two gardens there will be two flowing springs.

# 4952

(Jinn and mankind) - which of the favors would you then deny?

# 4953

In them there are pairs of each kind of fruit.

# 4954

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4955

(The dwellers of Paradise) will recline on couches lined with silk brocade and it will be easy to reach the ripe fruits from the two gardens.

# 4956

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4957

There will be bashful maidens untouched by mankind or jinn before.

# 4958

jinn and mankindîwhich of the favors of your Lord would you then deny

# 4959

who are as beautiful as rubies and pearls.

# 4960

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4961

Can any thing else be a response to a favor but a favor?

# 4962

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4963

Besides this, there will be two other gardens.

# 4964

\- jinn and mankind - which of the favors of your Lord would you then deny

# 4965

\- dark green in color.

# 4966

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4967

In these there will also be two springs gushing forth.

# 4968

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4969

In both gardens there will be fruits, palm-trees, and pomegranates

# 4970

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4971

There will be well-disciplined, beautiful maidens.

# 4972

\- jinn and mankind - which of the favors of your Lord would you then deny

# 4973

\- with big, black and white beautiful eyes, dwelling in tents.

# 4974

\- jinn and mankind - which of the favors of your Lord would you then deny

# 4975

\- untouched by jinn or mankind before.

# 4976

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4977

They will be reclining on plain green and beautifully printed cushions

# 4978

(Jinn and mankind) - which of the favors of your Lord would you then deny?

# 4979

Blessed is the Name of your Lord, the Lord of Glory and Grace.

# 4980

When the inevitable event comes,

# 4981

no soul will deny its coming.

# 4982

It will abase some and exalt others.

# 4983

When the earth is violently shaken

# 4984

and the mountains crumbled,

# 4985

they will become like dust scattered around.

# 4986

On that day, you (mankind) will be divided into three groups:

# 4987

The people of the right hand - those whose books of records will be placed in their right hands. How happy they will be!

# 4988

The people of the left hand - those whose books of records will be placed in their left hands. How miserable they will be!

# 4989

The foremost ones (in faith and virtue) - the foremost ones in receiving their reward.

# 4990

(The foremost ones) will be the nearest ones to God

# 4991

in the beautiful Paradise.

# 4992

Many of them will be from the ancient people

# 4993

and only a few of them from the later generations.

# 4994

They will recline on jewelled couches

# 4995

facing one another.

# 4996

Immortal youths will serve them

# 4997

with goblets, jugs and cups of crystal clear wine

# 4998

which will not cause them any intoxication or illness.

# 4999

Also, they will be served with the fruits of their choice

# 5000

and the flesh of birds, as they desire.

# 5001

They will have maidens with large, lovely black and white eyes,

# 5002

like pearls preserved in their shells,

# 5003

as reward for their deeds.

# 5004

They will not hear any unnecessary or sinful talk

# 5005

except each other's greetings of, "Peace be with you".

# 5006

As for the people of the right hand, how happy they will be!

# 5007

They will live amid the thornless lot trees

# 5008

and banana trees,

# 5009

with fruits piled up one on the other,

# 5010

and amid the extended shade

# 5011

near to flowing water

# 5012

and abundant fruits,

# 5013

undiminished and never denied

# 5014

and the noble maidens

# 5015

that We have created (for the people of the right hand).

# 5016

We have made them virgins,

# 5017

loving and of equal age.

# 5018

These (people of the right hand) consist of many from the ancient

# 5019

and many from the later generations.

# 5020

As for the people on the left hand, how miserable they will be!

# 5021

They will live amid the scorching,

# 5022

scalding water and under a shadow of black smoke,

# 5023

neither cold nor graceful in shape.

# 5024

They had lived in luxury before this

# 5025

and persisted in heinous sins.

# 5026

It was they who said, "Shall we be resurrected after we die and have turned into dust and bones?

# 5027

Will our ancient forefathers be resurrected too?

# 5028

(Muhammad), say, "All the ancient and later generations

# 5029

will be brought together for an appointment on an appointed day.

# 5030

Then you people who had gone astray and rejected the Truth

# 5031

will eat from the fruit of the tree of Zaqqum,

# 5032

filling your bellies, with it

# 5033

and on top of this you will drink boiling water

# 5034

like a thirsty camel".

# 5035

Such will be their dwelling on the Day of Judgment.

# 5036

It is We who have created you. Why then did you not testify to the Truth?

# 5037

Have you seen sperm?

# 5038

Did you create it or was it We who created it?

# 5039

We have destined death for you and no one can challenge Us

# 5040

in replacing you with another creation like you, changing you into a form which you do not know.

# 5041

You certainly knew about (your) first development. Why do you not take heed?

# 5042

Have you seen what you sow?

# 5043

Do you make it grow or is it We who make it grow?

# 5044

Had We wanted, We could have crushed it to bits and you would have been left to lament,

# 5045

crying, "We have been left to suffer loss.

# 5046

Surely, we have been deprived (of the benefits)".

# 5047

Have you seen the water which you drink?

# 5048

Is it you who sent it down from the clouds or is it We who have sent it down?

# 5049

Had We wanted, We could have made it salty. Why then do you not give thanks?

# 5050

Have you seen the fire which you kindle?

# 5051

Is it you who have produced its tree or is it We who have produced it?

# 5052

It is We who have made it as a reminder and a means of comfort for the people.

# 5053

(Muhammad), glorify your Lord, the Great One.

# 5054

I do not need to swear by the setting of the stars

# 5055

\- which is indeed a great oath if only you knew it -

# 5056

that this is an honorable Quran

# 5057

preserved in a hidden Book which

# 5058

no one can touch it except the purified ones.

# 5059

(This Quran) is a revelation from the Lord of the Universe.

# 5060

Would you say that this statement is a lie?

# 5061

Would you reject the sustenance that you receive rather than give thanks?

# 5062

Why can you not help a soul dying

# 5063

right before your very eyes?

# 5064

We are closer to him than you, but you cannot see.

# 5065

If you are true to your claim that there is no Day of Judgment,

# 5066

why can you not bring it (the soul) back (to life)?

# 5067

(If a dying soul) is of those near to God,

# 5068

it will have rest, happiness, and a beautiful Paradise.

# 5069

If it is of the people of the right hand,

# 5070

it will be with the people of the right hand, living in peace and security.

# 5071

If it is of those who have rejected the Truth and have gone astray,

# 5072

its dwelling will be boiling water

# 5073

and the heat of hell fire.

# 5074

This is the absolute Truth and certainty.

# 5075

So glorify the name of your Lord, the Great One.

# 5076

All that is in the heavens and the earth glorify God. He is Majestic and All-wise.

# 5077

To Him belongs the Kingdom of the heavens and the earth. He gives life and causes things to die. He has power over all things.

# 5078

He is the First, the Last, the Manifest, and the Unseen and He knows all things.

# 5079

It is He who created the heavens and the earth in six days and then established His Dominion over the Throne. He knows whatever enters into the earth, what comes out of it, what descends from the sky, and what ascends to it. He is with you wherever you may be and He is Well Aware of what you do.

# 5080

To Him belong the heavens and the earth and to Him all things return.

# 5081

He causes night to enter into day and day into night. He knows best what all hearts contain.

# 5082

Have faith in God and His Messenger and spend for His cause out of what is entrusted to you. Those who believe and spend for the cause of God will have a great reward.

# 5083

If you are true indeed to this covenant, why do you not believe in God, when His Messenger invites you to believe in your Lord with whom you have made a solemn covenant?

# 5084

It is He who sends illustrious revelations to His servant to take you out of darkness to light. God is Compassionate and All-merciful to you.

# 5085

Why do you not spend for the cause of God when to Him belongs the heritage of the heavens and the earth? Those who spend for the cause of God and fight before victory will have higher positions than those who spend for the cause of God and fight after victory. However, to both parties God has promised good rewards. God is Well Aware of what you do.

# 5086

Whoever gives a virtuous loan to God will receive double from Him in addition to an honorable reward.

# 5087

On the Day of Judgment you will see the believers with their light shining in front of them and to their right. They will be told, "Paradise wherein streams flow is the glad news for you today. You will live therein forever. This is the greatest triumph".

# 5088

On that day the hypocrites will say to the believers, "Please look at us so that we might benefit from your light." They will be told, "Go back and search for your own light." A barrier with a door will be placed between them. Inside it there will be mercy but outside of it there will be torment.

# 5089

(Those outside) will call out, "Were we not with you?" (Those inside) will reply, "Yes, you were with us but you spent your life in disbelief and hypocrisy, wished death to (Muhammad), had doubts about his message and let your longings deceive you until the decree of God came to pass. The devil deceived you about the mercy of God.

# 5090

So on this day no ransom will be accepted from you nor from the disbelievers. Your dwelling will be fire. It will be your friend and a terrible end".

# 5091

Is it not time for the hearts of the believers to become humbled by the remembrance of God and by the Truth which has been revealed so that they will not be like the followers of the Bible who lived before them and whose hearts have become hard like stone through the long years. Many of them are evil doers.

# 5092

Know that God brings the dead earth back to life. We have explained Our revelations to you so that you may perhaps have understanding.

# 5093

The charitable men and women who give a virtuous loan to God will receive double from Him in addition to their honorable reward.

# 5094

Those who believe in God and His Messenger are the truthful ones and are witness (to the deeds of others) before their Lord. They will have their reward and their light. Those who disbelieve and reject Our revelations shall be the dwellers of hell.

# 5095

Know that the worldly life is only a game, a temporary attraction, a means of boastfulness among yourselves and a place for multiplying your wealth and children. It is like the rain which produces plants that are attractive to the unbelievers. These plants flourish, turn yellow, and then become crushed bits of straw. In the life hereafter there will be severe torment or forgiveness and mercy from God. The worldly life is only an illusion.

# 5096

Compete with one another to achieve forgiveness from your Lord and to reach Paradise, which is as vast as the heavens and the earth, and is prepared for those who believe in God and His Messenger. This is the blessing of God and He grants it to whomever He wants. The blessings of God are great.

# 5097

Whatever hardships you face on earth and in your souls were written in the Book before the creation of the souls. This is certainly easy for God

# 5098

so that you would not grieve over what you have lost nor become too happy about what God has granted to you. God does not love the arrogant boastful ones who are niggardly and who try to make other people also niggardly.

# 5099

Those who turn away (from guidance) should know that God is Self-sufficient and Praiseworthy.

# 5100

We sent Our Messengers with clear evidence (to support their truthfulness), and sent with them the Book and the Balance so that people would maintain justice. We sent down iron - in which there is strong power and benefit for the people - so that God would know who would help Him and His Messenger without seeing the unseen. God is All-powerful and Majestic.

# 5101

We sent Noah and Abraham and placed prophethood and the Book among their offsprings, some of whom have the right guidance. However, most of them are evil doers.

# 5102

Then We sent Our other Messengers to follow their traditions. After them We sent Jesus, the son of Mary, to whom We gave the Gospel. In the hearts of his followers We placed compassion and mercy. We did not command them to lead the monastic life. This was their own method of seeking the pleasure of God. Despite this intention, they did not properly observe it (the monastic life). To the believers among them, We gave their reward but many of them are evil-doers.

# 5103

Believers, have fear of God and believe in His Messenger. God will grant you a double share of mercy, a light by which you can walk, and forgive your sins. God is All-forgiving and All-merciful.

# 5104

(Have fear of God and believe in His Messenger) so that the followers of the Bible will know that they can receive no reward from God. They should know that all favors are in the hands of God. He grants them to whomever He wants. The favors of God are great.

# 5105

God has certainly heard the words of the woman who disputed with you about her husband and who (after not having received a favorable response from you) complained to God. God was listening to your argument. He is All-hearing and All-aware.

# 5106

Those who renounce their wives by calling them mothers should know that their wives could never become their mothers. Their mothers are those who have given birth to them. The words that they speak are certainly detestable and sinful. But God is Pardoning and All-forgiving.

# 5107

Those who renounce their wives by calling them mothers and then change their minds about what they have said will have to set free a slave as a ransom and only then will their carnal relations be lawful. This is what you have been commanded. God is Well Aware of whatever you do.

# 5108

If one cannot set free a slave, he must fast for two consecutive months, and only then can he have lawful carnal relations. If this is also not possible, he must feed sixty destitute people. This is the command of God, so that perhaps you will have faith in God and His Messenger. Such are the Laws of God, and those who disbelieve them will suffer a painful torment.

# 5109

Those who oppose God and His Messenger will be humiliated like those who lived before. We have sent illustrious revelations and those who disbelieve will suffer a humiliating torment.

# 5110

On the day when everyone will be resurrected, God will tell them about their deeds which He has recorded in their entirety - while they themselves have forgotten them. God is the witness over all things.

# 5111

Have you not considered that God knows all that is in the heavens and the earth? There is not a single place wherein any secret counsel can take place between any three people without God being the fourth, nor five people without His being the sixth nor any gathering of more or less people, wherever it may be, without His being with them. On the Day of Judgment, He will tell them about their deeds. God has the knowledge of all things.

# 5112

Have you not seen those who have been forbidden to have secret counsels violate this prohibition and resume their secret counsels for sinful and hostile purposes and to disobey the Messenger? When they come to you (Muhammad), they greet you with a greeting with which even God has not greeted you and say to themselves, "Why has God not punished us for what we say (if he is a true Prophet)?" The heat of hell is a sufficient torment for them. This is the most terrible fate.

# 5113

Believers, when you hold a secret counsel, let it not be for a sinful, hostile purpose or to disobey the Messenger, but let your counsel take place for virtuous and pious reasons. Have fear of God in whose presence you will all be brought together.

# 5114

Holding secret counsels for (evil purposes) is a work of satan to cause grief to the believers, but he can do no harm to them except by the will of God. Let the believers trust in God.

# 5115

Believers, when you are told to make room in a meeting for others, do so. God will then make room for you. When you are told to disperse, do so. God will raise the position of the believers and of those who have received knowledge. God is Well-Aware of what you do.

# 5116

Believers, whenever you consult the Prophet, offer charity before your consultation. This will be better for you and more pure. However, if you do not find anything to give in charity, then God is All-forgiving and All-merciful.

# 5117

Were you afraid that giving in charity before your consultation would make you poor? Since you did not offer such charity, God forgave you for this. At least be steadfast in prayer, pay the religious tax, and obey God and His Messenger. God is Well Aware of what you do.

# 5118

Have you not seen those who have established friendship with the people who are subject to the wrath of God? They do not belong to you nor you to them, yet they knowingly try to prove their point by using false oaths.

# 5119

God has prepared a severe torment for them. What an evil deed they have committed!

# 5120

They have made their oaths as a shield to obstruct others from the way of God. They will suffer a humiliating torment.

# 5121

Neither their wealth nor their children will be able to protect them against God. They will be the dwellers of hell fire wherein they will live forever.

# 5122

On the day when God will resurrect them all together, they will swear to Him as they swore to you and they will think that they have a good case but they are certainly liars.

# 5123

Satan has dominated them and has made them forget the guidance of God. They are Satan's party and the party of Satan will certainly suffer a great loss.

# 5124

Disgrace will strike those who oppose God and His Messenger.

# 5125

God has decreed, "I and My Messenger shall certainly triumph." God is All-powerful and Majestic.

# 5126

You will not find any people of faith in God and the Day of Judgment who would establish friendship with those who oppose God and His Messenger, even if it would be in the interest of their fathers, sons, brothers, and kinsmen. God has established faith in their hearts and supported them by a Spirit from Himself. He will admit them to Paradise wherein streams flow to live therein forever. God is pleased with them and they are pleased with God. These are members of the party of God and the party of God will certainly have everlasting happiness.

# 5127

All that is in the heavens and the earth glorify God. He is the Majestic and All-wise.

# 5128

It is He who drove the disbelievers among the followers of the Bible out of their homes (in the Arabian Peninsula) as the first time exiles. You did not think that they would leave their homes and they thought that their fortresses would save them from God. The decree of God came upon them in a way that even they did not expect. He caused such terror to enter their hearts that they started to destroy their own homes by their own hands and by those of the believers. People of vision, learn from this a lesson.

# 5129

Had God not decreed exile for them, He would have certainly punished them (in some other way). In this life and in the next life they would have suffered the torment of hell fire.

# 5130

This is because they opposed God and His Messenger and whoever opposes God should know that God's retribution is severe.

# 5131

All the productive palm-trees (of the Jews hostile to you) which you cut down or left untouched were the will of God to bring disgrace upon the evil-doers.

# 5132

Since you did not have to exhaust your horses and camels or (even fight), God granted to His Messenger their property. God gives authority to His Messenger over whomever He wants. God has power over all things.

# 5133

Whatever God grants to His Messenger (out of the property) of the people of the towns, belongs to God, the Messenger, the kinsfolk, the orphans, the destitute and to those who may become needy while on a journey, so that it will not circulate only in the hands of rich ones among them. Take only what the Messenger gives to you and desist from what he forbids you. Have fear of God; God is severe in His retribution.

# 5134

The poor immigrants who were deprived of their homes and property, who seek favors and pleasures from God, and help Him and His Messenger will also have (a share in the said property). These people are the truthful ones.

# 5135

Those who established a community center and embraced the faith before the arrival of the immigrants love those who have come to their town. They are not jealous of what is given to the immigrants. They give preference to them over themselves - even concerning the things that they themselves urgently need. Whoever controls his greed will have everlasting happiness.

# 5136

Those who migrated later (to Medina) say, "Lord, forgive us and our brothers who preceded us in the faith, and clear our hearts of any ill will against the believers. Lord, You are Compassionate and All-merciful".

# 5137

Have you not seen the hypocrites who say to their disbelieving brothers among the People of the Book, "If you are driven out, we shall, also, leave the town with you and we shall never obey whoever seeks to harm you. If you are attacked, we shall help you." God testifies that they are liars.

# 5138

If they were to be expelled, they would not go with them. If they were to be attacked they would not help them. Even if they were to help them, they would run away from the battle and leave them helpless.

# 5139

They are more afraid of you than of God. They are a people who lack understanding.

# 5140

They will not fight you united except with the protection of fortified towns or from behind walls. They are strong among themselves. You think that they are united, but in fact, their hearts are divided. They are a people who have no understanding.

# 5141

They are like those who, a short time before, suffered the consequences of their deeds. They, too, will suffer a painful torment.

# 5142

They are like satan who said to people, "Reject the faith," but when the people rejected the faith he said, "I have nothing to do with you. I fear the Lord of the Universe".

# 5143

The fate of both of them will be hell fire wherein they will live forever. Thus will be the recompense for the unjust.

# 5144

Believers, have fear of God. A soul must see what it has done for the future. Have fear of God for He is All-aware of what you do.

# 5145

Do not be like those who forget about God. He will make them forget themselves. These are the sinful people.

# 5146

The Companions of the Fire and the Companions of the Garden are not equal. The Companions of the Garden will achieve felicity.

# 5147

The people of Paradise and hell are not alike; the people of Paradise are the successful ones. Had We sent down this Quran on a mountain, you would have seen it humbled and rent asunder for fear of God. These are parables which We tell to people so that perhaps they will think.

# 5148

He is God, the only Lord, Who knows the unseen and the seen. He is the Beneficent and All-merciful One.

# 5149

He is the only Lord, the King, the Holy, the Peace, the Forgiver, the Watchful Guardian, the Majestic, the Dominant, and the Exalted. God is too exalted to have any partner.

# 5150

He is the Creator, the Designer, the Modeler, and to Him belong all virtuous names. All that is in the heavens and the earth glorify Him. He is All-majestic and All-wise.

# 5151

Believers, do not choose My enemies and your own enemies for friends, and offer them strong love. They have rejected the Truth which has come to you, and have expelled the Messenger and you from your homes because of your belief in your Lord. When you go to fight for My cause and seek My pleasure, you secretly express your love of them. I know best what you reveal or conceal. Whichever of you does this has indeed gone astray from the right path.

# 5152

If they find an opportunity to turn against you, they will become your enemies and will stretch out their hands and tongues at you with evil intent. They would love to see you turn away from your faith.

# 5153

Your relatives and children will never be of any benefit to you on the Day of Judgment. God will separate you from them. He is All-aware of what you do.

# 5154

Abraham and those with him are the best examples for you to follow. They told the people, "We have nothing to do with you and with those whom you worship besides God. We have rejected you. Enmity and hatred will separate us forever unless you believe in One God." Abraham told his father, "I shall ask forgiveness for you only, but I shall not be of the least help to you before God".

# 5155

They prayed, "Lord, we have trust in You, turned to You in repentance, and to You we shall all return. Lord, save us from the evil intentions of the disbelievers. Our Lord, forgives us. You are Majestic and All-wise".

# 5156

They are the best examples for those who have hope in God and the Day of Judgment. Whoever turn away should know that God is Self-sufficient and Praiseworthy.

# 5157

God will perhaps bring about love between you and those of the disbelievers with whom you were enemies. God is All-powerful, All-merciful, and All-forgiving.

# 5158

God does not forbid you to deal kindly and justly with those who have not fought against you about the religion or expelled you from your homes. God does not love the unjust people.

# 5159

He only forbids you to be friends with those who have fought against you about the religion, expelled you from your homes or supported others in expelling you. Whoever loves these people are unjust.

# 5160

Believers, when believing immigrant women come to you, test them. God knows best about their faith. If you know that they are believers, do not return them to the disbelievers. Such women are not lawful for them and disbelievers are not lawful for such women. Give the disbelievers whatever they have spent (on such women for their dowry). There is no offense for you to marry them if you agree to give them their dowry. Do not hold unto your disbelieving wives; you may get back what you have spent on them for their dowry and the disbelievers may also ask for what they have spent. This is the command of God by which He judges you. God is All-knowing and All-wise.

# 5161

If your wives go away from you to disbelievers who will not give you back the dowry which you spent on them, let the Muslims pay back such dowry from the property of the disbelievers which may come into their hands. Have fear of God in whom you believe.

# 5162

Prophet, when believing women come to you pledging not to consider anything equal to God, not to steal, or to commit fornication, not to kill their children, or to bring false charges against anyone (such as ascribing others children to their husbands), and not to disobey you in lawful matters, accept their pledge, and ask forgiveness for them from God. God is All-forgiving and All-merciful.

# 5163

Believers, do not establish friendship with the people who have become subject to the wrath of God. They do not have any hope in the life to come, just as the disbelievers have no hope in those who are in their graves.

# 5164

All that is in the heavens and the earth glorify God. He is the Majestic and All-wise.

# 5165

Believers, why do you preach what you do not practice?

# 5166

It is most hateful in the sight of God if you say something and do not practice it.

# 5167

God loves those who fight for His cause in battlefield formations firm as an unbreakable concrete wall.

# 5168

Moses said to his people, "Why do you create difficulties for me when you know that I am God's Messenger to you?" When they deviated (from the right path), God led their hearts astray. God does not guide the evil-doing people.

# 5169

Jesus, son of Mary, said to the Israelites, "I am the Messenger of God sent to you. I confirm the Torah which is in existence and give you the glad news of the coming of a Messenger who will come after me named Ahmad." When this Messenger came to them with all the proofs (to support his truthfulness), they said, "He is simply a magician".

# 5170

Who is more unjust than one who creates falsehood against God when he has already been invited to Islam? God does not guide the unjust people.

# 5171

They want to put out the light of God with their mouths, but God will certainly make His light shine forever - even though the disbelievers may dislike this.

# 5172

It is He who has sent His Messenger with guidance and the true religion to stand supreme over all religions, even though the pagans may dislike it.

# 5173

Believers, shall I show you a bargain which will save you from the painful torment?

# 5174

Have faith in God and His Messenger and strive hard for His cause with your wealth and in persons. This is better for you if only you knew it.

# 5175

God will forgive your sins and admit you into Paradise wherein streams flow, and you live in the lofty mansions of the garden of Eden. This is indeed the greatest triumph.

# 5176

(Besides forgiveness) you will receive other favors which you will love: help from God and an immediate victory (Muhammad), give such glad news to the believers.

# 5177

Believers, be the helpers of God just as when Jesus, the son of Mary, asked the disciples, "Who will be my helpers for the cause of God?" and the disciples replied, "We are the helpers of God." A group of the Israelites believed in him and others rejected him. We helped the believers against their enemies and they became victorious.

# 5178

All that is in the heavens and the earth glorify God, the King, the Holy, the Majestic and the All-wise.

# 5179

It is He who has sent to the illiterate a Messenger from among their own people to recite to them His revelations and purify them. He will teach the Book to them

# 5180

and others who have not yet joined, and He will give them wisdom. Before this they had been in plain error. God is Majestic and All-wise.

# 5181

Such is the favor of God which He grants to whomever He wants. God's favor is great.

# 5182

Those who were to carry the responsibility of the Torah but ignored, are like donkeys laden with books. How terrible is the example of the people who reject the revelations of God. God does not guide the unjust.

# 5183

(Muhammad), ask the Jews, "If you believe that you are the chosen people of God to the exclusion of all other people, wish for death if you are truthful".

# 5184

They will never wish for death because of what they have done! God knows best about the unjust people.

# 5185

(Muhammad), tell them, "The death from which you run away will certainly approach you. Then you will be returned to the One who knows the unseen and the seen, and He will tell you what you have done".

# 5186

Believers, on Friday when the call for prayer is made, try to attend prayer (remembering God) and leave off all business. This would be better for you if only you knew it.

# 5187

When the prayer ends, disperse through the land and seek the favor of God. Remember Him often so that perhaps you will have everlasting happiness.

# 5188

When they see some merchandise or some sport, they rush towards it and leave you alone standing. Say, "(God's rewards for good deeds) are better than merriment or merchandise; God is the best Sustainer".

# 5189

When the hypocrites come to you, they say, "We testify that you are the Messenger of God." God knows that you are His Messenger. God testifies that they hypocrites are liars.

# 5190

They have chosen their oaths as a shield for them to obstruct others from the way of God. How terrible is what they do!

# 5191

This is because they accepted the faith and then rejected it. God has sealed their hearts, thus, they do not have any understanding.

# 5192

Their physical appearance attracts you when you see them and when they speak, you carefully listen to them. In fact, they are like propped up hollow trunks of wood (They are so cowardly) they think that every cry which they hear is against them. They are the enemy, so beware of them. May God condemn them. Where are they turning to, leaving behind the Truth?

# 5193

When they are told, "Come and let the Prophet of God seek forgiveness for you," they shake their heads and you can see them arrogantly turning away.

# 5194

It is all the same whether you seek forgiveness for them or not; God will never forgive them. God does not guide the evil-doing people.

# 5195

It is they who say, "Give nothing to those who are around the Messenger of God so that they will desert him." To God belongs the treasures of the heavens and the earth, but the hypocrites have no understanding.

# 5196

They say, "When we return to Medina, the honorable ones will certainly drive out the mean ones." Honor belongs to God, His Messenger and the believers, but the hypocrites do not know.

# 5197

Believers, do not let your wealth and children divert you from remembering God. Wwhoever is diverted will suffer a great loss.

# 5198

Spend for the cause of God out of what We have given you before death approaches you, and say, "Lord, would that you would give me respite for a short time so that I could spend for Your cause and become one of those who do good".

# 5199

God will never grant respite to any soul when its appointed time has come. God is Well-Aware of what you do.

# 5200

All that is in the heavens and the earth glorify God. To Him belongs the Kingdom and all praise. He has power over all things.

# 5201

It is He who has created you all but some of you have accepted the faith and some of you have not. God is Well Aware of what you do.

# 5202

He has created the heavens and the earth for a genuine purpose and has formed you in the best shape. To Him all things return.

# 5203

He knows all that is in the heavens and the earth and all that you reveal or conceal. God knows best whatever the hearts contain.

# 5204

Have you not received the news about the disbelievers living before you who suffered the consequences of their deeds and will suffer a painful torment?

# 5205

This was because their messengers came to them with clear proof (to support their prophethood) and they said, "Can mere mortals provide us with guidance?" They rejected the Messengers and turned away. God does not need the worship of anyone. He is Self-sufficient and Praiseworthy.

# 5206

The disbelievers have thought that they would never be resurrected (Muhammad). Say, "I swear by my Lord that you will certainly be resurrected and will be told about all that you have done." All this is certainly very easy for God.

# 5207

Thus, have faith in God, His Messenger and the Light which We have revealed. God is Well-Aware of what you do.

# 5208

On the day when We shall gather you all together (for the Day of Judgment), all cheating will be exposed. Those who believe in God and act righteously will receive forgiveness for their sins. They will be admitted into Paradise wherein streams flow and they will live forever. This certainly is the greatest triumph.

# 5209

As for those who have disbelieved and rejected Our revelations, they will dwell forever in hell fire, a terrible fate.

# 5210

No one will be afflicted with any hardship without it being the will of God. The hearts of whoever believed in God will receive guidance. God has the knowledge of all things.

# 5211

Obey God and the Messenger, but if you turn away, know that the only duty of Our Messenger is to clearly preach.

# 5212

God is the only Lord and in Him the believers should trust.

# 5213

Believers, some of your wives and children may prove to be your enemies so beware of them. However, if you would pardon, ignore and forgive, know that God is All-forgiving and All-merciful.

# 5214

Your property and children are a trial for you, but the reward (which one may receive from God) is great.

# 5215

Have as much fear of God as best as you can. Listen to the Messenger, obey him, and spend for your own sake good things for the cause of God. Those who control their greed will have everlasting happiness.

# 5216

If you give a virtuous loan to God, He will pay back double and forgive your sins. God is the Most Appreciating and the Most Forbearing.

# 5217

He knows the unseen and the seen. He is the Majestic and All-wise.

# 5218

Prophet and believers, if you want to divorce your wives, you should divorce them at a time after which they can start their waiting period. Let them keep an account of the number of the days in the waiting period. Have fear of God, your Lord. (During their waiting period) do not expel them from their homes and they also must not go out of their homes, unless they commit proven indecency. These are the Laws of God. Whoever transgresses against the laws of God has certainly wronged himself. You never know, perhaps God will bring about some new situation.

# 5219

When their waiting period is about to end, keep them or separate from them lawfully. Let two just people witness the divorce and let them bear witness for the sake of God. Thus does God command those who have faith in Him and the Day of Judgment.

# 5220

God will make a way (out of difficulty) for one who has fear of Him and will provide him with sustenance in a way that he will not even notice. God is Sufficient for the needs of whoever trusts in Him. He has full access to whatever He wants. He has prescribed a due measure for everything.

# 5221

If you have any doubt whether your wives have reached the stage of menopause, the waiting period will be three months. This will also be the same for those who do not experience menstruation. The end of the waiting period for a pregnant woman is the delivery. God will make the affairs of one who fears Him easy.

# 5222

This is the command of God which He has revealed to you. God will expiate the evil deeds of those who fear Him and will increase their rewards.

# 5223

Lodge them (your wives) where you lived together if you can afford it. Do not annoy them so as to make life intolerable for them. If they are pregnant, provide them with maintenance until their delivery. Pay their wage if they breast-feed your children and settle your differences lawfully. If you are unable to settle them, let another person breast-feed the child.

# 5224

Let the well-to-do people spend abundantly (for the mother and the child) and let the poor spend from what God has given them. God does not impose on any soul that which he cannot afford. God will bring about ease after hardship.

# 5225

How many a town has disobeyed its Lord and His Messenger! For them Our questioning was strict and Our punishment severe.

# 5226

They suffered the consequences of their deeds and their end was perdition.

# 5227

God has prepared severe retribution for them. People of understanding and believers, have fear of God. God has certainly sent you a reminder,

# 5228

a Messenger who recites to you the illustrious revelations of God, to bring the righteously striving believers out of darkness into light. God will admit those who believe in Him and act righteously to Paradise wherein streams flow, and they will live therein forever. God will provide them with excellent sustenance.

# 5229

It is God who has created the seven heavens and a like number of earths. His commandments are sent between them, so that you would know that God has power over all things and that His knowledge encompasses all.

# 5230

Prophet, in seeking the pleasure of your wives, why do you make unlawful that which God has made lawful. God is All-forgiving and All-merciful.

# 5231

God has shown you how to absolve yourselves of your oaths. He is your Guardian and is All-knowing and All-wise.

# 5232

The Prophet told a secret to one of his wives telling her not to mention it to anyone else. When she divulged it, God informed His Prophet about this. The Prophet told his wife part of the information which he had received from God and ignored the rest. Then she asked, "Who informed you about this?" He replied, "The All-aware and All-knowing one has told me".

# 5233

Would that you two (wives of the Prophet) had turned to God in repentance. Your hearts have sinned. If you conspire with each other against him, know that God is his Guardian. Gabriel, the righteous (ones) among the believers and the angels will all support him.

# 5234

If he divorces you, perhaps his Lord will replace you with better wives, either widows or virgins who will be Muslims: believers, faithful, obedient, repentant, and devout in prayer and fasting.

# 5235

Believers, save yourselves and your families from the fire which is fueled by people and stones and is guarded by stern angels who do not disobey God's commands and do whatever they are ordered to do.

# 5236

Disbelievers (will be told on the Day of Judgment), "Do not make any excuses on this day; you are only receiving recompense for what you have done".

# 5237

Believers, turn to God in repentance with the intention of never repeating the same sin. Perhaps your Lord will expiate your evil deeds and admit you to Paradise wherein streams flow. On the Day of Judgment, God will not disgrace the Prophet and those who have believed in him. Their lights will shine in front of them and to their right. They will say, "Our Lord, perfect our light for us and forgive our sins. You have power over all things".

# 5238

Prophet, fight against the disbelievers and the hypocrites and be stern against them. Their dwelling will be hell fire, the most terrible fate.

# 5239

God has told the disbelievers the story of the wives of Noah and Lot as a parable. They were married to two of Our righteous servants but were unfaithful to them. Nothing could protect them from the (wrath) of God and they were told to enter hell fire with the others.

# 5240

To the believers, as a parable, God has told the story of the wife of the Pharaoh who said, "Lord, establish for me a house in Paradise in your presence. Rescue me from Pharaoh and his deeds and save me from the unjust people.

# 5241

He has also told, as a parable, the story of Mary, daughter of Imran who preserved her virginity and (into whose womb) We breathed Our spirit. She made the words of her Lord and the predictions in His Books come true. She was an obedient woman.

# 5242

Blessed is He in whose hands is the Kingdom and who has power over all things.

# 5243

It is He who has created death and life to put you to the test and see which of you is most virtuous in your deeds. He is Majestic and All-forgiving.

# 5244

It is He who has created seven heavens, one above the other. You can see no flaw in the creation of the Beneficent God. Look again. Can you see faults?

# 5245

Look twice (and keep on looking), your eyes will only become dull and tired.

# 5246

We have decked the lowest heavens with torches. With these torches We have stoned the devils and We have prepared for them the torment of hell.

# 5247

For those who have disbelieved in their Lord, We have prepared the torment of hell, the most terrible place to return.

# 5248

When they are thrown into hell, they will hear its roaring while it boils.

# 5249

It almost explodes in rage. Whenever a group is thrown into it, its keepers will ask them, "Did no one come to warn you?"

# 5250

They will say, "Yes, someone did come to warn us, but we rejected him saying, 'God has revealed nothing. You are in great error".

# 5251

They will also say, "Had We listened or used our minds, we would not have become the dwellers of hell".

# 5252

They will confess to their sins, but the dwellers of hell will be far away from God's (mercy).

# 5253

Those who fear their Lord in secret will receive forgiveness and a great reward.

# 5254

Whether you conceal what you say or reveal it, God knows best all that the hearts contain.

# 5255

Does the One Who is Subtle, All-aware, and Who created all things not know all about them?

# 5256

It is He who has made the earth subservient to you. You walk through its vast valleys and eat of its sustenance. Before Him you will all be resurrected.

# 5257

Do you feel secure that the One in the heavens will not cause you to sink into the earth when it is violently shaking?

# 5258

Do you feel secure that the One in the heavens will not strike you with a sandstorm? You will soon know, with the coming of the torment, how serious Our warning was.

# 5259

Those who lived before them had also rejected Our warning, and how terrible was Our retribution!

# 5260

Did they not see the birds above them, stretching out, and flapping their wings. No one keeps them up in the sky except the Beneficent God. He certainly watches over all things.

# 5261

Do you have any armies who will help you against the Beneficent God? The disbelievers are certainly deceived (by satan).

# 5262

Is there anyone who will provide you with sustenance if God were to deny you sustenance? In fact, they obstinately persist in their transgression and hatred.

# 5263

Can one who walks with his head hanging down be better guided that one who walks with his head upright?

# 5264

(Muhammad), say, "It is God who has brought you into being and made ears, eyes, and hearts for you, but you give very little thanks".

# 5265

Say, "It is God who has settled you on the earth and to Him you will be resurrected".

# 5266

They say, "When will this torment take place if what you say is true?"

# 5267

Say, "God knows best. I am only one who gives warning".

# 5268

When they see the torment approaching, the faces of the disbelievers will blacken and they will be told, "This is what you wanted to (experience)".

# 5269

(Muhammad), say, "Have you not considered that regardless whether God forgives me and my followers or grants us mercy, but who will protect the disbelievers from a painful torment?

# 5270

Say, "He is the Beneficent One in whom we have faith and trust. You will soon know who is in manifest error".

# 5271

Say, "Have you not thought that if your water was to dry up, who would bring you water from the spring?"

# 5272

Nun. By the pen and by what you write,

# 5273

(Muhammad), you are not insane, thanks to the bounty of your Lord.

# 5274

You will certainly receive a never-ending reward.

# 5275

You have attained a high moral standard.

# 5276

You will see and they will also see

# 5277

which of you has been afflicted by insanity.

# 5278

Your Lord knows best who has gone astray from His path and who is rightly guided.

# 5279

Do not yield to those who reject the Truth.

# 5280

They would like you to relent to them so that they could also relent towards you.

# 5281

Do not yield to one persistent in swearing,

# 5282

back-biting, gossiping,

# 5283

obstructing virtues, a sinful transgressor,

# 5284

ill-mannered, and moraly corrupt or that because he may possess wealth and children.

# 5285

When Our revelations are recited to him,

# 5286

he says, "These are ancient legends".

# 5287

We shall brand him on his nose.

# 5288

We have tested them in the same way as we tested the dwellers of the garden (in Yemen) when they swore to pluck all the fruits of the garden in the morning,

# 5289

without adding ("if God wills").

# 5290

A visitor from your Lord circled around the garden during the night while they were asleep

# 5291

and the garden was turned into a barren desert.

# 5292

In the morning they called out to one another,

# 5293

"Go early to your farms, if you want to pluck the fruits".

# 5294

They all left, whispering to one another,

# 5295

"Let no beggar come to the garden".

# 5296

They were resolved to repel the beggars.

# 5297

When they saw the garden, they said, "Surely we have lost our way.

# 5298

(No, we are not lost.) In fact, we have been deprived of everything".

# 5299

A reasonable one among them said, "Did I not tell you that you should glorify God?"

# 5300

They said, "All glory belongs to God. We have certainly been unjust".

# 5301

Some of them started to blame others.

# 5302

They said, "Woe to us. We have been arrogant.

# 5303

Perhaps our Lord will replace it with a better garden. We turn in repentance to our Lord".

# 5304

Such is the torment if only they knew that the torment in the life hereafter will certainly be greater.

# 5305

The pious ones will receive a beautiful Paradise from their Lord.

# 5306

Shall We treat the Muslims like criminals?

# 5307

What is the matter with you? How could you judge this to be so?

# 5308

Do you have a book from which you study

# 5309

that tells you to do whatever you want?

# 5310

Do you have a covenant with Us which allows you to do whatever you want until the Day of Judgment?

# 5311

(Muhammad), ask which of them can guarantee that on the Day of Judgment.

# 5312

they will receive the same thing that the Muslims will? Do they have any witness to such an agreement? Let them bring out such witness, if they are truthful.

# 5313

On the day when the terrible torment approaches, they will be told (in a mocking way) to prostrate themselves, but they will not be able to do it.

# 5314

Their eyes will be lowered and disgrace will cover them. They had certainly been told to prostrate themselves before God when they were safe and sound.

# 5315

Leave those who reject the Quran to Me and I shall lead them step by step to destruction, without their being aware of it.

# 5316

I shall give them respite, however, My plan is so strong that they will never be able to escape from it.

# 5317

(Muhammad), do you ask for your preaching any recompense which is too heavy a price for them to pay?

# 5318

Do they possess the knowledge of the unseen which confirms the truthfulness of their belief?

# 5319

Exercise patience until the promise of your Lord (to punish the unbelievers) comes true. Do not be like Jonah (who left his people without the permission of God; he wanted them to be punished immediately),

# 5320

and who cried (for help) to his Lord, while imprisoned and helpless inside the fish. Had it not been for a favor from his Lord, he would have been left out in the open, deserving blame for his shortcomings.

# 5321

But his Lord chose him as His Prophet and made him one of the righteous ones.

# 5322

When the disbelievers listen to you reciting the Quran they almost try to destroy you with their piercing eyes. Then they say, "He is certainly insane".

# 5323

The Quran is nothing but a reminder from God to mankind.

# 5324

The Inevitable! (Day of Judgment).

# 5325

What is the Inevitable?

# 5326

Would that you knew (in detail) what the Inevitable is!

# 5327

The people of Thamud and Ad denied the Day of Judgment.

# 5328

The Thamuds were destroyed by a violent blast of sound.

# 5329

The Ads were destroyed by a swift, destructive gale

# 5330

which continued to strike them for seven and eight days so that eventually you could see the people lying dead like the hollow trunks of uprooted palm-trees.

# 5331

Can you see any of their survivors?

# 5332

The Pharaoh, those who lived before him and the people of the Subverted Cities all persisted in doing evil.

# 5333

They disobeyed the Messenger of their Lord and He seized them with torment which increased with time.

# 5334

When the flood rose high and covered the whole land, We carried you in the Ark.

# 5335

as a lesson for you, but only attentive ears will retain it.

# 5336

With the first blast of sound from the trumpet,

# 5337

the earth and mountains will be raised up high and crushed all together.

# 5338

On that day, the inevitable event will take place

# 5339

and the heavens will be rent asunder,

# 5340

and will turn frail, losing all force. The angels will be around the heavens and on that day eight of them will carry the Throne of your Lord above all the creatures.

# 5341

On that day all your secrets will be exposed.

# 5342

Those who will receive the books of the records of their deeds in their right hands will say, "Come and read my record.

# 5343

I was sure that the record of my deeds would be shown to me".

# 5344

They will have a pleasant life

# 5345

in an exalted garden

# 5346

with fruits within easy reach.

# 5347

Such people will be told, "Eat and drink with pleasure as the reward for what you did in the past".

# 5348

However, those who will receive the books of the records of their deeds in their left hands will say, "We wish that this record had never been given to us

# 5349

and that we would never knew what our records contained.

# 5350

Would that death had taken us away for good.

# 5351

Our wealth is of no benefit to us

# 5352

and our belief has destroyed us".

# 5353

The angels will be told, "Seize and chain them,

# 5354

then throw them into hell to be heated up therein.

# 5355

Fasten a chain to them - seventy cubits long -

# 5356

they did not believe in the great God,

# 5357

nor were they concerned with feeding the destitute.

# 5358

On this day, they will have no friends

# 5359

and no food except pus

# 5360

which only the sinners eat".

# 5361

I do not need to swear by what you see

# 5362

and what you do not see

# 5363

because the Quran is certainly the word of a reverent messenger.

# 5364

It is not the word of a poet but only a few of you have faith,

# 5365

nor is it the work of a soothsayer but only a few of you take heed.

# 5366

It is a revelation from the Lord of the Universe.

# 5367

Had Muhammad invented some words against Us,.

# 5368

We would have caught hold of him by his right hand

# 5369

and cut-off his main artery.

# 5370

None of you would be able to prevent Us from doing this to him.

# 5371

The Quran is certainly a reminder for the pious ones.

# 5372

We certainly know that some of you have rejected it

# 5373

and (on the Day of Judgment) this will be a great source of regret for the unbelievers.

# 5374

This is the Truth beyond any doubt.

# 5375

(Muhammad), glorify the name of your Lord, the Great One.

# 5376

Someone has (needlessly) demanded to experience the torment (of God),

# 5377

which will inevitably seize the disbelievers.

# 5378

No one can defend him against God, the Lord of the exalted positions.

# 5379

On that Day (of Judgment), long as fifty thousand years, the angels and the Spirit will ascend to Him.

# 5380

(Muhammad), exercise patience with no complaints.

# 5381

They think that it (the Day of Judgment) is far away.

# 5382

but We see it to be very near.

# 5383

On the day when the heavens become like molten metal.

# 5384

and the mountains become like wool,

# 5385

even intimate friends will not inquire about their friends,

# 5386

though they may see each other. A sinner will wish that he could save himself from the torment of that day by sacrificing his children,

# 5387

his wife, his brother,

# 5388

his kinsmen who gave him refuge (from hardship)

# 5389

and all those on earth.

# 5390

By no means! For the raging flames of the fire

# 5391

will strip-off the flesh

# 5392

and drag into it anyone who has turned away (from obeying God),

# 5393

and who accumulated wealth without spending it for a good purpose.

# 5394

Human beings are created greedy.

# 5395

When they are afflicted, they complain,

# 5396

but when they are fortunate, they become niggardly

# 5397

except those who are steadfast

# 5398

and constant in their prayers.

# 5399

They are those who assign a certain share of their property

# 5400

for the needy and the deprived,

# 5401

who acknowledge the Day of Judgment,

# 5402

who are afraid of the torment of their Lord,

# 5403

the punishment of their Lord is not something for them to feel secure of,

# 5404

who guard their carnal desires

# 5405

except from their wives and slave girls, in which case they are not to be blamed,

# 5406

but whoever goes beyond this is a transgressor;

# 5407

who honor their trust and promises,

# 5408

who testify to what they have witnessed,

# 5409

and (finally) those who do not miss their ritual - prayers at the prescribed times;

# 5410

such people will receive due honor in Paradise.

# 5411

What is wrong with the disbelievers who roam around you (Muhammad),

# 5412

left and right, in numerous groups?

# 5413

Does every one of them desire to enter the bountiful Paradise?

# 5414

By no means! For they know very well out of what We have created them (The human being's naturally growing from a living germ, without discipline and good deeds will not result in virtue).

# 5415

I do not need to swear by the Lord of the eastern and western regions that We have certainly all the power

# 5416

to replace them by a better people and none can challenge Our power.

# 5417

(Muhammad), leave them alone to dispute and play until they face the Day with which they have been threatened:

# 5418

the Day when they rush out of their graves as if racing towards a signpost,

# 5419

with their eyes cast down and covered by disgrace; the day about which they were promised.

# 5420

We sent Noah to his people telling him, "Warn your people before a painful torment approaches them".

# 5421

Noah said, "My people, I am warning you plainly.

# 5422

Worship God, have fear of Him and obey me.

# 5423

He will forgive your sins and give you a respite for an appointed time. When the time which God has appointed arrives, none will be able to postpone it. Would that you knew this!"

# 5424

Noah said, "My Lord, I have been preaching to my people, night and day,

# 5425

but it has had no effect on them except to make them run away.

# 5426

Evert time I invite them to Your (guidance) so that You can forgive them, they put their fingers into their ears, cover their heads with their clothes, persist in their disbelief and display extreme arrogance.

# 5427

"I preached to them aloud, in public.

# 5428

Then I conveyed the message to them, again, both in public and in private,

# 5429

and told them, "Ask forgiveness from your Lord; He is All-forgiving".

# 5430

He will send you abundant

# 5431

rain from the sky,

# 5432

strengthen you by (providing) you wealth and children, and make gardens and streams for you. What is the matter with you that you are not afraid of the greatness of God

# 5433

who has created you in several stages?

# 5434

"Have you not seen that God has created the seven heavens one above the other

# 5435

and placed therein the moon as a light

# 5436

and the sun as a torch.

# 5437

God made you grow from the earth. He will make you return to it and then take you out of it again.

# 5438

God has spread out the earth

# 5439

for you, so that you may walk along its wide roads".

# 5440

Noah said, "Lord, they have disobeyed me and followed those whose wealth and children will only bring about destruction for them.

# 5441

They have arrogantly plotted evil plans against me,

# 5442

and have said to each other, 'Do not give-up your idols. Do not renounce Wadd, Suwa\`, Yaghuth, Ya\`uq and Nasr (names of certain idols).

# 5443

They have misled many and the unjust will achieve nothing but more error".

# 5444

Because of their sins, they were drowned and made to enter hell. They could find no one to help them besides God.

# 5445

Noah said, "Lord, do not leave a single disbeliever on earth;

# 5446

if You do, they will mislead Your servants and will only give birth to ungrateful sinners.

# 5447

Lord, forgive me, my parents, the believers who have entered my home and all believing men and women. Give nothing to the unjust but destruction.

# 5448

(Muhammad), say, "It has been revealed to me that a party of jinn has listened (to the recitation) of the Quran and has told (their people), "We heard an amazing reading

# 5449

which guides people to the right path and we believe in it. We shall never consider anyone equal to our Lord;

# 5450

our Lord is too exalted to have either a wife or son.

# 5451

The dimwit one (the devil) among us has been telling confused lies about God.

# 5452

We thought that no man or jinn could ever tell lies about God.

# 5453

"Certain human beings sought refuge with certain jinn and this increased the rebelliousness of those jinn.

# 5454

Those people thought, like you, that God would never send down a Messenger.

# 5455

"We went near the heavens but found it to be full of strong guards and shooting flames.

# 5456

We used to sit near by and try to listen to the heavens, but shooting flames now await those who try to do that.

# 5457

We do not know whether by this arrangement God intends benefit and guidance for the people of the earth or only evil.

# 5458

As for us, some of us are righteous and others are not. We have all followed different ways.

# 5459

We knew that we could never challenge God whether we stayed on earth or fled elsewhere.

# 5460

Now that we have listened to the guidance, we believe in it. Whoever believes in his Lord does not need to fear loss or oppression.

# 5461

Some of us are Muslims and some of us have deviated from the Truth. Whoever has embraced Islam has followed the right guidance.

# 5462

However, the deviators from the Truth will be the fuel for hell".

# 5463

Had they (jinn and mankind) remained steadfast in their religion (Islam), We would certainly have given them abundant water to drink

# 5464

as a trial for them. God will make those who disregard the guidance from their Lord suffer increasing torment.

# 5465

All the parts of the body to be placed on the ground during prostration belong to God.

# 5466

Do not prostrate before anyone other than Him. When the servant of God (Muhammad) preached (his message) the jinn would all crowd around him.

# 5467

(Muhammad), say, "I worship only my Lord and do not consider anyone equal to Him".

# 5468

Say, "I do not possess any power to harm or benefit you".

# 5469

Say, "No one can protect me from God, nor can I find any place of refuge but with him.

# 5470

My only (means of protection) is to convey the message of God. Whoever disobeys God and His Messenger will go to hell, wherein he will live forever".

# 5471

(On the Day of Judgment) when the disbelievers witness that with which they have been threatened, they will then know whose helpers are weaker and fewer in number.

# 5472

(Muhammad), say, "I do not know whether that with which you have been threatened is close by or whether my Lord will prolong the time of its coming.

# 5473

He knows the unseen and He does not allow anyone to know His secrets except those of His Messengers whom He chooses.

# 5474

He causes angelic guards to march before and after him.

# 5475

(Messenger) so that He would know that the Messengers have conveyed the message of their Lord. He encompasses all that is with them and He keeps a precise account of all things".

# 5476

You, who have wrapped yourself up with a mantle,

# 5477

worship (God) for a few hours at night.

# 5478

(Worship Him) for more or less than half of the night

# 5479

and recite the Quran in a distinct tone;

# 5480

We are about to reveal to you a mighty word.

# 5481

Prayer at night leaves the strongest impression on one's soul and the words spoken are more consistent.

# 5482

During the day, you are preoccupied with many activities.

# 5483

Glorify the Name of your Lord, the Lord of the eastern and western regions, with due sincerity.

# 5484

He is the only Lord, so choose Him as your guardian.

# 5485

Bear patiently whatever they say, do not yield to them and keep on preaching decently to them.

# 5486

Leave the prosperous disbelievers to Me and give them respite for a little while;

# 5487

We have prepared for them fetters, flaming fire,

# 5488

food which chokes (them), and a painful torment.

# 5489

On that day, the earth and the mountains will be violently shaken, and the mountains will be turned into heaps of moving sand.

# 5490

We have sent you a Messenger, who will witness your deeds, just as We sent a Messenger to the Pharaoh.

# 5491

However, the Pharaoh disobeyed the Messenger and We seized him with a severe retribution.

# 5492

If you, disbelieve, how will you be able to protect yourselves from the hardships of the day which would even turn children grey-headed?

# 5493

On that day, the heavens will be rent asunder. This is the decree of God which has already been ordained.

# 5494

This is a reminder. Let anyone who wants, seek guidance from his Lord.

# 5495

Your Lord knows that you and a group of those who are with you get up for prayer sometimes for less than two-thirds of the night, sometimes half and sometimes one-third of it. God determines the duration of the night and day. He knew that it would be hard for you to keep an exact account of the timing of the night prayers, so He turned to you with forgiveness. Thus, recite from the Quran as much as possible. He knew that some of you would be sick, others would travel in the land to seek God's favors, and still others would fight for the cause of God. Thus, recite from the Quran as much as possible, be steadfast in prayer, pay the zakat, and give virtuous loans to God. Whatever good deeds you save for the next life, you will certainly find them with God. This is the best investment, and for this you will find the greatest reward. Ask forgiveness from God. God is All-forgiving and All-merciful.

# 5496

Cloaked one,

# 5497

stand up, deliver your warning,

# 5498

proclaim the greatness of your Lord,

# 5499

cleanse your clothes,

# 5500

stay away from sins

# 5501

and do not think that by doing such deeds, you have done a great favor to God.

# 5502

Exercise patience to please your Lord.

# 5503

When the trumpet is sounded,.

# 5504

it will be a hard day

# 5505

and for the disbelievers, in particular, it will not be at all easy.

# 5506

Leave to Me the one, whom I have created all by Myself,

# 5507

and whom I have granted abundant wealth

# 5508

and children living in his presence,

# 5509

whose life I have made run smoothly

# 5510

and who still desires more.

# 5511

Never will he receive more. He has been hostile to Our revelations.

# 5512

We shall make him suffer the torment of hell without relief.

# 5513

He planned and plotted.

# 5514

May he be condemned!

# 5515

What an evil plan he has made!

# 5516

May he be condemned again for his schemes! He looked around,

# 5517

frowned and scowled,

# 5518

then turned back, and swelling-up with pride,

# 5519

said, "This (the Quran) is nothing but magic, inherited from ancient magicians.

# 5520

These are only words from a mere mortal".

# 5521

I shall make him suffer the torment of hell.

# 5522

Would that you really knew what hell is!

# 5523

It leaves and spares no one and nothing.

# 5524

It scorches people's skin

# 5525

and it has nineteen angelic keepers.

# 5526

We have made only angels as the keepers of the fire (for they are the strongest in carrying out Our commands). Our informing (people) of the numbers of these angels is a trial for the disbelievers. It gives more certainty to the people of the Book and strengthens the faith of the believers. The people of the Book and the believers have no doubt about it. We have fixed the number to make the disbelievers and those whose hearts are sick say, "What does God mean by such a parable?" Thus, God guides and causes to go astray whomever He wants. No one knows about the army of your Lord except He Himself. This parable is a reminder for mankind.

# 5527

By the moon,

# 5528

by the retreating night,

# 5529

by the brightening dawn,

# 5530

hell is certainly the greatest calamity.

# 5531

It is a warning for mankind

# 5532

whether one steps forward to embrace the faith or one turns away from it.

# 5533

Every soul will be in captivity for its deeds

# 5534

except the people of the right hand

# 5535

who will be in Paradise

# 5536

and will ask of the criminals,

# 5537

"what led you into hell?"

# 5538

They will reply, "We did not pray,

# 5539

nor did we feed the destitute.

# 5540

We indulged and persisted in useless disputes,

# 5541

and rejected the Day of Judgment

# 5542

until death approached us".

# 5543

The intercession of the intercessors will be of no benefit to them.

# 5544

If such will be the Day of Judgment, what is the matter with them? Why do they run away from guidance,

# 5545

like frightened donkeys

# 5546

running away from a lion?

# 5547

Is it that everyone of them wants to receive a heavenly book addressed to him personally?

# 5548

This will certainly never be the case! In fact, they are not afraid of the Day of Judgment.

# 5549

There is no doubt that the Quran is a guide.

# 5550

Let anyone who seeks guidance do so.

# 5551

No one will seek guidance unless God wills it. He alone is worthy of being feared and He is the Source of Forgiveness.

# 5552

I swear by the Day of Resurrection

# 5553

and by the self accusing soul (that you will certainly be resurrected).

# 5554

Do men think that We shall never be able to assemble their bones?

# 5555

We certainly have the power to restore them even the very tips of their finger.

# 5556

In fact, people want to have eternal life in this world.

# 5557

He asks, "When will be the Day of Judgment?"

# 5558

When the eye is bewildered,

# 5559

the moon eclipsed.

# 5560

and the sun and the moon are brought together,

# 5561

people will say, "Is there anywhere to run away?"

# 5562

Certainly not! There will be no place of refuge.

# 5563

The only place of refuge will be with God.

# 5564

On that day, people will be informed of all that they had done and all that they were supposed to do.

# 5565

In fact, people are well-aware of their own soul

# 5566

even though they make excuses.

# 5567

(Muhammad), do not move your tongue too quickly to recite the Quran.

# 5568

We shall be responsible for its collection and its recitation.

# 5569

When We recite it, follow its recitation (by Us).

# 5570

We shall be responsible for its explanation.

# 5571

Human beings certainly do not want to pay much attention to the Quran. In fact, they love the worldly life

# 5572

and neglect the life to come.

# 5573

On the Day of Judgment some faces will be bright,

# 5574

and look forward to receiving mercy from their Lord.

# 5575

Others will be despondent,

# 5576

certain of facing a great calamity.

# 5577

Some people, certainly, do not believe in it, but when a person's soul reaches up to his throat

# 5578

and the angels say, "Who will take away his soul,

# 5579

(the angels of mercy or the angels of wrath,)" then, he will realize that it is time to leave this world.

# 5580

When legs are twisted around each other,

# 5581

that will be the time to be driven to one's Lord.

# 5582

The human being does not want to believe the Truth, nor does he want to pray.

# 5583

He rejects the faith, turns away

# 5584

and haughtily goes to his people.

# 5585

Woe to you!

# 5586

<!-- TODO:DUPLICATE -->

Woe to you!

# 5587

For you, the human being of such behavior, will certainly deserve it.

# 5588

Does the human being think that he will be left uncontrolled?

# 5589

Was he not once just a drop of discharged sperm.

# 5590

Was he not turned into a clot of blood? God then formed him and gave him proper shape. From the human being, God made males and females in pairs.

# 5591

Does He then not have the power to bring the dead back to life?

# 5592

There was certainly a time when there was no mention of the human being.

# 5593

We created the human being from the union of sperm and egg to test him. We gave him hearing and vision.

# 5594

We showed him the right path whether he would be grateful or ungrateful.

# 5595

We have prepared chains, shackles, and flaming fire (for the disbelievers).

# 5596

The virtuous ones will drink from a cup containing camphor

# 5597

which flows from a spring from which the servants of God will drink.

# 5598

The servants of God fulfill their vows and are afraid of the day in which there will be widespread terror.

# 5599

They feed the destitute, orphans, and captives for the love of God, saying,

# 5600

"We only feed you for the sake of God and we do not want any reward or thanks from you.

# 5601

We are afraid of our Lord and the bitterly distressful day".

# 5602

God will certainly rescue them from the terror of that day and will meet them with joy and pleasure.

# 5603

For their patience, He will reward them with Paradise and silk.

# 5604

They will recline therein on couches and they will find neither excessive heat nor cold.

# 5605

The shades of the garden will be closely spread over them and it will be easy for them to reach the fruits.

# 5606

They will be served with silver dishes and crystal clear goblets.

# 5607

Also there will be crystal clear goblets of silver containing the exact measure of drink which they desire.

# 5608

They will drink cups containing (soft flowing) sparkling water

# 5609

from a spring named salsabil.

# 5610

They will be served by immortal youths who look like scattered pearls.

# 5611

If you were to see it, you would find it to be a great kingdom with great bounty.

# 5612

They will have fine green silk and brocade, and they will be decked with bracelets of silver. Their Lord will provide them with a drink of pure wine.

# 5613

This will be their reward and their efforts will be appreciated.

# 5614

(Muhammad), We have revealed the Quran to you in gradual steps.

# 5615

So wait patiently for the command of your Lord and do not yield to any sinful or disbelieving person among them (people).

# 5616

Mention the Name of your Lord, mornings and evenings.

# 5617

Prostrate before Him and glorify Him extensively during the night.

# 5618

These people (disbelievers) love the worldly life and neglect the terrifying day which will come.

# 5619

We have created them and have given them strength. Had We wanted, We could have replaced them with another people like them.

# 5620

This chapter is a reminder. Let those who want, seek guidance from their Lord.

# 5621

(The virtuous mentioned in this chapter) want only what God wants. God is All-knowing and All-wise.

# 5622

He admits to His mercy whomever He wants. For the unjust He has prepared a painful punishment.

# 5623

By (the angels) sent forth with the commands of God,

# 5624

by (the angels) as swift as blowing winds,

# 5625

by (the angels) spreading (the words of God) far and wide,

# 5626

by (the angels) who make a clear distinction between right and wrong

# 5627

and by those who reveal revelations (to the prophets)

# 5628

to provide excuses for some and to give warnings to others:

# 5629

that whatever with which you have been warned will inevitably come to pass.

# 5630

Then the stars will lose their light.

# 5631

Heavens will rent asunder.

# 5632

The mountains will be blown away as dust.

# 5633

The Messengers will receive their appointments.

# 5634

If one asks, "To which day have such calamitous events been postponed?"

# 5635

one will be told,"To the Day of Distinction".

# 5636

Would that you knew about the Day of Judgment!

# 5637

On that day, woe will be to those who have rejected God's revelations!

# 5638

Did We not destroy the ancient people

# 5639

and make others settle after them in their land?

# 5640

Thus do We deal with the sinful ones.

# 5641

On that day, woe upon those who have rejected God's revelations!

# 5642

Did We not create you from an insignificant drop of fluid

# 5643

and place it in a secure place

# 5644

for an appointed time?

# 5645

Thus did We Plan and how excellent is Our planning!

# 5646

On that day, woe would be upon those who have rejected the revelations of God!

# 5647

Did We not make the earth as a gathering place

# 5648

for the living and the dead,

# 5649

place on it high mountains and provide you with fresh water?

# 5650

On that Day (of Judgment) woe would be upon those who have rejected God's revelations!

# 5651

Proceed to that (the Day of Judgment) which you have rejected.

# 5652

Proceed to that shadow, rising in three columns

# 5653

which neither gives shade nor protects one from the flames.

# 5654

The fire will shoot out sparks as big as huge towers

# 5655

and yellow camels.

# 5656

On that day, woe would be upon those who have rejected God's revelations!

# 5657

On that day they will not be able to speak,

# 5658

nor will they be permitted to offer any excuses.

# 5659

On that day, woe would be those who have rejected God's revelations!

# 5660

That is the Day of Judgment. We will bring you together with all the ancient peoples.

# 5661

If you have any plans, use them.

# 5662

On that day, woe would be upon those who have rejected God's revelations!

# 5663

The pious ones will rest amid the shade, springs,

# 5664

and fruits of the kind which they desire.

# 5665

(They will be told), "Eat and drink in good health as a reward for what you have done".

# 5666

Thus do We reward the righteous ones.

# 5667

On that day, woe would be upon those who have rejected God's revelations!

# 5668

(Disbelievers), eat and enjoy yourselves for a little while. You are certainly sinful ones.

# 5669

On that day, woe would be upon those who have rejected God's revelations!

# 5670

When they are told to say their prayers, they do not bow down (in prayer).

# 5671

On that day, woe would be upon those who have rejected God's revelations!

# 5672

In which word other than the Quran will they believe?

# 5673

What do they quarrel about?

# 5674

They quarrel about the great news

# 5675

concerning which they have disputes.

# 5676

(What they think is certainly despicable!). They will soon come to know (the reality).

# 5677

Yes, indeed, before long they will learn all about it.

# 5678

Have We not made the earth as a place to rest

# 5679

and the mountains as pegs (to anchor the earth)?

# 5680

Have We not created you in pairs,

# 5681

made sleep for you to rest,

# 5682

made the night as a covering,

# 5683

and the day as time for you to make a living?

# 5684

Have We not made seven strong heavens above you,

# 5685

(the sun) as a shining torch

# 5686

and sent down heavy rains from the clouds

# 5687

to make the seeds, plants,

# 5688

and thick gardens grow?

# 5689

The Day of Judgment will certainly be the final appointment.

# 5690

On that day the trumpet will be sounded and you will come (to Us) in huge groups.

# 5691

The heavens will have openings like doors.

# 5692

The mountains will be driven away and become like mirages.

# 5693

Hell will lie in wait (for its prey).

# 5694

It will be a place of return

# 5695

for the rebellious ones and they will live therein for ages.

# 5696

They will not feel cold nor taste any drink

# 5697

except boiling water and pus,

# 5698

as a fitting recompense for their deeds.

# 5699

They did not expect such a Judgment

# 5700

and persistently rejected Our revelations.

# 5701

However, We have recorded everything in a book.

# 5702

(They will be told), "Suffer, We shall only increase the torment for you".

# 5703

The pious ones will be triumphant.

# 5704

They will have gardens and vineyards,

# 5705

maidens with pears-shaped breasts who are of equal age (to their spouses)

# 5706

and cups full of wine.

# 5707

They will not hear therein any unnecessary words or lies.

# 5708

This will be their reward from your Lord, a favor from Him and a recompense for their deeds.

# 5709

He is the Lord of the heavens and the earth and all that is between them. He is the Beneficent God and no one will be able to address Him.

# 5710

On that day, the Spirit and the angels who stand in lines will not speak except those whom the Beneficent God has permitted, and he will speak the right words.

# 5711

That will be the Day of the Truth. So let those who want seek refuge from their Lord.

# 5712

We have warned you of the approaching torment. On that day, a person will see what his hands have committed. A disbeliever will say, "Would that I had been dust".

# 5713

By the angels who violently tear-out the souls of the disbelievers from their bodies,

# 5714

by the angels who gently release the souls of the believers,

# 5715

by the angels who float (in the heavens by the will of God),

# 5716

by the angels who hasten along

# 5717

and by the angels who regulate the affairs, (you will certainly be resurrected).

# 5718

On the day when the first trumpet sound blasts

# 5719

and will be followed by the second one,

# 5720

hearts will undergo terrible trembling,

# 5721

and eyes will be humbly cast down.

# 5722

(The disbelievers) say, "Shall we be brought back to life again

# 5723

after we have become bones and dust?"

# 5724

They have said, "Such a resurrection will certainly be a great loss".

# 5725

However, it will only take a single blast

# 5726

to bring them out of their graves and back to life on the earth's surface.

# 5727

(Muhammad), have you heard the story of Moses

# 5728

when his Lord called him in the holy valley of Tuwa,

# 5729

saying, "Go to the Pharaoh. He has transgressed beyond all bounds.

# 5730

And say to him, "Would you like to reform yourself?

# 5731

I shall guide you to your Lord so that you may perhaps have fear of Him".

# 5732

Moses showed him the great miracle

# 5733

but the Pharaoh rejected it and disobeyed (Moses).

# 5734

Then he turned away in a hurry,

# 5735

and gathered his people together

# 5736

saying, "I am your supreme lord".

# 5737

So God struck him with the torment of this life and the life hereafter.

# 5738

In this there is a lesson for those who have fear of God.

# 5739

(People), is your creation harder for God than that of the heavens, which He created, raised and established

# 5740

high above?

# 5741

He has made its nights dark and its days bright.

# 5742

After this, He spread out the earth,

# 5743

produced water and grass therefrom,

# 5744

then set-up firmly the mountains.

# 5745

All this was done as a means of enjoyment for you and your cattle.

# 5746

On the day when the great calamity comes,

# 5747

the human being will recall whatever he has done.

# 5748

Hell fire will become visible for those who would see it.

# 5749

Those who have rebelled

# 5750

and preferred the worldly life,

# 5751

hell will be their dwelling.

# 5752

However, those who had feared their Lord and restrained their souls from acting according to its desires.

# 5753

Paradise will be the dwelling.

# 5754

(Muhammad), they ask you, "When will the Hour of Doom come?"

# 5755

(Muhammad), you do not know (when and how) it will come.

# 5756

This matter is in the hands of your Lord.

# 5757

You are only a warner for those who fear such a day.

# 5758

On the day when they see it, it will seem to them as though they had only lived in the world for a morning and an afternoon.

# 5759

He frowned and then turned away

# 5760

from a blind man who had come up to him.

# 5761

You never know. Perhaps he wanted to purify himself,

# 5762

or receive some (Quranic) advice which would benefit him.

# 5763

Yet you pay attention

# 5764

to a rich man,

# 5765

though you will not be questioned even if he never purifies himself.

# 5766

As for the one who comes to you earnestly (striving for guidance).

# 5767

and who has fear of God,

# 5768

you ignore him.

# 5769

These verses are a reminder

# 5770

so let those who want to follow its guidance do so.

# 5771

(This Quran) is also recorded in honorable books,

# 5772

exalted, purified,

# 5773

by the hands of the noble, virtuous,

# 5774

and angelic scribes.

# 5775

May (the disbelieving) human being be condemned! What makes him disbelieve?

# 5776

From what has God created him?

# 5777

He created him from a living germ. He determined his fate

# 5778

and made the path of guidance easy for him to follow.

# 5779

Then He caused him to die and be buried

# 5780

and He will resurrect him whenever He wants.

# 5781

Certainly, he has not duly fulfilled His commands.

# 5782

Let the human being think about (how We produce) his food.

# 5783

We send down abundant water,

# 5784

and let the earth to break open

# 5785

to yield therein corn,

# 5786

grapes, vegetables,

# 5787

olives, dates,

# 5788

thickly planted gardens,

# 5789

fruits, and grass.

# 5790

(These are made so as to be) means of enjoyment for you and your cattle.

# 5791

When the trumpet sounds,

# 5792

it will be such a day when a person will run away from his brother,

# 5793

mother, father,

# 5794

wife and sons,

# 5795

for on that day everyone will be completely engrossed in his own concerns.

# 5796

Some faces on that day will be radiant,

# 5797

laughing and joyous

# 5798

but others will be gloomy

# 5799

and covered by darkness.

# 5800

These will be the faces of the sinful disbelievers.

# 5801

(On the day) when the sun is made to cease shining,

# 5802

the stars are made to fade away,

# 5803

the mountains are scattered about as dust,

# 5804

the young barren camels are abandoned,

# 5805

the wild beasts are herded together,

# 5806

the oceans are brought to a boil,

# 5807

souls are reunited with their bodies,

# 5808

questions are asked about the baby girls buried alive,

# 5809

such as, "For what crime were they murdered?"

# 5810

the records of deeds are made public,

# 5811

the heavens are unveiled,

# 5812

hell is made to blaze,

# 5813

and Paradise is brought near,

# 5814

then every soul will discover the consequence of its deeds.

# 5815

I do not need to swear by the orbiting

# 5816

stars which are visible during the night

# 5817

and sit during the day, or by the darkening night

# 5818

and brightening morning,

# 5819

that the Quran is the word of the honorable angelic, mighty Messenger

# 5820

who is honored in the presence of the Lord of the Throne,

# 5821

obeyed by (all creatures) and faithful to His trust.

# 5822

Your companion (Muhammad) does not suffer from any mental illness

# 5823

He certainly saw him (Gabriel) high up on the horizon in his original form

# 5824

He (Muhammad) is not accused of lying about the unseen.

# 5825

The Quran is not the word of condemned satan.

# 5826

Where then will you go?

# 5827

This is certainly the guidance for all (jinn and mankind).

# 5828

So let those who want, choose the right guidance

# 5829

However, you will not be able to choose anything unless God, Lord of the Universe wills it to be so.

# 5830

When the heavens are rent asunder,

# 5831

the stars are dispersed,

# 5832

the oceans are merged together,

# 5833

and the graves are turned inside out,

# 5834

every soul will see the result of its deeds - those recorded before his death and those which will produce either virtue or evil after his death.

# 5835

Human being, what evil has deceived you about your Gracious Lord,

# 5836

Who created you proportionately and fashioned you

# 5837

in whatever composition He wanted.

# 5838

Despite this, you deny the Day of Judgment,

# 5839

but you should know that there are angelic guards

# 5840

watching over you

# 5841

and these honorable scribes know whatever you do.

# 5842

The virtuous ones will live in bliss

# 5843

and the evil-doers will be in hell

# 5844

which they will enter on the Day of Judgment

# 5845

to burn therein.

# 5846

They will never be able to escape from it. Would that you knew what the Day of Judgment is!

# 5847

Again would that you only knew how terrible it really is!

# 5848

On that day, no soul will be of any benefit to any other soul. On that day, all affairs will be in the hands of God.

# 5849

Woe to those who are fraudulent in (weighing and measuring),

# 5850

those who demand a full measure from others

# 5851

but when they measure or weigh, give less.

# 5852

Do they not realize that they will be resurrected

# 5853

on a great day

# 5854

when mankind will stand before the Lord of the Universe?

# 5855

Woe to them! Let them know that the records of the sinner's deeds are in Sijin.

# 5856

Would that you knew what Sijin is!?

# 5857

It is a comprehensively written Book (of records).

# 5858

Woe, on that day, to those who have rejected God's revelations

# 5859

and those who have rejected the Day of Judgment.

# 5860

No one rejects it except the sinful transgressors

# 5861

who, when listening to Our revelations, say, "These are only ancient legends".

# 5862

They will never have faith. In fact, their hearts are stained from their deeds.

# 5863

On the Day of Judgment, they will certainly be barred from the mercy of their Lord.

# 5864

They will suffer the heat of fire

# 5865

and who will be told, "This is what you had called a lie".

# 5866

However, the records of the deeds of the virtuous ones will certainly be in Illiyin.

# 5867

Would that you knew what Illiyin is!

# 5868

It is a comprehensively written Book (of records).

# 5869

The ones nearest to God will bring it to public.

# 5870

The virtuous will live in bliss,

# 5871

reclining on couches, reviewing (the bounties given to them).

# 5872

You can trace on their faces the joy of their bliss.

# 5873

They will be given pure wine out of sealed containers

# 5874

which have the fragrance of musk. This is the kind of place for which one should really aspire.

# 5875

With the wine is a drink from Tasnim,

# 5876

a spring, the nearest ones to God will drink from it.

# 5877

The sinners had been laughing at the believers.

# 5878

When passing by them, they would wink at one another

# 5879

and, on returning to their people, boast about what they had done.

# 5880

On seeing the believers, they would say, "These people have gone astray".

# 5881

No one has appointed them to watch over the believers.

# 5882

On the Day of Judgment, the believers will laugh at the disbelievers

# 5883

while reclining on couches and reviewing (the bounties given to them).

# 5884

Will not the disbelievers then be duly recompensed for their laughing at the believers?

# 5885

When the heavens are rent asunder

# 5886

in obedience to the commands of their Lord which are incumbent on them,

# 5887

when the earth is stretched out

# 5888

and throws out of itself all that it contains

# 5889

in obedience to the commands of its Lord which are incumbent on it, (the human being will receive due recompense for his deeds).

# 5890

Human being, you strive hard to get closer to your Lord, and so you will certainly receive the recompense (of your deeds).

# 5891

The reckoning of those whose Book of records will be given into their right hands

# 5892

will be easy,

# 5893

and they will return to their people, delighted

# 5894

But as for those whose Book of records will be given behind their backs,

# 5895

they will say, "Woe to us!"

# 5896

They will suffer the heat of hell fire.

# 5897

They lived among their people joyfully

# 5898

and had thought that they would never be brought back to life again.

# 5899

This is a fact. Their Lord is Well-Aware of (all that they do).

# 5900

I do not need to swear by the sunset,

# 5901

or by the night in which things all come together to rest,

# 5902

or by the moon when it is full,

# 5903

that you will certainly pass through one stage after another.

# 5904

What is the matter with them? Why do they not believe?

# 5905

Why, when the Quran is recited to them, do they not prostrate themselves?

# 5906

In fact, they reject the Quran,

# 5907

but God knows best whatever they accumulate in their hearts.

# 5908

(Muhammad), tell them that they will all suffer a painful torment

# 5909

except the righteously striving believers, who will receive a never-ending reward.

# 5910

By the heavens with constellations,

# 5911

by the promised day,

# 5912

and by the witness (Muhammad) and that which is witnessed (the Day of Judgment),

# 5913

may the people be condemned those who tortured (the believers) in ditches

# 5914

by a burning fire

# 5915

while they themselves sat around it

# 5916

witnessing what they were doing.

# 5917

The only reason for which they tormented the believers was the latter's belief in God, the Majestic, and Praiseworthy.

# 5918

and the One to whom belongs the heavens and the earth. God is the Witness of all things.

# 5919

Those who persecute the believing men and women without repenting will suffer the torment of hell and that of the burning fire.

# 5920

As for the righteously striving believers, they will live in Paradise wherein streams flow. This is the greatest triumph.

# 5921

The vengeance of God is terribly severe.

# 5922

It is He who creates all things and causes them to return.

# 5923

He is the All-forgiving, the Most Loving One,

# 5924

the Owner of the Throne, the Glorious One,

# 5925

and the Most Effective in His decision.

# 5926

Have you not heard about the stories of the armies

# 5927

of the Pharaoh and Thamud?

# 5928

In fact, the disbelievers had always rejected (Our revelations).

# 5929

However, God encompassed their activities.

# 5930

What is revealed to you is certainly a glorious Quran

# 5931

that exists in a well-guarded tablet.

# 5932

By the heavens and al-tariq.

# 5933

Do you know what al-tariq is?

# 5934

(It is a nightly radiant star).

# 5935

There is no soul which is not guarded (by the two angels who record all of its deeds).

# 5936

Let the human being reflect that from what he has been created.

# 5937

He has been created from an ejected drop of fluid

# 5938

which comes out of the loins and ribs.

# 5939

God has all power to resurrect him.

# 5940

On the day when all secrets will be made public,

# 5941

he will have no power, nor anyone to help him.

# 5942

By the rotating heavens

# 5943

and the replenishing earth,

# 5944

the Quran is the final word,

# 5945

and it is certainly not a jest.

# 5946

They (disbelievers) plot every evil plan,

# 5947

but I too plan against them.

# 5948

Give respite to the disbelievers and leave them alone for a while.

# 5949

(Muhammad), glorify the Name of your lord, the Most High,

# 5950

Who has created (all things) proportionately,

# 5951

decreed their destinies, and provided them with guidance.

# 5952

It is He who has caused the grass to grow,

# 5953

then caused it to wither away.

# 5954

We shall teach you (the Quran) and you will not forget it

# 5955

unless God wills it to be otherwise. He knows all that is made public and all that remains hidden.

# 5956

We shall make all your tasks easy.

# 5957

Therefore, keep on preaching as long as it is of benefit.

# 5958

Those who have fear of God will benefit

# 5959

but the reprobates will turn away

# 5960

and suffer the heat of the great fire

# 5961

wherein they will neither live nor die.

# 5962

Lasting happiness will be for those who purify themselves,

# 5963

remember the name of the Lord, and pray to Him.

# 5964

However, (the disbelievers) prefer the worldly life

# 5965

even though the life hereafter will be better and will last forever.

# 5966

This is what is written in the ancient heavenly Books,

# 5967

the Scriptures of Abraham and Moses.

# 5968

Have you heard the story of the overwhelming event (the Day of Judgment)?

# 5969

On that day the faces of some people will be humbly cast down,

# 5970

troubled and tired as a result of their deeds in the past.

# 5971

They will suffer the heat of the blazing fire

# 5972

and will be made to drink from a fiercely boiling spring.

# 5973

They will have no food other than bitter and thorny fruit

# 5974

which will neither fatten them nor satisfy them.

# 5975

However, on that day the faces of other people will be happy.

# 5976

and pleased with the result of their deeds in the past.

# 5977

They will live in an exalted garden

# 5978

wherein they will not hear any vain talk.

# 5979

Therein will be a flowing spring,

# 5980

raised couches,

# 5981

well arranged goblets,

# 5982

well-placed cushions,

# 5983

and well spread carpets.

# 5984

Have they not looked at how the camel is created,

# 5985

how the heavens are raised up high,

# 5986

how the mountains are set firm,

# 5987

and how the earth is spread out?

# 5988

(Muhammad), preach; you are only a preacher.

# 5989

You do not have full control over them.

# 5990

However, those who turn away and disbelieve,

# 5991

God will punish them with the greatest torment.

# 5992

To Us they will all return.

# 5993

In Our hands are their accounts.

# 5994

By the dawn,

# 5995

by the Ten (secret) Nights,

# 5996

by the odd and even (8th and 9th Dhil-hajj)

# 5997

and by the night when it moves on towards daybreak (reward and retribution in the next life is an absolute reality).

# 5998

Is this not a sufficient oath for intelligent people?

# 5999

(Muhammad), consider how your Lord dealt with the tribe of Ad,

# 6000

the people of the huge columned city of Eram

# 6001

whose like has never been created in any other land.

# 6002

(Also consider how He dealt with) the Thamud, who carved their houses out of the rocks in the valley.

# 6003

(Also consider the people of) the Pharaoh who victimized people by placing them on the stake,

# 6004

led rebellious lives,

# 6005

and spread much corruption in the land.

# 6006

Thus, your Lord afflicted them with torment;

# 6007

your Lord keeps an eye on (all evil-doing people).

# 6008

As for the human being, when his Lord tests him, honors him, and grants him bounty, he says, "God has honored me".

# 6009

However, when his Lord tests him by a measured amount of sustenance, he says, "God has disgraced me".

# 6010

(Since wealth does not necessarily guarantee everlasting happiness) then why do you not show kindness to the orphans,

# 6011

or urge one another to feed the destitute?

# 6012

Why do you take away the inheritance of others indiscriminately

# 6013

and why do you have an excessive love of riches?

# 6014

When the earth is crushed into small pieces

# 6015

and (when you find yourself) in the presence of your Lord and the rows and rows of angels, your greed for riches will certainly be of no avail to you.

# 6016

On that day, hell will be brought closer and the human being will come to his senses, but this will be of no avail to him.

# 6017

He will say, "Would that I had done some good deeds for this life".

# 6018

On that day the punishment of God and His detention will be unparalleled.

# 6019

And His bonds will be such as none other can bind.

# 6020

Serene soul,

# 6021

return to your Lord well pleased with him and He will be pleased with you.

# 6022

Enter among My servants

# 6023

into My Paradise.

# 6024

I do not (need to) swear by this town (Mecca)

# 6025

in which you are now living

# 6026

or by the great father and his wonderful son (Abraham and Ishmael)

# 6027

that We have created the human being to face a great deal of hardship.

# 6028

Does He think that no one will ever have control over him?

# 6029

(He boasts and shows off) saying, "I have spent a great deal of money (for the cause of God)".

# 6030

Does he think that no one has seen him?

# 6031

Have We not given him two eyes,

# 6032

a tongue, and two lips?

# 6033

Have We not shown him the ways of good and evil?

# 6034

Yet, he has not entered into Aqaba

# 6035

Would that you knew what Aqaba is!

# 6036

It is the setting free of a slave

# 6037

or, in a day of famine, the feeding of

# 6038

an orphaned relative

# 6039

and downtrodden destitute person, (so that he would be of)

# 6040

the believers who cooperate with others in patience (steadfastness) and kindness.

# 6041

These are the people of the right hand.

# 6042

As for those who disbelieve in Our revelations, they are the people of the left

# 6043

who will be engulfed in the fire.

# 6044

By the sun and its noon-time brightness,

# 6045

by the moon when it follows the sun,

# 6046

by the day when it brightens the earth,

# 6047

by the night when it covers the earth with darkness,

# 6048

by the heavens and that (Power) which established them,

# 6049

by the earth and that (Power) which spread it out

# 6050

and by the soul and that (Power) which designed it

# 6051

and inspired it with knowledge of evil and piety,

# 6052

those who purify their souls will certainly have everlasting happiness

# 6053

and those who corrupt their souls will certainly be deprived (of happiness).

# 6054

The people of Thamud rejected (the truth) as a result of their rebelliousness

# 6055

when the most corrupt of them incited them (to commit evil).

# 6056

The Messenger of God told them, "This is a she-camel, belonging to God. Do not deprive her of her share of water".

# 6057

However, they rejected him and slew her. So their Lord completely destroyed them and their city for their sins.

# 6058

God is not afraid of the result of what He had decreed.

# 6059

By the night when it covers the day,

# 6060

by the day when it appears radiant,

# 6061

and by that (Power) which created the male and female,

# 6062

you strive in various ways.

# 6063

We shall facilitate the path to bliss

# 6064

for those who spend for the cause of God,

# 6065

observe piety, and believe in receiving rewards from God.

# 6066

But for those who are niggardly, horde their wealth,

# 6067

and have no faith in receiving any reward (from God).

# 6068

We shall facilitate the path to affliction

# 6069

and their wealth will be of no benefit to them when they face destruction.

# 6070

Surely, in Our hands is guidance,

# 6071

and to Us belong the hereafter and the worldly life.

# 6072

I have warned you about the fierce blazing fire

# 6073

in which no one will suffer forever

# 6074

except the wicked ones who have rejected the (Truth) and have turned away from it.

# 6075

The pious ones who spend for the cause of God

# 6076

and purify themselves will be safe from this fire.

# 6077

They do not expect any reward

# 6078

except the pleasure of their Lord, the Most High

# 6079

and the reward (of their Lord) will certainly make them happy.

# 6080

By the midday brightness

# 6081

and by the calm of night,

# 6082

(Muhammad), your Lord has not abandoned you (by not sending you His revelation), nor is He displeased with you.

# 6083

The reward in the next life will certainly be better for you than worldly gains.

# 6084

Your Lord will soon grant you sufficient favors to please you.

# 6085

Did He not find you as an orphan and give you shelter?

# 6086

Did He not find you wandering about and give you guidance?

# 6087

And did He not find you in need and make you rich?

# 6088

Do not oppress the orphans

# 6089

and do not reject the beggars

# 6090

and proclaim the bounties of your Lord.

# 6091

(Muhammad), have We not comforted your heart,

# 6092

relieved you of the burden

# 6093

which had been a heavy weight upon your back

# 6094

and granted you an exalted reputation?

# 6095

After every difficulty there is relief.

# 6096

Certainly, after every difficulty there comes relief.

# 6097

When you are free from (your obligations), strive hard (to worship God)

# 6098

and be devoted to your Lord's service.

# 6099

By the fig, by the olive,

# 6100

by Mount Sinai

# 6101

and by this inviolable city, Mecca.

# 6102

We have created the human being in the best form

# 6103

and We shall make him the lowest of low

# 6104

except the righteously striving believers who will have a never ending reward.

# 6105

After (knowing) this, what makes you still disbelieve in the Day of Judgment?

# 6106

Is God not the best of the Judges?

# 6107

(Muhammad), read in the name of your Lord who created (all things).

# 6108

He created man from a clot of blood.

# 6109

Recite! Your Lord is the most Honorable One,

# 6110

who, by the pen, taught the human being:

# 6111

He taught the human being what he did not know.

# 6112

Despite this, the human being still tends to rebel

# 6113

because he thinks that he is independent.

# 6114

However, (all things) will return to your Lord.

# 6115

Have you seen the one who prohibits

# 6116

a servant of Ours from prayer?

# 6117

What will happen if the praying person is rightly guided

# 6118

or if he commands others to maintain piety!?

# 6119

What will happen if the prohibiting rejects the Truth and turns away from it!?

# 6120

Does he not realize that God sees him?

# 6121

Let him know that if he does not desist, We shall certainly drag him by his forelocks,

# 6122

his lying sinful forelock.

# 6123

Let him call on his associates for help

# 6124

and We too will call the stern and angry keepers of hell.

# 6125

(Muhammad), never yield to him! Prostrate yourself and try to come closer to God.

# 6126

We revealed the Quran on the Night of Destiny.

# 6127

Would that you knew what the Night of Destiny is!

# 6128

(Worship) on the Night of Destiny is better than (worship) for a thousand months.

# 6129

On this Night, the angels and the spirit descend by the permission of their Lord with His decree (to determine everyone's destiny).

# 6130

This Night is all peace until the break of dawn.

# 6131

The disbelievers among the People of the Book and the pagans disbelieved (in Islam) only after receiving divine testimony:

# 6132

a Messenger (Muhammad) from God, reciting to them parts of the purified,

# 6133

holy Book which contain eternal laws of guidance.

# 6134

Nor did the People of the Book disagreed among themselves until after receiving the ancient divine testaments.

# 6135

They were only commanded to worship God, be uprightly devoted to His religion, steadfast in prayer and pay the zakat. This is truly the eternal religion.

# 6136

The disbelievers among the People of the Book and the pagans will dwell forever in hell; they are the worst of all creatures.

# 6137

The righteously striving believers are the best of all creatures.

# 6138

Their reward from their Lord will be the gardens of Eden wherein streams flow and wherein they will live forever. God will be pleased with them and they will be pleased with Him. This (reward) is for those who fear their Lord.

# 6139

When the earth is shaken by a terrible quake

# 6140

and it throws out its burden,

# 6141

the human being will say (in horror), "What is happening to it?"

# 6142

On that day the earth will declare all (the activities of the human being) which have taken place on it,

# 6143

having been inspired by your Lord.

# 6144

On that day, people will come out of their graves in different groups to see (the results of) their own deeds.

# 6145

Whoever has done an atom's weight of good,

# 6146

will see it and whoever has done an atom's weight of evil, will also see it.

# 6147

(I swear) by the snorting chargers (of the warriors), whose hoofs strike against the rocks

# 6148

and produce sparks

# 6149

while running during a raid at dawn,

# 6150

and leave behind a cloud of dust

# 6151

which engulfs the enemy.

# 6152

The human being is certainly ungrateful to his Lord.

# 6153

He himself knows this very well.

# 6154

He certainly has a strong love for wealth and riches.

# 6155

Does he not know that on the day when those in the graves are resurrected

# 6156

and all that is in the hearts is made public,

# 6157

their Lord will examine his deeds?

# 6158

The (unprecedented) crash!

# 6159

What is the crash?

# 6160

Would that you knew what the crash is!

# 6161

On that day, people will be like scattered moths

# 6162

and mountains will be like carded wool.

# 6163

Those whose good deeds will weigh heavier (on the scale)

# 6164

will live a pleasant life,

# 6165

but those whose good deeds will be lighter (on the scale).

# 6166

will have hawiyah as their dwelling.

# 6167

Would that you knew what hawiya his?

# 6168

It is a burning Fire.

# 6169

The desire to have more of the worldly gains have pre-occupied you so much (that you have neglected remembring God),

# 6170

until you come to the graves.

# 6171

You shall know.

# 6172

You shall cetainly know (about the consequences of your deeds).

# 6173

You will certainly have the knowledge of your deeds beyond all doubt.

# 6174

You will be shown hell

# 6175

and you will see it with your own eyes.

# 6176

Then, on that day, you will be questioned about the bounties (of God).

# 6177

By the time (of the advent of Islam),

# 6178

the human being is doomed to suffer loss,

# 6179

except the righteously striving believers who exhort each other to truthful purposes and to patience.

# 6180

Woe to every slanderer and backbiter

# 6181

who collects and hordes wealth,

# 6182

thinking that his property will make him live forever.

# 6183

By no means! They will be thrown into hutamah.

# 6184

Would that you knew what hutamah is!

# 6185

It is a fierce fire created by God

# 6186

to penetrate into the hearts.

# 6187

It will engulf them.

# 6188

in its long columns of flames.

# 6189

Have you not considered how your Lord dealt with the people of the elephant?

# 6190

Did He not cause their evil plots to fail

# 6191

by sending against them flocks of swallows

# 6192

which showered them with small pebbles of clay

# 6193

to turn them into (something) like the left-over grass grazed by cattle.

# 6194

For God's favors to them during their summer and winter journeys,

# 6195

Quraish should worship the Lord of this House.

# 6196

It is He who has fed them when they were hungry

# 6197

and has made them secure from fear.

# 6198

Have you seen the one who calls the religion a lie?

# 6199

It is he who turns down the orphans

# 6200

and never encourages the feeding of the destitute.

# 6201

Woe to the worshippers

# 6202

who become confused during their prayers,

# 6203

who show off (his good deeds)

# 6204

and refuse to help the needy.

# 6205

(Muhammad), We have granted you abundant virtue.

# 6206

So worship your Lord and make sacrificial offerings.

# 6207

Whoever hates you will himself remain childless.

# 6208

(Muhammad), tell the disbelievers,

# 6209

"I do not worship what you worship,

# 6210

nor do you worship what I worship

# 6211

I have not been worshipping what you worshipped,

# 6212

nor will you worship what I shall worship.

# 6213

You follow your religion and I follow mine.

# 6214

(Muhammad), when help and victory comes from God,

# 6215

you will see large groups of people embracing the religion of God.

# 6216

Glorify your Lord with praise and ask Him for forgivenes. He accepts repentance.

# 6217

May the hands of Abu Lahab perish!

# 6218

May he too perish!

# 6219

His property and worldly gains will be of no help to him.

# 6220

He will suffer in a blazing fire

# 6221

and so too will his wife who (threw thorns and firewood in the Prophet's way). Around her neck will be a rope of palm fibre.

# 6222

(Muhammad), say, "He is the only God.

# 6223

God is Absolute.

# 6224

He neither begets nor was He begotten.

# 6225

There is no one equal to Him.

# 6226

(Muhammad), say, "I seek protection from the Lord of the Dawn

# 6227

against the evil of whatever He has created.

# 6228

I seek His protection against the evil of the invading darkness,

# 6229

from the evil of those who practice witchcraft

# 6230

and from the evil of the envious ones.

# 6231

(Muhammad), say, "I seek protection from the Cherisher of mankind,

# 6232

the King of mankind,

# 6233

the Lord of mankind

# 6234

against the evil of the temptations of the satans,

# 6235

of jinn and human beings

# 6236

who induce temptation into the hearts of mankind.

