<!--
Quran Translation
Name: Daryabadi
Translator: Abdul Majid Daryabadi
Language: English
ID: en.daryabadi
Last Update: August 16, 2010
Source: Tanzil.net
-->

# 1

In the name of Allah, the Compassionate, the Merciful.

# 2

All praise unto Allah, the Lord of all the worlds.

# 3

The Compassionate, the Merciful.

# 4

Sovereign of the Day of Requital.

# 5

Thee alone do we worship and of Thee alone do we seek help,

# 6

Guide us Thou unto the path straight

# 7

The path of those whom Thou hast favoured. Not of those on whom is indignation brought down, nor of the astray.

# 8

Alif. Lam Mim

# 9

This Book whereof there is no doubt, is a guidance unto the God-fearing.

# 10

Who believe in the Unseen, and establish prayer, and out of that wherewith We have provided them expend.

# 11

And who believe in that which hath been sent down unto thee and that which hath been sent down before thee and of the Hereafter they are convinced.

# 12

These are on guidance from their Lord, and these they are the blissful ones.

# 13

Verily those who have disbelieved, it is equal to them whether thou warnest them or warnest them not; they will not believe.

# 14

Allah hath set a seal upon their hearts and upon their hearing, and over their sights is a covering; and unto them shall be a torment mighty.

# 15

And of mankind are some who say: we believe in Allah and in the Last Day: whereas they are not believers.

# 16

They would deceive Allah and those who believe, whereas they deceive not save themselves, and they perceive not.

# 17

In their hearts is a disease, so Allah hath increased unto them that disease; and unto them shall be a torment afflictive, for they have been lying.

# 18

And when it said unto them: act not corruptly on the earth, they say: we are but reconcilers.

# 19

Lo! verily it is they who are the corrupters, and yet they perceive not.

# 20

And when it said unto them: believe even as mankind have believed, they say: shall we believe even as the fools have believed? Lo! verily it is they who are the fools; and yet they know not.

# 21

And when they meet those who have believed, they say: We believe. And when they are alone with their Satans, they say: verily we are with you, we were but mocking.

# 22

Allah mocketh back at them, and letteth them in their exorbitance wander bewildered.

# 23

These are they who purchased error for guidance, but their traffic profited not, nor have they ever become guided.

# 24

Their likeness is as the likeness of him who kindleth a fire, then when it hath lit up that which is around him, Allah taketh away their light and leaveth them in darknesses where they see not

# 25

Deaf, dumb, blind; wherefore they will not return.

# 26

like unto a rain--laden cloud from heaven, wherein are darknesses and thunder and lightening. They so put their fingers in their ears because of the thunder-claps, guarding against death, and Allah is Encompasser of the infidels.

# 27

The lightning well-nigh snatcheth away their sight; whensoever it flasheth on them, they walk therein, and when it becometh dark unto them, they stand still. And had Allah willed He would of a surety have taken away their hearing and their sights; verily Allah is over everything potent.

# 28

O Mankind worship your Lord who hath created you and those before you, haply ye may become God-fearing-

# 29

Who hath made the earth for you a carpet and the heaven a structure, and sent down from heaven water, and brought forth therewith fruits as a Provision for you; wherefore set not up compeers unto Allah while ye know.

# 30

And if ye be in doubt concerning that which We have revealed unto Our bondsman, then bring a chapter like thereunto, and call your witnesses as against Allah, if ye say sooth.

# 31

But if ye do it not, --and by no means ye shall, --then dread the Fire, the fuel whereof is men and stones, gotten ready for the infidels.

# 32

And bear thou the glad tidings unto those who believe and do righteous works that verily for them shall be Gardens whereunder rivers flow. So oft as they shall be provided with a fruit therefrom they will say: this is that wherewith we were provided afore; and they shall be vouchsafed that which is consimilar; and for them shall be therein spouses purified, and therein they shall be abiders.

# 33

Verily Allah is not ashamed to propound a similitude, be it of a gnat or of aught above it. Then as to those who believe, they know that it is the truth from their Lord. And to those who disbelieve, they say what intendeth God by similitude? He sendeth many astray thereby, and He guideth many thereby, and He sendeth not astray thereby any except the transgressors,

# 34

Who break the covenant of Allah after the ratification thereof, and sunder that which Allah hath commanded should be joined, and act corruptly on the earth. These! they are the losers.

# 35

How will ye disbelieve in Allah whereas ye were lifeless and he quickened you; thereafter He will cause you to die, thereafter He will give you life, thereafter unto Him ye shall be returned!

# 36

He it is who created for you all that is on the earth, thereafter He turned to the heaven, and formed them seven heavens. And He is of everything the Knower.

# 37

And recall what time thine Lord said unto the angels: verily I am going to place a vicegerent On the earth. They said: wilt Thou place therein one who will act corruptly therein and shed blood While we hallow Thine praise and glorify Thee! Allah said: verily I know that which ye know not.

# 38

And He taught Adam the names, all of them; thereafter He set them before the angles, and said declare unto Me the names of those if ye say sooth.

# 39

They said: hallowed be Thou no knowledge is our save that which Thou hast taught us, verily Thou! Thou art the Knower, Wise.

# 40

Allah said: O Adam! declare thou unto them the names of those objects. Then when he had declared unto them the names of those, He said: said I not unto you, verily I know the hidden in the heavens and the earth, and know that which ye disclose and that which ye are wont to conceal!

# 41

And recall what time We said unto the angels: prostrate yourselves before Adam, they prostrated themselves; but not Iblis he refused and was stiff - necked and became of the infidels.

# 42

And We said: Adam! dwell thou and thine spouse in the Garden, and eat ye twain plenteously thereof as ye list, but approach not yonder tree, lest yet twain become of the wrong-doers.

# 43

Then the Satan caused the twain to slip on account thereof, and drave them forth from that which the twain were in. And We said: get ye down, one of you an enemy unto anot her, and for you on the earth shall be a resting-place and enjoyment for a season.

# 44

Then Adam learnt from his Lord certain Words, and He relented toward him, verily He! He is the Relentant, the Merciful.

# 45

We said: get ye all down from hence, and if there cometh unto you a guidance from Me, then whosoever shall follow Mine guidance, -- no fear shall come on them, nor shall they grieve.

# 46

And those who disbelieve and belie Our signs, --they, shall be fellows of the Fire; therein they shall be abiders.

# 47

Children of Israel! remember My favour wherewith favoured you, and fulfil My covenant, and shall fulfil your covenant, and Me alone shall ye dread.

# 48

And believe in that which I have sent down confirming that which is with you, and be not the first to disbelieve therein, and barter not My revelations for a small price, and Me alone shall ye fear.

# 49

And confound not the truth with falsehood, nor hide the truth while ye know.

# 50

And establish prayer, and give the poor-rate, and bow down with those who bow down.

# 51

Command ye mankind to piety and forget yourselves, the while ye read the Book! Understand then ye not!

# 52

And seek help in patience and prayer and verily it is, hard except prayer unto the meek.

# 53

Who know that verily they are going to meet their Lord, and that verily unto Him they are going to return,

# 54

O Children of Israel: remember My favour wherewith I favoured you, and that verily I preferred you over the world.

# 55

And fear a Day whereon not in aught shall a soul satisfy for a soul, nor shall intercession be accepted thereof, shall compensation be received therefor, nor shall they be succoured.

# 56

And recall what time We delivered you from the house of Fir'awn imposing upon you evil torment, slaughtering your sons and letting your women live; and therein was a trial, from your Lord, Mighty.

# 57

And recall what time We separated the sea for you and delivered you and drowned Fir'awn's house while ye looked on.

# 58

And recall what time We treated with Musa forty nights, then ye betook the calf after him, and ye were wrong-doers.

# 59

Then We pardoned you thereafter, that haply ye may return thanks.

# 60

And recall what time We vouchsafed unto Musa the Book and the distinction that haply ye may be guided.

# 61

And recall what time Musa said unto his people: my people! verily ye have wronged your souls by your taking the calf, wherefore repent unto your Maker, and slay yourselves: that were best for you with your Maker. Then He relented toward you; verily He! He is the Relentant, the Merciful

# 62

And recall what time ye said: O Musa! we will not believe in thee until we see God openly; then a thunderbolt took hold of you while ye looked on.

# 63

Then We raised you after your death that haply ye may return thanks.

# 64

And We overshadowed you with Clouds and We sent down unto you the Manna and the quails, saying: eat of the clean things, wherewith We have provided you. And they wronged Us not, but themselves they were wont to wrong.

# 65

And recall what time We said: enter this town and eat plenteously therefrom as ye list, and enter the gate prostrating yourselves and say: forgiveness; We shall forgive you your trespasses, and anon We shall increase unto the well-doers.

# 66

Then those who did wrong changed the Word that had been told them for anot her; so We sent down upon those who did wrong a scourge from heaven, for they were wont to transgress.

# 67

And recall what time Musa prayed for drink for his people. We said: smite With thy staff the stone. Then there gushed forth thereout twelve springs; every people already knew their drinking-place; eat and drink of the provision of Allah, and commit not evil on the earth as corrupters.

# 68

And recall what time ye said: O Musa! we shall by no means bear patiently with one food, wherefore supplicate for us unto thy Lord that He bring forth for us of that which the earth groweth, of its vegetables, and its cucumbers, and its Wheat, and its lentils, and its onions. He Said: would ye take in exchange that which is mean for that which is better! Get ye down into a City, as verily therein is for you that which ye ask for. And stuck upon them were abjection and poverty. And they drew on themselves indignation from Allah. This, because they were ever disbelieving in the signs of Allah and slaying the prophets without justice. This, because they disobeyed and were ever trespassing.

# 69

Verily those who believe, and those who are Judaised, and the Nazarenes, and the Sabians, - whosoever, believeth in Allah and the Last Day and worketh righteously, these! unto them shall be their hire with their Lord, no feal shall come on them nor shall they grieve.

# 70

And recall what time We took your bond, and raised over you the Tur saying: hold fast to that which We have vouchsafed unto you, and remember that which is therein, that haply ye may become God-fearing.

# 71

Then ye turned away there after; so had not the grace of Allah been unto you and His mercy, ye had surely become of the losers.

# 72

And assuredly ye know of those of you who trespassed in the matter of the Sabbath, wherefore We said unto them: be ye apes despised.

# 73

And We made it a deterrent unto those of their day and those after them, and an exhortation unto the God-fearing.

# 74

And recall what time Musa said unto his people: verily Allah commandeth you that ye slaughter a cow. They said: makest thou a jest of us? He said take refuge with Allah that I should be of the ignorant.

# 75

They said: supplicate for us unto thy Lord that He make manifest unto us whatever she should be. He said: verily He saith, she should be a cow neither old nor young, but middle-aged betwixt that; do then as ye are commanded.

# 76

They said: supplicate for us unto thy Lord that He make manifest unto us whatever her colour should be. He said: verily He saith, she should be a yellow cow the colour whereof is deepest, delighting the beholders.

# 77

They said supplicate for us unto thy Lord that He make manifest unto us whatever she should be, for verily the cow hath become dubious unto us and verily we, if God will, shall beguided.

# 78

He said: verily He saith, verify she should be a cow unyoked, not broken to till the ground or to water the field, whole, and without blemish in her. They said: now hast thou brought the truth. Then they slaughtered her, and they were wellnigh not doing it.

# 79

And recall what time ye slew a person, then quarrelled among yourselves respecting it, and Allah was to bring out that which ye were hiding.

# 80

Wherefore We said: smite him with part of her. Thus will Allah quicken the dead and He sheweth you His signs that haply ye may under stand.

# 81

Then your hearts hardened thereafter, so they are as stones or stronger in hardness: and verily of stones there are some from which gush forth rivers, and verily there are of them some that cleave asunder and water issueth therefrom, and verily there are of them some that fall down in awe of Allah: and Allah is not neglectful of that which ye work.

# 82

Covet ye then that they would believe for you whereas surely a Party of them hath been hearing the Word of Allah and then reverting it after they have understood it, While they know.

# 83

And when they meet those who believe they say: we believe; and when some of them are alone with some others they say speak ye unto them of that which God hath opened unto you so that they may argue therewith against you before your Lord? understand then ye not?

# 84

Know they not that Allah knoweth that which they hide and that which they make known?

# 85

And of them are unlettered ones who know not the Book but vain desires; and they do but conjecture.

# 86

Woe then unto those who write out the Book with their hands and say thereafter: this is from God, that they may barter it for a small price. Woe then unto them for that which thei hands had written; and woe unto them for that which they earn therwith.

# 87

And they say: Fire shall touch us not save for a few numbered days. Say thou: have ye taken a covenant with Allah, so that Allah shall not fail His covenant? or fabricate ye against Allah that which ye know not

# 88

O Yea! whosoever earnoth vice and his sin hath encompassed him, those shall be the fellows of the Fire, as abiders therein.

# 89

And those who believe and do righteous works, --those shall be the fellows of the Garden, as abiders therein.

# 90

And recall what time We took a bond with the Children of Israel saying: worship not any god save Allah, and unto parents show kindness, and also unto the kindred and the orphans and the poor, and speak kindly unto mankind, and establish prayer and give the poor rate. Then ye turned away, save a few of you, and ye are backsliders.

# 91

And recall what time We took a bond with you: saying: ye shall not shed your blood, nor drive one anot her from your homes; then ye ratified it and ye Were witnesses

# 92

Thereafter it is ye the very ones who slay each other and drive a party of you from their homes, and back up against them with guilt and iniquity; and if they come unto you as captives, ye ransom them, whereas forbidden unto you was their driving away itself. Believe ye then in part of the Book and disbelieve in part? What, then, is to be the meed of those of you who do that, save humiliation in the life of the world? And on the Day of Judgement they shall be brought back to the severest torment, and Allah is not neglectful of that which ye work.

# 93

These are they who have purchased the life of the world for the Hereafter; wherefore the torment shall not be lightened for them, nor shall they be succoured.

# 94

And assuredly We vouchsafed unto Musa the Book and We followed him up by the apostles after him, and unto 'lsa, son of Maryam, We vouchsafed evidences and aided him with the Holy Spirit. Then so often as there came unto you an apostle with that which your souls desired not, ye waxed stiff necked; and some ye belied and some ye slew?

# 95

And they say: our hearts are uncircumcised. Nay! Allah hath cursed them because of their infidelity: little wherefore it is they believe.

# 96

And when there came unto them a Book from before Allah confirming that which was with them, --and afore they were entreating God for victory over these who disbelieved, -then when there came unto them that which they recognised. they disbelieved therein wherefore Allah's curse be on the infidels!

# 97

Vile is that for which they have bartered their souls, that they should disbelieve that which Allah hath sent down, out of envy that Allah should reveal, out of His grace, unto whosoever of His bond men He listeth. Wherefore they have drawn upon themselves wrath upon wrath, and unto the infidel shall be a torment ignominious.

# 98

And when it said unto them believe in that which Allah hath sent down now, they say: we believe in that which hath been sent down unto Us. And they disbelieve in that which is besides that while it is the truth, confirming that which is with them. Say thou: wherefore then slew ye Allah's prophets afore, a if ye have been believers?

# 99

And assuredly Musa came unto you with evidence, then ye betook the calf after him, and ye were wrong-doers.

# 100

And recall what time We took your bond and raised over you the Tur, saying: hold fast to that which We have vouchsafed unto you and hearken. They said: we hear and we disobey. And into their hearts the calf was made to sink because of their infidelity. Say thou: vile is that which your belief commandeth you, if ye are believers.

# 101

Say thou: if for you alone is the abode of the Hereafter with Allah to the exclusion of mankind, then wish for death if ye say sooth.

# 102

And they will by no means ever wish for it, because of that which their hands have sent on before; and Allah is the Knower of the wrong-doers.

# 103

And surely thou wilt find them the greediest of men after life, even greedier than those who associate. Each one of them would fain life for a thousand years, and this will not save him from the torment, even if he hath lived so long. And Allah is the Beholder of that which they work.

# 104

Say thou: whosoever is an enemy unto Jibril, ----then verily he it is Who hath brought down this Revelation, by Allah's command, to thine heart, confirming that which went before, and a guidance and glad tidings unto the believers.

# 105

Whosoever is an enemy unto Allah and His angels and His apostles and Jibril and Mikail, then verily Allah is an enemy unto the infidels.

# 106

And assuredly We have sent down Unto thee evident signs, and none shall disbelieve therein save the transgressors.

# 107

Is it that whenever they enter into a covenant some party among them cast it aside? Aye! most of them even believe not.

# 108

And whenever there came unto them an apostle from Allah confessing to that which was with them, a Party among those who were vouchsafed the Book, cast Allah's Book behind their backs as though they knew not.

# 109

And they follow that which the Satans recited in the reign of Sulaiman; and Sulaiman blasphemed not, but the Satans blasphemed.; teaching people magic; and they follow that also which was sent down unto the two angels in Babil, Harut, and Marut. Unto none the twain taught it until they had said: We are but a temptation, so blaspheme not; but they learned from the twain that wherewith they might separate man from his wife; and they could harm none thereby save by Allah's will. And they have learnt that which harmeth them, and profiteth them not; and assuredly they know that whosoever purchaseth it, his is no portion in the Hereafter. And surely vile is the price for which they have bartered themselves, if they but knew!

# 110

And had they believed and feared, surely better had been the reward from before Allah, if they but knew!

# 111

O O Ye who believe! say not: Ra'ina, but say: Unzurna, and hearken; and unto the infidel shall be a torment afflictive.

# 112

Fain would they who disbelieve, be they of the people of the Book or of the associators, that naught of good should be sent down unto you from Your Lord; whereas Allah singleth out for His mercy whomsoever He will and Allah is the Lord of mighty grace.

# 113

Whatsoever verse We abrogate or cause to be forgotten We bring a better one or the like thereof; knowest thou not that Allah is over everything Potent?

# 114

Knowest thou not that verily Allah! His is the dominion of the heavens and the earth? and for you beside Allah is no protector or helper.

# 115

Seek ye to question your apostle, even as Musa was questioned afore. And whosoever changeth belief for infidelity, he hath of a surety strayed from the even way.

# 116

Fain would Many of the People of the Book turn you back infidels after ye have believed, out of envy from their, after the truth hath become manifest unto them so Pardon them, and pass over, until Allah sendeth His command. Verily Allah is over everything Potent.

# 117

And establish prayer and give the poor-rate. and whatsoever of good ye send forth for your souls ye shall find with Allah; verily Allah is the Beholder of that which ye work.

# 118

And they say: none shall enter the Garden except he be a Jew or a Nazarene. Such are their vain desires! Say thou: forthwith your proof if ye say

# 119

Aye! whosoever submitteth himself unto Allah and he is a well-doer-his hire is with his Lord; no fear shall come on them nor shall they grieve.

# 120

And the Jews say: the Nazarenes are not grounded on aught: and the Nazarenes say: the Jews are not grounded on aught While they recite the same Book. Even so say those who know not, the like of their saying. Allah will judge between them on the Day of Resurrection regarding that wherein they have been differing.

# 121

And who is more unjust than he who preventeth the mosques of Allah, that His name be mentioned therein, and striveth after their ruin? These! it was not for them to enter therein except in fear. Unto them shall be humiliation in this World, and unto them in the Hereafter a torment mighty.

# 122

And unto Allah belongeth the east and the west; so withersoever you turn there is the countenance of Allah: verily Allah is pervading, Knowing.

# 123

And they Say: God hath betaken unto Him a son! Hallowed be He: Aye unto Him belongeth whatsoever is in the heavens and the earth: ', all are unto Him devout

# 124

The Originator of the heavens and the earth; and whensoever He decreeth an affair, He only saith unto it: be; and it becometh.

# 125

And those who know not, say: Wherefore speakest not God unto us? or cometh not unto us a sign? Thus aid those before them the like of their saying: consimilar are their hearts. We have already manifested the signs unto the people who would be convinced.

# 126

Verily We have sent thee with the truth, as a bearer of glad tidings and a warner, and thou shalt not be questioned of the fellows of the Flame.

# 127

And the Jews will never be pleased with thee, nor the Nazarenes, except thou follow their faith. Say thou: verily the guidance of Allah, --that is the guidance. And of a surety wert thou to follow their desires after that which hath come unto thee of the knowledge, there will be for thee against Allah neither protector nor helper.

# 128

Those unto whom We have vouchsafed the Book and they recite it as it ought to be recited - they shall believe therein and whosoever disbelieveth therein, those then! they shall be the losers.

# 129

O Children of Isra'il! remember My favour wherewith favoured you, and that I preferred you over the world.

# 130

And fear a Day whereon not in aught shall a soul satisfy for a soul, nor shall compensation be accepted therefor, nor shall intercession profit it, nor shall they be succoured.

# 131

And recall what time his Lord Proved Ibrahim with certain words then he performed them. He said: verily I am going to make thee a leader unto mankind. Ibrahim said: and also of my progeny? Allah said: My covenant shall not reach the wrong-doers.

# 132

And recall what time We appointed the House a resort unto man kind and a place of security and said: take the station of Ibrahim for a place of prayer. And We covenanted with Ibrahim and Ismai'l, saying: purify ye twain My Houses for those who shall circumambulate it and those who shall stay, and those who shall bow down and prostrate themselves.

# 133

And recall what time Ibrahim said: my Lord! make this city a place of security, and provide the People thereof with fruits, - such of them as will believe in Allah and the last Day. Allah said: and whosoever will disbelieve, him also shall give enjoyment for a while; thereafter I shall drive him to the torment of the Fire, - an ill abode!

# 134

And recall what time Ibrahim was raising the foundation of the House and also Ismai'l, praying: our Lord! accept of us; verily Thou! Thou art the Hearer, the Knower!

# 135

Our Lord! make us twain submissive unto Thee, and of our progeny community submissive unto Thee, and show us our rites, and relent toward us! verily Thou! Thou art the Relentant, the Merciful!

# 136

Our Lord! raise up unto them an apostle from among them, who shall recite unto them Thy revelations, and shall teach them the Book and wisdom, and shall cleanse them. Verily Thou! Thou art the Mighty, the Wise.

# 137

And who shall be averse from the faith of Ibrahim, save one who befooleth his soul! And assuredly We chose him in this World, and verily he in the Hereafter shall be of the righteous.

# 138

Recall what time his Lord said unto him: submit, he said: I submit to the Lord of the Worlds.

# 139

And Ibrahim enjoined his sons the same and did Ya'qub also, saying: O my sons! verily Allah hath chosen for you the religion, so die not except ye be Muslims.

# 140

Were ye witnesses when death presented itself to Ya'qub, what time he said unto his sons: what will ye worship after me! They said: we shall worship the God the God of thy fathers, Ibrahim and Ismai'l and Ishaq, and unto Him we are submissive.

# 141

That are a community who have passed away, unto them shall be that which they earned and unto you that which ye earn, and ye shall be questioned not of that which they were wont to Work.

# 142

And they say: become Jews or Nazarenes, and ye shall be guided. Say thou: Aye! we follow the faith of Ibrahim, the upright, and he was not of the associators.

# 143

Say: we believe in Allah and that which hath been sent down unto us and that which was sent down unto Ibrahim and Ismai'l and Ishaq and Ya'qub and the tribes, and that which was vouchsafed unto Musa and lsa, and that which was vouchsafed unto the prophets from their Lord; we differentiate not between any of them, and unto Him are submissive.

# 144

So if they believe in the like of that which ye believe in, surely they are guided; but if they turn away, then they are but in Cleavage. So Allah will suffice thee against them and He is the Hearer, the Knower.

# 145

Ours is the dye of Allah! and who is better at dyeing than Allah! And we are His worshippers.

# 146

Say thou: contend ye with us regarding Allah, whereas He is our Lord even as He is Your Lord And unto us our works, and unto you your works, and we are His devotees.

# 147

Or say ye that Ibrahim and Ismai'l and Ishaq and Ya'qub, and the tribes were Jews or Nazarenes? Say thou: are ye the more knowing or is Allah? And who is more unjust than he who hideth a testimony that is with him from Allah? And Allah is not neglectful of that which ye Work.

# 148

That are a community who have passed away; unto them shall be that which they earned, and unto you that which ye earn; and ye shall be questioned not of that which they were wont to Work.

# 149

Anon will the foolish among mankind say: what hath turned them away from their Qiblah whereon they had been? Say thou: unto Allah belongeth the east and the west he guideth whomsoever He listeth unto a straight path.

# 150

And in this wise We have made you a community justly balanced, that ye may be witness against the man kind and that the apostle may be in regard to you a witness. And We appointed not the Qiblah which thou hast had save in order that We might know him who followeth the apostle from him who turnoth back upon his heels. And of a surety the change is grievous save unto those whom Allah hath guided. And Allah is not one to let your faith go wasted; verily Allah is unto mankind Tender, Merciful.

# 151

Oft We have seen the turning of thy face to the heaven, wherefore We shall assuredly cause thee to turn towards the Qiblah which shall please thee. Turn then thy face toward the Sacred Mosque; and turn ye, wheresoever ye be, your faces toward it. And verily those who are vouchsafed the Book know this to be the truth and from their Lord. Allah is not neglectful of that which they Work.

# 152

And shouldst thou bring unto those who are vouchsafed the Book every sign, they would not follow thy Qiblah, neither art thou to be a follower of their Qiblah; nor doth one part of them follow the Qiblah of the other. And shouldst thou follow their desires, after that which hath come unto thee of the knowledge, then verily thou wilt become one of the wrong-doers.

# 153

Those unto whom We have vouchsafed the Book recognise him even as they recognise their children; and verily a party of them hide the truth while they know.

# 154

The truth is from thy Lord; be then thou not of the doubters.

# 155

For every one is a direction witherward he turnoth; so strive to be foremost in virtues. Wheresoever ye may be, Allah will bring you together. Verily Allah is over everything Potent.

# 156

And from whencesoever thou goest forth, turn thy face toward the Sacred Mosque, and verily it is the very truth from thy Lord; and Allah is not neglectful of that which ye work.

# 157

And from whencesoever thou goest forth, turn thy face toward the Sacred Mosque, and wheresoever ye be, turn your face toward it, lest there should be with people an argument against you, except those of them who do wrong so fear them not, but fear Me; so that I may accomplish My favour upon you, and that ye may remain guided-

# 158

Even as We have sent amidst you an apostle from amongst you, who rehearseth unto you Our revelations and purifieth you, and teacheth you the Book and wisdom, and teacheth you that which ye were not wont to know.

# 159

Remember Me wherefore, and I shall remember you: and unto Me give thanks, and be notingrate unto Me.

# 160

O O Ye who believe! seek help in patience and prayer; verily Allah is with the patient.

# 161

And say not of those who are slain in the way of Allah: dead. Nay, they are living, but ye perceive not.

# 162

And We will surely prove you with aught of fear and hunger and diminution in riches and lives and fruits; and bear thou the glad tidings unto the patient;

# 163

Who, when there afflicteth them an affliction, say: verily we are Allah's, and verily unto Him we are returners.

# 164

These! on them shall be benedictions from their Lord and His mercy, and these! they are the rightly guided.

# 165

Verily Safa and Marwa are of the landmarks of Allah; so whosoever maketh a pilgrimage to the House, or performeth the Umra, in him there is no fault if he walketh in-between the twain. And whosoever voluntarily doth good, then verily Allah is Appreciative, Knowing.

# 166

Verily those who hide that which We have sent down of evidence and the guidance, after We have expounded its Unto mankind in the Book, these! - curseth them Allah, and shall curse them the cursers

# 167

Save those that repent and amend, and make manifest the truth I these it is toward whom I relent. And I am the Relenting, the Merciful!

# 168

Verily those who disbelieve, and die while they are infidels, these it is on whom shall be the curse of Allah and the angels and mankind all.

# 169

They shall be abiders therein, the torment shall not be lightened on them, nor shall they be respited.

# 170

And the God of you all is one God; there is no God but he, the Compassionate, the Merciful.

# 171

Verily in the creation of the heavens and the earth, and the alternation of night and day, and the ships that course upon the sea laden with that which profiteth mankind, and that which Allah sendeth down of water from the heaven and quickenoth the earth thereby after the death thereof; and scattereth therein of all kinds of moving creatures, and in the veering of the winds and the cloud subjected for service betwixt heaven and earth. are signs unto a people who understand.

# 172

And of mankind are some that set up compeers; unto Allah they love them as with the love due to Allah. And those who believe are strongest in love of Allah. Would that those who do wrong saw, when they saw the torment, that verily power belonged wholly unto Allah, and that Allah was severe in requital -

# 173

When those who were followed shall quit themselves of those who followed, and they all shall behold the torment, and sundered between them shall be the Cords.

# 174

And those who had followed shall say would that for us were a return, then would we quit ourselves of them as they have quitted themselves of us. In this wise Allah will show them their works as vain regrets; and they shall not be coming forth from the Fire.

# 175

Mankind! eat of whatsoever is, the earth, lawful, and clean and follow not the footsteps of Satan; verily he is an enemy unto you manifest.

# 176

He only commandeth you to evil and indecency, and that ye should say against Allah that which ye know not

# 177

And when it said unto them: follow that which Allah hath sent down, they say: nay, we shall follow that way whereon we found our fathers - even though their fathers understood not aught, nor were they guided aright?

# 178

And the likeness of those who disbelieve is as the likeness of one who shouteth unto that which heareth naught except a call and a cry; deaf, dumb; blind, wherefore they understand not.

# 179

O O Ye who believe! eat of the clean things wherewith We have provided you, and return thanks unto Allah, if Him indeed ye are wont to worship.

# 180

He hath only forbidden unto you the carcass and blood and the flesh of swine, and that over which is invoked the name of other than Allah. But whosoever is driven by necessity, neither alusting nor transgressing, for him is no sin; verily Allah is Forgiving, Merciful.

# 181

Verily those who hide that which Allah hath sent down in the Book and Purchase therewith a small gain, these are they who eat in their bellies naught but Fire. Allah will not speak unto them on the Day of Resurrection, nor purify them; and unto them shall be a torment afflictive.

# 182

These are they who have purchased error for guidance, and torment for forgiveness, How enduring must they be of the Fire!

# 183

This shall be because Allah hath verily sent down the Book with truth: and verily those who differ respecting the Book. are surely in cleavage wide.

# 184

Virtue is not in this that ye turn your faces toward the east and west, but virtue is of him who believeth in Allah and the Last Day and the angels and the Book and the prophets: and giveth of his substance, for love of Him unto kindred and orphans and the needy and the wayfarer and the beggars and for redeeming necks, and establisheth prayer and giveth the poor-rate and is of the performers of their covenant when they have covenanted; and is of the patient in adversity and affliction and in time or violence these are they who are proven true, and these they are God-fearing.

# 185

O O Ye who believe! prescribed unto you is retaliation for the slain; the free for the free, and a bondsman for a bondsman, and a woman for a woman; yet unto whomsoever is pardoned aught by his brother, then a serving with lenity and payments with kindness. That is an alleviation from your Lord and a mercy so whosoever shall transgress thereafter, for him there shall be a torment afflictive.

# 186

And for you in retaliation is life men of insight! that haply ye may fear God.

# 187

Prescribed unto you, when death is nigh unto one of you, if he leaveth any property, is the making of a bequest for parents and kindred equitably - a duty on the God-fearing.

# 188

Then whosoever altereth it after he hath heard it, the sin thereof shall be only on those who shall alter it: verily Allah is Hearing, Knowing.

# 189

How beit whosoever apprehendeth from the testator a mistake or a sin and thereupon he maketh up the matter between them, on him there shall be no sin; verily Allah is Forgiving, Merciful.

# 190

O ye who believe! prescribed unto you is fasting even as it was prescribed unto those before you, that haply ye may fear God.

# 191

Days numbered and few; then whosoever among you is sick or journeying, for him the like number of other days. And for those who can keep it with hardship the ransom is the feeding of a and whosoever voluntarily poor man doth good, it will be better for him; and that ye fast Will be better for you, if ye only knew.

# 192

The month of Ramadhan: therein was sent down the Qur'an: is a guidance unto mankind, and with evidences: one of the Books of guidance and the distinction. So whosoever of you witnesseth the month, he shall fast it, and whosoever sick or journeying, for him the like number of other days. Allah intendeth for you ease, and intendeth not for you hardship; so ye shall fulfil the number and shall magnify Allah for His having guided you, and haply ye may give thanks.

# 193

And when My bondsmen ask thee regarding Me, then verily I am Nigh; I answer the call of the caller when he calleth unto Me,; so let them answer Me and believe in Me, haply they may be rightly directed.

# 194

Allowed unto you, on the night of fasts, is consorting with your women. they are a garment unto you, and ye are a garment unto them. Allah knoweth that ye have been defrauding yourselves, so He hath relented toward you and pardoned you. Wherefore now copulate with them, and seek that which Allah hath prescribed for you, and eat and drink, Until the white thread becometh manifest unto you from the black thread of the dawn; thereafter complete the fast till night fall. And copulate not with them While ye are retreating in the mosques. These are the bounds of Allah, wherefore approach them not. Thus Allah expoundeth all His signs unto mankind that haply they may fear Him.

# 195

And devour not your riches among yourselves in vanity, nor convey them unto the judges that ye may devour thereby a portion of other people's riches sinfully while ye know.

# 196

They ask thee of new moons. Say thou: they are time-marks to mankind and for pilgrimage. And it is not piety that ye enter your houses by the backs thereof, but Piety is of him who feareth God; so enter the houses by the doors thereof, and fear Allah that haply ye may thrive.

# 197

And fight in the way of Allah those who fight you, and transgress not; verily Allah loveth not the transgressors

# 198

And slay them wheresoever ye come upon them, and drive them out whence they drove you out; and temptation is more grievous than slaughter. And fight them not near the Sacred Mosque until they fight you therein, but if they get ready to fight you there, then slay them. That is the meed of the infidels.

# 199

Then if they desist, then verily Allah is Forgiving, Merciful.

# 200

And fight them until there be no more temptation, and their obedience be wholly unto Allah. So if they desist, then there is to be no violence save against the wrong-doers.

# 201

A sacred month is for a sacred month; these sacrednesses are in retaliation. Whosoever then offereth violence unto you, Offer violence unto him the like of his violence unto you, and fear Allah, and know that Allah is with the God-fearing.

# 202

And expend in the way of Allah, and cast not yourselves with your hands into perdition, and do well. verily Allah loveth the well- doers,

# 203

And fulfil the pilgrimage and 'Umra for Allah. And if ye be besieged, offer whatsoever offering be easy, and shave not Your heads, until the offering reacheth its destination. Then whosoever of you sick or hath hurt in his head, for him is a ransom by fasting or alms or a rite. Then when ye are secure, whosoever combinoth 'Umra with the pilgrimage, for him is whatsoever offering be easy. And whosoever cannot afford then for him is a fast of three days during the pilgrimage and of seven when ye return these are ten days complete. That is for him whose family dwell not near the Sacred Mosque. And fear Allah, and know that verily Allah is severe in chastising.

# 204

The season of Pilgrimage is the months known; wherefore whosoever ordaineth unto himself the pilgrimage therein, there is no lewdness nor wickedness nor wrangling during the pilgrimage, and whatsoever of good ye do, Allah shall know it. And take provision for the journey, for verily the best provision is abstainment; and fear Me, O men of understanding!

# 205

No fault it is in you if ye seek grace from your Lord. Then when ye hurry from Arafat, remember Allah near the sacred monument. Remember Him as He hath guided you, and ye were afore of the erring.

# 206

Then hurry from the place whence the other people have hurried, and ask forgiveness of Allah, verily Allah is Forgiving, Merciful.

# 207

And when ye have completed Your rites, remember Allah even as ye remember your fathers or with a stronger remembrance. Of mankind there are some who say: our Lord vouchsafe unto us in, the world. And for such there shall be no portion in the Hereafter.

# 208

And of mankind are some who say: our Lord! vouchsafe unto us good in the world and good in the Hereafter, and save us from the torment of the Fire.

# 209

These! for them will be a share for that which they have earned. and Allah is swift at reckoning.

# 210

And remember Allah on the days numbered. Then whosoever hastenoth in two days on him is no sin, and whosoever delayeth, On him is no sin: this for him: who feareth. So fear Allah, and know that verily unto Him shall ye be gathered.

# 211

And of mankind is he whose discourse for the purpose of this world thou admirest, and he taketh Allah to witness as to that which is in his heart, whereas he is the most contentious of the adversaries.

# 212

And when he turnoth away, he speedeth through the land that He may act corruptly therein and destroy the tilth and the stock. And Allah approveth not corruptness.

# 213

And when it said unto him: fear Allah, arrogance taketh him to sin. Enough for him is Hell: surely an ill resort!

# 214

And of mankind is he who selleth his life even, seeking the pleasure of Allah; and Allah is Tender unto His bond men

# 215

O Ye who believe! enter into Islam wholly, and follow not the foot steps of the Satan, verily he is unto you an enemy manifest.

# 216

Wherefore if ye slip after that which hath come unto you of the evidence then - know that Allah is Mighty, Wise.

# 217

Await they only that Allah shall come unto them in the shadows of the Clouds, and also the angels, and the affair is decreed! And unto Allah are all affairs returned.

# 218

Ask thou the Children of Isra'il, how many a manifest sign We brought unto them. And whosoever altereth the favour of Allah after it hath come unto him, then verily Allah is severe in Chastising.

# 219

Fair-seeming is made the life of the world unto those who disbelieve, and they scoff at those who believe, whereas those who fear God shall be above them on the Day of Resurrection. And Allah provideth whomsoever He listeth without reckoning.

# 220

Mankind was one community; thereafter Allah raised prophets as bearers of glad tidings and warners, as He sent down the Book With truth that He may judge between mankind in that wherein they disputed. And none differed therein save those unto whom it was vouchsafed after the evidences had come to them, out of spite among themselves; then Allah guided those who believed unto the truth of that regarding which they differed, by His leave. Allah guideth whomsoever He listeth unto a path straight.

# 221

Deem ye that ye will enter the Garden while ye hath not come upon you the like of that which came upon those who have passed away before you There touched them adversity and distress, and shaken were they, until the apostle and those who believed with him said; when cometh the succour of Allah! Lo! verily Allah's succour is nigh.

# 222

They ask thee regarding whatsoever they shall expend. Say thou: whatsoever ye expend of wealth, let it be for the parents and kindred and orphans and the needy and the wayfarer and whatever good ye do, verily Allah is the Knower thereof.

# 223

Prescribed unto you is fighting, albeit it is abhorrent unto you. Belike ye abhor at thing whereas it is good for you, and belike ye desire a thing whereas it Is bad for you. And Allah knowcth and ye know not.

# 224

They ask thee of the sacred month, of fighting therein. Say thou; fighting therein is grievous; and hindering people from the way of Allah and unbelief in Him and in the sanctity of the Sacred Mosque and driving out its dwellers therefrom are more grievous with Allah, and such temptation is far more grievous than that slaughter. And they will not cease fighting you so that they might make you apostatize from your religion, if they can. And whosoever of you apostatizeth from his faith and dieth an Infidel, then these it is whose works shall be of none effect in this world and the Hereafter, and they shall be the fellows of the Fire; therein they shall be abiders.

# 225

Verily those who have believed and those who have emigrated and have striven hard in the way of Allah, all these shall hope for the mercy of Allah, and Allah is Forgiving, Merciful.

# 226

They ask thee of wine, and gambling. Say thou: in both is a great sin, and some benefits for men, but the sin of them is for greater than their benefit. And they ask thee, how much they should expend. Say thou: the redundant portion. In this wise Allah expoundeth unto you His commandments that haply ye may ponder.

# 227

On this Wor1d and the Here after. And they ask thee of orphans. Say thou: to set right affairs for them were best. If ye mix with them, then they are your brethren. Allah knoweth the foul-dealer from the fair-dealer. And had Allah so willed, He could have harassed you; verily Allah is Mighty, Wise.

# 228

And wed not infidel women until they believe; of a surety a believing bondwoman is better than an infidel Woman, albeit she please you. And wed not your women to infidel men until they believe; of a surety a believing bondman is better than an infidel, albeit the please you. These Call you unto the Fire, and Allah calleth you unto the Garden and unto forgiveness, by His leave; and He expoundeth His commandments unto mankind that haply they may be admonished.

# 229

And they ask thee of menstruation. Say thou: it is a pollution, so keep away from women during menstruation, and go not in unto them until they have purified themselves. Then when they have thoroughly purified themselves, go in unto them as Allah hath commanded you. Verily Allah loveth the penitents, and loveth the purifiers of themselves.

# 230

Your women are tilth Unto you, so go in unto your tilth as ye list, and provide beforehand for your souls. And fear Allah, and know that ye are going to meet Him; and give thou glad tidings Unto the believers.

# 231

And make not Allah a butt of your oaths that ye shall not act piously nor fear Allah nor set things right between and Allah is Hearing, Knowing.

# 232

Allah will not take you to task for the vain in Your oaths, but he shall take you to task for that which your hearts have earned, and He is the Forgiving, the Forbearing.

# 233

For those who swear off from their wives is a awaiting of four months; then if they go back, verily Allah is Forgiving, Merciful.

# 234

And if they resolve on divorcement, then verily Allah is Hearing, Knowing.

# 235

And the divorced women shall keep themselves in waiting for three courses nor is it allowed unto them that they should hide that which Allah hath created in their wombs, if they believe in Allah and the Last Day. And their husbands are more entitled to their restorations during the same, if they desire rectification. Unto women is due likes that which is due from women reputably. And for men is a degree over them. And Allah is Mighty, Wise.

# 236

Divorcement is twice: thereafter either retaining her reputably, or letting her off kindly. And it is not allowed unto you to take away aught ye have given them, except the twain fear that they may not observe the bonds of Allah. If yes fear that the twain may not observe the bonds of Allah, then no blame is on the twain for that where with she ransometh herself. These are the bonds of Allah, wherefore trespass them not; and whosoever trespasseth the bonds of Allah, then verily these! they are the wrong-doers.

# 237

If he divorceth her, then she is not allowed unto him thereafter until she wed a husband other than he; then if he divorceth her, no blame is on the twain in that they return unto each other, if they imagine they will oh serve the bonds of Allah. And these are the bonds of Allah; He expoundeth them unto a people who know.

# 238

And when ye have divorced your women, and they have attained their period, then either retain them reputably or let them off kindly; and retain them not to their hurt that ye may trespass; and whosoever doth this assuredly wrongeth his soul. And hold not Allah's commandments in mockery and remember Allah's favour upon you, and that he hath sent down unto you the Book and the wisdom wherewith He exhorted you; and fear Allah, and know that verily Allah is of everything the Knower

# 239

And when ye have divorced women and they have attained their period; straiten them not so that they wed not their husbands when they have agreed between themselves reputably; hereby is exhorted he among you who believeth in Allah and the Last Day: this is cleanest for you and purest. Allah knoweth and ye know not.

# 240

And mothers shall suckle their children two whole years: this is for him who intendeth that he shall complete the suckling; and on him to whom the child is born, is their provision and clothing reputably; not a soul is tasked except according to its capacity. Neither shall a mother be hurt because of her child, nor shall he to whom the child is born because of his Child; and on the heir shall devolve the like thereof. Then if the twain desire weaning by agreement between them and mutual counsel, on the twain is no blame. And if ye desire to give your children out for suckling, On you is no blame when ye hand over that which ye had agreed to give her reputably. And fear Allah, and know that of that which ye work Allah is the Beholder.

# 241

And as for those of you who die and leave wives behind, they Shall keep them selves in waiting for four months and ten days. Then when they have attained their period, no blame there is on you for that which they do with them selves reputably. And of that which ye work Allah is aware.

# 242

And no blame is on you in that ye speak indirectly of your troth unto the said women or conceal it in, your souls! Allah knoweth that ye will anon make mention of these women: but make no promises unto them in secret, except ye speak a reputable saying. And even resolve not on wedding-knot until the prescribed term hath attained its end; and know that Allah knoweth that which is in your souls, wherefore beware of Him, and know that Allah is Forgiving, Forbearing

# 243

No blame is on you if ye divorce women while yet ye have not touched them nor settled unto them a settlement. Benefit them on the affluent is due according to his means, and on the straitened is due according to his means. a reputable present, and duty on the well-doers.

# 244

And if ye divorce them ere ye have touched them but have settled unto them a settlement, then due from you is half of that which ye have settled unless the wives forego, or he in whose hand is the wedding-knot foregoeth, and that ye should forego is nigher unto piety. And forget not grace amongst yourself; verily of that which ye work Allah is the Beholder.

# 245

Guard the prayers, and the middle prayer, and stand up to Allah truly devout.

# 246

And if ye fear, then pray on foot or riding; then when ye are secure, remember Allah in the way He hath taught you which ye ever knew not.

# 247

And those of you who die and leave wives behind, they shall make a bequest unto their wives a year's maintenance without their having to go out, then if they go out, then no blame is on you for that which they, do with themselves reputably, and Allah is Mighty, Wise.

# 248

And for the divorced women shall be a reputable present: and duty on the God-fearing.

# 249

In this wise Allah expoundeth unto you His commandments, haply ye may reflect.

# 250

Bethinkest thou not of those Who Went forth from their habitations, and they were in their thousands, to escape death Then Allah said unto them: die and thereafter quickened them. Verily Allah is Gracious unto men; albeit most men give not thanks.

# 251

And fight in the way of Allah and know that verily Allah is Hearing, Knowing.

# 252

Who is he that will lend unto Allah a goodly loan, so that he will multiply it unto him manifold And Allah scanteth and amplifieth, and unto Him ye shall be returned.

# 253

Bethinkest thou not of the chiefs of the Children of Isra'il, after Musa? They said unto a Prophet of theirs: raise for us a king that we may fight in the way of God. He said: may it not be that if fighting were prescribed unto you, ye would not fight! They said: and wherefore shall we not fight in the way of God, whereas we have been driven forth from our habitations and children. Then when fighting was prescribed unto them, they turned away, save a few of them: and Allah is the Knower of the wrong-doers.

# 254

And their prophet said unto them: verily Allah hath raised unto you Talut as a king. They said: how can there be the dominion for him over us, whereas we are more worthy of the dominion than he nor hath he been vouchsafed an amplitude of wealth! He said: verily Allah hath chosen him over you and hath increased him amply in knowledge and physique, and Allah vouchsafeth His dominion unto whomsoever He listeth; and Allah is Bountiful, Knowing.

# 255

And their prophet said unto them: verily the sign of his dominion is that there shall come unto you the ark wherein is tranquillity from your Lord and the relic of that which the household of Musa and the household of Harun had left, the angels bearing it; verily, herein is a sign for you if ye are believers.

# 256

Then when Talut sallied forth with the hosts, he said, verily God will prove you with a river: then whosoever drinketh thereof shall be none of mine, and whosoever tasteth it not, verily shall be mine, excepting him who ladeth a lading with his hand. But they drank thereof, save a few of them. Then when he had crossed it, he, and those who believe with him, they said: We have no strength to-day against Jalut and his hosts. But those who imagined that they were going to meet Allah Said how oft hath a small party prevailed against a large party by God's leave! And Allah is with the patiently persevering.

# 257

And when they arrayed themselves against Jalut and his hosts, they said: our Lord pour forth on us patience, and set firm our feet, and make us triumph over the infidel people.

# 258

Then they vanquished them by the leave of Allah, and Da'ud slew Jalut, and Allah vouchsafed him dominion, and Wisdom and taught him of that which He Willed. And, it not for Allah's repelling people, some of them by means of others, the earth surely were corrupted; but Allah is Gracious unto the Worlds.

# 259

These are the revelations of Allah We rehearse them unto thee with truth, and verily thou art of the sentones.

# 260

These apostles: We have preferred some of them above some others: of them are some unto whom Allah spake, and some He raised many degrees. And We vouchsafed unto Isa, son of Maryam, the evidences, and We aided him with the holy spirit; and had Allah so willed those who came after them had not fought among themselves after the evidences had come unto them but they differed; then of them some believed and of them some disbelieved. And had Allah so willed, they had not fought among themselves, but Allah doth whatsoever He intendeth.

# 261

O O Ye who believe: expend of that which We have provided you ere the Day cometh wherein there will be neither bargain nor friendship nor intercession. And the infidels - they are the wrong-doers.

# 262

Allah! There is no God but he, the Living, the Sustainer Slumber taketh hold of Him not, nor sleep. His is whatsoever is in the heavens and whatsoever is on the earth. Who is he that shall intercede With Him except with His leave! He knoweth that which was before them and that which shall he after them, and they encompass not aught of His knowledge save that which He willeth. His throne comprehendeth the heavens and the earth, and the guarding of the twain wearieth Him not. And He is the High, the Supreme.

# 263

No constraint is there in the religion; surely rectitude hath become manifestly distinguished from the error. Whosoever then disbelieveth in the devil and believeth in Allah, hath of a surety rain hold of the firm cable whereof there is no giving way. And Allah is Hearing, Knowing.

# 264

Allah is the Patron of those who believe; He bringeth them forth from darknesses into the light; And, for those who disbelieve, the devils are their patrons; they bring them forth from the light into darknesses. These are the fellows of Fire, therein shall be abiders.

# 265

Bethinkest thou not of one who contended with Ibrahim concerning his Lord, because Allah had vouchsafed unto him dominion! When Ibrahim said: my Lord is He Who giveth life and causeth death, he said: give life and cause death. Ibrahim said: verily Allah bringeth the sun from the east, then bring it thou from the west. Thereupon he Who disbelieved Was dumb-founded, And Allah guideth not a wrong-doing people.

# 266

Or, the like unto him who passed by a town, and it lay overturned on its roofs. He said: how shall Allah quicken this after the death thereof Thereupon Allah made him dead for a hundred years, and thereafter raised him and said: how long hast thou tarried He said: I have tarried any day, or part of any day. Allah said: nay! thou hast tarried a hundred years: look at thy food and thy drink, they have not rotten, and look at thine ass; and this We have done in order that We may make of thee a sign unto men; and look thou at the bones, how we shall make them stand up and clothe them with flesh. Then when it became manifest Allah unto him he said: I know that verily everything Potent.

# 267

And recall what time Ibrahim Said: my Lord! shew me how Thou wiltquicken the dead. He said: belie Vest thou not! He said: O Yea but that my heart may rest at ease. He said: take then thou four of the birds, and incline them towards thee, and then put a part thereof on each hill, and thereafter call them; they will come unto thee speeding. And know thou that verily Allah is Mighty, Wise.

# 268

The likeness of those who expend their substance in the way of Allah is as the likeness of a grain that groweth seven ears and in each ear one hundred grains: and Allah multiplieth unto whomsoever He listeth. Allah is Bounteous, Knowing.

# 269

Those who expend their riches in the way of Allah and thereafter follow not that which they have expended with the laying of an obligation or with hurt, for them shall be their hire with their Lord; and no fear shall come on them, nor shall they grieve.

# 270

A reputable word and forgiveness are better than an alms which hurt followeth; and Allah is Self-Sufficient, Forbearing.

# 271

O O Ye who believe! make not your alms void by laying an obligation and by hurt, like unto him who expendeth his substance to be seen of men, and believeth not in Allah and the Last Day. The likeness of him is as the likeness of a smooth stone whereon is dust; a heavy rain falleth upon it, and leaveth it bare. They shall not have power over aught of that which they have earned and Allah shall not guide the disbelieving people.

# 272

And the likeness of those who expend their riches seeking the pleasure of Allah and for the strengthening of their souls is as the likeness of a garden on a height. A heavy rain falleth upon it, and it yieldeth its fruits two-fold and if no heavy rain falleth upon it, then a gentle rain and Allah is of that which ye work Beholder.

# 273

Fain would any of you that there be for him a garden of date-palms and grape-vines whereunder rivers flow end with every fruit therein for him, and that old age should befall him while he hath a progeny of weaklings, and that a whirlwind wherein is fire should then smite it, so that it is all consumed! In this wise Allah expoundeth unto you the signs that haply ye may ponder.

# 274

O O Ye who believe expend out of the good things which! ye have earned and out of that which We have brought forth for you from the earth, and seek not the vile thereof to expend, where as ye yourselves would not accept such except ye connived thereat. And know that Allah Self-Sufficient, Praiseworthy.

# 275

Satan promiseth You poverty and commandeth you to niggardliness, whereas Allah promiseth you forgiveness from Himself and abundance; and Allah is Bounteous, Knowing.

# 276

He vouchsafeth wisdom unto whomsoever He will, and whosoever is vouchsafed wisdom is of a surety vouchsafed abundant good, and none receiveth admonition Save men of understanding.

# 277

And whatever expense ye expend or whatever VOW ye vow, verily Allah knoweth it: and for the wrong doers there will be no helpers.

# 278

If ye disclose the alms, even so it is well, and if ye hide them and give them unto the poor, it will be better for you and He will expiate some of your misdeeds Allah is of that which ye work Aware.

# 279

Not on thee is their guidance, but Allah guideth whomsoever He listeth. And whatsoever ye expend of good it is for your own souls, and ye expend not save to seek Allah's countenance and whatsoever ye expend of good shall be repaid to you, and ye shall not be wronged.

# 280

Alms are for the poor who are restricted in the way of Allah, disabled from going about in the land. The (unknowing taketh them for the affluent because of their modesty thou I wouldst recognise them by their appearance: they ask not of men with importunity. And whatsoever ye shall expend of good, verily Allah is thereof Knower

# 281

Those who expend their riches by night and by day, in secret and openly, theirs shall be their hire with their Lord; no fear shall come on them, nor shall they grieve.

# 282

Those who devour Usury Shall not be able to stand except standeth one whom the Satan hath confounded with his touch. That shall be because they say: bargaining is but as usury whereas Allah hath allowed bargaining and hath forbidden usury. Wherefore Unto whomsoever an exhortation cometh from his Lord, and he desisteth, his is that which is past, and his affair is with Allah. And whosoever returnoth --such shall be the fellows of the Fire, therein they shall be abiders.

# 283

Allah obliterateth usury, and increaseth the alms. And Allah loveth not any ingrate sinner.

# 284

Verily those who believe and work righteous works and establish prayer and give the Poor-rate, theirs shall be their hire with their Lord: no fear shall come on them nor shall they grieve.

# 285

O O Ye who believe: fear Allah and leave that which remainoth of usury if ye are believers.

# 286

But if ye will do it not, then be apprised of war from Allah and His apostle. And if ye repent, then yours shall be your capital sums; ye shall neither wrong nor be wronged.

# 287

And if one be in difficulties, then let there be and deferment until easiness. But if ye forego, it were better for you if ye knew.

# 288

And fear the Day whereon ye shall be brought back unto Allah, then shall each sour be repaid, in full that which he hath earned, and they shall not be wronged.

# 289

O ye who believe! when ye deal, one with anot her, in lending for a term named, write it down, and let a scribe write it down justly between you, and let not the scribe refuse to write according as Allah hath taught him. Let him write them, and let him who oweth dictate, and let him fear Allah, his Lord, and diminish not aught thereof. But if he who oweth be witless or infirm or unable himself to dictate, then let his guardian dictate justly. And call to witness two witnesses of your men, but if both be not men, then a man and two women of those ye agree upon as witnesses, so that if one of the twain err, the one thereof shall remind the other: and let not the witnesses refuse When they are called on And be not Weary of writing it down, be it small or big, with the term thereof. This is the most equitable in the sight of Allah and the most confirmatory of testimony and nearest that ye may not doubt, except when it be a ready merchandise that ye circulate between you, for then there Shall be no blame on you if ye write it not down. And call witnesses when ye bargain With one anot her; and let not the scribe eome to harm nor the witness; and if ye do, verily it will be wickedness in you. Fear Allah; and Allah teacheth you Knower; and Allah is of everything Knower.

# 290

And if ye be on a journey and ye find not a scribe, then let there be a pledge taken; then, if one of you entrusteth the other, let the one is trusted discharge his trust, and let him fear Allah, his Lord. And hide not testimony whosoever hideth and it, his heart verily is Knower. Allah is of that which ye work

# 291

Allah's is whatsoever is in the heavens and Whatsoever is in the earth, and whether ye disclose that which is in your soul or conceal it, Allah will reckon with you therefor, then He will forgive whomsoever He will, and torment whomsoever He will, And Allah is over everything Potent.

# 292

The apostle believeth in that which is sent down Unto him from his Lord, and so do the believers. Each one believeth in Allah and His angels and His Books and His apostles, saying: we differentiate not between any of His apostles. And they say: we hearken and obey; Thy forgiveness, Our Lord! and Unto Thee is the return!

# 293

Allah tasketh not a soul except according to its capacity. For it shall be the good it earnoth, and against it the evil it earnoth. Our Lord! reckon with not if we forget or er. Our Lord! ray not on us a burthen like unto that which Thou laidest on those before us, Our Lord! impose not on US that for which we have not strength. And Pardon us; forgive US; and have mercy on us; Thou art our Patron: so make US triumph over the disbelieving people!

# 294

Alif, Lam, Mim,

# 295

Allah There is no god but He, the Living, the Sustainer.

# 296

He hath revealed unto thee the Book with truth confirming that which went before it; and He sent down the Taurat and Injil.

# 297

Aforetime, for a guidance unto the people, and sent down the criterion. Verily those who disbelieve in the signs of Allah Unto them shall be torment severe. And Allah is Mighty, Lord of Retribution.

# 298

Verily Allah aught is concealed from Him in the earth or in the

# 299

He it is Who fashionoth You in the Wombs as He will: there is no god but He, the Mighty, the Wise.

# 300

He it is who hath sent down unto thee the Book, wherein some verses are firmly constructed they are the mother of the Book: and others consimilar. But those in whose hearts is and deviation follow that which is consimilar therein, seeking discord and seeking to misinterpret the same whereas none knoweth the interpretation thereof a save Allah. And the firmly- grounded in knowledge Say: we believe therein, the whole is from our Lord. And none receiveth admonition save men of understanding.

# 301

Our Lord Suffer not our hearts to deviate after that Thou hast guided US, and bestow from Thine presence mercy. Verily Thou! Thou art the Bestower!

# 302

Our Lord! verily Thou art the Assembler of mankind for a Day whereof there is no doubt. Verily Allah faileth not the tryst.

# 303

Verily those who disbelieve-neither their riches nor their offspring shall avail them aught with Allah. and these! they shall be the fuel of the Fire.

# 304

After the wont of the people of Fir'awn and those before them. They belied Our signs, wherefore Allah laid hold of them for their sins. And Allah is Severe in chastising.

# 305

Say thou unto those who disbelieve: anon shall ye be overcome, and gathered unto Hell--an evil couch!

# 306

Of a surety there hath been unto you a sign, the two hosts that met, one host fighting in the way of Allah, and the other disbelieving, beholding themselves, with their own eyes, twice as many as they. And Allah aideth with His succour whomsoever He will. Verily herein is a lesson for men of insight.

# 307

Fair-seeming is made unto men the love of pleasurable things from women and children and talents heaped-up of gold and silver and horses branded up and cattle and tilth. All that is the enjoyment of the life of the World, and Allah! with Him is the best resort.

# 308

Say thou! Shall I declare unto you that which is better than these For those who fear Allah are Gardens with their Lord, there under rivers flow, wherein they shall be abiders, and spouses purified, and pleasure from Allah. And Allah is Beholder of His bondsmen

# 309

Those who say our Lord! verify we! we have believed, wherefore forgive us our sins, and protect us from the torment of the Fire.

# 310

The patient ones and the truthful ones and the devout ones and the expanders and the praying ones at early dawn for forgiveness.

# 311

Allah beareth witness - and also the angles and those endued with knowledge that there is no god but He, the Maintainer of equity: there is no god but He, the Mighty, the Wise.

# 312

Verily the religion with Allah is Islam and those Who Were vouchsafed the Book differed Not save after the knowledge had come unto them, out of spite among themselves. And whosoever disbelieveth in the revelations of Allah, then verily Allah swift at reckoning.

# 313

Wherefore if they contend with thee, say thou: have surrendered myself unto Allah and he who followeth me. And say thou unto those who have been vouchsafed the Book and unto the illiterates; do you (also) accept Islam? Then if they accept Islam, they are of a surety guided; and if they turn away, then upon thee is only the preaching, and Allah is Beholder of His bondsmen.

# 314

Verily those who disbelieve in the revelations of Allah and slay the prophets without justice and slay those among men who command equity thou unto them a torment afflictive.

# 315

These are they whose works have Come to naught in the world and the Hereafter, nor have they helpers.

# 316

Hast thou not observed those vouchsafed a portion of the Book called to the Book of Allah that it may judge between them? Then a party of them turn away and they are backsliders

# 317

That is because they say, the Fire shall touch us not save for a few days numbered. And there had deluded them in their religion that which they have been fabricating.

# 318

How shall it be then, when we shall gather them on the Day whereof there is no doubt, and every soul shall be repaid in full that which it hath earned, and they shall not be wronged.

# 319

Say thou: O Allah! sovereign of the dominion: Thou givest dominion unto whomsoever Thou wilt, and Thou takest away dominion from whomsoever Thou wilt; Thou honourest whomsoever Thou wilt, and Thou abasest whomsoever Thou wilt; and in Thine hand is good. And verily Thou art over every thing Potent.

# 320

Thou plungest night into day and Thou plungest day into night, and Thou bringest forth the living from the lifeless, and Thou bringest forth the lifeless from the living; and Thou providest for whomsoever Thou wilt without reckoning.

# 321

Let not the believers take unto themselves the infidels as friends, beside the believers: and whosoever doth that, then he is not in respect of Allah in aught, unless indeed ye fear from them a danger. And Allah maketh ye beware of Himself; and unto Allah is the last wending.

# 322

Say thou: Whether ye conceal that which is in your breasts or disclose it, Allah knoweth it, and He knoweth that which is in the heavens and in the earth; and Allah is over everything Potent.

# 323

The Day whereon each soul shall find presented whatsoever it hath worked of good and whatsoever it hath worked of evil, it would fain that there were betwixt it and that Day a wide space. And Allah maketh you beware of Himself: Allah is Tender unto His bondsmen.

# 324

Say thou: if ye, are wont to love Allah, then follow me, and Allah shall rove you and forgive you your sins; and Allah is Forgiving, Merciful.

# 325

Say thou: obey Allah and the apostle if thereafter they turn away. then verily Allah loveth not the infidels.

# 326

Verily did Allah choose Adam and Nuh and the house of lbrahim and the house of 'lmran out of the worlds

# 327

Progeny, one of the other, and Allah is Hearing, Knowing.

# 328

Recall what time the wife of 'lmran said my Lord verily have vowed unto Thee that which is in my belly to be dedicated; accept Thou then of me. Verily Thou! Thou art the Hearer, the Knower.

# 329

Then when she brought her forth, she said: my Lord verily have brought forth a female - and Allah knew best that which she had brought forth, - and the male is not as the female, and verily have named her Maryam, and verily seek refuge for her and her progeny with Thee from the Satan the accursed.

# 330

Then her Lord accepted her with goodly acceptance and made her grow up with a goodly growth, and He made Zakariyya take care of her. So oft as Zakariyya entered the apartment to see her, he found provision by her. He said: O Maryam! whence hast thou this! She said this is from before Allah. Verily Allah provideth for whomsoever He will without reckoning.

# 331

Forthwith Zakariyya prayed unto his Lord my Lord bestow on me from Thine presence a goodly offspring; verily Thou! Thou art the Hearer of prayer.

# 332

Then the angels called unto him even while he stood Praying in the apartment: verily Allah announceth unto thee Yahya confessing to a word from Allah, and a leader, and a chaste and a prophet of the righteous one.

# 333

He said: my Lord! in what wise shall there be unto me a youth whereas age hath overtaken me and my wife is barren. Allah said: even so: Allah doeth whatsoever He listeth.

# 334

He said: my Lord! appoint unto me a sign. Allah said: thy sign is that thou shalt not speak unto mankind for three days save by beckoning; and remember thy Lord much and hallow Him in the evening and morning.

# 335

And recall what time the angels said: O Maryam! verily Allah chose thee and purified thee and chose thee above the women of the worlds.

# 336

Maryam! be devout unto thy Lord, prostrate thyself, and bow down with them that bow down.

# 337

This is of the tidings of things hidden which We reveal unto thee and thou wast not with them when they cast their reeds as to which of them should take care of Maryam, nor wast thou with them when they disputed.

# 338

Recall what time the angels said: Maryam! verily Allah announceth unto thee a word from Him: his name Shall be the Masih, Isa, son of Maryam, illustrious in the world and the Hereafter and one of those brought nigh.

# 339

And he shall speak unto mankind from the cradle and in maturity; and be one of the righteous.

# 340

She said: my Lord! in what wise shall there be unto me a son whereas no human being hath touched me. Allah said: even so. Allah createth whatsoever He will, When He hath decreed a thing, He only saith to it: Be, and it becometh;

# 341

And He shall teach him the Book and wisdom and the Taurat and the Injil:

# 342

And an apostle Unto the children of Israi'l with this message: verily have come unto you with a sign from your Lord, verily I form for you out of clay as though the likeness of a bird and then I breathe thereunto, and a bird it becometh by Allah's command. And heal the blind from birth and the leprous and quicken the dead by Allah's command. And I declare unto you that which ye have eaten and that which ye have stored in your houses. Verily herein is a sign for you if ye are believers.

# 343

And I come confessing to the Taurat that was before me, and to allow unto you some of that which was forbidden unto you. So And I have come unto you with a sign from your Lord wherefore fear Allah and obey me.

# 344

Verily Allah is my Lord; and your Lord, wherefore worship Him; this is the straight path.

# 345

Then when 'Isa perceived in them infidelity, he said: who will be my helpers unto Allah! The disciples said; we are helpers of Allah; we believe in Allah and bear thou witness that verily we are Muslims.

# 346

Our Lord! we believe in that which Thou hast sent down, and, follow the apostle; write us up wherefore with the witnesses.

# 347

And they plotted, and Allah plotted, and Allah is the Best of plotters.

# 348

Recall what time Allah said: O 'Isa! verily I shall make thee die, and am lifting thee to myself and am purifying thee from those who disbelieve, and shall place those who follow thee above those who disbelieve until the Day of Resurrection; thereafter unto Me shall be the return of you all, then I shall judge between you of that wherein ye were wont to differ.

# 349

Then as for those who disbelieved I shall torment them with a severe torment in the world and the Hereafter, nor shall have they any helpers.

# 350

And as for those who believed and worked righteous works, He shall repay them their hires in full, and Allah loveth not the wrong-doers.

# 351

This which we recite unto thee is of the signs and of the wise admonition.

# 352

Verily the likeness of 'lsa with Allah is as the likeness of Adam: him He created out of dust, thereafter He said unto him: Be, and lo! he becometh.

# 353

This is the truth from thy Lord, wherefore be thou not of those who dubitate.

# 354

Wherefore those who contend with thee therein after that which hath come unto thee of the knowledge - say thou: come! let us call our sons and your sons, and our women and your women, and ourselves and yourselves, then let us humbly pray, and invoke the curse of Allah upon the liars.

# 355

Verily this! it is the true recital; and God there is none save Allah, and verily Allah! He is the Mighty, the Wise.

# 356

But if they turn away, then Allah is Knower of the corrupters.

# 357

Say thou: O people of the Book! come to a word common between us and between you; that we shall worship none save Allah's and that we shall not associate aught with Him, and that none of you shall take others as Lords beside Allah. Then if they turn away, say: bear witness that verily we are Muslims.

# 358

O people of the Book! wherefore contend ye concerning Ibrahim, whereas the Taurat and the Injil were not sent down save after him! Will ye not then under stand?

# 359

Ah! ye are those who fell to contending respecting that whereof ye had some knowledge, wherefore then should ye contend respecting that whereof ye have no knowledge! And Allah knoweth, and ye know not.

# 360

Ibrahim was not a Jew, nor a Nazarene, but he was an upright Muslim, nor was he of the associators.

# 361

Verily the nearest of mankind to Ibrahim, surely those who followed him, and this prophet, and those who believe; and Allah is the Patron of the believers.

# 362

Pain would a party of the people of the Book lead you astray, and none they lead astray save themselves, and they perceive not.

# 363

O people of the Book! wherefore disbelieve ye in the revelations of Allah whereas ye bear witness?

# 364

O people of the Book! wherefore confound ye the truth with falsehood, and hide the truths While ye know?

# 365

And a Party of the people of the Book say: believe in that which hath been sent down unto those who have believed, at the break of day, and disbelieve at the close thereof, haply they may turn away;

# 366

And believe not save one who followeth your religion. Say thou: verily the guidance of Allah - that is the guidance. Envy ye that any one should be vouchsafed the like of that which was vouchsafed unto you or fear ye that those others may overcome you in Contention before your Lord! Say thou: verily the grace is in the hand of Allah He vouchsafeth it unto whomsoever He will; and Allah is Bounteous, Knowing.

# 367

He singleth out for His mercy Whomsoever He will; And Allah is the Owner of mighty Grace.

# 368

And of the people of the Book is he whom if thou trustest with a talent, he will restore it unto thee, and among them is he whom if thou trustest with a dinar, he will not restore it unto thee except thou art ever standing over him that is because they say there is in the matter of the illiterates no call on us. And they forge a lie against Allah while they know.

# 369

Aye whosoever keepeth his covenant and feareth Allah--then verily Allah loveth the God-fearing.

# 370

Verily those who barter Allah's covenant and their oaths at a Small price- no portion is theirs in the Hereafter; nor shall Allah speak unto them or look at them on the Day of Resurrection, nor shall He cleanse them, and theirs shall be a torment afflictive.

# 371

And verily among them, are a party who pervert the Book with their tongues, that ye might deem it of the Book whereas it is not of the Book. And they say it is from God; whereas it is not from Allah, and they forge a lie against Allah while they know.

# 372

It is not Possible for a human being unto whom Allah hath vouchsafed the Book and Wisdom and prophethood that he should thereafter say unto men: be ye worshippers of me, beside Allah; but be ye faithful servants of the Lord, seeing that ye are wont to teach the Books and seeing that ye are wont to exercise yourselves therein.

# 373

And he would not command you that ye should take the angels and the prophets for lords. Would he command you to infidelity after ye are become Muslims?

# 374

And recall what time Allah took a bond from the prophets saying whatever I vouchsafed unto you of Book and Wisdom, end, thereafter there cometh unto you an apostle confessing to that which is with you, ye shall surely believe in him and succour him. He said: assent ye, and take ye My burthen thereunto They said: we assent. He said: then bear Witness, and I, with you among the witnesses.

# 375

Wherefore whosoever shall turn away thereafter -those then! they are the transgressors.

# 376

Seek they then other than the religion of Allah Whereas unto Him hath submitted whosoever is in the heavens and the earth willingly or unwillingly, and unto Him shall they all be returned.

# 377

Say thou: we believe in Allah and in that which is sent down unto us, and that which was sent down unto Ibrahim and Isma'il and Is-haq and Ya'qub and the tribes, and that which was vouchsafed unto Musa and 'Isa and other prophets from their Lord: we differentiate not between any of them, and unto Him we are submistive.

# 378

And whosoever will seek a religion other than Islam, it shall not be accepted of Him, and he shall be of the losers in the Hereafter.

# 379

How shall Allah guide a people who disbelieved after their belief and after they bore witness that the apostle was true and after evidences had come unto them! And Allah guideth not a wrong-doing people.

# 380

These! their meed is that on them shall be the curse of Allah and of angles and of mankind, all;

# 381

Abiders therein, their torment shall not be lightened nor shall they be respited.

# 382

Save such shall repent thereafter and amend; verily Allah is Forgiving, Merciful.

# 383

Verily those who disbelieve after they have believed and thereafter wax in infidelity, their- repentance shall by no means be accepted. These! they are the straying ones.

# 384

Verily those who disbelieve and die while they are infidels, not an earthful of gold shall be accepted from any such, were he to offer it as a ransom. These! theirs shall be a torment afflictive, nor shall they have any helpers.

# 385

O Ye shall not attain unto virtue until ye expend of that which ye love; and whatsoever ye expend, verily Allah Is thereof Knower.

# 386

Every foods was allowable unto the Children of Isra'il, save that which Isra'il had forbidden unto himself, ere the Taurat was revealed. Say thou: bring ye then the Taurat and recite it, if ye say sooth.

# 387

Then whosoever fabricateth after this, lie against Allah - these! they are the wrong-doers.

# 388

Say thou: Allah hath spoken the truth; follow therefore the faith of Ibrahim the upright; and he was not of the associators.

# 389

Verily the first House set apart unto mankind was that at Bakka, blest, and a guidance unto the worlds.

# 390

Therein are signs manifest, the station of Ibrahim. And whosoever entereth it shall be secure. And incumbent on mankind is pilgrimage to the House for that good-will of Allah: on him who is able to find a way thereunto. And whosoever disbelieveth, then verily Allah is Independent of the worlds.

# 391

Say thou: O People of the Book! wherefore disbelieve ye in the revelations of Allah, whereas Allah is witness of that which ye work!

# 392

Say thou: O people of the Book! wherefore turn ye aside from the way of Allah those who believe, seeking for it crookedness, while ye are witnesses! And Allah is not neglectful of that which ye work.

# 393

O Ye who believe! were ye to obey any party amongst those that have been vouchsafed the Book, they would, after your having believed, render you Infidels.

# 394

How can you disbelieve while unto you are recited the revelations of Allah, and in your midst is His apostle! And whosoever holdeth fast to Allah, he is of a surety guided unto a straight path.

# 395

O Ye who believe! fear Allah with fear due to Him, and die not except ye be Muslims.

# 396

And hold ye fast, all of you, to the cord of Allah, so and separate not. And remember Allah's favour unto you in that ye were enemies and He joined your hearts together, so ye became by His favour brethren; and ye were on the brink of an abyss of the Fire and He rescued you therefrom. In this wise Allah expoundeth unto you His revelations that haply ye may remain guided.

# 397

And let there be of you a community calling others to good and commanding that which is reputable and prohibiting that which is disreputable. And these they are the blissful.

# 398

And be not like unto those who separated and differed among themselves after there had come unto them evidences. These! for them shall be a torment mighty.

# 399

On a day whereon faces become whitened and faces become blackened. Then as for those whose faces shall have become blackened: disbelieved ye after your profession of belief! taste the torment for that ye have been disbelieving.

# 400

And as for those whose faces shall have become whitened-- they shall be in Allah's mercy; therein they shall be abiders.

# 401

These are revelations of Allah; We rehearse them unto thee with truth, and Allah intendeth not wrong unto the worlds.

# 402

Allah's is whatsoever is in the heavens and in the earth; and unto Allah shall be committed all affairs.

# 403

O Ye are the best community sent forth unto mankind; ye command that which is reputable and ye prevent that which is disreputable. and ye believe in Allah If the people of the Book believe, surely it were better for them. Of them are believers, and most of them are transgressors.

# 404

They shall not be able to harm you save with small hurt, and if they fight you, they shall turn upon you their backs; then they shall be succoured not.

# 405

Stuck upon them is abjection wheresoever they may be come upon, except in a compact with Allah and a compact with men; and they drew upon themselves indignation from Allah; and stuck upon them is poverty. That is because they have been disbelieving in the signs of Allah, and slaying the prophets without justice. That is because they disobeyed and have been trespassing.

# 406

Not are they all alike. Of the people of the Book there are a community steadfast, reciting the revelations of Allah in the hours of night while they prostrate themselves.

# 407

And they believe in Allah and the Last Day and command that which is reputable and prohibit that which is disreputable, and vie with each other to virtues. And these are of the righteous.

# 408

And whatsoever they do of virtue shall not be denied. And Allah is Knower of the God-fearing.

# 409

Verily those who disbelieve, neither their riches nor their progeny shall avail them aught against Allah. And these are the fellows of the Fire; thereinto they shall be abiders.

# 410

The likeness of that which they expend in this life of the world is as the likeness of a wind wherein is intense cold, it befalleth the tilth of a people who have wronged themselves, and destroyeth it. Allah wronged them not, but themselves they wrong.

# 411

O Ye who believe! take not for an intimate anyone besides yourselves; they shall not be remiss in doing you mischief. Fain would they that which distresseth you. Surely their malice hath shewn itself by their mouths, and that which their breasts conceal is greater still. Surely We have expounded unto you the signs, if ye will but reflect.

# 412

Lo! it is you who love them whereas they love you not, and you believe in the Book, all of it. When they meet you, they say: we believe. And when they are alone, they bite their fingertips at you in rage. Say thou: die in your rage. Verily Allah is Knower of that which is in the breasts.

# 413

If there happenoth unto you any good it grieveth them, and if there happenoth unto you an ill, they rejoice thereat. And if ye remain persevering and God-fearing their guile shall not harm you at all. Verily Allah is of that which they work Encompasser.

# 414

And recall what time thou settedst forth from thy household early to settle believers in positions for the fight. And Allah is Hearing, Knowing.

# 415

Recall what time two sections of you bethought that they should flag whereas Allah was the Patron of the twain. In Allah, then, let the believers trust.

# 416

And assuredly Allah had succoured you at Badr While ye were humble. Wherefore fear Allah that haply ye may return thanks.

# 417

And Recall what time thou saidst to the believers: sufficieth it not unto that your lord should reinforce you with three thousand angels sent down.

# 418

O Yea! if ye but remain persevering and God-fearing, and they should come upon you in this rush of theirs, your Lord shall reinforce you with five thousand angels marked.

# 419

And this Allah made not except as a joyful enunciation unto you, and that thereby your hearts might be set at rest--and no succour is there but from before Allah, the Mighty, the Wise.

# 420

That He may cut: off a portion of those who disbelieve, or abase them so that they may go back disappointed.

# 421

Not with thee is aught of the affair: He shall either relent toward them or torment them, for verily they are wrong-doers.

# 422

Allah's is whatsoever is in the heavens and whatsoever is in the earth. He forgiveth whomsoever He listeth, and tormenteth whomsoever He listeth. And Allah is Forgiving, Merciful.

# 423

O Ye who believe! devour not multiplied manifold; and fear usury, Allah, haply ye may fare well.

# 424

And beware of the Fire gotten ready for the infidels.

# 425

And obey Allah and the apostle, haply ye may be shewn mercy.

# 426

And vie with each other in hastening to obtain forgiveness from your Lord and toward the Garden whereof the width equalleth the heavens and the earth, gotten ready for the God- fearing

# 427

Those who expend in weal and woe, and the repressors of rage and the pardoners of men; and Allah loveth the doers of good.

# 428

And those, who, when they have done an ill-deed or wronged themselves, remember Allah and ask forgiveness of their sins - and who forgiveth sins save Allah! Is --and persist not in that which they have done, while they know.

# 429

Those! their meed is forgiveness from their Lord and Gardens whereunder rivers flow; they shall be abiders therein. Excellent is the hire of the workers!

# 430

Dispensations have gone forth before you go about then on the earth, and behold what wise hath been the end of the beliers!

# 431

This in exposition unto mankind and a guidance and an admonition unto the God-fearing.

# 432

And faint not, nor grieve; ye shall overcome, if ye are believers.

# 433

If there hath befallen you a sore, a sore like thereunto hath already befallen that people. These are the haps that We change about among man kind, that Allah may know those who believe and may take martyrs from among you and Allah loveth not the wrong doers.

# 434

And that Allah may purge those who believe and destroy the infidels.

# 435

Or, deem ye that ye shall enter the Garden while yet Allah hath not known those of you who have striven hard nor yet known the steadfast!

# 436

And assuredly ye were wont to long for death ere ye had met it. Now ye are beholding it even while ye are looking on.

# 437

And Muhammad is naught but an apostle; apostles have surely passed away before him. Will ye then, if he dieth or be slain, turn round on your heels! And whosoever turnoth round on his heels, hurteth not Allah at all. And anon shall Allah recompense the grateful.

# 438

It is not Possible for any person to die except by Allah's command at a term recorded. And whosoever desireth the reward of the world, We vouchsafe unto him thereof. and whosoever desireth the reward of the Hereafter, We vouchsafe unto him thereof. And anon will we recompense the grateful.

# 439

And many a prophet hath fought With a number of godly men beside him. They fainted not for aught that befell them in the way of Allah, nor they weakened, nor they humbled themselves; and Allah loveth the steadfast.

# 440

And their speech was naught but that they said: our Lord! forgive us our sins and our extravagance in our affairs, and make our foothold firm, and make us triumph over the disbelieving people.

# 441

Wherefore Allah vouchsafed unto them the reward of the World, and the excellent reward of the Hereafter. And Allah loveth the well-doer.

# 442

O O Ye who believe! if ye obey those who disbelieve, they will send you back on your heels, and ye will turn back losers.

# 443

But: Allah is your Friend, and He is the Best of helpers.

# 444

Anon shall We cast a terror into the hearts of those who disbelieve, for they have associated with Allah that for which Allah hath sent down no warranty, and their resort is the Fire: vile is the abode of the wrong-doers!

# 445

And Allah had assuredly made good His promise unto you when ye were extirpating them by His leave, until when ye flagged and ye disagreed about the command and ye disobeyed after He had shewn you that for which ye longed. Of you some desired the World and of you some desired the Hereafter, wherefore He turned you away from them that he might prove; and of a surety He hath pardoned you And Allah is Gracious unto the believers.

# 446

And recall what time ye were running off and would not look back on any one, albeit the apostle In your rear was calling unto you. Wherefore He caused sorrow to overtake you for sorrow. that ye might not grieve for that which ye might lose nor for that which might befall you. And Allah is Aware of that which ye Work.

# 447

Then, after sorrow, He sent down unto you a security-- slumber coming over a section of you; While anot her section, concerned about themselves, bethought of Allah unjustly: the thought of paganism. They said: have we aught at all of the affair? Say thou: the affair is wholly Allah's. They hide within themselves that which they disclose not unto thee, saying: had we aught of the affair, we would not have been slain here. Say thou: had ye stayed in your houses, even then those decreed to be slain would surely have gone forth to their places of slaughter; and this happened in order that he might prove that which was in your breasts, and purge that which was in your hearts; and Allah is Knower of that which is in the breasts.

# 448

As for those of you who turned back on the day the two hosts met, it was the Satan who made them slip because of something they had earned; and of a surety Allah hath pardoned them. Verily, Allah is Forgiving, Forbearing.

# 449

O O Ye who believe! be not like unto those who disbelieve and say of their brethren when they journey in the land or go to religious war: had they been with, they had not died nor had they been slain; this is in order that Allah may cause an anguish in their hearts. And it is Allah who maketh alive and causeth to die, and Allah is of that which ye work Beholder.

# 450

Verily if ye be slain in the way of Allah or die, forgiveness from Allah and mercy are surely better than that which they amass.

# 451

And whether ye die or be slain, assuredly unto Allah shall ye be gathered.

# 452

It was then of the mercy of Allah that thou hast been gentle with them; and wert thou rough, hardhearted, they had surely dispersed from around thee. So pardon them thou, and ask thou forgiveness for them and take thou counsel with them in the affair, and when thou hast resolved, put thy trust in Allah. Verily Allah loveth the trustful.

# 453

If Allah succoureth you, there is none that can overcome you; if He abandon you, who is there that can succour you after Him? And in Allah let the believers trust.

# 454

It is not the part of a prophet to hide anything away: whosoever hideth anything away, he shall bring forth on the Day of Resurrection that which he had hidden away; then shall each one be repaid in full that which he hath earned, and they shall not be wronged.

# 455

Is then one who followeth the pleasure of Allah like unto him who hath settled under the displeasure of Allah? His resort is Hell, and ill is that destination

# 456

Of diverse degrees shall be they with Allah, and Allah is Beholder of that which they work.

# 457

Assuredly Allah hath conferred a benefit on the believers when He raised up unto them an apostle from amongst themselves, he rehearseth unto them His revelations and purifieth them and teacheth them the Book and wisdom, and afore they were in an error manifest.

# 458

Is its that when a reverse hath befallen you, albeit ye had inflicted twice as much, ye say: whence is this? Say thou: it is but from yourselves verily Allah is over everything potent.

# 459

And that which befell you on the day whereon the two hosts met was by Allah's leave, and that he might know the believers.

# 460

And that he might know those who played the hypocrite. And it was said unto them: come ye, fight in the way of Allah or defend. They said: if we knew it was to be a fair fight We would surely have followed you. Nearer were they on that day to infidelity than to belief. They say with their mouths that which is not in their hearts and Allah knoweth best that which they conceal.

# 461

They say of their brethren, while they themselves staid: had they obeyed us they had not been slain. Say thou: then repel death from yourselves if ye say sooth.

# 462

And reckon not thou those slain in the way of Allah to be dead. Nay, they are alive, and with their Lord, and provided for.

# 463

Exulting in that which Allah hath vouchsafed them of His grace. And they rejoice in those who have not yet joined them from behind them, in the thought that unto them no fear shall come, nor shall they grieve.

# 464

They rejoice at the favour of Allah and His grace, and that verily Allah wasteth not the hire of the believers.

# 465

Those who answered to the call of Allah and the apostle after the wound that befell them --for those who did well among them and feared God shall be a mighty hire-

# 466

Those unto whom when certain men said: verily the people have mustered strong against you, so be afraid of them, it only increased them in belief, and they said: sufficient unto us is Allah, and an excellent Trustee is He!

# 467

They then returned with a favour from Allah and His grace: no evil touched them: and they followed Allah's pleasure and Allah is Owner of mighty grace.

# 468

It is only that the Satan frighteth you of his friends, wherefore fear them not, but fear Me, if ye are believers.

# 469

And let not those grieve thee who hasten toward infidelity; verily they shall not harm Allah at all. Allah desireth not to provide for them a portion in the Hereafter; and theirs shall be a torment mighty.

# 470

Verily those who have purchased infidelity for belief shall not hurt Allah at all, and theirs shall be a torment afflictive.

# 471

And let not those who disbelieve deem that We respite them for their good: We respite them only that they may increase in sin; and theirs shall be a torment ignominious.

# 472

Allah is not one to leave the believers in the state wherein ye are until He hath discriminated the impure from the pure. And Allah is not one to acquaint you with the Unseen, but Allah chooseth him whomsoever He willeth, of His apostles. Believe wherefore in Allah and His apostles; and if ye believe and fear, yours shall be a mighty hire.

# 473

And let not those who stint with that which Allah hath vouchsafed them in His grace deem that this is good for them: nay! it is bad for them; anon shall that wherewith they stint be hung round their necks on the Day of Judgement. And Allah's is the heritage of the heavens and the earth; and Allah is of that which ye work Aware.

# 474

Assuredly Allah hath heard the saying of those who say: verily Allah is poor and we are rich. Surely We shall write down that which they have said and their slaying of the prophets with- out justice, and We shall say taste the torment of the burning.

# 475

That is for that which your hands have sent on afore, for verily Allah is not a wronger of His bondmen.

# 476

There are those who say. verily God hath covenanted with us that we should believe not in an apostle until he bring unto us a sacrifice which a fire shall devour. Say thou: surety there came unto you apostles before me with evidences and with that which ye speak of, wherefore then did ye slay them, if ye say sooth?

# 477

If then they belie thee, even so were belied apostles before thee who came with evidences and scriptures, and the luminous Book.

# 478

Every soul Shall taste of death and only on the Day of Resurrection ye will be repaid your hire in full. Then whosoever shall be removed far away from the Fire and made to enter into the Garden, he indeed hath achieved the goal; and the life of the world is naught but an illusory enjoyment.

# 479

O Ye shall surely be proven in your riches and in your lives; and will surely bear much hurt from those who were vouchsafed the Book before you and from those who associate gods, and if ye endure and fear, then verily that is of the commandments determined.

# 480

And recall what time Allah took a bond from those who were vouchsafed the Book: ye shall surely expound it to the people and ye shall hide it not; whereafter they cast it behind their backs, and bartered it for a small price. Vile is that wherewith they have bartered.

# 481

Bethink not thou that those who exult in that which they have brought and love to De praised for that which they have not done, - bethink not thou that they shall be in security from the torment! And theirs shall be a torment afflictive.

# 482

Allah's is the dominion of the heavens and the earth. and Allah is over everything Potent.

# 483

Verily in the creation of the heavens and the earth and in the alter nation of the night and the day are signs Unto the men of understanding.

# 484

Who remember- Allah Standing and sitting and lying on their sides, and reflect on the creation of the heavens and the earth: our Lord Thou createdest not all this in vain. Hallowed be Thou! Save us, Thou, from the torment of the Fire!

# 485

Our Lord verily whomsoever Thou makest to enter into the Fire, him Thou hast surely humiliated and for the wrong-doers there shall be no helpers.

# 486

Our Lord verily we heard a caller calling to belief: believe in your Lord, wherefore we have come to believe. Our Lord forgive us our sins, and expiate from us our misdeeds, and let us die along with the pious.

# 487

Our Lord! vouchsafe unto us that which Thou hast promised us by Thine apostles, and humiliate us not on the Day of Resurrection. Verily Thou failest not the tryst.

# 488

Then their Lord hearkened unto them saying: I let not the work of a worker amongst you to waste, man or woman, one of you from the other. So those who emigrated and were driven forth from their homes and persecuted in My cause, and who fought and were slain, surely I shall expiate from them their misdeeds and surely I shall make them enter Gardens whereunder rivers flow; a reward from before Allah! And Allah! with Him is the excellent reward.

# 489

Let not beguile thee the moving to and fro about of those who disbelieve, in the cities

# 490

A brief enjoyment, and then Hell shall be their abode; ill is the resort!

# 491

But as to those who fear their Lord, theirs shall be Gardens whereunder rivers flow; they shall be abiders therein: an entertainment from before their Lord; and that which is with Allah it still better for the pious.

# 492

And verily of the people of the Book there are some who believe in Allah and in that which hath been sent down unto you and that which hath been sent down unto them, humbling themselves before Allah, and barter not the revelations of Allah for a small price, these they shall have their hire with Allah. Verily Allah swift in reckoning.

# 493

O Ye who believe! persevere, and excel in perseverance and be ever ready, and fear Allah that haply ye may thrive.

# 494

O ye mankind! fear your Lord; Who created you of a single soul and He created the reef the spouse thereof, and of the twain He spread abroad men manifold and women. And fear Allah by Whom ye importune one anot her, and the wombs. Verily Allah is ever over you a Watcher.

# 495

And give unto the orphans their substance, and substitute not the bad for the good; and devour not their substance by adding it to your substance; verily that is a great crime.

# 496

And if ye apprehend that ye may not deal justly with the orphan girls, then marry such as please you, of other Women, by twos and threes or fours, but if ye apprehend that ye shall not act justly, then marry one only, or that which your right hand own that Will be more fit, that ye may swerve not. their

# 497

And give unto women dowries as a gift, and if of themselves they give up aught thereof unto you, then eat it in pleasure and profit.

# 498

And give not unto the weak-witted the substance which Allah made a stay for you, but feed them there out, Sand clothe them, and say unto them a reputable saying.

# 499

And examine the orphans until they attain the age of wedlock, then if ye perceive in them and discretion, hand over unto them their substance, and consume it not extravagantly or hastily for fear that they may grow. And whosoever is rich, let him abstain, and whosoever is needy let him take thereof reputably. And when ye hand over their substance unto them, call in witnesses in their presence, and sufficeth Allah as a Reckoner.

# 500

Unto males shall be a portion of that which their parents and others near of kin may leave; and unto females shall be a portion of that which their parents and other near of kin may leave, whether it be small or large, a portion allotted.

# 501

And when those of kin are Present at the division and the orphans and the needy, provide for them thereout, and say unto them a reputable saying.

# 502

And let them beware who, should they leave behind them a weakly progeny, would be afraid on their account; let them, wherefore, fear Allah, and says a proper saying.

# 503

Verily those who devour the substance of the orphans wrongously, only devour the fire into their bellies, and anon they shall roast in the Blaze.

# 504

Allah enjoineth you in the matter of your children; the male will have as much as the portion of two females, but if they be females more than two, then they will have two-thirds of that which he hath left, and if only one, she will have a half; and as far as his parents, each of the twain shall have a sixth of that which he hath left if he have a child, but if he hath no child and his parents be his heirs, then his mother shall have a third; but if he have brothers, then his mother shall have a sixth: all after paying a bequest he may have bequeathed or a debt. Your fathers and your sons - ye know not which of them is higher unto you in benefit: an ordinance this from Allah, verily Allah is Knowing, Wise.

# 505

And ye will have half of that which your wives may leave, if they have no Child, but if they have a child then ye shall have one- fourth of that which they may leave, after paying a bequest they may have bequeathed or a debt. And they shall have one-fourth of that which ye may leaves if ye have no child; but if ye have a child then they will have one-eighth of that which ye may leave, after paying a bequest ye may have bequeathed or a debt. And if a man or a woman who leaveth the heritage hath no direct heirs but hath a brother or a sister, each of the twain will have a sixth; and if more than one, then they will have equal shares in one third after paying a bequest they may have bequeathed or a debt without prejudice: an ordinance this from Allah; and Allah Is Knowing, Forbearing.

# 506

These are the statutes of Allah, and whosoever obeyeth Allah and His apostle, him He shall cause to enter the Gardens whereunder rivers flow, as abiders therein; and that is an achievement mighty.

# 507

And whosoever disobeyeth Allah and His apostle, and transgresseth His statutes, him He shall cause to enter the Fire, as an abider therein; and unto him shall be a torment ignominous.

# 508

As for those of your women who may commit whoredom, call against them four witnesses from among them if they testify, confine you them to their houses till death complete their turn of life, or Allah appoint for them some other way.

# 509

And as for those twain of you who commit it, hurt them both; then, if they repent and amend, turn away from them; verily Allah is Relenting, Merciful.

# 510

With Allah is the repentance of those alone who do an evil foolishly and thereafter repent speedily, surely it is they unto whom Allah shall relent. And Allah is Knowing, Wise.

# 511

And repentance is not for those who go on working evil until when death presenteth itself unto one of them, and he saith: verily now I repent; nor for those who die while they are infidel. These! for them We have gotten ready a torment afflictive.

# 512

O Ye who believe! it is not allowed unto you that ye may heir the women forcibly; nor shut them up that ye may take away from them part of that which ye had given them, except when they be guilty of manifest enormity. And live with them reputably if ye detest them, belike ye detest a thing and yet Allah hath placed therein abundant good.

# 513

And if ye intend to replace a wife by anot her, and ye have given the one of them a talent, take not back aught therefrom. Would ye take it back by slander and manifest sin.

# 514

And how can ye take it back when one of you hath gone in unto the other, and they have obtained from you a rigid bond!

# 515

And wed not of women those whom your fathers had wedded, except that which hath already passed. Verily it hath been an indecency and an abomination and an evil way:

# 516

Forbidden unto you are your mothers and your daughters and your sisters and your father's sisters and your mother's sisters, and your brother's daughters and your sister's daughters. and your foster mothers and your foster sisters, and the mothers of your wives and your step-daughters, that are your wards, born of your wives unto whom ye have gone in, but if ye have not gone in unto them, no sin shall be on you, and the wives of your sons that are from your own loins, and, also that ye should have two sisters together, except that which hath already passed; verily Allah is ever Forgiving, Merciful.

# 517

And also forbidden are the wedded among women, save those whom your right hands own Allah's rescript for you. And allowed unto you is whatsoever is beyond that, so that ye may seek them with your substances as properly wedded men, not as fornicators. Then whomsoever of them ye have enjoyed, give them their dowers stipulated. And there will be no blame on you in regard to aught on which ye mutually agree after the stipulation; verily Allah is Knowing, Wise.

# 518

And whosoever of you has not ampleness of means that he may wed free believing women, let him wed such of the believing bondswomen as the right hands of you people own. And Allah noweth well your belief, ye are one from the other. O Ye may wed them then, with the leave of their owners, and give them their dowers reputably as properly wedded women, not as fornicateresses, nor as those taking to themselves secret paramours. And when they have been wedded, if they commit an indecency, on them the punishment shall be a moiety of that for free wedded women. This is for him among you, who dreameth perdition; and that ye should abstain is better for you, and Allah is Forgiving, Merciful.

# 519

Allah intendeth to expound unto you and to guide you into the dispensations of those before you and relent toward you. And Allah is Knowing, Wise.

# 520

And Allah intendeth to relent toward you, and those that follow lusts intend that ye shall incline a mighty inclining.

# 521

Allah intendeth that he shall lighten unto you, and man hath been created weak.

# 522

O Ye who believe! devour not your substance among yourselves unlawfully, but let it be a trading among you by mutual agreement. And slay not yourselves, verily Allah is unto you ever Merciful.

# 523

And whosoever doth that in transgression- and wrong, presently We shall roast him in Fire; and with Allah that is ever easy.

# 524

If ye shun the grievous sins from which ye are prohibited, We shall expiate from you your misdeeds, and make you enter a noble Entrance.

# 525

And long not for that wherewith Allah hath preferred one of you above anot her Unto men shall be the portion of that which they earn, and unto women shall be the portion of that which they earn. And ask Allah for some of His grace, verily Allah is of everything Knower.

# 526

And unto each We have appointed inheritors of that which the parents or the near of kin leave behind, and unto those with whom ye have made your pledges give their portion. Verily Allah is ever of everything a Witness.

# 527

Men are overseers over women, by reason of that wherewith Allah hath made one of them excel over anot her, and by reason of that which they expend of their substance. Wherefore righteous women are obedient, and are watchers in husbands absence by the aid and protection of Allah. And those wives whose refractoriness ye fear, exhort them, and avoid them in beds, and beat them; but if they obey you, seek not a way against them; verily Allah is ever Lofty, Grand.

# 528

And if ye fear a divergence between the twain, set up an arbiter from his household and an arbiter from her household; then if the twain desire rectification Allah shall bring harmony between the twain; verily Allah is ever Knowing, Aware.

# 529

And worship Allah and associate not aught with Him; and unto parents show kindness, and also unto kindred and orphans and the needy and the near neighbour and the distant neighbour and the companion by your side and the wayfarer and those whom your right hands own Verily Allah loveth not one who is vainglorious, boaster-

# 530

Those who are niggardly and command mankind to niggardliness and hide that which Allah hath vouchsafed unto them of His grace; and We, have gotten ready for the infidels a torment ignominous;

# 531

And those who expend of their substance for show of men, and believe not in Allah nor in the Last Day; and whosoever hath for him Satan as a companion, a vile companion hath he!

# 532

And what would befall them were they to believe in Allah and the Last Day and expend out of that wherewith Allah hath provided them? And of them Allah is ever the Knower.

# 533

Verily Allah wrongeth not any one a grain's weight, and if there is a virtue He shall multiply it and give from His presence a mighty hire.

# 534

How will it be then, when We shall bring, out of each community, a witness, and We shall bring thee against these as a witness?

# 535

That Day those who had disbelieved and disobeyed the apostle would fain that the earth would be levelled over them, and from Allah they will not be able to hide any discourse.

# 536

O Ye who believe! approach not prayer while ye are intoxicated until ye know that which ye say, nor yet while ye are polluted, save when ye be way faring, until ye have washed your selves. And if ye be ailing or on a journey, or one of you cometh from the privy have touched women, or ye and ye find not water, then betake your selves to clean earth and wipe your faces and your hands therewith; verily Allah is ever Pardoning, Forgiving.

# 537

Observest thou not those unto whom was vouchsafed a portion of the book purchasing error, and desiring that ye would err as regards the way!

# 538

And Allah is Knower of your enemies. Sufficieth Allah as a Friend and sufficieth Allah as a Helper.

# 539

Of those who are Judaised, are they who pervert Words from their meanings and say: We hear and we disobey, and: hear thou without being made to hear, and RA'INA, twisting their tongues and scoffing at the faith! And had they said: we hear and obey, and: hear thou, and: UNZURNA, it had surely been better for them and more upright. But Allah hath cursed them for their infidelity, wherefore they shall not believe, save a few.

# 540

O Ye who are vouchsafed the Book believe in that which We have sent down confirming that which is with you, ere We alter countenances and turn them into their hinder parts, or We might curse them even as We cursed the fellows of the Sabt; and Allah's command is ever fulfilled.

# 541

Verily Allah shall not Forgive that aught be associated with Him, and He will forgive all else unto whomsoever He listeth. And whosoever associateth aught with Allah, he hath of a surety fabricated a mighty sin.

# 542

Hast thou not observed those who hold themselves purified Nay! Allah purifieth whomsoever He will, and they shall not be wronged a whit.

# 543

Behold how they fabricate a lie against Allah! and sufficeth that as a manifest sin.

# 544

Hast thou not observed those unto whom is vouchsafed a portion of the Book testifying to idols and devils, and saying of those who have disbelieved: these are better guided as regards the way than the believers?

# 545

These are they whom Allah hath cursed; and whomsoever Allah curseth, for him thou shalt not find a helper.

# 546

Is theirs a portion of the dominion? In that case, they would not give the people a speck.

# 547

Or envy they the people on account of that which Allah hath vouchsafed unto them out of His grace! so, surely We vouchsafed unto the house of Ibrahim the Book and the wisdom and We vouchsafed unto them a mighty dominion.

# 548

Then of them were some who believed therein, and of them were some who turned aside therefrom, and Hell -will suffice as a Flame.

# 549

Verily those who disbelieve in Our revelations, presently We shall roast them into Fire. So oft as their skins are cooked We shall change them for other skins, so that they may keep on tasting the torment verily Allah is ever Mighty, Wise.

# 550

And those who believe and work righteous works, anon We shall cause them to enter the Gardens whereunder rivers flow as abiders therein for ever. For them shall be spouses purified, and We shall cause them to enter a sheltering shade.

# 551

Verily Allah commandeth you that ye shall render dues unto the owners thereof, and that, when ye judge between men, judge with justice. Verily excel lent is that wherewith Allah exhorteth you verily Allah is ever Hearing, Beholding.

# 552

O Ye who believe! obey Allah and obey the apostle and owners of authority from amongst you. then if dispute in aught refer it Unto ye Allah and the apostle if ye indeed believe in Allah and the Last Day. That is the best and fairest interpretation.

# 553

Hast thou not observed those who assert that they believe in that which hath been sent down unto thee and that which hath been sent down before thee desiring to go to the devil for judgement, whereas they have been commanded to disbelieve in him; and Satan desireth to lead them far astray.

# 554

And when it said unto them come unto that which Allah hath sent down and unto the apostle, thou wilt see the hypocrites hang back far from thee.

# 555

How then, when some ill befalleth them because of that which their hands have sent forth and then they come to thee swearing by Allah: we meant naught save kindness and concord.

# 556

These are they of whom Allah knoweth whatsoever is in their hearts: wherefore turn thou from them and exhort them, and say unto them for their souls, effectual saying.

# 557

And not an apostle We have sent but to be obeyed by Allah's command. And if they, when they had wronged their souls, had come unto thee and begged forgiveness of Allah, and the apostle had begged forgiveness for them they would surely have found Allah Relentant, Merciful.

# 558

Aye! by thy Lord, they shall not believe until they have made thee judge of that which is disputed among them, and then find no vexation in their hearts with that which thou hast decreed, and they submit with full submission.

# 559

And had We prescribed unto them: slay yourselves or go forth from your dwellings, they had not done it, save a few of them. And did they do that which they are exhorted to do, it would be for them better and more strengthening.

# 560

And then We would surely have vouchsafed unto them from Our presence a mighty hire.

# 561

And We would surely have guided them on the right path.

# 562

And whosoever obeyeth Allah and the apostle, then those shall be with them whom Allah hath blessed --from among the prophets, the saints, the martyrs, and the righteous. Excellent are these as a company!

# 563

That is the grace from Allah, and sufficeth Allah as Knower!

# 564

O Ye who believe! take your precaution then sally forth in detachment or sally forth all together.

# 565

And verily there Is among you he who laggeth behind, and if an ill befalleth you, he saith: surely Allah hath bestowed favour on me in that I was not Present with them.

# 566

And if there betideth you grace from Allah, then, as though there had been no tenderness between you and him, he saith: would that I had been with them! then I would have achieved a mighty achievement.

# 567

Let them wherefore fight in the way of Allah those who have purchased the life of this world for the Hereafter: And whosoever fighteth in the way of Allah, and is then slain or overcometh, We shall vouchsafe unto him a mighty hire.

# 568

And what aileth you that ye fight not in the way of Allah and for the oppressed among men and women and Children who say: our Lord! take US forth from this town whereof the people are Wrong-doing, and appoint us from before Thee a patron, and appoint us from before Thee a helper!

# 569

These who believe fight in the way of Allah and those who disbelieve fight in the way of the devil. Fight then against the friends of Satan; verily the craft of Satan is ever feeble.

# 570

Hast thou not observed those unto whom it was said;. withhold your hands, and establish prayer and give the poor-rate; but when thereafter fighting was prescribed unto them, lo! there is a party of them dreading men as with the dread of Allah, or with greater dread; and they say: our Lord! why hast Thou prescribed unto us fighting! Wouldst that Thou hadst let us tarry a term nearby! Say thou: the enjoyment of the world is little, and the Hereafter is better for him who feareth God; and ye shall not be wronged a whit.

# 571

Wheresoever ye may be, death shall overtake you, even though ye be in fortresses plastered. And if there betideth them some good, they say: this is from God. And if there betideth them some ill, they say: this is because of thee. Say thou: everything is from Allah. What aileth then this people, that well-nigh they understand not any speech

# 572

Whatsoever of good betideth thee is from Allah, and whatsoever of ill betideth thee is because of thy self. And We have sent thee unto the mankind as an apostle; and sufficieth Allah as a Witness.

# 573

Whosoever obeyeth the apostle hath indeed obeyed Allah, and whosoever turnoth away -We have not sent thee over them as a keeper.

# 574

And they say: Obedience. Then when they so forth from before thee, a part of them plan together by night other than they had said: and Allah writeth down that which they plan by night. Wherefore turn thou from them and trust in Allah and sufficeth Allah as a Trustee.

# 575

Ponder then they not on the Qur'an? Were it from other than Allah they would surely find therein many a contradiction.

# 576

And when there cometh unto them aught of security aught of alarm, they bruit it; abroad: whereas had they referred it to the apostle and those in authority among them, then those of them who can think it out would have known it. And had there not been Allah's grace upon you and His mercy, ye would surely have followed Satan, save a few.

# 577

Fight thou therefore in the way of Allah thou are not tasked except for thy own soul, and persuade the believers; belike Allah will withhold the violence of those who disbelieve. And Allah is stronger in violence and Stronger in chastising.

# 578

Whosoever intercedeth with a goodly intercession, his shall be a portion therefrom, and whosoever intercedeth with an ill intercession his shall be a responsibility thereof; and Allah is of everything the Controller.

# 579

And when ye are greeted with a greeting, then greet back with one better than that or return that; verily Allah is of everything the Reckoner.

# 580

Allah! there is no god but he. Surely He shall gather you together on the Day of Resurrecticn, whereof there is no doubt; and who is more truthful than Allah in discourse?

# 581

What aileth you then, that ye are two parties regarding the hypocrites? whereas Allah hath reverted them because of that which they have earned. Would ye lead aright those whom Allah hath sent astray? And whomsoever Allah sendeth astray, for him thou shalt not find a way.

# 582

Fain would they that ye disbelieved even as they have disbelieved, so that ye may be all alike. Wherefore take not friends from among them until they migrate for the sake of Allah; and if they turn away, then lay hold of them and slay them, wheresoever ye find them, and take not from among them a friend or a helper.

# 583

Excepting those who join a people between whom and you there is a bond or who come to you with their breasts straitened that they should fight you or fight their own people. And had Allah so willed, He would have surely set them upon you. If then they withdraw from you, and fight not against you and offer you peace, then Allah openoth not for you against them a way.

# 584

Surely ye will find others desiring, that they may be secure from you and may be secure from their people; and yet so oft as they are brought back into the temptation, they revert thereto. Wherefore if they withdraw not from you, nor offer you peace, nor restrain their hands, lay hold of them and slay them wheresoever ye find them. These: against them We have given you a clear warranty.

# 585

It is not for a believer to slay a believer except by a mischance; and whosoever slayeth a believer by mischance on him is the setting free of a believing bondman and blood-wit to be delivered to his family except that they forego. Then if he be of a people hostile unto you and is himself a believer, then the setting free of a believing bondman; and if he be of a people between man whom and you is a bond, then the bloodwit to be delivered to his family and the setting free of a believing bondman. Then whosoever findeth not the wherewithal, on him is the fasting for two months in succession: a penance from Allah. And Allah is ever Knowing, Wise.

# 586

And whosoever slayeth a believer intentionally, His meed is Hell, as an abider therein; and Allah shall be wroth with him and shall curse him, and shall get ready for him a torment terrible.

# 587

O Ye who believe! when ye march forth in the way of Allah, make things clear and say not unto one who giveth you a salutation: thou art none of a believer, seeking the perishable goods of the life of the world; for with Allah are spoils abundant. Even Thus were ye aforetime, then Allah favoured you. So make things clear; verily Allah is of that which ye work ever Aware.

# 588

Not equal are the holders back among the believers, save those who are disabled, and the strivers in the way of Allah with their- riches and their lives. Allah hath preferred in rank the strivers with their riches and their lives above the holders-back, and unto all Allah hath promised good. And Allah hath preferred the strivers above the holdersback with a mighty hire.

# 589

Ranks from Him and forgiveness and mercy; and Allah is ever Forgiving, Merciful.

# 590

Verily unto those whom the angels carry off in death, while they are yet oppressors of their souls, they will say: what were ye in? They will say: Weakened were we in the land. They Will say: was not Allah's land wide so that ye could migrate thereto. These: their resort is hell an evil retreat! -

# 591

Excepting the weak ones among men, women and children, unable to find a stratagem and not guided to a way.

# 592

These: belike Allah will pardon them, and Allah is ever Pardoning, Forgiving.

# 593

And whosoever migrateth in the way of Allah, shall find in the earth plentiful refuge and ampleness; and whosoever goes forth from his house as a fugitive unto Allah and His apostle, and death then overtaketh him his hire hath surely devolved upon Allah, and Allah is ever Forgiving, Merciful.

# 594

And when ye are journeying in the earth there shall be no fault in you that ye shorten the prayer if ye fear that those who disbelieve shall molest you, verily the infidels are ever unto you an avowed enemy.

# 595

And when thou art amidst them and hast set up the prayer for them, then let a party of them stand with thee and let them retain their arms; then when they have prostrated themselves, let them go behind you, and let anot her party who have not yet prayed, come and pray with thee; and let them also take their caution and their arms. Pain would those who disbelieve that ye neglected your arms and your baggage, so that they might swoop down upon you at one swoop. And there shall be no fault in you, if there be an injury to you from rain or ye are ailing, that ye lay down your arms and yet take your caution. Verily Allah hath gotten ready for the infidels a torment ignominious.

# 596

Then when ye have finished the prayer, remember Allah, standing and sitting and lying on Your sides. Then when ye are secure, establish the prayer verily the prayer is prescribed unto the believers at definite times.

# 597

And slacken not in seeking the enemy people if ye are suffering, then they suffer even as ye suffer, and you hope from Allah that which they hope not; and Allah is ever Knowing, Wise.

# 598

Verily We! We have sent down the Book unto thee With truth that thou mightest judge between people by that which Allah hath shewn thee; and be not thou On behalf of the deceivers a pleader.

# 599

And beg thou forgiveness of verily Allah is ever Forgiving.

# 600

And contend thou not for those who defraud their souls verily Allah loveth not one who is a defrauder, sinner.

# 601

They feel ashamed of men and feel not ashamed of Allah, whereas He is Present with them when by night they plan together of discourse which pleaseth Him not; and Allah is of that which they work ever an Encompasser.

# 602

Lo! it is ye who have contended for them in the life of the world; then who will contend for them with Allah on the Day of Resurrection, or who shall be their champion?

# 603

And whosoever worketh an ill or wrongeth his own soul, and thereafter beggeth forgiveness of Allah shall find Allah Forgiving, Merciful.

# 604

And whosoever earnoth a sin, only against his own soul he earnoth it; and Allah is ever Knowing, Wise.

# 605

And whosoever earnoth a vice or a sin, and thereafter casteth it on an innocent, he hath surely borne a calumny and a manifest sin.

# 606

Were not the grace of Allah on thee and His mercy, a party of them had surely resolved to mislead thee; whereas they mislead not but themselves, and they shall not hurt thee in aught. And Allah hath sent down unto thee the Book and wisdom, and hath taught thee that which thou knowest not; and the grace of Allah on thee is ever mighty.

# 607

No good is there in much of their whispers except in his who commandeth charity or kindness or reconciliation among mankind; and whosoever doeth this seeking the good-will of Allah, We shall presently give him a mighty hire.

# 608

And whosoever opposeth the apostle after the truth hath become manifest unto him, and followeth other way than that of the believers, We shall let him follow that to which he hath turned, and shall roast him in Hell - an evil retreat!

# 609

Verily Allah shall not forgive that aught be associated with Him, and He will forgive all else unto whomsoever He liketh; and whosoever associateth ought with Allah, hath surely strayed away a far straying.

# 610

They invoke beside Him but females, and they invoke not but a Satan rebellious.

# 611

Allah hath accursed him. And he said: surely shall take of Thine bondmen a portion allotted.

# 612

And surely I will lead them and will fill them with vain desires, and I will command them so that they will slit the ears of the cattle, and I will command them so that they will alter the creation of Allah. And whosoever taketh Satan for a patron, instead of Allah, shall surely suffer a manifest loss.

# 613

The Satan maketh them promises and filleth them with vain desires. and Satan promiseth them not but delusion.

# 614

These: their resort shall be Hell, and they shall not find therefrom an escape.

# 615

And those who believe and work righteous works, anon We shall make them enter Gardens whereunder the rivers flow, as abiders therein for ever: promise of Allah, true. And who is more truthful than Allah in speech?

# 616

Not by your vain desires nor by the vain desires of the people of the Book; whosoever worketh an evil, shall be requited therewith, and he will not find beside Allah a patron nor a helper.

# 617

And whosoever worketh of righteous works, male or female, and is a believer, these shall enter the Garden and shall not be wronged a speck.

# 618

And who can be better in religion than he who submitteth his countenance unto Allah, and sincere, and followeth the faith of Ibrahim, the upright And Allah took Ibrahim for a friend.

# 619

And Allah's is whatsoever is in the heavens and whatsoever is in the earth; and of everything Allah is ever an Encompasser.

# 620

And they ask thy decree concerning women. Say thou: Allah decreeth unto you concerning them and so do the revelations that have been rehearsed unto you in the Book concerning the orphan women unto whom yes give not that which is prescribed for them and yet desire that ye shall wed them, and concerning the oppressed children, and concerning this, that ye shall deal with the orphans in equity, and whatsoever of good ye de, then verily thereof Allah is ever Aware.

# 621

And if a woman feareth from her husband refractoriness or estrangement, it shall be no blame on the twain if they effect between them a reconciliation; and reconciliation is better. And souls are engrained with greed. And if ye act kindly and fear Him, then verily Allah is ever of that which ye work Aware.

# 622

And ye are not able to deal evenly between the wives, even though ye long to do so, but incline not an extreme inclining so that ye may leave her as one ahanging. And if ye effect a reconciliation and fear Allah, then Allah is ever Forgiving, Merciful.

# 623

And if the twain must sunder, Allah shall render the twain independent out of His bounty, and Allah is ever Bountiful, Wise.

# 624

Allah's is whatsoever is in the heavens and whatsoever is in the earth. And assuredly We enjoined those who were vouchsafed the Book before you and yourselves: fear Allah, and if ye disbelieve then Allah's is whatsoever is in the heavens and whatsoever is in the earth; and Allah is ever Self-Sufficient, Praiseworthy.

# 625

And Allah's is whatsoever is in the heavens and whatsoever is in the earth, and sufficeth Allah as a Champion.

# 626

If He will, He will take you away, O mankind! and bring forward others; and over that Allah is ever Potent.

# 627

Whosoever seeketh the reward of this world, with Allah is the reward of this world and of the Hereafter; and Allah is ever Hearing, Beholding.

# 628

O Ye who believe! be ye maintainers of justice, bearers of testimony for Allah's sake, though it be against yourselves or your parents or kindred. Be he rich or poor, Allah is nigher unto either wherefore follow not the passion, lest ye deviate. If ye incline or turn away, then verily of that which ye work Allah is ever Aware.

# 629

O Ye who believe believe in Allah's and His apostle and the Book He hath sent down unto His apostle and the Book He sent down aforetime; and whosoever disbelieveth in Allah and His angels and His Books and His Apostles and the Last Day, hath surely strayed away a far straying.

# 630

Verily those who believed and then disbelieved, and then believed and then, disbelieved, and thereafter waxed in infidelity ye Allah shall not forgive them nor guide them on the way.

# 631

Announce thou to the hypocrites that theirs shall be a torment afflictive.

# 632

Those who take infidels for, friends, instead of the believers. Seek thy honour with them verily then honour is Allah's altogether.

# 633

And it hath been revealed to you in the Book that when ye hear Allah's revelations being disbelieved in and mocked at, sit not down with them until they plunge in a discourse other than that; for, then, ye would surely become like unto them. Verily Allah is about to gather hypocrites and infidels in Hell together.

# 634

Those who wait about you. If then there be victory for you from Allah, they say: were we not with you? And if there is a portion for the infidels, they say: gained we not mastery over you, and kept we not you back from the believers! Allah shall Judge betwixt you On the Day of Judgement, and Allah shall not make for the infidels against the believers a way.

# 635

Verily the hypocrites would beguile Allah, whereas it is He who beguileth them,; and when they stand up to prayer, they stand up languidly, making a show to the people, and they remember not Allah but little.

# 636

Wave ring between this and that; neither for this nor for that and whomsoever Allah sendeth astray, for him thou wilt never find a way.

# 637

O Ye who believe! take not infidels for friends, instead of believers. Would ye give Allah against you a manifest warranty!

# 638

Verily the hypocrites shall be in the lowest abyss of the Fire; and thou wilt not find for them a helper.

# 639

Except those who shall yet repent and amend and hold fast by repent Allah and make their religion exclusive for Allah. These then shall be with the believers, and presently Allah shall give the believers a mighty hire.

# 640

What will Allah do with your torment, if ye return thanks and believe? And Allah is ever Appreciative, Knowing.

# 641

Allah approveth not the publishment of evil speech, unless by one who hath been wronged; and Allah is ever Hearing, Knowing.

# 642

Whether ye disclose a good or conceal it, or pardon an evil, then verily Allah is ever Pardoning potent.

# 643

Verily those who disbelieve in Allah and His apostles, and would differentiate between Allah, and His apostles, and say: some we believe in and others we deny; and they would take a way in between this and that.

# 644

These: they are the infidels in very truth, and We have gotten ready for the infidels a torment ignominious.

# 645

And those who believe in Allah and His apostles and differentiate not between any of them, anon We shall give them their hire; and Allah is ever Forgiving, Merciful.

# 646

The people of the Book ask thee to bring down a Book to them from the heaven. But surely they asked Musa a thing greater than that; they said: shew us God manifestly; whencefore the thunderbolt overtook them for their wrong-doing. Then they took a calf after there had come unto them the evidences. Even so We pardoned that, and We gave Musa a manifest authority.

# 647

And We raised the Mount over them for their bond. And We said unto them: enter the portal prostrating yourselves. And We said unto them: transgress not in the matter of the Sabbath and We took from them a firm bond.

# 648

Accursed are they then for their breach of the bond and their rejecting the commandments of Allah and their slaying the prophets without justification, and their saying: our hearts are uncircumcised. Aye! Allah hath set a seal upon them for their infidelity, wherefore they believe not but a little.

# 649

And for their blasphemy and for their speaking against Maryam a mighty calumny.

# 650

And for their saying: verily We have slain the Messiah 'Isa son of Maryam, an apostle of Allah, whereas they slew him not, nor they crucified him but it was made dubious unto them. And verily those who differ therein are in doubt thereof, they have no knowledge thereof; they but follow an opinion; and surely they slew him not.

# 651

But Allah raised him unto Himself; and Allah is ever Mighty, Wise.

# 652

And there is none among the people of the Book but shall surely believe in him before his death, and on the Day of Judgement he shall be a witness against them.

# 653

Wherefore because of the wrongdoing on the part of those who are Judaised We forbade unto them the clean things that had been allowed unto them, and also because of their keeping away many from Allah's way;

# 654

And also because of their taking usury whereas they were prohibited therefrom, and also because of their devouring the riches of men unlawfully. And for the infidels among them We have gotten ready a torment afflictive.

# 655

But of them those well-grounded in the Knowledge and the believers believe in that which hath been sent down unto thee and that which hath been sent down before thee, and the establishers of prayer and the givers of the poor-rate and the believers in Allah and the Last Day- those: unto them anon We shall give a mighty hire.

# 656

Verily We have revealed unto thee even as We revealed unto Nuh and the prophets after him, and as We revealed unto Ibrahim and Isma'il and Is-haq and Ya'qub and the tribes, and 'Isa and Ayyub and Yunus and Harun and Sulaiman, and unto Daud We vouchsafed a Scripture.

# 657

And We Revealed unto apostles of some of whom We have narrated unto thee aforetime and of others of whom We have not narrated unto thee; and unto Musa Allah spake directly.

# 658

We sent all these apostles as bearers of glad tidings and warners in order that there be no plea for mankind against Allah, after the apostle; and Allah is ever Mighty Wise.

# 659

How be it Allah beareth witness by that which He hath sent down unto thee He sent it down with His own knowledge and the angels also bear witness; and sufficieth Allah as a Witness.

# 660

Verily those who disbelieve and keep others from the way of Allah, have surely strayed far away.

# 661

Verily those who have disbelieved and done wrong, Allah is not one to forgive them nor to guide them to any way.

# 662

Except the way to Hell, as abiders therein for ever, and this unto Allah is ever easy.

# 663

O ye mankind! assuredly there hath come unto you the Prophet with the truth from your Lord wherefore believe that it may be well for you. And if ye disbelieve, then verily Allah's is whatsoever is in the heavens and the earth; and Allah is ever Knowing, Wise.

# 664

O ye people of the Book; exceed not the bounds in Your religion, and say not of Allah save that which is the truth. The Messiah 'Isa, son of Maryam, is but an apostle of Allah and His word --He cast it upon Maryam-- and a spirit from Him. Believe wherefore in Allah and His apostles, and say not: three. Desist, that it may be well for you. Allah is but the One God: hallowed be He that there should be unto Him a son! His is whatsoever is in the heavens and the earth, and sufficeth Allah as a Trustee.

# 665

The Messiah disdaineth not that he should be a bondman of Allah, nor do the angels brought near. And whosoever disdaineth serving Him and stiff-necked, anon He shall gather them all unto Him.

# 666

Then as to those who have believed and worked righteous works, He shall give unto them their hire in full and shall give unto them an increase out of His grace. And as to those who disdained and were stiff-necked, He shall torment them with a torment afflictive. And they shall not find for themselves, against Allah, a protecting friend or a helper.

# 667

O ye mankind! there surely hath come unto you a proof from your Lord, and We have sent down unto you a manifest light.

# 668

Then as to those who believe in Allah and hold fast by Him, anon He shall make them enter into a mercy from Himself and grace and shall lead them unto Himself by a path straight.

# 669

They ask thee for pronouncement. Say thou: Allah pronounceth thus in the matter of one without father or child: if a person perisheth and hath no child, but hath a sister, hers shall be the half of that which he hath left: and he shall be her heir if she hath no child, if there be two sisters, then theirs shall be two-third of that which he hath left; and if there be both brothers and sisters, then male shall have as much as the portion of two females. Allah expoundeth unto you, lest ye err; and Allah is of everything Knower.

# 670

O ye who believe! fulfil the compacts. Allowed unto you is the beast of the flock except that which is rehearsed unto you, not allowing the chase while ye are in a state of sanctity. Verily Allah ordaineth whatsoever He will.

# 671

O ye who believe! profane not the landmarks of Allah nor any sacred month nor the offering nor the victims with the garlands nor those repairing to the Sacred House seeking the grace of their Lord and His goodwill. And when ye have put off the state of sanctity, ye may chase. And let not the hatred against a people, because they kept you from the Sacred Mosque, incite you to trespass. Assist each other to virtue and piety, and assist not each other to sin and transgression, Fear Allah: verily Allah is Severe in chastising.

# 672

Forbidden unto you are the deadmeat, and blood, and the flesh of the swine, and that over which is invoked the name of other than Allah, and the strangled, and the felled, and the tumbled, and the gored, and that which wild animals have devoured, unless ye have cleansed, and that which hath been slaughtered on the altars, and that ye seek a division by means of the divining arrows: all that is an abomination. To- day those who disbelieve have despaired of your religion; wherefore fear them not, and fear Me. To-day I have perfected for you your religion, and have completed My favour upon you, and am well-pleased with Islam as your religion. Then whosoever is driven to extreme hunger not inclining to sin, verily then Allah is Forgiving, Merciful.

# 673

They ask thee as to whatever is allowed unto them. Say thou: allowed unto you are all clean foods, and as to the animals of prey which ye have taught even as Allah hath taught you, eat of that which they have caught for you, and mention the name of Allah over it; and fear Allah, verily Allah is swift in reckoning.

# 674

To-day are allowed unto you all clean foods, and the meat of those vouchsafed the Book is allowable for you, and your meat is allowable for them as also are the wedded believing women and the wedded women of those vouchsafed the Book before you, when ye have given them their dowers, taking them in wedlock, neither fornicating, nor taking them is secret paramours. And who soever rejecteth the faith, his work will surely come to naught, and in the Hereafter he shall be of the losers.

# 675

O ye who believe! when ye stand up for the prayer wash your faces and your hands unto the elbows, and wipe your heads, and wash your feet unto the ankles. And if ye be polluted, then purify yourselves And if ye be ailing or on a journey or one of you cometh from the privy or ye have touched women, and ye find not water, then betake yourselves to clean earth and wipe your faces and hands therewith. Allah intendeth not to lay upon you a hardship, but intendeth to purify you and to complete His favour upon you, that haply ye may return thanks.

# 676

And remember Allah's favour on you and His bond wherewith He bound you firmly when ye said: we hearken and we obey. And fear Allah: verily Allah is Knower of that which is in the breasts.

# 677

O ye who believe! be maintainers of your pact with Allah and witnesses in equity, and let not the hatred of a people incite you not to act fairly; act fairly; that is highest unto piety. And fear Allah; verily Allah is Aware of that which ye work.

# 678

Allah hath promised those who believe and work righteous works that for them shall be forgiveness; and a mighty hire.

# 679

And those who disbelieve and belie Our signs, they shall be the fellows of the Flaming Fire.

# 680

O ye who believe! remember Allah's favour on you when a people determined to stretch forth their hands against you, but he withheld their hands from you, And fear Allah, and in Allah let the believers trust.

# 681

And assuredly Allah took a bond from the Children of Isra'il, and We raised from amongst them twelve wardens. And Allah said: verily I am with you, if ye establish prayer and give the poor-rate and believe in My apostles and support them and lend unto Allah a goodly loan, I shall surely expiate for you your misdeeds and surely shall make you enter the Gardens whereunder rivers flow; then whosoever of you shall disbelieve thereafter, he hath surely strayed from the level way.

# 682

Wherefore for their breach of their bond We accursed them and We made their hearts hard. They pervert the words from the meanings thereof and have abandoned a good portion of that wherewith they were admonished. And thou wilt not cease to light upon defrauding on their part, save a few of them; yet pardon thou them and overlook them, verily Allah loveth the well-doers.

# 683

And of them who say: verily we are Nazarenes, We took a bond from them, but they have abandoned a good portion of that wherewith they were admonished. Wherefore We have occasioned enmity and hatred amongst them till the Day of Judgement, and presently Allah shall declare unto them that which they have been performing.

# 684

O ye people of the Book! surely there hath come Our apostle unto you expounding unto you much in the Book that ye were wont to hide, and much he passeth over. Of a surety, there hath come unto you from Allah a light and a Book luminous.

# 685

Therewith Allah guideth those who follow His goodwill unto the ways of safety, and bringeth them forth out of darkness into the light by His leave, and guideth them onto the right path.

# 686

Assuredly they have disbelieved who say. verily God! He is the Masih, son of Maryam. Say thou; who can avail in aught against Allah, if He intended to destroy Masih, son of Maryam, and his mother and thou on the earth altogether? And Allah's is the dominion of the heavens and the earth and that which is in between the twain. He createth whatsoever He will, and Allah is over everything Potent.

# 687

And the Jews and the Nazarenes say: we are the children of God and His loved ones. Say thou: wherefore then doth He torment you for your sins? Aye! ye are but men, part of those whom He hath created. He forgiveth whomsoever He will and tormenteth whomsoever He will. And Allah's is the dominion of the heavens and the earth and that which is in- between the twain, and unto Him in the return.

# 688

O people of the Book! surely there hath come unto you Our apostle, after a cessation of the apostles, expounding unto you, lest ye may say: there came not unto us a bearer of glad tidings nor a warner. So now there surely hath come unto you a bearer of glad tidings and a warner; and Allah is over everything Potent.

# 689

And recall what time Musa said unto his people: O my people! remember the favour of Allah on you when he made amongst you prophets and made princes, and vouchsafed unto you that which he vouchsafed not to anyone in the world.

# 690

O my people! enter the holy land which Allah hath prescribed for you and turn not back to your rearward for then ye become losers.

# 691

They said: O Musa! verily therein are a people high handed, and verily we shall never enter it until they go forth therefrom; so if they go forth thence, we shall verily enter in.

# 692

Thereupon spake two men of those who feared and whom Allah had favoured; enter ye the gate against them, then as ye enter it ye are the over - and put your trust in Allah, if ye are indeed believers.

# 693

They said: O Musa! verily we shall never enter it so long as they remain therein; go thou and thy Lord, and fight ye twain, we shall remain here sitting.

# 694

Said he: my Lord control not but myself and my brother, so decide Thou between us and this transgressing people.

# 695

Said He: verily then it is forbidden unto them for forty years, while they shall wander about in the earth, so mourn not thou over this transgressing people.

# 696

And rehearse thou unto them with truth the tale of the two sons of Adam, when the twain offered an offering, and it was accepted from one of them, and was not accepted from the other; he said: surely I will slay thee. Said the other: Allah accepteth only from the God- fearing.

# 697

If thou stretchest forth thine hand against me to slay me, I shall not be stretching forth my hand against thee to slay thee, verily I fear Allah, the Lord of the worlds.

# 698

Verily would that thou bear my sin and thine own sin, and then thou become of the fellows of the Fire; that is the meed of the wrong-doers.

# 699

Then his soul made the slaying of his brother agreeable to him, so he slew him, and he became of the losers.

# 700

Then Allah sent a raven scratching in the earth to show him in what wise he might cover the corpse of his brother. He said: woe unto me was incapable of being like unto this raven so that I might cover the corpse of my brother! And he became of the remorseful.

# 701

Because of that We Prescribed unto the Children of Isra'il: whosoever slayeth a person, except for a person, or for corruption in the land, it shall be as through he had slain all mankind, and whosoever bringeth life to one it shall be as though he had brought life to all mankind. And assuredly there came unto them Our apostles with evidences, yet even thereafter many of them are acting on the earth extravagantly.

# 702

The meed of those who wage war against Allah and His apostle and go about in the land corrupting is only that they shall be slain or crucified or their hands and feet be cut off on the opposite sides, or be banished from the land. Such shall be their humiliation in the world, and theirs shall be in the Hereafter a mighty torment.

# 703

Save those who repent ere ye have them in your power; for know that Allah is Forgiving, Merciful.

# 704

O ye who believe! fear Allah and seek approach unto Him and strive hard in His way, that haply ye may fare well.

# 705

Verily those who have disbelieved, if they had all that is in the earth and with it as much again whereby to ransom themselves from the torment on the Day of Judgement, it shall not be accepted of them, and theirs shall be a torment afflictive.

# 706

They will desire to come forth from the Fire, but they shall not be able to come forth therefrom, and theirs shall be a torment lasting.

# 707

As for the man-thief and the woman-thief, cut off their hands as a meed for that which they have earned; an exemplary punishment from Allah. And Allah is Mighty, Wise.

# 708

Then whosoever repenteth after his wrong-doing and amendeth, verily Allah shall relent toward him. Verily Allah is Forgiving, Merciful.

# 709

Knowest thou not that Allah! - verily His is the dominion of the heavens and the earth; He chastiseth whomsoever He will and forgiveth whomsoever He will; and Allah is over everything Potent.

# 710

O apostle! let not those grieve thee that hasten after infidelity from among these who say with their mouths: we believe, yet their hearts believe not, and from among those who are Judaised: listeners to falsehoods, listeners to anot her people who come not unto thee; they pervert the words after they have been set in their places, saying: if that which is given you be this accept it, but if that is not given you, beware. And whosesoever temptation Allah Willeth, thou shalt not avail him against Allah in aught. These are they whose hearts Allah would not cleanse; theirs is humiliation in this world and theirs shall be in the Hereafter a mighty torment.

# 711

Listeners are they to falsehood, devourers of the forbidden. Wherefore if they come to thee, either judge between them or turn away from them. And if thou turnest away from them, they shall not be able to hurt thee in aught; and if thou judgest, judge between them with equity, verily Allah loveth the equitable.

# 712

And how shall they ask thee for judgement, whereas with them is the Taurat wherein is Allah's judgement? And they turn away thereafter? And those are no believers.

# 713

Verily We sent down the Taurat wherein was a guidance and a light. By it the prophets who submitted themselves judged those who were judaised, and so did the divines and the priests by that wherewith they were entrusted of the Book of Allah and they had become witnesses thereof. Wherefore fear not the mankind but fear Me, and barter not My revelations for a small price, And whosoever judgeth not by that which Allah hath sent down - those then they are the infidels.

# 714

And We prescribed unto them therein: a life for a life, and an eye for an eye, and a nose for a nose, and an ear for an ear, and a tooth for a tooth, and wounds in reprisal, then whosoever forgoeth it, then it shall be for him an expiation. And whosoever judgeth not by that which Allah hath sent down - those then! they are the wrong-doers.

# 715

And in their footsteps We caused 'Isa, son of Maryam, to follow, confessing to that which had preceded him, the Taurat, and We vouchsafed unto him the Injil wherein was a guidance and a light, confirming that which had preceded it, the Taurat, and a guidance and an admonition unto the God-fearing.

# 716

And let the people of the Injil judge by that which Allah hath sent down therein; and whosoever judgeth not by that which Allah hath sent down, then those! - they are the transgressors.

# 717

And We have sent down the Book unto thee with truth; and confirming that which hath preceded it of the Book, and a guardian thereof. Wherefrom judge thou between them by that which Allah hath sent down, and follow thou not away from that which hath their desires come to thee of the truth. Unto each of you We appointed law and a way. And had Allah listed, He would have made you all a single community, but He willed not in order that he may prove you by that which He hath vouchsafed unto you. Hasten wherefore to the virtues; unto Allah is the return of you all; then He shall declare unto you concerning that wherein ye have been disputing.

# 718

And judge thou between them by that which Allah hath sent down, and follow thou not their desires, and beware thou of them lest they tempt thee away from any part of that which Allah hath sent down unto thee. Then if they turn away, then know thou that Allah only intendeth to afflict them for some of their sins. And verily many of the mankind are transgressors.

# 719

Seek they then the judgement of Paganism? And who is better than Allah in judgement unto a people who are convinced?

# 720

O ye who believe! take not the Jews and the Nazarenes as friends: friends they are to each other: and whosoever of you befriendeth them, verily he is of them; verily Allah guideth not a wrong-doing people.

# 721

Wherefore thou seest those in whose hearts is a disease hasten toward them saying: we fear lest there may befall us a reverse. But belike Allah may bring a victory or some affair from Himself; then they shall find themselves, for which they hide in their souls, remorseful.

# 722

And those who believe will say: are those they who swear by Allah say their solemn oaths that they were verily with you? Their works came to naught, and they found themselves losers.

# 723

O ye who believe! whosoever of you apostateth from his religion, then presently Allah shall bring a people whom He shall love and who shall love Him, gentle toward the believers, stern toward the infidels, striving hard in the way of Allah, and fearing not the reproof of any reprover. This is the grace of Allah; He bestoweth it on whomsoever He will. And Allah is Bountiful, Knowing.

# 724

Your friend is but Allah and His apostle and those who have believed- those who establish the prayer and give the poor-rate while they bow down.

# 725

And whosoever befriendeth Allah and His apostle and those who have believed, then verily the party of Allah! - they are the overcomers.

# 726

O ye who believe! take not as friends those who make a mockery and fun of your religion from among those who have been vouchsafed the Book before you and other infidels. And fear Allah if ye are believers.

# 727

And when ye call for the prayer they make a mockery and fun thereof. This because they are a people who understand not.

# 728

Say thou: O people of the Book! what is it that ye persecute us for save that we believe in Allah and in that which hath been sent down unto us and that which hath been sent down aforetime? and most of you are transgressors.

# 729

Say thou: shall I declare unto you something worse as a way with Allah than that? Whomsoever Allah hath accursed and is angered with, and of whom some He hath made apes and swine and slaves of the devil - those are worst in abode and furthest astray from the level way.

# 730

And when they come to you they say: we believe; whereas surely with infidelity they entered and surely with it they went forth. And Allah is Knower of that which they have been concealing.

# 731

And thou shalt see many of them hastening toward sin and transgression and their devouring of the forbidden. Vile indeed is that which they have been doing!

# 732

Wherefore is it that the divines and priests forbid them not of their speaking of sin and their devouring of the forbidden? Vile indeed is that which they have been performing!

# 733

And the Jews say: the hand of God is fettered. Fettered be their own hands, and cursed be they for that which they have said! Aye! His both hands are wide open. He expendeth howsoever He listeth. And surely that which hath been sent down to thee from thy Lord increaseth many of them in exorbitance and infidelity. And We have cast among them enmity and spite till the Day of Judgement: so oft as they kindle the fire of War Allah extinguisheth it, and they strive after corruption in the land, and Allah approveth not the corrupters.

# 734

And had the people of the Book believed and feared, We would surely have expiated from them their misdeeds and would surely have made them enter the Garden of Delight.

# 735

And had they established the Taurat and the Injil and that which hath now been sent down unto them from their Lord, they would have devoured from above them and from beneath them. Among them is a community right-doing; but many of them - vile is that which they work!

# 736

O Apostle! preach thou all that hath been sent down unto thee from thy Lord; and if thou do it not, thou wilt not have preached His message. Allah shall protect thee from mankind; verily Allah shall not guide a disbelieving people.

# 737

Say thou: people of the Book! ye rest not on aught until ye establish the Taurat and the Injil and that which hath now been sent down unto you from your Lord. And that which hath been sent down unto thee will surely increase many of them in exorbitance and infidelity; so mourn thou not over and disbelieving people.

# 738

Verily those who believe, and those who are Judaised, and the Sabians and the Nazarenes - whosoever believeth in Allah and the Last Day and worketh righteously, no fear shall come on them, nor shall they grieve.

# 739

Assuredly We took a bond from the Children of Isra'il and We sent unto them apostles. Whenever there came unto them an apostle with that which their souls desired not, a party of them they belied and a party they slew.

# 740

And they imagined that there would be no trial; so they blinded and deafened themselves. Thereafter Allah relented toward them, then they again blinded and deafened themselves. And Allah is Beholder of that which they Work.

# 741

Assuredly they have disbelieved who say: verily God: He is the Masih, son of Maryam, whereas the Masih had said: Children of Isra'il! worship Allah, mine Lord and your Lord; verily whosoever associateth aught with Allah, Allah shall surely forbid the Garden unto him, and his resort is the Fire; and for the wrong-doers there shall be no helpers.

# 742

Assuredly they disbelieve who say: God is the third of the three; whereas there is no god except the One God. And if they desist not from that which they say, there shall surely befall those of them who have disbelieved a torment afflictive.

# 743

Wherefore turn they not toward Allah and ask His forgiveness? And Allah is Forgiving, Merciful.

# 744

The Masih, son of Maryam, was naught but an apostle; surely there passed away apostles before him and his mother was a saintly woman; both of them were wont to eat food. Behold! how We expound unto them the evidences! Then behold! whither they are deviating!

# 745

Say thou: worship ye, beside Allah, that which availeth you not for hurt nor for profit! whereas Allah! He is the Hearer, the Knower.

# 746

Say thou: O people of the Book! exceed not the just bounds in your religion except with truth, and follow not the vain desires of a people who have strayed aforetime and have led many astray and have strayed from the level way.

# 747

Cursed were those who disbelieved from among the Children of Isra'il by the tongue of Daud and 'Isa, son of Maryam. That is because they disobeyed and were ever transgressing.

# 748

They were wont not to desist from the evil they committed; vile is that which they have been doing!

# 749

Thou wilt see many of them befriending those who disbelieve; vile surely is that which their souls have sent forth for them, so that Allah became incensed against them; and in torment they shall be abiders.

# 750

And had they believed in Allah and the prophet and that which is sent down unto him, they would not have taken them for friends, but many of them are transgressors.

# 751

Surely thou wilt find the Jews and those who associate the bitterest of mankind in enmity toward those who believe. And surely thou wilt find the highest in affection to those who believe those who say: we are Nazarenes. That is, because among them are divines and monks and because they are not stiff-necked.

# 752

And when they hear that which hath been sent down unto the apostle, then thou beholdest their eyes overflow, with tears because of the truth they have recognised. They say: Our Lord! we believe, so write us down with the witnesses.

# 753

And what aileth us that we should not believe in Allah and that which hath come unto us of the truth; and we long that our Lord will enter us with the righteous people.

# 754

Wherefore Allah will reward them, for that which they said, with Gardens whereunder rivers flow as abiders therein: such is the recompense of the well-doers.

# 755

And those who disbelieved and belied Our signs, they shall be the fellows of the Flaming Fire.

# 756

O ye who believe! forbid not the clean things of that which Allah hath allowed unto you, and trespass not verily Allah approveth not the trespassers.

# 757

And eat of that wherewith Allah hath provided you as lawful and clean; and fear Allah in whom ye are believers.

# 758

Allah shall not take you to task for the vain in your oaths; but he shall take you to task for that which your oaths make binding. The expiation thereof is the feeding of ten of the needy with the middle sort of that wherewith ye feed your households, or the clothing of them or the freeing of a neck; but whosoever cannot find, far him is a fasting of three days. That is the expiation of your oaths when ye have sworn and bear in mind your oaths. Thus doth Allah expound unto you His commandments, that haply ye may return thanks.

# 759

O ye who believe! wine and gambling and stone altars and divining arrows are only an abomination, a handiwork of Satan, shun it wherefore, that haply ye may fare well.

# 760

Satan only seeketh to breed animosity and spites among you by means of wine and gambling and would keep you from the remembrance of Allah and from prayer; will ye not then desist?

# 761

Obey Allah and obey the apostle, and beware; but if ye turn away, then know that upon Our apostle resteth only the plain preaching.

# 762

No sin is on those who believe and work righteous works for that which they have eaten when they have abstained, and believed and work righteous works, and shall again abstain and believe, and shall again abstain and do well; and Allah loveth the well-doers.

# 763

O ye who believe! Allah shall surely prove you with aught of the chases which your hands and your lances may reach, in order that Allah may know whosoever feareth Him unseen; so whosoever shall trespass thereafter, for him is a torment afflictive.

# 764

O ye who believe! slay not chase while ye are in a state of sanctity; and whosoever of you slayeth it wittingly, his compensation is the like of that which he hath slain, in domestic flocks, which two equitable persons among you shall judge: an offering brought to the Ka'ba; or as an expiation the feeding of the needy, or the equivalent thereof in fasts, that he may taste the grievousness of his deed. Allah hath pardoned that which is past, but whosoever returnoth, Allah shall take retribution from him; verily Allah is Mighty, Lord of Retribution

# 765

Allowed unto you is the game of the sea and the eating thereof: a provision for you and for the caravan; and forbidden unto you is the game of the land while ye are in the state of sanctity. And fear Allah unto whom ye shall be gathered.

# 766

Allah hath made the Ka'ba, the Sacred House, a maintenance for mankind and likewise the Sacred month, and so also the offering and the victims with garlands. That is in order that ye may know that Allah knoweth whatsoever is in the heavens and whatsoever is in the earth, and that of everything Allah is Knower.

# 767

Know that Allah is severe in chastising and that Allah is Forgiving, Merciful.

# 768

Naught resteth there on the apostle except the preaching, and Allah knoweth that which ye disclose and that which ye hide.

# 769

Say thou: equal are not the foul and the pure, even though the abundance of the foul may astonish thee; wherefore fear Allah, ye men of understanding! that haply ye may fare well.

# 770

O ye who believe! ask not about things which if disclosed to you, may annoy you; and if ye ask about them while the Qur'an is being revealed, they may be disclosed to you. Allah hath pardoned that; and Allah is Forgiving, Forbearing.

# 771

Surely people have asked questions before you, and were then found disbelievers therein.

# 772

Allah hath not appointed aught of the bahira or the sa'iba or the wasila or the ham, those who disbelieve have fabricated a lie against Allah, and most of them reflect not.

# 773

And when it is said unto them: come to that which Allah hath sent down and to the apostle, they say: enough for us is that whereon we found our fathers. What! even though their fathers knew not aught nor were guided.

# 774

O ye who believe! on you resteth the case of yourselves; it can hurt you not as to whosoever strayeth so long as ye keep yourselves guided. Unto Allah is the return of you all; then He shall declare unto you that which ye were wont to work.

# 775

O ye who believe! the testimony amongst you, when death presenteth itself to you, at the making of a bequest shall be that of two equitable persons from amongst you, or two others from amongst those not of you, if ye be journeying in the earth and the affliction of death afflicteth you. O Ye shall detain the twain after the prayer, if ye be in doubt, and they shall swear by Allah affirming: we shall not barter it for a price, even though he be a kinsman, and we shall not hide the testimony of Allah, for then verily we shall be of the sinners.

# 776

If then it be lit upon that the twain had been guilty of a sin, then two othershall take their place from among those who were sinned against, the two nearest of kin, and they shall swear by Allah affirming: our testimony is worthier of credit than their testimony and we have not trespassed, for then verily we shall be of the wrong-doers.

# 777

That shall make it more likely that they shall produce the testimony according to the fact thereof or they shall fear that other oaths would be admitted after their oaths. And fear Allah and hearken; and Allah guideth not a transgressing people.

# 778

Beware of the Day whereon Allah shall assemble the apostles and say unto them: how were you answered? Then they will say: no knowledge have we; verily Thou! Thou art the Great Knower of the things hidden.

# 779

And call to mind what time Allah will say: 'Isa, son of Maryam, remember My favour unto thee and unto thine mother when I aided thee with the holy spirit so that thou spakest unto mankind in the cradle and in maturity, and when taught thee the Book and wisdom and the Taurah and the Injil, and when thou formedst out of clay as though the likeness of a bird by My command, and thou breathedest thereinto and it became a bird by My command, and thou healedest the blind from birth and the leprous by My command; and when thou causedest the dead to come forth by My command; and when I restrained the Children of Isra'il from thee when thou didst come to them with evidences, and those of them who disbelieved said: this is but magic manifest.

# 780

And recall what time I revealed to the disciples: believe in Me and My Apostle, they said: we have believed and bear thou witness that verily we are Muslims.

# 781

Recall what time the disciples said: O 'Isa, son of Maryam! is thine Lord able to send down unto us some food from the heaven? He said: fear Allah, if ye are indeed believers.

# 782

They said: we mean that we may eat thereof and we may set our hearts at rest and we be assured that thou hast spoken the truth unto us, and we should be of the witnesses thereof.

# 783

'Isa, son of Maryam, said: O Allah, our Lord send down unto us some food from the heaven, that it may become unto us an occasion of joy, unto the first of us and the last of us, and a sign from Thee. And provide us Thou; and Thou art the Best of providers.

# 784

Allah said: verily I am going to send it down to you, but whosoever of you disbelieveth thereafter, verily shall torment him with a torment wherewith I shall not torment any other of the worlds.

# 785

And call to mind what time Allah will say: O 'Isa, son of Maryam! was it thou who said to the people: take me and my mother as two god beside Allah! 'Isa will say: hallowed be Thou! it was not for me to say that to which had no right; had I said it, Thou would have surely known it; Thou knowest that which is in my mind and know not that which is in Thy mind. Verily Thou! Thou art the Great Knower of the things hidden.

# 786

I spake not unto them aught save that for which Thou badest me: worship Allah, mine Lord and your Lord. I was a witness over them so long as abode amongst them: then when Thou tookest up Thou hast been the Watcher. And over everything Thou art a Witness.

# 787

Shouldst Thou torment them, then verily they are Thine creatures; and shouldst Thou forgive them, then verily Thou! Thow art the Mighty, the Wise.

# 788

Allah will say: this is a Day whereon their truthfulness will benefit the truthful. Theirs are Gardens whereunder rivers flow; they shall be abiders therein for ever, well-pleased is Allah with them and well-pleased are they with Him: that is an achievement supreme.

# 789

Allah's is the dominion of the heavens and the earth and whatsoever Is therein, and over everything He is Potent.

# 790

All praise unto Allah, who created the heavens and the earth and made the darknesses and the light, yet those who disbelieve equalise others with their Lord.

# 791

He it is who created you of clay and then decreed a term - and a term determined is with Him - yet ye waver.

# 792

He is Allah in the heavens and the earth; He knoweth your secret and your publishment, and He knoweth that which ye earn.

# 793

And not a sign cometh unto them of the signs of their Lord but that therefore they have been backsliders.

# 794

Surely they have belied the truth when it came unto them; so presently there cometh unto them the tidings of that whereat they have been mocking.

# 795

Observe they not how many a generation before them We have destroyed whom We had established on the earth as We have not established you, and upon whom We had sent the rains of heaven pouring and under whom We had made the rivers flow; yet We destroyed them for their sins and We produced after them a generation of others.

# 796

And had We sent down unto thee a Book written upon parchment so that they could have touched it with their hands, those who disbelieve would have said: this is naught but magic manifest.

# 797

And they say: wherefore hath not an angel been sent down unto him? Were We to send down an angel, the affair would have been decreed and they would not be respited.

# 798

And had We made him an angel, We would still have made him a man, and We would have confounded for them that which they are confounding.

# 799

And assuredly mocked were the apostles before thee, wherefore that whereat they scoffed beset these who had been mocking.

# 800

Say thou: go about in the earth and then see what wise hath been the end of the beliers.

# 801

Say thou: whose is whatsoever is in the heavens and the earth? Say thou: Allah's. He hath prescribed mercy for Himself. Surely He shall gather you together on the Day of Judgement whereof there is no doubt. Those who have lost themselves shall not believe.

# 802

His is whatsoever dwelleth in the night and the day; and He is the Hearer, the Knower.

# 803

Say thou: Shall I take for a patron any other than Allah, the Maker of the heavens and the earth! And He feedeth, and is not fed. Say thou: I am commanded that I be the first who submitteth himself, and that: be thou not of the associaters.

# 804

Say thou: verily fear, if disobey my Lord, the torment of a Mighty Day.

# 805

From whomsoever it is averted on that Day, upon him indeed He has had mercy; that is a supreme achievement.

# 806

If Allah touch thee with hurt there is no reverser thereof but he, and if he touch thee with good, then He is over everything Potent.

# 807

He is the Supreme above His creatures; and He is the Wise, the Aware.

# 808

Say thou: what thing is the greatest in testimony? Say thou: Allah is Witness between me and you, and this Qur'an hath been revealed unto me that I may thereby warn you and whomsoever it may reach. Would ye indeed testify that there is anot her god together with Allah? Say thou: I testify not. Say thou: verily He is the One God, and I am quit of that which ye associate.

# 809

Those whom We have vouchsafed the Book recognise him even as they recognise their own children. Yet those who have lost themselves will not believe.

# 810

And who is a greater wrong-doer than he who fabricateth a lie against Allah or belieth His signs? Verily the wrong-doers shall not fare well.

# 811

And let them beware the Day whereon We shall gather them all together; then We shall say unto those who associated: where are your associate-gods whom ye have been asserting?

# 812

Then they will have no excuse but to say: by God our Lord, we have not been associaters.

# 813

Behold! how they lied against themselves! and then failed them that which they had been fabricating.

# 814

And of them are some who hearken unto thee and We have set over their hearts veils lest they understand it, and in their ears heaviness, and though they see any sign they will not believe therein: in as much as when they come to thee, they dispute with thee. Then who disbelieve say: this is naught but the fables of the ancients.

# 815

And they prohibit others therefrom, and they withdraw therefrom, and they destroy not but their own souls while they perceive not.

# 816

And couldst thou see what time they shall be held over the Fire, and then they will say: would that we were sent back and now we shall not belie the signs of our Lord and we shall be of the believers.

# 817

Yea! manifest hath become unto them that which they were erst wont to hide. And were they sent back they would surely return to that which was prohibited to them, and verily they are perfect liars.

# 818

And they say: there is naught but our life of the world, nor are we to be raised.

# 819

And couldst thou see what time they shall be held before their Lord? He will say: is this not real? They will say: aye! by our Lord! He will say: taste then the torment for ye have been disbelieving.

# 820

Lost surely are those who belie their meeting with Allah, until when the Hour cometh on them on a sudden, and they will say: woe betide us, that we neglected it! - the while they will be bearing their burthens on their backs. Lo! vile is that which they shall bear.

# 821

And naught is the life of world but a play and a sport, and surely the abode of the Hereafter is better for those who fear. Reflect then ye not?

# 822

We know indeed that verily that which they say grieveth thee, but it is not thee they belie; it is the signs of Allah the wrong- doers gainsay.

# 823

And apostles have assuredly been belied before thee, but they patiently bare that wherefore they were belied, and they were hurt, until Our succour came to them. And none can change the words of Allah; and assuredly there hath come unto thee some tidings of the sent ones.

# 824

And if their backsliding is hard unto thee, then seek out, if thou canst, an opening into the earth or a ladder to the heaven that thou mayst bring unto them a sign. And had Allah willed, He would have assembled them unto the guidance; wherefore be not thou of the ignorant.

# 825

Only those respond who hearken. And as to the dead, Allah will raise them, and thereafter unto Him they shall be returned.

# 826

And they say: wherefore is not a sign sent down upon him from his Lord? Say thou: verily Allah is able to send down a sign, howbeit most of them know not.

# 827

And there is not an animal on the earth nor a fowl that flieth with its two wings but are communities like unto you. And We have not been remiss in respect of aught in the Book: then unto their Lord they shall be gathered.

# 828

And those who belie our signs are deaf and dumb, in darkness. Whomsoever Allah willeth He sendeth astray, and whomsoever He willeth He putteth on the right path.

# 829

Say thou: look ye now, were Allah's torment to come upon you, or the Hour come upon you, would ye then cry unto other than Allah, if ye are truthful?

# 830

Aye! unto Him alone ye would cry, and He would remove that where for ye cried unto Him, if He will, and ye would forget that which ye associate.

# 831

And assuredly We sent apostles unto communities before thee; then We laid hold of them with adversity and distress, that haply they may humble themselves.

# 832

Wherefore then did they not, when the affliction from us came upon them, humble themselves? But their hearts became hardened, and the Satan made fair-seeming unto them that which they were wont to do.

# 833

Then when they forgot that whereof they were reminded We opened upon them the doors of everything, until when they boasted of that which they were given, We laid hold of them on a sudden, and lo! they were dumbfounded.

# 834

Then the people who committed wrong were cut off completely. And all praise is unto Allah, the Lord of the worlds.

# 835

Say thou: look ye were Allah to take away your hearing and your sight and seal up your hearts, what god, other than Allah, shall bring them unto you? Behold! how variously We propound the signs, yet they turn aside.

# 836

Say thou look ye now, were Allah's torment to come upon you on a sudden or openly, would there be destroyed any but the wrong- doers?

# 837

And We send not the sent ones except as bearers of glad tidings and warners. Then whosoever believeth and amendeth, on such shell come no fear nor they shall grieve.

# 838

And those who belie Our signs-torment shall touch them for they have been transgressing.

# 839

Say thou: I say not unto you, that with me are the treasures of Allah, nor I know the Unseen, nor say unto you that I am an angel; I but follow that which hath been revealed unto me. Say thou: are the blind and the seeing equal? Will ye not then consider?

# 840

And warn thou therewith those who fear that they shall be gathered unto their Lord, when there shall be for them no patron nor intercessor beside Him; haply they may become God-fearing.

# 841

And drive not away those who call upon their Lord morning and evening, seeking His countenance. Not on thee is aught of their reckoning, nor on them aught of thine reckoning, so that thou mayest drive them away and thus become of the wrong-doers.

# 842

And Thus We have tried some of them by means of others, that they might say: are those they whom God hath favoured amongst us? Is not Allah the Best Knower of the thankful?

# 843

And when those who believe in Our signs come unto them, say thou: peace be on you; your Lord hath prescribed mercy for Himself; so that whosoever of you doeth an evil through Ignorance, then repenteth thereafter and amendeth, then verily He is Forgiving, Merciful.

# 844

And Thus We expound revelations so that the way of the culprits may be shown up.

# 845

Say thou: verily I am forbidden to worship those whom ye call upon beside Allah. Say thou: I shall not follow your vain desires, for then I shall be gone astray, and shall not remain of the guided.

# 846

Say thou: verily stand upon an evidence from my Lord, and ye belie it; not with me is that which ye fain would hasten on. The judgement is not but of Allah. He counteth the truth, and He is the Best of deciders.

# 847

Say thou: if that which ye fain would hasten on be with me, the affair would have been decided between me and you; and Allah is the Best Knower of you the wrong-doers.

# 848

And with Him are the keys of the unseen; none knoweth them but he. And He knoweth whatsoever is in the land and the sea. Not a leaf falleth but he knoweth it, nor a seed-grain groweth in the darkness of the earth, nor aught of fresh or dry but is in a Book luminous.

# 849

And He it is who taketh your souls by night, and knoweth that which ye earn by day. Then He raiseth you therein, that there may be fulfilled the term allotted. Thereafter unto Him shall be your return; and then He shall declare unto you that which ye have been working.

# 850

And He is the supreme over His creatures, and He sendeth guardians over you until when death cometh unto one of you Our messengers take his soul, and they fail not.

# 851

Then they all shall be taken back unto Allah, their true Master. Lo! His shall be the judgement. And he is the Most Swift of reckoners.

# 852

Say thou: who delivereth you from the darknesses of the land and the sea, when ye cry unto Him in humility and in secrecy: if He delivered us from this, we shall surely be of the thankful?

# 853

Say thou: Allah delivereth you therefrom and from every pain, yet ye thereafter associate.

# 854

Say thou: He is Able to stir up torment on you from above you or from beneath your feet or to confound you by factions and make you taste the violence of one anot her. Behold! how variously We propound the signs that haply they may understand.

# 855

And thy people belie it, while it is certain to befall. Say thou: I am not over you a trustee.

# 856

For every announcement is a set time; and presently ye shall know.

# 857

And when thou seest those who plunge in Our revelations keep away from them until they plunge in a discourse other than that; and if the Satan causeth thee to forget, then sit not thou, after the recollection, with the wrong-doing people.

# 858

And naught on their account shall be on those who fear but admonition that haply they also may become God-fearing.

# 859

And let those alone who have taken their religion as a play and a sport and whom the life of the world hath beguiled. And admonish thou them therewith lest a soul be given up to perdition for that which it hath earned, when for him there shall be no friend or intercessor beside Allah, and when if he offer every equivalent it shall not be accepted of him. Those are they who are given up to perdition for that which they have earned. For them shall be drink of boiling water and a torment afflictive, for they were wont to disbelieve.

# 860

Say thou: shall we call upon, beside Allah, that which can neither profit us nor hurt us, and shall we turn on our heels after Allah hath guided us, like unto one whom the Satans have be guiled to wander bewildered in the land, his: fellows calling him unto the right path: come unto us? Say thou: verily the guidance of Allah, that is the Guidance, and we are commanded to submit ourselves to the Lord of the worlds.

# 861

And that: establish prayer and fear Him; and it is He unto whom ye shall be gathered.

# 862

And it is He who hath created the heavens and the earth in truth. And the Day when He saith: be, it shall become. His saying is the Reality. And His will be the dominion the Day the Trumpet will be blown. Knower of the Unseen and the seen, is the Wise, the Aware.

# 863

And recall what time Ibrahim said unto his father Azar: takest thou idols for gods! Verily I see thee and thy people in error manifest.

# 864

And in this wise We showed unto Ibrahim the governance of the heavens and the earth, and that he might become of the convinced.

# 865

Then when the night darkened on him, he beheld a star. He said: this is mine Lord. Then when it set, he said. I love not the setting ones.

# 866

Then when he beheld the moon uprise, he said: this is mine Lord. Then when it set, he said: were it not that my Lord kept me guiding, surely I must have been of the erring people.

# 867

Then when he beheld the sun uprise, he said: this is mine Lord; this is the greatest. Then when it set, he said: O my people! verily I am quit of that which ye associate.

# 868

Verily I have set my countenance towards Him who hath created the heavens and the earth, upright, and am not of the associaters.

# 869

And his people contended with him. He said; contend ye with me concerning Allah when He hath surely guided me? I fear not that which ye associate with Him save aught that mine Lord may will. My Lord comprehendeth everything in His Knowledge. Will ye not then be admonished?

# 870

And how should I fear that which ye have associated, while ye fear not to have associated with Allah that for which He hath sent down unto you no warranty? Which, then, of the two parties, is more worthy of security, if ye but knew?

# 871

It is those who believe and confound not their belief with wrong doing. These! theirs is the security and they are the guided.

# 872

And this was Our argument which We vouchsafed unto Ibrahim against his people. We raise in degrees whomsoever We list; verily thy Lord is Wise, Knowing.

# 873

And We bestowed upon him Is-haq and Ya'qub: each one We guided. And Nuh We had guided afore, and of his progeny Da-ud and Sulaiman and Ayyub and Yusuf and Musa and Harun. And thus We recompense the well-doers.

# 874

And also Zakariyya and Yahya and Isa and llyas: each one was of the righteous.

# 875

And Ismai'l and Alyas'a and Yunus and Lut: each one of them We preferred above the worlds.

# 876

And also some of their fathers and their progeny and their brethren: We chose them and guided them onto the right path.

# 877

This is the guidance of Allah whereby He guideth whomsoever of His bondmen He listeth. And if they had associated, to naught would have come all that they were wont to work.

# 878

Those are they unto whom We vouchsafed the Book and judgement and prophethood. Wherefore if those disbelieve therein, We have surely entrusted its unto a people who are not disbelievers therein.

# 879

Those are they whom Allah had guided, so follow thou their guidance, Say thou: no hire I ask therefor; it is but an admonition unto the worlds.

# 880

And they estimated not Allah with an estimation due unto Him when they said: on no human being hath God sent down aught. Say thou: who sent down the Books wherewith Musa came, a light and a guidance unto mankind, which ye have made into separate parchments. Some of it ye disclose and much thereof ye conceal. And ye were taught that which ye knew not: neither ye nor your fathers. Say thou: Allah, and let them alone, sporting in their vain discourse.

# 881

And this is a Book We have sent down, blest, and confirming that which hath been before it. And it is sent that thou mayest warn thereby the mother of towns and those around it. And those who believe in the Hereafter believe in it, and they guard their prayer.

# 882

And who is a greater wrong-doer than one who fabricateth a lie against Allah, or saith: a Revelation hath came to me, whereas no Revelation hath come to him in aught, and one who saith: I shall send down the like of that which God hath sent down? Would that thou souldst see what time the wrong-doers are in the pangs of death while the angels are stretching forth their hands saying: yield up your souls; to-day ye will be awarded a torment of ignomity for that which ye have been saying of Allah other than the truth, and against His signs ye were wont to be stiff-necked.

# 883

And now ye are come unto us singly even as We had created you for the first time, and ye have left behind your backs that which We had granted unto you, and We see not along with you your intercessors who ye fancied were Our associates in respect of you as ye asserted. Now are the ties betwixt you severed and strayed from you is that which ye were wont to assert.

# 884

Verily Allah is the Cleaver of the seed-grain and the date- stone. He bringeth forth the living from the lifeless, and He is the Bringer-forth of the lifeless from the living. Such is Allah: whither away then are ye deviating?

# 885

The Cleaver of the dawn; and He hath appointed the night as a rest, and appointed the sun and the moon according to a reckoning that is the disposition of the Mighty, the Knowing.

# 886

And it is He who hath appointed for you the stars that ye may be guided thereby in the darknesses of the land and the sea. Surely We have expounded the signs unto a people who know.

# 887

And it is He who hath produced you from one person, and thenceforth provided for you an abode and a depository. Surely We have expounded the signs unto a people who understand.

# 888

And it is He who hath sent down rain from heaven and We have thereby brought forth growth of every kind, and thereout We have brought forth green stalks from which We bring forth close-growing seed- grain. And from the date-stone: from the spathe thereof come forth clusters of dates lowhanging; and gardens of grapes, and the olive, and the pomegranate, like unto one anot her and unlike. Look at the fruit thereof when it fruiteth and the reforming thereof. Verily therein are signs unto a people who believe.

# 889

And they have set up the genii as associates unto Allah, whereas He hath created them and they impute unto Him falsely without knowledge, sons and daughters. Hallowed be He, far above that which they ascribe!

# 890

Originator of the heavens and the earth! How should He have a son when there is for Him no spouse? And He hath created everything and He is Knower of everything.

# 891

Such is Allah, your Lord, There is no god but He, the Creator of everything: so worship Him. And He is unto everything a Trustee.

# 892

Sights comprehend Him not, and He comprehendeth all sights. And He is the Subtle, the Aware.

# 893

Surely there hath come unto you enlightenment from your Lord. Whosoever then shall see shall do so for his own soul, and whosoever blindeth himself shall do so to his own hurt. And say thou I am not over you a guardian.

# 894

And Thus We variously propound the revelation, and this is in order that they may say: thou hast studied, and that We may expound it to a people who know.

# 895

Follow thou that which hath been revealed unto thee from thy Lord: no god is there but He; and turn thou away from the associaters.

# 896

And had Allah willed, they had not associated. And We have not made thee a guardian over them nor art thou unto them a trustee.

# 897

Revile not those whom they invoke besides Allah, lest they may spitefully revile Allah without knowledge. Thus fair-seeming unto every community We have made their work. Then unto their Lord is their return, and then He will declare unto them that which they were wont to work.

# 898

And they swear by God with thee their solemn oaths that if there came unto them a sign they would surely believe therein. Say thou: signs are but with Allah; and what will make ye perceive that even if it came they will not believe?

# 899

And We shall turn aside their hearts and their eyesights, even as they believed not therein for the first time and We shall let them wander in their exorbitance perplexed.

# 900

And even thou We had sent down angels unto them, and the dead had spoken to them, and We had gathered together about them everything face to face, they were not such as could believe, unless Allah had so willed, but most of them speak ignorantly.

# 901

And in this wises have we appointed unto every prophet an enemy-- Satans of men and of genii inspiring to each other gilded speech as a delusion. And had thy Lord willed, they could not have done so; wherefore let thou alone if them and that which they fabricate.

# 902

And it is in order that the; hearts of those who believe not in the Hereafter might incline thereto, and that they might be pleased therewith, and that they might do that whereof they are the doers.

# 903

Say thou: shall I then seek as judge other than Allah, when it is He who hath sent down toward you the Book detailed? And those whom We vouchsafed the book know that it hath been revealed by thy Lord in truth; so be thou not of the doubters.

# 904

And perfected is the word of thy Lord in veracity and in justice. And none can change His words. And He is the Hearer, the Knower.

# 905

And if thou obeyedest most of those on the earth, they would lead thee astray from the way of Allah; they follow not but their fancy, and they only conjecture.

# 906

Verily thy Lord; He knoweth best whosoever strayeth from His path and He knoweth best the guided ones.

# 907

Wherefore eat of that whereon the name of Allah hath been pronounced, if ye are believers in His revelations.

# 908

And what aileth you that ye should not eat that whereon the name of Allah hath been pronounced while He hath surely detailed unto you that which He hath forbidden you, unless ye are driven thereto? Verily many lead others astray by their desires without knowledge. Verily thy Lord! He knoweth best the transgressors.

# 909

And leave the outside of sin and the inside thereof; verily those who earn sin, anon will they be requited for that which they were wont to do.

# 910

And eat not of that whereon the name of Allah hath not been pronounced; for verily that is a departure. Verily the Satans are ever inspiring their friends that they may wrangle with you; and were ye to obey them, verily ye shall become associaters indeed.

# 911

Is he who was dead, and We quickened him and appointed for him a light whereby he walketh among mankind, like unto him whose similitude is that he is in darknesses forth from which he cannot come? Even so is made fair-seeming to the infidels that which they are wont to do.

# 912

And even so we set up in every town the great ones as its sinners, that they may plot therein. And they plot not but against themselves, and they perceive not.

# 913

And whensoever there cometh unto them a sign, they say: we shall not believe until we are vouchsafed the like of that which is vouchsafed unto the apostles of Allah. Allah knoweth best wheresoever to place His apostleship. Anon shall befall those who have sinned vileness before Allah and severe chastisement for that which they were wont to plot.

# 914

So whomsoever Allah willeth that he shall guide, He expoundeth his breast for Islam; and whomsoever He willeth that he shall send astray, He maketh his breast strait, narrow, as if he were mounting up into the sky, thus Allah layeth the abomination on those who believe not.

# 915

And this is the path of thine Lord, straight. We have surely detailed the revelations unto a people who would be admonished.

# 916

For them is an abode of peace with their Lord; and He shall be their patron for that which they have been doing.

# 917

On the Day whereon He will gather them all together: O ye race of genii! surely much ye have gotten out of mankind. And their friends among mankind will say: our Lord! much use some of us made of others, and now we have reached the appointed term which Thou appointedest for us. He will say: the Fire shall be your habitation, therein ye shall be as abiders, save as Allah may will. Verily thy Lord is Wise, Knowing.

# 918

And thus We shall keep some of the wrong-doers close to others for that which they were wont to earn.

# 919

O ye race of genii and mankind came there not apostles unto you from amongst you recounting unto you My signs and warning you of your meeting of this Day? They will say: we bear witness against ourselves. The life of the world hath deluded them, and they shall bear witness against themselves that verily they had been infidels.

# 920

This is because thy Lord is not one to destroy a town for its wrong-doing while its people are unaware.

# 921

For all there will be degrees in accordance with that which they did, and thy Lord is not unaware of that which they do.

# 922

And thine Lord is Self-sufficient, the Owner of mercy. If He will, He can take you away, and make those succeed you, after you, whomsoever He will, even as He raised you from the seed of anot her people.

# 923

Verily that which ye are promised is sure to arrive, and ye cannot escape.

# 924

Say thou. O my people! go on acting in your way, verily I am going to act in my way, presently ye shall know whose will be the happy end of the abode; and verily the wrong-doers will not fare well.

# 925

And they'll appoint for Allah, of the tilth and cattle He hath produced, a portion, they say according to their fancy: this is for Allah, and: this for our associate-gods. Then, that which is for their associate-gods reacheth not Allah, while that which is for Allah reacheth their associate-gods; vile is the way they judge!

# 926

And even so their associate-gods have made fair seeming unto many of the associaters the slaying of their offspring, so that they may cause them to perish and that they may confound unto them their religion. And had Allah so willed, they would not have done it. Wherefore let thou alone them and that which they fabricate.

# 927

And they say according to their fancy: such cattle and tilth are taboo none shall eat thereof save whom we allow, and there are cattle whose backs are forbidden, and cattle over which they pronounce not the name of Allah: a fabrication against Him Anon He shall requite them for that which they were wont to fabricate.

# 928

And they say: whatsoever is in the bellies of such cattle is for our males alone and is forbidden unto our wives, and if it be born dead, then they all are partakers thereof. Anon He shall requite them for their attribution verily He is Wise, Knowing.

# 929

Surely lost are they who slay their offspring foolishly and without knowledge, and have forbidden that which Allah had provided for them: a fabrication against Allah: surely they have strayed and have not become guided ones.

# 930

And it is He who hath produced gardens, trellised and untrellised, and the date-palm and the corn of varied produce, and the olives and the pomegranates alike and unlike. Eat of the fruit thereof when it fruiteth, and give the due thereof on the day of its harvesting; and waste not; verily He approveth not the wasters.

# 931

And of the cattle He hath created beasts of burden and small ones. Eat of that which Allah hath provided for you; and follow not the foot-steps of the Satan; verily he is unto you a manifest foe.

# 932

He hath created eight pairs of the sheep a twain, and of the goats a twain. Say thou: is it the two males He hath forbidden or the two females, or that which the wombs of the two females contain? Declare unto me with knowledge, if ye are truth-tellers.

# 933

And of the camels He hath created a twain and of the oxen a twain. Say thou: is it the two males He hath forbidden or the two females, or that which the wombs of the two females contain? Were ye present when Allah enjoined this on you? Who then doth greater wrong than he who fabricateth a lie against Allah that he may lead people astray; verily Allah shall not guide a wrong-doing people.

# 934

Say thou: I find not in that which hath been revealed unto me aught forbidden unto an eater that eateth thereof, except it be carcass, or blood poured forth, or flesh of swine, for that verily is foul, or an abomination over which is invoked the name of other than that of Allah. Then whosoever is driven thereto, neither lusting nor transgressing, verily thy Lord is Forgiving, Merciful.

# 935

And unto those who are Judaised We forbade every animal with cloven hoof; and of the bullock and the goats We forbade unto them the fat thereof, save that which is borne on their backs or entrails or that which sticketh to the bone. Thus We requited them for their rebellion, and verily We are the Truthful.

# 936

So if they belie thee, say thou: Your Lord is Owner of extensive mercy, and His wrath shall not be turned aside from the guilty people,

# 937

Anon will those who associate had God willed, we would not say: have associated, nor our fathers; neither could we have forbidden aught. Even so belied those before them, until they tasted Our wrath. Say thou: is there with you any authority, that ye may bring unto us? ye but follow your fancy, and only conjecture.

# 938

Say thou: with Allah resteth the argument evident. Wherefore, had He so willed, He would have guided you all.

# 939

Say thou: here with your witnesses, those who will testify that Allah hath forbidden all this. Then even if they testify, testify thou not with them. And follow thou not the desires of those who belie Our signs and those who believe not in the Hereafter while they equalise others with their Lord.

# 940

Say thou: come, I shall recite that which your Lord hath forbidden unto you: associate not aught with Him, and shew kindness unto the parents, and slay not your offspring for fear of want - We it is who shall provide for you and them -and approach not indecencies, whatsoever is open thereof and whatsoever is concealed, and slay not anyone whom Allah hath forbidden except for justification. Thus He enjoineth you that haply ye may reflect.

# 941

And approach not the substance of an orphan save with that which is best until he attaineth his age of strength, and fill up the measure and balance with equity- We burthen not a soul except according to its capacity and when ye speak, be fair, even though it be against a kinsman; and the covenant of Allah fulfil. Thus He enjoineth you that haply ye may be admonished.

# 942

And that: verily this is my path, straight; follow it then, and follow not other ways; that will deviate you from His way. Thus He enjoineth you, that haply ye may fear God.

# 943

Then unto Musa We vouchsafed the Book perfect for him who would do well and detailing every thing and a guidance and a mercy, that haply in the meeting of their Lord they would believe.

# 944

And this is a Book We have sent down, blest, follow it then and fear God, haply ye may be shewn mercy.

# 945

Lest ye should say: the Book was only sent down to the two sects before us, and we in sooth were unaware of their readings.

# 946

Or lest ye should say. if only the Book had been sent down to us, we should surely have been better guided than they. So now surely there hath come unto you an evidence from Your Lord and a guidance and a mercy. Who then doth greater wrong than he who belieth the signs of Allah and shunneth them? Anon We will requite those who shun Our signs with an evil torment in as much as they were wont to shun them.

# 947

They await indeed that the angel should come unto them, or that thy Lord should come or that certain of the signs of thy Lord should come. On the Day whereon certain of the signs of thy Lord will come, belief will not profit any person who had not believed theretofore or had not earned any good by his belief. Say thou: so wait ye verily we also are waiting.

# 948

Verily those who have split their religion and become sects, thou art not amongst them in aught: their affair is only with Allah. Then He will declare unto them that which they were wont to do.

# 949

Whosoever will come with a virtue for him shall be then like thereof, and whosoever will come with a vice shall not be requited save with the like thereof; and they shall not be wronged.

# 950

Say thou as for me, my Lord hath guided me unto a straight path, a right religion, the faith of Ibrahim, the upright, and he was not of the associaters.

# 951

Say thou: verily my prayer and my rites and my living and my dying are all for Allah, Lord of the worlds.

# 952

No associate hath He. And to this I am bidden, and I am the first of the Muslims.

# 953

Say thou: shall seek a Lord other than Allah, while He is the Lord of everything? And no person earneth aught save against himself, and no bearer of burden shall bear anot her's burden. Thereafter Unto your Lord shall be your return, and He will declare unto you that wherein ye have been disputing.

# 954

And He it is Who hath made you successors in the earth, and hath raised some of you over others in degrees, that he might prove you by that which He hath vouchsafed unto you. Verily thy Lord is swift in chastising, and verily He is Forgiving, Merciful.

# 955

Alif-Lam-Mim-Suad,

# 956

This is a Book sent down toward thee: so let there be no straitness in thy breast therefor: that thou mayest warn thereby! and this is an admonition unto the believers.

# 957

Follow that which is sent down toward you from your Lord, and follow not any patrons beside Him; yet little ye are admonished.

# 958

And how many a township We have destroyed, upon them Our violence came at night or while they were taking their midday rest.

# 959

Then naught was their cry a when Our violence came upon them save that they said: verily we have been the wrong-doers.

# 960

Then We will surely question those to whom were the messengers sent, and We will surely question the sent ones.

# 961

Then surely We will recount unto them with knowledge, and We have not been absent.

# 962

And the weighing on that Day is certain, then whosesoever balances will be heavy, those! they shall fare well.

# 963

And whosesoever balances will be light - those are they who have lost themselves in respect of Our signs.

# 964

And assuredly We established you in the earth and appointed for you livelihoods therein; yet little thanks ye return.

# 965

And assuredly We created you, thereafter We fashioned you, and thereafter We said to the angels: prostrate yourselves before Adam; then they fell prostrate; not so Iblis: he was not of those who fell prostrate.

# 966

Allah said: what prevented thee, that thou shouldst not prostrate thyself, when I bade thee? He said. I am better than he; me Thou createdest me from fire, and him Thou createdest from clay.

# 967

Allah said: then get thee down from hence; not for thee is it to be stiff-necked herein. So go thou forth; verily thou art of the abject ones.

# 968

He said: respite me till the Day they shall be raised up.

# 969

Allah said: verily thou art of the respited.

# 970

He said: because Thou hast seduced me, I will beset for them Thy straight path.

# 971

Then surely I will come upon them from before them and from behind them and from their right and from their left, and Thou shalt not find the most of them thankful.

# 972

Allah said: go thou forth from hence, scorned, driven away. Whosoever of them followeth thee, I will of a surety fill Hell with you all.

# 973

And: O Adam: dwell thou and thy spouse in the Garden and eat ye twain thereof Whence ye will, and approach not yonder tree lest ye twain become of the wrong-doers.

# 974

Then the Satan whispered unto the twain in order that he might discover unto the twain that which lay hidden from the twain of their shame, and said: your Lord forbade you not vender tree but lest ye twain should become angels or become of the abiders.

# 975

And he sware unto them both: verily I am unto you of your good counsellors.

# 976

Thus with guile he caused the twain to fall. Then when the twain had tasted of the tree, their shame was discovered to them, and the twain began to cover themselves with leaves from the Garden; and their Lord called out unto the twain: forbade I not ye twain yonder tree, and said I not unto you, verily the Satan is unto you twain a manifest enemy?

# 977

The twain said. our Lord! we have wronged our souls, and if Thou forgivest us not and hath not mercy on us, we shall of a surety be of the losers.

# 978

Allah said: get ye down, one of you an enemy unto anot her; and for you on the earth there shall be a habitation and provision for a season.

# 979

Allah said: therein ye shall live and therein ye shall die, and therefrom ye shall be brought forth.

# 980

O Children of Adam! verily We have sent down unto you a garment covering your shame and as an adornment; and the garment of piety --that is the best. That is of the signss of Allah, that haply they may be admonished.

# 981

O Children of Adam! let not the Satan tempt you even as he drave forth your parents from the Garden, divesting the twain of their garment that he might discover unto the twain their shame. Verily he beholdeth you, he and his tribe, in such wise that ye behold them not. Verily We have made the Satans patrons of those only who believe not.

# 982

And when they commit an indecency, they say: we found our fathers thereon, and God hath enjoined it on us. Say thou. verily Allah enjoineth not an indecency; say ye falsely of Allah that which ye know not?

# 983

Say thou; my Lord hath enjoined equity, and that ye shall set your faces aright at every prostration, and call on Him, making religion pure for Him. Even as He began you; ye shall be brought back.

# 984

A part He hath guided, and upon a part the straying hath been justified. Verily they have taken the Satans as patrons instead of Allah and they imagine that they are guided ones.

# 985

O Children of Adam! take your adornment at every worship: and eat and drink, and waste not; verily He approveth not the wasters.

# 986

Say thou: who hath forbidden the adornment which Allah hath produced for His servants and the clean things of food? Say thou: these on the Day of Judgement, shall be for those alone who in the life of this world have believed. Thus We expound the signs unto a people who know.

# 987

Say thou: my Lord hath only forbidden indecencies the open thereof and the hidden thereof, and sin, and high-handedness without justice, and ye associate aught with Allah, for which He hath sent down no warranty, and that ye speak falsely of Allah that which ye know not.

# 988

And for every community there is an appointed term; then when its term shall arrive, not an hour will they stay behind or go in advance.

# 989

O Children of Adam! if there come unto you apostles from amongst you recounting My signs unto you, then whosoever shall fear God and amend, on them no fear shall come nor they shall grieve.

# 990

And those who shall belie Our signs and shall be stiff- necked against them--they shall be fellows of the Fire; therein they shall be abiders.

# 991

Who doth greater wrong than he who fabricateth a lie against Allah or belieth His sign? These: their full portion from the Book shall reach them until when Our messengers come unto them causing them to die, and say: where is that which ye were wont to call upon beside Allah? They will say: they have strayed from us. And they shall testify against themselves that they have been infidels.

# 992

Allah will say. enter the Fire among the communities who have passed away before you, of genii and mankind. So oft as a community will enter it, it shall curse its sister, until, when all shall have arrived one after anot her therein, the last of them shall say of the first of them: our Lord! these led us astray; so mete out unto them and double torment of the Fire, He will say: to each, double; but ye know not.

# 993

And the first of them will say unto the last of them: ye have then no preference over us; taste then the torment for that which ye were wont to earn.

# 994

Verily those who belie Our signs and are stiff-necked against them, for them will not be opened the portals of heaven, nor shall they enter the Garden until a camel passeth through the eye of a needle. And Thus We requite the guilty ones.

# 995

Their shall be a bed in Hell, and over them coverings; and Thus We requite the wrong-doers.

# 996

And those who believed and worked righteous works-We burthen not a soul except according to its capacity, they shall be fellows of the Garden; therein they shell be abiders.

# 997

And We shall extract whatsoever of rancour there may be in their breasts, rivers flowing beneath them, and they will say all praise unto Allah who hath guided us onto this; we were not such as to find guidance were it not that Allah had guided us; assuredly the aspotles of our Lord came with truth. And they shall be cried unto: this is the Garden, it ye inherit for that which ye have been working.

# 998

And the fellows of the Garden shall cry unto the fellows of the Fire: surely we have found true that which our Lord had promised us; have ye found true that which your Lord had promised you? They shall say: Yea! Then a Crier in-between them shall cry: the curse of Allah be upon the wrong-doers.

# 999

Those who turned away from the way of Allah and would seek to render it crooked and in the Herafter they were disbelievers.

# 1000

And betwixt the twain there will be a veil, and, on the heights will be men recognising them all by their mark, and they will cry unto the fellows of the Garden; peace be unto you! They will not have entered it yet, while they shall be longing.

# 1001

And when their eyes Will be turned toward the fellows of the Fire, they will say: our Lord! place us not with these wrong-doing people.

# 1002

And the fellows of the heights will cry unto the men whom they would recognise by their mark, and say: your multitude availed you naught nor that over which ye were wont to be stiff-necked.

# 1003

Are these the ones of whom ye sware that Allah would not reach them with His mercy? Unto them it hath been said enter the Garden; on you shall come no fear nor shall ye grieve.

# 1004

And the fellows of the Fire will cry unto the fellows of the Garden: pour out on us water or aught wherewith Allah hath provided you. They will say verily Allah hath forbidden it unto infidels.

# 1005

Who took their religion as a sport and a play and whom the life of the world beguiled. So today We will forget them even as they forget the meeting of this their Day and as they were ever gainsaying Our signs.

# 1006

And assuredly We have brought unto them a book which We have detailed according to knowledge a guidance and, mercy unto a people who believe.

# 1007

They await only its fulfilment. The Day whereon the fulfilment thereof arriveth, those who were negligent thereof afore shall say: surely the apostles of our Lord brought the truths; are there for us any intercessors that they might intercede for us? or could we be sent back that we may work otherwise than we were wont to work? Surely they have lost themselves, and there hath strayed from them that which they were wont to fabricate.

# 1008

Verily your Lord is Allah who created the heavens and the earth in six days, then established Himself on the Throne, making the night cover the day, seeking it swiftly, and created the sun and the moon and the stars subjected to service by His command. Lo! His is the creation and the command. Blessed is Allah, the Lord of the worlds.

# 1009

Call on Your Lord in humility and in secrecy; verily He approveth not the trespassers.

# 1010

And act not corruptly in the earth after the good ordering thereof, and call on Him fearing and longing; verily the mercy of Allah is nigh unto the well-doers.

# 1011

And it is He who sendeth forth the heralding winds before His mercy, until when they have carried a heavy-laden cloud We drive it unto a dead land and send down rain thereby and bring forth thereby all kinds of fruits. In this wise We will raise the dead; haply ye may be admonished.

# 1012

And a good land: its herbage cometh forth by the command of its Lord; and that which is vile, it cometh forth only scantily. In this wise We vary the signs for a people who return thanks.

# 1013

Assuredly We sent Nuh unto his people, and he said: O my people! worship Allah; no god ye have but He; verily I fear for you the torment of a mighty day.

# 1014

The chiefs of his people said: verily we see thee in error manifest.

# 1015

He said: O my people! not with me is the error, but I am an apostle from the Lord of the worlds.

# 1016

I preach unto you the messages of my Lord and I councel you good, and I know from Allah which ye know not.

# 1017

Marvel ye that an admonition from your Lord should come unto you upon a man from amongst yourselves, in order that the may warn you and that ye may fear, and that haply ye may be shewn mercy?

# 1018

Then they belied him; there upon We delivered him and those with him in the ark, and drowned those who belied Our signs; verily they were a people blind.

# 1019

And unto 'Ad We sent their brothers Hud. He said: O my people! worship Allah, no god ye have but He; Fear ye not?

# 1020

The chiefs of those who disbelived among his people said: verily we see thee in folly, and verily we deem thee to be of the liars.

# 1021

He said: O my people! not with me is folly, but I am an apostle from the Lord of the worlds.

# 1022

I preach unto you the messages of my Lord, and I am unto you a counseller faithful.

# 1023

Marvel ye that an admonition from your Lord should come unto you upon a Man from amongst you in order that he may warn you? Remember what time He made you successors after the people, of Nuh, and increased you amply in stature Remember the benefits of Allah, that haply ye may fare well.

# 1024

They said: art thou come unto us that we should worship God alone and leave that which our fathers were wont to worship? Bring thou then upon us that wherewith thou threatenest us if thou sayest sooth.

# 1025

He said: surely there have befallen you wrath and indignation from your Lord. Dispute ye with me over names ye have named, ye and your fathers, for which Allah hath sent down no warranty? Wait then; I also will be with you of those who wait.

# 1026

Then We delivered him and those with him by a mercy from Us, and We utterly cut off those who belied Our signs, and would not be believers.

# 1027

And unto Thamud We sent their brother, Salih He said: my people! worship Allah, no god ye have but He; surely there hath come unto you an evidence from your Lord. Yonder is the she-camel of Allah: a sign unto you; so leave her alone, pasturing on Allah's earth, and touch her not with evil, lest there seize you a torment afflictive.

# 1028

And remember what time He made you successors after 'Ad and inherited you in earth; ye take for yourselves palaces in the plains whereof and ye hew out the mountains as houses. Remember ye wherefore the benefits of Allah and commit not evil on the earth as corrupters.

# 1029

The chiefs of those who were stiff-necked amongst His people said unto those who were counted weak -unto such of them as believed: know ye that Salih is a sent one of his Lord? They said: verily we are believers in that wherewith he hath been sent.

# 1030

Those who were stiff-necked said: verily we are disbelievers in that which ye believe.

# 1031

Then they hamstrung the she camel and disdained the commandment of their Lord, and said: Salih! bring upon us that wherewith thou hast threatened us if thou art in sooth of the sent ones.

# 1032

Whereupon an earthquake seized them, so that they lay prone in their dwellings.

# 1033

Then he turned from them, and said: O my people! assuredly delivered unto you the messages of my Lord, and counselled you good, but ye approve not the good counsellors.

# 1034

And We sent Lut, when he said unto his people: commit ye an indecency wherewith none hath preceded you in the worlds?

# 1035

Verily ye go in lustfully unto men instead of women! Aye! ye are a people extravagant.

# 1036

And naught was the answer of his people save that they said: drive themforth from your city, verily they are a people who would be pure!

# 1037

Then We delivered him and his household, save his wife: she was among the lingerers.

# 1038

And We rained upon them a rain. So behold! what like was the end of the sinners.

# 1039

And unto Madyan We sent their brother Shu'aib. He said: O my people! worship Allah, no god ye have buthe; surely there hath come unto you an evidence from your Lord. So give full measure and weight, and defraud not people of their things, and act not corruptly on the earth after the ordering thereof; thatis best for you if ye be believers.

# 1040

And beset not every highway menacing and turning aside from the path of Allah those who believe in Him, and seeking to make it crooked. And remember when ye were small, and He thereafter multiplied you; and behold what like was the end of the corrupters.

# 1041

And if there be a party of you who believeth in that wherewith I am sent and a party who believeth not, then have patience until Allah judgeth between us, and He is the Best of judges.

# 1042

The chiefs of those who were stiff-necked amongst his people said: surely we shall drive you forth, Shu'aib! and those who have believed with thee from our city, or else ye shall return unto our faith. He said: what! even though we be averse!

# 1043

We must have been fabricating a lie against Allah if we returned to your faith after Allah hath delivered us therefrom. And it is not for us to return thereunto except that Allah our Lord so willed; everything our Lord comprehendeth in His knowledge; in Allah we place our trust. O our Lord! decide Thou between us and our people with truth, Thou art the Best of the deciders.

# 1044

And the chiefs of those who disbelieved amongst his people said: should ye follow Shu'aib, lo! verily ye will be the losers.

# 1045

Whereupon an earthquake laid hold of them: so that they lay prone in their dwelling.

# 1046

Those who belied Shu'aib became as though they had never dwelt therein; those who belied Shu'aib, it is they who became the losers.

# 1047

Then he turned from them, and said: my people! assuredly I delivered unto you the messages of my Lord, and counselled you good; how then should I lament over an unbelieving people?

# 1048

And We sent not a prophet to any township but We laid hold of the people thereof with tribulation and distress that haply they may humble themselves.

# 1049

Thereafter We substituted ease in place of adversity until they abounded and said: even Thus tribulation and prosperity touched our fathers. Then We laid hold of them of a sudden, while they perceived not.

# 1050

And had the people of those townships believed and feared, We would of a surety have opened up to them blessings from the heavens and the earth; but they belied, wherefore We laid hold of them for that which they had been earning.

# 1051

Are the people of the townships then secure that Our wrath would not come upon them at night while they are slumbering?

# 1052

Or, are the people of the township secure that Our wrath would not come upon them by daylight while they are disporting themselves?

# 1053

Are then they secure against the contrivance of Allah? And none feeleth secure against the contrivance of Allah except the people who are losers.

# 1054

Guideth it not those who inherit the land after the people thereof, that, had We willed, We would have afflicted them for their sins? And We have put a seal upon their hearts, so that they hearken not.

# 1055

Those townships! We recount unto thee some tidings thereof. Assuredly there came unto them their apostles with evidences, but they were not such as to believe that which they had erst belied. Thus doth Allah put a seal upon the hearts of the infidels.

# 1056

And We found no covenant in most of them; and most of them We found ungodly.

# 1057

Then We sent, after them, Musa with Our signs unto Fir'awn and his chiefs, but they wronged them. Behold that wise was the end of the corrupters!

# 1058

And Musa said: O Fir'awn! I am an apostle from the Lord of the worlds;

# 1059

Incumbent it is upon me that I speak naught respecting Allah save the truth; surely I have brought you an evidence from your Lord; wherefore let then go with me the Children of Isra'il.

# 1060

He said: if thou hast brought a sign, forth with it then, if thou art of the truth-tellers.

# 1061

Thereupon he cast down his rod, when, lo it was a serpent manifest.

# 1062

And he drew forth his hand, when lo: it was white unto the beholders.

# 1063

The chiefs of the people of Fir'awn said: verily this is a magician knowing.

# 1064

He would drive you forth from your land; so what is it that ye enjoin?

# 1065

They said: put him and his bro ther off, and send unto the cities callers.

# 1066

That they may bring to thee every magician knowing.

# 1067

And the magicians came unto Fir'awn. They said: surely there is for us a reward if we are the overcomers.

# 1068

He said: yea! and verily ye shall be of those brought nigh.

# 1069

They said: O Musa! either thou cast down, or we shall be the ones to cast down.

# 1070

He said: cast ye. Then when they cast clown, they enchanted the eyes of the people, and terrified them and brought mighty magic to bear.

# 1071

And we revealed unto Musa: cast down thy rod. And lo! it Was swallowing up that which they had feigned.

# 1072

Thus the truth prevailed, and that which they had brought vanished.

# 1073

Thus they were overcome and made to look abiect.

# 1074

And the magicians flung themselves prostrate.

# 1075

They said: we believe in the Lord of the worlds.

# 1076

The Lord of Musa and Harun.

# 1077

Fir'awn said:? believed ye in him ere I have given you leave? Verily this is a plot ye have plotted in the city that ye may drive forth the people thereof So presently ye shall know.

# 1078

Surely I will cut off your hands and feet on the opposite sides and thereafter I will crucify you all.

# 1079

They said: verily unto our Lord we are turning.

# 1080

And what is it for which thou takest vengeance on us save that we have believed in the signs of our Lord when they came unto us? Our Lord! pour out upon us perseverance and cause us to die as Muslims.

# 1081

And the chiefs of the people of Fir'awn said: wilt thou leave alone Musa and his people to act corruptly in the land and to leave alone thee and thy gods! He said: soon we shall slay their sons and let live their women, and we are masters over them.

# 1082

Musa said unto his people: seek help in Allah and persevere; verily the earth is Allah's; He maketh whomsoever He willeth of His bondmen inherit it, and the happy end is of the God-fearing.

# 1083

They said: oppressed we have been ere thou camest unto us and since thou hast come unto us. He said: belike your Lord will destroy your enemy and establish yougs in their stead in the land, thathe may see what wise ye act.

# 1084

And assuredly We laid hold of the people of Fir'awn with lean years and lack of fruits, that haply they might dread.

# 1085

So whenever good-hap came unto them, they would say: ours is this. And if a mishap afflicted them, they would lay it to the evil augury of Musa and these with him. Behold! their evil augury was only with Allah, but most of them knew not.

# 1086

And they said: whatsoever thou mayest bring unto us of the nature of a sign wherewith to enchant us, in thee we are not going to be believers

# 1087

Thereafter We sent upon them the flood, and the locusts, and the lice, and the frogs, and the blood: signs detailed; yet they remained stiff-necked and they, were a people sinful.

# 1088

And whensoever a plague fell on them, they said: O Musa! supplicate thy Lord for us, by that which He hath covenanted with thee; surely if thou remove the plague from us we will surely believe in thee, and we will send away with thee the Children of Israi'l.

# 1089

Then whensoever We removed the plague from them, till a term which they were to reach, lo! they were breaking faith.

# 1090

Wherefore We took vengeance on them and drowned them in the sea, for they belied Our signs and were neglectful of them.

# 1091

And We caused the people who had been oppressed to inherit the eastern parts of the land, and the western parts thereof, which We had blest. And fulfilled was the good word of thy Lord unto the Children of Isra'il' for they were long-suffering, and We destroyed that which Fir'awn and his people had builded and that which they had raised.

# 1092

And We led the Children of Isra'il across the sea. Then they came upon a people cleaving to the idols they had. T'hev said: Musa! make for us a god even as they have gods. He said: verily ye are a people given to ignorance.

# 1093

Verily these! destroyed is that wherein they are engaged and vain is that which they have been doing.

# 1094

He said: shall I seek for you a god other than Allah, whereas He hath preferred you above the worlds?

# 1095

And recall what time We delivered you from the house of Fir'awn perpetrating on you terrible torment, slaying your sons and letting your women live, and therein was a trial from your Lord, tremendous.

# 1096

And We treated with Musa thirty nights, and We completed them with ten; so the appointment of his Lord was completed by forty nights. And Musa said unto his brother Harun: act thou in my place among my people, and rectify, and follow not the way of the corrupters.

# 1097

And when Musa came at Our appointment, and his Lord spake unto him, he said my Lord! shew Thyself unto me, that I may look at Thee! He said: thou canst not see Me: but look at the yonder mount; if it stands in its place, then thou wilt see Me. Then when his Lord unveiled His glory unto the mount, it turned it to dust, and Musa tell down thunderstruck. Then when he recovered, he said: hallowed be Thou! I turn unto Thee repentant, and I am the first of the believers,

# 1098

He said: O Musa! verily I have chosen thee above mankind by My messages and by My speaking; so hold fast thou that which I have given thee, and be of the thankful.

# 1099

And We wrote for him in the tablets of everything an exhortation, and and a detail of everything. So hold thou fast with firmness, and bid thy people follow the best thereof anonl will shew you the dwelling of the ungodly people.

# 1100

I shall turn away from My signs those who are big with pride on the earth, without justice, and although they may see every sign, they will not believe therein; and if they see the path of rectitude they will not take it as their path, and if they see the path of error they will take it for their path. This is because they belied Our signs, and they were ever negligent thereof.

# 1101

And those who belie Our signs and the meeting of the Hereafter- vain shall be their Work. They shall be requited not save for that which they wrought.

# 1102

And ehe people of Musa, after him, took of their trinkets a calf: a body with a low. Saw they not that it spake nor unto them nor could guide them to a way? They took it, and became wrong-doers.

# 1103

And when they repented and saw that they had strayed, they said: if our Lord have not mercy on us and forgive us not, we shall surely be of the losers.

# 1104

And when Musa returned unto his people indignant and sorrowing, he said: ill is that which ye have acted as my successors, after me Anticipated ye the command of you Lord! And he cast down the tablets and took hold of the head of his brother dragging him unto himself. Aaron said: son of my mother! the people held me weak and well- nigh slew me, so cause not the enemies rejoice over me, and place me not with the wrong-doing people

# 1105

Musa said: O Lord! forgive me and my brother, and cause us twain to enter into Thy mercy, and Thou art the Most Merciful of the merciful.

# 1106

Verily those who took the calf, anon will overtake them indignation from their Lord and abasement in the life of the World. Thus We require the fabricators.

# 1107

And those who committed evils, and repented thereafter and believed --verily thy Lord is thereafter Forgiving, Merciful.

# 1108

And when the indignation of Musa was appeased, he took up the tablets, and in the inscription thereon were guidance and mercy unto these who dread their Lord.

# 1109

And Musa singled out of his people seventy men for Our appointment, then when the earthquake laid hold of them he said. O my Lord! hadst Thou willed, Thou wouldst have destroyed them afore and me also. wilt Thou destroy Us for that which the foolish ones amongst us have done! lt is only thy trial, whereby thou sendest astray whomsoever Thou wilt and keepest guided whomsoever Thou wilt. Thou art our patron. So forgive us Thou and have mercy on us; and thou art the Best of the forgivers.

# 1110

And ordain for us good in the world and in the Hereafter; verily we have been guided unto Thee. Allah said: as to My chastisement, therewith afflict whomsoever I Will and as to My mercy, it comprehendeth everything. Wherefore I shall ordain it for those who fear an give poor- rate and those who believe in Our signs.

# 1111

Those who follow the apostle, the unlettered prophet. Whom they find written down with them in the Taurat and the Injil; he biddeth them to the seemly and prohibiteth unto them the unseemly, alloweth unto them things clean and forbiddeth unto them things unclean and relieveth them of their burthen and the shackles which have been upon them. Those who believe in him and side with him and succour him and follow the light which hath been sent down with him; those: they shall fare well.

# 1112

Say thou: O mankind! verily I am the apostle of Allah unto you all- of Him whose is the dominion of the heavens and the earth. No god is there but he; He giveth life and causeth to die. Believe then in Allah and His prophet, the unlettered prcphet, who believeth in Allah and His words, and follow him that haply ye may be guided.

# 1113

And of the people of Musa there is a community guiding others by the truth and judging thereby.

# 1114

And We cut them up into twelve tribes as communities. And We revealed unto Musa, when his people asked him for drink: Smite the rock with thy rod. Then gushed forth therefrcm twelve springs: every people already knew their drinking-places. And We shaded them with thick clouds, and We sent down upon them the manna and the quails, saying: eat of the clean things wherewith We have provided you. And they wronged not Us, but themselves they were wont to wrong.

# 1115

And recall what time it was said unto them: dwell in yonder town and eat plentifully therefrom an ye list, and say: fergiveness, and enter the gate bowing; and We will forgive you your trespasses: anon We will increase unto the well-doers.

# 1116

Then those of them who did wrong changed the word that had been told them for anot her, whereupon We sent upon them a scourge from the heaven for they were wont to transgress.

# 1117

And ask thou them concerning the town that was close on the sea, when they transgressed in the matter of the sabt, when their fish came unto them openly on their sabt day, while they came not on the day whereon they kept not We proved them for the sabt. Thus they were wont to transgress.

# 1118

And recall what time a community of them said Why exhort ye a people whom Allah is going to destroy or chastise with a severe chastisenent They said: to justify us before your Lord, and that haply they may fear.

# 1119

Then when they forgot that wherewith they had been exhorted, We delivered those who restrained from evil, and We laid hold of those who did wrong with a distressing torment for they were wont to transgress.

# 1120

So when they exceeded the bounds of that which they were prohibited We said unto them: be ye apes despised.

# 1121

And recall what time thy Lord proclaimed that he would surely raise upon them, till the Day of Resurrection, someone perpetrating upon them worst oppression. Verily thy Lord is swift in chastising, and verily He is Forgiving, Merciful.

# 1122

And We cut them up into communities on the earth; some of them righteous, and some of them otherwise; and We proved them wifh good and evil that haply they may return.

# 1123

Then there succeeded them a posterity; they inherited the Book taking this near world's gear and saying surety it will be forgiven, And if there cometh unto them anot her gear like thereunto they shall take it. Hath there not lain upon them the bond of the Book that they shall not say of God aught but the truth? And they have read that which is therein. And the abode of the Hereafter is better for those who fear. Understand then ye not?

# 1124

And those who hold fast by the Book and establish prayer-- verily We shall not waste the hire of the rectifiers.

# 1125

And recall what time We shook the mountain over them as though it were a canopy, and they imagined that it was going to fall on them; and We said: hold with firmness that which We have vouchsafed you, and remember that which is therein, that haply ye may fear.

# 1126

And recall what time thy Lord took from the children of Adam their posterity from their backs, and made them testify as to them selves saying: am I not your lord? They said: Yea! we testify. That was lest ye should say on the Day of Resurrection verily of this we have been unaware.

# 1127

Or lest ye should say: it Was only our fathers who associated afore, and we have been a posterity after them; wilt Thou then destroy us for that which the followers of falsehood did?

# 1128

And Thus We detail the revelations, that haply they may return.

# 1129

And recite thou unto them the story of him Unto whom We vouchsafed Our signs, but he sloughed them off, wherefore the Satan followed him, and he became of the perverted.

# 1130

And had We willed We would surely have lifted him thereby, but he clung to the earth and followed his desire, wherefore his case became like unto the case of a dog, who, if thou attackest him, lolleth out his tongue and if thou leavest him alone, lolleth out his tongue. Such is the likeness of the people who belie Our sign; so recount thou the narratives, that haply they may refelect.

# 1131

Vile is the likeness of the people who belie Our signs, and their own souls they are wont to wrong.

# 1132

Whomsoever Allah guideth, he is the rightly guided: and whomsoever He sendeth astray - those! they are the losers.

# 1133

And assuredly We have created for Hell many of the genii and mankind; they have hearts wherewith they understand not, and they have eyes wherewith they see not, and they have ears wherewith they hearken not; they are like unto cattle; nay, they are further astray; those! they are the negligent ones.

# 1134

Allah's are the excellent names; so call on Him thereby; and leave alone those who profane His names. Anon will they be requitcd for that which they were wont to work.

# 1135

And of those whom We have created there is a community guiding others with truth and acting justly according thereto.

# 1136

And those who belie Our signs, step by step We lead them on in a way they know not.

# 1137

And I give them rein: verily My contrivance is firm.

# 1138

Reflect they not that in their companions there is no madness! he is naught but a manifest warner.

# 1139

Look they not at the governance of the heaven and the earth and whatsoever Allah hath created of aught, and at the fact that their term may have drawn nigh? In what discourse then will they, thereafter, believe!

# 1140

Whomsoever Allah sendeth astray, no guide is then for him, and He letteth them wander perplexed in their exorbitance.

# 1141

They ask thee concerning the Hour, when will its coming be? Say thou: knowledge thereof is with my Lord only: none shall disclose it at its time buthe; heavy it is in the heavens and the earth; it shall not come upon you except on a sudden. They ask thee as though thou wert familiar therewith. Say thou: knowledge thereof is with Allah only; but most of men know not.

# 1142

Say thou: I possess no power over benefit or hurt to myself save as Allah willeth; and had I knowledge of the unseen I would have amassed ample good, and evil would not have touched me. I am naught but a warner and a bringer of tidings unto a people who believe.

# 1143

He it is who created you from a single soul, and He created therefrom his spouse that he might find repose in her. Then when he covereth her she beareth a light burthen and fareth about there with; then when she groweth heavy the twain call upon Allah their Lord: if Thou vouchsafest us a goodly Child, we shall surely be of the thankful.

# 1144

But when He vouchsafeth the twain a goodly child they set up unto Him associates in respect of that which He hath vouchsafed to them. Exalted be Allah far from that which they associate!

# 1145

Associate they those who cannot create aught and are created?

# 1146

And who cannot succour them, nor can succour themselves.

# 1147

And if ye call them toward guidance they follow you not: it is the same to you whether ye call them or are silent.

# 1148

Verily those whom ye call upon beside Allah are creatures like unto you; so call on them, and let them answer you if ye say sooth.

# 1149

Have they feet wherewith they wend? Have they hands wherewith they grip? Have they eyes wherewith they see? Have they ears wherewith they hearken? Say thou: call upon your associate gods, and then plot against me and respite me not.

# 1150

Verily my protector is Allah who hath revealed the Book, and He protecteth the righteous.

# 1151

And those whom ye call upon be side Him cannot succour you nor them selves they can succour.

# 1152

And if ye Call them towards guidance they will not hear and thou wilt behold them looking at thee, but they see not.

# 1153

Use thou indulgence and enjoin seemliness and turn away from the ignorant.

# 1154

And if there prompt thee a prompting from the Satan, see refugee with Allah; verily He is Hearing, Knowing.

# 1155

Verily those who fear God when an instigation from the Satan toucheth them, they call to mind land lo! they are enlightened.

# 1156

And their brethren drag them on toward error, so they stop not short.

# 1157

And whenever thou bringest not unto them, as a sign, they say: wherefore hast not thou selected it? Say thou: I only follow that which hath been revealed unto me by my Lord. This is an enlightenment from your Lord and a guidance and a mercy unto a people who believe.

# 1158

So when the Qur'an is recited, listen thereto and keep silence, haply ye may be shewn mercy.

# 1159

And remember thou thy Lord within thyself with humility and fear, without loudness in word, in the morning and evenings; and be thou not of the negligent.

# 1160

Verily those who are with thy Lord are not stiff-necked against His woorship, and they hallow, and unto Him they prostrate themselves.

# 1161

They ask thee concerning the spoils of war. Say thou: the spoils of war are Allah's and the apostle's. So fear Allah, and set right the matter among you, and obey Allah and His apostle if ye are believers.

# 1162

The believers are only those whose hearts thrill with fear when Allah is mentioned, and when His revelations are rehearsed unto them, they increase their faith and who trust in their Lord.

# 1163

Who establish prayer and who expend of that wherewith We have provided them.

# 1164

Those: it is they who are the true believers. For them are degrees with their Lord and forgiveness and a provision honourable.

# 1165

This is like what time thy Lord had caused thee to go forthfrom thy house for a right cause, while a party among the believers were averse.

# 1166

Disputing with thee respecting the right cause after it had become manifest, as though they were led forth unto death while they looked on.

# 1167

And recall what time Allah was promising you one of the two parties that it should be yours, and ye would fain to have that the one without; Whilst Allah besought arms were yours to justify the truth by His words and to cut off the root of the infidels.

# 1168

In order that he might justify the truth and falsify the false even though the guilty ones were averse.

# 1169

And recall what time ye implored our Lord and He answered you: verily I am about to succour you with a thousand of angels rank in rank.

# 1170

And Allah made not this save as a glad tidings, and that your hearts might thereby be set at rest; and succour cometh not but from Allah. Verily Allah is Mighty, Wise.

# 1171

Recall what time He caused slumber to cover you as a security from Himself, and He sent down rain upon you from heaven that he might cleanse you thereby and take away from you the pollution of the Satan, and that he might gird up your hearts and make your feet firm thereby.

# 1172

And recall what time thy Lord inspired the angels: verily I am with you, so keep firm those who have believed; will cast horror into the hearts of those who have disbelieved, so smite them above the neck and smite of them every fingertip.

# 1173

This, because they have resisted Allah and His apostle; and whosoever resisteth Allah and His apostle, then verily Allah severe in retribution.

# 1174

This! taste it then, and know that for the infidels is the torment of the Fire.

# 1175

O Ye who believe! whenever ye those who disbelieve matching meet slowly turn to them not your backs.

# 1176

And whosoever turneth his back to them on such a day, unless it be swerving to a fight or wriggling round to anot her company, hath surely drawn upon himself indignation from Allah, and his resort is Hell--an evil destination!

# 1177

Wherefore ye slew them not, but Allah slew them, and thou thrtwest not, When thou threWest, but Allah threw, in order that he might prove the believers with a goodly proving from Him. Verily Allah is Hearing, Knowing.

# 1178

Thus! And know that Allah weakenoth the contrivance of infidels.

# 1179

If ye besought a judgement then surely a judgement hath come unto you. And if ye desist it Will be better for you; and if ye return. We will return; and your host shall avail you not, although numerous it be; and know that verily Allah is with the believers.

# 1180

O Ye who believe! obey Allah and His apostle and turn not away therefrom while ye hearken.

# 1181

And be not like unto those who say: we hear, whereas they hearken not.

# 1182

Verily the vilest of beasts with Allah are the deaf and dumb who understand not.

# 1183

And had Allah known in them any good He would surely have made them hearken; and even if He made them hear, they would surely turn away as backsliders.

# 1184

O Ye who believe! answer Allah and the apostle when he calleth you to that which quickeneth you, and know that verily Allah interposeth between a man and his heart, and that verily unto Him ye all shall be gathered.

# 1185

And fear the trial that shall not afflict those alone who among you do Wrong; and know that verily Allah severe in chastising.

# 1186

And remember what time ye were few and downtrodden in the land fearing that the people would snatch you away; then He gave you refuge and strengthened you with His succour, and provided you with good things that haply ye might return thanks.

# 1187

O Ye who believe! defraud not Allah and the apostle, nor defraud your trusts while ye know.

# 1188

And know that your riches and your children are but a temptation, and that verily Allah: with Him is a mighty hire.

# 1189

O Ye who believe! if ye fear Allah He will make for you a distinction and will expiate for you your misdeeds, and forgive you; and Allah is Owner of Mighty Grace.

# 1190

And recall what time those who disbelieved were plotting against thee to confine thee or to slay thee or to drive thee forth: they were plotting and Allah was plotting, and Allah is the Best of plotters.

# 1191

And when Our revelations are rehearsed unto them, they say: we have heard; we could if we willed, surely say something the like thereof; naught is this but fables of the ancients.

# 1192

And recall what time they said: O God! if this indeed be the truth from before Thee, then rain down stones upon us from heaven or bring on us a torment afflictive.

# 1193

And Allah is not one to chastise them whilst thou art in their midst, nor was Allah going to chastise them while they were asking forgiveness.

# 1194

And what aileth them that Allah should not chastise them when they are hindering people from the Sacred Mosque, whereas they are not even the keepers thereof - its keepers are none but the God-fearing-- but most of them know not.

# 1195

And naught was their prayer at the House but whistling and hand-clapping. Taste then the torment for ye were to disbelieve.

# 1196

Verily those who disbelieve are expending their riches in order to hinder People from the way of Allah; so they will go on expending them; thereafter they shall become an anguish unto them; then they shall be overcome. And those who disbelieve shall be gathered for Hell.

# 1197

In order that Allah may distinguish the vile from the good; and the vile He shall place one upon anot her, and shall pile it all together, and shall place it into Hell. Those! it is they who are the losers.

# 1198

Say thou unto those who have disbelieved: if they desist, that which is past shall be forgiven them, and if they return, then already gone forth is the dispensation of the ancients.

# 1199

And fight against them until there be no temptations and their obedience be wholly unto Allah. So if they desist, thens verily Allah is the Beholder of that which they do.

# 1200

And if they turn away, then know that Allah is your Patron: excellent Patron! and excellent helper!

# 1201

And know that whatsoever ye obtain of spoils then verily unto Allah belongeth a fifth thereof and unto the apostle and unto his kindreds and the orphans and the needy and the wayfarer if ye indeed have believed in Allah and that which We sent down on our bondmans on the day of distinction, the day whereon the two hosts met. And Allah is over everything Potent.

# 1202

And recall what time ye were on the hither side and they were on the yonder side and the caravan below you. And if ye had mutually appointed ye would surely have failed the appointment. But the action wao brought about in order that Allah may decree an affair already enacted, so that he who was to perish, should perish after an evidence and he who was to remain alive may remain alive after an evidence. And verily Allah is Hearing, Knowing.

# 1203

And recall what time Allah shewed them few unto thee in thy dream. And had He shewn them numerous unto thee, surely ye would have flagged and surely ye would have disputed over the affair but Allah saved you. Verily He is the Knower of that which is in the breasts.

# 1204

And recall what time He shewed them few in your eyes when ye met and lessened you in their eyes in order that Allah might decree an affair already enacted; and unto Allah are all affairs returned.

# 1205

O Ye who believe! when ye meet a party, stand firm and remember Allah much, that haply ye may fare well.

# 1206

And obey Allah and His apostle, and dispute not, lest ye flag and your predominance depart, and be patient. Verily Allah is with the patient

# 1207

And be not like unto those who came forth from their homes vaunting and to be seen of men and hindering others from the way of Allah; and Allah is the Ecompasser of that which they work.

# 1208

And recall what time the Satan made their works fair- seeming unto them and said: there is none of mankind to overcome you to- day, and verily I am your neighbour. Then when the two parties faced each other, he turned on his heels, and said: verily I am quit of you, verily I behold that which ye behold not; verily I fear Allah: and Allah severe in retribution.

# 1209

And recall what time the hypocrites and these in whose hearts was a disease said: their religion hath be gulfed those. And whosoever relieth on Allah then verily Allah is Mighty, Wise.

# 1210

And couldst thou behold when the angels take away the life of those who disbelive striking their faces and their backs: taste the torment of burning.

# 1211

This, because of that which your hands have sent forth, and verily Allah is never unjust unto His creatures.

# 1212

Like are they unto the wont of the house of Fir'awn and those before them. They disbelieved in the signs of Allah, wherefore Allah laid hold of them for their sins. Verily Allah is strong, Severe in retribution.

# 1213

This, because Allah is not one to change His favour wherewith He hath favoured a people until they have changed that which is in themselves; and verily Allah is Hearing, Knowing.

# 1214

Like are they Unto the wont of the house of Fir'awn and those before them. They belied the signs of their Lord; wherefore We destroyed them for their sins, and drowned the house of fir'awn; and all of them were wrong-doers.

# 1215

Verily the vilest of moving creatures with Allah are those who disbelieve-wherefore they shall not believe-

# 1216

They with whom thou covenantedest, then they break their covenant every time, and they fear not.

# 1217

Wherefore if thou over-takest them in war, disperse thou through them those behind them, that haply they may be admonished.

# 1218

And shouldst thou fear treachery from any people cast back then unto them their covenant to be equal. Verily Allah approveth not the treacherous.

# 1219

Let not those who disbelieve deem that they have escaped, verily they cannot frustrate.

# 1220

And get ready against them whatsoever ye can of force and wellfed horses whereby ye may overawe the enemy of Allah and your enemy and others besides them whom ye know not Allah knoweth them. And whatsoever ye expend in the way of Allah shall be repaid to you in full; and ye shall not be wronged.

# 1221

And if they incline unto peace, then thou mayest incline thereunto, and rely thou on Allah; verily He is the Hearer, the Knower.

# 1222

And if they seek to deceive thee, then verily Allah is sufficient unto thee. He it is who aided thee with His succour and with the believers.

# 1223

And He united their hearts. Hadst thou expended all that is on the earth thou couldst not have united their hearts, but Allah united them; verily He is Mighty, Wise.

# 1224

0 Prophet! sufficient unto thou is Allah and those who follow thee of believers.

# 1225

0 Prophet! urge the believers unto fighting. If there be twenty of you persevering, they will overcome two hundred, and if there be of you a hundred, they will overcome a thousand of those who disbelieve, for they are a people who understand not.

# 1226

Now Allah hath lightened your burden, and He knoweth that verily there is in you a weakness. So if there be a hundred of you persevering, they will overcome two hundred, and if there be a thousand of you they will overcome two thousand, by the command of Allah and Allah is with the persevering.

# 1227

It behoveth not a prophet that he should have captives until he hath greatly slaughtered in the land. Ye seek the gear of the world, while Allah seeketh the Hereafter; and Allah is Mighty, Wise.

# 1228

Were it not that a writ had already gone forth from Allah, there would surely have touched you a mighty torment for that which ye took

# 1229

Eat ye then of that which ye have obtained of spoi1, lawful and clean, fear Allah; verily Allah is Forgiving, Merciful

# 1230

O Prophet! say Unto the captives who are in your hands: if Allah knoweth any good in Your hearts He will give you better than that which hath been taken away from you, and shall forgive you; and Allah is Forgiving, Merciful.

# 1231

And if they seek defrauding thee, then they have defrauded Allah before, yet he gave thee power over them; and Allah is Knowing, Wise.

# 1232

Verily those who believed and emigrated and strave hard in the way of Allah with their riches and lives'and those who sheltered and succoured: those shall be heirs unto one anot her. And those who believed but emigrated not, ye have naught of inheritance to do with them, unless they emigrate. And should they seek succour from you in the matter of religion, then incumbent on you is the succour, except against a people between whom and you there is a compact. And Allah is the Beholder of that which ye work.

# 1233

And those who disbelieve: they shall be heirs unto one anot her. if ye do this not, a sedition there will be in the land and a great corruption.

# 1234

And those who believe and have emigrated and striven hard in the way of Allah, those who sheltered and succoured --these! they are the believers in very truth; for them shall be forgiviness and honourable provision.

# 1235

And those who believed after wards and emigrated and strave hard along with you: these also are of you; and the kindred by blood are nearer unto one anot her in Allah's decree; verily Allah is of everything the Knower.

# 1236

Quittance is this from Allah and His aposle unto the associators with whom ye had covenanted.

# 1237

Go about, then, in the land for four months. And know that verily ye cannot escape Allah, and that verily Allah is the humiliator of the infidels.

# 1238

And a proclamation is this from Allah and His apostle unto the mankind on the day of the greater pilgrimage that Allah is quit of the associators, and so is His apostle. Wherefore if ye repent, it shall be better for you, but if ye turn away, then know that ye cannot escape Allah. And announce thou unto those who disbelieve a torment afflictive.

# 1239

Except those of the associators with whom ye covenanted and they have not failed you in aught, nor have they backed up anyone against you; so fulfil unto them their covenant till their full period. Verily Allah loveth the Godfearing.

# 1240

When, therefore, the sacred months have slipped away, slay the associators's wheresoever ye find them and capture them and beset them and lie in wait for them at every ambush. Then, should they repent and establish prayer and give the poor-rate, leave their way free. Verily Allah is Forgiving, Merciful.

# 1241

And should one of the associators seek protection of thee grant him protection, that he may hear the word of Allah, then let him reach his place of security. That is because they are a people who know not.

# 1242

How can there be for the associators covenant with Allah. and His apostle save for those with whom ye covenanted near the Sacred Mosque? Act straight with them so long as they act straight with you. Verily Allah loveth the God-fearing.

# 1243

How indeed! whereas if they get the better of you they respect not regarding you either kinship or agreement. They please you with their mouth, the while their hearts refuse; and most of them are Ungodly.

# 1244

They have bartered the revelations of Allah for a small price, so they keep back from His path. Verily vile is that which they have been working.

# 1245

They respect not either kinship or agreement in a believer: those! they are the transgressors!

# 1246

If they repent and establish prayer and give the poor- rate, then they are your brethren-in-faith. And we detail the revelations unto a people who know.

# 1247

And if they violate their oaths after their covenant and revile your religion, fight those leaders of infidelity-verily no oaths will hold in their case that haply they may desist.

# 1248

Will ye not fight a people who have violate their oaths and resolved the expulsion of the apostle and who began against you for the first time? Fear ye them? Allah is more worthy that ye should fear Him, if ye are believers.

# 1249

Fight them. Allah will torment them at your hands, and humiliate them and give you victory over them and heal the breasts of the believing people.

# 1250

And He will take away the rage of their hearts. And Allah will relent toward whomsoever He liketh; and Allah is Knowing, Wise.

# 1251

Deem ye that ye would be left alone while yet Allah hath not known those of you who have striven hard and have not taken an ally besides Allah and His apostle and the believers? And Allah is Aware of that which ye work.

# 1252

It is not for the associators that they shall tend Allah's mosques, while giving evidence of infidelity against themselves. Those! vain shall be their works, and in the Fire they shall be abiders.

# 1253

They only shall tend Allah's mosques who believe in Allah and the Last Day and establish prayer and give the poor rate and fear none save Allah. Belike those will be of the guided ones.

# 1254

Make ye the giving of drinks unto the pilgrims and the tendance of the Sacred Mosque like unto the conduct of one who believeth in Allah and the Last Day and striveth hard in the way of Allah! Equal they are not with Allah, and Allah guideth not the wrong-doing people.

# 1255

Those who have believed and emigrated and have striven hard in the way of Allah with their riches and their lives are for higher in degree with Allah. Those! they are the achievers.

# 1256

Their Lord giveth them glad tidings of a mercy from Him and of goodwill and of the Gardens wherein theirs will be a delight lasting:

# 1257

As abiders therein for evermore. Verily Allah: with Him is a hire mighty.

# 1258

O Ye who believe! take not your fathers and your brothers for friends if they love infidelity above faith. Whosoever of you then befriendeth them then those! they are the wrong-doers.

# 1259

Say thou: if you fathers and your sons and your brothers and your wives and your family and the riches ye have acquired and the traffic wherein ye fear a slackening and the dwellings which please you are dearer unto you than Allah and His apostle and striving in His cause, then wait until Allah bringeth about His decree, and Allah guideth not the ungodly people.

# 1260

Assuredly Allah hath succoured you on many fields and on the day of Hunain, When your number elated you; then it availed you naught, and the earth, wide as it is, straitened unto you; then ye turned away in retreat.

# 1261

Thereafter Allah sent down His calm upon His apostle and upon the believers, and He sent down hosts ye saw not and tormented those who would disbelieve: such is the meed of the infidels.

# 1262

Then Allah will, thereafter, relent toward whomsoever He liketh, and Allah is Forgiving, Merciful.

# 1263

O Ye who believe! the associators are simply filthy; so let them not approach the Sacred Mosque after this their year; and if ye fear poverty, Allah shall presently enrich you out of His grace, if He will. Verily Allah is grace. Knowing, Wise.

# 1264

Fight against those who believe not in Allah nor in the Last Day and hold not that forbidden which Allah and His apostle have forbidden and observe not the true religion, of those who have been vouchsafed the Book, until they pay the tribute out of hand and they are subdued.

# 1265

And the Jews say: Uzair is a child of God; and the Nazarenes say: the Masih is a child of God. That is their saying with their mouth, resembling the saying of those who disbelieved aforetime. May Allah confound them'. whither are they turning away!

# 1266

They have taken their priests and their monks for their Lords besides God, and also the Masih son of Maryam; whereas they Were commanded not but to worship the One God: no god is there but he. Hallowed be He from that which they associate'.

# 1267

They seek to extinguish the light of Allah with their mouths; and Allah refuseth to do otherwise than perfect His light, although the infidels may detest.

# 1268

He it is who hath sent His apostle with the guidance and the true religion that he may make it prevail over all religions, although the associators may detest.

# 1269

O Ye who believe! verily many of the priests and the monks devour the substances of men in falsehood and hinder People from the way of Allah. And those who treasure up gold and silver and expend them not in the way of Allah -announce thou unto them a torment afflictive.

# 1270

On a Day whereon they Shall be heated in Hell-Fire, and therewith shall be branded their foreheads and their sides and their backs: this is that which ye treasured up for yourselves, so taste now that which ye have been treasuring up.

# 1271

Verily the number of months with Allah is twelve months ordained in the writ of Allah on the day whereon He created the heavens and the earth; of these four sacred: that is the right religion. Wherefore wrong not yourselves in respect thereof. And fight the associators, all of them even as they fight all of you; and knew that Allah is with the God-fearing

# 1272

The postponement is but an addition unto infidelity, whereby the infidels are led astray, allowing it one year and forbidding it anot her year, that they may make up the number which Allah hath sanctified; and then they allow that which Allah hath forbidden. Made fair-seeming unto them is the vileness of their works; and Allah guideth not an infidel people.

# 1273

O Ye who believe! what aileth you that when it is said unto you: march forth in the way of Allah, ye are weighed down earthward? Are ye pleased with the life of the world rather than the Hereafter? whereas the enjoyment of the life of the world by the side of the Hereafter is but little.

# 1274

If ye march not forth, He will torment you with a torment afflictive, and will substitute for you a people-other than you; and Him ye cannot hurt in aught; and Allah is over everything Potent.

# 1275

If ye succour him not, then surely Allah hath succoured him when these who disbelieved drave him: the second of the two When the twain were in a cave, and when he Said unto his companion. grieve not, verily Allah is with Us. Then Allah sent down His calm upon him and aided him with hosts whom ye saw not, and made the word of those who disbelieved nethermost, and the word of Allah! that is the upper most. And Allah is Mighty, wise,

# 1276

March forth light and heavy and strive hard with your riches and your lives in the way of Allah; that is the best for you, if ye have knowledge.

# 1277

Were there a gear nigh and a journey moderate, they would have surely followed thee, but the distance seemed far unto them. And anon they will be swearing by Allah: if only we could we would surely have come forth with you. They destroy their own souls: and Allah knoweth that verily they are liars.

# 1278

Allah pardon thee! why didst thou give them leave before it was manifest unto thee as to whosoever told the truth and thou hadst known the liars.

# 1279

Those who believe in Allah and the Last Day would not ask thy leave to be excused from striving hard with their riches and their lives; and Allah is Knower of the God-fearing.

# 1280

It is only those who believe not in Allah and the Last Day and whose hearts doubt who ask thy leave, so in their doubt they are tossed to and fro.

# 1281

And had they intended the going forth, they would have made some preparation therefor; But Allah was averse to their wending, wherefore He withheld them, and the word was passed: stay of home with the stay-at-homes.

# 1282

Had they gene forth with you, they would have added unto you naught save unsoundness, and they would surely have hurried about in Your midst seeking sedition unto you; and amongst you there are listeners to them; and Allah is Knower of the wrong-doers.

# 1283

Assuredly they besought sedition afore and turned the affairs upside down for thee until the truth arrived and the decree of Allah prevailed, averse though they were.

# 1284

And of them there is he who saith: give me leave, and tempt me not. Lo! into temptation they are already fallen, and verily the Hell is the encompasser of the infidels.

# 1285

If good befalleth thee, it annoyeth them, and if an affliction befalleth thee, they say; surely we took good hold of our affair before. And they turn away while they are exulting.

# 1286

Say thou: naught shall ever befall us save that which Allah hath ordained for us; He is our patron, and on Allah let the believers rely.

# 1287

Say thou await ye for us ought save one of the two excellences; while for you we wait that Allah shall afflict you with a torment from Himself or at our hands. Await then, we also are with you awaiting.

# 1288

Say thou: expend willingly or unwillingly, it will not be accepted of you; verily ye are ever a people ungodly.

# 1289

And naught preventeth their expendings being accepted except that they have disbelieved in Allah and His apostle, and they perform not prayer except as sluggards and expend not except as those averse.

# 1290

Let not wherefore their riches and their children amaze thee. Allah intendeth only to torment them therewith in the life of the world and that their souls pass away while they are infidels.

# 1291

And they swear by Allah that they are surely of you, whereas they are not of you; but they are a people who dread.

# 1292

Could they find a place of refuge or caverns or a retreating hole, they would turn round thereto rushing headlong.

# 1293

And of them are some who traduce thee in respect of alms. Then if they are given thereof they are pleased and if they are not given thereof, lo! they are enraged.

# 1294

Would that they were pleased with that which Allah and His apostle had given them, and were to say: sufficient unto us is Allah, anon Allah will give us out of His grace and so will His apostle, verily unto Allah we lean.

# 1295

The compulsory alms are only for the poor and the needy and the agents employed therein and those whose hearts are to be conciliated and those in bondage and debtors and for expenditure in the way of Allah and for the wayfarer: an ordinance from Allah: and Allah is Knowing, Wise.

# 1296

And of them are some who vex the prophet and say: he is all ears Say thou: he is all ears unto good for you, believing in Allah and giving credence to the believers and a mercy unto those of you who believe. And those who vex the apostle of Allah, unto them shall be a torment afflictive.

# 1297

They swear unto you by Allah that ye be pleased, whereas wortheir are Allah and His apostle that they should please Him, if they be believers indeed.

# 1298

Know they not that whosoever shall oppose Allah and His apostle, verily for him shall be Hell-Fire wherein he shell be an abider? That is a mighty humiliation.

# 1299

The hypocrites apprehend lest a Surah should be revealed unto them declaring unto them that which is in their hearts. Say thou: mock on! verily Allah is about to bring out that which ye apprehend.

# 1300

Shouldst thou question them, they will surely say:: we were only plunging about and playing. Say thou: was it Allah and His signs and His apostle that ye have been mocking?

# 1301

Make no excuse. Of a surety ye are disbelieving after declaring your faith. If, party of you We shall Opardon, anot her party We shall torment for they have remained sinners.

# 1302

The hypocritical men and the hypocritical women are all of a piece; they command that which is disreputable and restrain from that which is reputable, and they tighten their hands. They neglected Allah, so He had neglected them. Verily the hypocrites! they are the ungodly ones.

# 1303

Allah hath promised the hypocritical men and hypocritical women and unto the open infidels Hell-Fire, wherein they shall be abiders: sufficient is that unto them. And Allah shall accurse them, and theirs shall be a torment lasting.

# 1304

Like ye are unto those before you: mightier were they than you in prowess and more abundant in riches and children. They enjoyed their portion awhile, so enjoy your portion awhile even as those before you enjoyed their portion awhile, and ye plunged about even as they plunged about. Those! their works have come to naught in the world and the Hereafter, and those! they are the losers.

# 1305

Have not come to them the tidings of those before them: the people of Nuh and 'Ad and Thamud and the people of Ibrahim and the dwellers of Madyan and of the overturned cities! There came unto them their apostles with evidences. Wherefore Allah was not one to wrong them, but themselves they were wont to wrong.

# 1306

And the believing men and believing women are friends one unto anot her: they command that which is reputable and restrain from that which is disreputable, and establish prayer and give the poor-rate and obey Allah and His apostle. Those! Allah will surely show mercy to them; verily Allah is Mighty, Wise.

# 1307

Allah hath promised the believing men and believing women Gardens whereunder rivers flow, wherein they shall be abiders, and goodly dwellings in the Everlasting Gardens --and goodwill from Allah is the greatest ofall--that! it is the achievement supreme.

# 1308

O Prophet! strive hard against the infidels and the hypocrites; and be severe unto them. And their resort is Hell--a hapless destination.

# 1309

They swear by Allah that they said it not, but assuredly they said the word of infidelity and disbelieved after their Profession of Islam and they resolved that to which they could not attain. And they avenged not except for this that Allah and His apostle had enriched them out of His grace. If then they repent, it will be better for them, and if they turn away, Allah will torment them with an afflictive torment in the world and the Hereafter, and theirs shall be on the earth no friend nor helper.

# 1310

And of them are some who covenanted With saying: if He giveth of His grace, we will surely give alms and we will surely become of the righteous.

# 1311

Then when He gave them out of His grace, they became niggardly therewith and turned away as backsliders.

# 1312

So He chastised them with setting hypocrisy in their hearts until the Day they shall meet Him, because they kept back from Allah that which they had promised Him, and because they were wont to lie.

# 1313

Knew they not that Allah knoweth their secret and their Whisper, and that Allah is the Knower of Things Hidden!

# 1314

These are they who traduce those who give alms cheerfully, from among the believers, and those who find not anything to give but their hard earnings: at them they scoff. Allah shall scoff back at them. and theirs shall be a torment afflictive.

# 1315

Ask thou forgiveness for them or ask thou not forgiveness for them: if thou askest forgiveness for them seventy times, Allah will forgive them not. This, because they disbelieved in Allah and His apostle, and Allah guideth not an ungodly people.

# 1316

Those who were left rejoiced at their staying behind the apostle of Allah, and they detested to strive hard with their riches and their lives in the way of Allah, and they said: march not forth in the heat. - Say thou: hotter still is the Hell-Fire. Would that they understood!

# 1317

Little then let them laugh, and much they shall weep: the meed of that which they have been earning.

# 1318

If, then, Allah bring thee back to a party of them, and they ask leave of thee for going forth, say thou: never ye shall go forth with me, nor ever fight an enemy with me; verily ye were pleased with sitting at home the first time, wherefore sit now with those who stay behind.

# 1319

And pray thou not ever over any of them that may die nor stand thou over his grave. Verily they have disbelieved in Allah and His apostle and died while they were ungodly.

# 1320

And let nor their riches and their children amaze thee. Allah intendeth only to torment them therewith in the world, and that their souls may pass away while they are infidels.

# 1321

And whenever any Surah is sent down commanding: believe in Allah and strive hard in the company of His apostle, the opulent among them ask leave of thee, and say: leave us; we shall be with those who stay.

# 1322

Pleased are they that they should be with the women sitters-at-home, and their hearts are sealed up, so they understand not.

# 1323

But the apostle and those who believed in his company strave hard with their riches and their lives. These are they for whom are goods, and these: they are the blissful.

# 1324

For them Allah hath gotten ready Gardens whereunder rivers flow, wherein they shall be as abiders. That is the supreme achievement.

# 1325

And there came the apologists from among dwellers of the desert men praying that leave may be given them and those Who had lied unto Allah and His apostle sat at home. An afflictive torment shall afflict those of them who disbelieve.

# 1326

Not on the feeble and the ailing nor on those who find not the where withal to expend there is any blame, when they wish well to Allah and His apostle. No way is there against the well-doers; and Allah is Forgiving, Merciful.

# 1327

Nor on those who, when they came unto thee that thou mightest mount them and thou saidst: I find not any animal to mount you on, turned back while their eyes overflowed with tears for grief that they could not find ought to expend.

# 1328

The way is only against those who ask leave of thee while they are rich. They are pleased that they should be with the women sitters-at-home. Allah hath sealed up their hearts, so they know not.

# 1329

They will excuse themselves unto you when ye return to them. Say thou: excuse not yourselves, we shall by no means believe you: Allah hath already declared unto us some tidings of you, and Allah will behold your work and so will His apostle; and thereafter ye will be brought back unto Him who knoweth the hidden and the manifest, who will then declare unto you that which ye have been working.

# 1330

They will indeed swear unto you by Allah when ye return to them that ye may avert from them. So avert from them: verily they are an abomination, and their resort is Hell--a recompense for that which they have been earning.

# 1331

They will swear unto you in order that ye may be well- pleased with them. Then if ye are well-pleased with them, verily Allah will not be well-pleased with an ungodly people.

# 1332

The dwellers of the desert are the hardest in infidelity and hypocrisy and likeliest not to know the ordinances of that which Allah hath sent down unto His apostle. And Allah is Knowing, Wise.

# 1333

And of the dwellers of the desert is one who taketh that which he expen deth as a fine, and waiteth for evil turns of fortune for you. Upon them shall be the evil turn of fortune. And Allah is Hearing, Knowing.

# 1334

And of the dwellers of the desert is one who believeth in Allah and the Last Day, and taketh that which he expendeth as approaches unto Allah and the blessings of His apostle. Lo! verily these are an approach for them; anon Allah will enter them into His mercy. Verily Allah is Forgiving, Merciful.

# 1335

And the Muhajirs and Ansar, the leaders and the first ones and those who followed them in well-doing, --well-pleased is Allah with them, and well pleased are they with Him, and He hath gotten ready for them Gardens where under the rivers flow, as abiders therein forever. That is the achievement supreme.

# 1336

And of the dwellers of the desert around you some are hypocrites, and so are some of the people of Madinah; they have become inured to hypocrisy thou knowest them not, We know them. We will torment them twice, and thereafter they shall be brought back to a torment terrible.

# 1337

And others have confessed their faults; they have mixed up a righteous work with anot her vicious. Bellike Allah will relent toward them; verily Allah is Forgiving, Merciful.

# 1338

Take thou alms out of their riches; thereby thou wilt cleanse them and purify them; and pray thou for them. Verily thy prayer is a repose for them; and Allah is Hearing, Knowing.

# 1339

Know they not that it is Allah who accepteth the repentance of His bondmen and taketh the alms, and that it is Allah who is the Relenting, the Merciful!

# 1340

And say thou: work on! Allah beholdeth your work and so do His apostle and the believers, and anon ye will be brought back to the Knower of the hidden and the manifest; He will then declare unto you that which ye have been working.

# 1341

And others are awaiting the decree of Allah, whether He shall torment them or whether He will relent toward them; and Allah is Knowing, Wise.

# 1342

And as for those who have set up a mosque for hurting and blaspheming and the causing of division among the believers and as a lurking-place for one who hath warred against Allah and His apostle aforetime, and surely; they will swear: we intended only good, whereas Allah testifieth that they are liars.

# 1343

Thou Shalt never stand therein. Surely a mosque founded from the first day on piety is wortheir that thou shouldst stand therein. In it are men who love to cleanse themselves: and Allah approveth the clean.

# 1344

Is he, then, who hath founded his building upon piety towards Allah and His good-will better, or he who hath founded his building on the brink of a crumbling bank, so that it crumbleth with him into the Hell-fire! And Allah guideth not the wrong-doing people.

# 1345

And their building which they have builded will not cease to be a cause of doubt in their hearts unless it be that their hearts are cut asunder; and Allah is Knowing, Wise.

# 1346

Verily Allah hath bought of the believers their lives and their riches for the price that theirs shall be the Garden: they fight in the way of Allah and slay and are slain: a promise due thereon in the Taurat, in the Injil - and the Qur'an-and who is more faithful unto his covenant than Allah? Rejoice wherefore in your bargain which ye have made. And that it is the mighty achievement.

# 1347

They are those who repent, who worship who praise, who fast constantly, woo bow down, who prostrate themselves, who command the reputable and restrain from the disreputable and who keep the ordinances of Allah; and bear thou glad tidings to the believers.

# 1348

It is not for the Prophet and those who believe to ask for the forgiveness of the associators, although they be of kin after it hath become manifest unto them that they are the fellows of the Flaming Fire.

# 1349

And Ibrahim's asking for the forgiveness of his father was only in pursuance of a promise which he had made unto him. Then, when it became manifest unto him that he was an enemy of Allah, he declared himself quit of him. Verily Ibrahim was long-suffering, forbearing.

# 1350

Allah is not one to leed a people astray after He hath guided them until He hath made manifest unto them that which they should guard against. Verily Allah is of everything the Knower.

# 1351

Verily Allah! His is the dominion of the heavens and the earth. He giveth life and He causeth to die; and for you there is, besides Allah, no protector or helper.

# 1352

Assuredly Allah hath relented toward the Prophet and the Muhajirs and the Ansar who followed him in the hour of distress after the hearts of a part of them had well-nigh swerved aside when He relented toward them. Verily He is unto them Tender, Merciful.

# 1353

And also He relented toward the three who were left behind until when the earth, vast as it is, became straitened unto them and their own lives became straitened unto them and they imagined that there was no refuge from Allah except unto Him. Thereafter He relented toward them, so that they might repent. Verily Allah! He is the Relenting, the Merciful.

# 1354

O Ye who believe! fear Allah, and be with the truthful.

# 1355

It was not for the people of Madina and those around them of the desert dwellers that they should lay behind the apostle of Allah, nor that they should prefer themselves before him. That is because there afflicteth them not thirst or fatigue or hunger in the way of Allah or they tread a place trodden on enraging the infidels, nor they attain an attainment from the enemy, but a good deed is thereby written down unto them. Verily Allah wasteth not the hire of the well-doers.

# 1356

And they expend not an expending, small or great, or transverse a vale, but it is written down unto them, so that Allah may recompense them with the best for that which they have been working.

# 1357

And it is not for the believers to march forth all together. So why should not a band from each party of them march forth so that they may gain understanding in religion and that when they come back unto them, haply they might warn their people when they come back unto them, haply they may beware!

# 1358

O Ye who believe! fight the infidels who are near unto you, and surely let them find in you sternness, and know that Allah is with the God-fearing,

# 1359

And whenever a Surah s sent down, there are some of them who say which of You hath this increased in faith! As for those who believe, it hath increased them in faith, and they rejoice.

# 1360

And as for those in whose hearts is a disease, unto them it hath increased pollution to their pollution, and they die while they are infidels.

# 1361

Behold they not that they are tried every year once or twice? Yet they repent not, nor are they admonished.

# 1362

And whenever a Surah is sent down they look on at each other as though saying: observeth you anyone? Thereafter they turn to go; Allah hath turned their hearts, for verily they are people who understand not.

# 1363

Assuredly there hath come unto you an apostle from amongst yourselves: heavy upon him is that which harasseth you, solicitous for you, and with the believers tender and merciful.

# 1364

If, then, they turn away, say thou: sufficing unto me is Allah, there is no god but he, on Him I rely and He is the Lord of Mighty Throne.

# 1365

Alif-Lam-Ra. These are the verses of the Wise Book.

# 1366

It is a matter of wonderment to the mankind that we should reveal unto a man among them saying: warn thou the man kind, and bear those who have believed the glad tidings that theirs shall be a sure footing. with their Lord! The infidels say: verily this in a sorcerer manifest.

# 1367

Verily your Lord is Allah who hath created the heavens and the earth in six days, then established Himself on the Throne disposing the affair; no in tercessor is there, except after His leave. That is Allah, your Lord; so worship Him. Would ye then not be admonished!

# 1368

Unto Him is the return of you all--the promise of Allah is truth. Verily He beginneth the creation, then He shall repeat it, that he may recompense those who believed and did righteous works with equity. And those who disbelieved -- for them shall be draught of boiling water and a torment afflictive for they were wont to disbelieve.

# 1369

He it is who hath made the sun a glow and the moon a light, and hath determined mansions for her that ye may know the number of the years and the reckoning Allah hath not created all this except with a purpose; He detaileth these signs unto those who know.

# 1370

Verily in the alteration of he night and the day and in that which Allah hath created in the heavens and the earth are surely signs unto a people who fear.

# 1371

Verily those who hope not for meeting with us, and, well- pleased with the life of the world, and are satisfied therewith, and those who are neglectful of our signs.

# 1372

These! their abode shall be the Fire, for that which they have been earning.

# 1373

Verily those who believe and do righteous works, their Lord will guide them because of their faith. Beneath them will flow rivers in Gardens of Delight.

# 1374

Their cry therein will be: hallowed be Thou! O Allah! and their greeting therein: peace! And the end of their Cry Will be: all praise unto Allah, the Lord of the worlds

# 1375

And were Allah to hasten the ill unto mankind as their desire for hastening the good, their term would surely have been decreed unto them. So we let alone those who hope not for the meeting with Us, wandering in their exorbitance perplexed.

# 1376

And when harm toucheth man, he calleth us on his side, or sitting or standing; then when We have removed his harm from him, he passeth on as though he had never called Us to a harm that touched him. In this wise is made fairseeming unto the extravagant that which they have been working.

# 1377

And assuredly We have destroyed the generations before you when they did wrong, while their apostles came unto them with the evidences, and they were not such as to believe. In this wise We requite the sinning people.

# 1378

Then We appointed you as successors in the land after them, that We might see how ye would work.

# 1379

And whenever Our manifest revelations are rehearsed unto them, those who hope not for the meeting with Us, say: bring us a Qur'an other than this, or change it. Say thou: it lieth not with me to change it of my own accord; I only follow that which is Revealed unto me; verily I fear, if I disobey my Lord, the torment of the Mighty Day.

# 1380

Say thou: had Allah so willed. Would not have rehearsed it unto you, nor would He have acquainted you therewith. Of a surety I have tarried among you a lifetime before it. Would ye not then reflect?

# 1381

Who then is a greater wrong doer than he who fabricateth a lie against Allah or belieth His revelations? Verily He will not let the culprits fare well.

# 1382

And they worship, beside Allah, that which harmeth them not, nor profiteth them, and they say: these are our intercessors with God: Say thou: apprise ye Allah of that which He knoweth not in the heavens nor in the earth? Hallowed be He and Exalted far above that which ye associate!

# 1383

And mankind were not but a single ccmmunity then they differed. And had not a word from thy Lord gone forth, it would have been decreed between them in respect of that wherein they differ.

# 1384

And they say: wherefore is not a sign sent down unto him from his Lord! Say thou: the Hidden belongeth unto Allah alone; so wait, verily I am with you among those who wait.

# 1385

And when We let mankind taste of mercy after an adversity hath touched them, forthwith they have a plot with regard to his signs. Say thou: Allah is swifter in plotting. Verily Our mesengers write down that which ye plot.

# 1386

He it is who enableth you to travel by land and sea until when ye are in ships and they run away with them with a goodly wind and they rejoice thereat, there cometh upon them a tempestuous wind and there cometh unto them a billow from every side, and they imagine that they are encompassed therein, they cry unto Allah making there faith pure for Him: If Thou deliverest us from this. we would surely be of those who are thankful.

# 1387

Then when He delivereth them. they forthwith rebel in the earth without justice. O ye! your rebellion is only against yourselves: a brief enjoyment of the life of the world; thereafter unto Us is Your return; then We will declare unto you that which ye have been working.

# 1388

The similitude of the life of the world is only as the rain which We send down from heaven, wherewith maingleth the growth of the earth, of which men and cattle eat, until, when the earth putteth on her oranament and is adorned, and the inhabitants thereof imgine that they are potent over it, there cometh unto it Our command by night or by day, then We make it stubble as though it had not flourished yesterday. Thus We detail the signs unto a people who ponder.

# 1389

And Allah calleth unto the abode of peace and guideth whomso ever He will to the right path.

# 1390

Unto those who have done good is the good (reward) and an increase: neither darkness nor abjection will cover their faces. These are the fellows of the Garden: therein they will be abiders.

# 1391

And those who have earned misdeeds -the requital of a misdeed is the like thereof and abjection will cover them; no protector they shall have from Allah, though their faces were over cast with pieces of night pitch-dark. These are the fellows of the Fire: therein they will be abiders.

# 1392

Remember the Day whereon We shall gather them together, then We shall say un to those who associated: keep your place, ye and your associate gods. Then We shall cause split between them: and their associate-gods will say: it was not us that ye were worshipping.

# 1393

And God sufficieth as witness between you and us, of your worship, we have been ever unaware.

# 1394

Therein every soul shall prove that which it sent before, and they shall be brcught back to Allah, their rightful Owner, and there shall stray from them that which they were wont to fabriCate.

# 1395

Say thou: who provideth for you from the heaven and the earth, or who owneth the hearing and the sight, and who bringeth forth the living from the lifeless and bringeth forth the lifeless from the living, and who disposeth the affair! They will then surely say: Allah. Say thou: will ye not then fear Him?

# 1396

Such is Allah, your rightful Lord. What then is there after the truth but error? Whither away then are ye drifting!

# 1397

In this wise is the word of thy Lord justified on those who transgress: that they shall not come to believe.

# 1398

Say thou: is there any of your associate-gods who originateth the creation and then repeateth it? Say thou: Allah originateth the creation and then shall repeat it. Whither away then are ye deviating?

# 1399

Say thou: is there any of your associate-gods who guideth you to the truth! Say thou: Allah guideth unto the truth. Is He, then, who guideth to the truth more worthy to be followed, or one who findeth not the guidance unless he is guided. What aileth ye then? How ill ye judge!

# 1400

And most of them follow naught but an opinion; verily opinion availeth not against the truth; verily Allah is the Knower of that which they do.

# 1401

And this Qur'an is not such as could be fabricated as against Allah. But it is a confirmation of that a which is before it, and and a d etailing of the Decree, whereof there is no doubt, from the Lord of the worlds.

# 1402

Say they: he hath fabricated it! Say thou: then bring ye a Surah like thereunto, and call whomsoever ye can beside Allah, if ye say sooth.

# 1403

Aye! they have belied that of which the knowledge they comprehended not and of which the fulfilment hath not come to them. Likewise belied those who were before them; behold then in what wise hath been the end of the wrongdoers.

# 1404

And of them are some who will believe therein, and of them are some who will not believe therein; and thy Lord is the Best Knower of the corrupters.

# 1405

And if they belie thee, say thou: unto me my work, and unto you your work: ye are quit of that which I work and am quit of that which ye work.

# 1406

And of them are some who hearken unto thee, so canst thou make the deaf hear, even though they apprehend not?

# 1407

And of them are some who look at thee, so canst thou guide the blind, even though they see not?

# 1408

Verily Allah wrongeth not mankind in aught but mankind wrong themselves.

# 1409

And of the Day whereon He shall gather them, as though they had tarried not save an hour of he day they shall mutually recognize. Lost surely are those who belie the meeting with Allah and they were not such as to be guided.

# 1410

And whether We shew thee soome of that which We have promised them, or We cause thee to die, Unto us is their return, and Allah is witness of that which they do.

# 1411

And for each community there hath been sent an apostle; and when their apostle hath arrived, the matter between them is decreed in equity, and they are not wronged.

# 1412

And they say: when cometh this promise, if ye say sooth?

# 1413

Say thou: I own not any power of hurt or benefit unto myself, save that which Allah may will. For each community is a term; when their term hath arrived, not an hour can they stay behind nor can they advance.

# 1414

Say thou: bethink ye, if His torment come on you by night or by day which Portion thereof would the culprlts hasten on?

# 1415

Is It, then, when it hath befallen, that ye will believe therein Now?- whereas ye have surely been hastening it On.

# 1416

Thereafter, it will be said unto those who wronged themselves: taste the torment everlasting: ye are requited not save for that which ye have been earning.

# 1417

And they ask thee to tell them if it be-true. Say thou: yeal by my Lord, It, Is the veary truth, and ye shall not be able to escape.

# 1418

And if every one that hath wronged had all that is in the earth, surely he would ransom himself therewith. And they shall conceal remorse when they behold the torment, and the matter will be decreed between them in equity, and they shall not be wronged.

# 1419

Lo! verily Allah's is whatsoever is In the heavens and the earth, Lo! verily Allah's promise is true; but most of them know not.

# 1420

He giveth life and causeth to die, and unto Him ye shall be returned.

# 1421

O Mankind! now there hath come unto you an exhortation from your Lord and a healing for that which is in Your breasts, and a guidance and a mercy for the believers.

# 1422

Say thou: in the grace of Allah and in His mercy--therein let them therefore rejoice: far better it is than that which they amass.

# 1423

Say thou: bethink ye of that which Allah hath sent down unto you of provision, and ye have then made thereof allowable and forbidden? Say thou: is it that Allah hath given you leave, or fabricate ye a lie against Allah?

# 1424

And what imagine those who fabricate a lie against Allah of the Day of Resurrection? Verily Allah is the owner of grace unto mankind, but most of them return not thanks.

# 1425

Thou art not engaged in any business, nor dost thou recite any part of the Qur'an, nor ye work any work, but We are witnesses over you when ye are engaged therein. And there escapeth not thy Lord the weight of an ant in the earth or the heavens, nor less than that nor greater, but it is in a Book luminous.

# 1426

Lo! verily the friends of Allah! no fear shall come upon them nor shall they grieve.

# 1427

They who believed and have been fearing God;

# 1428

Unto them is glad tidings in the life of the world and in the Hereafter. No changing is there in the words of Allah. That! it is the mighty achievement.

# 1429

And let not their saying grieve thee. Verily honour is Allah's wholly. He is the Hearer, the Knower.

# 1430

Lo! verily Allah's is whosoever is in the heavens and whosoever is on the earth. And what is it that they who call unto associate-gods beside Allah follow They follow but an opinion, and they are but conjecturing.

# 1431

He it is who hath appointed for you the night that ye may repose therein and the day enlightening. Verily in that are signs for a people who listen.

# 1432

They say: God hath taken a son. Hallowed be He-He, the selfesufficient! His is whatsoever is in the heavens and whatsoever is in the earth. No warranty is there with you for this. Ascribe ye falsely unto Allah that which ye know not?

# 1433

Say thou: verily those who fabricate a lie against Allah shall not fare well.

# 1434

A brief enjoyment in the world; then unto Us is their return; then We will make them taste a severe torment, in that they have been disbelieving.

# 1435

And rehearse thou unto them the story of Nuh, when he said unto his people: O my people! if my standing forth and my admonishment with the commandments of Allah be hard upon you, then on Allah I rely; so devise your affair, ye and your associate-gods and let not your affair be dubious unto you, then have it decreed against me, and respite me not.

# 1436

If then ye turn away, I have asked of you no hire, my hire is only with Allah, and I am commanded to be of those who submit.

# 1437

So they belied him; then We delivered him and those with him in the ark, and We made them successors, while We drowned those who belied Our signs. Behold then what like hath been the end of those who were warned.

# 1438

Then, We raised after him other apostles to their people, and they brought them evidences, but they were not such as to believe that which they had belied afore. Thus We seal the hearts of the transgressors.

# 1439

Then, after them, We raised Musa and Harun unto Fir'awn and his chiefs with Our signs, but they grew stiff-necked and they were a people guilty.

# 1440

Then when there came unto them the truth from Us, they said: verily this is magic manifest.

# 1441

Musa said: say ye this of the truth after it hath come unto you? Is this magic? and the magicians fare not well.

# 1442

They said: art thou come unto us to turn us aside from that faith whereon We found our fathers, and that the greatness in the land shall be unto you twain! And for the sake of you twain we are not going to be believers.

# 1443

And Firawn said: bring unto me every magician knowing.

# 1444

Then when the magicians were come, Musa said unto them: cast down that which ye are going to cast down.

# 1445

Then when they had cast down, Musa said: that which ye have brought is magic, verily Allah will soon make it vain; verily Allah setteth not right the work of the corrupters.

# 1446

And Allah justifieth the truth according to His words, even though the culprits may detest.

# 1447

Then none believed in Musa save a posterity of his people, through fear of Fir'awn and their chiefs, lest he should persecute them; and verily Fir'awn was lofty in the land, and verily he was of the extravagant.

# 1448

And Musa said: my people! if ye have been believing in Allah, then on Him rely, if ye are muslims.

# 1449

So they said: on Allah We rely, our Lord! make us not a trial for the wrong-doing people.

# 1450

And deliver us in Thine mercy from the disbelieving people.

# 1451

And We Revealed unto Musa and his brother: inhabit houses for your people in Misr, and make your houses a place of Worship, and establish prayer, and give glad tidings to the believers.

# 1452

And Musa said: our Lord! verily Thou! Thou hast vouchsafed unto Fir'awn and his chiefs adornment and riches in the life of the world, Our Lord, that they may lead men astray from Thine way. Our Lord! wipe out their riches, and harden their hearts, so that they may not believe until they behold the torment afflictive.

# 1453

Allah said: surely the petition of you twain is accepted, so keep straight on, and follow not the path of those who know not.

# 1454

And We led the Children of Isra'il across the sea; then Fir'awn and his hosts pursued them in rebellion and enmity, until, when the drowning over-took him, he said: I believe that verily He! there is no god but he, in whom the Children of Isra'il believe, and am of the Muslims.

# 1455

Now indeed! whereas thou hast rebelled afore, and wast of the corrupters.

# 1456

So this day We deliver thee in thy body that thou mayest be a sign unto those after thee, and verily many of mankind are of our signs neglectful.

# 1457

And assuredly We settled the Children of Isra'il into a secure settlement, and We provided them with good things; nor they differed until there had come unto them the knowledge. Verily thine Lord shall judge between them on the Day of Resurrection as to that wherein they have been differing.

# 1458

And if thou be in doubt concerning that which We have sent down unto thee, then ask those who have read the Books before thee. Assuredly hath the truth come unto thee from thy Lord, so be not then of the doubters.

# 1459

And be not thou of those who belie Allah's signs, lest thou be of the losers.

# 1460

Verily those on whom the word of thy Lord hath been justified shall not believe.

# 1461

Even though every sign should come unto them, until they hehold an afflictive torment.

# 1462

Why then was there not a township which believed, so that its faith might have profited it, except the people of Yunus! When they believed, We removed from them the torment of humiliation in the life of the world, and We let them enjoy for a season.

# 1463

And had thy Lord willed, those who are on the earth would have believed, all of them, together; canst thou then compel mankind until they become believers?

# 1464

It is not for any soul that it should believe save with Allah's will, and He layeth the abomination upon those who reflect not.

# 1465

Say thou: behold that which is in the heavens and the earth; and signs and warnings avail not those who will not believe.

# 1466

Wait they then aught but the days of those who have passed away before them. Say thou: wait then, verily I am with you among those who wait.

# 1467

Thereafter We delivered Our apostles and those who believed. Even so, as incumbent upon us, We deliver the believers.

# 1468

Say thou: ye men! if ye are in doubt concerning my religion-- then worship not those ye worship beside Allah, but I worship Allah who causeth you to die; and I am commanded that I should be of the believers.

# 1469

And that: keep thy countenance straight toward the religion, Upright; and by no means be of the associators.

# 1470

And invoke not beside Allah that which can neither profit thee nor hurt thee; then if thou dost so, thou art forthwith of the wrong- doers.

# 1471

And if Allah toucheth thee with hurt there is no remover thereof but he, and if He intendeth any good there is no averter of His grace. He letteth it befall on whomsoever of His bondmen He will; and He is the Forgiving, the Merciful.

# 1472

Say thou: O mankind! the truth hath surely come unto you from your Lord: whosoever then is guided, is guided only for himself, and whosoever strayeth, strayeth only against himself; and am not over you a trustee.

# 1473

And follow thou whatsoever is revealed unto thee, and endure until Allah judgeth, and He is the Best of judges.

# 1474

Alif. Lam. Ra. A Book this, the verses whereof are guarded, and then detailed, from before the Wise, the Aware.

# 1475

Saying: ye shall not worship ought except Allah. Verily I am unto you from Him a warner and a bearer of glad tidings.

# 1476

And that: ask forgiveness of your Lord, then repent toward Him, He will let you enjoy a goodly enjoyment until a term appointed and will vouchsafe unto every owner of grace His grace. And if ye turn away, verily I fear for you the torment of a Great Day.

# 1477

Unto Allah is your return, and He is over everything Potent.

# 1478

Lo! they fold their breasts that they may hide from Him. Lo! when they cover themselves with their garments, He knoweth that which they conceal and that which they make known. Verily He is the Knower of the secrets of the breasts.

# 1479

And there is not a moving creature on the earth but upon Allah is the sustenance thereof, and He knoweth its habitation and its resting-place: everything is in a Book luminous.

# 1480

And He it is who hath created the heavens and the earth in six days -and His throne was upon the water--that he might prove you, as to which of you is excellent in work. And if thou sayest: ye shall verily be raised after death, surely those who disbelieve will say: naught is this but sorcery manifest.

# 1481

And if We defer from them the torment until a period determined, they say: What withholdeth it! Lo! the day it betideth them it shall not be averted from them, and shall beset them that whereat they have been mocking.

# 1482

And if We let man taste mercy from us, and thereafter withdraw it from him, verily he is despairing, blaspheming.

# 1483

And if We let him taste favour after harm hath touched him, he saith: the ills have departed from me; verily he becometh elated, boastful.

# 1484

Not so are those who persevere and do righteous works. Those! theirs shall be forgivness and a great hire.

# 1485

So hapoy thou mayest abandon part of that hich hath been revealed unto thee, and thy breast is straitened thereby, because they say: wherefore hath not a treasure been sent down unto him, or an angel come with him! Thou art but a warner, and of everything Allah is the Trustee.

# 1486

Or say they: he hath fabricated it? Say thou: bring ye then ten Surahs the like thereunto fabricated, and call whomsoever ye can beside Allah, if ye say sooth.

# 1487

Then if they respond you not, know that it hath been sent down only with the Knowledge of Allah, and that there is no god but he; are ye Muslims then?

# 1488

Whosoever desireth the life of the world and the adornment thereof, We shall repay them in full their works therein, and in it they shall not be defrauded.

# 1489

These are they for whom there is not in the Hereafter save the Fire; to naught shall come that which they have performed, and vain is that which they have been working

# 1490

Is he like unto him who resteth upon an evidence from His Lord, so and there rehearseth it a witness from Him And before it was the Book of Musa, a pattern and a mercy; these believe therein; and whosoever of the sects disbelieveth therein, the Fire is his promised place. Be then thou not in dubitation thereof, verily it is the truth from thy Lord, yet most of the mankind believe not.

# 1491

And who doth greater wrong than he who fabricateth a lie against Allah! these shall be set before their Lord, and the witnesses shall say; these are they who lied against their Lord. Lo! the curse of Allah shall fall on the wrong-doers-

# 1492

Who hinder others from the way of Allah and would seek crockedness therein, and they: in the Hereafter they are disbelievers.

# 1493

These could not escape on the earth, nor could there be for them protectors against Allah; doubled shall be the torment for them; they were notable to hearken, nor would they be clear sighted.

# 1494

These are they who have lost their souls, and hath strayed from them that which they have been fabricating.

# 1495

Undoubtedly they! in the Hereafter they shall be the greatest losers.

# 1496

Verily those who believed and worked righteous works and humbled themselves before their Lord--they shall be the fellows of the Garden: therein they shall be abiders.

# 1497

The likeness of the two parties is as the blind and deaf, and the seeing and hearing. Are the twain equal in likeness? Admonished are ye not then?

# 1498

And assuredly We sent Nuh unto his people saying: verily I am unto you a plain warner.

# 1499

That ye shall worship none except Allah; verily I fear for you the torment of a Day afflictive.

# 1500

The chiefs of those who disbelieved among his people said: we behold thee except as a human being like us, and we behold not any follow thee except the meanest of us, by an immature opinion; nor We behold in you any exellency over us; nay! we deem you liars.

# 1501

He said: bethink ye, O my people! if I rested upon an evidence from my Lord, and a mercy hath come unto me from Him, and that hath been obscured unto you, Shall we make you adhere to it while ye are averse thereto?

# 1502

And, O my people, I ask not of you any riches therefor; my hire is not but with Allah. And I am not going to drive away those who have believed; verily they are going to meet their Lord; but I behold you a people ignorant!

# 1503

O My people! who will succour me against Allah, if I drave them away! Admonished are ye not then?

# 1504

And I say not unto you that with me are the treasures of Allah, nor that I know the Unseen; nor I say, I am an angel. And say not of those whom your eyes condemn that Allah shall not bestow on them good - -Allah knoweth best that which is in theeir souls. Verily in that case would be of the wrong-doers.

# 1505

They said: O Nuh! surely thou hast disputed with us and hath multiplied the disputation with us; now bring us that wherewith thou threatenest us, if thou be of the truth-tellers.

# 1506

He said: only Allah will bring it on you if He will, and ye shall not escape.

# 1507

Nor would my good counsel profit you, even though I wished to give you good counsel, if Allah willed to keep you astray. He is your Lord, and unto Him ye shall be returned.

# 1508

Or say they: he hath fabricated it? Say thou: on me then be my guilt, and I am quit of that whereof ye are guilty.

# 1509

And it was revealed unto Nuh: verily none of thy people will believe save those that have believed already; so be not distressed for that which they have been doing.

# 1510

And make thou the ark under Our eyes and Our Revelation; and address Me not regarding those that have done wrong; verily they are to be drowned.

# 1511

And he was making the ark; and whenever the chiefs of his people passed by him, they scoffed at him. He said: if ye scoff at us, verily we also scoff at you even as ye scoff at us.

# 1512

So presently ye shall know on whom cometh a torment that humiliateth him, and on whom is let loose a torment lasting.

# 1513

Thus were they employed until when Our decree came and the oven boiled over, We said: carry thereon of every kind two, and thy household except him thereof against whom the word hath already gone forth, and whosoever hath believed. And there had not believed with him save a few.

# 1514

And he said: embark therein; in the name of Allah be its course and its anchorage, verily my Lord is Forgiving, Merciful.

# 1515

And it moved on with them amidst waves like mountains. And Nuh called out his son, and he was apart: O my son! embark with us, and be not with the infidels.

# 1516

He said: I shall betake me to a mountain which will defend me from the water. Nuh said: there is no defender to-day from the decree of Allah save for one on whom He hath mercy. And a wave intervened betwixt the twain; so he was of the drowned.

# 1517

And it was said: O earth! swallow up thy water, and cease, O heaven! And the water abated; and fulfilled was the decree. And it rested upon the Judi; and it was said: away with the wrong-doing people!

# 1518

And Nuh cried unto his Lord, and said: my Lord! verily my son is of my household, and verily Thine promise is the truth: and Thou art the Greatest of the rulers.

# 1519

He said: O Nuh! verily he is not of thy household; verily he is of unrighteous Conduct; wherefore ask Me not that whereof thou hast no knowledge; verily I exhort thee not to be of the ignorants.

# 1520

Nuh said: my Lord! verily take refuge with Thee lest I may ask Thee that whereof I have no knowledge. And if Thou forgivest me not and hast not mercy on me, I shall be of the losers.

# 1521

It was said: Nuh! get thou down with peace from us and blessings upon thee and the communities with thee. And there shall be communities whom we shall let enjoy themselves, and thereafter there shall befall them from us a torment afflictive.

# 1522

That is of the stories of the unseen: We Reveal it unto thee: thou knewest it not, nor thy nation knew it ere this. So be thou patient; verily the happy end is for the God-fearing.

# 1523

And unto 'Aad We sent their brother Hud. He said: O my people! worship Allah; \` there is no god for you but he; ye are but fabricators.

# 1524

O My people! I ask of you no hire therefor, my hire is cnly on Him who created me, will ye not then reflect?

# 1525

O My people! ask forgiveness of your Lord, then repent tcward Him; He will send the heaven upon you pouring, land He will add ycu strength upon your strength, and turn not away as guilty ones.

# 1526

They sai: O Hud! thou hast not brought us an evidence, and we are not going to abandon our gods thy saying, nor are we going to be believers in thee.

# 1527

All that we say is that some of our gods have smitten thee with evil. He said: verily I call Allah to witness, and bear ye witness, that I am quit of that which ye associate.

# 1528

Beside Him, so plot against me all tcgether, and then respite me not.

# 1529

Verily rely on Allah, my Lord and your Lord; no moving creature is there but he holdeth it by its forelock; verily my Lcrd is on the straight path.

# 1530

If then ye turn away, I have surely preached unto you that wherewith I was sent unto you. And my Lord will set up in succession a people other than you, and ye shall not harm Him at all, verily my Lord is over everything a Guardian.

# 1531

And then when Our decree came to pass, We delivered Hud and these who believed with him by a mercy from us; and We delivered them: from a torment rough.

# 1532

And such were 'Aad. They gainsaid the signs of their Lord, and disobeyed His apostles, and followed the bidding of any tyrant froward.

# 1533

And they were followed in this world by a curse, and so will they be on the Judgment Day. Lo! verily 'Aad disbelieved in thy Lord. Lo! away with 'Aad, the people of Hud.

# 1534

And unto Thamud We sent their brother Saleh. He said: O my people! worship Allah; there is no god for you but he. He hath caused you to spring out of the earth, and hath made you dwell therein. Wherefore ask forgiveness of Him, then repent toward Him; verily my Lord is Nigh, Responsive.

# 1535

They said: O Saleh! heretofore thou wast amongst us as one hoped for. Forbiddest us thou to worship that which our fathers have worshipped? And verily we are regarding that to which thou callest us in doubt disquieting.

# 1536

He said; O my people! bethink if I rest on an evidence from my Lord, and there hath come to me from Him a mercy, then who will succour me against Allah, if I disobey Him? Ye then increase me not save in loss.

# 1537

And O my people! yonder is the she-camel of Allah: a sign unto you; so let her alone, feeding in Allah's land, and touch her not with evil, lest there may overtake you a torment nigh.

# 1538

Yet they hamstrang her. Then he said: enjoy yourselves in your dwellings three days: that is a promise, not to be falsified.

# 1539

Then when Our decree came to pass We delivered Saleh and those who believed with Him by a mercy from Us, and from the humiliation of that day. Verily thy Lord! He is the Strong, the Mighty.

# 1540

And the shout overtook those who had done wrong; so they lay in their dwellings crouching

# 1541

As though they had never lived at ease therein. Lo! verily Thamud disbelieved in their Lord. Lo! away with Thamud.

# 1542

And assuredly Our messengers came unto Ibrahim with the glad tidings. The said: peace! He said: peace! And he tarried not till he brougt a calf roasted.

# 1543

And when he beheld that their hands reached it not he misliked them, and ccnceived a fear of them. They said fear not verily we are sent unto the people of Lut.

# 1544

And his wife was standing. she laughed. Then We gave her the glad tidings of Is'haq, and after Is'haq, Ya'qub.

# 1545

She said: Oh for me shall bring forth when I am old, and this my husband is advanced in years! Verily a marvellous thing is this!

# 1546

They said marvellest thou at the decree of Allah? Mercy of Allah and His blessings be upon you, people of the house, verily He is Praiseworthy, Glorious.

# 1547

Then when the alarm had departed from Ibrahim and the glad tidings had come home unto him, he took to disputing with us for the people of Lut

# 1548

Verily Ibrahim was forbearing, long-suffering, penitent.

# 1549

O Ibrahim! leave off this; verily the decree from thy Lord hath already come, and verily they! upon them is coming a torment unavoidable.

# 1550

And when Our messengers came unto Lut, he was distressed on their account, and he felt straitened on their account, and he said: this is a lay dreadful.

# 1551

And his people came unto him rushing on toward him, and afore they were wont to work vices. He said. O my people! these are my daughters: purer are they for you; so fear Allah, and humiliate me not in the face of my guests; is there not among you any man right-minded?

# 1552

They said: assuredly thou knowest that we have no right to thy daughters, and verily thou knowest that which we would have.

# 1553

He said. Would that I had strength against you or could betake me to a powerful support!

# 1554

They said: O Lut! verily we are messengers of thy Lord; they shall by no means reach thee: go forth thou With thy household in a part of the night, and let none of you look back, save thy wife; verily that which befalleth them shall befall her; verily their appointment is for the morning; is not morning nigh?

# 1555

Then when Our decree came to pass, We turned the upside thereof downward, and We rained thereon stones of baked clay, piled up.

# 1556

Marked from before thy Lord. Nor are they from the wrong- doers far away.

# 1557

And unto Madyan We sent their brother Shu'aib. He said: O my people! worship Allah; there is no god for you but he. And give not short measure and weight. Verily I see you in prosperity, and verily I fear for you the torment of a Day encompassing

# 1558

And, O my people! give full measure and weight with equity, and defraud not the people of their things, and commit not mischief on the earth as corrupters.

# 1559

And the remainder of Allah is better for you, if ye believers, and I am not over you a guardian.

# 1560

They said: Shu'aib, commandeth thee thy prayer that we should abandon that which our fathers have worshipped, or that we should not do with our riches whatsoever we will! thou, indeed! thou forsooth art forbearing, right-minded!

# 1561

He said: O my people! bethink if I rested on an evidence from my Lord, and He hath provided me with a goodly provision from Himself, shell I fail to deliver His message! And I desire not, in order to oppose you, to do that which I forbid I desire not but rectification, so far you as I am able, and my hope of success is not save with Allah; in Him I rely and unto Him I turn penitently.

# 1562

And, O my people! let not the cleavage with me incite you so that there befall you the like of that which befell the people of Nuh and the people of Hud and the people of Saleh; and the people of Lut are not from you far away.

# 1563

And ask forgiveness of your Lord, and then repent unto him; verily my Lord is Merciful, Loving.

# 1564

They said: O Shu'aib! we understanand not much of that which thou sayest, and verily we see thee weak among us, and were it not for thy company we had surely stoned thee, and thou art not among us mighty.

# 1565

He said: O my people! is my company mightier with you than Allah? Him ye have cast behind your backs neglected; verily my Lord is of that which ye work Encompasser.

# 1566

And, O my people! work according to your condition, verily I am going to work in my way; presently ye shall know on whom cometh a torment humiliating him and who is a liar. And Watch, verily I also am with you a watcher.

# 1567

And when our decree came to pass, We delivered Shu'aib and those who believed with him by a mercy from Us, and the shout overtook those who did wrong, so they lay in their dwellings crouching.

# 1568

As though they had never lived at ease therein. Lo! a far removal for Madyan, even as Thamud were removed afar!

# 1569

And assuredly We sent Musa with Our signs and a manifest warranty.

# 1570

Unto Firawn and his chiefs. But they followed the commandment of Fir'awn, and the commandment of Fir'awn was not right- minded.

# 1571

He shall head his people on the Day of Resurrection and cause them to descend into the Fire, ill is the descent, descended!

# 1572

And they were followed in this world by a curse and so they will be on the Day of Resurrection, ill is the present presented!

# 1573

That is from the stories of the Cities which We recount unto thee: of them some are standing and some mown down.

# 1574

And We wronged them not but they wronged themselves. So their gods, whom they called upon beside Allah, availed them not in aught, when there came the decree of thy Lord, and they added unto them naught but perdition.

# 1575

And even such is the overtaking of thy Lord when He overtaketh the cities while they are wrong-doers; verily His overtaking is afflictive, severe.

# 1576

Verily herein is a sign unto him who feareth the torment of the Hereafter. That is a Day whereon mankind shall be gathered together, and that is a Day to be witnessed.

# 1577

And We defer it not but to a term determined.

# 1578

The day it cometh no soul shall speak save by His leave: then of them some shall be wretched and some blessed.

# 1579

As for those who shall be wretched. they shall be in the Fire, wherein for them shall be panting and roaring.

# 1580

Abiders they shall be therein, so long as the heavens and the earth remain, save as thy Lord may will. Verily thy Lord is the Doer of whatsoever He intendeth.

# 1581

And as for those who shall be blest, they shall be in the Garden, as abiders therein so long as the heavens and the earth remain, save as thy Lord may will. a gift unending.

# 1582

So be not thou in dubitation concerning that which these people worship. They worship not save as their fathers worshipped afore; and verily We will repay unto them in full their portion, undiminished.

# 1583

And assuredly vouchsafed unto Musa the Book, and disputation arose thereabout; and had not a word preceded from thy Lord, it would have been decreed between them. And verily they are concerning that in doubt disquieting.

# 1584

And verily unto each will thy Lord repay their works in full; verily of that which they work He is Aware.

# 1585

So stand thou straight as thou hast been commanded, thou and whosoever repented with thee; and be not arrogant; verily He is of that which ye work Beholder.

# 1586

And lean not toward those who do wrong, lest the Fire should touch you, and ye have no protectors beside Allah nor ye would then be succoured.

# 1587

And establish thou the prayer at the two ends of the day, and in the neighbouring watches of the night verily virtues take away vices. That is a reminder unto the mindful.

# 1588

And be patient thou; verily Allah wasteth not the hire of the welldoers.

# 1589

Why were there not of the generations before you owner of wisdom restraining others from corruption on the earth, except a few of those whom We delivered from amongst them! And those who did wrong followed that in which they luxuriated, and they had been sinners.

# 1590

And thy Lord is not one to destroy cities wrongously while the inhabitants thereof are rectifiers.

# 1591

And had thy Lord Willed, He would surely have made mankind of one community, and they will not cease differing.

# 1592

Save these on whom thy Lord hath mercy; and for that he hath created them. And fulfilled will be the word of thy Lord: surely I will fill Hell with the jinn and mankind together.

# 1593

And all that We recount unto thee of the stories of the apostles is in order that We may make firm thy heart thereby. And in this there hath come to thee truth and an exhortation and an admonition unto the believers.

# 1594

And say thou unto those who believe not: work according to your condition verily We, going to work in our way.

# 1595

And await; as verily we are awaiting.

# 1596

And Allah's is the Unseen of the heavens and the earth, and unto Him the whole affair shall be brought back. So worship Him thou and rely on Him; and thy Lord is not negligent of that which ye work.

# 1597

Alif. Lam. Ra. These are the verses of a Book luminous.

# 1598

Verily We! We have sent it down, an Arabic Recitation, that haply ye may reflect.

# 1599

We! We recount unto thee the best of stories, by Revealing unto thee this Our'an, although thou wast before that of the unaware ones.

# 1600

Recall what time Yusufj said unto his father:, y father! verily have seen eleven stars and the sun and the moon; I have seen them prostrating themselves unto me.

# 1601

He said: O my son! recount not thine vision unto thy brethren, lest they plot a plot against thee; verily the Satan is unto man an enemy manifest.

# 1602

And Thus will thy Lord choose thee and teach thee of the interpretation of discourses, and will fulfil His favour upon thee and upon the house of Y'aqub even as He fulfilled it upon thy fathers, Ibrahim and Is-haq aforetime; verily thy Lord is Knowing, Wise.

# 1603

Assuredly in Yusuf and his brethren there have been signs for the inquirers.

# 1604

Recall what time they said: surely Yusuf and his brother are dearer to our father than we, whereas we are company; verily our father is in error manifest.

# 1605

Slay Yusuf or cast him forth to some land; your father's countenance will be free for you, and ye shall be thereafter a people favoured.

# 1606

Said a speaker from among them; slay not Yusuf, but cast him into the bottom of a well, some of the caravan will take him up--if ye must be doing.

# 1607

They said: our father! wherefore thou intrustest us not with Yusuf, whereas verily we are his well-wishers.

# 1608

Send him with us tomorrow, that he may refresh himself and play, and verily we are to be his guards.

# 1609

He said: verily it grieveth me that ye should take him away, and I fear lest a wolf may devour him, While ye are negligent of him.

# 1610

They said: if the wolf devoured him while we were a company, we must indeed then be the losers!

# 1611

So when they took him away, and resolved to place him in the bottom of the well, We Revealed unto him: surely thou wilt declare unto them this their affair, while they shall perceive not.

# 1612

And they came to their father at nightfall, weeping.

# 1613

They said: our father! we went off competing, and left Yusuf by our stuff, so a wolf devoured him; and thou wilt put no credence in us, even though we are the truth-tellers.

# 1614

And they brought his shirt with false blood. He said: nay! your selves have embellished for you an affair; so seemly patience! and Allah is to be implored for help in that which ye ascribe

# 1615

And a caravan came, and they sent their water-drawer, and he let down his bucket. He said: glad tidings! here is a youth. And they hid him as merchandise, And Allah was the Knower of that which they worked.

# 1616

And they sold him for a mean price: a few dirhams numbered and they were in regard to him of the indifferent.

# 1617

And he who bought him in Misr said unto his wife: make his dwelling honourable: belike he may profit us or we may take him as a son. And Thus We made a place for Yusuf in the land, and it was in order that We may teach him the interpretation of discourses. And Allah is Dominant in His purpose, but most of men know not.

# 1618

And when he reached his maturity We vouchsafed unto him judgement and knowledge; and Thus We recompense the well-doers.

# 1619

And she in whose house he was, solicited him against himself; and she fastened the doors, and said: come on, O thou! He said: Allah be my refuge: verily he is my lord; he hath made me a goodly dwelling; verily the wrong-doers fare not well.

# 1620

And assuredly she besought him, and he would have besoughther were it not that he had seen the argument of his Lord. Thus We did, in order that We might avert from him all evil and indecency; verily he was of our bondmen single-hearted.

# 1621

And the twain raced to the door, and she rent his shirt from behind, And the twain met her master at the door. She said: What is the meed of him who intended evil toward thy house hold except that he be imprisoned, or a torment afflictive?

# 1622

He said: it is she who solicited me against myself And a witness from her own household bare witness: if his shirt be rent in front, then she speaketh the truth and he is of the liars.

# 1623

And if his shirt be rent from behind, then she lieth, and he is of the truth-tellers.

# 1624

So when he saw his shirt rent from behind, he said: verily it is of the guile of ye women; verily the guile of ye women is mighty.

# 1625

Yusuf! turn away therefrom; and, thou woman! ask forgiveness for thy sin; verily thou hast been of the guilty.

# 1626

And women in the city said; the wife of the AZiZ hath solicited her page against himself; he hath inflamed her with love; verily we behold her in error manifest.

# 1627

Then, when she heard of their cunning talk, she sent unto them a messenger, and got ready for them a cushioned Couch, and gave a knife to each of them. And she said: come forth to them. Then when they saw him, they were astonished at him, and they made a cut in their hands, and said: how perfect is God! no man is he: he is naught but an angel noble.

# 1628

She said: that then is he in regard to whom ye reproached me. Assuredly solicited him against himself but he abstained; and if he doth not that which I command him, he shall surely be imprisoned and he shall surely be of the degraded.

# 1629

He said: my Lord: prison is dearer to me than that to which these women call me; and if Thou avertest not their guile from me should incline toward them and become of the Ignorant.

# 1630

Then his Lord answered to him, and averted their guile from him; verily He! He is the Hearer, the Knower!

# 1631

Thereafter it occurred to them even after they had, the signs, to imprison him for a season.

# 1632

And there entered with him into the prison two pages. One of them said: verlly I saw myself pressing wine; and the other said: verily I saw myself carrying upon my head bread whereof the birds were eating. declare unto us the interpretation thereof, verily we see thee of the well-doers.

# 1633

He said: there will not come to you any food wherewith ye are provided but I shall have declared unto the interpretation thereof ere it cometh unto you. that is of that which my Lord hath taught me; verily I have abandoned the creed of a people who believe not in Allah and who in the Hereafter are disbelievers.

# 1634

And I have followed the creed of my fathers, Ibrahim and Is'haq and ya'qub: it is not for us to associate aught with Allah. That is of Allah's and upon mankind; but grace upon us most of mankind thank not.

# 1635

O My two fellow-prisoners! are sundry lords better of Allah, the One, the Subduer

# 1636

Ye worship not, beside Him, but names ye have named, ye and your fathers: Allah hath not sent down for them any warranty. Judgment is but Allah's; He hath commanded that ye worship not except Him. That is the right religion, but most of the mankind know not.

# 1637

O My two fellow-prisoners; as for one of you twain he will pour out wine for his lord; and as for the other, he will be crucified, and the birds will eat from off his head; O Thus is decreed the affair whereof ye twain enquired.

# 1638

And he said to one of them who he imagined would be saved: mention me in the presence of thy lord. Then the Satan caused him to forget to mention him to his lord, so that he tarried in the prison several years.

# 1639

And the king said: verily I saw seven fat kine which seven lean ones are devouring and seven green cornears and seven others dry. O ye chiefs! give me an answer in regard to my vision if a vision ye are wont to expound.

# 1640

They said: medleys of dreams! and in the interpretation of dreams we are not skilled.

# 1641

Then the one of the twain, who was saved, and now recollected himself after a period, said: I, even I, shall declare unto you the interpretation thereof; so send me forth.

# 1642

Yusuf, O saint! give an answer unto us in regard to seven fat kine which seven lean ones are devouring and seven green corn-ears and seven others dry; haply may return unto the people; haply they may learn.

# 1643

He said: ye shall sow seven years as is your went; and that which ye reap leave in its ears, except a little whereof ye may eat.

# 1644

Then thereafter will come seven hard years which will devour that which ye have laid up beforehand for them except a little which ye shall preserve.

# 1645

Then thereafter will come a year wherein mankind will have rain and wherein they will press.

# 1646

And the king said: bring him Unto me. Then, when the messenger came to him, he said: return to thy lord, and ask him, what about the women who cut their hands! verily my Lord is the Knower of their guile.

# 1647

He said: What was the matter with you when ye solicited Yusuf against himself! They said: how perfect is God! we knew not of any evil against him. The wife of the Aziz said: how hath the truth come to light, even I, solicited him against himself, and verily he is of the truth-tellers.

# 1648

He said: that did in order that he may know that I betrayed him not in secret, and that Allah guideth not the guile of betrayers.

# 1649

Nor I acquit myself; verily the self ever urgeth to evil save that self on Whom my Lord hath mercy; verily My Lord is Forgiving, Merciful.

# 1650

And the king said: bring him unto me I will single him out for myself Then when he spake unto him, he said: verily thou art to-day with us placed high, intrusted.

# 1651

He said: set me over the store houses of the land; verily I shall be a keeper knowing.

# 1652

Thus We established Yusuf in the land so that he might settle therein wherever he listed. We bestow of Our mercy on whomsoever We will, and We waste not the hire of the well-doers.

# 1653

And surely the hire of the Here after is better for those who believe and ever fear.

# 1654

And the brethren of Yusuf came and entered unto him, and he recognized them, while they recognized him not.

# 1655

And when he had furnished them with their furnishing, he said: bring unto me a brother of your from your father behold ye not that I give full measure and that am the best of entertainers.

# 1656

But if ye bring him not unto me, there shall be no measuring for you from me, and ye shall not approach me.

# 1657

They said: we will surely entice away his father from him; and verily we are doers.

# 1658

And he said to his pages: place their goods in their packs, haply they will recognize them when they reach back to their household: haply they will return.

# 1659

Then when they returned to their father, they said: our father! the measuring hath been denied us, wherefore send thou with us our brother, and we shall get our measure; and verily we shall be his guards.

# 1660

He said: I intrust you with him only as I intrusted you with his brother aforetime; Allah is the best Guard, and He is the Most Merciful of the merciful.

# 1661

And when they opened their stuff, they found their goods returned unto them. They said: our father! what more can we desire! here are our goods returned to us; We Shall supply our household and shall guard our brother and shall add anot her measure of a camel load: this is only a small measure.

# 1662

He said: I will by no means send him with you until ye give me an assurance by Allah that ye will bring him back to me, unless it be that ye are encompassed. Then when they gave him their assurance, he said: Allah is over that which we have said Warden.

# 1663

And he said: my sons! enter not by one gate but enter by different gates; and I cannot avail you against Allah at all: judgment is but Allah's; on Him I rely, and on Him let the relying rely.

# 1664

And when they entered as their father had enjoined them, it availed them not against Allah at all; it was only a craving in the soul of Ya qub that he satisfied; verily he was endued with knowledge, for We had taught him; but most of the people know not.

# 1665

And when they entered unto Yusuf, he betook his full brother unto himself, and said: verily I am thine own brother Yusuf, so sorrow not over that which they have been working.

# 1666

And when he had furnished them with their furnishing; he placed the drinking-cup in his brother's pack. - Thereafter a crier cried: O caravan! verily ye are thieves.

# 1667

They said while they turned toward them: what is it that ye miss!

# 1668

They said: we miss the king's cup; and for him who bringeth it shall be a camel-load; and thereof I am a guarantor.

# 1669

They said: by Allah! assuredly ye know that we came not to work corruption in the land, nor we have been thieves.

# 1670

They said: what shall be the meed of him, if ye are found liars!

# 1671

They said: his meed shall be that he, in whose pack it is found, shall himself be recompense thereof. Thus we reccmpense the wrong- doers.

# 1672

Then he began with their sacks before the sack of his brother; then he brought it forth from his brothers sack. In this wise We contrived for Yusuf. He was not one to take his brother by the law of the king, except that Allah willed. We exalt in degrees whomsoever We will, and above every knowing one is a Knower.

# 1673

They said: if he stealeth, then surely a brother of him hath stolen afore. But Yusuf concealed it in himself, and discovered it not unto them. He said: ye are in evil plight, and Allah is the Best Knower of that which ye ascribe.

# 1674

They said: Aziz! verily he hath a father, an old man very aged; So take one of us in his stead; verily we behold thee to be of the well-doers.

# 1675

He said: Allah forbid that we should take anyone but him with whom we found our stuff; verily then we should be the wrong-doers.

# 1676

Then when they despaired of him they counselled together privately. The eldest of them said: know ye not that your father hath taken an assurance from you before Allah? and aforetime ye have been remiss in your duty in respect of Yusuf; I so will by no means go forth from the land until my father giveth me leave or Allah judgeth for me, and He is the Best of judges.

# 1677

Return unto your father, and say: our father! verily thy son hath stolen, and we testify not save according to that which we know; and of the unseen we could not be guards.

# 1678

And inquire those of the city where we have been and of the caravan with whom we have travelled hither; and verily we are truth- tellers.

# 1679

He said: nay! your selves have embellished for you an affair; so seemly patience! Belike Allah may bring them all unto me; verily He! only He Is the Knowing, the Wise.

# 1680

And he turned away from them, and said: O my grief for Yusuf! and his eyes whitened with grief, while he was filled with suppressed sorrow.

# 1681

They said: by Allah! thou wilt not cease remembering Yusuf until thou art wizened or thou be of the dead.

# 1682

He said: I only bewail my cogitation and grief unto Allah, and I know from Allah that which ye know not.

# 1683

O My sons! go and ascertain about Yusuf and his brother, and despair not of the comfort of Allah; verily none despair of the comfort of Allah except a people disbelieving.

# 1684

And when they entered unto him, they said: O Aziz! distress hath touched us and our household, and we have brought poor goods, wherefore give us full measure, and be charitable unto us; verily Allah recompenseth the charitable.

# 1685

He said: remember ye that which ye did Unto Yusuf and his brother while ye were ignorant?

# 1686

They said: art thou Yusuf indeed! He said: I am Yusuf and this is my brother; Allah hath surely been gracious unto us; verily whosoever feareth and endureth, then verily Allah wasteth not the hire of the well-doers.

# 1687

They said: by Allah! assuredly Allah hath chosen thee above us, and we have been sinners indeed.

# 1688

He said; no reproach upon you today. May Allah forgive you; and He is the Most Merciful of the merciful.

# 1689

Go with this shirt of mine and cast it upon my father's face; he shall become clear-sighted; and bring unto me all your household.

# 1690

And when the caravan had departed, their father said: surely feel the smell of Yusuf, if ye think not that I am doting.

# 1691

They said: by Allah! verily thou art in thine old-time error.

# 1692

Then, when the bringer of the glad tidings came, he cast it upon his face and he became clear-sighted. He said: said I not unto you, verily I know from Allah that which ye know not.

# 1693

They said: our father! pray for forgiveness of our sins for us; verily we have been sinners.

# 1694

He said: presently I shall pray for forgiveness for you of my Lord; verily He! only He is the Forgiving, the Merciful.

# 1695

Then when they entered unto Yusuf, he betook his parents unto himself. and said: enter Misr, if Allah will, in security.

# 1696

And he raised his parents to the throne, and they fell down before him prostrate, And he said: O my father! this is the interpretation of my vision aforetime; My Lord hath now made it come true; and surely He did well by me when he took me forth from the prison, and hath brought you from the desert after the Satan had stirred strife between me and my brethren; verily my Lord is subtilel Unto whomsoever He will. Verily He! only He, is the Knowing, the Wise.

# 1697

O My Lord! Thou hast given me of the dominion, and hast taught me of the interpretation of discourses, Creator of the heavens and the earth! Thou art my Patron in the world and the Hereafter. Make me to die a Muslim, and join me with the righteous.

# 1698

This is of the tidings of the unseen, which We reveal unto thee; nor wast thou with them when they resolved on their affair while they were plotting.

# 1699

And most of the people, though thou desiredest ardently, are not going to be believers.

# 1700

And thou askest them not any hire therefor; it is but an admonition unto the worlds.

# 1701

And how many a sign in the heavens and the earth they pass by, while they are averters therefrom.

# 1702

And most of them believe not in Allah except as they are associators.

# 1703

Are they secure then against this, that there may come upon them an overwhelming of Allah's torment, or that there may come upon them the Hour on a sudden while they percieve not?

# 1704

Say thou: this is my way: I call unto Allah resting upon an insight---I, and whosoever followeth me. Hallowed be Allah: and I am not of the associators.

# 1705

And We sent not before thee any save men unto whom We revealed from among the people of the towns. Have then they not travelled about in the land that they might observe of what wise hath been the end of those before them! And surely the abode of the, Hereafter is best for those who fear! Reflect then ye not!

# 1706

Respited were they until when the apostles had despaired and imagined that they were deluded, there came unto them Our succour; then whomsoever We willed was delivered. las And Our wrath is not warded off from a people sinful.

# 1707

Assuredly in their stories is a lesson for men of understanding. It is not a discourse fabricated, but a confirmation of that which went before it, and a detailing of everything, and a guidance and a mercy unto a people who believe.

# 1708

Alif. Lam. Mim. Ra. These are the verses of the Book. And that which is sent down unto thee from thy Lord is the truth, but most of the people believe not.

# 1709

Allah it is who hath raised the heavens without pillars that ye can see, then He established Himself on the throne, and subjected the sun and the moon, each running unto a period determined. He disposeth the affair, and detaileth the signs, that haply of the meeting with your Lord ye may be convinced.

# 1710

And He it is who hath stretched forth the earth, and placed therein firm mountains and rivers; and of every fruit he hath placed therein two in pairs. He covereth the night with the day; verily therein are signs for a people who ponder.

# 1711

And in the earth are regions neighbouring and gardens of vines and cornfields, and palm-trees clustered and single, watered by the same water; yet some We make to excel others in food. Verily therein are signs for a people who reflect.

# 1712

And shouldst thou marvel, then marvellous is their saying: when we have become dust, shall we be in a new creation! ' These are they who disbelieved in their Lord; and these! -- the shackles round their necks; and these shall be the fellows of the Fire as abiders therein.

# 1713

And they ask thee to hasten the evil before the good, while examples have already gone forth afore them. And thy Lord is Owner of forgiveness unto mankind despite their wrong-doing; and verily thy Lord is severe in requital

# 1714

And those who disbelieve say: wherefore is not a sign sent down unto him from his Lord! Thou art but a warner; and unto every people there is a guide.

# 1715

Allah knoweth that which each female beareth and that which the wombs want and that which they exceed, and with Him everything is in due measure:

# 1716

Knower of the hidden and the manifest! the Great! the Exalted.

# 1717

Equal unto him is he among you who hideth the word and he who publisheth it, and he who hideth himself in the night and he who goeth about freely in the day.

# 1718

For him are angels in succession, before him and behind him; they guard him with Allah's command. Verily Allah altereth not that which is with a people until they alter that which is with themselves. And when Allah intendeth evil unto a people there is no turning it back; nor is for them, beside Him, any patron.

# 1719

He It is who sheweth the lightning unto you for fear and for desire, and bringeth up the clouds heavy.

# 1720

And the thunder halloweth His praise, and so do the angels in awe of Him; and He sendeth the thunderbolts and smiteth therewith whomsoever He will. And they dispute concerning Allah, and He is strong in prowess.

# 1721

Unto Him is the true call, and those whom they call upon beside Him answer them not at all, save as is answered one stretching out his palms to water that it may reach his mouth, while it will reach it not. And the supplication of the infidels only goeth astray.

# 1722

And unto Allah prostrateth himself whosoever is in the heavens and the earth, willingly or of constraint, and also thir shadows in the moring and the evenings.

# 1723

Say thou: who in the Lord of the heavens and the earth Say thou: Allah. Say thou: have ye then taken beside Him patrons who own not to themselves benefit nor hurt! Say thou: are the blind and the seer equal? Or, the darknesses and light equal? Or have they set up associates unto Allah, who have created even as He hath created, so that the Creation hath become dubious unto them! Say thou: Allah is the Creator of everything; and He is the One, the Subduer.

# 1724

He sendeth down water from the heaven, so that the valleys flow according to their measure; then the torrent beareth the scum on top, and from that over which they kindle a fire seeking ornament or goods- ariseth a scum like thereto: Thus doth Allah propound the truth and falsity. Then as for the scum, it departeth as rubbish, and as for that which benefiteth the mankind, it lasteth on the earth: Thus doth Allah propound the similitudes.

# 1725

For these who answer their Lord is ordained good. And those who answer not their Lord--if they had all that is in the earth, and therewith the like thereof, they would ransom themselves therewith. These! for them shall be an evil reckoning; and their resort is Hell, a hapless bed!

# 1726

Shall he then who knoweth that which is sent down unto thee is the truth be like unto him who is blind! Only the men of understanding are admonished

# 1727

Those who fulfil the covenant of Allah, and violate not the bond.

# 1728

And those who enjoin that which Allah hath commanded to be enjoined, and fear their Lord, and dread the evil reckoning;

# 1729

And those who persevere seeking the countenance of their Lord and establish prayer, and expend out of that wherewith We have provided them, secretly and openly, and combat evil with good. These! for them is the happy end in the Abode:

# 1730

Gardens Everlasting; they shall enter them, and also whosoever shall have acted righteously from among their fathers and their spouses and their progeny. And angels shall enter unto them from every portal, saying:

# 1731

Peace be upOn you for ye patiently persevered. Excellent then is the happy end in the Abode!

# 1732

And those who violate the covenant of Allah after the ratification thereof, and sunder that which Allah hath commanded to be conjoined, and act corruptly in the earth--these! unto them is a curse, and unto them shall be the evil Abode.

# 1733

Allah enlargeth the provision for whomsoever He Willeth and, stinteth. And they exult in the life of the world, whereas the life of the world, by the side of the Hereafter, is only a Passing enjoyment.

# 1734

And those who disbelieve say: wherefore is not a sign sent down unto him from his Lord! Say thou: verily Allah sendeth astray whomsoever He will and guideth unto Himself whosoever turnoth in penitence--

# 1735

They are those who believe and whose hearts find rest in the remembrance of Allah. Lo! in the remembrance of Allah hearts do find rest.

# 1736

Those who believe and work righteous works, for them is bliss and a happy resort.

# 1737

Thus We have sent thee unto a community before whom other communities have passed away, in order that thou mayest recite unto them that which We have Revealed unto thee; yet they disbelieve in the Compassionate. Say thou: He is my Lord, there is no god but he; on Him I rely, and unto Him is my return in penitence.

# 1738

And if there were a Qur'an whereby the mountains could be moved or Whereby the earth could be traversed or whereby the dead could be spoken to, it would be in vain. Aye! the affair belongeth to Allah entirely. Have not then those who believe yet known that had Allah willed, He would have guided all mankind! And a rattling adversity ceaseth not to befall those who disbelieve for that which they have wrought or to alight nigh unto their habitation. until Allah's promise cometh; verily Allah faileth not the tryst.

# 1739

And assuredly mocked were apostles before thee; then I respited those who disbelieved; thereafter took hold of them; so of what wise hath been My requital.

# 1740

Is He, then, who is ever standing over every soul with that which he earneth, like unto other! And yet they have set up associates unto Allah. Say thou: name them; would ye inform Him of that which He knoweth not on the earth? or is it by way of outward saying? Aye! fair-seeming unto those who disbelieve is made their plotting, and they have been hindered from the way. And whomsoever sendeth astray, for him there is no guide.

# 1741

For them is torment in the life of the Word, and surely the torment of the Hereafter is harder; and from Allah there is for them no protector.

# 1742

The case of the Garden which hath been promised unto the God-fearing: rivers flow thereunder; fruit thereof is perpetual, and so is thes hade thereof. This is the ending of those who fear; and the ending of the infidels is the Fire.

# 1743

They unto whom We vouchsafed the Book rejoice at that which hath been sent down unto thee; and of their bands are some who deny some of it. Say thou: have only been commanded that: should worship Allah and should associate not with Him. Unto Him I call, and unto Him is my return.

# 1744

And Thus We have sent it down as a judgment in Arabic, And surely wert thou to follow their vain desires, after that which hath come to thee of knowledge, thou wilt not have against Allah any patron or protector.

# 1745

And assuredly We sent apostles before thee and We made for them wives and progeny and it is not for an apostle to Produce a verse except by the command of Allah; for everv time there is a Book.

# 1746

Allah abolisheth whatsoever He Will and keepeth; and with Him is the mother of the Book.

# 1747

And whether We shew thee part of that which We have promised them, or We take thee away, on thee is only the preaching, and on Us is the reckoning.

# 1748

Behold they not that We visit the landj diminishing it by the borders thereof Allah judgeth, and there is no reviser of His judgment; and He is swift in reckoning,

# 1749

And of a surety there plotted those before them; but unto Allah belongeth the plotting entirely. He knoweth that which each soul earneth. And anon will the infidels know for whom is the happy ending of the Abode.

# 1750

And those who disbelieve say: thou art not a sent one. Say thou: Allah is a sufficient witness between me and you, and also he with whom is knowledge of the Book.

# 1751

Alif. Lam. Ra. This is a Book which We have sent down unto thee, that thou mayest bring the mankind forth from the darknesses unto the light, by the command of their Lord: unto the path of the Mighty, the Praiseworthy.

# 1752

Allah, whose is that which is in the heavens and that which is in the earth; and woe be unto the infidels because of a torment severe

# 1753

Those who prefer the life of the world to the Hereafter, and hinder people from the way of Allah, and seek crookedness therein; these are in error far-off.

# 1754

And We sent not an apostle but with the speech of his people that he might expound unto them. Then Allah sendeth astray whomsoever He will, and guideth whomsoever He will. And He is the Mighty, the Wise.

# 1755

And assuredly We sent Musa with our signs saying: bring thy people forth from the darknesses unto the light, and remind them of the annals of Allah. Verily therein are signs for everyone patient, and thankful.

# 1756

And recall what time Musa said unto his people: remember the favour of Allah upon you when He delivered you from the house of Fir'awn who were imposing upon you evil torment, slaughtering your sons and letting your women live, and therein was from your Lord a trial terrible.

# 1757

And what time your Lord proclaimed: if ye give thanks, surely I will increase you, and if ye disbelieve, verily My torment severe.

# 1758

And Musa said: if ye disbelive, -- ye and all those who are on the earth-then verily Allah is self-sufficient, Praiseworthy. disquieting.

# 1759

Hath not the tidings come to you of those before you: the people of Nuh and the 'Aad and the Thamud and those after them! None knoweth them save Allah. There came unto them their apostles with the evidences, but they put their hands to their mouths, and said: verily we disbelieve in that where- with ye have been sent, and verily regarding that to which ye call Us We are in doubt disquieting.

# 1760

Their apostles said: is there doubt about Allah, the Maker of the heavens and the earth? He calleth you that he may forgive you of your sins and retain you till a term fixed. They said: ye are but like us; ye mean to turn us aside from that which our fathers have been worshipping; so bring us a warranty manifest.

# 1761

Their apostles said unto them: we are naught but human beings like but Allah bestoweth favour on you, of His bond whomsoever He willeth and it is not for us to bring you a men command of warrantv except by the Allah. On Allah then let the believers rely.

# 1762

And wherefore should we not rely on Allah when He hath surely guided us our ways! And surely we shall bear patiently that with which ye afflict us and in Allah then let the trustful put their trust.

# 1763

And those who disbelieved said to their apostles: we will surely drive you forth from our land, or else ye will have to return to our faith. Then their Lord Revealed unto them: We will surely destroy the wrong-doers.

# 1764

And We will surely cause you to dwell in the land after them: that is for him who feareth standing before Me and feareth My threat.

# 1765

And they besought judgment, and disappointed was every tyrant obstinate.

# 1766

Behind him is Hell, and he shall be made to drink of fetid water.

# 1767

Which he gulpeth, but wellnigh swalloweth not. And death cometh upon him from every side, while yet he is not dead, and behind him is a torment terrible.

# 1768

The likeness of those who disbelieve in their Lord: their works are like ashes upon which the wind bloweth hard on a stormy day: they shall not be able to get aught of that which they have earned. That! that is the straying far-off

# 1769

Beholdest thou not that Allah hath created the heavens and the earth with a purpose? If He willed He would make you pass away and bring a creation new.

# 1770

And for Allah that is not hard.

# 1771

And they all shall appear before Allah, then those who were counted weak shall say to those who were stiff-necked: verily we were unto you a following, are ye going to avail us at all against the torment of AllAh? They Will say: had Allah guided, We would have guided you also; it is equal unto us whether we become impatient or bear patiently; for us there is no place of escape.

# 1772

And the Satan will say, When the affair hath been decreed: verily Allah promised you a promise of truth; and I promised you, then I failed; and I had over you no authoyourity, save that I called you and ye answered me; wherefore reproach not but reproach yourself. I am not me going to succour you nor are ye going to succour me: verily I disbelieve in your having associated me afore. Verily the wrong-doers! for them is a torment zfflictive.

# 1773

And those who believed and worked righteous works shall be made to enter Gardens whereunder rivers flow as abiders therein by the command of their Lord, their greeting therein will be: peace!

# 1774

Beholdest thou not how Allah hath propounded the similitude of the clean word? It is like a clean tree, its root firmly fixed, and its branches reaching unto heaven.

# 1775

Giving its fruit at every season, by the command of the Lord. And Allah propoundeth similitudes for mankind that haply they may be admonished.

# 1776

And the similitude of the foul word is as a foul tree, uprooted from upon the earth, and there is for it no stability.

# 1777

Allah keepeth firm those who believe by the firm Word in the life of the world and in the Hereafter, and Allah sendeth astray the wrong-doers. And Allah doth that which He willeth.

# 1778

Beholdest thou not those who returned the favour of Allah with infidelity and caused their people to alight in the dwelling of perdition:

# 1779

Hell, wherein they shall roast. How ill is the settlement!

# 1780

And they have set up compeers unto Allah, that they may lead men astray from His way. Say thou: enjoy, then verily your vending is unto the Fire.

# 1781

Say thou unto those of My bond- men who have believed, let them establish prayer and expend of that wherewith We have provided them secretly and openly, ere the Day cometh wherein there will be no bargain nor friendliness.

# 1782

Allah it is who hath created the heavens and the earth, and sent down from the heaven water, and hath there by brought forth fruits as a provision for you; and He hath subiected the ships for you that it may run in the sea by His command; and He hath subjected for you the rivers.

# 1783

And He hath subjected for you the sun and the moon, two constant toils; and He hath subjected for you the night and the day.

# 1784

And He hath vouchsafed unto you some of everything ye asked Him. And if ye would count Allah's favours, ye can not compute them; verily man is a great wrong-doer, highly ungrateful.

# 1785

And recall what time Ibrahim said: my Lord! make this City secure and keep me and my sons away from worshipping the idols.

# 1786

My Lord! they have sent astray many among mankind; whosoever followeth me, verily he is of me; and whosoever disobeyeth me, then verily Thou art Forgiving, Merciful.

# 1787

Our Lord! verily have caused some of my progeny to dwell in a valley uncultivable near Thy Sacred House, Our Lord! in order that they may establish prayer; make Thou therefore the hearts of some of mankind to Yearn toward them, and provide them Thou With fruits, haply they may give thanks.

# 1788

Our Lord! verily Thou knowest that which We conceal and that which We make known; and not of aught is concealed from Allah in the earth or in the heaven.

# 1789

All praise be unto Allah who hath bestowed upon me, despite old age lsma'il and ls-haq; verily my Lord is the Hearer of supplication.

# 1790

My Lord! make me establisher of prayer and also from my progeny, our Lord! and accept Thou my supplication.

# 1791

Our Lord! forgive me and my parents and the believers on the Day whereon will be set up the reckoning.

# 1792

And deem not Allah negligent of that which the wrong-doers work: He only deferreth them to a Day whereon the sighthall remain staring.

# 1793

They hastening forward, their heads upraised, their look returning not unto them and their hearts void.

# 1794

And warn thou the mankind of the Day whereon the torment will come unto them; then those who have done wrong shall say: our Lord! defer us to a term near at hand we will answer Thy call and we will follow the apostles. Were ye not wont to swear afore that for you there was to be no decline?

# 1795

And ye dwell in the dwellings of those who had wronged themselves and it had become manifest unto you in what wise We had dealt with them, and We had propounded for you similitudes.

# 1796

And of a surety theys Plotted their plot, and with Allah was their plot, though their plot was such as to remove thereby mountains.

# 1797

So deem not thouthat Allah is going to fail His promise to His apostles; verily Allah is Mighty, Lord of vengeance

# 1798

On the Day whereon the earth will be changed into other than the earth, and the heavens also; and all creatures will appear unto Allah, the One, the Subduer.

# 1799

And thou wilt see the guilty on that Day bound together in fetters.

# 1800

Their trouser hell be of pitch, and the Fire shall cover their faces.

# 1801

That Allah may requite each soul according to that which he hath earned: verily Allah is swift in reckoning.

# 1802

This is a preaching for mankind, and that they may be warned thereby, and that they may know that there is only one God, and that the men of understanding may be admonished.

# 1803

Alif. Lam. Ra. These are the verses of the Book, and a Qur'an luminous.

# 1804

Oft times would those who disbelieve fain that they had been Muslims.

# 1805

Leave them thou to eat and to enjoy, and let vain hope divert them; presently they will know.

# 1806

And We have not destroyed a town but there was therefor a decree known.

# 1807

No community precedeth the term thereof nor doth it fall behind.

# 1808

And they say: O thou unto whom the Admonition hath been sent down! verily thou art possessed.

# 1809

Why bringest thou not angels unto us if thou art of the truthtellers!

# 1810

We send not the angels down save with judgment, and then they would not be respited.

# 1811

Verily We! it is We who have revealed the Admonition, and verily We are the guardians thereof.

# 1812

And assuredly We have sent apostles before thee among the sects of the ancients.

# 1813

And not an apostle came unto them but at him they were wont to mock.

# 1814

Even so we make a way for it in the hearts of the culprits.

# 1815

They believe not therein, and already the example of the ancients hath gone forth.

# 1816

And if We opened upon them a door of the heaven, and they passed the day mounting thereto.

# 1817

They would surely say: intoxicated have been our sights; aye! we are a people enchanted.

# 1818

And assuredly We have set constellations in the heaven and made it fairseeming unto the beholders

# 1819

And We have guarded it from every Satan damned.

# 1820

Save him who stealeth the hearing, and him there followeth a flame gleaming.

# 1821

And the earth! We have stretched it out and have cast thereon mountains firm, and We have caused to spring up thereon everything weighed.

# 1822

And We have appointed thereon for you livelihoods and also for those of whom ye are not the providers.

# 1823

And there is not of aught but with Us are the treasures thereof, and We send it not down save in a measure known

# 1824

And We send the winds fertilizing, then We send down water from the heaven and We give it to you to drink, and thereof ye could not be the treasurers.

# 1825

And verily We! it is We who give life and death, and We shall be the survivors.

# 1826

And assuredly We know those of you who have gone before and those who will come hereafter.

# 1827

And veriiy thy Lord! He will gather them, and verily He is Wise. Knowing.

# 1828

And assuredly We have created human being from ringing clay of loam moulded.

# 1829

And the Jinn, We had created them afore of the fire of the scroching wind.

# 1830

And recall what time thy Lord said unto the angels: verily I am about to createa man from ringing clay of loam moulded.

# 1831

Then when I have formed him and breathed into him of My Spirit fall down unto him prostrate.

# 1832

So the angels prostrated themselves, all of them together.

# 1833

But Iblis did not; he refused to be with the prostrates.

# 1834

Allah said: O Iblis! what aileth thou that thou art not with the prostrates?

# 1835

He said it was not for me that should prostrate myself unto a human being whom Thou hast created from ringing clay of loam moulded.

# 1836

Allah said: then get thee forth therefrom; verily thou art one damned.

# 1837

And verily on thee shall be the curse till the Day of Requital.

# 1838

He said: my Lord! respite me then till the Day whereon they will be raised up.

# 1839

Allah said: verily then thou art of the respited:

# 1840

Till the Day of the Time known.

# 1841

He said: my Lord! because Thou hast led me to err I will surely make things fairseeming unto them on the earth and will surely seduce them all:

# 1842

But not such of them as are Thy bondmen single-hearted.

# 1843

Allah said: this is the path leeding unto Me straight.

# 1844

Verily as for My bondmen, no authority shalt thou have over them, except the erring one who follow thee.

# 1845

And verily Hell is the place promised unto them all.

# 1846

Unto it are seven portals; unto each portal is a Portion of them assigned.

# 1847

Verily the God-fearing shall be amidst gardens and springs.

# 1848

Enter therein in peace, secure.

# 1849

And We shall have removed whatsoever of grudge may be in their breasts: brethren they. sitting upon couches facing each other.

# 1850

There shall touch them no toil therein, nor therefrom they shall ever be driven out.

# 1851

Declare thou unto My bondmen: verily I! I am the Forgiver, the Merciful.

# 1852

And verily My torment! that is the torment afflictive

# 1853

And declare thou unto them of Ibrahim's guests.

# 1854

When they entered unto him, and said; peace! He said: verily we are afraid of you.

# 1855

They said: be not afraid; verily we bear thou the glad tidings of a boy knowing.

# 1856

He said: bear ye me glad tidings when old age hath touched me? of what then ye bear me glad tidings?

# 1857

They said: we bear tidings of a truth; be then thou not of the desponding.

# 1858

He said: and who despondeth of the mercy of his Lord except the astray

# 1859

He said: what is your errand, sent ones?

# 1860

They said: verily we have been sent unto a people guilty-

# 1861

All except the household of Lut; surely we are going to deliver all of them.

# 1862

But not his wife; we have decreed that she will be of those staying behind.

# 1863

Then when the sent ones entered unto the household of Lut.

# 1864

He said: verily ye are a people stranger.

# 1865

They said: nay! we have come to thee with that whereof they have been dubitating.

# 1866

And we have brought unto thee the truth, and verily we say sooth.

# 1867

So set out thou with thy house hold in a portion of the night, and follow thou their backs, and let not one of you look back, and pass whither ye are commanded.

# 1868

And We decreed unto him this commandment because the last of those was to be cut off in the early morning.

# 1869

And there came the people of the city rejoicing

# 1870

He said: verily these are my guests, so disgace me not.

# 1871

And fear Allah, and humiliate me not.

# 1872

They said: forbade we not thee against the worlds?

# 1873

He said: these are my daughters, if act ye must.

# 1874

By thy life, in their intoxication they were wandering bewildered.

# 1875

Then the shout took hold of them at the sunrise.

# 1876

And We made the upside there of downwards, and We rained on them stones of baked clay.

# 1877

Verily therein are signs for men of sagacity.

# 1878

And verily they are on a pathway lasting.

# 1879

Verily in that is a sign for the believers.

# 1880

And the dwellers of the wood surely were wrong-doers.

# 1881

So We took vengeance on them. And verily both are on a high-road open.

# 1882

And assuredly the dwellers of Hijr belied the sent ones.

# 1883

And We brought Our signs unto them, yet they were averting themselves therefrom.

# 1884

And they were hewing out houses from mountains feeling secure.

# 1885

Then the shout took hold of them in the early morn.

# 1886

Then availed them not that which they had been earning.

# 1887

And We have not created the heaven and the earth and that which is in between them save with a purpose. And verily the Hour is surely coming; so overlook thou with a seemly overlooking,

# 1888

Verify thy Lord! He is the Great Creator, the Knower.

# 1889

And assuredly We have vouchsafed unto thee seven of the repetitions and the mighty Qur'an.

# 1890

Cast not thine eyes toward that which We have let classes of them to enjoy; and grieve not over them, and lower thy wing unto the believers.

# 1891

And say thou: verily I! I am a plain warner.

# 1892

Even as We sent down on the dividers -

# 1893

Those who have made the scripture bits.

# 1894

By thy Lord, We will question them all.

# 1895

For that which they have been working.

# 1896

Promulgate thou that which thou art commanded, and turn away from the associaters.

# 1897

Verily We will suffice unto thee against the mockers.

# 1898

Who set up along with Allah anot her god; presently they shall know.

# 1899

And assuredly We know that thou straitenest thy breast by that which they say.

# 1900

So hallow thou the praise of thy Lord, and be thou of the prostrate.

# 1901

And worship thy Lord until there cometh unto thee the certainty.

# 1902

The affair of Allah cometh, so seek not to hasten it. Hallowed be He and Exalted above that which they associate.

# 1903

He sendeth down the angels with the spirit by His command upon whomsoever of his bondmen He willeth: warn that there is no god but I, wherefore fear Me.

# 1904

He hath created the heavens and the earth with a purpose. Exalted is He above that which they associate.

# 1905

He hath created man from a drop, and Lo! he is a disputer open.

# 1906

And the cattle! He hath created them. For you in them there is warmth and other profits and of them ye eat.

# 1907

And for you there is beauty in them as ye drive them at eventide and as ye drive them out to pasture.

# 1908

And they bear Your loads to a city Which ye could not reach except with travail of souls; verily your Lord is Kind, Merciful.

# 1909

And He hath created horses and mules and asses that ye may ride there on, and as an adornment; and He createth that which ye know not.

# 1910

And upon Allah is the direction of the way, and thereof is some crooked; and had He willed He would have guided you all.

# 1911

He it is who sendeth down from the heaven water for you, wherefrom is drinking and wherefrom are trees whereas ye pasture your herds.

# 1912

He groweth for you thereby the corn and olives and date- palms and grapes and all kinds of fruit. Verily therein is a sign for a people who ponder.

# 1913

And He hath subiected for you the night and the day and the sun and the moon, and the stars are subjected by His command. Verily therein are signs for a people who understand.

# 1914

And He hath subjected for you whatsoever He hath multiplied for you on the earth of various kinds. Verily therein is a sign for a people who receive admonition.

# 1915

And He it is who hath subjected the sea that ye may eat thereout flesh fresh and bring forth therefrom ornaments that ye wear. And thou beholdest ships ploughing therein, and it is in order that ye may seek of His grace, and that haply ye may give thanks.

# 1916

And He hath cast on the earth firm mountains lest it move away with you, and rivers and paths that haply ye may be directed.

# 1917

And also landmarks; and by the stars they are guided.

# 1918

Is there one who createth like unto one who createth not? Will ye not then be admonished?

# 1919

And if ye would count the favours of Allah ye could not compute them verily Allah is Forgiving, Merciful.

# 1920

And Allah knoweth that which ye keep secret and that which ye publish.

# 1921

And those upon whom they call beside Allahls have not created aught, and are themselves created.

# 1922

Dead are they, not alive; and they perceive not when they will be raised up.

# 1923

God of you all is One God; so those who believe not in the Hereafter-their hearts are perverse and they are stiff-necked.

# 1924

Undoubtedly Allah knoweth that which they keep secret and that which they publish; verily He loveth not the stiff- necked.

# 1925

And when it is said unto them: what is it that your Lord hath sent down? they say: fables of the ancient.

# 1926

That they may bear their burthens in full on the Judgment- Day and also some of the burthens of those whom they have led astray without knowledge. Lo! vile is that which they shall bear!

# 1927

Surely there plotted those before them, but Allah came upon their structures from the foundations, so the roof fell down upon them from above them and the torment came upon them whence they perceived not.

# 1928

Then on the Judgment-Day He will humiliate them and say: where are My associates regarding whom ye have been causing cleavage? Those who have been vouchsafed knowledge will say: verily the humiliation to-day and ill-hap are upon the infidels-

# 1929

Those whom the angels cause to die while they are wronging them selves, and then they proffer submission: we have not been working any evil. Yea! verily Allah is the Knower of that which ye have been working.

# 1930

Wherefore enter the portals of Hell as abiders therein. Vile is the abode of the arrogant

# 1931

And when it is said unto those who fear: what is it that your Lord hath sent down? They say: that which is better. For those who do good is good in this world, and the dwelling of the Hereafter is better. Excellent is the dwelling of the God-fearing!

# 1932

Gardens Everlasting which they shall enter, whereunder rivers flow; theirs therein shall be whatsoever they list; Thus Allah recompenseth the God-fearing-

# 1933

Those whom the angels cause to die while they are clean, saying peace be upon you! enter the Garden for that which ye have working.

# 1934

Await they aught but that the angels should come unto them or the command of thy Lord should come Likewise did those before them. Allah wronged them not, but they were wont to wrong themselves.

# 1935

Then there be-fell them the vices of that which they had worked, and there surrounded them that whereat they had been mocking.

# 1936

And those who associate say: had God willed we would not have worshipped aught beside Him, neither we nor our fathers, nor we would have forbidden aught without Him. Like-wise did those before them. Naught is then on the apostles except a preaching plain.

# 1937

And assuredly We have raised in every community an apostle saying: worship Allah and avoid the devil. Then of them were some whom Allah guided, and of them were some upon whom the straying was justified. Wherefore travel about on the earth, and look on what wise hath been the end of the disbelievers.

# 1938

If thou art solicitous for their guidance, then verily Allah guideth not whomsoever He sendeth astray, and for them there are no helpers.

# 1939

And they swear by God the most solemn of oaths that God would not raise him who dieth. Yea! it is a promise on Him incumbent but most of mankind know not.

# 1940

This will be in order that he may manifest unto them that wherein they differ, and that those who disbelieved should come to know that they had been liars.

# 1941

Our only saying unto a thing, when We intend it, is that We say unto it: be, and it becometh.

# 1942

And those who have emigrated for the sake of Allah after they had been wronged. We shall surely settle them well in the world and the hire of the Hereafter is greater: if they but know!

# 1943

They are those who bear with patience, and in their Lord they trust.

# 1944

And We sent not before thee any but men unto whom We Revealed; so ask ye the people of the Admonition if ye know not.

# 1945

With evidences and scriptures We sent them. And We have sent down unto thee the Admonition that thou mayest expound unto mankind that which hath been revealed toward them, and that haply they may reflect.

# 1946

Feel then they secure who have plctted vices that Allah will not sink them into the earth or that the torment may come upon them whence they perceive not?

# 1947

Or, thathe will not take hold of them in their going to and fro! so that they cannot escape.

# 1948

Or, that he will not take hold of them by giving them a fright? verily thy Lord is Kind, Merciful.

# 1949

Have they not observed the things which Allah hath created? shadows thereof turn themselves on the right and on the left. prostrating themselves unto Allah, and they are lowly.

# 1950

And unto Allah prostrateth itself whatsoever is in the heavens and whatsoever is in the earth of the living creatures and also the angels; and they are not stiff-necked.

# 1951

They fear their Lord above them and do that which they are commanded.

# 1952

And Allah hath said: take not two gods; He is only One God so Me alone, Me dread.

# 1953

And His is whatsoever is in the heavens and the earth, and unto Him is obedience due perpetually; will ye then fear any other than Allah?

# 1954

And whatsoever of favours is with you is from Allah; then when distress toucheth you, unto Him ye cry out.

# 1955

Then when He removeth the distress from you, forthwith a party of you with their Lord associate.

# 1956

That they may show ingratitude for that which We have vouchsafed unto them. Enjoy then, presently ye shall know.

# 1957

And they appoint for that which they knew not a portion of that wherewith We have provided them By Allah! ye will surely be questioned regarding that which ye have been fabricating.

# 1958

And they appoint for Allah daughters --hallowed be He! -- and for themselves that which they desire.

# 1959

And when there is announced unto any of them a female his countenance remainoth darkened the whole day and he is wroth inwardly.

# 1960

Skulking from the people because of the evil of that which hath been announced unto him: shall he keepit with ignominy or bury it in the dust! Lo'. vile is that which they judge!

# 1961

For those who believe not in the Hereafter is an evil similitude, and for Allah is the sublime similitude, and He is the Mighty, the Wise.

# 1962

And if Allah were to lay hold of mankind for their wrong- doing, not a living creature He would leave on it, but he deferreth them to a term appointed, then, when their term cometh, they cannot put it off by an hour not anticipate it.

# 1963

And they ascribe to Allah that which they detest, and their tongues utter the lie that unto them shall be good; undoubtedly unto them shall be the Fire, and they will be hastened thereto.

# 1964

By Allah! assuredly We have sent apostles to communities before thee, then the Satan made their works fairseeming unto them, so he is their patron to-day, and unto them shall be a torment afflictive.

# 1965

And We have not sent down the Book unto thee save in order that thou mayest expound unto them that wherein they differ, and as a guidance and a mercy unto a people who believe.

# 1966

And Allah hath sent down from the heaven water, then he reviveth the earth thereby after the death thereof; verily therein is a sign for a people who hearken.

# 1967

And verily there is for you in the cattle a lesson: We give you to drink of that which is in their bellies, from betwixt the dung and the blood: milk Pure and pleasant to swallow for the drinkers.

# 1968

And also a lesson for you in the fruits of the date-palms and the grapes whereof ye take a liquor and a provision goodly; verily therein is a sign far a people who understand.

# 1969

And thy Lord inspired the bee saying: take thou for thyself of the mountains houses and of the trees and of that which they erect.

# 1970

Then eat thou of all the fruits and tread the ways of thy Lord made easy. There springeth forth from their bellies a drink varied in colours; therein is healing for mankind; verily therein is a sign for a people who reflect.

# 1971

And Allah hath created you, then He taketh your souls; of you are some who are brought back to the meanest of age, so that they know not aught after having knowledge; verily Allah is Knowing, Potent.

# 1972

And Allah hath preferred some of you over some other in provision; then those who are preferred are not going to hand over their provision to those whom their right hands possess as to be equal in respect thereof. Gainsay they then the favour of Allah?

# 1973

And Allah hath appointed for yourselves spouses, and from your spouses He hath appointed for you sons and grandsons, and He hath provided you with clean foods. In falsehood then believe they, and in Allah's favour disbelieve they?

# 1974

And they worship, beside Allah, that which owneth them not any provision from the heavens and the earth, and they cannot

# 1975

Propound not then for Allah similitudes, verily Allah knoweth and ye know not.

# 1976

Allah propoundeth a similitude: there is a bondman enslaved who hath not power over aught; and there is one whom We have provided from Ourselves with goodly provision and he expendeth thereof secretly and openly; can they be equal? All praise Unto Allah; but most of them know not.

# 1977

And Allah propoundeth a similitude: there are two men, one of them dumb who hath of Power over aught and is a weariness unto his master, whithersoever he directeth him he bringeth not any good; is he equal with one who commandeth justice and in himself on a straight patht?

# 1978

And Allah's is the Unseen of the heavens and the earth, and the affair of the Hour will be not but as a flash of the eye, or it is even nearer, verily Allah is over everything Potent.

# 1979

And Allah hath brought you forth from the bellies of your mothers while ye know not aught, and He hath appointed for you hearing and sight and hearts that haply ye might give thanks.

# 1980

Behold they not the birds subjected in the firmament of the heaven? Naught supporteth them save Allah; verily therein are signs for people who believe.

# 1981

Allah hath appointed for you from your houses a repose, and He hath appointed for you from the skins of the cattle houses which ye find light, on the day of your flitting and on the day of your stopping, and from their wools and their furs and their hair a furnishing and an enjoyment for a season.

# 1982

And Allah hath appointed for you, of that which He hath created shades, and He hath appointed for you from the mountains places of retreat, and He hath appointed for you coats protecting you from the heat and coats protecting you from the violence. Thus He perfecteth His favour on you that haply ye may submit.

# 1983

Then if they turn away, on thee is only the preaching plain.

# 1984

They recognize the favour of Allah, then they deny it, and most of them are infidels.

# 1985

And bewore a Day whereon We will raise up from each community a witness, then those who have disbelieved will not be given leave, nor they will be permitted to please Allah.

# 1986

And when those who have done wrong will behold the torment, it will not be lightened unto them, nor will they be respited.

# 1987

And when those who have associated will behold their associate-gods, they will say: our Lord! yonder are our associate-gods upon whom we have been calling beside Thee, they Will proffer them the saying: verily ye are liars.

# 1988

And they will proffer sub mission unto Allah on that Day, and there will stray from them that which they have been fabricating.

# 1989

Those who disbelieved and hindered others from the way of Allah- We shall increase for them torment upon torment for they have been spreading corruption.

# 1990

And beware a Day whereon We shall raise up in every community a witness regarding them from amongst them selves, and We shall bring thee as a witness regarding these. And We, have revealed unto thee the Book as an exposition of everything and as a guidance and mercy and glad tidings to the Muslims.

# 1991

Verily Allah commandeth justice and well-doing and giving to kindred; and He prohibiteth lewdness and wickedness and oppression; He exhorteth you that haply ye may beadmonished.

# 1992

And fulfil the covenant of Allahs when ye have covenanted, and violate not the oaths after the ratification thereof, and surely ye have appointed Allah a surety over you. verily Allah knoweth that which ye do:

# 1993

And be not like unto her who unravelleth her yarn into strands after its strength, holding your oaths a means of discord amongst you that a community may be more numerous than anot her community; Allah only proveth you there by; and He will surely manifest unto you on the Judgment Day that wherein ye have been differing.

# 1994

And had Allah willed, He would have made you all one community, but he sendeth astray whomsoever He willeth, and guideth whomsoever He willeth; and surely ye shall be questioned regarding that which ye have been working.

# 1995

And make not your oaths a means of discord amongst you lest a foot may slip after the fixture thereof, and ye may taste evil for having hindered others from the way of Allah, and unto you there shall be a torment mighty.

# 1996

And barter not the covenant of Allah for a small price; verily that which is with Allah --that is better for you, if ye only know.

# 1997

That which is with you is exhausted, and that which is with Allah is lasting. And We will surely recompense those who have been patient their hire for the best of that which they have been working

# 1998

Whosoever worketh righteously, male or female, and is a believer, We will surely quicken him to a clean life, and will surely recompense them their hire for the best of that which they have been working.

# 1999

And when thou wouldst read the Qur'an seek refuge with Allah from Satan the damned.

# 2000

Verily he hath no authority over those who believe and in their Lord trust

# 2001

His authority is only over those who befriend him and those who are in respect of Him associators.

# 2002

And whenever We change a verse in place of anot her verse - -and Allah is the Best Knower of that wwhich He revealeth --they say: thou art but a fabricator, Aye! most of them know not.

# 2003

Say thou: the Holy Spirit hath brought it down from thy Lord with truth, that it may establish those who believe, and as a guidance and glad tidings unto the Muslims.

# 2004

And assuredly We know that they say: it is only a human being who teachech him. The speech of him unto whom they incline is foreign while this is Arabic speech plain.

# 2005

Verily those who believe not in the signs of Allah--Allah shall not guide them, and unto them shall be a torment afflictive.

# 2006

It is only those who believe not in the signs of Allah who fabricate lie, and those! they are the liars.

# 2007

Whosoever disbelieveth in Allah after his belief--save him who is constrained and his heart is at rest with the belief -but whosoever expandeth his breast to infidelity, upon them shall be wrath from Allah, and unto them shall be a torment mighty.

# 2008

That is because they loved the life of the world above the Hereafter, and because Allah guideth not an infidel people.

# 2009

These are they upon whose hearts and hearing and sight Allah hath set a seal; and these! they are the negligent.

# 2010

Undoubtedly they in the Hereafter shall be the very losers.

# 2011

Then, verily, thy Lord unto those who have emigrated after they had been tempted and have thereafter striven hard and endured, verily thy Lord thereafter is Forgiving, Merciful.

# 2012

Beware a Day whereon each soul will come pleading for itself, and each soul will be paid in full that which it hath wrought, and they shall not be wronged.

# 2013

And Allah propoundeth a similitude: a town which was secure and at rest, to which came the provision thereof plenteously from every place; then it ungratefully denied the favours of Allah; wherefore Allah made it taste the extreme of hunger and fear because of that which they were wont to perform.

# 2014

And assuredly there came to them an apostle from among them, but they belied him, wherefore the torment took hold of them while yet they were wrong-doers.

# 2015

So eat of that which Allah hath provided you of lawful and clean things, and give thanks for Allah's favour, if it is He whom ye are went to Worship.

# 2016

He hath only disallowed unto you the dead-meat and blood and swine-flesh and that over which is invoked the name of other than Allah. Then whosoever is driven by necessity, not alusting nor transgressing verily Allah Is Forgiving, Merciful.

# 2017

And say not concerning that wherein Your togues utter a lie: this is lawful, and this is unlawful, that ye may fabricate a lie againt Allah, verily those who fabricate lie against Allah shall not fare well.

# 2018

A brief enioyment, and unto them shall be a torment afflictive.

# 2019

And un to those who are Judaised We disallowed that which We have already recounted unto thee; and We wronged them not, but themselves they were wont to Wrong.

# 2020

Then, verily, thy Lord unto those who work evil from ignorance, and then repent thereafter and amend, verily thy Lord thereafter is Forgiving, Merciful.

# 2021

Verily Ibrahim was a pattern, devout unto Allah, upright, and, not of the associaters.

# 2022

Grateful for His favours: He chose him and guided him to a straight path.

# 2023

And We vouchsafed unto him good in this world, and in the Hereafter he shall be of the righteous.

# 2024

Afterwards We revealed unto thee: follow thou the faith of Ibrahim the upright; and he was not of the associaters.

# 2025

The sabbath was only appointed for those who differed thereon; and verily thy Lord will judge between them on the Judgment-Day concerning that wherein they have been differing.

# 2026

Call them unto the way of thy Lord with Wisdom and goodly exhortation, and argue with them with that which is best. Verily thy Lord! He is the Best Knower of him who hath strayed from His way, and He is the Best Knower of the guided ones.

# 2027

And if ye chastise, then chastise with the like of that wherewith ye were afflicted, and if ye endure patiently, then surely it is better for the patient.

# 2028

And endure them patiently; and thy patience is not but from Allah; and grieve not over them, and be not thou in straitness because of that which they plot.

# 2029

Verily Allah is with those who fear and those who are well- doers.

# 2030

Hallowed be He Who translated His bondman in a night from the Sacred Mosque to the Furthest Mosque, the environs whereof We have blest, that We might shew him of Our signs; verily He! He is the Hearer, the Beholder.

# 2031

And We vouchsafed unto Musa the Book and We appointed it as a guidance to the Children of Isra'il: take not beside Me a trustee.

# 2032

O progeny of those whom We bare with Nuh: verily he was a bondman grateful.

# 2033

And We decreed unto the Children of Isra'il in the Book; ye will surely cause corruption in the land twice, l and ye will surely rise to a great height.

# 2034

Then when the promise for the first of the two came, We raised against you bondmen of Ours endued with exceeding violence, so they entered the dwellings; and it was a promise fulfilled.

# 2035

Thereafter We gave you a return of victory over them, and We supported you with riches and children, and We made you a numerous concourse.

# 2036

If ye will do well ye will do well for yourselves, and if ye will do evil it will be against the same. Then when the promise of the second came, We raised up a people that they may disgrace your faces and may enter the Mosque even as they entered it the first time, and that they may destroy with utter destruction whatsoever may fall under their power.

# 2037

Belike your Lord may yet have mercy on you; and if ye still revert, We will revert. And We have appointed Hell for the infidels a prison.

# 2038

Verily this Qur'an guideth unto that path which its sraightest and beareth glad tidings to the believers who work righteous deeds that for them shall be a hire great.

# 2039

And that those who believe not in the Hereafter--for them We have gotten ready a torment afflictive.

# 2040

And man prayeth for evil the prayer he should make for good, and man is ever hasty.

# 2041

And We have appointed the night and the day as two signs; then We blurred the sign of the night and made the sign of the day illuminating that ye may seek grace from Your Lord, and that ye may know the number of the years and the reckoning; and everything We have detailed in full details.

# 2042

And every man: We have fastened his action round his neck, and We shall bring forth unto him on the Day of Judgment a book proffered him open.

# 2043

Read thine book; sufficeth to-day thy soul against thee as a reckoner.

# 2044

Whosoever is guided, it is only for himself that he is guided and whosoever Strayeth, it is only against the same that he strayeth; and a burthen-bearer beareth not the burthen of anot her. And We have not been tormentors until We had raised an apostle.

# 2045

And when We intend that We shall destroy a town We command the affluent people thereof, then they transgress therein; wherefore the word is justified on them; then We annihilate it with Utter annihilation.

# 2046

How many a generation have We destroyed after Nuh; and sufficeth for the offences of His bondmen thy Lord as the Aware, the Beholder.

# 2047

\- Whosoever intendeth the quick Passing world, We hasten to him therein whatsoever We please unto whomsoever We intend; thereafter We shall appoint for him Hell wherein he shall roast, reproved, rejected.

# 2048

And whosoever intendeth the Hereafter and striveth therefor with due striving, while he is a believer, then those: their striving shall be appreciated.

# 2049

To each--these and those--We extend of the bestowment of thy Lord; and the bestowment of thy Lord is never restrained.

# 2050

Behold thou! how We have preferred some of them over some others; and surely: the Hereafter is greater in degrees and greater in preferment.

# 2051

Set not up along with Allah anot her god, lest thou sit down reproved, renounced.

# 2052

And thy Lord hath decreed that ye shall Worship none but Him, and unto parents shew kindness; and if either of them or both of them attain old age with thee, Say not unto them: pooh: And browbeat them not, and Speak unto them a respectful speech.

# 2053

And lower unto them the wing of meekness out of mercy, and say: O my Lord! have mercy on the twain even as they brought me up when young.

# 2054

Your Lord is the Best Knower of that which is in your souls; if ye have been righteous, then He is unto thee Oftreturning, Forgiving.

# 2055

And give thou to the kinsman his due, and also unto the needy and the wayfarer; and squander not in squandering.

# 2056

Verily the squanderers are ever the brethren of the Satans, and the satan is ever unto his Lord ungrateful.

# 2057

And if thou turnest away from them awaiting a mercy from thy Lord which thou hopest, then speak unto them a gentle speech.

# 2058

And let not thine hand be chained to thy neck, nor stretch it forth to the utmost stretching, lest thou sit down reproached, impoverished.

# 2059

Verily thy Lord extendeth the provision for whomsoever He will and He measureth it out; verily He is in respect of His bondmen Aware, Beholder.

# 2060

And saly not your offspring for fear of want; We provide for them and for yourselves; verily their slaying is a great crime.

# 2061

And approach not adultery; verily it is ever an abomination and vile as a pathway.

# 2062

And slay not anyone whom Allah hath forbidden except for justification; and whosoever is slain wrongfully, We have surely given his next-of-kin authority so let him not be extravagant in slaying; verily he is ever succoured.

# 2063

And approach not the substance of an'orphan save with that which is best, until he attaineth his age of strength. And fulfil the covenant; verily the covenant shall be asked about.

# 2064

And give full measures when ye measure and weigh with an even balance that is good, and the best interpretation.

# 2065

And go not thou after that where of thou hast no knowledge verily the hearing and the sight and the heart, each of these shall be asked about.

# 2066

And walk thou not on the earth struttingly; verily thou wilt by no means rend the earth, nor canst thou attain to the mountains in stature.

# 2067

Each of these--theyice thereof is unto thy Lord ever detestable.

# 2068

That is Part of that wisdom which thy Lord hath revealed unto thee, and set not up thou along with Allah anot her god, lest thou be cast into Hell, reproved, rejected.

# 2069

Hath then your Lord distinguished you with sons and taken for Himself females from among the angels? Verily ye say a saying mighty?

# 2070

And assurelly We have propounded it variously in this Qur'an that they might be admonished, but it increaseth them only in aversion.

# 2071

Say thou: were there along with Him other gods, as they say, then they would have brought unto the Owner of the Throne a way.

# 2072

Hallowed be He, and exalted be He above that which they say --a greatheight!

# 2073

There hallow Him the seven heavens and the earth and whosoever is therein. And naught there is but halloweth His praise, but ye understand not their hallowing; verily He is ever Forbearing, Forgiving.

# 2074

And when thou recitest the Qur'an, We set up between thee and those who believe not in the Hereafter a curtain drawn down.

# 2075

And We set up over their hearts veils lest they understand it, and in their ears heaviness and when thou mentionest in reciting the Qur'an thy Lord alone, they turn backward as averters.

# 2076

We are Best Knower of that wherewith they listen what time they listen to thee and what time they counsel together in secret, when the wrong-doers say: ye but follow a man enchanted.

# 2077

Behold! how they propound similitudes for thee! They have strayed and cannot find a way.

# 2078

And they say: when we shall have become bones and fragments, shall we in sooth be raised as a new creation?

# 2079

Say thou: become ye stones or iron.

# 2080

Or anything created of the things more remote in your breasts. Then they will say: who will restore us! Say thou: He who created you the first time. Then they will wag their heads at thee and say; when will it be! Say thou: belike it is nigh-

# 2081

The Day whereon He will call you, and ye will answerl with His praise, and ye will imagine that ye had tarried but little.

# 2082

Say thou unto My bondmen that they should say that which is best, Verily the Satan would stir up strife between them; verily the Satan is unto men ever an enemy manifest.

# 2083

Your Lord is the Best Knower of you; if He willeth He will have mercy upon you, or if He willeth He will torment you. And We have not sent thee over them as a trustee.

# 2084

And thine Lord is the Best Knower of those who are in the heavens and the earth. And assuredly We have preferred some prophets over some others: and We vouchsafed unto Daud a Scripture.

# 2085

Say thou: call upon those whom ye fancy beside Him; they are able neither to remove the distress from you nor to work a turning off.

# 2086

Those whom they call upon themselves seek access to their Lord, striving which of them shall be the nearest; and they hope for His mercy and fear His torment; verily the torment of thy Lord is ever to be guarded against.

# 2087

Not a town is there but VVe are going to destroy it before the Day of Judgment or to torment it With a severe torment; that is in the Book inscribed.

# 2088

And naught hinderedeth Us from sending the signs except that the ancients belied them. And We vouchsafed unto Thamud a she-camel as an illumination, but they did her wrong. And We send not the signs save to frighten.

# 2089

And recall what time We said unto thee: verily thy Lord hath encompassed mankind. And We made the vision We shewed thee but a temptation for men, and likewise the tree accurst in the Qur'an. And We frighten them, but it only increaseth them in exorbitance great.

# 2090

And recall what time We said unto the angels: prostrate youselves before Adam. So they prostrated themselves, but Iblis did not; he said: shall I prostrate myself before one whom Thou hast created of clay?

# 2091

lblis said; bethinkest Thou: This one whom Thou hast honoured above me- if Thou deferrest me till the Day of Judgment, shall surely seize his progeny save a few.

# 2092

Allah said: be thou gone; then who soever of them followeth thee, Hell is your meed, a meed ample.

# 2093

And unsettle thou whomsoever of them thou canst with thy voice, and summon against them thine horse and thine foot, and share with them riches- and children, and promise unto them; and the Satan promiseth not but to delude.

# 2094

Verily My bondmen; over them thou hast no authority; and thy Lord sufficeth as a Trustee.

# 2095

Your Lord is He who speedeth for you the ship in the sea that ye may seek His grace; verily He it unto you ever Merciful.

# 2096

And when there toucheth you a distress on the sea, those whom ye call upon fall away except Him alone, then when He delivereth you on the land ye turn away: and man is ever ungrateful.

# 2097

Are ye then secure that he will not cause a side of the land to swallow you up, or send over you a sand-storm, and then ye will not find for yourselves a trustee?

# 2098

Or are ye secure that he will not send you back therein anot her time and then send upon you a gale of wind and drown you for your having disbelieved, so that therein you will not find for yourselves against Us an avenger?

# 2099

And assuredly We have honoured the Children of Adam: and We have borne them on the land and the sea, and We have provided them with clean things, and We have preferred them over many of them whom We have created with a preferment.

# 2100

Remember the Day whereon We shall call all man kind with their record: then whosoever will be vouchsafed his book in his right hand, those shall read their book, and they shall not be wronged a whit.

# 2101

And whosoever hath been in this life blind will in the Hereafter be blind, and far astray from the way.

# 2102

And verily they had well-nigh tempted thee away from that which We have revealed unto thee, that thou shouldst fabricate regarding something else; and then surely they would have taken thee as a friend!

# 2103

And were it not that We had confirmed thee, thou hadst well-nigh leaned toward them a little.

# 2104

In that case We would have surely made thee taste the double of the tornment of the life and the double of the torment of death, and then thou wouldst not find against Us a helper.

# 2105

And verily they had well-nigh unsettled thee from the land that they might drive thee forth from thence. And in that case they would not have tarried after thee but a little while.

# 2106

This was Our dispensation with those whom We sent before thee of Our apostles, and thou wilt not find in this Our dispensation a change.

# 2107

Establish thou the prayer from the declination of the sun to the darkening of the night, and the Recitation at the dawn; verily the Recitation at the dawn is ever borne witness to.

# 2108

And of the night--keep the vigil therein, as an act of supererogation for thee; belike thy Lord will raise thee up in a station praised.

# 2109

And say thou: O my Lord! cause me to enter a rightful entrance and cause me to go forth with a rightful outgoing, and appoint for me from before Thee an authority helpful.

# 2110

And say thou: the truth is come, and falsehood hath vanished; verily falsehood is ever vanishing.

# 2111

And We reveal by means of the Qur'an that which is a healing and a mercy unto the believers, and it only increaseth the wrong- doers in loss.

# 2112

And when We show favour unto he turneth away and withdraweth on his side; and when evil toucheth him he is ever despairing.

# 2113

Say thou: everyone worketh after his disposition, and your Lord is the Best Knower of him who is best guided on the Way.

# 2114

And they ask thee regarding the spirit, Say thou: the spirit is by the command of my Lord, and ye have not been vouchsafed of knowledge save a little.

# 2115

And if We listed, We could surely take away that which We have revealed unto thee: then thou wilt not find in respect thereof against us as trustee.

# 2116

Except as a mercy from thy Lord verily His grace unto thee is ever great.

# 2117

Say thou: if the mankind and the jinn leagued together that they might produce the like of this Qur'an, they could nor produce the like thereof, though one to the other were a backer.

# 2118

And assuredly We have variously propounded for mankind in this Qur'an every kind of similitude, yet most men have refused everything except infidelity.

# 2119

And they say: we shall by no means believe in thee until thou causest for us to gush forth from the earth a foun tain.

# 2120

Or there be for thee a garden of date-palms and wine, and thou causest in the midst thereof rivers to gush forth.

# 2121

Or thou causest the heaven to fall upon us, as thou assertest, in pieces, or thou bringest God and the angels face to face.

# 2122

Or there be for thee a house of gold or thou mountest to the heaven, and we will by no means believe in thy mounting even until thou causest a book to be sent down to us, which we may read. Say thou: hallowed be my Lord! I am naught but a human being sent as an apostle.

# 2123

And naught hath prevented men from believing when the guidance came Unto them except that they said: hath God sent a human being as apostle?

# 2124

Say thou: were there in the earth angels walking about contentedly, We would surely have sent down unto them from the heaven an angel as an apostle.

# 2125

Say thou: Allah sufficeth as a witness between me and you; verily He is in respect of His bondmen ever the Aware, the Beholder.

# 2126

And whomsoever Allah guideth, then he is the guided; and whomsoever He sendeth astray--for such thou wilt by no means find friends beside Him. And We shall gather them on the Day of Judgment on their faces, blind and deaf and dumb; their abode being Hell; so oft as it grosweth dull We shall increase for them the Flame.

# 2127

This shall be their meed because they disbelieved in Our signs and said when we have become bones and fragments, shall we in sooth be raised up a new creation!

# 2128

Behold they not that Allah who created the heavens and the earth is Able to create their likes? And He hath appointed for them a term whereof there is no doubt; yet the wrong-doers have refused everything excepting infidelity.

# 2129

Say thou: if it were ye who owned the treasures of the mercy of my Lord, ye would surely refrain for fear of expending; and man is ever miserly.

# 2130

And assuredly We vouchsafed unto Musa nine manifest signs - ask thou the Children of Israel--so when he came unto them, Fir'awn said unto him, verily imagine thee, O Musa! enchanted.

# 2131

Musa said: assuredly thou knowest that none hath sent down these save the Lord of the heavens and the earth as an enlightenment; and verily imagine thee, Fir'awn, doomed.

# 2132

Then he besought to unsettle them from the land; wherefore We drowned him and those with him, all together.

# 2133

And We said, after him, unto the Children of Isra'l: dwell on the earth, then when there cometh the promise of the Hereafter, We shall bring you as a crowd.

# 2134

And with truth We have sent it down and with truth it hath come down; and We have not sent thee but as a bringer of glad tidings and a warner.

# 2135

And this is a Recitation which We have made distinct that thou mayest recite it unto mankind with delay, and We have revealed it at intervals.

# 2136

Say thou: whether ye believe it or believe it not, verily those who were vouchsafed knowledge before it, when it is recited unto them, fall down on their chins, prostrating.

# 2137

And they say: hallowed be our Lord! the promise of Our Lord was ever to have been fulfilled.

# 2138

And they fall down on their chins weeping, and it increaseth them in humility.

# 2139

Say thou: call upon Allah or call upon Rahman, by whichsoever ye call, His are the excellent names. And shout not thy prayer, nor speak it low, but Seek between these a way.

# 2140

And say thou: all praise is unto Allah who hath not taken a son, and whose is no associate in the dominion, nor hath He a protector through weakness, and magnify Him with all magnificence.

# 2141

All praise unto Allah who hath sent down unto His bondman the Book, and hath not placed therein any crookedness.

# 2142

Straightforward, that it may warn of a severe violence from before Him, and bring glad tidings to the believers who work righteous works that theirs shall be a goodly hire.

# 2143

They will abide therein for ever.

# 2144

And that it may warn those who say: God hath taken a son.

# 2145

No knowledge thereof have they, nor had their fathers. Odious is the word that cometh out of their mouths; they say not but a lie.

# 2146

Haply thou art going to kill thyself over their footsteps, if they believe not in this discourse, out of sorrow.

# 2147

Verily We have made whatsoever is on the earth as an adornment thereof, that We may prove them - which of them is best in work.

# 2148

And verily We are going to make whatsoever is thereon a soil bare.

# 2149

Deemest thou that the people of the cave and the inscription were of Our signs a wonder?

# 2150

Recall what time the youths betook themselves to the cave, then said: our Lord! vouchsafe unto us mercy from before Thee, and prepare for us in our affair a right course.

# 2151

Wherefore We put a covering over their ears in the cave for a number of years.

# 2152

Thereafter We raised them up that We might know which of the two parties was best at reckoning the time that they had tarried.

# 2153

We recount unto thee their tidings With truth. Verily they were certain youths who believed in their Lord, and We increased them in guidance.

# 2154

And We braced their hearts when they stood forth and said: our Lord is the Lord of the heavens and the earth; never we shall call upon a god beside him; for then we shall be saying an abomination.

# 2155

These, our people, have taken for themselves gods beside Him - wherefore bring they not for them an authority manifest? --and who doth greater wrong than he who fabricateth against God a lie?

# 2156

And now when ye have withdrawn from them and that which they worship, except God, betake yourselves to the cave; your Lord will unfold for you some of His mercy, and will prepare for you of your affair an easy arrangement.

# 2157

And thou Woudst behold the sun when it riseth veering away from their cave on the right, and when it setteth, passing them by on the left, while they were in the spacious part thereof: that is of the signs of Allah. Whomsoever Allah guideth, he indeed is the guided; and whomsoever He sendeth astray, for him thou wilt never find a directing friend.

# 2158

And thou wouldst have deemed them awakes whereas they were asleep and We turned them over on the right side and on the left side, while their dog stretched forth his two forelegs on the threshold. If thou hadst observed them, thou wouldst have surely turned away from them in fright, and wouldst have surely been filled with awe of them.

# 2159

And likewise we raised them up that they might question among themselves; there spake a speaker from amongst them: how long have ye tarried? They said we have tarried a day or part of a day. They said, your Lord knoweth best how long ye have tarried; now send one of you with this your money unto the city and let him see which food is purest there, and let him bring you a provision thereof, and let him be circumspect, and let him by no means discover you to anycne.

# 2160

Verily they, if they come to know of you, would stone you or make you revert to their faith, and lo! then ye will never fare well.

# 2161

And likewise We caused their affair to be lit upon that they might know that the promise of Allah is true, and that the Hour- there is no doubt thereof, Recall what time they were disputing among themselves regarding their affair, and then they said: build over them a building--their Lord is the Best Knower about them-then those who prevailed in their affair said: surely we will raise over them a place of worship.

# 2162

Anon they will say: they were three the fourth of them their dog. And they will say: they were five, the sixth of them their dog- -guessing at the unknown --and they willl say: they were seven, the eighth of them their dog. Say thou: my Lord is the Best Knower of their number; there knew them only a few; so debate thou not regarding them except an cut ward debating, and ask not regarding them anyone of them.

# 2163

And never say thou of a thing: verily I am going to do that on the morrow.

# 2164

Except with this reservation that Allah so will. And remember thy Lord when thou forgettest; and say thou belike my Lord will guide me to something nearer than this to right direction.

# 2165

And they tarried in their cave three hundred years and added nine.

# 2166

Say thou: Allah knoweth best how long they tarried; His alone is the hidden knowledge of the heavens and the earth. How well He seeth and heareth. They have no patron beside Him, nor in His rule He associateth anyone.

# 2167

And rehearse thou that which hath been revealed unto thee of the Book of thy Lord; and none may alter His Words, and never wilt thou find beside Him a covert.

# 2168

And endure thy self in the company of those who call upon their Lord in the morning and evening seeking His and let not thine eyes countenance rove from them seeking the adornment of the life of this world, and obey thou not him whose heart We have made to neglect Our remembrance, and who followeth his lust, and whose affair is exceeding the bound.

# 2169

And say thou: the truth is from your Lord; let him therefore who will, believe, and let him who will, disbelieve. Verily We have gotten ready for the wrong-doers a Fire the awnings whereof shall encompass them; and if they cry for relief they shall be relieved with water like the dregs of oil scalding their faces. 111 the drink, and vile the resting-place!

# 2170

Verily those who believe and work the righteous works-- verily We waste not the hire of one who doth well in regard to his work.

# 2171

These! for them are Gardens Everlasting whereunder rivers flow; bedecked they shall be therein with bracelets of gold, and wear they shall green robes of satin and brocade, reclining therein on the couches; excellent the reward, and goodly the resting-place!

# 2172

Propound thou unto them the similitude of two men. We appointed to one of them two gardens of vine and hedged both with date- palms, and We placed in-between the twain tillage.

# 2173

Each of the two gardens brought forth its produce and stinted not aught thereof; and We caused to gush forth in the midst of the twain a river.

# 2174

And he had property. Then he Said unto his fellow while he spake with him: I am more than thou in substance and am mightier in respect of retinue.

# 2175

And he entered his garden, while he was a wrong-doer in respect of his own soul; he said: I imagine not that this shall ever perish.

# 2176

Nor I imagine that the Hour is going to happen; and if am brought back to my Lord, surely I will find something better than this as a retreat.

# 2177

His fellow said unto him, while he spake with him: hast thou disbelieved in Him Who created thee of dust, then of a sperm, and formed thee a man?

# 2178

But he is Allah, my Lord; and with my Lord associate not anyone.

# 2179

Wherefore saidst thou not, when thou enteredest thy garden: whatsoever Allah may will! there is no power save in Allah! If thou beholdest I am inferior to thee in substance and offspring.

# 2180

Then belike my Lord will vouchsafe unto me something better than thy garden and send thereon a belt from the heaven that it become a plane slippery.

# 2181

Or the water thereof become deep sunken so that therefor thou canst not make a search.

# 2182

And his property was encompassed; and lo! he was wringing the palms of his hands over that which he had expended thereon, while itlay fallen down on its trellises, and saying: Oh, would that had not associated with my Lord anyone:

# 2183

And there could be no party suceouring him as against Allah, nor could he himself be an avenger.

# 2184

Herein is all protection from Allah the True: He is excellent in respect of reward and excellent in respect of the final end!

# 2185

And propound thou unto them the similitude of the life of the World. It is as water which We send down from the heaven, then there mingleth therewith the vegetation of the earth, and lo! it becometh dry stubble which the winds scatter and Allah is over everything potent.

# 2186

Substance and sons are the adornment of the life of the World, and the righteous works that last are excellent with thy Lord in respect of reward, and excellent in respect of hope.

# 2187

And beware a Day whereon we will make the mountains to pass, and thou wilt see the earth away plain, and We shall gather them, and We shall leave of them not one.

# 2188

And they shall be sent before thy lord in ranks! now are ye come to Us even as We had created you the first time; aye ye fancied that We had appointed for you no tryst.

# 2189

And the Book shall be placed, and thou wilt see the culprits alarmed at that which is therein, and they will say: Ah! woe unto us! what aileth this book that it leaveth not any sin small or great but it hath computed it! And they shall find all that they had wrought present; and thy Lord wrongeth not any one.

# 2190

And recall what time we said unto the angels: prostrate yourselves before Adam, and they prostrated themselves, but Iblis did not; he was of the genii; so he trespassed the commandment of his Lord. Would ye then take him and his progeny as patrons instead of Me, whereas they are unto you an enemy III is for the wrong-doers an exchange!

# 2191

I Made them not present at the creation of the heavens and the earth nor at the creation of themselves; nor was I one to take the seducers as supporters;

# 2192

And beware a Day whereon He will say: cry unto my associates say cry unto whom ye fancied. So they will call unto them, and they will answer them not, and We shall place between them a partition.

# 2193

And the culprits will behold the Fire and imagine that they are about to fall therein, and they shall not find therefrom a way of escape.

# 2194

And assuredly We have variously propounded in this Qur'an for mankind every kind of similitude; and man is of all things the most disputing.

# 2195

And naught preventeth mankind from believing when the guidance hath come unto them, and from asking foregiveness of their Lord, but that there may come unto them the dispensation of the ancients, or that the torment may come Unto them face to face.

# 2196

And We send not apostles save as bringers of glad tidings and warners; and those who disbelieve dispute with falsehood that they rebut thereby the truth; and they take My signs and that whereof they are warned as a mockery.

# 2197

And who doth greater wrong than he who is admonished with the signs of His Lord yet turneth away from them and forgetteth that which his hands have sent forth? Verily We have set up veils over lest they should understand it, and in their ears a heaviness; and if thou callest them to the guidance, lo! they will not let themselves be guided ever.

# 2198

And thy Lord is the Forgiver, Owner of mercy. Were He to call them to account for that which they have earned; He would have hastened for them torment; but for them is a tryst beside which they cannot find a place to betake themselves to.

# 2199

And these cities! We destroyed them when they did wrong, and We had appointed for their destruction a tryst.

# 2200

And recall what time Musa said unto his page: I shall not cease until I reach the confluence of the two seas, or I shall go on for ages.

# 2201

And when the twain reached the confluence of the two, they forgot their fish, and it took its way into the sea freely.

# 2202

And when the twain had passed by, he said unto his page: bring us our morning-meal, assuredly we have met from this journey of ours, toil

# 2203

He said: lookest thou! when we betook ourselves to the rock, then forgot the fish; and naught but the Satan made me forget to mention it, and it took its way into the sea--a marvel!

# 2204

Musa said: that is that which we have been seeking. So they turned back upon their footsteps, retracing.

# 2205

Then the twain found a bondman from Our bondmen, him We had vouchsafed a mercy from before Us, and him We had taught from Our presence a knowledge.

# 2206

Musa said unto him: shall I follow thee that thou mayest teach me of that which thou hast been taught a directive knowledge.

# 2207

He said: verily thou wilt not be able to have with me patience;

# 2208

And how canst thou have patience over that which thy knowledge encompasseth not

# 2209

Musa said: thou wilt find me, if Allah will, patient, and shall not disobey thee in any affair.

# 2210

He said: then if thou wilt follow me ask me not of anything until begin thereof some mention.

# 2211

Then the twain journeyed until when they embarked in a boat, he scuttled it. Musa said: hast thou scuttled it that thou mayest drown the people thereof? Assuredly thou hast committed a thing grievous.

# 2212

He said: said I not that thou wouldst not be able to have with me patience?

# 2213

Musa said: take me not to task for that forget, and impose not in my affair hardship.

# 2214

Then the twain journeyed until when they met a boy, and he killed him. Musa said: hast thou slain a person innocent not in return for a Person Assuredly thou hast committed a thing formidable.

# 2215

He said: said I not unto thee that thou wouldst by no means be able to have with me patience?

# 2216

Musa said: if I ask thee regarding aught after this, company not with me; surely there hath reached to thee from my side an excuse.

# 2217

Then the twain journeyed until when they came unto the people of a city, they begged food from the people thereof, but they refused to entertain the twain. Then they found therein a wall, about to fall down, and he set it upright. Musa said: hadst thou willed, thou mightest have taken therefor a hire.

# 2218

He said: this shall be the parting between me and thee; now I shall declare unto thee the interpretation of that wherewith thou wast not able to have patience.

# 2219

As for the boat, it belonged to poor men working in the sea, so I intended to damage it, for there was before them a prince taking every boat by force.

# 2220

And as for the boy, his parents were believers, and we apprehended that he might impose upon the twain exorbitance and infidelity.

# 2221

So we intended that their Lord should change for the twain one better than he in piety and closer in affection.

# 2222

And as for the wall, it belonged to two orphan boys in the town and underneath it was a treasure belonging to them and their father had been righteous. So thy Lord intended that the twain should attain their maturity and bring forth for themselves their treasure as a mercy from thy Lord. And I did it not of mine own command; that is the interpretation of that wherewith thou wast not able to have patience.

# 2223

And they ask thee of Zul Qarnain. Say thou: shall recite unto you of him some mention.

# 2224

Verily We! We established him in the earth, and vouchsafed unto him of everything a way.

# 2225

Then he followed a way.

# 2226

Until when he reached the setting-place of the sun, he perceived it setting in a miry spring, and he found beside it a nation. We said: Zul Qarnian! either chastise them or take in respect of them the way of kindness.

# 2227

He said: as for him who doeth wrong, presently we shall torment him, and thereafter he shall be brought back to his Lord, and He shall torment him with a torment formidable.

# 2228

And as for him who believeth and worketh righteously, unto him shall be a goodly hire, and anon we shall speak unto him of our affair something easy.

# 2229

Thereafter he followed a way.

# 2230

Until when he reached the rising place of the sun, he perceived it rising upon a nation for whom against it We had not set a veil.

# 2231

Thus it was. And surely We have encompassed all that was with him, in knowledge

# 2232

Thereafter he followed a way.

# 2233

Until when he arrived between the two mountains, he found beside them a people who well-nigh understood not a word.

# 2234

\`They said: O Zul-Qarnain verily Yajuj and Majuj are working corruption in the land; shall we then pay thee tribute on condition that thou place between us and them a barrier!

# 2235

He said: better is that where in my Lord hath established me; so help me with might, and I shall place between you and them a rampart.

# 2236

Bring me lumps of iron. Then when he had evened Up between the two mountain-sides, he said: blow! Then when he had made it fire, he said: bring me and I shall pour thereon molten cOpper.

# 2237

Thus they Were not able to mount it, nor Were they able to burrow through it.

# 2238

He said: this is a mercy from my Lord; then when the promise of my Lord cometh, He shall make it powder, and the promise of my Lord is ever true.

# 2239

And We shall leave them on that day surging one against anot her and the trumpet shall be blown, and then We shall assemble them together.

# 2240

And We shall set hell on that Day unto the infidels with a setting.

# 2241

Unto those whose eyes had been under a covering from My remembrance, nor had they been able to hear.

# 2242

Deem then those who disbelieve that they may take My bondmen, instead of Me, as patrons! Verily We have gotten ready the Hell for the infidels as an entertainment.

# 2243

Say thou: shall I declare unto you the greatest losers in respect of works?

# 2244

They are those whose effort is wasted in the life of the world, and they deem that they are doing well in performance.

# 2245

They are those who disbelieve in the signs of their Lord and in the meeting with Him; so of non-effect will be made their works, and We shall not allow them on the Day of Judgment any weight.

# 2246

That shall be their meed--Hell-for they disbelieved and held My revelations and My apostles in mockery.

# 2247

Verily those who believe and do righteous works, unto them shall be gardens of Paradise for an entertainment.

# 2248

As abiders therein, they shall not seek therefrom any change.

# 2249

Say thou: were the sea to become ink for the words of my Lord, the sea would surely exhaust ere the words of my Lord exhausted, even though We brought onot her like thereof for support.

# 2250

Say thou: I am but a human being like yourselves; revealed unto me is that your God is One God. Whosoever then hopeth for the meeting with his Lord, let him work righteous work, and let him not associate in the worship of his Lord anyone.

# 2251

Kaf- Ha-Ya-'Ain-Sad.

# 2252

Mention of the mercy of thy Lord to His bondman Zakariyya.

# 2253

Recall what time he cried unto his Lord with a cry secret.

# 2254

He said: O my Lord! verily the bones of me have waxen feeble, and the head is glistening with hoariness, and have not yet been in my prayer to thee, my Lord, unblest.

# 2255

And verily I fear my kindred after me, and my wife hath been barren; so bestow on me from before Thee an heir.

# 2256

Inheriting me and inheriting the Children of Ya'qub; and make him, my Lord, acceptable!

# 2257

O Zakariyya! verily We give thee the glad tidings of a boy: his name shall be Yahya; We have not afore-time made his namesake.

# 2258

He said: O my Lord! in what wise shall there be for me a boy, whereas my wife hath been barren, and surely have reached an age of extreme degree?

# 2259

Allah said: even so! Thy Lord saith: it is unto Me easy, whereas surely I created thee afore when thou wast not aught.

# 2260

He said: my Lord appoint for me a sign. Allah said: thy sign is that thou shalt not speak unto mankind for three nights, while sound.

# 2261

Then he came forth to his people from the sanctuary, and he beckoned unto them. hallow your Lord morning and evening.

# 2262

O Yahya! se hold fast the book. And We vouchsafed unto him wisdom, while yet a child.

# 2263

And tenderness from Our presence and purity, and he was God-fearing.

# 2264

And duteous unto his parents, and Was not high-handed rebel.

# 2265

And Peace be unto him the day he was born and the day he dieth and the day he will be raised up alive.

# 2266

And mention thou in the Book Maryam, what time the retired from her people to a place eastward.

# 2267

Then she took beside them a curtain; then We sent unto her Our Spirit, and he took unto her the form of a human being sound.

# 2268

She said: verily seek refuge with the Compassionate from thee if thou art God-fearing.

# 2269

He said: I am but a meenger from thy Lord that I may bestow on thee a boy pure.

# 2270

She said: in what wise shall there be a boy unto me, whereas not a human being hath touched me, nor have I been a harlot?

# 2271

He said: even so! Thy Lord saith: it is With Me easy, and it is in order that We may make him a sign unto mankind and a mercy from Us, and it is an affair decreed.

# 2272

hen she conceived him, and she retired with him to a place far-off.

# 2273

Then the birth-pangs drave her to the trunk of a palm- tree; she said: would that had died afore this and become forgotten, lost in oblivion!

# 2274

Then one cried unto her from underneath her, that grieve not, thy Lord hath placed underneath thou a rivulet.

# 2275

And shake toward thee the trunk of the palm-tree it shall drop on thee dates fresh and ripe.

# 2276

So eat and drink thou, and cool thine eyes; and if thou beholdest the human beings anyone, say: verily I have vowed to the Compassionate a fast, so I shall not speak today to any human being.

# 2277

Then she brought him to her nation carrying him. They said: Maryam! assuredly thou hast brought a thing unheard Of.

# 2278

O sister of Harun: thy father was not a man of evil, nor was thy mother a harlot.

# 2279

Then she Pointed to him. They said: how shall we speak to one who is in the cradle, a child?

# 2280

He Said: verily I am a bondman of Allah; He hath vouchsafed me the Book and made me a prophet.

# 2281

And He hath made me blest wheresoever I may be, and enjoined on me the prayer and the poor-rate as long as I am alive.

# 2282

And dutecus Unto my mother, and hath not made me high- handed, unblest.

# 2283

And peace be on me the day was born and the day die and the day I shall be raised up alive.

# 2284

Such is 'lsa, son of Maryam: this Is the word of truth wherein they are doubting.

# 2285

Allah is not one to take to Himself a son. Hallowed be He! whensoever He decreeth an affair he only Saith to it: be, and it becometh.

# 2286

And verily Allah is my Lord and your Lord; so worship Him; this is a way straight.

# 2287

Then the sects have differed among themselves; so woe to those who disbelieve in the witness of a Day Mighty!

# 2288

How wondrous in their hearing and their sight will they be the Day they come unto Us! But to-day the wrong doers are in error manifest.

# 2289

And warn thou them of thy Day of Sighing when the affair shall have been decreed while yet they are in negligence and are not believing.

# 2290

Verily We! We shall inherit the earth and whatsoever is thereon: and Unto Us they shall be returned.

# 2291

And mention thou in the Book Ibrahim; verily he was a man of truth, a prophet.

# 2292

Recall what time he said unto his father:, O my father! wherefore worshippest thou that which heareth not and seeth not, nor availeth thee at all?

# 2293

O My father! verily there hath come to me of the knowledge which hath not come unto thee; so follow me, and I shall guide thee to a path even.

# 2294

O My father! worship not the satan; hath been Unto the Compassionate a rebel.

# 2295

O My father! verily I fear that there may touch thee a torment from the Compassionate so that thou become to the Satan a companin.

# 2296

He said: art thou averse to my gods, O Ibrahim? If thou desistest not, surely I shall stone thee; and depart from me for ever so long.

# 2297

Ibrahim said: peace be on thee! anon shall ask forgiveness of my Lord for thee; verily He is unto me ever so soicitous.

# 2298

And I renounce you and that unto which ye call beside Allah; and I shall call unto my Lord; belike in calling unto my Lord I shall not be unblest.

# 2299

Then when he had renounced them and that which they worshipped beside Allah, We best owed on him Ishaq and Yaqub and each one We made a prophet!

# 2300

And We bestowed on them of Our mercy, and We made for them a renown lofty.

# 2301

And mention thou in the Book Musa: verily he was single- hearted, and was an apostle, prophet.

# 2302

And We cried unto him from the right side of the mount, and We drew him nigh for whispering.

# 2303

And We bestowed on him, out of Our mercy, his brother Harun, a prophet.

# 2304

And mention thou in the Book lsma'i; verily he was true in promise, and was apostle, prophet.

# 2305

And he was wont to command his household to the Prayer and the poor-rate, and he was with his Lord an approved one. \*Chapter: 19

# 2306

And mention thou in the book ldris, verily he was a man of truth, a prophet. \*Chapter: 19

# 2307

And We exalted him to a position lofty. \*Chapter: 19

# 2308

These are they whom Allah hath favoured, from among the prophets, of the progeny of Adam and of them whom We bare with Nuh, and of the progeny of Ibrahim and Isra'il, and of those whom We have guided and chosen; whenever the revelations of the Compassionate were rehearsed unto them, they fell down prostrating themselves and weeping. \*Chapter: 19

# 2309

Then there succeeded to them a posterity who neglected the prayers and followed lusts; so presently they shall meet with perdition. \*Chapter: 19

# 2310

Excepting those who may repent and believe and work righteously; these shall enter the Garden and shall not be wronged at all \*Chapter: 19

# 2311

Gardens Everlasting, which the Compassionate hath promised unto his bondmen, unseen; verily His premise is ever to be fulfilled. \*Chapter: 19

# 2312

They shall not hear therein any vain word, but they shall hear only peace; and therein they shall have their provision morning and evening. \*Chapter: 19

# 2313

Such is the Garden which We shall cause those of Our bondmen to inherit who have been God-fearing. \*Chapter: 19

# 2314

And we descend not except by the command of thy Lord: his is whatsoever is before us and whatsoever is behind us and whatsoever is in-between; and thy Lord is not a forgetter \*Chapter: 19

# 2315

Lord of the heavens and the earth and that which is betwixt the twain; so Him worship thou, and endure patiently in His worship; knowest thou any as his compeer? \*Chapter: 19

# 2316

And man saith: when I am daed, Shall I be presently brought forth alive. \*Chapter: 19

# 2317

Remembereth not man that We created him afore when he was not aught? \*Chapter: 19

# 2318

By thy Lord, then, We shall surely gather them and the satans; thereafter We shall surely bring them round Hell, kneeling. \*Chapter: 19

# 2319

Thereafter, We shall surely draw aside, from each sect, whichever of them against the Compassionate were most in excess. \*Chapter: 19

# 2320

Then surely it is We who are the Best Knower of these worthiest of being therein roasted. \*Chapter: 19

# 2321

And not one of you but shall pass over it: it is for thy Lord an ordinance decreed. \*Chapter: 19

# 2322

Then We shall deliver those who have feared, and shall have the wrong-doers therein kneeling. \*Chapter: 19

# 2323

And when Our manifest revelations are rehearsed unto them, those who disbelieve say unto those who believe: which of the two portions is better in station and goodlier in company? \*Chapter: 19

# 2324

And how many a generation have We destroyed before these, who were goodlier in goods and outward appearance? \*Chapter: 19

# 2325

Say thou: whosoever is in error--surely unto him the Compassionate lengtheneth a length, until When they behold that wherewith they were threatened, either the torment or the Hour, then they shall come to know whosoever is worse in position and weaker as an army. \*Chapter: 19

# 2326

And Allah increaseth in guidance those who let themselves be guided, and the righteous works that last are excellent with thy Lord in respect of reward and excellent in respect of return. \*Chapter: 19

# 2327

Hast thou observed him who disbelieveth in Our signs and saith: surely I shall be vouchsafed riches and children. \*Chapter: 19

# 2328

Hath he looked unto the Unseen, or hath he taken of the Compassionate a covenant? \*Chapter: 19

# 2329

By no means! We shall write down that which he saith; and We shall lengthen for him of the torment a length. \*Chapter: 19

# 2330

And We shall inherit from him that whereof he spake, and he shall come to us alone. \*Chapter: 19

# 2331

And they have taken gods beside Allah that they might be unto them a glory. \*Chapter: 19

# 2332

By no means! anon they shall deny their worship, and become unto them an adversary. \*Chapter: 19

# 2333

Beholdest thou not that We have sent the satans upon the infidels inciting them by an incitement? \*Chapter: 19

# 2334

So hasten thou not against them; We are only counting against them a counting. \*Chapter: 19

# 2335

On the Day whereon We shall gather the God-feaing unto the Com- passionate as an embassy. \*Chapter: 19

# 2336

And shall drive the culprits to Hell as a herd. \*Chapter: 19

# 2337

They shall not own intercession, excepting those who have taken of the Compassionate a covenant. \*Chapter: 19

# 2338

And they say: the Compassionate hath taken a son. \*Chapter: 19

# 2339

Assuredly ye have brought a thing monstrous. \*Chapter: 19

# 2340

Well-nigh the heavens are rent thereat and the earth cleft in sunder and the mountains fall down in pieces. \*Chapter: 19

# 2341

That they should ascribe unto the Compassionate a son. \*Chapter: 19

# 2342

And it behoveth not the Compassionate that he should take a son. \*Chapter: 19

# 2343

None there is in the heavens and the earth but must come unto the Compassionate as a bondman. \*Chapter: 19

# 2344

Assuredly He hath comprehanded them and counted them a full Counting. \*Chapter: 19

# 2345

And each of them is to come to Him on the Day of Judgment alone. \*Chapter: 19

# 2346

Verily those who believe and do righteOUs works--anon the Compassionate shall appoint for them affection. \*Chapter: 19

# 2347

So We have made it easy in thine tongue in order that thou mayest thereby give glad tidings unto the Godfearing and warn thereby a people contentious. \*Chapter: 19

# 2348

And how many a generation have We destroyed before them! Perceivest thou of them anyone or hear of them a whisper? \*Chapter: 20

# 2349

Ta. Ha. \*Chapter: 20

# 2350

We have not Sent down on thee the Qur'an that thou shouldst be distressed. \*Chapter: 20

# 2351

But only as an admonition unto him who feareth. \*Chapter: 20

# 2352

A down-sent from Him who Created the earth and the heavens high.

# 2353

The Compassionate on the Throne is established.

# 2354

His is whatsoever is in the heavens and whatsoever on the earth and - whatsoever is in-between. and whatsoever is underneath the earth.

# 2355

And if thou speakest the word aloud, then verily He knoweth the secret and the most hidden.

# 2356

Allah! no God there is but he! His are the names excellent.

# 2357

Hath there come unto thee the story of Musa?

# 2358

Recall what time he saw a fire and said to his household, bide ye! verily I have perceived a fire! haply I may bring you from it a brand or may find at the fire a guidance.

# 2359

Then when he was come thereto, he was cried unto. O Musa!

# 2360

Verily I! I am thy Lord: so take off thy shoes; verily thou art into the holy valley, Tuwa.

# 2361

And I! I have chosen thee hearken thou then to that which shall be revealed.

# 2362

Verily I! I am Allah! no God there is butI; so Worship Me, and establish prayer for My remembrance.

# 2363

Verily the Hour is coming--I wish to conceal it - in Order that every one may be requited according to that which he hath endeavoured.

# 2364

So let not him who believeth not therein and followeth his own desire keep thee away therefrom lest thou perish.

# 2365

And what is that in thy right hand, O Musa!

# 2366

He said: it is my staff; I lean there on; and therewith beat down fodder for my sheep; and for me therein are other purposes.

# 2367

Allah said: cast it down, O Musa!

# 2368

So he cast it down, and lo! it was a serpent running along.

# 2369

Allah said: take hold of it, and fear not; We shall restore it to its former state.

# 2370

And press thy hand to thy side, it will come forth white, without hurt, as anot her sign.

# 2371

That We may shew thee of Our Signs the greatest.

# 2372

Go thou unto Fir'awn; verily he hath waxen exorbitant.

# 2373

He said: my Lord! expand for me my breast.

# 2374

And ease for me by affair.

# 2375

And loose a knot from my tongue.

# 2376

That they may understand my Speech.

# 2377

And appoint for me a minister from my household.

# 2378

Harun, my brother.

# 2379

Strengthen by him my back.

# 2380

And associate him in my affair.

# 2381

That We may hallow Thee oft.

# 2382

And may make mention of Thee oft.

# 2383

Verily Thou! Thou art of us ever a Beholder.

# 2384

He said: surely thou art granted thy petition, O Musa!

# 2385

And assuredly We conferred a benefit on thee anot her time.

# 2386

When We inspired unto thy mother that which We inspired,

# 2387

Saying! cast him in the ark, and cast him into the river, and the river will throw him on the bank, and then an enemy of Mine and an enemy of his will take him up. And I cast on thee love from Me in order that thou mayest be formed under Mine eye.

# 2388

What time thy sister was walking along and saying: shall I direct you unto one who will take care of him! Thus We returned thee to thy mother that she might cool her eyes and she might not grieve. And thou slewest a person, but We delivered thee from sorrow, and We tried thee with several trials. Then thou tarriedst for years among the people of Madyan then thou camest according to fate, O Musa!

# 2389

And formed thee for Myself.

# 2390

Go thou and thy brother with My signs, and slacken not in remembrance of Mine.

# 2391

Go ye twain unto Fir'awn, verily he hath waxen exorbitant,

# 2392

Then say to him a gentle saying; haply he may be admonished or he may fear.

# 2393

The twain said: O our Lord! verily we fear that he may hasten against us or wax exorbitant.

# 2394

He said; fear not; verily I shall be With you twain: I shall hear and see.

# 2395

So go to him, and say: verily we are two apostles of thy Lord, so let go with us the Children of Isra'il, and torment them not; surely we have come unto thee with a sign from thy Lord: and peace be upon him who followeth the guidance.

# 2396

Verily We! it hath been revealed unto us that the torment will be for him who belieth and turneth away.

# 2397

He said: who is the Lord of you twain, O Musa!

# 2398

Musa said: our Lord is He who vouchsafed unto everything its creation, then guided it.

# 2399

He said: then what happened to the former generations?

# 2400

Musa said: the knowledge there of is with my Lord in the Book; my Lord erreth not, nor He forgetteth.

# 2401

Who hath appointed for you the earth as a bed, and hath opened for you therein pathways, and hath sent down from the heaven water, and thereby We have brought forth kinds of plants, various.

# 2402

Eat and pasture your cattle: verily therein are signs for men of sagacity.

# 2403

Thereof We created you, and thereunto We return you, and therefrom We shall bring You forth once again.

# 2404

And assuredly We shewed him Our signs, all of them, but he belied and refused.

# 2405

He said: art thou come unto us that thou mayest drive us out of our land by thy magic, O Musa!

# 2406

So We shall surely bring unto thee a magic the like thereof; so Make between us and thee an appointment which neither we nor thou shall fail in some open space.

# 2407

Musa said: your appointment is the gala day, and that the people be gathered in the forenoon.

# 2408

Then Firawn turned away, devised his stratagem; thereafter he came.

# 2409

Musa said unto them: woe unto you! fabricate not against Allah a lie, lest he extirpate you with a torment, and surely He who fabricateth, loseth.

# 2410

Then they wrangled about their affair among themselves, and kept secret their private counsel.

# 2411

They said: verily these two are magicians, intending to drive you forth from your land by their magic and to do away with your superior way.

# 2412

Wherefore devise your stratagem, and then come in a row; and prospered to-day is he who overcometh.

# 2413

They said: either thou cast down, or we shall be the first to cast down.

# 2414

He said: nay, cast ye down. And lo! their cords and their staves were made to appear to him by their magic as though they were running.

# 2415

Then a kind of fear in his soul Musa felt.

# 2416

We said: fear not! verily thou! thou shalt be the superior.

# 2417

And cast thou down that which is in thy right hand: it shall swallow up that which they have wrought; They have wrought only a magician's stratagem; and the magician prospereth not wheresoever he cometh.

# 2418

Then the magicians were cast down prostrate; they said: we believe in the Lord of Musa and Harun.

# 2419

Fir'awn said; believed ye in him ere I gave you leave! verily he is your chief who hath taught you magic. So I will surely cut off your hands and feet on the opposite sides, and will surely crucify you on the trunks of palm-trees, and ye shall surely know whichever of us is severer in torment and more lasting.

# 2420

They said: we shall by no means prefer thee to that which hath come to us of the evidences, and to Him Who hath created us; so decree thou whatsoever thou shalt decree; thou canst only decree in respect of the life of this world.

# 2421

Verily we! we have believed in our Lord, that he may forgive us our faults, and that to which thou hast constrained us in the way of magic; and Allah is Best and Most Lasting.

# 2422

Verily whosoever cometh unto his lord as a Culprit, for him is Hell wherein he will neither die nor live.

# 2423

And whosoever cometh unto Him as a believer, and he hath done righteous works---then these! for them are ranks high.

# 2424

Gardens Everlasting whereunder rivers flow: abiders therein; that is the meed of him who hath purified himself.

# 2425

And assuredly We revealed unto Musa, saying: depart in night with my bondmen, and make for them in the sea a parth dry: thou Shalt fear neither overtaking, nor shalt thou be afraid.

# 2426

Then Fir'awn followed them with his hosts; and there came upon them of the sea that which came upon them.

# 2427

And Fir'awn led his nation astray, and guided them not.

# 2428

O Children of Israel; We delivered you from your enemy, and treated with you on the right side of the mount and sent down upon you the manna and the quails.

# 2429

Saying: eat of the clean things wherewith We have provided you, and wax not exorbitant in respect thereof, lest My wrath alight on you; and upon whomsoever My wrath alighteth, he surely perisheth.

# 2430

And verily I am the Most Forgiving unto whomsoever repenteth and believeth and worketh righteously, and thereafter letteth himself remain guided.

# 2431

And what hath made thee hasten from thy people, O Musa?

# 2432

He said: those! they are close on my footstep, and hastened to Thee, O my Lord; that Thou mightest be wellpleased.

# 2433

He said: verily We have tempted thy people after thee, and the Samiri hath led them astray.

# 2434

So Musa returned unto his people, indignant and sorrowful. He said: O my people! promised there not your Lord unto you an excellent promise! Lasted then the covenant too long for you, or desired ye that the wrath from your Lord should alight on you, so that ye failed to keep my appointment?

# 2435

They said: we failed not to keep thy appointment of our own authority, but we were laden with burthens of the people's ornaments; then we threw them, and Thus Samiri cast down.

# 2436

And he produced for them a calf: a body with a low. Then they Said: this is your god and the god of Musa, and that he forgat.

# 2437

Observed they not that it returned not unto them a word, and owned not for them hurt or profit?

# 2438

And assuredly Harun had said unto them afore: O my people! ye are only being tempted thereby; and verily your Lord is the Compassionate; so follow me and obey my command.

# 2439

They said: we shall by no means cease to be assiduous to it until there returneth to us Musa.

# 2440

Musa said: O Harun! what prevented thee, when thou sawest them going astray.

# 2441

That thou followedst me not! Hast thou disobeyed my command?

# 2442

Harun said: O my mother's son! hold me not by my beard nor by my head verily feared that thou wouldst say, thou hast caused a division among the Children of Israel and hast not guarded my Word.

# 2443

Musa said: what was thy object, O Samiri?

# 2444

He said: l saw that which they saw not; so I seized a handful from the footstep of the messenger, and then cast it; Thus my soul embellished the affair to me.

# 2445

Musa said: begone thou! verily it shall be thine in life to say no contact; and verily thine is an appointment which thou shalt by no means fail. And look at thy god to which thou hast been assidauous; we shall surely burn it, and we shall scatter it into the sea a wide scattering.

# 2446

Your God is only Allah, the One other than whom there is no god. He comprehendeth everything in knowledge.

# 2447

Thus We recount unto thee some tidings of that which hath preceded; and surely We have vouchsafed unto thee from before Us an admonition.

# 2448

Whosoever turnoth away therefrom--verily they shall bear on the Day of Judgment a burthen,

# 2449

As abiders therein. And vile will load! them on the Day of Judgment as a load!

# 2450

The Day whereon the trumpet will be blown into, and We shall gather the culprits on that Day blear-eyed,

# 2451

Mutterin among themselves: ye tarried not save ten days.

# 2452

We are the Best Knower of that which they will say, when the best of them in judgment Will say: ye tarried not save for a day.

# 2453

And they ask thee regarding the mountains; so say thou: my Lord will scatter them with a total scattering.

# 2454

Then He shall leave it a plain, level.

# 2455

Wherein thou shalt not see any crookedness or ruggedness.

# 2456

That Day they shall follow the caller for Whom there shall be no crookedness; and voices Shall be humbled for the Compassionate; so that thou shalt not hear ought except pattering

# 2457

That Day intercession will Profit not except him for whom the Compassionate giveth leave, and of whom He approveth the Word.

# 2458

He knoweth that which is before them and that which is behind them, and they, encompass it not with their knowledge.

# 2459

And downcast will be faces before the Living, the Self- subsisting, and disappointed will be he who beareth a wrong.

# 2460

And whosoever worketh of the righteous works, and is a believer, he will not fear Wrong or begrudging

# 2461

And Thus We have sent it down, an Arabic Recitation, and have propounded variously therein of the threats, that haply they may fear, or that it may generate in them some admonition.

# 2462

Exalted is Allah, the True King! And hasten thee not with the Qur'an before there is finished to thee the revelation thereof, and say thou: O my Lord! increase me in knowledge!

# 2463

And assuredly We covenanted with Adam aforetime, then he forgat, and We found not in him steadiness.

# 2464

And recall what time We said to the angels: prostrate yourselves before Adam. They fell prostrate, but Iblis did not; he refused.

# 2465

Then We said: Adam! verily this is an enemy unto thee and thine spouse; so let him not drive forth you twain from the Garden, lest thou be destressed.

# 2466

Verily it is thine that thou shalt not hunger therein nor go naked.

# 2467

Nor that thou shalt thirst therein nor shall suffer from the sun.

# 2468

Then the Satan whispered unto him; he said: Adam! shall direct thee to the tree of eternity and a dominion that ageth not!

# 2469

Then the twain ate thereof; so there became disclosed to them their shame, and they began sewing upon them selves some of the leaves of the Garden, so Adam disobeyed his Lord, and erred,

# 2470

Thereafter his Lord accepted him, and relented toward him, and guided him.

# 2471

He said: get ye twain down therefrom together: some of you an enemy unto some others; then if there cometh unto you from Me guidance, whosoever followeth My guidance shall neither go astray nor be distressed.

# 2472

And whosoever turneth away from My admonition, for him verily will be a livelihood shrunken, and We shall raise him up on the Day of Judgment sightless.

# 2473

He will say: O my Lord! why hast Thou gathered me sightless whereas surely I have been a seer.

# 2474

Allah will say: Thus came Our signs Unto thee and thou ignoredst them; so that wise today thou shalt be ignored.

# 2475

Thus We requite him who trespasseth and believeth not in the signs of his Lord, and surely the torment of the Hereafter is most severe and most lasting.

# 2476

Hath it not served as guidance to them how many a generation We have destroyed before them, amidst whose dwellings they Walk! Verily therein are signs for men of sagacity.

# 2477

And had not a word from thy Lord gone forth, and a term determined, it must necessarily have come.

# 2478

So bear thou patiently that which they say, and hallow the praise of thy Lord before the rising of the sun and before the setting thereof. And hallow Him in part of the night and the ends of the day, haply thou wilt be pleased.

# 2479

And strain not thine eyes after that which We have given classes of them to enjoy: the splendour of the life of the World, that We might try them therein; and the provision of thy Lord is the best and most lasting.

# 2480

And command thy household for prayer, and persevere thou therein; We ask not of thee any provision; we Who provide thee; and the happy end is for piety.

# 2481

And they Say: wherefore bringeth he not unto us a sign from his Lord? Hath not there came unto them the evidence of that which is in the former Scriptures?

# 2482

And had We destroyed them With a torment before it, surely they would have said: O our Lord why sent not Thou Unto us an apostle that we might have followed Thy signs before we were disgraced and humiliated.

# 2483

Say thou: everyone Is on the watch; so watch, and anon ye shall know who are the fellows of thee even path and who hath let himself be guided.

# 2484

There hath approached unto mankind their reckoning, while they in neglect are turning away.

# 2485

There cometh not unto them a fresh admonition from their Lord but they listen to it while they are playing.

# 2486

In sport being their hearts. And those who do wrong keep secret their private discourse this is but a human being like unto yourselves; will ye then betake yourselves to magic while ye know?

# 2487

The Prophet said: my Lord knoweth the word in the heavens and the earth, and He is the Hearer, the Knower.

# 2488

Aye! they say: a medley of dreams; aye! he hath fabricated it; aye! he is a poet; so let him bring us a sign even as the ancients were sent with.

# 2489

Not a city before them which We destroyed believed; will they then believe?

# 2490

And We sent not before thee but men unto whom We revealed; so ask the people of the Admonition if ye know not.

# 2491

And We made them not bodies not eating food; nor were they to be abiders.

# 2492

Then We made good unto them the premise; so We delivered them and those whom We willed, and We destroyed the extravagant.

# 2493

And assuredly We have sent down unto you a Book wherein is admonition for you; will ye not then reflect?

# 2494

And how many a city have We overthrown which were doing wrong, and We caused to grow up thereafter anot her nation!

# 2495

Then when they perceived Our violence, lo! they were from it fleeing.

# 2496

Flee not, and return unto that wherein ye luxuriated and your habitations, haply ye will be questioned.

# 2497

They said: woe unto us! verily we have been wrong-doers.

# 2498

And this ceased not to be their cry until We made them a harvestreaped, extinguished.

# 2499

And We created not the heaven and the earth and that which is in between in play.

# 2500

Had We intended that We should choose a sport, surely We would choose it from before Us--if We were ever going to do that.

# 2501

Aye! We hurl truth against false hood, so that it braineth it, and lo! it vanisheth; and to you be the woe for that which ye utter!

# 2502

And His is whosoever is in the heavens and the earth; and those nigh unto Him are not too stiff-necked for His worship nor are they weary.

# 2503

And they hallow Him night and day, and they flag not.

# 2504

Have they taken gods from the earth who raise the deed?

# 2505

Had there been in between the twain gods except Allah surely the twain would have gone to ruin. Hallowed be Allah, the Lord of the Throne, from that which they utter!

# 2506

He shall be questioned not as to that which He doth, while they shall be questioned.

# 2507

Have they taken gods beside Him? Say thou: forth with your proof This is an admonition unto those with me and an admonition unto those before me. But most of them knew not the truth, and so they are averters.

# 2508

And We sent not before thee an apostle but We revealed unto him that there is no god but I, so worship Me.

# 2509

And they say; the Compaionate hath taken a son. Hallowed be He! aye! they are bondmen honoured.

# 2510

They precede Him not in words, and by His command they work.

# 2511

He knoweth whatsoever is before them and whatsoever is behind them; and they intercede not except for him whom He approveth, and in awe of Him they are fearful.

# 2512

And whosoever of them should say: verily I am a god beside Him, such a one We shall requite with Hell; Thus We requite the wrong- doers.

# 2513

Have not these who disbelieve considered that the heavens and the earth were closed up, then We rent them? And We have made of water everything living; will they not then believe?

# 2514

And We have placed in the earth firm mountains lest it should move away with them, and We placed therein Passages for paths, that haply they may be guided.

# 2515

And We have made the heaven a roof, safe, and from the signs there of they are averters.

# 2516

And He it is Who hath created the night and the day, and the sun and the moon, each in an orb floating.

# 2517

And We appointed not for any human being before thee immortality; if thou then diest, are they to be immortals?

# 2518

Every soul is going to taste of death, and We shall prove you with evil and good as a temptation; and unto Us ye shall be returned.

# 2519

And when those who disbelieve behold thee they only take thee up for mockery: is this he who mentioneth your gods? while in the mention of the compassionate they are themselves blasphemers.

# 2520

Man was created of hast, surely I shall show you MY signs, so ask Me not to hasten.

# 2521

And they say: when cometh this torment if ye are truth- tellers!

# 2522

If only those who disbelieve have known of the time when they shall not be able to ward off from their faces the Fire nor from their backs, nor shall they be succoured!

# 2523

Aye! it would come upon them on a sudden and shall dumbfound them; they shall not be able to avert it, nor shall they be respited.

# 2524

And assuredly mocked were the apostles before thee, then there surrounded those of them Who scoffed that whereat they had been mocking!

# 2525

Say thou: who guardeth you by night and by day from the Compassionate! O Yet from the remembrance of their Lord they avert themselves!

# 2526

Have they gods who defend them beside Us? They are not able to succour themselves, and against Us they cannot be kept company with.

# 2527

Aye! We let these people and their fathers enjoy until there grew long upon them the life. Behold they not that We come unto the land diminishing it by the borders thereof? Shall they then be the victors?

# 2528

Say thou: I only warn you by the revelation; and the deaf hearken not unto the call when they are warned.

# 2529

And if a breath of the torment of thy Lord were to touch them, they will say: woe unto us! we have been wrong-doers.

# 2530

And We shall set balances of justice for the Day of Judgment; then no soul shall be wronged at all; and if it be but the weight of a grain of mustard-seed We shall bring it; and We suffice as Reckoners.

# 2531

And assuredly We vcuchsafed unto Musa and Harun the distinction and illumination and an admonition for the God-fearing.

# 2532

These who fear their Lord unseen, and who are of the Hour fearful.

# 2533

And this is an admonition blest, which We have sent down! will ye then be the rejectors thereof?

# 2534

And assuredly We vouchsafed un to lbrahim his rectitude aforetime, and him We had ever known.

# 2535

Recall what time he said unto his father and his people what are these images to which ye are cleaving?

# 2536

They said: we found our fathers the worshippers thereof.

# 2537

He said: assuredlY ye, ye and your fathers, have been in error manifest.

# 2538

They said: hast thou come unto us with the truth, or art thou of those who sport?

# 2539

He said: Aye! your Lord is the Lord of the heavens and the earth Who created them, and as to that I am of the witnesses.

# 2540

And by Allah I shall surely devise a plot against your idols after ye turned away backward.

# 2541

Then he made them fragments, all except the big one of them, that haply unto it they may return.

# 2542

They said: who hath wrought this to our gods? verily he is of the wrong-doers.

# 2543

They said: We heard a youth speak of them, who is called Ibrahim.

# 2544

They said: bring him then before the eyes of the people, haply they may bear witness.

# 2545

They said: art thou the one who hath wrought this unto our gods, O Ibrahim?

# 2546

He said: rather he hath wrought it: this big one of them: so question them, if they ever speak.

# 2547

They then turned to themselves, and said: verily ye it is who are the wrong-doers.

# 2548

Thereafter they were made to turn over upon their heads, saying, assuredly thou knowest that they speak not.

# 2549

He said: worship ye, then, beside Allah, that which profiteth you not at all, nor it hurteth you

# 2550

Fie upon you and upon that which ye worship beside Allah! Will ye not then reflect?

# 2551

They said: burn him, and succour your gods, if ye will be doing.

# 2552

We said: O fire! be thou cool and peace unto Ibrahim

# 2553

And they intended to do him an evil, but We made them the worst losers.

# 2554

And We delivered him and Lut to the land wherein We had placed Our blessings for the worlds.

# 2555

And We bestowed upon him ls-haq and Ya qub as a grandson; and each one We made righteous.

# 2556

And We made them leaders, guiding by Our command; and We revealed unto them the doing of good deeds and the establishment of prayer, and the giving of poor-rate; and of Us they were the worshippers.

# 2557

And Lut! We vouchsafed unto him judgment and knowledge, and We delivered him out of the city which had been working foul deeds; verily they were a people evil, wicked.

# 2558

And We caused him to enter into Our mercy; verily he was of the righteous.

# 2559

And Nuh! recall what time he cried aforetime; so we answered him and delivered him and his house hold from a calamity mighty.

# 2560

And We succoured him against the people who belied Our signs; verily they were a people evil, so we drowned them all.

# 2561

And Daud and Sulaiman! recall what time they gave judgment regarding the tillage when certain people's sheep had pastured therein at night; and of the judgment concerning them We were the Witnesses.

# 2562

So We gave the understanding thereof unto Sulaiman; and unto each We vouchsafed judgment and knowledge. And We so subjected the mountains that they shall hallow us along with Daud, and also the birds; and We were the doers.

# 2563

And We taught him the art of making the coats of mail for you that it may protect you from your violence; are ye then thankful?

# 2564

And unto Sulaiman We subjected the wind, strongly raging, running at his command toward the land wherein We had placed Our blessing; and of evrything We are the knowers.

# 2565

And of the satans were some who dove for him, and worked a work beside that; and of them We were the Watchers.

# 2566

And Ayyub! recall what time he cried unto his Lord: verily hurt hath touched me, and Thou art the Most Merciful of the mercifuls.

# 2567

So We answered him and We removed that which was with him of the hurt, and We vouchsafed unto him his household and the like thereof along with them, as a mercy from us and a remembrance unto the worshippers.

# 2568

And Isma'il and ldris and Zul-Kifl! each were of the patient.

# 2569

And We caused them to enter into our mercy, verily they are of the righteous.

# 2570

And Zun-nun! recall what time he departed in anger and imagined that We could not straiten him, then he cried in the darknesses, that: there is no god but Thou! hallowed be Thou! verily I have been of the wrong-doers.

# 2571

So We answered him, and We delivered him from the distress, and Thus do We deliver the believers.

# 2572

And Zakariyya! recall what time he cried unto his Lord: my Lord! leave me not solitary, though Thou art the best of heirs.

# 2573

So We answered him, and We bestowed on him Yahya and We made sound for him his spouse. Verily they Were wont to vie with one anot her in good deeds and to call upon us with longing and dread, and they were ever before us meek.

# 2574

And she who guarded her chastity! Then We breathed into her of Our spirit, and made her and her son a sign unto the worlds.

# 2575

Verily this community of yours is a single community, and I am your Lord; so worship Me.

# 2576

And they cut up their affair among them:, all are unto Us returners.

# 2577

Whosoever worketh righteous works, and he is a believer, there shall be no denial of his endeavour; and We are for him the Writers.

# 2578

And a ban is laid on every town which We have destroyed, that they Shall not return.

# 2579

Until when Ya'juj and Ma'juj are let out, and from every mound they are trickling down.

# 2580

And there shall approach the true promise; and lo! the eyes of those who disbelieved shall be staring: woe unto us! surely we have been in neglect thereof; aye! we have been the wrong-doers.

# 2581

Verily ye and whatsoever ye worship beside Allah shall be firewood for Hell: thereunto ye shall go down.

# 2582

Had these been gods, they would not have gone down thereunto; and all of them therein shall be abiders.

# 2583

Theirs therein shall be roaring, and therein they shall hear not.

# 2584

Verily those for whom the good reward hath preceded from Us, they therefrom shall be kept far away.

# 2585

They shall not hear the least sound thereof, and in that felicity which their souls desire they shall be abiders.

# 2586

The Great Terror shall grieve them not, and the angels will meet them: this is Your Day which ye were ever promised-

# 2587

The Day whereon We shall roll up the heaven like as the rolling up of a scroll for books. Even as We began the first creation, We shall restore it: a promise binding upon Us; verily We have been the Doers.

# 2588

And assuredly We have prescribed in the Scripture after the admonition, that: the land! there shall inherit it My bondmen righteous.

# 2589

Verily in this in a preaching for a people who are worshippers.

# 2590

And We have not sent thee except as a mercy unto the Worlds.

# 2591

Say thou: this only hath been revealed unto me, that your god is only One God. submit ye then?!

# 2592

Then if they turn away, say thou: I have proclaimed unto you all alike, and I know not whether nigh or far is that which ye are promised,

# 2593

Verily He knoweth that which is public in speech, and He knoweth that which ye hide.

# 2594

And know not; haply it may be a trial for you, and an enjoyment for a season.

# 2595

He saith: my Lord! judge Thou with truth. And our Lord is the Compassionate Whose help is to be sought against that which ye utter.

# 2596

Mankind! fear your Lord; verily the quake of the Hour shall be a thing mighty.

# 2597

The Day whereon ye behold it, every suckling woman shall forget that which she suckleth, and every burthened woman shall lay down her burthen; and thou shalt behold mankind as drunken, whereas drunken they will be not, but the torment of Allah shall be severe.

# 2598

And of mankind is he who disputeth respecting Allah without knowledge, and followeth any Satan froward.

# 2599

Against whom it is prescribed, that: whosoever befriendeth him, him he shall lead astray and shall guide him on to the torment of the Flame.

# 2600

O Mankind! if ye be in doubt respecting the Resurrection, then We have created you of the dust, then of a drop, then of clot, then of a piece of flesh, formed and unformed, that We might manifest unto you Our power. And We settle in the wombs that which We will until a term determined. Then We bring you forth as babes, then We let you reach your maturity. And of you is he who dieth, and of you is he who is brought back to the most abject age, so that after knowing he knoweth not aught. Andthou beholdest the earth withered up, and when We send down thereon water, it stirreth and swelleth, and it groweth every luxuriant kind of growth.

# 2601

That, because Allah! He is The Truth, and He quickeneth the dead, and verily He is over everything Potent.

# 2602

And because the Hour is coming- there is no doubt thereof-- and because Allah will raise up those who are in the graves.

# 2603

And of mankind is he who disputeth respecting Allah without knowledge or guidance or a Book luminous.

# 2604

Bending his neck, that he may lead astray from the way of Allah; his shall be humiliation in the world, and We shall make him taste on the Day of Judgment the torment of Burning.

# 2605

That is because of that which thy hands have sent forth, and verily Allah is not a wronger of His bondmen.

# 2606

And of mankind is he who worshippeth Allah as on edge; if there befalleth him good, he in contented therewith, and if there befalleth him a trial, he turneth round on his face; he loseth the world and the Hereafter: that indeed is a loss manifest!

# 2607

He calleth upon that, beside Allah, which can neither hurt him nor profit him! that! it is a straying far-off.

# 2608

He calleth upon him whose hurt is nearer than his profit: surely ill the patron! ill the comrade!

# 2609

Verily Allah shall cause those who believe and work righteous works to enter Gardens whereunder rivers flow; verily Allah doth whatsoever He intendeth.

# 2610

Whosoever hath been imagining that Allah shall not make him victorious in the world and the Hereafter, let him stretch a cord up to the heaven and let him cut it, and let him look if his stratagem can do away that whereat he enrageth.

# 2611

And Thus We have sent it down as evidences, and verily Allah guideth whomsoever He intendeth.

# 2612

Verily those who believe and those who are Judaised and the Sabians and the Nazarenes and the Magians and those who associate - verily Allah will decide between them on the Day of Judgment; verily Allah is over everything a Witness.

# 2613

Beholdest thou not that Allah unto Him adore whosoever is in the heavens and on the earth, and the sun, and the moon, and the mountains, and the trees and the beasts, and many of mankind! And many are there on whom due is the torment. And whomsoever Allah despiseth, none can honour; verily Allah doth whatsoever He willeth.

# 2614

These twain are opponents who contended respecting their Lord; then as for those who disbelieved, cut out for them shall be raiments of frre: poured out over their head shall be hot water.

# 2615

Molten thereby shall be that which is in their bellies and also their skins.

# 2616

And for them shall be maces of iron.

# 2617

So oft as they would seek to go forth therefrom, because of anguish, they shall be sent back therein, and taste the torment of Burning.

# 2618

Verily Allah will cause those who believe and work righteous works to enter Gardens whereunder the rivers flow, wherein they will be bedecked with brace lets of gold and with pearls, and their garment therein shall be of silk.

# 2619

And they have been guided unto goodly speech, and they have been guided to the path of the Praiseworthy.

# 2620

Verily those who disbelieve and hinder others from the path of Allah and from the Sacred Mosque which We have appointed for mankind, equal in respect thereunto are the dweller therein and the stranger. And whosoever will seek profanity therein wrongfully, We shall make him taste of a torment afflictive.

# 2621

And recall what time We settled Ibrahim in the place of the House, Saying: associate not thou with Me aught, and purify My House for these who circumambulate and those who stand up and those who bow and make prostration.

# 2622

And proclaim thou among mankind the pilgrimage; they shall come unto thee on foot and on any lean mount, coming from every deep defile.

# 2623

That they may witness the benefits to them and may mention the name of Allah on the days known over the beast cattle wherewith He hath provided them. So eat thereof, and feed the hungry poor.

# 2624

Thereafter let them end their unkemptnesss and fulfil their vows and circumambulate the ancient House.

# 2625

Thus it is. And whosoever suspecteth the sacred ordinances of Allah, it shall be better for him with his Lord. And allowed unto you are the cattle, save that which hath been rehearsed unto you; so avoid the pollution of the idols, and avoid the word of falsehood.

# 2626

Reclining unto Allah, not associating aught with Him. And whosoever associateth aught with Allah, it is as though he had fallen from the heaven and the birds had snatched him, or the wind had blown him to a place remote.

# 2627

Thus it is. And whosoever respecteth the rites of Allah, then verily it is from piety of the hearts.

# 2628

For you in them are benefits for a term appointed, and thereafter the destination is toward the ancient House.

# 2629

And unto every community We appointed a ritual, that they mention the name of Allah over the beast cattle wherewith He hath provided them: and your God is One God, so unto Him submit. And bear thou glad tidings unto the humble-

# 2630

Those---whose hearts, when Allah is mentioned, are filled with awe and who patiently endure that which befalleth them, and these who establish the prayer and of that wherewith We have provided them expend.

# 2631

And the camels! We have appointed them for you among the landmarks of Allah; for you is good therein; so mention the name of Allah over them, standing in rows. Then when they fall down on their sides, eat thereof and feed the contented and suppliant. Thus We have subjected them to you, that haply ye may return thanks.

# 2632

Their flesh reacheth not Allah nor their blood: but it is Piety from you that reacheth Him. Thus He hath subjected them to you, that ye may magnify Allah for He hath guided you; and bear thou glad tidings unto the welldoers.

# 2633

Verily Allah will repel from those who believe: verily Allah loveth not any treacherous, ingrate.

# 2634

Permitted are those who are fought against, because they have been oppressed, and verily to succour them Allah is potent

# 2635

Those who have been driven forth from their abodes without justice, except because they say: our Lord is Allah. And were it not for Allah's repelling of someby means of others, cloisters and churches, synogogues and mosques wherein the name of Allah is mentioned much, would have been pulled down. Surely Allah shall succour whosoever succoureth Him; verily Allah is strong, Mighty

# 2636

Those who if We establish them in the earth, shall establish the prayer and give the poor-rate and command that which is reputable and restrain that which is disreputable and unto Allah is the end of all affairs.

# 2637

And if they belie thee, then surely there have belied before them the people of Nuh and the 'Aad and the Thamud.

# 2638

And the people of Ibrahim and the people of Lut.

# 2639

And the denizens of Madyan. And belied was Musa. I gave rein to the infidels; then took hold of them; so how hath been My wrath!

# 2640

How many a city have We destroyed, while it was a wrong- doer--and it lieth overturned on its roofs, -and how many a well abandoned and how many a castle fortifred!

# 2641

Have they not marched forth in the land, so that there might become unto them hearts to understand with or ears re hear with? Verily it is not the sights that are blinded but blinded are the hearts that are in the breasts.

# 2642

And they ask thee to hasten on the torment, whereas Allah shall not fail His promise. And verily a day with thy Lord is as a thousand years of that which ye compute.

# 2643

And how many a city did give reins to, While it wronged itself, then took hold of it! and unto Me is the return.

# 2644

Say thou: mankind! I am unto you only a warner manifest.

# 2645

Then those who believe and work righteous works--for them is forgiveness and a provision honourable.

# 2646

And those who endeavour in respect of Our signs to frustrate them- those shall be the fellows of Flaming Fire.

# 2647

And We have sent before thee no apostle or prophet but when he read the Satan cast forth suggestions in respect of his reading; then Allah abolisheth that which the Satan casteth forth; then Allah confirmeth His revelations; and Allah is Knowing. Wise;

# 2648

That he may make that which the Satan casteth forth a temptation for those in whose heart is a disease and whose hearts are hardened--and the wrong-doers are in divergence far-off -

# 2649

And that those who have been vouchsafed knowledge may know that it is the truth from thy Lord and may believe therein, and so their hearts may submit thereto. And verily Allah is the Guide of those who believe unto a path straight.

# 2650

And those who disbelieve will not cease to be in doubt thereof until the Hour cometh upon them on a sudden, or there cometh upon them the torment of a Barren Day.

# 2651

The dominion on that Day will be Allah's; He shall judge between them; then those who believed and worked righteous works shall be in the Gardens of Delight.

# 2652

And those who disbelieved and belied Our signs--then these! for them will be a torment ignominous.

# 2653

And those who emigrated in the way of Allah, and thereafter they were slain or they died - surely Allah will provide them with a goodly provision; and verily Allah! He is the Best Provider.

# 2654

Surely He will make them enter an entrance wherewith they will be well pleased and verily Allah is Knowing, Forbearing.

# 2655

That is so. And whosoever Chastiseth the like of that whereby He was injured, and thereafter he hath been ogain oppressed, surely Allah will succour him: verily Allah is Pardoning, Forgiving.

# 2656

That is to be because Allah plungeth the night into the day and plungeth the day into the night, and because He is Hearing, Beholding.

# 2657

That is because Allah! He is the Truth, and because that which they call upon beside Him--it is the false. And verily Allah! He is the High, the Great.

# 2658

Beholdest thou not that Allah sendeth down water from the heaven and the earth becometh green? Verily Allah is subtile, Aware.

# 2659

His is whatsoever is in the heavens and whatsoever is on the earth; and verily Allah He is the Self-sufficient, the PraiseWorthy.

# 2660

Beholdest thou not that Allah hath subjected to Himself for you whatsoever is on the earth and the ships running in the sea by His command? And He with holdeth the heaven that it fall not on the earth save by His leave. Verily Allah is, unto mankind, Clement, Merciful.

# 2661

And He it is who gave you life and will thereafter cause you to die, and will thereafter give you life; verily man is ingrate.

# 2662

Unto every community We have appointed a rite which they perform. Let them not therefore contend with thee in the affair; and call them thou unto thy Lord, verily thou art on true guidance.

# 2663

And if they dispute with thee, say thou: Allah knoweth best that which ye Work.

# 2664

Allah will judge between you on the Day of Judgment concerning that wherein ye have been differing.

# 2665

Knowest thou of that Allah knoweth whatsoever is in the heaven and the earth? Verily that is in a Book; verily that is for Allah easy.

# 2666

And they worship, beside Allah, that for which He hath revealed no authority and that whereof they have no knowledge; and for the wrong-doers there shall not be a helper.

# 2667

And when Our manifest signs are rehearsed unto them, thou recognizest repugnance on the countenaces of those who disbelieve; well- nigh they rush upon these who rehearse unto them Our Signs. Say thou: shall declare unto you something more grievous than that-the Fire--Allah hath promised it to those who disbelieve? An evil destination!

# 2668

O Mankind! a similitude is propounded; so hearken thereto. Verily those whom ye call upon beside Allah will by no means create a fly, even though they assembled for that; and if the fly were to snatch away aught from them, they cannot recover it from him: weak the seeker and the sought!

# 2669

They have not estimated Allah His rightful estimate; verily Allah is strong, Mighty!

# 2670

Allah chooseth from the angels messengers and also from mankind; verily Allah is Hearing, Beholding.

# 2671

He knoweth whatsoever is before them and whatsoever is behind them; and unto Allah are returned all affairs

# 2672

O Ye who believe! bow down and prostrate yourselves and worship your Lord, and do the good, that haply ye may thrive.

# 2673

And strive hard for Allah as is due unto Him hard striving. He hath distinguished you, and hath not placed upon you any narrowness in the religion the faith of your father, Ibrahim. He hath named you Muslim aforetime and in this, that the apostle may be a witness for you, and that ye may be witnesses against mankind. Wherefore establish the prayer and'give the poor-rate, and hold fast by Allah; He is your Patron: an Excellent Patron and Excellent helper!

# 2674

Blissful are the believers'-

# 2675

Those who in their prayer are lowly.

# 2676

And those who from everything vain turn away.

# 2677

And those who for the sake of purification are doers.

# 2678

And those who of their private Parts are guards.

# 2679

Save in regard to their spouses and those whom their right hands own: so they are not blameworthy-

# 2680

And Whosoever seeketh beyond that, then it is these who are the transgressors

# 2681

And those who of their trusts and covenant are keepers.

# 2682

And those who of their prayers are observant.

# 2683

These! they are the inheritors.

# 2684

Who shall inherit Paradise; therein they shall be abiders.

# 2685

And assuredly We created man of an extract of clay.

# 2686

Thereafter We made him of a Sperm In a receptacle safe.

# 2687

-Thereafter We created the sperm a clot; then We created the clot a lump of flesh; then We created the lump of flesh bones; then We clothed the bones with flesh: thereafter We brought him forth as anot her creature. Blest then be Allah, the Best of creators!

# 2688

Then verily, thereafter, ye are sure to die.

# 2689

Then verily on the Day of Judgment ye shall be raised up.

# 2690

And assuredly We created above you seven paths, and of the creation We have not been neglectful.

# 2691

And We sent down from the heaven water in measure, and We caused it to settle in the earth; and verily to take it away We are Able.

# 2692

Then We brought forth for you therewith gardens of date- palm and vines; for you therein are fruits many, and thereof ye eat.

# 2693

And also a tree that springeth forth from mount Sinai, that groweth oil and is a sauce for the eaters.

# 2694

And verily in the cattle for you is a lesson. We give you to drink of that which is in their bellies, and for you in them are advantages many, and of them ye eat.

# 2695

And on them and on the ship ye are borne.

# 2696

And assuredly We sent Nuh unto his people, and he said: O my people! worship Allah; for you there is no god but he; will ye not then fear Him!

# 2697

Then said the chiefs of those who disbelieved among his people: this is no other than a human being like unto you, he seeketh to make himself superior unto; and if God had willed, He would save sent down angels; we have not heard of this among our fathers ancient.

# 2698

He is only a man in whom is madness wherefore await for him for a season.

# 2699

Nuh said: my Lord! vindicate me, for they belie me.

# 2700

Then We revealed unto him, saying: build the ark under Our eyes and Our Revelation; then when Our command cometh and the oven boileth over, make way therein of every pair two, and thy household save him thereof against whom there hath already gone forth the word; and address me not in respect of those who have done wrong; verily they are to be drowned.

# 2701

And when thou art settled, thou and those with thee, in the ark, say thou: praise unto Allah who hath delivered us from the wrong doing people.

# 2702

And say thou, my Lord! cause me to land at a landing blest, and thou art the Best of these who bring to land.

# 2703

Verily in that are signs; verily We have ever been provers.

# 2704

Then, after them We brought forth anot her generation.

# 2705

Then We sent amongst them an apostle from amongst themselves, saying: worship Allah, for you there is no god but he; will ye then not fear Him?

# 2706

And said the chiefs of those who disbelieved among his people and belied the meeting of the Hereafter and whom We had luxuriated in the life of the World: this is no other than a human being like unto you: he eateth of that whereof ye eat, and he drinketh of that which ye drink.

# 2707

And were ye to obey a human being like you, ye are forthwith to be losers.

# 2708

Promiseth he unto you that ye, when ye have died and have become dust and bones, ye are to be brought forth?

# 2709

Away! away with that wherewith ye are promised;

# 2710

There is nought but our life of the world; we die and we live, and we are not going to be raised Up.

# 2711

He is but a man who hath fabricated against God a lie, and in him we are not going to be believers.

# 2712

He said: my Lord! vindicate for they belie me.

# 2713

Allah said: after a little while they will become regretful.

# 2714

Then the shout laid hold of them in truth, and We made them a refuse; so away with the wrong-doing people!

# 2715

Then after them We brought forth other generations.

# 2716

No community can anticipate their term, nor can they lay behind.

# 2717

Thereafter We sent Our apostles, successively. So oft as there came unto a community their apostle, they belied him, so We made them follow one anot her, and We made them bywords: so away with a people who believe not!

# 2718

Thereafter We sent Musa and his brother Harun with Our signs and an authority manifest.

# 2719

Unto Fir'awn and his chiefs, but they grew stiff-necked, and they were a people self-exalting.

# 2720

So they said: shall we believe In two human beings like unto us, while their nation are to us slaves?

# 2721

Then they belied the twain; so they became of those who were destroyed.

# 2722

And assuredly We vouchsafed unto Musa the Book, that haply they may be guided.

# 2723

And We made the son of Maryam and his mother a sign; and We sheltered the twain on a height: a quiet abode and running water.

# 2724

O Ye apostles! eat the good things and work righteously; verily of that which ye work I am the Knower.

# 2725

And verily this religion of yours is one religion, and I am your Lord, so fear Me.

# 2726

Then they cut their affair among them in regard to the Scriptures: each band in that which is with them rejoicing.

# 2727

Wherefore leave thou them in their bewilderment for a season.

# 2728

Deem they that in the wealth and sons wherewith We enlarge them.

# 2729

We are hastening them on to good things? Aye! they perceive not.

# 2730

Verily those who for fear of their Lord are in awe.

# 2731

And those who in the signs of their Lord do believe.

# 2732

And those who with their Lord associate not anyone.

# 2733

And those who give whatsoever they give, while their hearts are anxious that unto their Lord they are to be retutners

# 2734

These are hastening on to good, and they are therein foremost.

# 2735

And We task not any soul except according to its capacity, and with Us is a book speaking with truth, and they will not be wronged.

# 2736

Aye! their hearts are in bewilderment in respect thereof, and they have works beside that, of which they are workers.

# 2737

Until when We lay hold of the luxuriant ones of them with the torment, and lo! then they are imploring!

# 2738

Implore not to-day; verily ye from Us are not to be succoured.

# 2739

Surely My signs have been rehearsed unto you, and upon your heel ye were wont to draw back.

# 2740

Stiff-necked, discoursing thereof by night, reviling.

# 2741

Pondered they not over the Word? or came there unto them that which came not unto their fathers ancient?

# 2742

Or, is it that they recognised not their apostle, and so of him they become deniers?

# 2743

Or, say they: in him is madness? O Aye he brought them the truth, and most of them to the truth are averse.

# 2744

And were the truth to follow their desires there would have been corrupted the heavens and the earth and whatsoever is therein. Aye! We have come to them with their admonition; so it is from their admonition that they turn away.

# 2745

Or, is it that thou askest of them any maintenance? The maintenance of thy Lord is better, and He is the Best of providers.

# 2746

And verily thou! thou callest them unto a Path straight.

# 2747

And verily those who believe not in the Hereafter are from the path deviating.

# 2748

And though We have mercy on them We may remove whatsoever of hurt is with them, surely they would persist in their exorbitance, wandering perplexed.

# 2749

And assuredly We took hold of them with the torment, yet they humbled not themselves to their Lord, nor did they entreat.

# 2750

Until when we shall open upon them a portal of severe torment, and lo! thereat they are desparing

# 2751

And He it is Who brought forth for you hearing and sight and hearts, little thanks ye give!

# 2752

And He it is Who spread you on the earth, and unto Him ye will be gathered.

# 2753

And He it is Who quickeneth and causeth to die, and His is the alternation of night and day; will ye not then reflect?

# 2754

Aye! they say the like of that which said the ancients.

# 2755

They say: when we are dead, and have become dust and bones, shall we verily be raised up?

# 2756

Assuredly this we have been promised--we and our fathers-- aforetime: naught is this but the fables of the ancients.

# 2757

Say thou: whose is the earth and whosoever is therein, if you know?

# 2758

They will surely say: God's. Say thou: will ye not then heed?

# 2759

Say thou: who is Lord of the seven heavens and Lord of the mighty throne?

# 2760

They will surely say: God. Say thou: will ye not then fear?

# 2761

Saythou: in whose hands is the governance of everything, and who sheltereth but from whom none is sheltered, if ye know?

# 2762

They will surely say: God's. Say thou: how then are ye turned away?

# 2763

Aye! We have brought them the truth and verily they are the liars.

# 2764

Allah hath not betaken to Himself any son, and there is not along Him any god; else each god would have gone off with that which he had created, and one of them would have exalted himself above the others. Hallowed be Allah above that which they ascribe!

# 2765

Knower of the unseen and the seen, Exalted is He above that which they associate!

# 2766

Say thou; my Lord! if Thou wilt shew me that wherewith they are threatened.

# 2767

My Lord! then place me not among the wrong-doing people.

# 2768

And verily to shew them that wherewith We threaten them We are surely Able.

# 2769

Repel thou the evil with that which is the best, We are the Best Knower of that which they utter.

# 2770

And say thou: my Lord! I seek refuge with Thee against the whisperings of the satans;

# 2771

And I seek refuge with Thee, my Lord! lest they may be present with me

# 2772

lt ceaseth not until when death cometh to one of them, and he saith: my Lord! send me back.

# 2773

That I may work righteously in that which have left. By no means! It is but a word he uttereth; and before them is a barrier until the Day when they shall be raised.

# 2774

Then when the Trumpet is blown there will be no lineage among them that Day, nor will they ask of each other.

# 2775

Then he whose balances shall be heavy --these! they are the blissful ones.

# 2776

And he whose balances shall be light--these are they who have lost themselves: in Hell they are abiders.

# 2777

The Fire will scorch their faces, and therein they shall be grinning.

# 2778

Have not My revelations been rehearsed unto you, and them ye have been belying?

# 2779

They will say: our Lord! our wretchedness overcame, us, and we have been a people erring.

# 2780

O our Lord! take us forth from it: then if we return, we shall be wrong-doers indeed.

# 2781

He shall say: slink away there unto, and speak not unto Me.

# 2782

Verily there was a party of My bondmen who said: our Lord! we have believed, wherefore forgive us and have mercy upon us, and Thou art the Best of the merciful ones!

# 2783

Then ye took them mockingly, so that they caused you to forget remembrance of Me, and at them ye were wont to laugh.

# 2784

Verily I have recompensed them today for they bear patiently, verily they! are the achievers.

# 2785

He will say: how long tarried ye on the earth in number of year?

# 2786

-They will say we tarried a day or part of a day; ask those who keep count.

# 2787

He will say: ye tarried a little indeed; would that ye had known that:

# 2788

Deem ye that We have created youl in vain and that unto Us ye are not to be returned?

# 2789

So exalted be Allah, the True King! there is no god but he, Lord of the Throne honoured.

# 2790

And whosoever calleth, along with Allah, unto anot her god, of whom he hath no warranty, then his reckoning is only with his Lord; verily thrive will not the infidels.

# 2791

And say thou: my Lord! forgive and have mercy, and Thou art the Best of the merciful ones.

# 2792

This is a chapter which We have sent down, and which We have ordained; and therein We have sent down revelations manifest, that haply ye may be admonished.

# 2793

The adulteress and the adulterer: scourge each one of the twain with a hundred stripes. And let not tenderness rake hold of you in regarad to the twain in the law of Allah, if ye have come to believe in Allah and the Last Day. And let witness this torment a band of the believers.

# 2794

The adulterer weddeth not but an adulteress or an associatoress: and the adulteress! --none weddeth her save an adulterer or an associator; and that is forbidden unto the believers.

# 2795

And those who accuse clean wowomen and then bring not four eyewitnesses, Scourge them with eighty stripes and accept not their- testimony for Ever. And these! they are the transgressors

# 2796

Excepting those who thereafter shall repent and make amends. Verily Allah is Forgiving, Merciful.

# 2797

And as for those who accuse their wives and there are not for them witnesses except themselves, the testimony of one of them shall be four testimonies by Allah: that verily he is of the truth-tellers

# 2798

And the fifth, that the curse of Allah be upon him if he be of the liars.

# 2799

And it will revert the chastisement from her if she testifieth by Allah four times that verily he is of the liars.

# 2800

And the fifth that Allah's wrath be upon her if he is of the truthtellers.

# 2801

And had it not been for the grace of Allah and His mercy unto you and that Allah is Relenting, Wise, ye had been lost.

# 2802

Verily those who brought forward the calumny were a small band among Deem it not an evil for you; nay, it was good for you. Unto every one of them shall be that which he hath earned of the sin, and he among them who undertook the bulk of it---for him shall be a torment mighty.

# 2803

Wherefore, when ye heard it, did not the believing men and believing women imagine best of their own people and say: this is a calumny manifest!

# 2804

Wherefore did they not bring four witnesses thereof? Then when they brought not the witnesses, those! with Allah they are the liars.

# 2805

Had there not been Allah's grace upon you and His mercy in the World and the Hereafter, surely there would have touched you for that whcrein ye had rushed, torment mighty--

# 2806

When ye were publishing it with your tongues and saying that with your mouths of which ye had no knowledge. Ye deemed it light, and it was with Allah mighty!

# 2807

And wherefore, when ye heard it, did ye not say: it is not for us to speak thereof, hallowed be Thou! that is a slander mighty!

# 2808

Allah exhorteth you lest ye may ever revert to the like thereof, if ye are believers indeed.

# 2809

And Allah expoundeth unto you the revelations and Allah is Knowing, wise.

# 2810

Verily those who love that in decency should be propagated regarding those who believe, for them shall be a torment afflictive in the world and the Hereafter. And Allah knoweth, and ye know not.

# 2811

And had there not been Allah's grace upon you and His mercy, and that Allah was Tender and Merciful, ye had Perished.

# 2812

O Ye who believe! follow not the footsteps of the Satan. And whosoever followeth the footsteps of the Satan, then he only urgeth to indecency and abomination. And had there not been the grace of Allah upon you and His mercy, not one of you would ever have been cleansed; but Allah cleanseth whomsoever He Will and Allah is Hearing, Knowing.

# 2813

And let not the owners of affluence and amplitude among you swear off from giving unto the kindred and the needy and the emigrants in the way of Allah; let them pardon and overlook. Love ye not that Allah should forgive you And Allah is Forgiving, Merciful.

# 2814

verily those who accuse chaste. unknowing, - believing women, shall be cursed in the world and the Hereafter; and for them shall be a torment mighty.

# 2815

On the Day whereon their tongues and their hands and their feet will bear witness against them regarding that which they were wont to work.

# 2816

On that Day Allah shall pay them in full their recompense, and they shall know that Allah! He is the True, the Manifest.

# 2817

Vile women are for vile men, and vile men are for vile women, and clean women are for Clean men, and clean men are for clean women; these are quit of that which the people say: for them is forgiveness and a provision honoured.

# 2818

O Ye who believe! enter not houses other than your own until ye have asked leave and invoked peace on the inmates thereof. That is better for you, haply ye may take heed.

# 2819

Then if ye find no one therein, enter not until leave hath been given you. And if it iaid unto you go back, then go back. It is Cleaner for you, and Allah is of that which ye work knower.

# 2820

No fault it is upon you that ye enter houses uninhabited wherein there is some property for you; and Allah knoweth that which you disclose and that which ye hide.

# 2821

Say thou unto the believers that they shall lower their sights and guard their private parts, that is cleaner for them; verlly Allah is Aware of that which they perform.

# 2822

And say thou unto the believing women that they shall lower their sights and guard their private parts and shall not disclose their adornment except that which appeareth thereof; and they shall draw their scarves over their bosoms; and shall not disclose their adornment except unto their husbands or their fathers or their husbands fathers or their sons or their husbands sons or their brothers or their brothers sons or their sisters sons or their Women or those whom their right hands own or male followers wanting in sex desire or children not acquainted with the privy parts of women; and they Shall not strike their feet so that there be known that which they hide of their adornment. And turn penitently unto Allah ye all, O ye believers, haply ye may thrive!

# 2823

And wed the single among you and the fit ones among your male and female slaves; if they are poor, Allah will enrich them of His grace; Allah is Ample, Knowing.

# 2824

And those who find not means to marry shall restrain themselves until Allah enricheth them of His grace. And from among those whom your right hands own those who seek a writing- write it for them if ye know in them any good, and vouchsafe unto them of the wealth of Allah which He hath vouchsafed unto you. And constrain not your bedmaids to harlotry if they would live chastely, in order that ye may seek the chance gain of the life of the world. And whosoever will constrain them, then verily Allah is--after their constraint--Forgiving, Mercifu1.

# 2825

And assuredly We have sent down unto you revelations illuminating and a similitude for those who passed away before you and an exhortation unto the God-fearing.

# 2826

Allah is the light of the heavens and the earth: the likeness of His light is as a niche wherein is a lamp; the lamp is in glass; the glass is as though it were a star brilliant; lit from a tree blest, an olive, neither in the east nor in the west; well-nigh its oil would glow forth even though fire touch it not. light upon light. Allah guideth unto His light whomsoever He will: And Allah propoundeth similitudes for mankind: verily Allah is of everything the Knower.

# 2827

They worship in houses which Allah has bidden to be exalted and His name to be remembered therein; they hallow Him therein in mornings and evenings-

# 2828

Men whom neither trafficking nor bargaining diverteth from the remembrance of Allah and the establishment of the prayer and the giving of the poor-rate, fearing a Day whereon upset will be the hearts and sights.

# 2829

That Allah may recompense them the best for that which they worked and may increase unto them of His grace, and Allah provideth for whomsoever He will without measure.

# 2830

And those who disbelieve--their works are like a mirage in a desert which the thirsty deemeth to be water, until when he cometh thereto he findeth not aught, and findeth Allahs with himself, and He payeth him his account in full; and Allah is swift at reckoning.

# 2831

Or, like the darknesses in a sea deep; there covereth it a wave from above it, a wave from above it, above which is a cloud: darknesses one above anot her: when he putteth out his hand well-nigh he seeth it not. And upto whomsoever Allah shall not appoint a light, his shall be no light.

# 2832

Beholdest thou not that Allah --those hallow Him whosoever is in the heavens and the earth and the birds with wings outspread? Surely each one knoweth his prayer and his hallowing; and Allah is the Knower of that which they do.

# 2833

And Allah's is the dominion of the heavens and the earth, and unto Allah is the return.

# 2834

Beholdest thou not that Allah driveth a cloud along, then combineth it, then maketh it a heap, and then thou beholdest the fine rain come forth from the interstices thereof? And He sendeth down from the heaven mountains wherein is hail, then afflicteth therewith whomsoever He will, and averteth it from whomsoever He will: wellnigh the flash of His lightening taketh away the sights.

# 2835

Allah turneth the night and the day over and over; verily therein is a lesson for men of insight.

# 2836

Allah hath created every moving creature of water; of them is one that walketh upon his belly. and of them is one that walketh upon its two feet; and of them is one that walketh upon four. Allah createth whatsoever He listeth; verily Allah is over everything Potent.

# 2837

Assuredly We have sent down revelations illuminating: and Allah guideth whomsoever He listeth unto a path straight.

# 2838

And they say: we have believed in Allah and in the apostle and we have obeyed; then there backslide a party of them thereafter: and these are not believers.

# 2839

And when they are called to Allah and His apostle that he may judge between them, lo! a party of them are averters.

# 2840

And if right had been theirs, they would have come to him readily.

# 2841

Is in their hearts a disease? or doubt they? or fear they that Allah shall misjudge them, as also His apostle? Aye! these are the very wrong-doers!

# 2842

-The only saying of the believers when they were called to Allah and His apostle thathe might judge between them was that they said: We hear and we obey. And these! they are the very ones blissful.

# 2843

And whosoever obeyeth Allah and His apostle, and dreadeth Allah and feareth him-these! they are the achievers.

# 2844

And they swear by Allah with their solemn oaths that, if thou commandest them they will surely go forth. Say thou: swear not, obedience is recognize! verily Allah is Aware of that which ye Work.

# 2845

Say thou: obey Allah and obey the apostle; then if ye turn away, upon him is only that wherewith he hath been laid upon, and upon you is that wherewith ye have been laid upon; if ye obey him, ye will be guided; and naught is upon the apostle except the preaching plain.

# 2846

Allah hath promised those of you who believe and work the righteous works that he shall make them successors on the earth even as He had made those before them successors, and that he shall surely establish for them their religion which He hath approved for them, and that he shall surely exchange unto them after their fear a security, provided they worship Me, associating not aught with Me; and whosoever will disbelieve thereafter, then those! they are the transgressors.

# 2847

And establish the prayer and give the poor-rate and obey the apostle, haply ye may be shewn mercy.

# 2848

Deem not those who disbelieve able to frustrate His Purpose on the earth; and their abode shall be the Fire--an ill retreat!

# 2849

O Ye who believe! let those whom your right hands own and those of you who have not attained puberty ask leave of you three times before the dawn prayer, and when ye lay aside your garments noonday, and after the night-prayer: three at times of privacy for you. NO fault there is upon you or upon them beyond these times going round upon you, some of you upon some others. In this wise Allah expoundeth unto you the commandments; and Allah is Knowing, Wise.

# 2850

And when the children among you attain puberty, then let them ask leave even as those before them asked leave. In this wise Allah expoundeth unto you His commandments; and Allah is Knowing, Wise.

# 2851

And past child-bearing women who have no hope of wedlock-- upon them it is no fault that they lay aside their outer garments, not flaunting their adornment. And that they should restrain themselves is better for them; Allah is Hearing, Knowing.

# 2852

No restriction is there upon the blind, nor is there the restriction upon a lame, nor is there a restriction upon the sick. nor upon yourselves that ye eat in your houses or the houses of your fathers or the houses of your mothers or the houses of your brothers or the houses of your sisters or the houses of your fathers brothers or the houses of your fathers sisters or the houses of your mothers brothers or the houses of your mothers sisters or from that house where of ye own the keys or from the house of a friend. No fault is there upon you whether ye eat together or in separate groups, Then when ye enter houses, salute each other with a greeting from before Allah, blest and goodly. Thus Allah expoundeth unto you the revelations, haply ye may reflect.

# 2853

The believers are those alone who have believed in Allah and His apostle, and when they are with him on some affair collecting People together they depart not Until they have asked his leave. Verily those who ask thy leave, those are they who believe in Allah and His apostle. So if they ask thy leave for some business of theirs, give thou leave unto whomsoever of them thou wilt, and ask thou forgiveness of Allah for them. Verily Allah is Forgiving, Merciful.

# 2854

Place not the apostle's calling among you on the same footing as your calling of each other. Of a surety Allah knoweth those who slip away privately; let therefore those who oppose His commandment beware lest there befall them a trial or there befall them a torment afflictive.

# 2855

Lo! verily Allah's is whatsoever is in the heavens and the earth; surely He knoweth that which ye are about and the Day whereon they shall be made to return unto Him; then He shall declare unto them that which they worked; and Allah is of everything the Knower.

# 2856

Blest be He who hath revealed the Criterion unto His bondman thathe may be unto the worlds a warner.

# 2857

He whose is the dominion of the heavens and the earth, and who hath not taken a son, and for whom there is not an associate in the dominion, and who hath created everything, and measured it according to a measurement.

# 2858

And they have taken beside Him gods creating not aught and are themselves created, owning for themselves neither hurt nor benefit, and owning not death nor life nor resurrection.

# 2859

And those who disbelieve, say. this is naught but a falsehood thathe hath fabricated and there have assisted him therein other people. so surelythey have aimed at a wrong and a fraud.

# 2860

And they say: fables of the ancients which he hath had written down, so they are dictated unto him, morning and evening.

# 2861

Say thou; He hath sent it down Who knoweth the secret of the heavens and the earth; verily He is ever Forgiving, Merciful.

# 2862

And they say: what aileth this apostle: he eateth food and walketh about the market-places: wherefore is not an angel sent down unto him, so thathe may be along with him a warner '

# 2863

Or, whereforeis not there cast down unto him a treasure or he has a garden whereof he may eat! And the wrong-doeray: ye follow only a man bewitched.

# 2864

Behold how they propound similitudes for thee! so they have strayed and cannot find a way.

# 2865

Blest is He Who, if He willed, shall appoint for them something better than that: gardens whereunder the rivers flow, and appoint for them palaces.

# 2866

Aye! they belie the Hour; and We have gotten ready for him who belieth the Hour a Flame.

# 2867

When it beholdeth them from afar, they shall hear it raging and roaring.

# 2868

And when they are flung into a strait place thereof, bound Up, they shall call therein unto death.

# 2869

Call not to-day for a single death but call for death manifold.

# 2870

Say thou: in that better or Garden of Abidence that hath been promised to the God-fearing! It shall be theirs as a recompense and a retreat.

# 2871

Theirs therein shall be all that they wish for, as abiders; a promise from thy Lord to be asked for.

# 2872

And on the Dav whereon He will gather them and that v; hich they worship beside Allah and will say. are ye the ones who sent astray these My bondmen; or strayed they themselves from the way!

# 2873

They will say; hallowed be Thou! it behoved us not that we should take beside Thee any patron, but Thou allovvedest them and their fathers enjoyment Until they forgat the admonition, and they were a people doomed.

# 2874

So now they belie you in that which ye said; so ye are not able to obtain diversion nor help. And who soever of you doth wrong, him We shall make taste a great torment.

# 2875

And We have not sent before thee ony of the sent ones but verily they ate food and walked about in the market places. And We have made some of you unto some others a temptation; will ye have patience! And thy Lord is ever a Beholder. pART XIX

# 2876

And those who fear not the meeting with Usl say: wherefore are not angels sent down unto us or wherefore we see not our Lord! Assuredly they have proven stiff-necked in their souls and have exceeded the bounds with excess great.

# 2877

The Day whereon they shall behold the angels on that day there will be nea joy for the culprits, and they will say: away! away!

# 2878

And We shall set upon that which they worked, and shall make it as dust wind-scattered.

# 2879

Fellows of the Garden shall be on that Day in a goodly abode and a gocdly re pose.

# 2880

And on the Day whereon the heaven shall be rent asunderg from the q clouds and the angelhall be sent downll with a great descending.

# 2881

The dominion on that Day rhall is; be the true dominion, of the Compassionate, l and it shall be anday upon the infidels hard.

# 2882

On the Day when the wrong-doer shall gnaw his hands saying: would that had taken with the apostle a way!

# 2883

Ah! woe unto me! wouldthat had never taken such a one for a friend!

# 2884

Assuredly he misled me from the admonition after it had come unto ine. Verily the Satan is ever unto man a betrayer.

# 2885

And the Apostle will say: my lord! verily my people too k this Qur'an as a thing to be shunned.

# 2886

And even scals We appointed unto every prophet an enemy from among the culprits. And thine Lord sufficeth as GUide and Helper.

# 2887

And those who disbelieve say: wherefore is the Qur'an not revealed unto him entire at once! Thus---We reveal- that We may establish thy heart there with; and We have repeated it with a repetition.

# 2888

And they come not unto thee with a similitude but We bring thee the truth and an excellent interpretation.

# 2889

They who shall be gathered prone on their faces unto Hell-- those shall be worst in respect of place and the most astray in respect of path.

# 2890

And assuredly We vouchsafed unto Musa the Book and We placed with him his brother Harun as a minister.

# 2891

Then We said: go ye twain unto a people who have belied Our signs. Then We annihilated them an utter annihilation.

# 2892

And the people of Nuh! When they belied the apostles We drowned them, and made them a sign unto mankind. And We have gotten ready unto the wrong-doers a torment afflictive,

# 2893

And the 'Aad and the Thamud and the dwellers of the pass and generations in-between many.

# 2894

And unto each! We propounded similitude thereunto; and each We ruined an utter ruin.

# 2895

And assuredly they have gone by the township whereon was rained the evil rain. Are they not wont to see it? Aye! they expect not Resurrection.

# 2896

And when they behold thee, they hold thee up for mockery: is this the one whom Allah hath sent as an apostle

# 2897

Well nigh he had led us astray from our gods if we had not persevered towards them. Presently they shall know, When they behold the torment, who, more astray in respect of path.

# 2898

Hast thou observed him who hath taken as his god his own desire! wilt thou be over him a trustee?

# 2899

Or deemest thou that most of them hear or understand? They are but like unto the cattle; nay, they are even farther astray from the path.

# 2900

Hast thou not observed thine lord-how He hath stretched out the shadow? And if He had willed He would have made it still. Then We have made the sun for it an indication.

# 2901

Then We draw it toward Us with an easy drawing.

# 2902

And it is He who hath made for you the night a covering, and the sleep; repose, and hath made the day a resurrection.

# 2903

And it is He who sendeth fort the winds as a herald before His mercy and We send down from the heaven water pure.

# 2904

That We may quicken thereby a dead land, and We give drink thereof to that which We have created of cattle and human beings many.

# 2905

And We set it forth among them, that they may be admonished, but most men begrudge aught save infidelity.

# 2906

And if We had willed, We would have raised up in each town a warner.

# 2907

Se obey not thou the infidels, but strive against them therewith with a great striving.

# 2908

And it is He who hath mixed the two seas: this, sweet ond thirst quenching; that, saltish ond bitter; and hath placed between the twain a barrier and a great partition complete.

# 2909

And it is He who hath created man from water, and then made for him kinship by blood and marriage. And thy Lord is ever potent.

# 2910

And yet they worship, besides Allah, that which can neither benefit them nor hurt them; and the infidel is ever an aider of the devil against his Lord.

# 2911

And We sent thee but as a bearer of glad tidings and warner.

# 2912

Say thou. ask of you no hire for this, save that whosoever will may take unto his Lord a way.

# 2913

And trust thou in the Living One who dieth not, and hallow His praise; it sufficeth that he of the sins of His bondmen is Aware.

# 2914

Who created the heavens and the earth and whatsoever is in- between them in six days, then He established Himself on the Throne -the Compassionate! so, concernin Him, ask any one informed.

# 2915

And when it is said unto them: prostrate yourselves unto the Compassionate, they say: and what is the Compassionate? Shall we prostrate ourselves unto that which thou commandest us? And it increaseth in them aversion.

# 2916

Blest be He Who hath placed big stars in the heaven, and hath placed therein a lamp and a moon enlightening.

# 2917

And it is He Who hath appointed the night and the day a succession, for him who desireth to consider or desireth to be grateful.

# 2918

And the bondmen of the Compassionate are those Who Walk upon the earth meekly and when the ignorant address them, they say peace

# 2919

And these who pass the night before their Lord, prostrate and standing up.

# 2920

And these who say: our Lord! avert from us the torment of Hell verily the torment thereof is perishment.

# 2921

Verily ill it is as an abode and as a station.

# 2922

And those who when they expend, are neither extravagant nor sparing, and it is a medium in-between.

# 2923

And those who call not unto anot her god along with Allah and slay not any soul which Allah hath forbidden, save in justification, and commit not fornication. And Whosoever shall do this, Shall incur the meed.

# 2924

Multiplied for him shall be the torment on the Day of Resurrection, and he shall therein abide disgraced.

# 2925

Save him who repenteth and believeth and worketh righteous work. Then these! for them Allah shall change their vices into virtues. Verily Allah is ever Forgiving, Merciful.

# 2926

And whosoever repenteth and worketh righteously, then verily he repenteth toward Allah with a true repentance.

# 2927

And those who witness not falsehood, and when they pass by some vanity pass by with dignity.

# 2928

And those who, when they are admonished by the commands of Allah, fall not down thereat, deaf and blind.

# 2929

And those who say: our Lord bestow on us coolness of eyes from our wives and our offspring, and make us unto the God-fearing a pattern.

# 2930

Those shall be rewarded with the highest apartment, because they persevered. and therein they shall be met with a greeting and salutation-

# 2931

Abiders therein: excellent it is as an abode and as a station.

# 2932

Say thou: my Lord careth not for you were it not for your prayer. whereas ye have even belied, so presently this denial shall come as the cleaving punishment.

# 2933

Ta. Sin Mim.

# 2934

These are the verses of a Book luminous.

# 2935

Belike thou shalt kill thyself with grief because they become not believers.

# 2936

If We list, We can send down unto them a sign from the heaven so that their necks would became to it submissive.

# 2937

And there cometh not unto them any fresh admonition from the Compassionate but they are wont to be there from backsliders.

# 2938

So they have surely belied; wherefore anon there shall come unto them the truth of that whereat they were wont to mock.

# 2939

Observe they not the earth, how much We make to grow therein of every fruitful kind?

# 2940

Verily therein is a sign; yet most of them are not believers.

# 2941

And verily thy Lord! He is the Mighty, the Merciful.

# 2942

And recall what time thy Lord called unto Musa, saying: go thou unto the wrong-doing people.

# 2943

The people of Fir'awn; fear they Me not?

# 2944

He said: my Lord! verily I fear they shall belie me.

# 2945

And my breast straiteneth, and my tongue moveth not quickly: so send for Harun.

# 2946

And they have a crime against me, so I fear that they shall slay me.

# 2947

He said: by no means. so go ye twain with Our signs; verily We shall be with you listening.

# 2948

So go ye twain unto Fir'awn and say: verily we are the apostles of the Lord of the Worlds,

# 2949

Send with us the Children of Isra'il?

# 2950

Fir'awn said: brought we not thee up amongst us as a child? And thou tarriedst amongst us for many years of thy life?

# 2951

And thou didst that thy deed which thou didst; and thou art of the ingrates.

# 2952

He said: I did it then when I was mistaken.

# 2953

Then I fled from you when I feared you, and my Lord bestowed on me wisdom and made me one of the sent ones.

# 2954

And that favour wherewith thou didst oblige me was that thou hadst enslaved the Children of Isra'il?

# 2955

Fir'awn said. and what is the Lord of the worlds?

# 2956

He said: Lord of the heavens and the earth and whatsoever is in-between, if ye seek to be convinced.

# 2957

Fir'awn said unto those around him: hear ye not?

# 2958

He said: your Lord and the Lord of your ancient fathers.

# 2959

Fir'awn said: verily your apostle who hath been sent unto you is mad.

# 2960

He said: Lord of the east and the west and whatsoever is in-between, if ye understand.

# 2961

Fir'awn said: if thou wilt take a god other than me, I shall surely place thee among the prisoners.

# 2962

He said: even though I bring unto thee something manifest?

# 2963

Fir'awn said: forth with it then, if thou art of the truth- tellers.

# 2964

Then he cast down his staff, and lo! it was a serpent manifest.

# 2965

And he drew forth his hand, and lo! it was white unto the beholders.

# 2966

Fir'awn said unto the chiefs around him: verily this is a magician knowing.

# 2967

He would drive you out of your land through his magic; what then is it ye command?

# 2968

They said: put off him and his brother, and send unto the cities callers.

# 2969

Thot they may bring to thee every magician knowing.

# 2970

So the magicians were assembled at a set time on a day made known.

# 2971

And it was said unto the people: are ye going to assemble.

# 2972

Belike we may follow the magicians if they are the winners?

# 2973

Then when the magicians came, they said unto Fir'awn: will there surely be a big hire for us if we are the winners?

# 2974

He said: yea; and ye shall verily then be of those brought nigh.

# 2975

Musa said unto them: cast whatsoever ye have to cast.

# 2976

Then they cast their cords and their staves, and said: by the might of Fir'awn, verily we! we shall be the winners.

# 2977

Then Musa cast down his staff, and lo! it swallowed up that which they had devised.

# 2978

Then the magicians flung themselves prostrate.

# 2979

They said: we believe in the Lord of the worlds.

# 2980

The Lord of Musa and Harun.

# 2981

Fir'awn said: ye believed in him ere I gave you leave. Verily he is your chief who hath taught you magic, so ye shall surely come to know. Surely I shall cut off your hands and feet on opposite sides and surely I shall crucify you all.

# 2982

They said: no harm! verily unto our Lord we are to return.

# 2983

Verily we long that our Lord shall forgive us our faults because we have been the first of the believers

# 2984

And We revealed unto Musa saying: go by night with My bondmen verily ye shall be pursued.

# 2985

Then Fir'awn sent unto the cities callers:

# 2986

Verily these are but a band small.

# 2987

And verily they have enraged US.

# 2988

And verily we are host well-provided.

# 2989

Then We drave them forth from gardens and springs.

# 2990

And treasures and a station noble.

# 2991

Even so. And We caused the Children of Isra'il to inherit them.

# 2992

Then they pursued them at sunrise.

# 2993

And when the two parties saw each other, the companions of Musa said: verily we are overtaken.

# 2994

Musa said: by no means; verily with me is my Lord; He shall guide me.

# 2995

Then We revealed unto Musa, saying: smite thou the sea with thy staff. So it became separated, and each part was like unto a cliff mighty.

# 2996

And We brought near thither the others.

# 2997

And We delivered Musa and those with him together.

# 2998

Then We drowned the others.

# 2999

Verily herein is a sign; but most of them are not believers.

# 3000

And verily thy Lord! He is the Mighty, the Merciful.

# 3001

And recite unto them the story of Ibrahim.

# 3002

When he said unto his father and his people: what worship ye?

# 3003

They said: we worship idols, and we are unto them ever devoted

# 3004

He said: hearken they unto you when ye cry?

# 3005

Or, benefit they you or hurt they you?

# 3006

They said: nay; but we found our fathers doing in this wise.

# 3007

He said: have ye observed that which ye worship

# 3008

Ye and your fathers of old?

# 3009

Verily they are an enemy unto me, save the Lord of the worlds.

# 3010

Who hath created me, and He guideth me.

# 3011

He Who feedeth me and giveth me to drink.

# 3012

And when I sicken, then He healeth me.

# 3013

And He Who shall cause me to die, and then shall quicken me.

# 3014

And He Who, long, shall forgive me my faults, on the Day of Requital.

# 3015

My Lord! bestow on me wisdom and join me with the righteous.

# 3016

And appoint for me an honourable mention among the posterity

# 3017

And make me one of the inheritors of the Garden of Delight.

# 3018

And forgive my father; verily he is of the erring.

# 3019

And humiliate me not on the Day whereon people shall be raised.

# 3020

The Day whereon will profit neither substance nor sons.

# 3021

Unless it be he, who shall bring unto Allah a whole heart,

# 3022

And the Garden shall be brought nigh to the God, fearing.

# 3023

And the Fierce Fire shall be made apparent unto the seduced ones.

# 3024

And it shall be said unto them where is that which ye were wont to worship?

# 3025

Beside Allah? Can they succour you or succour themselves?

# 3026

Then they shall be hurled therein, they and the seduced ones.

# 3027

And the hosts of Iblis together.

# 3028

And they, While contending therein, shall say:

# 3029

By Allah, we have indeed been in an error manifest.

# 3030

When we equalled you with the Lord of the worlds.

# 3031

And none led us astray except the Culprits.

# 3032

So none we have as intercessors.

# 3033

Nor any loving friend.

# 3034

Were there for us a return, we would be of the believers.

# 3035

Verily herein is a sign, but most of them are not believers.

# 3036

And verily thy Lord! He is the Mighty, the Merciful.

# 3037

And Nuh's people belied the sent ones.

# 3038

When their brother Nuh said Unto them: fear ye not?

# 3039

Verily I am unto you an apostle trusted.

# 3040

So fear Allah and obey me.

# 3041

And I ask of you no hire therefor; my hire is but with the Lord of the worlds.

# 3042

So fear Allah and obey me.

# 3043

They said: shall We believe in thee when the meanest follow thee?

# 3044

He said: I have no knowledge of that which they have been Working.

# 3045

Their reckoning is upon my Lord, if ye but knew.

# 3046

And I am not to drive away the believers.

# 3047

I am naught but a warner manifest.

# 3048

They said: if thou desistest not, thou shalt surely be of those stoned.

# 3049

He said: my Lord! verily my people have belied me.

# 3050

So decide Thou between me and them with a decision, and deliver me and those who are with me of the believers.

# 3051

Wherefore We delivered him and those with him in the laden ark.

# 3052

Then We drowned the rest thereafter.

# 3053

Verily herein is a sign, yet most of them are not believers.

# 3054

And thy Lord! He is the Mighty, the Merciful.

# 3055

The'Aad belied the sent ones.

# 3056

When their brother Hud said Unto them: fear ye not?

# 3057

Verily I am unto you an apostle trusted.

# 3058

So fear Allah and obey me.

# 3059

And I ask of you no hire therefor: my hire is but with the Lord of the worlds.

# 3060

Build ye on every eminence a landmark in vanity?

# 3061

And take ye for yourselves castles that haply ye may abide.

# 3062

And when ye seize, ye seize like unto tyrants.

# 3063

So fear Allah, and obey me.

# 3064

And fear Him Who hath aided you with that which ye know.

# 3065

He hath aided you With Cattle and sons.

# 3066

And gardens and springs.

# 3067

Verily I fear for you the torment of a Mighty Day.

# 3068

They said: it is equal unto us whether thou admonishest or art not of the admonishers.

# 3069

This in but a custom of the ancients.

# 3070

And we are not going to be tormented.

# 3071

And they belied him; so We destroyed them. Verily herein is a sign, yet most of them are not believers.

# 3072

And verily thy Lord? He is the Mighty, the Merciful.

# 3073

The Thamud belied the sent ones

# 3074

When their brother Salih said unto them: fear ye not?

# 3075

Verily I am unto you an apostle trusted.

# 3076

So fear Allah, and obey me.

# 3077

And I ask of you no hire therefor; MY hire is but with the Lord of the worlds.

# 3078

Shall ye be left secure in that which is here before us.

# 3079

In gardens and springs.

# 3080

And corn-fields and palm-trees whereof the spathes are fine?

# 3081

And hew ye out houses in the mountains skilfully! g

# 3082

So fear Allah, and obey me.

# 3083

And obey not the command of the extravagant.

# 3084

Who work corruption in the land and rectify not.

# 3085

They said: thou art but one of the bewitched;

# 3086

Thou art but a human being like unto us. So bring thou a sign if thou art of the truth-tellers.

# 3087

He said: yonder is a she-camel; to her a drink, and to you a drink, each on a day known.

# 3088

And touch her not with ill, lest there take hold of you the torment of a Mighty Day.

# 3089

Then they hamstrung her; and then they became regretful.

# 3090

So the torment took hold of them: verily herein is a sign, but most of them are not believers.

# 3091

And verily thy Lord! He is the Mighty, the Merciful.

# 3092

The people of Lut belied the sent ones.

# 3093

When their brother Lut said unto them: fear ye not?

# 3094

Verily I am unto you an apostle trusted.

# 3095

So fear Allah, and obey me.

# 3096

And I ask of you no hire there for; my hire is but with the Lord of the worlds.

# 3097

Go ye in, of all creatures, unto the males?

# 3098

And leave ye your spouses your Lord hath created for you? Aye! ye are a people trespassing.

# 3099

They said: if thou desistest not, O Lut! thou shalt surely be of those driven forth.

# 3100

He said: verily I am of those who abhor your work.

# 3101

My Lord! deliver me and my household from that which they work.

# 3102

So We delivered him and his household all.

# 3103

Save an old woman among the lingerers.

# 3104

Thereafter We annihilated the rest.

# 3105

And We rained on them a rain. So ill was the rain on those warned?

# 3106

Verily herein is a sign, yet most of them are not believers.

# 3107

And verily thy Lord! He is the Mighty, the Merciful.

# 3108

The dwellers of the wood belied the sent ones.

# 3109

What time Shu'aib, said unto them: fear ye not?

# 3110

Verily I am unto you an apostle trusted.

# 3111

So fear Allah, and obey me.

# 3112

And ask of you no hire therefor; and my hire is but with the Lord of the worlds.

# 3113

Give full measure, and be not of those who cause others to lose.

# 3114

And weigh with a balance straight.

# 3115

And defraud not people of their things, and commit not corruption on the earth.

# 3116

So fear Him Who created you and the former generations.

# 3117

They said: thou art but of the bewitched;

# 3118

And thou art but a human being like unto us, and we deem thee to be of the liars.

# 3119

So cause thou a fragment of the heaven to fall upon us, if thou art of the truth-tellers.

# 3120

He. said: My Lord is the Best Knower of that which ye work.

# 3121

Thenn they belied him; wherefore there laid hold of -them the torment of day of shadow. Verily it was the torment of a Mighty Day.

# 3122

Verily herein is a sign; but most of them are not believers.

# 3123

And verily thy Lord! He is the Mighty, the Merciful.

# 3124

And verily it is a revelation of the Lord of the worlds.

# 3125

The Trusted spirit hath brought it down.

# 3126

Upon thy heart, that thou mayest be of the warners,

# 3127

In plain Arabic speech.

# 3128

And verily it is in the Scriptures of the ancients.

# 3129

Is it not a sign unto them that the learned among the Children of Isra'il know it?

# 3130

And had We revealed it unto any of the ncn-Arabs,

# 3131

And he had-read it unto them, even then they would not have been believers therein.

# 3132

In this wise have We made way for it into the hearts of the culprits.

# 3133

They will not believe therein until they behold the torment afflictive.

# 3134

It shall come unto them on a sudden, and they shall not perceive.

# 3135

Then they will say: are we to be respited?

# 3136

Seek haste then they with our torment?

# 3137

Beholdest thou? - if We let them enjoy for years.

# 3138

And then there cometh unto them that which they had been promised.

# 3139

What shall that which they enjoyed avail them?

# 3140

And We destroyed not a city but it had its warners.

# 3141

By way of admonition, and We have never been oppressors.

# 3142

And the satans have not brought it down.

# 3143

It behoveth them not, nor they can.

# 3144

Verily far from hearing are they removed.

# 3145

So call not thou unto anot her god along with Allah, lest thou be of the doomed.

# 3146

And warn thou thy clan, the nearest ones.

# 3147

And lower thou thy Wlng Unto those who follow thee as believers.

# 3148

And if they disobey thee, say thou: verily I am quit of that which ye work.

# 3149

And rely thou upon the Mighty, the Merciful.

# 3150

Who seeth thee when thou standest up

# 3151

And thy movements among those who fall prostrate.

# 3152

Verily He! He is the Hearer, the Knower.

# 3153

Shall declare unto you upon whom the satans descend!

# 3154

They descend upon every calumniator, sinner.

# 3155

Who give ear, and most of them are liars.

# 3156

As for the poets -it is the seduced who follow them.

# 3157

Observest thou not, that they Wander about every vale.

# 3158

And that they say that which they do not?

# 3159

Save those who believed and worked righteous works and remembered Allah much, and vindicated themselves after they had been wronged. And anon those who do wrong shall come to know with what a translating they shall be translated.

# 3160

Ta. Sin. These are the verses of the Qur'an and a Book luminous.

# 3161

A guidance and glad tidings unto the believers.

# 3162

Who establish the prayer and give the poor-rate, and of the Hereafter they are convinced.

# 3163

Verily those who believe not in the Hereafter - fairseeming unto them We have made their works, so that they wander perplexed.

# 3164

Those are they for whom shall be an evil torment. And in the Hereafter they shall be the greatest losers.

# 3165

And verily thou art receiving the Qur'an) from before the Wise, the Knowing.

# 3166

Recall what time Musa said unto his household: verily I perceive a fire afar; I shall forthwith bring you tidings thereof, or bring unto you a brand lighted therefrom, haply ye may warm yourselves.

# 3167

Then when he came unto it, he was cried unto Thus; Blest is whosoever is in the fire and whosoever is around it; and hallowed be Allah, the Lord of the Worlds.

# 3168

O Musa! verily it is I, Allah, the Mighty the Wise!

# 3169

And cast thou down thy staff. Then when he saw it wriggling as though it were a serpent, he turned in flight and looked not back. O Musa! fear thou not; verily in My presence the sent ones fear not.

# 3170

Excepting any who may have done wrong and thereafter changeth evil for good then verily I am Forgiving, Merciful.

# 3171

And put thy hand into thy bosom, it Shall come forth white, with out hurt: amongst nine signs unto Fir'awn and his people. Verily they have been a people transgressing.

# 3172

Then when Our signs came unto them illuminating, they said: this is a magic manifest.

# 3173

And they gainsaid them, out of spite and arrogance, although their souls were convinced thereof. So behold! what hath been the end of the corruptors.

# 3174

And assuredly We vouchsafed unto Daud and Sulaiman a knowledge, and the twain said: praise unto Allah Who hath preferred us above many of His believing bondmen!

# 3175

And Sulaiman inherited from Daud. And he said: O mankind! verily have been taught the diction of we birds, and we have been vcuchsafed of every thing; and verily this is grace manifest.

# 3176

And there were gathered unto Sulaiman his hosts of jinns and mankind and birds, and they were set in bands.

# 3177

Until when they came unto the valley of the ants, an ant said: O ants! enter Your habitations lest Sulaiman and his hosts crush you while they perceive not.

# 3178

So he smiled, amused at her speech, and said: my Lord! arouse me that I should be thankful for Thy favour wherewith Thou hast favoured me and my parents, and that I should work righteously pleasing Thee, and out of Thy mercy enter me among Thine righteous bondmen.

# 3179

And he sought after the birds and said: what aileth me that I see not the hoopoe; is he among the absentees?

# 3180

Surely I shall torment him with a severe torment, or I shall slaughter him, unless he bringeth unto me a warranty manifest.

# 3181

Buthe tarried not far, and he said: I have encompassed that which thou hast- not encompassed, and I come unto thee from Saba with a tidings sure.

# 3182

Verily have found a woman ruling over them and she hath been vouchsafed somewhat of everything, and hers is a mighty throne.

# 3183

I have found her and her people adoring the sun instead of Allah, and the Satan hath made their works fairseeming unto them, and hath barred them from the way, so they are not guided.

# 3184

So that they adore not Allah who bringeth forth the hidden in the heavens and the earth, and knoweth that which conceal and that which ye make known.

# 3185

Allah! there is no God but he, the Lord of the Magnificent Throne.

# 3186

Sulaiman said: we shall see now whether thou hast spoken the truth or whether thou art of the liars.

# 3187

Go thou with this epistle of mine, and cast it down unto them, and turn aside from them, and see how they return.

# 3188

She said: O chiefs! verily there hath been cast unto me an honourable epistle.

# 3189

Verily it is from Sulaiman, and verily it is: in the name of Allah, the Compassionate, the Merciful.

# 3190

Saying: exalt not yourselves against me, and come unto me submissive.

# 3191

She said: O chiefs! counsel me in my affair. I am wont not to resolve on any affair until ye are present with me.

# 3192

They said: we are owners of power and owners of great violence, but the command is with thee; see then whatsoever thou shalt command.

# 3193

She said: verily the kings, when they enter a City, despoil it, and make the most powerful inhabitants thereof the most abased; so will they do.

# 3194

So verily I am going to send a present unto them, and see with what answer the envoys come back.

# 3195

Then when he came unto Sulaiman, he said: are ye going to add riches to me. Then that which Allah hath vouchsafed unto me is better than that which He hath vouchsafed unto you. Aye! it is ye who exult in your present.

# 3196

Go back unto them. Then surely we shall come unto them with hosts which they cannot withstand, and we shall drive them forth therefrom abased and they shall be humbled.

# 3197

He said: O chiefs! which of you will bring unto me her throne, ere they come unto me submitting themselves?

# 3198

A giant from the jinns said: I shall bring it unto thee ere thou arisest from thy place; verily I am strong for it and trusty.

# 3199

The one who had some knowledge of the Book said: I shall bring it unto thee ere thy eye twinkleth. Then when he saw it placed before him, he said: this is of the grace of my Lord that he may prove me whether I give thanks or am ungrateful. Whosoever giveth thanks he only giveth thanks for his own soul; and whosoever is ungrateful then verily my Lord is Self-sufficient, Munificent.

# 3200

He said: disguise for her her throne, that we may see whether she be guided or be of those who are not guided.

# 3201

Then when she arrived, it was said: is thy throne like unto? She said: it is as though it were it; and we have been vouchsafed the knowledge before this, and we have been Muslims.

# 3202

And that which she was wont to worship instead of Allah hindered her; verily she was of an infidel people.

# 3203

It was said unto her: enter the palace. Then when she saw it,, he deemed it a pool and bared her shanks. He said: verily it is a palace evenly floored with glass. She said: my Lord! verily I wronged my soul, and now submit myself together with Sulaiman unto Allah, the Lord of the Worlds.

# 3204

And assuredly We sent unto the Thamud their brother Saleh saying: worship Allah. Then lo! they became two parties contending.

# 3205

He said: O my people! wherefore seek ye to hasten the evil before the good? Wherefore ask ye not forgiveness of Allah, that haply ye may be shewn mercy.

# 3206

They said: we augur ill of thee and of those who are with thee. He said: your augury is with Allah. Aye! ye are a people being tested.

# 3207

And there were nine of a group in the City, who spread corruption in the land and rectified not.

# 3208

They said: swear one to anot her by God that we shall surely fall upon him and his household by night and thereafter we shall surely say unto his heir; We witnessed not the destruction of his household, and verily we are truthtellers.

# 3209

And they plotted a plot, and We plotted a plot, while they perceived it not.

# 3210

So behold thou how was the end of their plotting: verily We annihilated them and their nation all together.

# 3211

So yonder are their houses overturned, for they did wrong. Verily, herein is a sign unto a people who know.

# 3212

And We delivered those who believed and were wont to fear.

# 3213

And Lut! what time he said unto his people: commit ye indecency while ye see?

# 3214

Would ye go in lustfully unto men instead of women? Aye! ye are a people addicted to ignorant ways.

# 3215

Then there was no answer of his people save that they said: drive forth the family of Lut from your City, verily they are a people who would be pure!

# 3216

Then We delivered him and his household save his wife: We destined hers to be of the lingerers.

# 3217

And We rained upon them a rain; ill was the rain upon the warned.

# 3218

Say thou: All praise unto Allah, and peace upon His bondmen whom He hath Chosen! Is Allah best, or that which they associate?

# 3219

Is not he best Who hath created the heavens and the earth, and Who sendeth down water for you from the heaven wherewith We cause beauteous orchards to grow up, whereof it was not possible for you to cause the trees to grow up! Is there any god along with Allah! Nay! but they are a people who equalise.

# 3220

Is not he best Who hath made the earth a fixed abode and placed rivers in the midst thereof and placed Firm mountains thereon, and hath set a barrier between the two seas? IS there any god along with Allah? Nay! but most of them know not.

# 3221

Is not he best Who answereth the distressed when he calleth unto Him and removeth the evil, and hath made you the successors in the earth? Is there any god along with Allah? Little ye reflect!

# 3222

Is not he best Who guideth you in the darknesses of the land and the sea, and Who sendeth the winds as heralds before His mercy Is there any god along with Allah? Exalted be Allah from all that they associate!

# 3223

Is not he best Who originateth creation, and shall thereafter restoreth it, and Who provideth for you from the heaven and the earth? IS there any godl along with Allah? Say thou: bring your proof, if ye are truth-tellers.

# 3224

Say thou: none in the heavens and the earth knoweth the Unseen save Allah; nor can they perceive when they will be raised.

# 3225

Aye! their knowledge attaineth not to the Hereafter, Aye! they are in doubt thereof. Aye! thereunto they are blind.

# 3226

And those who disbelieve say: when we have become dust, we and our fathers, shall we, for sooth, be brought forth?

# 3227

Assuredly we have been promised this aforetime, we and our fathers. Naught is this but fables of the ancients.

# 3228

Say thou: travel in the land and behold what like hath been the end of the culprits.

# 3229

And grieve thou not over them nor be straitened because of that which they plot.

# 3230

And they say: when will this Promise be fufilled if ye say sooth?

# 3231

Say thou: belike close behind you may be some of that which ye would hasten on.

# 3232

And verily thine Lord is full of grace for mankind, but most of them give not thanks.

# 3233

And verily thine Lord knoweth whatsoever their breasts conceal and whatsoever they make known.

# 3234

And naught there is hidden in the heaven or the earth but it is in a Manifest Book.

# 3235

Verily this Qur'an recounteth with truth unto the Children of Isra'il much of that wherein they differ.

# 3236

And verily it is a guidance and a mercy unto the believers.

# 3237

And verily thine Lord shall decide between them with His judgment, and He is the Mighty, the Knowing.

# 3238

Wherefore put thy trust in Allah; verily thou art on manifest truth.

# 3239

Verily thou canst not make the dead hear, nor canst thou make the deaf hear the call when they flee turning their backs.

# 3240

Nor canst thou lead the blind out of their error. Thou canst make none hear save these who believe in Our signs and who have submitted themselves.

# 3241

And when the word shall come to be fulfilled concerning them, We shall bring forth a beast of the earth speaking unto them, that the people have not of Our signs been convinced.

# 3242

And remind them of the Day whereon We shall Rather from every community a troop of those who belied Our signs, and they shall be held in order.

# 3243

Until when they shall have come, He Shall say: belied ye My signs when ye encompassed them not in Your knowledge; nay, what else was it that ye have been working?

# 3244

And the Word shall be fulfilled concerning them, because they did wrong, and they shall not be able to speak.

# 3245

Observe they not that We have appointed the night that they may repose therein, and the day sight-giving? Verily herein are signs unto a people who believe.

# 3246

And remind them of the Day whereon the trumpet shall be blown, and affrighted will be those who are in the heavens and the earth, save him whom Allah willeth. And all shall come unto Him, lowly.

# 3247

And thou shalt see the mountains thou deemest solid passing away as the passing away of the clouds: the handiwork of Allah Who hath perfected everything. Verily He is Aware of all that ye do.

# 3248

Whosoever will bring good shall have better than the worth thereof; and they from the terror of that Day will be secure.

# 3249

And whosoever will bring evil --their faces shall be cast down into the Fire. Are ye being requited aught save that which ye have been working?

# 3250

I am commanded only to worship the Lord of this city which He hath sanctified, -and His is every thing - and I am commanded to be of the Muslims;

# 3251

And that I should recite the Qur'an. And whosoever receiveth guidance, receiveth guidance for his own soul, and as for him who strayeth say thou: I am only of the warners.

# 3252

And say thou: All praise unto Allah! Anon He shall shew you His signs, so that ye will recognize them. And thy Lord is not negligent of that which ye Work.

# 3253

Ta. Sin. Mim.

# 3254

These are verses of the Manifest Book.

# 3255

WE recite unto thee of the story of Musa and Fir'awn with truth fora people who believe.

# 3256

Verily Fir'awn exalted himself in the earth and made the people thereof into sects, weakening a party among them, slaying their sons and letting their women live. Verify he was of the corrupters.

# 3257

And We desired that We should be gracious unto those who were weakened in the land, and We should make them leaders and We should make them the inheritors.

# 3258

And We should establish them in the earth, and We should let Fir'awn and Haman and their hostee from them that which they dreaded.

# 3259

And We inspired the mother of Musa, saying: suckle him, then when thou fearest for him, cast him into the river and fear not, nor grieve. Verily We are going to restore him unto thee, and shall make him one of the sent ones.

# 3260

And the household of Fir'awn took him Up, that he should become unto them an enemy and a grief. Verily Fir'awn and Haman and their hosts were sinners.

# 3261

And the wife of Fir'awn said: a comfort unto me and thee slay him not; belike he shall be of benefit to us or we might like him for a son; and they perceived not.

# 3262

And the heart of the mother of Musa became void, and she had wellnigh disclosed him, had We not fortified her heart, that she might remain one of the believers.

# 3263

And she said unto his sister: follow him. So she watched him from afar; and they perceived not.

# 3264

And We had aforetime forbidden foster-mothers for him; so she said: shall direct you unto a household who will rear him for you and who will be unto him good counsellors.

# 3265

So We restored him unto his mother that she might be comforted and not grieve, and that she might know that the promise of Allah is true. Yet most of them know not.

# 3266

And when he attained his full strength and became firm, We vouchsafed unto him wisdom and knowledge; and Thus We reward the well- doers.

# 3267

And he entered the City at a time of unawareness of the inhabitants thereof, and he found therein two men fighting, one being of his own party, and the other of his enemies. And he who was of his party, called him for help against him who was of his enemies. So Musa truck him with his fist, and put an end of him. He said: this is of the work of the satan, verily he is an enemy, a misleader manifest.

# 3268

He said: my Lord! verily I have wronged my soul, so wherefore forgive me. So He forgave him. Verily He! He is the Forgiving, the Owner of Mercy.

# 3269

He said: my Lord! whereas Thou hast favoured me, I shall nevermore be a supporter of the culprits.

# 3270

And in the morning he was in the city fearing and looking about, when lo! he who had asked his succour yesterday was crying out unto him. Musa said: verily thou art a seducer manifest.

# 3271

And when he sought to seize him who was an enemy unto them both, he said: O Musa wouldst thou slay me as thou didst slay a person yesterday? Thou seekest only to be a tyrant in the land, and thou seekest not to be of the reconcilers.

# 3272

And there came a man from the farthest part of the city, running; he said: O Musa! the chiefs are taking counsel together concerning thee, that they might slay thee; wherefore go forth thou, verily I am unto thee of the admonishers.

# 3273

So he went forth from thence fearing, looking abcut. He said: my Lord! deliver me from the wrong-doing people.

# 3274

And when he betook himself toward Madyan, he said: belike my Lord will guide me even way.

# 3275

And when he arrived at the water of Madyan, he found there a community of the people watering. And he found, apart from them, two women keeping back their flocks. He said: what aileth you twain! The twain said: we water not until the shepherds have driven away their flocks; and our father is a very old man.

# 3276

Then he watered their flocks for the twain. Then he turned aside into the shade, and said: my Lord! I verily of the good which Thou mayest send down for me I am needy.

# 3277

Then there came unto him one of the twain walking bashfully, and said: verily my father calleth for thee, that he may recompense thee with a hire for that thou didst water the flock for us. Then, when he was come unto him and had recounted unto him the whole story, he said: fear not; thou hast escaped from the wrong-doing people.

# 3278

And said one of the twain: O my father! hire him, for the best that thou canst hire is the strong and trustworthy one.

# 3279

He said: verily I wish I would marry thee to one of these two daughters of mine provided that thou hirest thyself to me for eight years. then if thou completest ten it will de of thine own accord, and I would not make it hard for thee; thou Shalt find me, Allah willing, of the righteous.

# 3280

Musa said: be that between me and thee: whichsoever of the two terms I shall fulfil, it shall be no harshness to me; and of that which we say Allah is Trustee.

# 3281

Then when Musa had fulfilled the term, and was journeying with his household, he saw a fire on the side of Tur, and said unto his household: bide ye; verily I see a fire afar, haply I may bring unto you tidings thereon, or a brand out: of the fire, haply ye may warm yourselves.

# 3282

Then when he was come thereto, he was called from the right side of the valley in the ground blest from the tree: Musa! verily I! I am Allah, the Lord of the worlds;

# 3283

And cast thou down thy staff. And when he saw it stirring, as though it were a serpent, he turned in flight and looked not back. O Musa! draw nigh, and fear not; thou art of the secure ones.

# 3284

Slip thy hand in thy bosom, it shall come forth white without hurt; and draw back thy arm unto thee for fear. These shall be two proofs from thy Lord unto Fir'awn and his chiefs; verily they have been a people given to transgression.

# 3285

He said: My Lord! verily I have slain a man among them and I fear they shall slay me.

# 3286

And My brother Harun! He is more eloquent than I in speech; wherefore send him with me as a support, to corroborate me; verily I fear that they shall belie me.

# 3287

He said: We shall indeed strengthen thine arm with thy brother, and We shall vouchsafe unto you authority, so that they shall not be able to come up to you. Go forth with Our signs! Ye twain and those who follow you, shall be the victors.

# 3288

Then when Musa came unto them with Our manifest signs, they said: this is naught but magic fabricated; and we heard not of this among our fathers of old.

# 3289

And Musa said: My Lord best knoweth him who bringeth guidance from before Him and him whose will be the happy end of the Abode. Verily the wrong-doers shall not thrive.

# 3290

And Fir'awn said: O chiefs! know not of a god for you except me. Wherefore light thou for me, O Haman! clay, and make me a lofty tower that I may ascend unto the God of Musa; and verily I imagine him to be of the liars.

# 3291

And he and his hosts were stiff-necked in the land without right, and imagined that before Us they would not be brought back.

# 3292

Wherefore We laid hold of him and his hosts and cast them into the sea. So behold thou what like hath been the end of the wrong- doers!

# 3293

And We made them leaders calling to the Fire, and on the Day of Resurrection they shall not be succoured.

# 3294

And We caused a curse to follow them in this world, and on the Day of Resurrection they shall be of the castaway.

# 3295

And assuredly We vouchsafed the the Scripture unto Musa after We had destroyed the generations of old: enlightenment unto mankind and a guidance and a mercy, that haply they might be admonished.

# 3296

And thou wast not on the western side when We decreed the affair unto Musa, and thou wast not of the witnesses.

# 3297

But We brought forth generations, and prolonged unto them was life; nor wast thou a dweller among the people of Madyan, reciting unto them Our revelations; but it is We who were to send.

# 3298

Nor wast thou beside the Tur when We called; but thou art sent as a mercy from thy Lord, that thou mayest warn a people unto whom no warner came before thee, that haply they might be admonished.

# 3299

And lest, if an affliction had afflicted them for that which their hands had sent before, they should have said: our Lord! wherefore sent not Thou an apostle unto us that we might have followed Thy revelations and been of the believers!

# 3300

Yet when the truth is come unto them from before Us, they say: wherefore hast he not been vouchsafed the like of that which was given unto Musa? Disbelieved they not in that which was given unto Musa aforetime? They say; two magics supporting each other. And they say: verily in all such things we are disbelievers.

# 3301

Say thou: then bring a Book from before Allah, that is better in guidance than these two shall follow it--if ye are truth- tellers.

# 3302

Then if they answer thee not, know thou that they only follow their own desires; and who is farther astray than he who followeth his desire without guidance from Allah? Verily Allah guideth not a wrong- doing people.

# 3303

And assuredly We have caused the Word to reach them in succession, that haply they may be admonished.

# 3304

Those unto whom We vouchsafed the Book before it, --they believe therein.

# 3305

And when it is rehearsed unto them they say: we believe therein: verily it is truth from our Lord: verily we have been even before it of those who submit themselves.

# 3306

These shall be vouchsafed their hire twice over, because they have persevered, and they repel evil with good, and expend of that wherewith We have provided them.

# 3307

And when they hear vain discourse they withdraw therefrom and say: unto US our works, and unto you your works; peace be unto you; we seek not the ignorant.

# 3308

Verily thou shalt not guide whomsoever thou lovest, but Allah shall guide whomsoever He will. And He knoweth best who are the guided.

# 3309

And they say: were we to follow the guidance with thee, We Shall be snatched away from our land. Have We not established for them an inviolable sanctuary whereunto fruits of every sort are brought: a provision from Our presence? But most of them know not.

# 3310

And how many a city have We destroyed that exulted in their living! And yonder are their dwellings which have not been inhabited after them unless for a little while; and verily We! We have been the inheritors.

# 3311

Nor was thy Lord to destroy the Cities, until He had raised up in their mother-city an apostle reciting unto them our revealations. Nor were We to destroy the cities unless the inhabitants thereof were wrong-doers.

# 3312

And whatsoever ye are vouchsafed is an enjoyment of the life of the world and an adornment thereof; and that which is with Allah is better and more lasting. Will ye not therefore reflect?

# 3313

Is he, then, whom We have promised an excellent promise which he is going to meet, like unto him whom We have suffered to enjoy awhile the enjoyment of the life of the world, then on the Day of Resurrection he shall be of those brought up!

# 3314

And on the Day whereon He shall call unto them and say: where are My associates whom ye were wont to assert?

# 3315

Those upon whom the sentence will be pronounced will say: our Lord these are they whom we seduced, we seduced them even as we our selves were seduced. We declare ourselves quit of them before Thee; not our selves they were wont to worship.

# 3316

And it shall be said: Call upon your associate-gods. And they shall call upon them, and they shall not answer them, and they shall behold the torment. Would that they had received the guidance!

# 3317

And on the Day whereon He shall call unto them and say: what answer gave ye to the sent ones?

# 3318

Bedimmed unto them shall be all excuses on that Day, wherefore they shall not be able to ask one of another.

# 3319

Howbeit, whosoever shall repent and believe, and work righteous works - belike he shall be of the thrivers.

# 3320

And thy lord createth whatsoever He listeth and chooseth; no Choice is to be far them. Hallowed be Allah and exalted above that which they associate!

# 3321

And thy Lord knoweth that which their breasts conceal and that which they make known.

# 3322

And He is Allah there is no god but he! His is all praise in the first and in the last, and His is the command, and unto Him ye shall be returned.

# 3323

Say thou: bethink ye, if Allah made night continuous for you till the Day of Resurrection, what god is there beside Allah, who would bring you light? Hearken ye not?

# 3324

Say thou: bethink ye, if Allah made day continuous for you till the Day of Resurrection, what god is there beside Allah, who would bring you night wherein ye have repose? Behold ye not?

# 3325

It is of His mercy He hath appointed for you night and day, that therein ye may have repose, and that ye may seek of His grace, and that haply ye may give thanks.

# 3326

And on the Day whereon He shall call unto them and say: where are My associates whom ye were wont to assert?

# 3327

We shall take out from every community a witness and We shall say: come forth with your proof; then they shall know that the truth was Allah's, and astray will go from them that which they were wont to fabricate.

# 3328

Verily Qarun was of the people of Musa; then he behaved arrogantly toward them. And We had vouchsafed him of the treasures whereof the keys would have weighed down a band of strong men. Recall what time his people said unto him: exult not; verily God loveth not the exultant.

# 3329

And seek the abode of the Hereafter with that which God hath vouchsafed thee, and forget not thy portion in the World, and be thou bounteous even as God hath been bounteous unto thee, and seek not corruption in the earth; verily Allah loveth not corrupters.

# 3330

He said: I have been vouchsafed this only because of the knowledge that is with me. Knew he not that Allah had destroyed before him, of the generations, those who were stronger than he in might and larger in respect of following? And the culprits shall not be questioned of their sins.

# 3331

Then he went forth unto his people in his pomp. Those who sought the life of the world said: would that we had the like of that which hath been vouchsafed unto Qarun! Verily he is the owner of a very great fortune.

# 3332

And those who had been vouchsafed the knowledge said: woe unto you! the reward of Allah is best for him who believeth and worketh righteously and none shall attain it except the patient.

# 3333

Then We sank the earth with him and his dwelling-place. And he had no host to defend him against Allah, nor was he of those who could defend themselves.

# 3334

And those who had wished for his place but yesterday began to say: Ah! Allah expandeth the provision for whomsoever He will of His bondmen and stinteth, had not Allah been gracious unto us, He would have sunk the earth with us also. Ah! the infidels thrive not.

# 3335

This is the abode of the Hereafter! We appoint it unto those who Seek not exaltation in the earth nor corruption; and the happy end is for the God-fearing.

# 3336

Whosoever bringeth good shall have better than it, and whosoever bringeth evil, then those who do ill works shall be rewarded only for that which they have been working.

# 3337

Verily He who hath imposed the Qur'an on thee Is surely about to bring thee back home. Say thou: my Lord knoweth best who bringeth guidance and who is in an error manifest.

# 3338

And thou wast not hoping that the Book would be Inspired in thee; but it is a mercy from thy Lord, so be thou not a supporter of the infidels.

# 3339

And let them not turn thee aside from the signs of Allah after they have been sent down unto thee. And call thou men unto thy Lord, and be thou not of the associaters.

# 3340

And invoke thou not any other god along with Allah. There is no god but he. Everything is perishable save His countenance His is the judgment, and unto Him ye shall be returned.

# 3341

Alif. Lam. Mim.

# 3342

Bethink men that they shall be left alone because they say: we believe; and that they shall not be tempted?

# 3343

And assuredly We have tempted those who were before them. So Allah will surely know those who are true and He will surely know the liars.

# 3344

Or bethink those who work ill deeds that they shall outstrip Us? lll do they judge!

# 3345

Whosoever hopeth for the meeting with Allah, then Allah's term is surely coming, and He is the Hearer, the Knower.

# 3346

And whosoever strive, striveth only for himself: verily Allah is Independent of the worlds.

# 3347

And whosoever believe and work righteous works, We shall purge away from them their ill-deeds and shall recompense them the best of that which they have been working.

# 3348

And We have enjoined on man kindness unto parents. But if the twain strive to make thee associate with Me that of which thou hast no knowledge, obey them not. Unto Me is your return, and I shall declare unto you that which ye have been working.

# 3349

And those who believe and work righteous works--We shall surely cause them enter among the righteous.

# 3350

Of mankind are some who say: we believe in Allah; then if they are afflicted in the way of Allah, they take the persecution of men even as the torment of Allah; and then, if succour cometh from thy Lord they say: verily we have been with you. Is not Allah the Best Knower of that which is in the breasts of the creatures?

# 3351

And surely Allah shall come to know those who believe, and surely He shall come to know the hypocrites.

# 3352

And those who disbelieve say unto those who believe: follow our way, and we shall surely bear your sins; whereas they shall not bear aught of their sins; verily they are the liars.

# 3353

And surely they shall bear their loads and other loads beside their own loads, and surely they shall be questioned on the Day of Resurrection concerning that which they were wont to fabricate.

# 3354

And assuredly We sent Nuh unto his people. Then he tarried among them for a thousand years, save tifty years; and then deluge overtook them, while they were wrong-doers.

# 3355

Then We delivered him and those in the ark, and made it a sign unto the worlds.

# 3356

And We sent Ibrahim. Recall what time he said unto his people: worship Allah, and fear Him; that is best for you if ye but knew.

# 3357

Ye only worship images instead of Allah, and ye create a falsehood. Verily those whom ye worship instead of Allah own no provision for you. Wherefore seek with Allah provision, and worship Him, and give thanks unto Him: unto Him ye shall be returned.

# 3358

And if ye belie me, then communities before you have belied: and upon the apostle is naught but a preaching manifest.

# 3359

Observe they not what wise Allah originateth creation? And then He shall restore it. Verily for Allah that is easy.

# 3360

Say thou: go about in the land and behold what wise He hath originated creation; and then Allah shall produce another production; verily Allah is over everything Potent.

# 3361

He shall torment whomsoever He Will, and shall show mercy unto whomsoever He Will, and unto Him ye shall be returned.

# 3362

And ye cannot escape in the earth nor in the heaven, and beside Allah there is for you no friend nor helper.

# 3363

Those who disbelieve in the signs of Allah and in their meeting with Him, they shall despair of My mercy, and they! theirs shall be a torment afflictive.

# 3364

Then the answer of his people was naught but that they said: slay him, or burn him. Then Allah delivered him from the fire; verily herein are signs for a people who believe.

# 3365

And he said: ye have taken images instead of Allah out of affection between you in the life of the world; but on the Day of Resurrection ye shall deny each other and ye shall curse each other, and your resort shall be the Fire, and ye shall have no helpers.

# 3366

And Lut believed in him. And he said: verily I am going to migrate to my Lord; verily He is the Mighty, the Wise.

# 3367

And We bestowed on him Is-haq and Y'aqub, and We placed among his posterity prophethood and the Book, and We vouchsafed unto him his hire in the World, and verily in the Hereafter he shall be of the righteous.

# 3368

And Lut: Recall what time he said unto his people: verily ye commit an indecency wherein none hath preceded you in the Worlds.

# 3369

Ye go in indeed unto males, and ye rob on the highway, and ye commit that which is disreputable in your assembly? Then the answer of his people was naught but that they said: bring thou God's torment on us if thou art of the truth-tellers.

# 3370

He said: my Lord! give me victory over the corrupt people.

# 3371

And when Our messengers came unto Ibrahim with the glad tidings, they said: verily we are about to destroy the inhabitants of that city: verily the inhabitants thereof have been wrong-doers.

# 3372

He said: verily Lut is therein. They said: we know better who is therein: we are to deliver him and his household, save his wife; she is to be of the lingerers.

# 3373

And when Our messengers came unto Lut, he was distressed on their account and felt straitened on their account. And they said: fear not, nor grieve: verily we are to deliver thee and thy household, save thy wife: she is to be of the lingerers.

# 3374

Verily we are about to bring down upon the inhabitants of this city a scourge from the heaven, for they have been transgressing.

# 3375

And assuredly We have left thereof manifest sign for a people who reflect.

# 3376

And unto Madyan We sent their brother, Shu'aib. He said: my people! worship Allah, and fear the Last Day, and commit not evil on the earth as corrupters.

# 3377

Then they belied him; wherefore an earthquake laid hold of them, and they lay in their dwellings, crouching.

# 3378

And the 'Aad and Thamud and of a surety their destruction is apparent unto you from their dwellings. The Satan made fairseeming their works unto them, and so kept them off from the path, while they were endued with sight.

# 3379

And Qarun and Fir'awn and Haman! And assuredly Musa came unto them with the evidences, yet they were stiff-necked in the land. And they could not outstrip Us.

# 3380

Wherefore each We laid hold of for his sin. Of them were some on whom We sent a violent wind; and of them were some - who were overtaken by a shout; and of them were some - with whom We sank the earth; and of them were some - whom We drowned. Allah was not such as to wrong them, but themselves they were wont to wrong.

# 3381

The likeness of those who take other patrons than Allah is as the likeness of the spider who taketh unto herself a house. And verily the frailest of all houses is the spider's house - if they but knew!

# 3382

Verily Allah knoweth whatsoever thing they invoke beside Him. And He is the Mighty, the Wise.

# 3383

And these similtudes! We propound them for mankind; and none understand them save men of knowledge.

# 3384

Allah hath created the heavens and the earth in truth; verily there in is a sign for the believers.

# 3385

Recite thou that which hath been revealed unto thee of the Book and establish thou the prayer; verily prayer preventeth man from indecency and that which is disreputable: and surely the remembrance of Allah is the greatest. And Allah knoweth that which ye perform.

# 3386

And dispute not with the people of the Book unless in the best manner, save with those of them who do wrong; and say: we believe in that which hath been sent down unto us and that which hath been sent down unto you: our God and your God is One; and unto Him we are submissive.

# 3387

And likewise have We sent down unto thee the Book; so those to whom We have vouchsafed the Book believe therein, and of those also some believe therein. And none gainsay Our signs save the infidels.

# 3388

And thou hast not been reciting any book before it, nor hast thou been writing it With thine right hand, for then might the followers of falsehood have doubted.

# 3389

Aye! it in itself manifest signs in the breasts of those who have been vouchsafed knowledge, and none gainsay Our signs save the wrong-doers.

# 3390

And they say: wherefore are not signs sent down upon him from his Lord! Say thou: signs are with Allah only, and I am but a manifest warner.

# 3391

Sufficeth it not for them that We have sent down unto thee the Book to be recited unto them? Verily herein is a mercy and an admonition for a people who believe.

# 3392

Say thou: Allah sufficeth for witness between me and you: He knoweth whatsoever is in the heavens and the earth. And they who believe in falsehood and disbelieve in Allah, those: they shall be the losers.

# 3393

And they ask thee to hasten on the torment. And had not there been a term appointed, the torment would surely have come unto them. And surely it shall come upon them of a sudden while they perceive not.

# 3394

They ask thee to hasten on the torment; and verily the Hell is about to encompass the infidels.

# 3395

On the Day whereon the torment shall cover them from above them and from underneath their feet, and He shall say: taste that which ye have been working!

# 3396

My bondmen, who believe! verily My earth is wide, so Me alone worship.

# 3397

Every soul shall taste of death; then unto Us ye shall be returned.

# 3398

And those who believe and work righteous works--them We shall surely settle in lofty dwellins of the; they shall be of the Garden whereunder the rivers flow; they shall be abiders therein. Excellent is the hire of the Workers.

# 3399

Who persevere and in their Lord trust!

# 3400

And how many a moving creature there is that beareth not its provision! Allah provideth for it and for you. And He is the Hearer, the Knower.

# 3401

And wert thou to ask them.: who hath created the heavens and the earth and subjected the sun and the moon they would surely say: Allah. How then are they deviating?

# 3402

Allah expandeth provision for whomsoever He Will of His bondmen and stinteth it for him. Verily Allah is of everything the Knower.

# 3403

And wert thou to ask them: who sendeth down water from the heaven, and therewith quickeneth the earth after the death thereof? they would surely say: Allah. Say thou: all praise unto Allah! Aye! most of them reflect not.

# 3404

And this life of the world is but: sport and play. Verily the home of the Hereafter--that is life indeed, if they but knew!

# 3405

So When they mount upon the ships they call on Allah making pure for Him the religion, then when He delivereth them safely on the land, lo! they associate

# 3406

So that they become ingrate for that which We have vouchsafed unto them, and that they enjoy themselves; but presently they shall know.

# 3407

Behold they not that We have appointed an inviolable sanctuary, while men are being snatched away round about them? in falsehood then believe they, and unto the favour of Allah will they be ingrate?

# 3408

And who is a greater wrong-doer than he who fabricateth a lie against Allah or belieth the truth when it cometh unto him Will there not be in the Hell an abiding-place for the infidels?

# 3409

And those who strive hard in us, We shall surely guide them in Our paths; verily Allah is with the welldoers.

# 3410

Alif. Lam Mim.

# 3411

The Byzantians have been overcome.

# 3412

In a nearer land; and they, after the overcoming of them, shall soon overcome.

# 3413

In some few years. Allah's is the command, before and after. And on that day the believers wiil rejoice.

# 3414

In Allah succour. He succoureth whomsoever He will, and He is the Mighty, the Merciful.

# 3415

This is Allah's promise; and Allah faileth not His promise. Yet most men know not.

# 3416

They know only the outward appearance of the life of the world, and they! of the Hereafter, they are neglecetful.

# 3417

Ponder they not in their minds: Allah hath not created the heavens and the earth and whatsoever is in-between the twain save with a purpose and for a term appointed? And verily many men in the meecing of their Lord are unbelievers.

# 3418

Have they not journeyed in the land and observed what wise hath been the end of those before them? They were stronger than they in power and they brake up the earth and they inhabited it with greater affluence than these have inhabited it, and their apostles came unto them with evidences. And Allah was not one to wrong them, but themselves they were wont to wrong.

# 3419

Then the end of those who committed evil was evil, for they belied the signs of Allah and they were wont to mock at them.

# 3420

Allah originateth the creation, then He shall restore it, then unto Him ye shall be returned.

# 3421

And on the day whereon the Hour arriveth, dumb-struck will be the culprits.

# 3422

And not from their associate-gods, there will be intercessors for them, and unto their associate-gods they will be unbelievers.

# 3423

On the Day whereon the Hour arriveth, that Day they shall be separated.

# 3424

Then as for those who believed and worked righteous works, they shall be in a meadow made happy.

# 3425

And as for those who disbelieved and belied Our signs and the meeting of the Hereafter--these to the torment shall be brought.

# 3426

So hallow Allah when ye enter the night and when ye enter the morning, --

# 3427

And His is all praise in the heavens and the earth! --and at the sun's decline and when ye enter the noon.

# 3428

He bringeth forth the living from the lifeless, and He bringeth forth the lifeless from the living, and He quickeneth the earth after the death thereof; and even so shall ye be brought forth.

# 3429

And of His signs is, that he created you of dust, then lo! ye are humankind spreading yourselves.

# 3430

And of His signs is, thathe created for you from yourselves pouses that ye may find repose in them, and He set between you affection and mercy. verily herein are signs for a people who ponder.

# 3431

And of His signs are the creation of the heavens and the earth, and the variation of your languages and complexions; verily herein are signs for men of knowledge.

# 3432

And of His signs are your sleeping by night and by day, and your seeking of His grace verily herein are signs for a people who hearken.

# 3433

And of His signs is that he sheweth you the lightning for a fear's and for a hope, and sendeth down from the heaven water, and therewith quickeneth the earth after the death thereof; verily herein are signs for a people who reflect.

# 3434

And of His signs is that the heaven and the earth stand fast by His command, and thereafter, when He calleth you, a call from the earth, lo! ye shall come forth.

# 3435

His is whosoever is in the heavens and the earth; all are unto Him obedient.

# 3436

And He it is who originateth the creation, then shall restore it, and it is easier for Him. His is the most exalted similitude in the heavens and in the earth; and He is the Mighty, the Wise.

# 3437

He propoundeth unto you a similitude taken from yourselves. Have you, from among those whom your right hands own, partners in that wherewith We have provided you, so that ye are equal in respect thereof, and ye fear them as ye fear each other? In this wise We detail the signs for a people who reflect.

# 3438

Aye! those who do wrong follow their own lusts without knowledge. Who, then, will guide him whom Allah hath sent astray? And for them there will be no helpers.

# 3439

Wherefore set thou thy face towards the true religion uprightly. And follow thou the constitution of Allah according to which He hath constituted mankind. No altering let there be in Allah's creation. That is the right religion, but most men know not.

# 3440

And remain turning penitently unto Him, and fear Him, and establish prayer, and be not of the associaters:

# 3441

Of those who split up their religion and became sects, each band in that which is with them exulting.

# 3442

And when hurt toucheth mankind they cry unto their Lord, turning penitently unto Him; then when He causeth them to taste of His mercy, lo! a part of them with their Lord associate others.

# 3443

So that they may be ungrateful for that which We have vouchsafed to them. So enjoy awhile; presently ye shall come to know.

# 3444

Or have We sent unto them any authority, so that it speaketh of that which they have been with Him associating?

# 3445

And when We cause mankind to taste of mercy they exult thereat; then if an evil befalleth them because of that which their hands have sent forth, lo! they despair.

# 3446

Behold they not that expandeth the provision for whomsoever He and stinteth? Verily herein are signs for a people who believe.

# 3447

So give thou unto the kinsman his due and unto the needy and unto the wayfarer. That is best for those who seek Allah's countenance; and those: they are the blissful ones.

# 3448

And whatsoever ye give in gift in order that it may increase among the substance of men increaseth not with Allah; and whatsoever ye give in poor-rate seeking the countenance of Allah-then those: they shall, have increase manifold.

# 3449

Allah is He Who created you and provided food for you, then He causeth you to die, and then He shall quicken you. Is there any of your associate-gods that doth aught of that? Hallowed and exalted be He above that which they associate!

# 3450

Corruptness hath appeared on land and sea because of that which men's hands have earned, so that he may make them taste a part of that which they have worked, in order that haply they may turn.

# 3451

Say thou: go forth in the land and behold what wise hath been the end of those of aforetime? And most of them were associaters.

# 3452

So set thy face toward the right religion before the Day cometh from which there is no averting, from Allah, on that Day they shall be sundered.

# 3453

Whosoever disbelieveth, on him is his infidelity, and those who work righteously are preparing for themselves.

# 3454

So that he shall recompense those who believe and work righteous works out of His grace; verily He loveth not the infidels.

# 3455

And of His signs is that he sendeth winds heralding rain and that he may make you taste of His mercy, and that the ships may sail at His command and that ye may seek His grace, and that haply ye may return thanks.

# 3456

And assuredly We sent apostles before thee unto their people. They brought them manifest signs. Then We took vengeance upon those who transgressed. And incumbent upon us was avengement of the believers.

# 3457

Allah is He Who sendeth the winds so that they raise a cloud and then spreadeth it along the heaven as He will and breaketh it into fragments, and thou beholdest the rain come forth from the intestines thereof. Then when He maketh it fall upon such of His bondmen as He will, lo! they rejoice.

# 3458

Even though before it was sent down upon them, before that, they were surely despairing.

# 3459

Look then at the effects of Allah's mercy: what wise He quickeneth the earth after the death thereof. Verily. He is the Quickener of the dead, and He is over every-thing potent.

# 3460

And if We send a wind, and they should see their tilth yellow, then they would thereafter remain disbelieving.

# 3461

So verily thou canst not make the dead hear, nor canst thou make the deaf hear the call when they turn away in flight.

# 3462

Nor canst thou be a guide to the blind out of their error; thou canst make none to hear save those who believe in Our signs, and who have surrendered themselves.

# 3463

Allah it is Who created you in weakness, then He appointed strength after weakness, then after strength appointed weakness and grey hair. He createth whatsoever He listeth: and He is Knower, the Potent.

# 3464

And on the Day whereon the Hour arriveth, the Culprits Will swear that they tarried not but an hour: Thus Were they ever deluded.

# 3465

And those who have been vouchsafed knowledge and belief will say: assuredly ye have tarried according to the decree of Allah until the Day of Upraising; so this is the Day of Upraising, but ye were wont not to know.

# 3466

On that Day the excusing of themselves will not profit those who did wrong, nor shall they be suffered to please Allah.

# 3467

And assuredly We have propounded for mankind, in this Qur'an, every kind of similitude; and if thou bringest unto them a sign, those who disbelieve are sure to say: ye are but followers of falsehood.

# 3468

In this wise Allah sealeth the hearts of those who believe not.

# 3469

So have thou patience; verily the promise of Allah is true. And let not make thee impatient those who have no conviction.

# 3470

Alif; Lam. Mim.

# 3471

These are verses of the Wise Book.

# 3472

A guidance and a mercy for the well-doers:

# 3473

Those who establish the prayer and give the poor-rate and of the Hereafter are convinced.

# 3474

These are on guidance from their Lord, and these! they are the blissful ones.

# 3475

And of mankind is one who purchaseth an idle discourse, that he may mislead from Allah's way without knowledge, and taketh it by way of mockery. These! for them shall be a torment ignominious.

# 3476

And when Our revelations are recited unto him he turneth away in his stiff-neckedness as though he heard them not: as though there was a deafness in his ears. So announce thou unto him a torment afflictive.

# 3477

Verily those who believe and work righteous works, theirs shall be Gardens of Delight.

# 3478

Therein they will be abiders: a true promise of Allah. And He is the Mighty, the Wise.

# 3479

He hath created the heavens that ye behold without pillars and hath cast Into the earth firm mountains lest it move away with you; and He hath scattered thereon every kind of animal. And We send down water from the heaven and We make grow every kind of goodly growth therein.

# 3480

This is the creation of Allah; shew that which those beside Him me have created. Aye! the wrong-doers are in error manifest.

# 3481

And assuredly We vouchsafed unto Luqman Wisdom, saying: give thanks unto Allah; and whosoever giveth thanks giveth thanks for his soul; and whosoever is unthankful--then verily Allah is self-sufficient, praiseworthy

# 3482

And recall what time Luqman said unto his son, while he was exhorting him: O my son! associate not aught with Allah; verily this associating is surely a tremendous wrong.

# 3483

And We have enjoined upon man concerning his parents--his mother beareth him in hardship upon hardship and his weaning is in two years: give thanks unto Me and unto thy parents; Unto Me is the goal.

# 3484

And if the twain strive with thee to make thee associate with Me that for which thou hast no knowledge, then obey them not. And bear them thou company in the world reputably, and follow thou the path of him who turneth penitently unto Me. Then unto Me is your return, and I shall declare unto you that which ye have been working.

# 3485

O my son! though it be but the weight of a grain of mustard-seed, and though it be in a rock or in the heavens, or in the earth, Allah shall bring it forth. Verily Allah is subtile, Aware.

# 3486

O My son! establish prayer and command that which is reputable and forbid iniquity, and bear patiently whatsoever may befall thee; verily that is of the firmness of affairs.

# 3487

And turn not away thy cheek from men nor walk on the earth stultingly, verily Allah loveth not any vainglorious boaster.

# 3488

And be modest in thy gait and lower thy voice; verily the most abominable of voices is the voice of the ass.

# 3489

Observe ye not that Allah hath subjected for you whatsoever is in the heavens and whatsoever is in the earth, and hath completed His favours on you outwardly and inwardly? And yet of mankind is one who disputeth concerning Allah without knowledge and with neither guidance nor a Book luminous.

# 3490

And when it is said unto them: follow that which Allah hath sent down, they say: nay! we shall follow that which we found our fathers upon. What! even though the Satan had been calling on them unto the torment of the Blaze.

# 3491

And whosoever submitteth his countenance unto Allah and he is a well doer, he hath of a surety lain hold of the firm cable. Unto Allah is the end of all affairs.

# 3492

And whosoever disbelieveth, let not his unbelief grieve thee. Unto Us is their return, and We shall declare unto them that which they have worked. Verily Allah is the Knower of that which is in the breasts.

# 3493

We let them enjoy for a while, and then We shall drive them to a torment rough.

# 3494

And wert thou to ask them: who hath created the heavens and the earth they will surely say: Allah. Say thou: All praise unto Allah! But most of them know not,

# 3495

Allah's is whatsoever is in the heavens and the earth. Verily Allah! He is the Self-sufficient, the Praiseworthy.

# 3496

And if whatever trees there are on the earth were pens, and the sea were ink with seven more seas to help it, the words of Allah could not be exhausted; verily Allah is Mighty, Wise.

# 3497

And your creation and your upraising are only as though of one soul; verily Allah is Hearing, Beholding.

# 3498

Observest thou not that Allah plungeth the night into the day and plungeth the day into the night and hath subjected the sun and the moon, each running unto an appointed term, and that Allah is of that which ye work Aware.

# 3499

That is because Allah! He is the Truth, because whatsoever they call upon beside Him is falsehood, and because He is the Exalted, the Grand.

# 3500

Observest thou not that the ship saileth in the sea by the favour of Allah that he may shew you of His signs? Verily therein are signs for every persevering, grateful heart.

# 3501

And when a wave covereth them like awnings, they call upon Allah, making their religion pure for Him. Then when He delivereth them on the land, only some of them keep to the middle course. And none gainsaith Our signssave each perfidious, ingrate one.

# 3502

Mankind! fear your Lord and dread a Day whereon no father shall atone for his son, and no son shall atone for his father at all. Verily the promise of Allahs is true. Let not the life of the world beguile you, and let not the great beguiler beguile you in regard to Allah.

# 3503

Verily Allah! with Him alone is the knowledge of the Hour, and He it is who sendeth down the rain and knoweth that which is in the wombs: and no person knoweth whatsoever it shall earn on the morrow, and a person knoweth not in whatsoever land he shall die. Verily Allah is Knowing, Aware.

# 3504

Alif. Lam Mim.

# 3505

Revelation of this Book, whereof there is no doubt, is from the Lord of the Worlds.

# 3506

Will they say: he hath fabricated it? Aye! it is the truth from thy Lord, that thou mayest warn therewith a people unto whom no warner came before thee, that haply they may be guided.

# 3507

Allah it is Who created the heavens and the earth and whatsoever is betwixt the twain in six days, and then He established Himself on the throne. No patron have ye nor an intercessor, besides Him. Will ye not then be admonished?

# 3508

He disposeth every affair from the heaven unto the earth; thereafter it shall ascend unto Him in a Day the measure whereof is one thousand years of that which ye compute.

# 3509

Such is the Knower of the unseen and the seen, the Mighty, the Merciful.

# 3510

Who hath made everything exceeding good which He hath created. And He originated the creation of man from clay;

# 3511

Then He made his progeny from an extract of water base.

# 3512

Then He fashioned him and breathed into him something of a spirit from Him; and He ordained for you hearing and sight and hearts. Little is the thanks ye return.

# 3513

And they say: when we are vanished in the earth, shall we then be raised in a new creation? Aye! in the meeting with their Lord they are disbelieving.

# 3514

Say thou: the angel of death who is set over you shall cause you to die, thereafter unto your Lord ye shall be returned.

# 3515

Couldst thou but see when the culprits shall hang their heads before their Lord, saying: our Lord! we have now seen and heard; so send us back; we shall work righteously, verily we are convinced.

# 3516

And had We listed surely We could have given every soul its guidance; but true must be the word from Me; I shall surely fill Hell with the Jinn and mankind together.

# 3517

So taste ye the sequel, for as much as ye forgat the meeting of this your day, verily We have forgotten you. Taste the torment abiding for that which ye have been working.

# 3518

They alone believe in Our revelations who, when they are reminded thereof, fall down prostrate and hallow the praise of their Lord, and they are not stiff-necked.

# 3519

Their sides leave off the couches calling upon their Lord in fear and in desire, and of that wherewith We have provided them they expend.

# 3520

No soul knoweth that which is kept hidden for them of perfect comfort as a recompense for that which they have been working.

# 3521

Shall he, therefore, who is a believer, be like unto him who is a transgressor? They are not equal.

# 3522

And as for those who believe and work rigteous works--for them are Gardens of Abode: an entertainment for that which they have been working.

# 3523

And as for those who transgress their abode is the Fire. So oft as they desire to get thereout, they shall be sent back thereto; and it will be said unto them: taste the torment of the Fire which ye were wont to belie.

# 3524

And surely We shall make them taste of the smaller torment prior to the greater torment, that haply they may yet return.

# 3525

And who is a greater wrong-doer than he who is reminded of His signs, then he turneth aside therefrom? Verily unto the culprits We are going to be Avenger.

# 3526

Assuredly We vouchsafed the Book Unto Musa; so be thou not in doubt in thy receiving it. And We appointed it to be a guidance unto the Children of Is'rail.

# 3527

And We appointed, from amongst them, leaders guiding others by Our command, when they had persevered, and of Our signs they were convinced.

# 3528

Verily thy Lord! He shall decide between them on the Day of Judgment concerning that wherein they have been differing.

# 3529

Hath this not guided them: how many generations We have destroyed before them amidst whose dwellings they walk? Verily therein are signs; will they not therefore hearken?

# 3530

Observe they not that We drive water unto a land bare, and bring forth therewith crops whereof their cattle and they themselves eat? Will they not therefore be enlightened?

# 3531

And they say: When will this Decision arrive if ye are truthtellers?

# 3532

Say thou: on the day of the Decision their belief will not profit those who have disbelieved; nor will they be respited.

# 3533

Wherefore turn aside thou from them, and await; verily they are awaiting.

# 3534

O Prophet! fear Allah and obey not the infidels and the hypocrites; verily Allah is ever Knowing, Wise.

# 3535

And follow that which is revealed to thee from thy Lord; verily Allah is of that which ye Work ever Aware.

# 3536

And put thy trust in Allah and Allah sufficeth as a Trustee.

# 3537

Allah hath not placed unto any man two hearts in his inside, nor hath He made your spouses whom ye declare to be as your mother's backs, your real mothers, nor hath He made your adopted sons your real sons. This is only your saying by your mouths, whereas Allah saith the truth and He guideth the way.

# 3538

Call them by their fathers: that will be most equitable in the sight of Allah. And if ye know not their fathers then they are your brethren in religion and your friends. And there is no fault upon you in regard to the mistake ye have made therein, but in regard to that which your hearts intend purposely. And Allah is ever Forgiving, Merciful.

# 3539

The Prophet is nigher unto the believers than themselves, and his wives are their mothers. And kinsmen are nigher one to another in the ordinance of Allah than other believers and the emigrants except that ye may act reputably unto your friends. This hath been written in the Book.

# 3540

And recall what time We took a bond from the prophets and from thee and from Nuh and Ibrahim and Musa and 'Isa son of Maryam. And We took from them a solemn bond;

# 3541

That he may question the truthful of their truth. And for the Infidels He hath gotten ready a torment afflictive.

# 3542

O Ye who believe! remember Allah's favour unto you when there came unto you hosts, and We sent against them a wind and hosts which ye saw not, and Allah was of that which ye were working a Beholder.

# 3543

When they came upon you from above you and from below you, and when eyes turned aside and hearts reached to the gullets, and of Allah ye were imagining various things.

# 3544

There were the believers proven and shaken with a mighty shaking

# 3545

And when the hypocrites and those in whose hearts is disease were saying: Allah and His apostle have promised us nought but delusion.

# 3546

And when a party of them said: O inhabitants of Yathrib! there is no place for you, so return. And a part of them asked leave of the Prophet, saying: verily our houses lie open; whereas they lay not open; they only wished to flee.

# 3547

And if they were to be entered upon from the sides thereof and they were asked to sedition, they would surely have committed it, and they would have tarried therein but slightly.

# 3548

And arruredly they had already covenanted with Allah that they would not turn their backs; verily the covenant with Allah must be questioned about.

# 3549

Say thou: flight shall not profit you if ye flee from death or slaughter, and lo! ye will not enjoy life except for a little.

# 3550

Say thou: who is there that will protect you from Allah if He intendeth to bring evil on you or intendeth mercy for you? And they shall not find for themselves, besides Allah, a patron or helper.

# 3551

Surely Allah knoweth those among you who hinder and those who say unto their brethren: come hither unto us; and they themselves come not to the battle save a ittle,

# 3552

Being niggardly toward you. Then when the fightin cometh, thou beholdest them look unto thee, their eyes rolling about, like the eyes of him who fainteth unto death. Then when the fighting is over they inveigh against you with sharp tongues, being niggardly of the good things. These have not believed; wherefore Allah hath made their works of none effect, and that is with Allah ever easy.

# 3553

They deem that the confederates have not yet departed; and if the confederates should come, they would fain to be in the desert with the wandering Arabs inquiring for tidings of you. And if they happen to be amongst you, they would fight but little.

# 3554

Assuredly there hath been for you: in the apostle of Allah an excellent pattern for him who hopeth in Allah and the Last Day and remembereth Allah much.

# 3555

And when the believers saw the confederates, they said: this is that which Allah and His apostle had promised us; and Allah and His apostle had spoken the truth. And it only increased them in belief and in self-surrender.

# 3556

Of the believers are men who have fulfilled that which they covenaned with Allah. Some of them have performed their vow, and some of them are waiting, so and they have not changed in the least.

# 3557

All this happened in order that Allah may recompense the truthful for their truth, and may punish the hypocrites if He would, or relent toward them. Verily Allah is ever Forgiving, Merciful.

# 3558

And Allah drave baCk those who disbelieved in their rage; they obtained no advantage, and Allah sufficed for the believers in the fighting; and Allah is ever Strong, Mighty.

# 3559

And He brought those of the people of the Book who backed them down from their fortresses and cast into their hearts terror; a part of them ye slew, and ye made captives a part.

# 3560

And He caused you to inherit their land and their houses and their riches, and land which ye have not yet trodden. And Allah is over everything ever potent.

# 3561

Prophet! say unto thy wives: if it be that ye seek the world's life and the adornment thereof, then come I shall make a provision for you and I shall release you with a handsome release.

# 3562

And if ye seek Allah and His apostle and the abode of the Hereafter, then verily Allah hath gotten ready for the well-doers among you a mighty hire.

# 3563

O Ye wives of the Prophet! whosoever of you shall commit a manifest Indecency, doubled for her would be the punishment twice over; and with Allah that is easy.

# 3564

And whosoever of you shall be obedient unto Allah and His apostle and shall work righteously, her hire We shall give her twice over, and We have gotten ready for her a generous provision.

# 3565

wives of the prophet! ye are not like any others of women, if ye are God-fearing. So be not soft in speech, lest one in whose heart is disease should be moved with desire, bun speak a reputable speech.

# 3566

And stay in Your houses. and display not yourselves! with the display of the times of former Paganism; and establish the prayer and give the poor-rate and obey Allah and His apostle. Allah only desireth to take away uncleanness from you, people of the house-hold, and to purify you with a thorough purification.

# 3567

And bear in mind that which is rehearsed in your homes of the revelations of Allah and the wisdom. Verily Allah is ever Subtile, Aware.

# 3568

Verily the Muslim men and Muslim women, and the believing men and the believing women, and the devout men and the devout women, and the men of veracity and the women of veracity, and the persevering men and the persevering women, and the men of humility and the women of humility and the almsgiving men and the almsgiving women, and the fasting men and the fasting women, and the men who guard their modesty and the women who guard their modesty, and the Allah-remembering men and the Allah remembering women: Allah hath gotten ready for them forgiveness and mighty hire.

# 3569

And it is not for a believing man or a believing woman, when Allah and His apostle have decreed an affair, that they should have any choice in their affair. And whosoever disobeyeth Allah and His apostle hath strayed with a manifest straying.

# 3570

And recall what time thou wast saying unto him on whom Allah had conferred favour and thou hadst conferred favour: keep thy wife to thyself and fear Allah; so and thou wast concealing in thy mind that which Allah was going to disclose, and thou wast fearing mankind, whereas Allah had a better right that Him thou shouldst fear. Then when Zaid had performed his purpose concerning her, We wedded her to thee, that there should be no blame for believers in respect of wives of their adopted sons, when they have performed their purpose concerning them. And the ordinance of Allah was to be fulfilled.

# 3571

No blame there is upon the Prophet in that which Allah hath decreed for him. That hath been Allah's dispensation with those who have passed away afore - and the ordinance of Allah hath been a destiny destined

# 3572

Those who preached the messages of Allah and feared Him, and feared none save Allah; and Allah sufficeth as a Reckoner.

# 3573

Muhammad is not the father of any of your males, but the apostle of Allah and the seal of the prophets; and Allah of everything is ever the Knower.

# 3574

O Ye who believe! remember Allah with much remembrance.

# 3575

And hallow Him morning and evening.

# 3576

He it is Who sendeth His benedictions to you and His angels also that he may bring you forth from darknessess into light; and unto the believers He is ever Merciful.

# 3577

Their greeting on the Day whereon they meet Him will be: peace. And He hath gotten ready for them a generous hire.

# 3578

Prophet! verily We have sent thee a witness and a bearer of glad tidings and a warner.

# 3579

And a summoner unto Allah by His command and an illuminating lamp.

# 3580

And bear thou unto the believers the glad tidings that theirs is from Allah a great grace.

# 3581

And obey thou not the infidels and the hypocrites, and heed not their annoyances, and trust in Allah; and Allah sufficeth as a Trustee.

# 3582

O Ye who believe! when ye marry believing women and then divorce them before ye have touched them, then there is no waiting-period from you incumbent on them that ye should count. So make provision for them and release them with a seemly release.

# 3583

O Prophet! verily We have allowed unto thee thy wives unto whom thou hast given their hires, and also those whomsoever thy right hand ownEth of those whomsoever Allah hath given thee as spoils of war, and the daughters of thy paternal uncle, and the daughters of thy paternal aunts, and the daughters of thy maternal uncle, and the daughters of thy maternal aunts, who migrated with thee, and any believing woman, when she offereth herself unto the Prophet if the Prophet desire to wed her --purely for thee, above the rest of the believers. Surely We know that which We have ordained unto them concerning their wives and those whom their right hands won: in order that there may be no blame upon thee: And Allah is ever Forgiving, Merciful.

# 3584

Thou myest put off such of them as thou wilt, and thou mayest take unto thee such of them as thou wilt; and whomsoever thou desirest if such as thou hadst set aside there is no blame upon thee. This is likelier to cool their eyes and not let them grieve and to keep them pleased with whatsoever thou shalt give every one of them. Allah knoweth that which is in your hearts. and Allah is ever Knowing, Forbearing.

# 3585

Women are not allowed unto thee henceforth, nor mayest thou change them for other wives although their beauty please thee, save those whom thy right hand shall own; and Allah is ever over everything a Watcher.

# 3586

O Ye who believe! enter not the houses of the Prophet, except when leave is given you, for a meal and at a time that ye will have to wait for its preparation; but when ye are invited, then enter, and when ye have eaten, then disperse, without lingering to enter into familiar discourse. Verily that incommodeth the Prophet, and he is shy of asking you to depart, bur Allah is not shy of the truth. And when ye ask of them aught, ask it of them from behind a curtain. That shall be purer for your hearts and for their hearts. And it is not lawful for you that ye should cause annoyance to the apostle of Allah, nor that ye should ever marry his wives after him; verily that in the sight of Allah shall be an enormity.

# 3587

Whether ye disclose a thing or conceal it, verily Allah is of everything ever Knower.

# 3588

It is no sin for them in respect to their fathers or their brothers, or their brothers sons, or their sisters sons, or their own women, or those whom their right hands own; and fear Allah; verily Allah is of everything ever a Witness.

# 3589

Verily Allah and His angels send their benedictions upon the prophet. O ye who believe! send your benedictions upon him and salute him with a goodly Salutation.

# 3590

Verily those who annoy Allah and His apostle, --Allah hath cursed them in the world and the Hereafter, and hath gotten ready for them a torment Ignominious.

# 3591

And those who annoy the believing men and the believing women, without their earning it, shall surely bear the guilt of calumny and manifest sin.

# 3592

O Prophet! say unto thy wives and thy daughters and women of the believers that they should let down upon them their wrapping- garments. That would be more likely to distinguish them so that they will not be affronted. And Allah is ever Forgiving, Merciful.

# 3593

If the hypocrites and those in whose hearts is a disease and the raisers of commotion in Madina desist not, We shall surely set thee up against them; thenceforth they shall not be suffered to neighbour thee therein except for a little while.

# 3594

Accursed; wherever found they shall be laid hold of and slain with a relentless slaughter.

# 3595

That hath been the dispensation of Allah with those who have passed away afore; and thou shalt not find in the dispensation of Allah any change.

# 3596

People ask thee ccncerning the Hour. Say thou: the knowledge there of is only with Allah: and what knowest thou! --belike the Hour is nigh.

# 3597

Verily Allah hath cursed the infidels, and hath gotten ready for them a Blaze.

# 3598

Abiders therein they shall be for ever, and they shall find neither a protecting friend nor a helper.

# 3599

On the Day whereon their faces shall be rolled in the Fire, they will say: Oh that we had obeyed Allah and had obeyed the apostle!

# 3600

And they will say: our Lord! verily we obeyed our chiefs and our great ones, and they led us astray from the way.

# 3601

Our Lord! give them double torment and curse them with a great curse.

# 3602

O Ye who believe! be not like unto those who annoyed Musa; but Allah cleared him of that which they said, and he was in the sight of Allah illustrious.

# 3603

O Ye who believe! fear Allah, and speak a straight speech.

# 3604

He WiLL rectify for you your works, and forgive you your sins. And Whosoever obeyeth Allah and His apostle, he hath indeed achieved a mighty achievement.

# 3605

Verily We! We offered the trust unto the heavens and the earth and the mountains, but they refused to bear it and shrank therefor. And man bore it; verily he was very iniquitous and very ignorant-

# 3606

So that Allah will torment the hypocritical men and the hypocritical women and the associators and the associatoresses and Allah will relent toward believing men and the believing women; and Allah is ever Forgiving, Merciful

# 3607

All praise Unto Allah whose is whatsoever is in the heavens and whatsoever is in the earth; and His is the praise in the Hereafter And He is the Wise, the Aware.

# 3608

He knoweth whatsoever penetrateth into the earth and whatsoever cometh forth therefrom and whatsoever descendeth from the heaven and whatsoever ascendeth thereto. And He is the Merciful, the Forgiving.

# 3609

Those who disbelieve say: the Hour will not come Unto us. Say thou: yea, by my Lord the Knower of the unseen, it will surely come Unto you. Not the weight of an atom escapeth Him in the heavens or in the earth; nor is there anything less than it nor greater but it is inscribed in a Luminous Book

# 3610

That He may recompense these who believed and worked righteous works. Those! theirs shall be forgiveness and a generous provision.

# 3611

And those who endeavoured to frustrate Our signs - those! theirs shall be a torment of afflictive calamity.

# 3612

And who have been vouchsafed knowledge beholding that the Book which hath been sent down Unto thee from thy Lord, - it is the truth and it guideth Unto the path of the Mighty, the Praiseworthy,

# 3613

And those who disbelieve say: shall we direct you toward a man declaring Unto you that when ye have become dispersed" with full dispersion, then ye will be raised Unto a new creation?

# 3614

Hath he fabricated a lie against Allah, or is therein him a madness? Nay, but those who disbelieve in the Hereafter are themselves in a torment and error far-reaching:

# 3615

Behold they not that which is before them and that which is behind them of the heaven and the earth If We will, We shall sink the earth with them or cause a fragment of the heaven to fall on them. Verily therein is a sign Unto every repentant bondman.

# 3616

And assuredly We vouchsafed Unto Da'ud grace from us,' and said: mountains! repeat Our praise with him; and also ye birds! And We softened for him the iron.

# 3617

Saying: make thou complete coats of mail, and rightly dispose the links, and work ye, righteously; verily I am of that which Ye work a Beholder.

# 3618

And Unto Sulaiman We subjected the wind, whereof the morning journeying was a month and the evening journeying a month. And We made a fount of brass to flow for him. And of the Jinn were some who worked before him by the Will Of his Lord. And whosoever of them swerved from Our command, him We shall cause to taste the torment of the Blaze.

# 3619

They worked for him whatsoever he pleased, of lofty halls and statues and basins like cisterns and cauldrons Standing firm. Work ye, house of Da'ud! with thanksgiving; few of My bondmen are thankful.

# 3620

Then when We decreed death for him, naught discovered his death to them' save a moving creature of the earth which gnawed away his staff. Then when he fell, the Jinn clearly perceived that, if they had known the unseen they would not have tarried in the ignominious torment.

# 3621

Assuredly there was for Saba a sign in their own dwelling- place: two gardens on the right hand and on the left. And it was said Unto them: eat ye of the provision of your Lord and give thanks Unto Him: a fair land' and a forgiving Lord.

# 3622

But they turned away. Wherefore We sent upon them the inundation of the dam and We exchanged their two gardens for two gardens bearing bitter fruit, and tamarisk. And some few lote-trees.

# 3623

In this wise We requited them for they were ungrateful. And We requite not thus any save the ungrateful infidels.

# 3624

And We had placed between them and the cities" which We had blest cities easy to be seen, and We had made the stages of journey between them easy:" travel in them nights and days secure.

# 3625

Then they said: Our Lord make the distance between our journeys longer. And they wronged themselves. Wherefore We made them by words and dispersed them with a total dispersion. Verily herein are signs for every persevering, grateful persons.

# 3626

And assuredly Iblis found his conjecture true concerning them; and they followed him all save a party of the believers.

# 3627

And he hath no authority over them except that We would know him who believeth in the Hereafter from him who is in doubt thereof. And thy Lord is over everything a Warden.

# 3628

Say thou: call upon those whom ye assert beside Allah. They own not an atom's weight either in the heavens or in the earth, nor have they any partnership in either, nor is there for Him from among them any supporter.

# 3629

lntercession with Him profiteth not save the intercession of him whom He giveth leave. They hold their peace until when fright is taken off from their hearts, they say: What is it that your Lord hath said? They say: the very truth. And He is the Exalted, the Great.

# 3630

Say thou: who provideth food for you from the heavens and the earth? Say thou: Allah; verily either we or ye are on the guidance or in error manifest.

# 3631

Say thou: ye will not be questioned about that which we have committed, nor shall we be questioned about that which ye work.

# 3632

Say thou: our Lord shall assemble us together, then He shall judge between us with truth; and He is the Great Judge, the Knower.

# 3633

Say thou: show me those whom ye have joined with Him as associates. By no means! Aye! He is Allah, the Mighty, the Wise.

# 3634

And We have not sent thee save as a bearer of glad tidings and a warner Unto all mankind; but most of man kind know not.

# 3635

And they say: when is this promise to be fulfilled if ye say sooth?

# 3636

Say thou: the appointment to you is for a Day which ye cannot put back for one hour nor can ye anticipate.

# 3637

And those who disbelieve say: we shall by no means believe in this Qur'an nor in that which hath been before it. Would that thou couldst see when the wrong-doers shall be made to stand before their Lord! They shall cast back the word one to another; those who were deemed weak will say Unto those who were stiff-necked: had it not been for you, surely we should have been believers.

# 3638

Those who were stiff-necked will say Unto those who were deemed weak: was it we who prevented you from the guidance after it had come Unto you? Aye! ye have been guilty yourselves.

# 3639

And those who were deemed weak will say Unto those who were stiff necked: aye, it was your plotting by night and by day, When ye were commanding us that we should disbelieve in Allah and set up peers Unto Him. And they Will keep secret their shame when they behold the torment. And We shall place shackles on the necks of those who disbelieved. They shall be requited not save according to that which they had been working.

# 3640

And We sent not a warner Unto a town but the affluent thereof said:' verily in that wherewith ye have been sent we are disbelievers.

# 3641

And they said: we are more numerous in riches and children, and we are not going to be tormented.

# 3642

Say thou: verily my Lord expandeth the provision for whomsoever He will and stinteth it; but most of mankind know not.

# 3643

And it is not your riches nor your children that shall draw you nigh Unto us with a near approach, but whoso ever believeth and worketh righteously- then those! theirs shall be a twofold meed for that which they will have worked, and they will be in upper apartments secure.

# 3644

And those who endeavour to frustrate Our signs, Unto the torment they will be brought.

# 3645

Say thou: verily my Lord expandeth the provision for whomsoever He listeth of His bondmen, and stinteth it for him. And whatsoever ye expend of aught He shall replace it. And He is the Best of Providers.

# 3646

And on the Day whereon He gathereth them together, then He will say Unto the angels: was it ye that these were wont to worship?

# 3647

They will say: hallowed be Thou! Thou art our protecting friend, not they; Aye! they have been worshipping the jinn; In them most of them were believers.

# 3648

To-day ye own not for one another either benefit or hurt. And We shall say Unto those who did wrong: taste the torment of the Fire which ye were wont to belie.

# 3649

And when there are rehearsed Unto them Our plain revelations, they this messenger is naught but as a man who seeketh to prevent you from that which your fathers have been worshipping. And they say: this message is naught but a fraud fabricated. And those who disbelieve say of the truth When it is come Unto them: this is naught but manifest magic.

# 3650

And We had not vouchsafed Unto them Books they should have been studying, nor had We sent Unto them, before thee, any warner.

# 3651

And those before them belied; and these have not arrived Unto a tithe of that which We vouchsafed Unto them. But they belied My apostles. So how terrible was My disapproval

# 3652

Say thou: I but exhort you Unto one thing: that ye stand, for Allah's sake, by twos and singly, and then ponder; in your companion there is no madness; he is naught but a warner Unto you preceding a torment severe.

# 3653

Say thou: whatsoever hire might have asked of you is yours; my hire is with Allah only. And He is of everything a Witness.

# 3654

Say thou: verily my Lord hurleth the truth: the Knower of things hidden.

# 3655

Say thou: the truth is come, and falsehood shall neither originate nor be restored."

# 3656

Say thou: if ever I go astray, I shall stray only against myself, and if I remain guided it is because of that which my Lord hath revealed Unto me. Verily He is Hearing, Nigh.

# 3657

And couldst thou see the time when they shall be terrified! Then there shall be no escaping, and they shall be laid hold of from a place quite nigh.

# 3658

And then they will say: we believe therein. But whence can there be the attainment of faith from a place so afar.

# 3659

Whereas they disbelieved therein afore, and conjectured about the unseen from a place so afar.

# 3660

And they will be shut off from that which they will eagerly desire, as shall be done with the likes of them of yore. Verily they have been in doubt perplexing.

# 3661

All praise Unto Allah, the Creator Of the heavens and the earth, the Appointer of the angels as His messengers, with wings of twos and threes and fours. He addeth in creation what soever He listeth Verily Allah is over everything Potent.

# 3662

Whatsoever of mercy Allah may grant Unto mankind none there is to withhold it; and whatsoever He may with hold none there is to release it thereafter. And He is the Mighty, the Wise.

# 3663

O mankind! remember the favour of Allah toward you. Is there any Creator other than Allah who provideth for you from the heaven and the earth? There is no god but He. Wither then are ye deviating?

# 3664

And if they belie thee, then surely apostles have been belied before thee. And Unto Allah shall be brought back all affairs.

# 3665

O mankind! verily the promise of Allah is true. So let not the life of the world beguile you, and with respect to Allah let not beguile you the great be guiler.

# 3666

Verily the Satan is an enemy Unto you, wherefore hold him for an enemy; he only calleth his confederates that they become of the fellows of the Blaze.

# 3667

Those who disbelieve - theirs shall be a torment severe; and those who believe and work righteous works, - theirs shall be forgiveness and a great hire.

# 3668

Is he, then, whose evil work hath been made fair-seeming unto him, so that he deemeth it good, be as he who rightly perceiveth the truth? Verily Allah sendeth astray whomsoever He listeth, and guideth whomsoever He listeth; so let not thine soul expire after them in sighings; verily Allah is the Knower of that which they perform.

# 3669

And it is Allah Who sendeth the winds, and they raise a cloud; then We drive it unto a dead land and We quicken thereby the earth after the death thereof. Even so shall be the Resurrection.

# 3670

Whosoever desireth glory, then all glory is Allah's; unto Him mount up the goodly words; and the righteous works exalteth it. And those who plot evils,--theirs shall be a torment severe; and the plotting of those!--it shall perish.

# 3671

And Allah created you of dust, then of a seed; then He made you pairs. No female beareth or bringeth forth but with His knowledge. And no aged man growth old, nor is aught diminished of his life, but it is in a Book; verily for Allah that is easy.

# 3672

And the two seas are not alike: this, sweet, thirst- quenching, pleasant to drink; and that, saltish and bitter. And yet from each ye eat flesh fresh and bring forth the ornaments that ye wear. And thou seest therein ships cleaving the water, that ye may seek of His graCe, and that haply ye may give thanks.

# 3673

He plungeth the night into the day and He plungeth the day into the night, and He hath subjected the sun and moon, each running till an appointed term. Such is Allah, your Lord; His is the dominion; and those whom ye call on besides Him own not even the husk of a date-stone.

# 3674

If ye call Unto them, they hear not your calling, and even if they heard, they could not answer you. On the Day of Judgment they will deny your associating. And none can declare Unto thee the truth like Him who is Aware.

# 3675

O mankind! ye are needers Unto Allah, and Allah! He is the Selfsufficient, the Praiseworthy

# 3676

If He will, He can take you away and bring about a new creation."

# 3677

And with Allah that shall not be hard.

# 3678

And a bearer of burthen will not bear another's burthen, and if one heavy-laden calleth for his load, naught thereof will be borne although he be of kin. Thou canst warn only those who fear their Lord, unseen, and establish prayer. And whosoever becometh clean becometh clean only for himself; and Unto Allah is the return.

# 3679

Not alike are the blind and the seeing.

# 3680

Neither darknesses and light,

# 3681

\- Nor the shade and the sun's heat.

# 3682

Nor alike are the living and the dead. Verily Allah maketh whomsoever He listeth to hear and thou canst not make them hear who are in the graves.

# 3683

Thou art naught but a warner.

# 3684

Verily We! We have sent thee with the truth, as a bearer of glad tidings and as a warner; and there is not a community but there hath passed among them a warner.

# 3685

And if they belie thee, then surely those before them have also belied. Their apostles came Unto them with evidences and scriptures and a Book luminous.

# 3686

Then I took hold of those who disbelieved. So how terrible was My disapproval!

# 3687

Beholdest thou not that Allah sendeth down water from the heaven, and then We thereby bring fruit of diverse colours? And in the mountains are steaks white and red, of diverse colours, and also intensely black.

# 3688

And of men and beasts and cattle, likewise of diverse colours. Those only of His bondmen who have knowledge fear Allah Verily Allahis the Mighty, the Forgiving.

# 3689

Verily those Who read the book of Allah and establish prayer and expend of that wherewith We have provided them, secretly and in open, hope for a merchandise that shall not perish.

# 3690

That He may pay them their hires in full and increase Unto them of His grace; verily, He is Forgiving, Appreciative.

# 3691

And that which We have revealed Unto thee of the Book - it is the very truth confirming that which hath been before it; verily, Allah is Unto His servants Aware, Beholding.

# 3692

Thereafter We made inheritors of the book those whom We chose of Our bondmen. Then of them are some who wrong themselves, and of them are some who keep the middle way, and of them are some who, by Allah's leave, go ahead in virtues. That! that is a great grace.

# 3693

Gardens Everlasting! these they Shall enter, wearing therein bracelets of gold and pearls, and their raiment therein shall be of silk.

# 3694

And they will Say: all praise Unto Allah who hath taken away grief from us. verily, our Lord is Forgiving, Appreciative.

# 3695

Who hath, through His grace, lodged us in the abode of permanence, wherein there will not touch us tall, and wherein there will not touch us weariness.

# 3696

And those who disbelieve-for them shall be Hell-Fire. It shall not be decreed to them that they should die, nor shall the torment thereof be lightened for them. Thus We requite Every ingrate.

# 3697

And they will be shouting therein: our Lord! take us out; we shall work righteously, not that which we have been working. Gave We not you lives long enough so that whosoever would receive admonition could receive admonition therein? and there came Unto you a warner; taste therefore and for the wrong-doers there will be no helper.

# 3698

Verily Allah is the Knower of the unseen of the heavens and the earth. Verily, He is the Knower of that which is in the breasts.

# 3699

He it is who hath made you successors in the earth. So whosoever disbelieveth, on him will befall his infidelity. And for the infidels their infidelity increaseth with their Lord naught save abhorence. And for the infidels their infidelity increastth naught save loss.

# 3700

Say thou: what bethink ye of your associate-gods upon which ye call besides Allah? Show me whatsoever they have created of the earth. Or, have they7 any partnership in the heavens? Or have We vouchsafed to them a Book so that they stand on an evidence therefrom? Nay! the wrong-doers promise each other only delusions.

# 3701

Verily Allah withholdeth the heavens and the earth lest they cease; and should they cease, not any one could withhold them after Him. Verily He is ever Forbearing, Forgiving.

# 3702

And\`they swear by God with a most solemn oath, that if there came a warnet Unto them, they would surely be better guided than any of the other communities. Then when there did come Unto them a warner, it increased in them naught save aversion,-

# 3703

Through their stiff-neckedness in the land, And the plotting of evil only infoldeth the authors thereof. Wait they, then, but the dispensation of the ancients? And thou wilt not find in dispensation of Allah a change, nor wilt thou find in dispensation of Allah a turning off

# 3704

Have they not travelled on the earth, so that they might see what wise hath been the end of those before them. although they were stronger than these in Power? And Allah is not such that aught in the heavens and the earth can frustrate him. Verily, He is ever the Knowing, the potent.

# 3705

Were Allah to take mankind to task for that which they earn, He would not leave a moving creature on the back thereof; but He putteth them off until a term appointed; then when their term cometh, - then, verily Allah is ever of His bondmen a Beholder.

# 3706

Ya-Sin.

# 3707

By the Qur'an full of wisdom.

# 3708

Verily thou art of the sent ones,

# 3709

upon the straight path.

# 3710

This is a revelation of the Mighty, the Merciful.

# 3711

That thou mayest warn a people whose fathers were not warned; so they are negligent.

# 3712

Assuredly the word hath been justified against most of them, wherefore they shall not believe.

# 3713

Verily We have placed on their necks shackles which are up to the chins; so that their heads are forced up.

# 3714

And We have placed before them a barrier and behind them a barrier, so We have covered them, so that they see not.

# 3715

And it is alike Unto them, whather thou warnest them or warnest them not; they shall not believe.

# 3716

Thou canst warn only him who followeth the admonition and feareth the Compassionate, unseen. So bear thou Unto him the glad tidings of forgiveness and a generous hire.

# 3717

Verily We! We shall guicken the dead. And We write down that which they send before and their footsteps. And everything We have counted up in a Book luminous.

# 3718

And propound thou Unto them the similitude of the inhabitants of a town, When there came thereto the sent ones;

# 3719

What time We sent Unto them two, then they belied the twain, wherefore We strengthened them with a third, and they said: verily we are Unto you the sent ones.

# 3720

They said: ye are but human beings like ourselves; the Compassionate hath not sent down aught; ye are only lying.

# 3721

They said: our Lord knoweth that we are surely Unto you the sent ones.

# 3722

And on us is naught but manifest preaching.

# 3723

They said: verily we augur ill of you; if ye desist not, we shall surely stone you, and there will befall you from us a torment afflictive.

# 3724

They said: your evil augury be with you. Call ye it an ill- luck because ye are admonished! Aye! ye are a people extravagant.

# 3725

And there came from the farthest part of the town a man running. He said; O my people! follow the sent ones.

# 3726

Follow those who ask not of you any hire, and who are rightly guided.

# 3727

And what aileth me that I should not worship Him who hath created me, and Unto whom ye shall be returned.

# 3728

Shall I take beside Him gods when, if the Compassionate should intend me any harm, their intercession will avail me not at all, nor would they save me?

# 3729

Verily then I should be in error manifest.

# 3730

Verily I believe now in your Lord; so hearken Unto me."

# 3731

It was said: enter thou the Garden. He said: would that my people knew.

# 3732

That my Lord hath forgiven me, and hath made me of the honoured ones.

# 3733

And We sent not against his people after him a host from heaven, nor have We been sending down any such.

# 3734

It was but one shout, and lo! they were extinct.

# 3735

Ah the misery of the bondmen! there cometh not: Unto them an apostle but him they have been mocking.

# 3736

Behold they not how many We have destroyed before them of the generations! verily Unto them they shall not return.

# 3737

And surely all, every one of them, shall be brought before us.

# 3738

And a sign Unto them is the dead land. We quicken it and therecut We bring forth grain, so that thereof they eat.

# 3739

And We place therein gardens of the date-palms and vines; and We therein cause to gush forth springs.

# 3740

That they may eat of the fruit thereof; and their hands worked it not. Will they not, therefore, give thanks?

# 3741

Hallowed be He who hath created all the pairs of that which the earth groweth, and of themselves and of that which they know not!

# 3742

And a sign Unto them is the night. We draw off the day therefrom, and lo! they are darkened.

# 3743

And the sun runneth to its appointed term: that is the disposition of the Mighty, the Knowing."

# 3744

And the moon! For it We have decreed mansions till it reverteth like the old branch of a palm-tree.

# 3745

It is not permitted to the sun that it should overtake the moon, nor can the night outstrip the day: each in an orbit, they float.

# 3746

And a sign Unto them is that We bear their offspring in a laden ship.

# 3747

And We have created for them of the like thereUnto whereon they ride.

# 3748

And if We list, We shall drown them, and there will be no shout for them, nor will they be saved.

# 3749

unless it be a mercy from us, and as an enjoyment for a season.

# 3750

And when it is said Unto them: fear that which is before you and that which is behind you, that haply ye may find mercy, they withdraw.

# 3751

And not a sign cometh Unto them of the signs of their Lord, but they are ever backsliders therefrom.

# 3752

And when it is said Unto them: expend of that wherewith Allah hath provided you, those who disbelieve say Unto those who believe: shall we feed those whom God Himself would have fed, if He listed? Ye are in naught else than error manifest.

# 3753

And they say: when will this promise be fulfilled if ye say sooth?

# 3754

They await not but one shout, which shall lay hold of them while they are yet wrangling.

# 3755

And they will not be able to make a disposition, nor to their family they return.

# 3756

And the trumpet shall be blown, and lo! from the tombs Unto their Lord they shall be hastening.

# 3757

They will say: Ah woe Unto us! who hath roused us from our sleeping-place? This is that which the Compassionate had promised, and truly spake the sent ones.

# 3758

It shall be but one shout; and lo! they shall all be brought together before us.

# 3759

To-day no soul will be wronged at all; nor shall ye be requited but for that which ye have been working.

# 3760

Verily the fellows of the Garden to-day shall be happily employed.

# 3761

They and their spouses, in shade on couches shall be reclining.

# 3762

Theirs shall be fruit therein and theirs shall be whatsoever they ask for.

# 3763

Peace shall be the word from the Lord Merciful.

# 3764

And separate yourselves this Day, O ye culprits!

# 3765

Enjoined I not on you, ye children of Adam, that ye shall not worship the Satan - verily he is Unto you manifest foe.

# 3766

And that: ye shall worship Me; this is the straight path?

# 3767

And yet assuredly he hath led astray of you a great multitude. Wherefore reflect ye not?

# 3768

Yonder is Hell, which ye were promised.

# 3769

Roast therein To-day for that ye have been disbelieving.

# 3770

To-day We shall seal upon their mouths, and their hands will speak Unto us, and their feet will bear witness of that which they have been earning.

# 3771

And if We listed, surely We should wipe out their eyes so that they would struggle for the way how then would they see?

# 3772

And if We listed, surely We should transform them in their places, so that they would be able neither to go forward nor to return

# 3773

And whomsoever We grant long life, We reverse him in creation. Reflect then they not?

# 3774

And We have not taught him poetry, nor it befitteth him. This is but an admonition and a Recital luminous:

# 3775

In order that it may warn him who is alive, and that the sentence may be justified on the infidels.

# 3776

Observe they not that We have created for them, of that which Our hands have worked, cattle: so that they are their owners.

# 3777

And We have subdued them Unto them, so that some of them they have for riding and on some of them they feed?

# 3778

And they have therefrom other benefits and drinks. Will they not then give thanks?

# 3779

And they have taken beside Allah gods, hoping that haply they may be succoured.

# 3780

They are not able to give them succour; whereas they shall be against them host brought forward.

# 3781

So let not their speech grieve thee. Verily We! We know whatsoever they keep secret and whatsoever they make known.

# 3782

Beholdest not man that We have created him from a sperm? Yet lo! he is a manifest disputer?

# 3783

And he propoundeth for us a similitude, and forgetteth his creation, He saith: who shall quicken the bones when they are decayed?

# 3784

Say thou:" He shall quicken them Who brought them forth for the first time, and He is of every kind of creation the Knower!

# 3785

Who giveth you out of the green tree fire, and lo! ye kindle therewith.

# 3786

Is not He who created the heavens and the earth able to create the like of these? Yea! He is the Supreme Creator, the Knower.

# 3787

His affair, when He intendeth a thing, is only that He saith Unto it: be, and it becometh.

# 3788

Wherefore hallowed be He in whose hand is the governance of everything, and Unto whom ye shall be returned.

# 3789

By the angels ranged in ranks.

# 3790

By the angels driving away.

# 3791

By the angels reciting the praise.

# 3792

Verily your God is One.

# 3793

Lord of the heavens and the earth and whatsoever is in- between the twain, and Lord of the easts.

# 3794

Verily We! We have adorned the nearest heaven with an adornment: the stars.

# 3795

And have placed therein a guard against any Satan froward.

# 3796

They cannot listen to the exalted assembly, and they are darted at from every side.

# 3797

With a driving fusillade, and theirs shall be a torment perpetual;

# 3798

Except him who snatcheth away a word by stealth, and him then pursueth a glowing flame.

# 3799

Ask them thou: are they stronger in structure or those others whom We have created? Verily We! We have created them of a sticky clay.

# 3800

Aye! thou marvellest, and they scoff.

# 3801

And when they are admonished, they receive not admcnition.

# 3802

And when they behold a sign, they turn to scoffing.

# 3803

And they say: this Qur'an is naught but magic manifest.

# 3804

When we have become dead and have become dust and bones, shall we then verily be raised?

# 3805

And also our forefathers?

# 3806

Say thou: and verily ye; shall then be despicable.

# 3807

It shall be but one shout, lo! they shall be staring.

# 3808

And they will say: Ah! woe be Unto us! this is the Day of Requital.

# 3809

This is the Day of Judgment which ye were wont to belie.

# 3810

Gather together those who did wrong and their comrades and that which they were wont to worship

# 3811

Beside Allah, and lead them on to the path of the Flaming Fire.

# 3812

And stop them; verily they are to be questioned:

# 3813

What aileth you that ye succour not one another?

# 3814

Nay! on that Day they will be entirely submissive.

# 3815

And they will advance toward each other mutually questioning.

# 3816

They will say: verily ye! ye were wont to come Unto us Imposing.

# 3817

They will say: nay! ye yourselves were not believers.

# 3818

And we had over you no authority, but ye were a people exorbitant.

# 3819

So on us hath been justified the sentence of our Lord: verily we are to taste.

# 3820

We seduced you astray; verily we were ourselves the seduced ones.

# 3821

So verily on that Day they all in the torment will be sharers.

# 3822

Verily We! in this wise We deal with the culprits.

# 3823

Verily when it was said Unto them: there is no god but Allah, they ever grew stiff-necked.

# 3824

And they said: are we going to abandon our gods on account of a Poet distracted?

# 3825

Aye! he hath come with the truth, and he confesseth to the sent ones.

# 3826

Verily ye are going to taste a torment afflictive.

# 3827

And ye shall be required not except for that which ye have been doing;

# 3828

But the bondmen of Allah, the sincere ones -

# 3829

Those! theirs shall be a provision known:

# 3830

Fruits! And they shall be honoured.

# 3831

In Gardens of Delight.

# 3832

On couches, facing one another.

# 3833

Round shall be passed a cup Unto them filled with limpid drink:

# 3834

White, a pleasure Unto the drinkers.

# 3835

No headiness there shall be therein, nor shall they be therewith Inebriated.

# 3836

And with them shall be damsels of refraining looks, large- eyed

# 3837

As though they were eggs hidden.

# 3838

Then they will advance Unto each other, mutually questioning.

# 3839

And a speaker from among them will say: verily there was Unto me a mate.

# 3840

Who said: art thou of those who confess to the doctrine of Resurrection:

# 3841

When we are dead and have become dust and bones, are we indeed going to be requited?

# 3842

Allah will say: will ye look down?

# 3843

Then he will look down and see him in the midst of the Flaming Fire.

# 3844

And he will say: by Allah, thou hadst wellnigh causedest me to perish.

# 3845

And but for the favourcf my lord, I should have been of those brought forward.

# 3846

Are we not then to die

# 3847

Save our first death, and are we not to be tormented?

# 3848

Verily this! that is the supreme achievement.

# 3849

For the like of this, then, let the workers work.

# 3850

Is this better as an entertainment or the tree of Zaqqum?

# 3851

Verily We! We have made it a temptation for the wrong- doers.

# 3852

Verily it is a tree that springeth forth in the bottom of Flaming Fire.

# 3853

The fruit thereof is as though the hoods of the serpents.

# 3854

And verily they must eat thereof and fill their bellies therewith.

# 3855

And thereafter verily they shall have thereon a draught of balling water.

# 3856

And thereafter verily their return is Unto the Flaming Fire.

# 3857

Verily they found their fathers gone astray.

# 3858

So they in their footsteps are rushing.

# 3859

And assuredly there went stray before them many of the ancients.

# 3860

And assuredly We sent among them warners.

# 3861

So behold what wise hath been the end of those who were warned.

# 3862

Save the bondmen of Allah sincere.

# 3863

And assuredly Nuh cried Unto us; and We are the Best of answerers!

# 3864

And We delivered him and his people from the great affliction.

# 3865

And his offspring! them We made the survivors.

# 3866

And We left for him among the posterity.

# 3867

Peace be on Nuh among the worlds.

# 3868

Verily We! thus We recompense the well-doers.

# 3869

Verily he was of Our bondmen believing.

# 3870

Then We drowned the others.

# 3871

And verily of his sect was Ibrahim.

# 3872

Recall what time he came Unto his lord with a heart whole.

# 3873

Recall what time he said Unto his father and his people: What is it that ye worship?

# 3874

Is it a falsehood-god beside Allah - that ye desire?

# 3875

what, then, is your opinion of the Lord of the worlds?

# 3876

Then he glanced a glance on the stars.

# 3877

And he said: verily I am about to be sick.

# 3878

So they departed from him turning their backs.

# 3879

Then he slipped Unto their gods and said: eat ye not

# 3880

What aileth ye that ye speak not?

# 3881

Then he slipped Unto them striking them with the right hand.

# 3882

Then they advanced toward him, hastening.

# 3883

He said: worship ye that which carve.

# 3884

Whereas Allah hath created you and that which ye make?

# 3885

They said. build for him a building and cast him into the flaming fire.

# 3886

And they devised a plot for him, but We made them the humble.

# 3887

And he said: verily I am going to my Lord who will guide me.

# 3888

My Lord! Bestow on me a son who will be of the righteous.

# 3889

Wherefore We gave him the glad tidings of a boy gentle.

# 3890

And when he attained the age of, running with him, he said: O my son! verily I have seen in a dream that I am slaughtering thee; so look, what considerest thou? He said: O my father! do that which thou art commanded; thou shalt find me, Allah willing, of the patients.

# 3891

Then when the twain had submitted themselves and he had prostrated him upon his temple.

# 3892

We cried Unto him: O Ibrahim

# 3893

Of a surety thou hast fulfilled the vision. Verily We! thus We recompense the well-doers.

# 3894

Verily that! that was a trial manifest.

# 3895

And We ransomed him with a mighty victim.

# 3896

And We left for him among the posterity:

# 3897

Peace be Unto Ibrahim:

# 3898

Verily We! thus We compense the well-doers.

# 3899

Verily he was one of Our believing bondmen.

# 3900

And We gave him the glad tidings of Is-haq, a prophet, and of the righteous.

# 3901

And We blessed him and Is-haq; and of their offspring are some well-doers and some who wrong themselves manifestly.

# 3902

And assuredly We gave grace Unto Musa and Harun.

# 3903

And delivered them and their people from the great affliction.

# 3904

And We succoured them so that they became overcomers.

# 3905

And We vouchsafed Unto the twain a Book luminous.

# 3906

And We led the twain on Unto the straight path.

# 3907

And We left for the twain among the posterity:

# 3908

Peace be Unto Musa and Harun.

# 3909

Verily We! thus We recompense the well-doers.

# 3910

Verily the twain were of Our bondmen believing.

# 3911

And verily, llyas was one of the sent ones.

# 3912

Recall what time he said Unto his people: fear ye not?

# 3913

Call ye upon Bal and forsake the Best of creators.

# 3914

Allah, your Lord and Lord of your forefathers?

# 3915

Then they belied him, so verily they are to be brought up.

# 3916

Except the bondmen of Allah sincere.

# 3917

And We left for him among the posterity:

# 3918

Peace be Unto Elyasin.

# 3919

Verily We! thus We recompense the well-doers.

# 3920

Verily he was one of Our bondmen believing.

# 3921

And verily Lut was of the sent ones.

# 3922

Recall what time We delivered him and his household, all.

# 3923

Save an old woman among the lingerers.

# 3924

Then We annihilated the others.

# 3925

And surely ye pass by them in the morning.

# 3926

And at night. Will ye not therefore reflect?

# 3927

And verily Yunus was Of the sent ones.

# 3928

Recall what time he ran away Unto a laden ship.

# 3929

Then he joined the lots, and was of the condemned.

# 3930

And a fish swallowed him, and he was reproaching himself.

# 3931

And had he not been of those who hallow Him,

# 3932

He would have tarried in the belly thereof till the Day when they are raised.

# 3933

Then We cast him on a bare desert whilst he was sick.

# 3934

And We caused to grow over him a tree, a gourd.

# 3935

And We had sent him to a hundred thousand: rather they exceeded.

# 3936

And they believed, whrefore We let them enjoy life for a season.

# 3937

Now ask thou them: there for thy Lord daughters and for them sons?

# 3938

Or created We the angels females while they were witnesses?

# 3939

Lo! verily it is of their falsehood that they say:

# 3940

God hath begotten. Verily they are the liars.

# 3941

Hath He chosen daughters above sons?

# 3942

What aileth you? How judge ye?

# 3943

Will ye not then be admonished?

# 3944

Or, is there for you a clear warranty

# 3945

Then bring your book, if ye say sooth.

# 3946

And they have made a kinship between Him and the jinn a kinship whereas the jinn assuredly know that they are to be brought up

# 3947

Hallowed be Allah from that which they ascribe to Him.

# 3948

Except the bondmen of Allah sincere.

# 3949

Wherefore verily neither ye nor that which ye worship,

# 3950

Can tempt anyone to rebel against Him.

# 3951

Save him Who is to roast in the Flaming Fire.

# 3952

Of us there is none but hath a station assigned.

# 3953

And verily we! we are ranged in ranks.

# 3954

And verily we! we halloW.

# 3955

And they surely were wont to say:

# 3956

Had we but an admonition as had the ancients.

# 3957

Surefy we would have been the bondmen of God sincere.

# 3958

Yet they disbelieve therein. Presently they shall come to know.

# 3959

And assuredly Our word hath already gone forth Our bondmen, the sent ones:

# 3960

That verily they! they shall be made triumphant.

# 3961

And verily Our host! they are to be overcome.

# 3962

So turn thou aside from them for a season.

# 3963

And see them thou; they themselves shall presently see.

# 3964

Our torment seek they to hasten on!

# 3965

Then when it descendeth Unto them face to, face, a hapless morn that shall be for those who were Warned.

# 3966

And turn thou aside from them for a season.

# 3967

And see thou: they themselves shall presently see.

# 3968

Hallowed be thine Lord, the Lord of Majesty, from that which they ascribe!

# 3969

And peace be Unto the sent ones.

# 3970

And all praise Unto Allah the Lord of the worlds.

# 3971

Sad. By the Qur'an full of admonition.

# 3972

Verily those who disbelieve are in vainglory and shism.

# 3973

How many a generation have We destroyed afore them, and they cried when there was not time of fleeing.

# 3974

And they marvel that there should come Unto them a warner from among themselves. And the infidels say: this is a magician and a liar!

# 3975

Maketh he the gods One God? Verily that is a thing astounding!

# 3976

The chiefs among them departed saying: go, and persevere in your gods; verily this is a thing designed.

# 3977

We heard not thereof in the later faith; this is naught but an invention.

# 3978

Hath Unto him the admonition been sent down from amongst us! Yea! they are in doubt concerning My admonition. Yea! they have not yet tasted My torment.

# 3979

Or, are with them the treasures of the mercy of thy Lord, the Bestower?

# 3980

Or, is theirs the dominion of the heavens and the earth and that which is in-between the twain? If so, let them ascend by steps.

# 3981

Here there is a host of the confederates only to be defeated.

# 3982

Before them there have belied the people of Nuh and the 'Aad, and Fir'awn the owner of the stakes.

# 3983

And the Thamud, and the people of Lut, and the dwellers of the wood; these were the confederates.

# 3984

There was not one but belied the apostles, wherefore justified was My wrath.

# 3985

And these wait but for one shout, wherefrom there will be no deferment.

# 3986

And they say: our Lord! hasten our portion unto us before the Day of Reckoning

# 3987

Bear thou with that which they say, and remember Our bondman, Da-ud, endured with strength; verily he was oft-returning onto Us.

# 3988

Verily We so subjected the mountains that they should hallow Us with him at nightfall and sunrise.

# 3989

And the birds also, gathering all oft-returning onto Him on his account.

# 3990

And We made his dominion strong and vouchsafed him wisdom and decisive speech.

# 3991

And hath the tidings of the contending parties reached thee, when they walled the apartment?

# 3992

When they went in unto Da-ud, he was frightened at them. They said: fear not we are two contending parties; one of us hath oppressed the other, so judge between us with truth, and be not iniquitious, and guide us unto the even path.

# 3993

Verily this my brother hath nine and ninety ewes while I have one ewe; and he saith: entrust it to me, and he hath prevailed upon me in speech.

# 3994

Da-ud said: assuredly he hath wronged thee in demanding thine ewe in addition to his ewes, and verily many of the partners oppress each other save such as believe and work righteous works, and few are they. And Da-ud imagined that We had tried him; so he asked forgiveness of his Lord, and he fell down bowing and turned in penitence.

# 3995

So We forgave him that; and verily for him is an approach with us, and a happy retreat.

# 3996

O Da-ud! verily We have appointed thee a vicegerent in the earth, so judge between mankind with truth, and follow not desire, lest it cause thee to err from the path of Allah. Verily those who err from the path of Allah - Unto them shall be a severe torment, for they forgat the Day of Reckoning.

# 3997

And We have not created the heaven and the earth and whatsoever is in-between the twain in vain." That is the opinion of those who disbelieve. And woe Unto those who disbelieve the Fire."

# 3998

Shall We make those who believe and work righteous works I i ke Unto the corrupters in the earth; Or Shall We make the God-fearing like Unto the wicked!

# 3999

This is a Book We have sent down Unto thee, blest, that they may ponder the revelations thereof, and that there may be admonished men of understanding.

# 4000

And We vouchsafed Unto Da-ud Sulaiman. How excellent a bondman! j Verily he was oft-returning.'

# 4001

Recall what time there were presented Unto him, at eventide, s coursers swift-footed.

# 4002

He said: verily I have loved the love of earthly good above the remembrance of my Lord until the sun hath disappeared behind the veil.

# 4003

Bring them back Unto me; and he set about slashing their legs and necks.

# 4004

And assuredly We tried Sulaiman, and set upon his throne a mere body. Thereafter he was penitent.

# 4005

He said: my Lord! forgive me, and bestow on me a dominion which no one may obtain beside me: verily Thou! Thou art the Bestower.

# 4006

Then We subjected to him the wind: it ran gently by his command withersoever he directed.

# 4007

And We subjected to him the evil ones: every builder and diver.

# 4008

And others bound in fetters.

# 4009

This is Our gift, SO bestow thou or withhold, without rendering an account.

# 4010

And verily for him is an approach with us, and a happy end.

# 4011

And remember thou Our bondman Ayyub, what time he cried Unto his Lord: verily the Satan hath touched me with affliction and suffering.

# 4012

Stamp the ground with thy foot. yonder is water to wash in, cool, and water to drink.

# 4013

And We bestowed on him his household and along with them the like thereof, out of mercy from us, and a remembrance Unto men of understanding.

# 4014

And take in thine hand a handful of twigs, and strike therewith, and break not thine oath. Verily We! We found him patient. How excellent a bondman! Verily he was oft-returning.

# 4015

And remember thou Our bond men, Ibrahim and Is-haq and Ya'qub. owners of might ana insight.

# 4016

Verily We! We distinguished them with a distinct quality: the remembrance of the Abode.

# 4017

And verily they are with us of the elect of the excellent ones

# 4018

And remember Isma'il and Al-Yas'a and Zul-kifl: all of the excellent ones.

# 4019

This is an admonition, and verily for the God-feoring is a happy retreat:

# 4020

Gardens Everlasting, whereof the portals remain opened for them.

# 4021

Therein they will recline; therein they will call for plenteous fruit and drink.

# 4022

And with them will be virgins of refraining looks and of equal age.

# 4023

This it is that ye are promised for the Day of Reckoning.

# 4024

Verily this is Our provision: there will be no ceasing thereof.

# 4025

This: and verily for the exorbitant there shall be an evil retreat:

# 4026

Hell, wherein they roast: a wretched couch.

# 4027

This - let them taste it: scalding water and corruption.

# 4028

And other torments, like thereof, conjoined.

# 4029

This is a crowd rushing in along with you; no welcome for them; verily they are to roast in the Fire.

# 4030

They will say nay! it is ye, for whom there is no welcome: it is ye who have brought it upon us. Evil shall be the resting-place.

# 4031

They Will say: our Lord! whosever hath brought this upon us, - Unto him increase doubly the torment of the Fire.

# 4032

And they will Say: what aileth us that we behold not men whom we were wont to count among the evil ones?

# 4033

Took we them so unjustly for a butt of mockery, or are they deluding our eyes?

# 4034

Verily this is the very truth: the wrangling of the fellows of the Fire!

# 4035

Say thou: I am but warner, and there is no god but Allah, the One, the Subduer.

# 4036

Lord of the heavens and the earth and whatsoever is in- between the twain, the Mighty, the Forgiver.

# 4037

Say thou: it is a tiding mighty.

# 4038

Ye are therefrom averting.

# 4039

I had no knowledge of the chiefs on high when they disputed;

# 4040

Naught is revealed Unto me except that I am a warner manifest.

# 4041

Recall what time thy Lord said Unto the angels: verily I am about to create a human being from clay;

# 4042

Then when I have formed him and breathed into him of My spirit, fall down before him prostrate.

# 4043

The angels prostrated themselves, all of them.

# 4044

Not so lblis. He grew stiffnecked and became of the infidels.

# 4045

Allah said: O Iblis! what preventeth thee from prostrating thyself before that which have created with both my hands? Becomest thou stiff-necked, or art thou of the exalted ones?

# 4046

He said: I am better than he: me Thou hast created of fire, and him Thou hast created of clay.

# 4047

Allah said: get thee forth therefrom verify thou art driven away.

# 4048

And verily My curse shall be on thee till the Day of Requital,

# 4049

He said: my Lord! respite me till the Day whereon they are raised up.

# 4050

Allah said: verily, thou art of those respited.

# 4051

Until the Day of the time appointed.

# 4052

He said: by Thy majesty, then, I shall surely seduce them, all.

# 4053

Save Thy bondmen among them Sincere.

# 4054

Allah said: the truth is, and it is the truth that I speak, -

# 4055

That I shall fill Hell with thee and such of them as shall follow thee, all together.

# 4056

Say thou: ask of you for it no hire, nor am I of the affecters.

# 4057

It is naught but an admonition Unto the worlds.

# 4058

And ye shall surely come to know the truth thereof after a season.

# 4059

The revelation of this Book is from Allah, the Mighty, the Wise.

# 4060

Verily We! We have sent down the Book Unto thee With truth: wherefore worship thou Allah, making exclusion for Him in religion.

# 4061

LO! for Allah is the religion exclusive. And those who take patrons beside Him, saying: We Worship them not save in order that they may bring us nigh Unto God in approach - -verily Allah will judge between them concerning that wherein they differ. Verily Allah guideth not him who is a liar and ingrate.

# 4062

Had Allah willed to take a son, He could have chosen whatsoever He pleased out of that which He hath created. Hallowed be He! He is Allah the One, the Subduer.

# 4063

He hath created the heavens and the earth with truth. He rolleth the night around the day, and rolleth the day around the night, and He hath subjected the sun and the moon: each running on for a term appointed! Lo! He is the Mighty, the Forgiver.

# 4064

He created you Of a Single soul, and made his spouse therefrom; and of the cattle He sent down Unto you eight pairs. He createth you in the bellies of your mothers, one creation after creation, in a threefold darkness. Such is Allah, your Lord. His is the dominion, there is no god but He. Whither then turn ye away?

# 4065

If ye disbelieve, then verily Allah is Independent of you. And He approveth not of infidelity in His bondmen. And if ye return thanks He approveth of that in you. No burdened soul shall bear another's burthen. Thereafter Unto your Lord is Your return; and He shall declare Unto you that which ye have been Working. Verily He is the Knower of that which is in the breasts.

# 4066

And when some hurt toucheth man, he calleth upon his Lord, turning Unto Him in penitence; then when He bestoweth upon him a favour from Himself, he forgetteth that for which he called on Him afore, and setteth up peers Unto Allah that He may lead astray others from His way Say thou: enjoy thou life in thy infidelity for a while, verily thou art of the fellows of the Fire.

# 4067

Is he who is devout, in the watches of the night prostrating himself and standing, bewaring of the Hereafter and hoping for the mercy of his Lord to be dealt with like a wicked infidel? Say thou: shall they who know and those who know not be held equal? It is only men of understanding who receive admonition.

# 4068

Say thou: O Mine bondmen who believe! fear your Lord. For those who do good in this world there is good: and Allah's earth is spacious. Verily the patient shall be paid in full their hire without reckoning.

# 4069

Say thou: verily I am commanded to worship Allah, making for Him religion exclusive.

# 4070

And I am commanded this, in order I may be the first Of those who submit.

# 4071

Say thou: verily fear, if I disobeyed my Lord, torment of a Day mighty.

# 4072

Say thou: it is Allah I worship, making for Him my religion exclusive

# 4073

So worship whatsoever ye will, besidev him. Say thou: verily the losers are those who shall have lost themselves and their household" on the Day of judgment LO! that will be a loss manifest.

# 4074

For them! above them shall be coverings of Fire and beneath them coverings. Therewith Allah affrighteth His bondmen. O My bondmen! wherefore fear Me.

# 4075

And those who avoid the devils lest they should worship them and turn Unto Allah in penitence, for them are glad tidings. Wherefore give thou glad tidings Unto My bondmen,

# 4076

Who hearken Unto the word and follow that which is the exceLlent there of. These are they whom Allah hath guided, and those are men of understanding.

# 4077

Is he then on whom is justified the decree of torment - wilt thou rescue him who is in the Fire?

# 4078

But those whofear their Lord, for them are lofty chambers with lofty chambers above them, built whereunder rivers flow: the promise of Allah, and Allah faileth not the appointment.

# 4079

Beholdest thou not that Allah sendeth down water from the heaven, and causeth it to enter springs in the earth, and thereafter produceth thereby corn various coloured. Thereafter it wirhereth, and thou beholdest it turn yellow; then He maketh it chaff. Verily herein is an admonition for men of understanding.

# 4080

Shall he then whose breast Allah hath expanded for Islam, so that he followeth a light from his Lord be as he whose heart is hardened? Then woe Unto those whose hearts are hardened against remembrance of Allah. They are in an error manifest.

# 4081

Allah hath revealed the most excellent discourse, a Book consimilar oft-repeated, whereat trembleth the skins of these who fear their Lord; then their skins and their hearts soften at the remembrance of Allah. This is Allah's guidance, wherewith He guideth whomsoever He will. And whomsoever Allah sendeth astray, for him there is no guide.

# 4082

Is he, then, who will shield himself with his face from the evil of torment on the Day of Resurrection be as he who is secure therefrom And it shall be said Unto the wrong-doers: taste ye that which ye have been earning.

# 4083

Those before them belied, wherefore the torment came on them whence they knew not.

# 4084

So Allah made them taste humiliation in the life of the world. And surely the torment of the Hereafter is greater - if they but know!

# 4085

And assuredly We have propounded for mankind in this Qur'an all kinds of similitudes, that haply they may be admonished.

# 4086

An Arabic Qur'an, wherein there is no crookedness, that haply they may fear.

# 4087

Allah propoundeth a similitude: man having several partners,"quarelling, and a man wholly belonging to one man. Are the two equal in likeness? All praise Unto Allah. But most of them know not.

# 4088

Verily thou art mortal, and verily they are mortals.

# 4089

Then verily on the Day of Resurrection, before your Lord ye shall contend.

# 4090

And who is a greater wrong-doer than he who fabricateth a lie against Allah, and belieth the truth when it cometh Unto him? Will not in Hell be an abode for the infidels?

# 4091

And whosoever bringeth the truth, and whosoever giveth credence thereto - these! they are the God-fearing.

# 4092

Theirs will be whatsoever they will desire with their Lord: that is the hire of the well-doers.

# 4093

That through this Promise Allah may expiate from them the worst of that which they may have worked, and may recompense them their hire for the best of that which they have been working.

# 4094

Is not Allah sufficient for His bondman? Yet they would frighten thee with those beside Him? And whomsoever Allah sendeth astray, for him there shall be no guide.

# 4095

And whomsoever Allah guideth, for him there shall be no misleader. Is not Allah Mighty, and Lord of Retribution?

# 4096

And wert thou to ask them: who hath created the heavens and the earth? they will surely say: Allah. Say thou: bethink ye then that those whom ye call upon beside Allah, - could they if Allah intended some hurt for me, remove His hurt? or if He intended some mercy for me, could they withhold His mercy? Say thou: enough for me is Allah; in Him the trusting put their trust.

# 4097

Say thou: my nation! work according to your condition; I am going to work in my way; presently ye shall come to know.

# 4098

On whom cometh a torment humiliating him, and on whom alighteth a torment lasting.

# 4099

Verily We! We have sent down Unto thee the Book for mankind? with truth. Then whosoever receiveth guidance, it is for his soul and whosoever strayeth, strayeth only to its hurt; and thou art not over them a trustee.

# 4100

Allah it is who taketh away souls at the time of their death, and those which die not in their sleep: then He withhold those on which He hath decreed death, and sendeth back the rest for an appointed term. Verily herein are signs for a people who ponder.

# 4101

Have they taken others for intercessors beside Allah! Say thou: What! even though they own not aught and understand not?

# 4102

Say thou: Allah's is intercession altogether. His is the dominion of the heavens and the earth; then Unto Him shall ye be returned.

# 4103

And when Allah alone is mentioned, then shrink with eversion the hearts of those who believe not in the Hereafter, and when those beside Him are mentioned, lo! they rejoice.

# 4104

Say thou: O Allah! Creator of the heavens and the earth! Knower of the hidden and the open! Thou shalt judge between Thy bondmen concerning that wherein they have been differing.

# 4105

And were those who did wrong to own all that is in the earth, and there with as much again, they shall surely seek to ransom themselves therewith from the evil of the torment on the Day of Judgment; and there shall appear Unto them from Allah that whereon they had not been reckoning,

# 4106

And there shall appear Unto them the evils that they earned, and there shall surround them that whereat they had been mocking.

# 4107

When hurt toucheth a man he calleth on us, and thereafter, when We have changed it Unto a favour from Us, he saith: have been given itso only by force of my knowledge. Aye! it is a trial, but most of them know not.

# 4108

Surely those who were before them said it, yet there availed them not that which they had been earning.

# 4109

And there befell them the evils of that which they had earned. And of these they who go wrong-anon will befall them the evils of that which they earn; nor can they frustrate.

# 4110

Know they not that Allahs expandeth provision for whomsoever He will, and stinteth it for whomsoever He will! Verily herein are signs for a people who believe.

# 4111

Say thou: my bondmen who have committed extravagance against themselves despair not of the mercy of Allah; verily Allah will forgive the sins altogether. Verily He! He is the Forgiving, the Merciful.

# 4112

And turn penitently Unto your Lord and submit Unto Him ere there cometh Unto you the torment, and then ye shall not be succoured.

# 4113

And follow the best of that which hath been sent down Unto you from your Lord there cometh on you torment of a sudden, while ye perceive not.

# 4114

Lest a soul should say: Alas! for that I have been remiss in respect of Allah, and I was but of the scoffers!

# 4115

Or, lest it should say: had Allah but guided me, I should surely have been of the God-fearing!

# 4116

Or lest it should say, when it will behold the torment: were there for me a return I would be of the well-doers.

# 4117

Yea! surely there came Unto thee My revelations, but thou beliedest them and wast stiff-necked and wast of the infidels.

# 4118

And on the Day of Judgment thou Shalt see those who lied against Allah - their faces blackened. Is not in Hell the abode of the stiff-necked?

# 4119

And Allah will deliver those who feared Him to their place of safety. Evil will not touch them, nor will they grieve.

# 4120

Allah is the Creator everything, And He is over everything a Trustee.

# 4121

His are the keys of the heavens and the earth and those who disbelieve in the revelations of Allah-those! they are the losers.

# 4122

Say thou: is it other than Allah that ye command me to worship! O ye pagans

# 4123

And assuredly it hath been revealed Unto thee and Unto those before thee: if thou associatest surely of non-effect shall be made thy work, and thou shalt surely be of the losers.

# 4124

Aye! Allah must thou worship, and be among the thankful.

# 4125

And they estimated not Allah with an estimation due Unto Him whereas the whole earth shall be His handful on the Day of Judgment, and the heavens shall be rolled in His right hand. Hallowed be He and Exalted above that which they associate.

# 4126

And the trumpet will be blown, when whosoever are in the heavens and whosoever are on the earth will swoon away, save him whomsoever Allah willeth. Then it shall be blown again, and lo! They will be standing, looking on.

# 4127

And the earth will gleam with the light of its Lord, and the Record shall be set up, and the prophets and the witnesses will be brought and judgment will be given between them with truth, and they will not be wronged.

# 4128

And each soul will be paid in full that which it hath worked; and He is the Best Knower of which they do.

# 4129

And those who disbelieve will be driven onto Hell in troops till, when they arrive thereto, the portals thereof will be opened, and the keepers thereof will say Unto them: came there not Unto you apostles from amongst you, rehearsing Unto you the revelations of you Lord and warning you of the meeting of this your Day? They shall say: Yea, but the word of torment hath been justified on the Infidels.

# 4130

It will be said: enter the portals Of Hell to be abiders therein. How ill, then, is the abode of the stiff-necked!

# 4131

And those who feared their Lord Will be driven Unto the Garden in troops till, when they arrive thereto, and the portals thereof will be opened, the keepers thereof Will say Unto them: Peace be Unto you! excellent are ye! enter it as abiders.

# 4132

And they Will say: all praise Unto Allah, who hath fulfilled His promise Unto us and made us inherit this land, so that we may dwell in the Garden whereever we will! Excellent then is the hire of the workers!

# 4133

And thou wilt see the angels thronging round the Throne, hallowing the praise of their Lord. And judgment shall be given between them with truth: and it will be said: all praise Unto Allah, the Lord of the worlds.

# 4134

Ha. Mim.

# 4135

The revelation of the Book is from Allah, the Mighty, the Knower. Forgiver of sin, and Accepter of repentance, severe in chastisement, Lord of power. There is no god but He; Unto Him is the journeying.

# 4136

Forgiver of sin, and Acceptor of repentance severe in chastisement, Lord of Power. There is no god but He; unto Him is the journeying.

# 4137

None dispute concerning the revelations of Allah save those who disbelieve, so let not beguile thee their going about in the cities.

# 4138

The people of Nuh and the confederates after them belied their apostles before these, and each disbelieving community advanced toward their apostle that they may lay hold of him and disputed with vain speech that they may confute the truth thereby. Wherefore I laid hold of them; and how terrible was My chastisement!

# 4139

And thus hath the Word of thy Lord been justified on those who disbelieve: that they shall be the fellows of the Fire.

# 4140

Those who bear the Throne and those who are round about it, hallow the praise of their Lord and believe in Him and ask forgiveness for those who believe, saying: our Lord! Thou comprehendest everything in mercy and knowledge, wherefore forgive these who repent and follow Thine path, and protect them from the torment of the Flaming Fire.

# 4141

Our Lord! make them enter the Everlasting Gardens Which Thou hast promised them, and also such of their fathers and their spouses and their offspring as verify Thou: Thou art the Mighty, the Wise.

# 4142

And protect them from evils. And whosoever Thou shalt protect from evils on that Day, him Thou hast of a surety taken into mercy and that: it is an achievement mighty.

# 4143

Verily those who disbelieve-they will be cried Unto: surely Allah's abhorrence was greater than Is your abhorrence toward yourselves when ye were called Unto the belief, and ye disbelieved.

# 4144

They will say: our Lord! Thou hast made us die twice, and Thou hast made us live twice now We confess our sins: there no getting out any way?

# 4145

That is because when Allah alone was called upon ye disbelieved, and when some one was associated with Him ye believed. So the judgment is of Allah, the Exalted, the Great.

# 4146

He it is who sheweth you His signs and sendeth down for you from the heaven provision. And none receiveth admonition save him who turneth in penitence.

# 4147

Wherefore call Unto Allah, making religion for Him pure, though the infidels be averse.

# 4148

He is Lofty in degrees, Lord of the Throne. He casteth the spirit of His command upon whomsoever He will of His bondmen, that he may warn people of the Day of Meeting.

# 4149

The Day whereon they will appear: naught of them will be concealed from Allah, Whose is the dominion to-day? It is of Allah, the One, the Subduer.

# 4150

To-day each soul will be recompensed for that which it hath earned; no wrong-doing to-day; verily Allah is Swift at reckoning.

# 4151

Wherefore warn them thou of the Day of portending, whereon the hearts will be in the throats, choking: then will be for the wrong- doers no ardent friend nor an intercessor to be given heed to.

# 4152

He knoweth the fraudulence of the eyes, and that which the breasts conceal.

# 4153

Allah decreeth with truth, while those whom they call upon beside Him cannot decree aught; verily Allah! He is the Hearer, the Beholder!

# 4154

Have they not travelled about in the land so that they may behold of what wise hath been the end of those who were before them? They were mightier than these in strength and in the traces in the land. Yet Allah laid hold of them for their sins, and from Allah they had none as protector.

# 4155

That was because their apostles were wont to bring them evidence, but they disbelieved; wherefore Allah laid hold of them. Verily He is strong, severe in chastisement.

# 4156

And assuredly We sent Musa with Our signs and a manifest authority.

# 4157

Unto Fir'awn and Haman and Qur'an, but they said: a magician, a liar.

# 4158

And when he came to them with the truth from before Us, they said: slay the sons of those who have believed with him, and let their women live. And the plot of the infidels was naught but vain.

# 4159

And Fir'awn said: let me alone, that may slay Musa, and let him call upon his Lord. Verily fear that he may change your religion or that he may cause to appear in the land corruption.

# 4160

And Musa said: verily I seek refuge in my Lord and your Lord from every stiff-necked person who believeth not in a Day of Reckoning.

# 4161

And a believing man of Fir'awn 's household, hiding his belief, said: would ye slay a man because he saith: my Lord is God, and hath come upto you with evidences from your Lord? If he is a liar, then upon him will be his lie, and if he is a truth-teller, then there will befall you some of that wherewith he threateneth you; verily God guideth not one who is an extravagant and a liar.

# 4162

O My people! yours is the the dominion to-day: ye being overcomers in the land; but who will succour us aginst the scourge of God if it cometh Unto us! Fir'awn said: I shew you only that which see, and I guide you but to the path of rectitude.

# 4163

And he who believed said: O my people. verily I fear for you a fate like the day of the confederates.

# 4164

Like the wont of the people of Nuh and A'ad and Thamud and those after them, and God intendeth not any wrong Unto His bondmen.

# 4165

And, O my people! verily fear for you a Day of Mutual Calling.

# 4166

A Day whereon ye shall turn away retreating: for you there will be no protector from God; and whomsoever God sendeth astray for him there is no guide.

# 4167

And assuredly there came Unto you Yusuf aforetime with evidences, yet ye ceased not to be in doubt concerning that which he brought Unto you, until when he died, ye said: God shall by no means raise an apostle after him. Thus Allah keepeth astray one who is extravagant and a doubter.

# 4168

Those who wrangle concerning the signs of Allah without any authority that hath come Unto them. It is greatly abhorrent Unto Allah and Unto those who believe. Thus Allah sealeth up the heart of any stiff-necked, high-handed, person.

# 4169

And Fir'awn said: O Haman! build for me a tower that haply I may reach the ways of access

# 4170

The way of access to the heavens so that may be apprised of the God of Musa, and verily I believe him to be a liar. And thus fair- seeming was made Unto FIr'awn the evil of his work, and he was hindered from the path. And the plot of Fir'awn ended only in ruin.

# 4171

And he who believed said: O my people! follow me, I shall guide you to the path of rectitude,

# 4172

O My people! this life of the world Is but a possi enjoyment, and verily the Hereafter! that is the Abode of rest.

# 4173

Whosoever worketh an evil, he shallnotberequited except the like thereof; and whosoever, male or female, worketh righteously, and is a believer-they will enter the Garden wherein they will be pro vided for without measure.

# 4174

And, O my people! what aileth me that call you Unto deliverance, while ye call me Unto the Fire!

# 4175

Ye call me for this, that should O blaspheme against God and associate with Him that whereof have no knowledge, call you onto the Mighty, the

# 4176

Without doubt ye only call me Unto that which is not to be invoked in the world nor in the Hereafter; and verily our return shall be Unto God, and the extravagant! they shall be fellows of the Fire.

# 4177

And anon ye shall remember that which am telling you. Confide my affair Unto God; verily God is the Beholder of His bondmen.

# 4178

Wherefore Allah protected him from ills which they plotted, and there surrounded the family of Fir'awn the evil of torment.

# 4179

The Fire! They are exposed thereto morning and evening. And on the Day whereon the Hour will uprise, it will be said: cause the family of Fir'awn to enter the most grievous torment.

# 4180

And consider what time they will wrangle together in the Fire, and the oppressed will say Unto those who were stiff-necked: verily we have been Unto you a following, are ye going to avail us against a portion of the Fire?

# 4181

Those who were stiff-necked will say: verily we are all in it; verily Allah hath judged between His bondmen.

# 4182

And those in the Fire will say Unto the keepers of Hell: supplicate your Lord that He may lighten for us a day of the torment.

# 4183

They will say: came there not your apostles Unto you with evidences? They will say: Yea? They will say: supplicate then yourselves. And supplication of the infidels will be but in wandering.

# 4184

Verily We! We shall surely succour Our apostles and those who believe, both in the life of the world and on a Day whereon the witnesses will stand forth.

# 4185

A Day whereon their excuse will not Profit the wrong- doers; and theirs Will be the curse and theirs the evil Abode.

# 4186

And assuredly We vouchsafed Unto Musa the guidance, and We caused the Children of Isra'il to inherit the Book.

# 4187

A guidance and an admonition Unto the men of understanding,

# 4188

Wherefore persevere thou. Verily the Promise of Allah is true and ask forgiveness for thy fault, and hallow the praise of thy Lord in the evening and in the morning.

# 4189

Verily those who wrangle concerning the revelations of Allah without an authority having come Unto them there is aught in their breasts save greatness Which they shall not reach. Seek refuge thou then in Allah verily He! He is the Hearer, the Beholder.

# 4190

The creation of the heavens and the earth is indeed greater than the creation of mankind; but most of man kind know not.

# 4191

Not equal are the blind and the seeing; nor those who believed and Work righteous works and the evil-doer. Little are ye admonished!

# 4192

Verily the Hour is coming: there is no doubt thereof; yet most of mankind believe not.

# 4193

And your Lord hath said: call Unto Me, and I shall answer your prayer. Verily those who are stiff-necked against My worship, anon they will enter Hell abject.

# 4194

Allah it is who hath appointed for you the night that ye may repose therein, and day enlightening. Verily Allah is the Lord of Grace for mankind; bur most of mankind return not thanks.

# 4195

Such is Allah. your Lord, the Creator of everything there is no God but He. Wither then are ye straying away?

# 4196

In this wise have those strayed who the signs of Allah were away want to gainsay.

# 4197

Allah it is Who hath appointed for you the earth for a resting-place and the heaven for a structure, and fashioned you and fashioned you well, and provided you with goodly things. Such is Allah, your Lord. So blessed be Allah, the Lord of the worlds!

# 4198

He is the Living: there is no god but He so call upon Him, making religion pure for Him. All praise Unto Allah, the Lord of the worlds!

# 4199

Say thou: verily I am forbidden that should worship these whom ye call upon beside Allah when evidences have come Unto me from my Lord, and I am commanded that I should submit to the Lord of the Worlds.

# 4200

He it is Who created you of dust, and thereafter of a drop, and thereafter of a clot, and thereafter He bringeth you forth as an infant, and thereafter He ordaineth that ye attain your full strength and thereafter that ye become old men-though some of you die before-and that ye attain the appointed term, and that haply ye may reflect.

# 4201

He it is Who causeth life and death. Then whensoever He decreeth an affair He only saith Unto it: be, and it becometh.

# 4202

Observest thou not those who wrangle concerning the revelations of Allah: whither are they turning away?

# 4203

Those who belie the Book and that message wherewith We sent Our apostles, presently they shall come to know.

# 4204

When shackles will be on their necks and also chains; they will be dragged.

# 4205

Into the balling water; then into the Fire they will be stocked.

# 4206

Then it will be said Unto them: where are those whom ye have been associating

# 4207

Beside Allah? They will say: they have failed us: aye! we have not been calling upon aught afore. Thus doth Allah lead the infidels astray.

# 4208

That is because ye had been exulting in the earth without right, and because ye had been strutting.

# 4209

Enter ye the gates of Hell as abiders therein. Hapless is the abode of the stiff-necked.

# 4210

Wherefore persevere thou; verily the promise of Allah is true; then whether We let thee see a part of that wherewith We have promised them, or whether We cause thee to die, Unto us they all will be caused to retvtn.

# 4211

Assuredly We have sent apostlesy before thee, of them are these whose store We have recounted Unto thee and these whose story We have net recounted Unto thee. And it was not possible for anv apostle that he should bring a sign san by Allah's leave. So when the commade of Allah cometh, judgment will be given with truth, and then will lose the followers of falsehood.

# 4212

Allah it is Who hath appointed for you cattle, that ye may ride on some of them, and eat of others

# 4213

And there are other benefits in them for you and that ye may attain thereby to any need that is in Your breasts and upon them and upon ships ye are borne.

# 4214

And He sheweth you His signs. Which, then, of the signs of Allah shall ya deny?

# 4215

Have they not travelled in the earth so that they may behold what wise hath been the end of those before them. They were more numerous than these, and mightier in strength and the traces in the land. But naught availed them of that which they had been earning.

# 4216

And when their apostles came Unto them with evidences, they exulted in the knowledge which was with them, and there surrounded them that which they had been mocking.

# 4217

Then when they behold Our prowess, they said: we believe in Allah alone, and we disbelieve in that which with Him we have been associating.

# 4218

But their belief profited them naught when they saw our prowess. This hath been Allah's dispensation that hath- been in regard to His bondmen. And then there were lost the infidels.

# 4219

Ha-Mim.

# 4220

This is a revelation from the Compassionate, the Merciful -

# 4221

A Book whereof the verses are detailed: an Arabic Qur'an: for a people who know:

# 4222

A bearer of glad tidings and a warner. Yet most of them turn aside, so that they hearken not.

# 4223

And they say: our hearts are under veils from that whereUnto thou callest us, and in our ears there is heaviness, and betwixt us and thee there is a curtain; work thou then, verily we are Workers.

# 4224

Say thou: I am only a human being like Unto you: only it is revealed Unto me that your God is but One God, wherefore take the straight path Unto Him and seek forgiveness of Him. And woe be Unto the associators.

# 4225

Who give not the poor-rate; and they! in the Hereafter, they are disbelievers.

# 4226

Verily those who believe and work righteous works - Unto them shall be a hire unceasing.

# 4227

Say thou: are ye indeed those who disbelieve in Him who hath created the earth in two days, and set up Unto Him peers? That is the Lord of the worlds.

# 4228

And He placed therein mountains firmly rooted rising above it, and blessed it, and ordained therein the sustenance thereof, all this in four days: comglete: this for the inquirers.

# 4229

Thereafter turned He to the heaven and it was as smoke, and said Unto it and Unto the earth: come ye twain, willingly or loth. They said: we come willingly.

# 4230

Then He decreed them as seven heavens in two days, and revealed Unto each heaven the command thereof; and We bedecked the nether heaven with lamps and placed therein a guard. That is the ordinance of the Mighty, the Knower.

# 4231

Then if they Still turn away, say thou; I warn you of a calamity like the calamity of the 'Aad and Thamud.

# 4232

Recall what time the apostles came Unto them from before them and behind them, saying: worship none save Allah. They said: had our Lord listed, He surely would have sent down angels, so verily in that wherewith ye have been sent we are disbelievers altogether.

# 4233

As for the tribe of 'Aad - they grew stiff-necked on the earth without justification, and said: who is mightier than we in strength? Saw they not that Allah who created them,-He was Mightier than they in strength? And Our signs they were wont to gainsay.

# 4234

Wherefore We sent upon them a raging wind in days inauspicious, that We might make them taste the torment of humiliation in the life of the world; and surely the torment of the Hereafter will be more humiliating, nor will they be succoured.

# 4235

And as for the tribe of the Thamud We guided them but they preferred blindness to the guidance, wherefore the bolt of the torment of abjection laid hold of them because of that which they had been earning.

# 4236

And We delivered those who believed and had been fearing.

# 4237

And warn them of the Day whereon the enemies of Allah will be gathered Unto the Fire; and they will be set in bands.

# 4238

Until when they come to it, their ears and their sights and their skins will bear witness against them of that which they had been working.

# 4239

And they will say Unto their skins: wherefore bear ye witness against us They will say: Allah hath caused us to speak, Who causeth everything to speak, and Who created you the first time and Unto whom ye are now caused to return.

# 4240

Ye have not been taking cover against yourselves lest your ears and your eyes and your skins should bear witness against you, but ye imagined that Allah not much knew of that which ye were working.

# 4241

That thought of yours which ye formed concerning Your Lord, hath ruined you, and ye have become of the losers.

# 4242

Then if they are patient, the Fire is their home, and if they seek to please Allah, they will not be of those who are allowed to please Allah.

# 4243

And We have assigned Unto them some companions who made fairseeming Unto them that which was before them and that which was behind them justified upon them was the Word Pronounced on the communities of the jinn and mankind who passed away before them; verily they were the losers.

# 4244

And those who disbelieve say: hearken not Unto this Qur'an and babble therein, haply ye may overcome.

# 4245

Wherefore We will surely cause those who disbelieve to taste a severe tor ment, and We will surely requite them the worst of that which they have been working.

# 4246

That is the meed of the enemies of Allah: the Fire. Therein is their home of Abidence: a meed forasmuch as Our revelations they were wont to gainsay.

# 4247

And those who disbelieve will say: our Lord! show us those, of the jinn and mankind, who led us astray and we will place them underneath our feet that they may be of the nithermost.

# 4248

Verily those who say: our Lord is Allah, and have thereafter stood fast by it,- upon them there shall come down the angels: fear not, nor grieve, and rejoice in the tidings of the Garden which ye have been promised.

# 4249

We are your friends in the life of the world and in the Hereafter; there in yours will be whatsoever your souls desire, and therein yours shall be whatsoever ye call for.

# 4250

And entertainment from the Forgiving, the Merciful.

# 4251

And who is better in speech than he who summoneth Unto Allah, and worketh righteously, and saith: verily I am one of the Muslims.

# 4252

Nor can good and evil be equal. Repel thou evil with that which is goodly then behold he between whom and thee there was enmity, will be as though he was a warm friend.

# 4253

And none attaineth that except those who are patient; and none attaineth that except the owner of mighty good fortune,

# 4254

And if there inciteth thee an incitement from the Satan then seek refuge in Allah. Verily He! He is the Hearer, the Knower.

# 4255

And of His signs are the night and the day and the sun and the moon. So prostrate not yourselves Unto the sun nor the moon. but prostrate yourselves Unto Allah who hath created them, if it is He alone whom ye are worshipping.

# 4256

And if they grow stiff-necked, then verily those who are with thy Lord, hallow Him night and day, and they weary not.

# 4257

And of His signs is that thou beholdest the earth lowly, and when We send down thereon water, it stirreth to life and groweth. Verily He who quickeneth is the Quickener of the dead. Verily He is over everything Potent.

# 4258

Verily those who blaspheme Our revelations are not hid from Us. Is he then who will be cast into the Fire better or he who cometh secure on the Day of Resurrection? Work whatsoever ye will; Verily He is of that which ye work the Beholder.

# 4259

Verily those who disbelieve in the Admonition when it cometh Unto them are themselves to blame. Verily it is a Book mighty.

# 4260

Falsehood cannot come at it from before it or behind it It, a revelation from One Wise and Praiseworthy.

# 4261

Naught is said Unto thee save that which was said Unto the apostles afore thee. Verily thy Lord is Owner of forgiveness and Owner of afflictive chastisement.

# 4262

And had We made it a recital in a foreign tongue, they would have surely said: wherefore are the verses thereof not detailed? A foreign tongue and an Arab! Say thou: Unto those who have believed it is a guidance and a healing: and those who believe not, - in their ears there is a heaviness, and Unto them it is blindness. These are they who are cried Unto from a place far-off.

# 4263

And assuredly We vouchsafed Unto Musa the Book, and difference arose concerning it; and had not a word gone forth from thy Lord, the affair would have been decreed between them. And verily they are in regard thereto in doubt and dubitating.

# 4264

Whosoever worketh righteously it is for his soul, and whosoever worketh evil it is against it. And thine Lord is not an oppressor Unto His bondmen.

# 4265

Unto Himl is remitted the knowledge of the Hour. And not a fruit cometh forth from the knops thereof; neither doth a female bear or bring forth but with His knowledge. And on the Day whereon He will call Unto them: where are my associates. they will say: we protet Unto Thee, none of us is a witness thereof.

# 4266

And there will fail them those whom they had been calling upon aforetime, and they will perceive that there is for them no shelter.

# 4267

Man is not wearied of praying for worldly good, and if there tcucheth him an evil, he is despondent, despairing.

# 4268

And, surely, if We cause him to taste mercy from Us after affliction hath touched him, he is sure to say: this is my own, and I deem not that the Hour will everarise, and were I to be brought back to my Lord, verily there will be for me, with Him, an excellent condition. But We shall surely declare Unto those who disbelieve that which they have worked, and We shall surely make them taste a torment rough..

# 4269

And when We shew favour Unto man, he turneth aside and withdraweth on his side, and when evil toucheth him, then he is full of prolonged prayer.

# 4270

Say thou: bethink ye! if it is really from Allah and then ye disbelieve therein, then who is further astray than one who is in schism far-off?

# 4271

Anon We shall shew them Our signs in the regions and in their ownselves until it becometh manifest Unto them that it is the truth. Sufficeth it not in regard to thy Lord, that He is over everything Witness?

# 4272

Lo! they are in doubt concerning the meeting with their Lord: Lo! He Is of everything the Encompasser!

# 4273

Ha. Mim.

# 4274

Ain. Sin. Qaf.

# 4275

In this wise revealeth Unto thee and Unto those before thee, Allah the Mighty, the Wise.

# 4276

His is whatsoever is in the heavens and whatsoever is in the earth, and He is the Exalted, the Grand.

# 4277

Well-nigh the heavens might be rent in sunder from above them. And the angels hallow the praise of their lord and ask forgiveness for these on the earth. Lo! Verily Allah! He is the Forgiver, the Merciful!

# 4278

And those who take Patrons beside Him, Allah is Warden over them, and thou art not over them a trustee.

# 4279

And thus We have revealed Unto thee a Qur'an in Arabic, that thou mayest warn the mother of towns and those around it, and that thou mayest warn them of a Day of Assembling whereof there is no doubt. A party will be in the Garden, and a party in the Blaze.

# 4280

And had Allah willed, He would have made them one community; but He causeth whomsoever He will to enter into His mercy. And the wrong doers! for them there shall be no patron or helper.

# 4281

Have they taken patrons besides Him! But Allah! He is the Patron, HE quickeneth the dead, and He is over every-thing Potent.

# 4282

And whatsoever it be wherein ye differ the decision thereof is with Allah; such is Allah, my Lord: in Him put my trust and Unto Him I turn in penitenance.

# 4283

The Creator of the heavens and the earth: He hath made for you mates of yourselves, and of the cattle also mates, whereby He diffuseth you. Not like Unto Him is aught, and He is the Hearer, the Beholder!

# 4284

His are the keys of the heavens and the earth. He expandeth provision for whomsoever He will and stinteth. Verily; He is of everything the Knower.

# 4285

He hath instituted for you in religion that which He had enjoined upon Nuh, and which We have revealed Unto thee, and which We had enjoined upon Ibrahim and Musa and Isa, saying: establish the religion, and be not divided therein. Grievous Unto the associaters is that Unto which thou callest them. Allah chooseth for Himself whomsoever He will and guideth Unto Himself whomsoever turneth in penitence.

# 4286

And they divided not until after knowledge had come to them, through spite between themselves; And had not a word gone forth from thy Lord for an appointed term, the affair would surely have been judged between them. And verily those who have been made inheritors of the Book after them are in doubt thereof dubitating.

# 4287

Wherefore Unto that summon thou, and be steadfast as thou hast been commanded, and follow not their desires. And say thou: I believe in whatsoever Allah hath sent down of the Book, and I am commanded that I should do justice between you; Allah is our Lord and your Lord; Unto us our works, and Unto you your works; let there be no contention between us and you; Allah will assemble us, and Unto Him is the return.

# 4288

And those who contend respecting the religion of Allah after it hath been acknowledged, their contention is void in the sight of their Lord, and upon them shall befall wrath, and theirs shall be a severe torment.

# 4289

Allah it is Who hath sent down the Book with the truth and the balance. And what shall make thee know the Hour may haply be nigh.

# 4290

Only those who believe not therein seek to hasten it, and those who believe are fearful thereof and know that it is the truth. Lo! verily these who debate concerning the Hour are in error far-off.

# 4291

Allah is Gentle Unto His bondmen: He provideth for whomsoever He will, and He is the Strong, the Mighty.

# 4292

Whosoever seeketh the tillage of the Hereafter Unto him We shall give increase in his tillage; and whosoever seeketh the tillage of the world We shall give him somewhat thereof, and in the Hereafter his shall be no portion.

# 4293

Have they associate-gods who have instituted for them a religion which Allah hath not allowed? And had there net been a decisive Word, the affair would have been judged between them. And verily the wrong-doers? theirs shall be a torment afflictive.

# 4294

Thou shalt see the wrong-doers fearful on account of that which they have earned, and it is sure to befall them. And those who believe and work righteous works will be in meadows of the Gardens theirs will be whatsoever they list, in the presence of their Lord. That! that is the supreme grace.

# 4295

That is that whereof Allah giveth the glad tidings Unto His bondmen who believe and work righteous works, Say thou: I ask of you no hire therefor save affection in respect of kinship. And whoso ever earneth a good deed We shall increase Unto him good in respect thereof; verily Allah is Forgiving, Appreciative.

# 4296

Say they: he hath fabricated a lie concerning God! Now, if Allah willed, He would seal thine heart. And Allah abolisheth falsehood and establisheth truth by His words; verily He is the Knower of that which is in the breasts.

# 4297

And He it is Who accepteth repentances from His bondmen, and pardoneth the evil deeds and knoweth that which ye do.

# 4298

And He answereth those who believe and work righteous works and increaseth Unto them of His grace. And the infidels! theirs shall be a severe torment.

# 4299

And had Allah expanded the provision for His bondmen they surely would have rebelled in the earth, but He sendeth down by measure as He willeth; verily He is, in respect of His bondmen. Aware and Beholder.

# 4300

And He it is Who sendeth down the rain after men have despaired, and spreadeth abroad His mercy. And He is the Patron of all, the Praiseworthy.

# 4301

And of His signs is the creation of the heavens and the earth and of the moving creatures which He hath dispersed in the twain. And He is for their assembling whensoever He will Potent.

# 4302

And whatsoever of affliction befalleth you is owing to that which your hands have earned; and He pardoneth much.

# 4303

And ye cannot frustrate His Punishment in the earth; and there is for you beside Allah neither protector nor helper.

# 4304

And of His signs are the ships in the sea like landmarks.

# 4305

If He willeth He causeth the wind to cease so that they keep still on the back thereof; verily therein are signs for every patient, grateful person.

# 4306

Or He may destroy them because of that which they have earned, and He may pardon many of them.

# 4307

And those who dispute in respect of Our revelations may know that for them there is a place of shelter.

# 4308

So whatsoever things are vouchsafed Unto you are but a Passing enjoyment for the life of the world, and that which is with Allah, better and more lasting, is for those who believe and in their Lord put their trust.

# 4309

And those who avoid heinous sins and indecencies, and when they are wroth forgive.

# 4310

And those who answer the call of their Lord and establish prayer and whose affair being matter of counsel among themselves, and who of that wherewith We have provided them expend.

# 4311

And those who, when they are oppressed vindicate themselves.

# 4312

The meed of an ill-deed is an ill the like thereUnto; but whosoever pardoneth and amendeth, his hire is on Allah; verily He approveth not the wrong-doers.

# 4313

And whosoever vindicateth him self after wrong done him these! against them there is no way of blame.

# 4314

The way of blame is only against those who wrong mankind, and rebel in the earth without justice; these! for them is a torment afflictive.

# 4315

And whosoever forbeareth and forgiveth -that verily is of the firmness of affairs.

# 4316

And whomsoever Allah will send astray, for him there will be no protecting friend to take His place. And thou wilt behold the wrong- doers when they behold the torment saying: is there Unto return any way?

# 4317

And thou wilt behold them set up before it, downcast with ingominy ond looking with stealthy glance. And those who believe will say: verily the losers are they who have lost themselves and their housefolk on the Day of Resurrection. Lo! verily the wrong-doers will be in a a torment lasting.

# 4318

And they shall have no patrons succouring them beside Allah. And whomsoever Allah sendeth astray for him there will be no way.

# 4319

Answer the call of Your Lord afore there cometh Unto you a Day for which there is no averting from Allah. Ye will have no place of refuge on that Day, nor there will be for you any denying of Your guilt.

# 4320

If then they turn away, then We have not sent thee to be a warden over them, on thee is naught but preaching. And verily We! when We cause man to taste of mercy from Us he exulteth thereat; and if an ill befalleth them because of that which their hands have sent on, then verily man becometh ingrate.

# 4321

Allah's is the dominion of the heavens and the earth. He createth whatsoever He Will. He bestoweth females upon whomsoever He will, and bestoweth males upon whomsoever He Will.

# 4322

Or He conjoineth them males and females; and He maketh barren whomsoever He will; verily He is Knower, Petent.

# 4323

And it is not Possible for a human being that Allah should speak Unto him otherwise than by revelation or from behind a veil, or that He sendeth a messenger, so that he revealeth by His command whatsoever He will; verily He is Exalted, Wise.

# 4324

Even so We have revealed Unto thee a spirit of Our command; thou knewest not whatsoever the Book was, nor whatsoever the faith; We have made it a light wherewith We guide whomsoever We will of Our bondmen. And verily thou guidest Unto a straight path.

# 4325

The path of Allah, Whose is whatsoever is in the heavens and whatsoever is in the earth. Lo! Unto Allah trend all affairs.

# 4326

Ha. Mim.

# 4327

By this luminous Book.

# 4328

Verily We! We have made it an Arabic Qur'an that haply ye may reflect.

# 4329

And verily it is, in the Original Book before Us, indeed exalted.

# 4330

Shall We then take away from you the Admonition because ye are a people extravagant?

# 4331

And how many a prophet We sent among the ancients.

# 4332

And not a prophet came Unto them but him they were wont to mock.

# 4333

Wherefore We destroyed peoples mightier than these in prowess; and there hath gone forth the example of the ancients.

# 4334

And if thou askest them: who hath created the heavens and the earth? they will surely say: created them the Mighty, the Knower.

# 4335

Who hath made for you the earth a bed, and hath made for you paths therein that haply ye may be directed.

# 4336

And Who sendeth down from the heaven water in measure; then We quicken a dead land therewith: even so ye shall be brought forth.

# 4337

And Who hath treated the pairs, all of them, and appointed for you from ships and cattle things whereon ye ride.

# 4338

That ye mount firmly on the backs thereof, and then may remember the favour of your Lord When ye mount thereon, and may say: hallowed be He Who hath subjected this Unto us, and we for it were not fit.

# 4339

And verily Unto our Lord we are to return.

# 4340

And they appoint for Him from His bondmen a part! Verily man is an ingrate manifest.

# 4341

Hath He taken for Himself from whatsoever He hath created daughters, and hath honoured you with sons.

# 4342

And when there is announced Unto any of them the birth of that which he likeneth Unto the Compassionate, his countenance remaineth darkened the whole day and he is wroth inwardly."

# 4343

Hath He taken to Himself that which is reared in ornaments, and is in contention not plain?

# 4344

And they make the angels who are the bondmen of the Compassionate females. Have they witnessed their creation? Their testimony will be written down, and they will be questioned.

# 4345

And they say: had the Compassionate willed we should not have worshipped them. They have no knowledge thereof; they are only guessing.

# 4346

Have We vouchsafed Unto them any Book before this, so that they are to it holding fast?

# 4347

Nay! they say: verily we have found our fathers on a certain way, and verily by their footsteps we are guided.

# 4348

And in this wise We sent not before thee into any city a warner but the affluent thereof said: verily we! we found our fathers on a certain way and verily their footsteps we are following.

# 4349

The warner said: What! even though bring you a better guidance than that which ye found your fathers upon They said: verily in that wherewith ye are sent we are disbelievers.

# 4350

Wherefore We took revenge on them. Behold, then how hath been the end of the beliers?

# 4351

And recall what time Ibrahim said Unto his father and his people: verily I am quit of that which ye worship.

# 4352

Save Him Who hath created me, and then He would guide me.

# 4353

And he made it a word lasting among his posterity that haply they should return.

# 4354

Aye! I let these and their fathers enjoy life, until there hath come Unto them the truth and an apostle manifest.

# 4355

And when the truth cometh Unto them, they say this is magic, and verily we are therein disbelievers.

# 4356

And they say: wherefore hath not this Qur'an been revealed to a man of the two cities who was great.

# 4357

Shall they apportion their Lord's mercy? It is We Who have apportioned among them their livelihood in the life of the War, and raised some of them over others in degrees, so that one of them may take another as a serf; and the mercy of thy Lord is better than that which they amass.

# 4358

And were it not that mankind would have become one community, We should make for those who disbelieve in the Compassionate roofs of silver for their houses and silver stair ways whereby they ascend.

# 4359

And silver doors for their houses, and silver couches whereon they recline,

# 4360

And ornament of gold. And yet all that would have been but a pro vision Of the life of the World; and the Hereafter with thy Lord is for the Godfearing.

# 4361

And whosoever blindeth himself to the admonition of the Compassionate, We assign Unto him a Satan, and he becometh his companion.

# 4362

And verily they hinder them from the way, whilst they deem that they are rightly guided.

# 4363

Until when he cometh Unto Us, he will say. Ah! would that there had been between me and thee, the distance of the east and the west an evil companion

# 4364

And it Will profit you not today, because ye have done wrong, that ye are in the torment sharers.

# 4365

Wherefore canst thou make the deaf to hear, or canst thou guide the blind or him who is is error manifest?

# 4366

And if We take thee away. We shall surely take vengeance on them.

# 4367

Or if We shew thee that wherewith We threaten them, verily We are going to prevail over them.

# 4368

Hold thou fast wherefore to that which is revealed Unto thee: verily thou art on the straight path. s

# 4369

And verily it is an admonition Unto thee and thy people; and presently ye will be questioned.

# 4370

And ask thou Our apostles whom We sent before thee: appointed We gods, beside the Compassionate, to be worshipped?

# 4371

And assuredly We sent Musa with Our signs Unto Fir'awn and his chiefs, and he said: verily I am an apostle of the Lord of the worlds.

# 4372

Then when he came Unto them with Our signs, behold! at them they were laughing.

# 4373

And not a sign We shewed them but it was greater than the like thereof; and We laid hold of them with the torment that haply they might turn.

# 4374

And they said: magician! supplicate thy Lord for us for that which He hath covenanted with thee; verily we shall let ourselves be guided.

# 4375

Then When We had removed from them the torment, behold they were breaking their promise.

# 4376

And Fir'awn proclaimed among his people, saying: O my people! is not mine the dominion of Mis and witness yonder rivers flowing underneath me? See ye not?

# 4377

Aye! I am better than this one who is depicable, and well- nigh cannot make himself plain.

# 4378

Wherefore, then, have bracelets of gold not been set upon him, and wherefore have not angels come with him accompanying

# 4379

Then he incited his people and they obeyed him; verily they were ever a transgressing people.

# 4380

So when they vexed Us, We took vengeance on them, and We drowned them all.

# 4381

And We made them a precedent and an ensample Unto those after.

# 4382

And when the son of Maryam is held up, an example, behold! thy people thereat cry out.

# 4383

And they say: are our gods better, or is he? They mention him not to thee save for disputation. Aye! they are a people contentious.

# 4384

He is naught but a bondman: him We favoured, and him We made an ensample Unto the Children of Israil.

# 4385

And had We willed We could have appointed angels born of you in the earth to succeed each other.

# 4386

And verily he is a sign of the Hour wherefore dubitate not thereof, and follow Me: this is the straight path.

# 4387

And let not the Satan hinder you; verily he is Unto you an enemy manifest.

# 4388

And when Isa came with; evidences, he said: of a surety I have come Unto you with Wisdom, and to expound Unto you some of that wherein ye differ; so fear Allah and obey me.

# 4389

Verily Allah! He is my lord and your Lord, so worship Him: this is the straight path.

# 4390

Then the sects differed among themselves. Woe then Unto those who do Wrong because of the torment of an afflictive Day.

# 4391

They await but the Hour: that it should come upon them of a sudden, while they perceive not.

# 4392

The intimate friends on that Day Will be hostile Unto one another save the God-fearing.

# 4393

O My bondmen! no fear shall be on you Today, nor shall ye grieve

# 4394

Ye who believed in Our revelations and were Muslims.

# 4395

Enter the Garden, ye and your spouses, joyfully.

# 4396

Passed round amongst them will be dishes of gold and goblets, and therein will be whatsoever souls desire and eyes delight in; and ye will be therein abiders.

# 4397

This is the Garden which ye have been made to inherit for that which ye have been working.

# 4398

For you therein will be fruits in plenty whereof ye will eat.

# 4399

Verily the culprits in Hell's torment will be abiders.

# 4400

It shall not be abated from off them, and they will be therein despondent.

# 4401

And We wronged them not, but they have been the wrong- doers themselves.

# 4402

And -they will cry: O keeper let thy Lord make an end of us. He will say: verily ye shall bide

# 4403

Assuredly We brought the truth Unto you, but most Of you are to the truth averse.

# 4404

Have they determined an affair? then verily We are also determining.

# 4405

Bethink they that We hear not their secrets and whispers? Yea! We do, and Our messengers present with them write down.

# 4406

Say thou: had the Compassionate a son, shall be the first of his worshippers.

# 4407

Hallowed be the Lord of the heavens and the earth, the Lord of the Throne, from that which they ascribe!

# 4408

So let them thou alone wading and sporting until hey meet the Day which they are promised.

# 4409

And He it is Who is God in the heavens and God in the earth, and He is the Wise, the Knower.

# 4410

And blest be He Whose is the dominion of the heavens and the earth and whatsoever is in-between the twain, and with Him is knowledge of the Hour, and Unto Him ye will be made to return.

# 4411

And those whom they call upon beside Him own not the power of intercession save those who have borne witness to the truth and who know.

# 4412

And wert thou to ask them who created them, they will surely say: God. Witherward then are they deviating!

# 4413

And We hear his saying: my Lord! verily these are a people who believe not.

# 4414

Wherefore turn thou aside from them, and say: peace. presently they shall come to know.

# 4415

Ha. Mim.

# 4416

By the luminious Book.

# 4417

Verily We have sent it down on a blessed night, verily We were to become warners.

# 4418

Therein is decreed every affair of wisdom

# 4419

As a command from before Us. Verily We were to become senders:

# 4420

A mercy from thy Lord. Verily He! He is the Hearer, the Knower.

# 4421

Lord of the heavens and the earth and whatsoever is in- between the twain, if only ye would be convinced.

# 4422

There is no god but He. He quickeneth and causeth to die: your Lord and Lord of your forefathers.

# 4423

Aye! they're in doubt sporting.

# 4424

So wait thou day whereon the heaven will bring forth a manifest smoke:

# 4425

Covering the people's this shall be a torment afflictive.

# 4426

Our Lord! remove from us the torment, verily we shall become believers.

# 4427

How can there be an admonition Unto them, when surely there came Unto them an apostle manifest!

# 4428

Yet they turned away from him and said: one tutored, one distraced.

# 4429

Verily We shall remove the torment for a while; but verily ye shall revert.

# 4430

On the Day whereon We assault them with the greatest assault, verily We shall take vengeance.

# 4431

And assuredly afore them We proved Fir'awn's people, and there came Unto them an apostle honoured.

# 4432

Saying: restore to me the bondmen of Allah, verily I am Unto you an apostle trusted.

# 4433

And saying exalt not yourselves against Allah; verily I have come Unto you with an authority manifest.

# 4434

And verily I have sought refuge in my Lord and your Lord lest ye stone me.

# 4435

And if ye will not believe in me, then let me alone.

# 4436

Then he called upon his Lord. these are a people guilty.

# 4437

So depart thou with My bondmen by night; verily ye shall be pursued.

# 4438

And leave thou the sea divided: verily they are a host to be drowned.

# 4439

They left - how many! - of gardens and springs.

# 4440

And cornfields and goodly positions.

# 4441

And the delights which they had been enjoying!

# 4442

Even so And We caused to inherit them another people.

# 4443

And the heavens and the earth wept not over them, nor were they respited.

# 4444

And assuredly We delivered the Children of Isra'il from an ignominous torment

# 4445

From Fir'awn; verily he was haughty and of the extravagant.

# 4446

And assuredly We elected them with knowledge above the worlds.

# 4447

And We vouchsafed Unto them signs wherein was a manifest favour.

# 4448

Verily these! they say:

# 4449

There is naught but our first death, and we shall not be raised again.

# 4450

Bring then our fathers if ye say so.

# 4451

Are they better Or the people of Tubba and those afore them? We destroyed them; verily they were culprits.

# 4452

And We created not the heavens and the earth and all that is in-between the twain sporting.

# 4453

We created them not save with a purpose but most of them know not.

# 4454

Verily the Day of Distinction is the term appointed for all of them.

# 4455

A Day whereon a friend shall not avail a friend at all, nor shall they be helped.

# 4456

Save those on whom Allah will have mercy. Verily He! He is the Mighty, the Merciful.

# 4457

Verily the tree of Zaqqum:

# 4458

Food of the sinner.

# 4459

Like the dregs of all! It shall seethe in the bellies:

# 4460

As the seething of boiling water.

# 4461

Lay hold of him, and drag him Unto the midst of the Flaming Fire.

# 4462

Then pour upon his head the torment of balling water.

# 4463

Taste thou! thou art indeed mighty, honoured!

# 4464

Verily this is that whereof ye were wont to doubt.

# 4465

Verily the God-fearing will be in a place secure

# 4466

Amidst gardens and springs.

# 4467

Attired in fine silk and brocade, facing each other.

# 4468

Even so. And We shall pair them with fair damsels large- eyed.

# 4469

They will call therein for every kind of fruit in security.

# 4470

They will not taste death therein, except the first death; and He will preserve them from the torment of the Flaming Fire.

# 4471

A bounty from thy Lord. That! that is the supreme achievement.

# 4472

And We have made it easy in thy language; they might haply be admonished.

# 4473

Wait thou then; verily they also are waiting.

# 4474

Ha. Mim.

# 4475

The revelation of the Book is from Allah, the Mighty, the Wise.

# 4476

Verily in the heavens and the earth are signs Unto the believers.

# 4477

And in the creation of yourselves and of the beasts that He hath scattered over the earth, are signs Unto a people who are convinced.

# 4478

And in the alternation of night and day and that which Allah sendeth down of provision from the heaven and thereby quickeneth the earth after the death thereof and the turning about of the winds, are signs Unto a people who reflect.

# 4479

These are the revelations of Allah which We rehearse Unto thee with truth: in what discourse then, after Allah and His revelations, will they believe?

# 4480

Woe Unto every liar, sinner!

# 4481

Who heareth the revelations of Allah rehearsed Unto him, and yet persisteth with stiff-neckedness as though he heard them not. Announce thou Unto him, then, a torment afflictive.

# 4482

And when he cometh to know aught of Our revelations, he taketh it scoffingly. These! theirs shall be a torment ignominous;

# 4483

Before them is Hell; naught will avail them of that which they earned, nor those whom they took for patrons beside Allah. Theirs shall be a torment mighty.

# 4484

This Book is guidance, and those who disbelieve in the revelations of their Lord, theirs shall be torment of calamity, afflictive.

# 4485

Allah it is Who hath subjected the sea for your sake, that the ships may run thereon by His command and that ye may seek of His grace, and that haply ye may return thanks.

# 4486

And He hath subjected for your sake whatsoever is in the heavens and whatsoever is in the earth, the whole from Himself. Verily herein are signs Unto a people who ponder.

# 4487

Say thou Unto those who believe, let them forgive those who hope not for the days of Allah, that He may requite a community for that which they have been earning.

# 4488

Whosoever worketh righteously, worketh for himself; and whosoever doth evil, doth against himself; then Unto your Lord ye will be made to return.

# 4489

And assuredly. We vouchsafed Unto the Children of Israil the Book and the wisdom and the propherhood, and We provided them with good things and preferred them above the worlds.

# 4490

And We vouchsafed Unto them evidences of the affair. And they differed not except after the knowledge had come Unto them, through spite among themselves. Verily thy Lord will decide between them on the DaY of Judgment concerning that wherein they have been differing.

# 4491

And thereafter We have placed thee upon the law of the religion; so follow it thou, and follow not the vain desires of those who know not.

# 4492

Verily they cannot avail thee at all against Allah. And verily the wrong doers! friends are they one Unto another. And Allah is the Friend of the God-fearing.

# 4493

This Book is an enlightenment Unto mankind and a guidance, and a mercy Unto a People who are convinced.

# 4494

Deem those who commit ill deeds that We shall make them as those who believe and work righteous Works? Equal is their life and their death! How ill they judge!

# 4495

And Allah hath created the heavens and the earth with purpose and that every soul may be recompensed for that which it hath earned. And they will not be wronged.

# 4496

Beholdest thou him who taketh for his god his own vain desire, and Allah hath sent him astray despite his knowledge, and hath sealed up his hearing and his heart, and hath set on his sight a covering? Who will guide him after Allah? Will ye not then be admonished?

# 4497

And they say: there is no naught but our life of the world; die and we live; and naught destroyeth us save Time. And they have no knowledge thereof: they do but guess.

# 4498

And when Our manifest revelations are rehearsed Unto them, their argument is no other than that they say bring our fathers, if ye say sooth.

# 4499

Say thou: Allah keepeth you alive, then He shall cause you to die, then He shall assemble you on the Day of Resurrection whereof there is no doubt; but most of mankind know not.

# 4500

And Allah's is the dominion of the heavens and the earth; and on the Day whereon the Hour arriveth, then shall lose the followers of falsehood.

# 4501

And thou shalt behold each community kneeling; each community shall be summoned to its Book. Today, shall be recompensed for that which ye have been working.

# 4502

This Book of Ours speaketh against you with truth; verily We have been setting down whatsoever ye have been working.

# 4503

Then, as for those who believed and worked righteous works, their Lord will cause them to enter into His mercy: that is a manifest achievement.

# 4504

And as for those who disbelieved: Were not My revelations rehearsed Unto you? but ye were stiff necked, and ye were a people guilty.

# 4505

And when it was said; verily Allah's promise is, true, and the Hour! there is no doubt thereof, ye said: we know not what the Hour is, we imagine it naught but an opinion, and we are not convinced.

# 4506

And there will appear Unto them the evils Of that which they had worked, and there will surround them that whereat they had been mocking.

# 4507

And it will be said: Today shall forget you, even as ye forgat the meeting of this your Day, and your abode will be the Fire, and none ye will have as helpers.

# 4508

That is because ye took the revelations of Allah scoffingly, and there beguiled you the life of the world. Today, therefore, they will not be taken forth therefrom, nor will they be suffered to please Allah.

# 4509

All praise, then, Unto Allah, Lord of the heavens and Lord of the earth, Lord of the worlds.

# 4510

And His alone is the Majesty in the heavens and the earth, and He is the Mighty, the Wise.

# 4511

Ha. Mim.

# 4512

The revelation of the Book is from Allah, the Mighty, the Wise.

# 4513

We created not the heavens and the earth and whatsoever is in-between the twain save with truth, and for a term stated. And those who disbelieve are from that whereof they are warned backsliders.

# 4514

Say thou: bethink ye: whatsoever ye call upon beside Allah- show me whatsoever they have created of the earth? Or have they any partnership in the heavens? Bring me a Book before this, Or some trace of knowledges if ye say sooth.

# 4515

And who is more astray than he who calleth beside Allah, Unto such as will answer it not till the Day of Resurrection and who are of their call unaware.

# 4516

And when mankind will be gathered they will become Unto them enemies and of their worship they will become deniers.

# 4517

And when Our manifest revelations are rehearsed Unto them those who disbelieve say of the truth when it hath come to them: this is magic manifest.

# 4518

Say they: he hath fabricated it. Say thou: if I have fabricated it, then ye cannot avail me against Allah in aught. He is the Knower of that which ye utter thereof; He sufficeth as a witness between me and you; and He is Forgiving, Merciful.

# 4519

Say thou: I am not an innovator among the apostles, nor I know whatsoever shall be done with me or with you; I only follow that which is revealed Unto me, and am but a warner manifest.

# 4520

Say thou: bethink ye: if it is from Allah while ye disbelieve therein and a witness from the Children of Isra'il beareth witness to the like thereof and believeth, while ye are still stiff necked, then who is further astray than you? Verily Allah guideth not a wrong-doing people.

# 4521

And those who disbelieve say of those who believe: had it been good, they would not have preceded us thereto. And when they have not let themselves be guided thereby, they say: this is an ancient falsehood.

# 4522

And before it there hath been the Book of Musa, a guide and a mercy. And this a Book confirming it, in Arabic speech, that it may warn those who have done wrong and as glad tidings Unto the well-doers.

# 4523

Verily those who say: our Lord is Allah, and thereafter stand fast thereto, no fear shall come upon them, nor shall they grieve.

# 4524

Those are the fellows of the Carden: abiders therein: a recompense for that which they have been working.

# 4525

And We have enjoined upon man kindness Unto the parents: with hardship his mother beareth him and with hardship she bringeth him forth, and the bearing of him and the weaning of him is thirty months, until, when he attaineth his full strength and attaineth the age of forty years, he saith: my Lord! grant me that may give thanks for the favour wherewith. Thou hast favoured me and my parents and that may work righteously such as Thou mayest approve; and be Thou good Unto me in my progeny, verily have turned Unto Thee repentant, and verily I am of those who submit.

# 4526

Those are they from whom We shall accept the best of that which they have worked, and their misdeeds We shall pass by: among the fellows of the Garden: a true promise this, which they have been promised.

# 4527

And he who saith Unto his parents: fie upon you both! threaten me ye that I shall be taken forth, whereas generations have passed away before me? and the twain implore Allah's assistance woe Unto thee! come to believe! verily the promise of Allah is true; yet he saith: naught is this but fables of the ancients."

# 4528

Those are they upon whom hath been justified the saying about the communities of the Jinn and mankind who have passed away before them; verily they are ever the losers.

# 4529

And for each are ranks according to that which they have worked, that He may repay them in full for their works; and they shall not be wronged.

# 4530

And on the Day whereon those who disbelieve shall be placed before the Fire: ye made away with your good things in your life of the world, and ye enjoyed yourselves therewith so Today ye shall be requited with the torment of ignominy, for that ye have been growing stiff-necked on the earth without justification, and for that ye have been transgressing.

# 4531

And remember thou the brother of the Aad when We warned his people in the sandhills - and surely there have passed away warners before him and after him - saying: worship none save Allah, verily I fear for you the torment of a mighty Day.

# 4532

They said: art thou come Unto us that thou mayest turn us aside from our gods? then bring thou upon us that wherewith thou threatenest us, if thou art of the truth-tellers.

# 4533

He said: the knowledge is only with Allah, and I preach Unto you that wherewith I have been sent, but I see you are a people given to ignorance.

# 4534

Then when they beheld it as an overpeering cloud tending toward their valleys they said: yonder is an overpeering cloud bringing us rain. Nay it is that which ye sought to be hastened: a wind wherein is a torment afflictive.

# 4535

It shall annihilate everything by the command of its Lord. Wherefore they became such that naught could be seen save their dwellings Thus We requite a nation of the culprits.

# 4536

And assuredly We had established them in that flourishing condition wherein We have not established you, and We had appointed for them hearing and sight and hearts; yet their hearing and sight and heart availed them not at all, they became wont to gainsay the revelations of Allah, and surrounded them that whereat they had been mocking.

# 4537

And assuredly We have destroyed the cities round about you. and We have variously propounded our signs, that haply they might return.

# 4538

Then wherefore succoured them not those whom they had taken for gods beside Allah, as a means of approach? Aye! they failed them. And that was their lie, that which they had been fabricating.

# 4539

And recall what time We turned towards thee a company Of the Jinns hearkening Unto the Qur'an. So when they came in the presence thereof they said: give ear. Then when it was ended, they turned back to their people as warners.

# 4540

They said: O our people! verily we have hearkened Unto a Book sent down after Musa, confirming that which was before it, guiding Unto the truth and a straight path.

# 4541

O our people! answer Allah's summoner and believe in him; He shall forgive you your sins and shall shelter you from a torment afflictive.

# 4542

And whosoever answereth not Allah's summoner, he cannot frustrate His vengeAnce on the earth, and for him there will be, beside Him, no patrons. Those are in error manifest.

# 4543

Bethink they not that Allah Who created the heavens and the earth and was not fatigued with the creation thereof, is able to quicken the dead? Aye! verily He is over everything Potent.

# 4544

And on the Day whereon those who disbelieve will be placed before the Fire: is this not real? They will say: yea, by our Lord. He will say: taste wherefore the torment, for ye have been disbelieving.

# 4545

Bear thou then with patience even as the apostles, endued with resolution bear with patience, and seek not to hasten on for them. On the Day whereon they will behold that wherewith they are threatened, it will seem to them as though they had tarried but an hour of the day. A proclamation this: so none will be destroyed save the nation of transgressors.

# 4546

Those who disbelieve and hinder others from the way of Allah, He shall send their works astray.

# 4547

And those who believe and work righteous works and believe in that which hath been revealed Unto Muhammad -and it is the truth from their Lord- He shall expiate their misdeeds from them and shall make good their state.

# 4548

That is because those who disbelieve follow the falsehood, and those who believe follow the truth from their Lord. And thus Allah propoundeth Unto mankind their similitude.

# 4549

Now when ye meet those who disbelieve, smite their necks until when ye have slain them greatly, then make fast the bonds; then, thereafter let them off either freely or by ransom, until the war layeth down the burthens thereof. That ye shall do. And had Allah willed, He would have vindicated Himself against them, but He ordained fighting in order that He may prove you one by the other. And those who are slain in the way of Allah, He shall not send their works astray.

# 4550

Anon He shall guide them, and shall make good their state.

# 4551

And He shall make them enter the Garden; He shall have made it known, Unto them.

# 4552

O ye who believe! if ye and shall succour Allah, He shall succour you make firm your feet.

# 4553

And those who disbelieve, downfall shall be theirs, and He shall send astray their Works.

# 4554

That is because they detest that which Allah hath sent down, and so He shall make of non-effect their works.

# 4555

Have they not travelled then on the earth so that they might see how hath been the end of those before them! Allah annihilated them. And for the infidels theirs shall be the like fate therefore.

# 4556

That is because Allah is the patron of those who believe, and because the infidels! no patron is theirs.

# 4557

Verily Allah shall cause those who believe and work righteous works to enter Gardens whereunder rivers flow. And those who disbelieve enjoy themselves and eat even as the cattle eat, and the Fire shall be the abode for them.

# 4558

And many a city, mightier In strength than the city which drave thee forth, We destroyed them, and there was no helper of theirs.

# 4559

Is he then who standeth, on an evidence from his Lord like Unto him whose evil of work is made fair-seeming for him and those who follow their lusts?

# 4560

A likeness of the Garden which hath been promised to the God-fearing: therein are rivers of water incorruptible, and rivers of milk whereof the flavour changeth not, and rivers of wine: a joy Unto the drinkers; and rivers of honey clarified. theirs therein shall be every kind of fruit, and forgiveness from their Lord. ShAll Persons enjoying such bliss be like Unto those who are abiders in the Fire and are given to drink boiling water so that it mangleth their entrails?

# 4561

Of them are some who listen to thee, until, when they go forth from before thee, they say Unto those who have been vouchsafed knowledge, what is that he hath said just now? Those are they whose hearts Allah hath sealed up and they follow their lusts.

# 4562

And those who are guided He increaseth Unto them guidance, and giveth them their piety.

# 4563

Await they but the Hour, that it should come upon them on a sudden? Tokens thereof are already come, so how shall it be with them when there cometh Unto them their admonition!

# 4564

So know thou that there is no god save Allah, and ask forgiveness for thy fault and for believing men and believing women. And Allah knoweth well your moving about and your place of rest.

# 4565

And those who believe say wherefore hath not a Surah been revealed? Then when there is sent down a Surah firmly constructed, and fighting is mentioned therein, thou seest those in whose hearts is a disease looking at thee with the look of one swooning Unto death. So also for them!

# 4566

Their obedience and speech are known. Then when the affair is determined, if even then they gave credence Unto Allah, it would have been better for them.

# 4567

Then, belike ye are, if ye turn to cause corruption in the earth away, and to sever your kinship.

# 4568

Those are they whom Allah hath cursed, and then hath deafened them and blinded their sights.

# 4569

Ponder then they not on the Qur'an, or are on the hearts locks thereof?

# 4570

Verily those who have apostated on their backs after the guidance had become manifest Unto them, the devil hath embellished this apostacy for them and hath given them false hopes.

# 4571

That is because they said Unto those who detest that which Allah hath revealed: we shall obey you in part of the affair; and Allah knoweth their talking in secret.

# 4572

How then shall it be when the angels shall take them away at death smiting their faces and their backs!

# 4573

That is because they followed that which angered Allah and detested His good-will; so He made their works of non-effect.

# 4574

Deem those in whose hearts is a disease that Allah will never bring to light their secret malevolence?

# 4575

And if We willed, We would surely shew them Unto thee, so that thou shouldst surely know them by their marks. And thou shalt surely know them by the mode of their speech. And Allah knoweth your works.

# 4576

And of a surety We shall prove you all until We know the strivers among you and the steadfast, and We shall prove your states.

# 4577

Verily those who have disbelieved and have hindered others from the way of Allah and have opposed the apostle after the guidance had become manifest Unto them, shall not hurt Allah at all, and anon He shall render their works of non effect.

# 4578

Ye who believe! obey Allah and obey the apostle, and render not Your works vain.

# 4579

Verily those who disbelieve and hinder others from the way of Allah and then die as infidels, Allah shall by no means forgive them.

# 4580

Wherefore faint not, nor cry out for peace; and ye shall be triumphant. And Allah is with you, and He will not defraud you of your works.

# 4581

The life of the world is but a sport and a pastime. And if ye believe and fear, He will give you your hire, and will not require of you your substance.

# 4582

If He required it of you and importuned you, ye would be niggardly, and He will bring to light your secret malevolence.

# 4583

Behold! ye are those who are called to expend in the way of Allah, then there are of you some who are niggardly. And whosoever is niggardly is niggardly only to himself. And Allah is Self-sufficient, and ye are the needy. And if ye turn away, He will substitute for you another people, and then they will not be the likes of you.

# 4584

Verily We! a victory We have given thee, a manifest victory.

# 4585

That Allah may forgive thee that which hath preceded of thy fault and that which may come later, and may accomplish the more His favour on thee, and may keep thee guided on the straight path.

# 4586

And that Allah may succour thee with a mighty succour.

# 4587

He it is Who sent down tranquillity into the hearts of the believers that they might increase belief Unto their belief. And Allah's are the hosts of the heavens and the earth and Allah is ever Knowing, Wise.

# 4588

He hath ordained war in order that He may cause the believing men and the believing women enter Gardens whereunder rivers flow, as abiders therein, and that He may expiate from them their misdeeds. And that is with Allah ever an achievement mighty.

# 4589

And that He may chastise the hypocritical men and the hypocritical women and the associaters and the associatresses, the thinkers of evil thought concerning Allah. Unto them shall befell the evil turn of fortune, and Allah shall be wroth with them and shall curse them, and He hath gotten ready for them Hell: an ill destination!

# 4590

And Allah's are the hosts of the heavens and the earth, and Allah is ever Mighty, Wise.

# 4591

Verily We! We have sent thee as a witness and a bearer of glad tidings and a warner.

# 4592

That ye may believe in Allah and His apostle, and may assist Him and honour Him, and may hallow Him at dawn and evening.

# 4593

Verily those who swear fealty Unto thee, only swear fealty Unto Allah: the hand of Allah is over their hands. So whosoever breaketh his oath, breaketh it only to his soul's hurt; and whosoever fulfilleth that which he hath convenanted with Allah, him anon He shall give a mighty hire.

# 4594

Those who lagged behind of the desert Arabs Will presently say Unto thee: our properties and our households kept us occupied, so ask thou forgiveness for Us. They say with their tongues that which is not in their hearts. Say thou: who can avail you in aught against Allah, if He intended you hurt or intended you benefit? Yea! Allah is of that which ye work ever Aware.

# 4595

Yea! ye imagined that the apostle and the believers would never return to their households, and that became fair-seeming in your hearts, and ye bethought an evil thought, and ye became a people doomed.

# 4596

And whosoever believeth not in Allah and His apostle then verily We have gotten ready for the infidels a Blaze.

# 4597

And Allah's is the dominion of the heavens and the earth. He forgivEth whomsoever He Will and tormenteth whomsoever he will; and Allah is ever Forgiving, Merciful.

# 4598

Those who lagged behind will presently, When ye march forth to take spoils, leave us, we shall follow say you. They intend to change the word of Allah. Say thou: ye shall by no means follow us; thus hath Allah said afore. Then they will say: Aye! ye envy us. Aye! little it is they are wont to understand.

# 4599

Say thou Unto those who lagged behind of the desert Arabs: surely ye shall be summoned against a people endued with exceeding violence then ye will fight them or they will submit. Then if ye obey, Allah will give ye a goodly hire; but if ye turn away even as ye turned away aforetime. He will torment you with a torment afflictive.

# 4600

There is no blame upon the blind, nor is there blame upon the lame, nor is there blame upon the sick. And whosoever obeyeth Allah and His apostle, He will cause him enter Gardens where under rivers flow; and whosoever turneth away, him He shall torment with a torment afflictive.

# 4601

Assuredly well-pleased was Allah with the believers when they sware fealty Unto thee under the tree, and he knew that which was in their hearts, wherefore He sent down tranquillity on them, and rewarded them with a victory near at hand.

# 4602

And spoils in abundance that they are taking. And Allah is ever Mighty, Wise.

# 4603

Allah hath promised you abundant spoils that ye shall take, and these He hath hastened to you, and hath restrained the hands of people from you, that it may be a sign Unto the believers, and that He may guide you to a straight path.

# 4604

And He promiseth another victory, over which ye have as yet no power: Allah hath surely encompassed it; and Allah is over everything ever Potent.

# 4605

And had those who disbelieve fought against you, surely they would have turned their backs, and then they would have found no patron nor helper.

# 4606

That hath been the dispensation of Allah with those who passed away aforetime; and thou shalt not find in the dispensation of Allah any change.

# 4607

And He it is Who restrained their hands from you and Your hands from them, in the vale of Makka so, after He had made you superior to them; and Allah is of that which ye work ever a Beholder.

# 4608

They were those who disbelieved and hindered you from the Sacred Mosque and hindered the detained offering that it should arrive at the goal thereof. And had it not been for believing men and believin women whom ye knew not, and that ye might have trampled on them and thus there might have befallen you crime on their account unwittingly. He had not restrained your hands from them. But this He did that He might bring into His mercy whomsoever He will. Had they been distinguished one from another, surely We had tormented those who disbelieved among them with a torment afflictive.

# 4609

When those who disbelieve had put in their hearts a zeal, the zeal of Paganism, then Allah sent down His tranquillity upon His apostle and upon the believers, and kept them fixed on the way of piety, and they were worthy thereof and meet therefor; and Allah is of everything ever Knower.

# 4610

Assuredly did Allah shew a true vision to His apostle in very truth; ye shall surely enter the Sacred Mosque, if Allah willeth, secure, having your heads shaven and your hair cut, and ye shall not fear. He knoweth that which ye know not; wherefore He appointed, beside that, a victory near at hand.

# 4611

He it is Who hath sent His apostle with the guidance and the true religion that He may make it prevail over all other religions, and Allah sufficeth as a Witness.

# 4612

Muhammad is the apostle of Allah. And those who are with him are stern against the infidels and merciful among themselves; Thou beholdest them bowing down and falling prostrate, seeking grace from Allah and His goodWill Mark of them is on their faces from the effect of prostration: such is their similitude in the Taurat. And their similitude in the lnjil: like Unto a sown corn that putteth forth its shoot and strengtheneth it, and swelieth, and riseth upon the stalk thereof delighting the sowers. Such are the early Muslims described that He may enrage the infidels with them. Allah hath promised Unto those among them who believe and work righteous works, forgiveness and a mighty hire.

# 4613

O ye who believe! be not forward in the presence of Allah and His apostle, and fear Allah; verily Allah is Hearing, Knowing.

# 4614

Ye who believe raise not your voices above the voice of the prophet, nor shout loud Unto him in discourse as ye shout loud Unto one another, lest your works may be rendered of non-effect, while ye perceive not.

# 4615

Verily those who lower their voices in the presence of the apostle of Allah -those are they whose hearts Allah hath disposed Unto piety: theirs will be forgiveness and a mighty hire.

# 4616

Verily those who call aloud Unto thee from without the inner apartments, most of them reflect not."

# 4617

And had they had patience till thou camest forth Unto them, it had surely been best for them; and Allah is Forgiving, Merciful.

# 4618

ye who believe! if an evil-doer Came Unto you with a report, then inquire strictly, lest ye hurt a people in ignorance and repent thereafter of that which ye have done.

# 4619

And know that verily among you is the apostle of Allah. Were he to obey you in many affairs, ye would surely be in trouble but Allah hath endeared belief to you and hath made it fair-seeming in your hearts, and hath rendered detestable Unto you infidelity and wickedness and disobedience. These! they are the men of rectitude.

# 4620

Through grace from Allah and His favour; and Allah is Knowing, Wise.

# 4621

And if two parties of the believers fall to mutual fighting, then make reconciliation between the twain. Then if one of them rebelleth against the other, fight that Party which rebelleth till it returneth Unto the affair of Allah; then if it returneth, make reconciliation between the twain with justice and be equitable; verily Allah loveth the equitable.

# 4622

The believers are but brethren; wherefore make reconciliation between your brethren and fear Allah, that haply ye may be shewn mercy.

# 4623

O ye who believe! let not one group scoff at another group, belike they may be better than they are, nor let some women scoff at other women, belike they may be better than they are. And traduce not one another, nor revile one another by odious appellations! ill is the name of sin after belief. And whosoever will not repent, then those, they are the wrong-doers.

# 4624

O ye who believe! avoid much suspicion; verily some suspicion is a sin. And espy not, nor backbite one another: would any of you love to eat the flesh of his dead brother? Ye detest that. And fear Allah verily Allah is Relenting, Merciful.

# 4625

O Humankind verily We! We have created you Of a male and female, and We have made you nations and tribes that ye might know one another. Verily the noblest of you with Allah is the most God-fearing of you; verily Allah is Knowing, Aware,

# 4626

The desert Arabs say: we have believed. Say thou: believe not, but rather say: We have submitted; and belief hath not yet entered into your hearts. And if ye obey Allah and His apostle, He shall not diminish from you aught Of you, wOrks verily Allah is Forgiving, Merciful.

# 4627

The believers are only those who believed in Allah and His apostle and thereafter doubted not, and strave with their riches and their persons in the cause of Allah. Those! they are the truthful.

# 4628

Say thou: Would ye appraise Allah of your religion, whereas Allah knoweth whatsoever is in the heavens and whatsoever is in the earth, and Allah is of everything Aware!

# 4629

They make it a favour Unto thee that they have surrendered. Say thou: deem not your surrender a favour Unto me; nay! Allah hath conferred a favour Unto you inasmuch as He hath guided you to belief, if ye are sincere.

# 4630

Verily Allah knoweth the Unseen of the heavens and the earth; and Allah is the Beholder of that which ye work.

# 4631

Qaf. By the Qur'an glorious, We have sent thee as a warner.

# 4632

Aye! they marvel that there hath come Unto them a warner from among themselves; so the infidels Say: this is a thing wondrous!

# 4633

Shell We be brought back when we are dead and have become dust? That is a return remote!

# 4634

Surely We know that which the earth consumeth of them, and with Us is, Book preserved.

# 4635

Aye! they belie the truth when it cometh Unto them; wherefore they are in an affair confused.

# 4636

Have they not looked up to the heaven above them, in what wise We have constructed and bedecked it, and that therein is no rift?

# 4637

And the earth! We have spread it forth, and have cast therein firm mountains, and have caused to grow therein of every beauteous kind of plants:

# 4638

An insight and an admonition for every bondman penitent.

# 4639

And We have sent down from the heaven water brest wherewith We have caused gardens to grow and the grain reaped.

# 4640

And tall date-palms laden with clusters ranged.

# 4641

As a provision for our bondmen; and therewith We have quickened a dead land. Even so will be the coming forth.

# 4642

And before them the people of Nuh belied, and so did the dwellers Of Rass and the Thamud.

# 4643

And the A-ad, and Fir'awn. and the brethren of Lut.

# 4644

And the dwellers in the wood, and the people of Tubba. Each one belied the apostles, wherefore fulfilled was My judgement.

# 4645

Are We then wearied with the first creation? Aye! they are in dubiety regarding a new creation.

# 4646

And assuredly We have created man and We know whatsoever his soul whispereth Unto him, and We are nigher Unto him than his jugular vein.

# 4647

Behold! when the two receivers receive-one on the right hand and one on the left a sitter.

# 4648

Not a word he uttereth but there is with him a watcher ready.

# 4649

And the stupor of death will come in truth: this is that which thou hast been shunning.

# 4650

And the trumpet will be blown: this is the Day of the Threatening.

# 4651

And there shall come every soul therewith shall be a driver and a witness.

# 4652

Assuredly thou wast in neglect thereof; now We have removed from off thee thy veil, so thy sight Today is piercing.

# 4653

And his companion will say: this is that which with me is ready.

# 4654

Cast ye twain into Hell every Person rebellious, contumacious.

# 4655

Hinderer o fgood, trespasser, doubter

# 4656

Who set up with Allah another god. So cast him ye twain into the torment severe.

# 4657

His companion will say: O our Lord! caused him not to transgress but he was himself in error far off.

# 4658

Allah will say: wrangle not in My presence, and had already proferred Unto you the threat.

# 4659

The Word will not be changed in My presence, nor am an oppressor at all Unto My bondmen.

# 4660

Mention the Day whereon We shall say Unto the Hell: art thou filled? and it will say: is there yet any addition?

# 4661

And brought nigh will be the Garden Unto the God-fearing, not far-off.

# 4662

This is that which ye were promised: for every oft- returning heedful one.

# 4663

That feareth the Compassionate in the unseen and cometh to Him with a heart penitent:

# 4664

Enter it in peace. This is the Day of Abidence.

# 4665

Theirs therein will be whatsoever they list; and with Us will be yet more.

# 4666

And how many a generation have We destroyed before them, who were mightier in power than they, and they traversed the cities! No place of refuge could they find.

# 4667

Verily herein is an admonition Unto him who hath a heart, or giveth ear while he is heedful.

# 4668

And assuredly We created the heavens and the earth and whatsoever is in between the twain in six days, and there touched Us naught of weariness.

# 4669

So bear thou patiently with that which they say, and hallow the praise of thine Lord before the rising of the sun and before its setting.

# 4670

And in the night-time hallow Him, and also after the prescribed prostration.

# 4671

And hearken thou: the Day whereon the caller will call from a place quite near.

# 4672

The Day whereon they will surely hear the shout - that is the Day of coming forth.

# 4673

Verily We! it is We Who give life and cause death, and Unto Us is the journeying.

# 4674

That shall be the Day whereon the earth will be cleft from off them as they hasten forth. That shall be a gathering Unto Us easy.

# 4675

We are the best Knower of that which they say, and thou art not over them over them tyrant. Wherefore admonish thou by the Qur'an him who feareth My threat.

# 4676

By the dipersing winds that disperse.

# 4677

And the clouds bearing a load.

# 4678

And the ships that glide with ease.

# 4679

And the angels who distribute the affair.

# 4680

Verily that wherewith ye are threatened is surely true.

# 4681

And verily the Requital is surely to befall.

# 4682

By the heaven full of paths.

# 4683

Verily ye are in a divided opinion.

# 4684

Turned aside therefrom is who is turned aside.

# 4685

Perish the conjecturers

# 4686

Those who are in heedlessness neglectful.

# 4687

They ask: when is the Day of Requital coming?

# 4688

It will be the Day whereon in the Fire they will be burned

# 4689

Taste your burning: this is that which ye sought to be hastened.

# 4690

Verily the God-fearing will be amid Gardens and water- springs.

# 4691

Taking that which their Lord will vouchsafe Unto hem. Verily they have been before that well-doers.

# 4692

Little of the night they were wont to slumber.

# 4693

And in the dawns they prayed for forgiveness.

# 4694

And in their substance was the right of the beggar and non- beggar.

# 4695

And on the earth there are signs for those who would be convinced.

# 4696

And also in Your own selves. Behold ye not?

# 4697

And in the heaven is Your provision and that which ye are promised.

# 4698

By the Lord of the heaven and the earth it is sure, even as it is a fact that ye are speaking.

# 4699

Hath there come Unto thee the story of Ibrahim's honoured guests?

# 4700

When they came in Unto him, and said:'peace!' he said: 'peace'! - people unknown.

# 4701

Then he turned away privately Unto his household, and brought a calf fatted.

# 4702

And he set it before them, and said: wherefore eat ye not?

# 4703

Then he conceived a fear of them. They said: fear not. And they gave him the tidings of a youth knowing.

# 4704

Then his wife drew near vociferating, and smote her face, and said: an old barren woman!

# 4705

They said: even so saith thine Lords Verily He! He is the Wise, the Knower.

# 4706

He said: what then is your errand! O ye sent ones!

# 4707

They said: verily we are sent Unto a people, guilty.

# 4708

That we may send down upon them stones of baked clay.

# 4709

Marked, from before thy Lord, for extravagant.

# 4710

Thus We brought forth from there in who were believers.

# 4711

And We found not therein more than one house of the Muslims.

# 4712

And We left therein a sign for those who fear the afflictive torment.

# 4713

And in Musa also was a lesson, when We sent him Unto Fir'awn with authority manifest.

# 4714

Then he turned away with his court, and said: a magician or a madman.

# 4715

Then We laid hold of him and his hosts and flung them into the sea, and he was reproachable.

# 4716

And in \`A-ad also was a lesson, when We sent against them the barren wind.

# 4717

It left not aught whereon it came but it made it as matter decayed.

# 4718

And in Thamud's also was a lesson, when it was said Unto them: enjoy yourselves for a season.

# 4719

Then they disdained the command of their Lord; wherefore the bolt laid hold of them even while they looked on.

# 4720

So they were not able to stand, nor could they help themselves.

# 4721

And the people of Nuh We destroyed aforetime; verily they were a people transgressing.

# 4722

And the heaven! We have built it with might, and verily We are powerful.

# 4723

And the earth! We have stretched it forth beneath; an excellent Spreader are We!

# 4724

And of every thing We have created pairs, that haply ye may remember.

# 4725

Flee therefore Unto Allah; verily I am Unto you from Him a warner manifest.

# 4726

And set not up another god with Allah; verily I am Unto you from Him a warner manifest.

# 4727

Likewise, there came not an apostle Unto those before them but they said: a magician or a madman!

# 4728

Have they bequeathed its Unto each other! Nay! they are a people contumacious.

# 4729

So turn away thou from them, not thou art blameworthy.

# 4730

And admonish, for verily admonition profiteth the believers.

# 4731

And have not created the Jinn and mankind but that they should worship Me.

# 4732

I seek not any provision from them, nor I desire that they should feed Me.

# 4733

Verily Allah! He is the Provider, Owner of power, Firm.

# 4734

So verily Unto those who do wrong there is a portion like Unto the portion of their fellows; wherefore let them not ask Me to hasten on.

# 4735

Woe, then, Unto those who disbelieve in their Day which they are promised.

# 4736

By the mount.

# 4737

By the book inscribed.

# 4738

In parchment unrolled.

# 4739

By the House Frequented.

# 4740

By the roof elevated.

# 4741

By the sea overflowing.

# 4742

Verily the torment of thine Lord is sure to befalls

# 4743

Of it there is no averter.

# 4744

On the Day whereon the heaven will shake with an awful shaking.

# 4745

And the mountains will move away with an awful movement.

# 4746

Woe, then, will be on that Day to the beliers

# 4747

Those who in wading sport themselves.

# 4748

On the Day whereon they will be pushed into Hell-Fire with a dreadful push.

# 4749

This is the Fire which ye were wont to believe.

# 4750

Is this magic? or ye still see not clearly!

# 4751

Roast therein; endure it or endure it not, thereof it is equal Unto you. Ye are only being requited for that which ye have been working.

# 4752

Verily the God-fearing will bein Gardens and Delight.

# 4753

Rejoicing in that which their Lord hath vouchsafed Unto them; and their Lord will protect them from the torment of the Flame.

# 4754

Eat and drink with relish for that which ye have been working.

# 4755

Reclining on couches ranged. And We shall couple them with maidens wide eyed.

# 4756

And those who believe and whose progeny follow them in belief. We shall cause their progeny to join them, and We shall not diminish Unto them aught of their own work. Every man is for that which he hath earned a pledge.

# 4757

And We shall increasingly give them fruit and meat such as they desire.

# 4758

They will therein snatch from one another a cup; therein will be neither vain babble nor sin.

# 4759

And there will go round on them youths appointed to attend them as though they were pearls hidden.

# 4760

And they will advance Unto each other asking questions.

# 4761

They will say: verily we were aforetime, midst our household, ever in dread.

# 4762

Wherefore Allah hath obliged us, and hath protected us from the torment of the Scorch.

# 4763

Verily we were wont to pray Unto Him aforetime; verily He! it is He, the Benign, the Merciful.'

# 4764

Wherefore admonish thou! thou art not, by the grace of thy Lord, a soothsayer or a madman.

# 4765

Or say they: a poet for whom we wait some adverse turn of fortune!

# 4766

Say thou: waits verily I am, with you, among the waiters.

# 4767

Enjoin them their understandings to this? or are they a people conumacious?

# 4768

Or say they: he hath fabricated it: aye they will not believe.

# 4769

Let them bring a discourse like thereUnto, if they say sooth.

# 4770

Have they not been created by aught, or are they the creators?

# 4771

Created they the heavens and the earth! Aye! they will not be convinced.

# 4772

Are with them the treasures of thy Lord! or are they the dispensers?

# 4773

Have they a stairway whereby they overhear? Then let their listener bring an authority manifest.

# 4774

Hath He daughters and ye sons?

# 4775

Or askest thou a hire from them so that they are with debt laden?

# 4776

Is with them the Unseen, and they write it down!

# 4777

Seek they to lay a plot? Then those who disbelieve it is they who shall be plotted against.

# 4778

Is theirs a god beside Allah? Hallowed be Allah from that which they associate!

# 4779

And if they should see a fragment of the heaven falling down, they would say: it is only clouds piled up.

# 4780

Wherefore let them alone, till they meet their Day whereon they shall swoon.

# 4781

A Day whereon their plotting will avail them not at all, nor will they be succoured.

# 4782

And verily for those who do wrong there is a torment before that; but most of them know not.

# 4783

And wait thou patiently the judgment of thy Lord; verily thou art before Our eyes; and hallow the praise of thy Lord when thou uprisest.

# 4784

And in the night also hallow Him, and at the setting of the stars.

# 4785

By the star when it setteth.

# 4786

Your companion hath not gone astray, nor hath he erred.

# 4787

And he speaketh not of his own desire.

# 4788

It is but a revelation revealed.

# 4789

One of mighty powers hath taught it him.

# 4790

One strong of make. Then he stood straight.

# 4791

While he was on the uppermost horizon.

# 4792

Thereafter he drew nigh, then he let himself down.

# 4793

Till he was two bows length off or yet nearer.

# 4794

Thus He revealed Unto His bondman whatsoever He revealed.

# 4795

The heart lied not in that which he saw.

# 4796

Will ye therefore dispute with him concerning that which he hath Seen?

# 4797

And assuredly he saw him at another descent.

# 4798

Nigh Unto the lote-tree at the boundary.

# 4799

Nigh thereto is the Garden of Abode.

# 4800

When that covered the lote-tree which covered it.

# 4801

The sight turned not aside, nor it exceeded.

# 4802

Assuredly he beheld of the sign of his Lord, the greatest.

# 4803

Have ye then considered Al-Lat and AL-'uzza:

# 4804

And Manat the other third?

# 4805

What!-Unto YOu the males and Unto Him the females?

# 4806

That indeed is a division unfair!

# 4807

They are but names which ye have named, ye and your fathers, for which Allah hath sent down no authority. They follow but their fancy, and that which pleaseth their souls; whereas assuredly there hath come Unto them from their Lord the guidance.

# 4808

Shall man have whatsoever he wisheth for!

# 4809

Allah's is the last and the first.

# 4810

And many soever are angels in the heavens whose intercession shall not avail at all save after Allah hath given leave for whomsoever He listeth and pleaseth.

# 4811

Verily those who believe not in the Hereafter name the angels with the names of females.

# 4812

And they have no knowledge thereof; they follow but a vain opinion, and verily a vain opinion attaineth not aught of the truth.

# 4813

Wherefore withdraw thou from him who turneth away from Our admonition and seeketh not but the life of the world.

# 4814

That is their highest point of knowledge. Verily thine Lord! it is He Who is the Best Knower of him who strayeth from His way, and He is the Best Knower of him who letteth himself be guided.

# 4815

And Allah's is whatsoever is in the heavens and whatsoever is in the earth, that He may recompense those who do evil for that which they worked and reward those who do good with good.

# 4816

They are those who avoid enormities of sin and abominations save the minor offences. Verily thy Lord is of vast for giveness: He is Best Knower of you when He produced you out Of the earth, and when ye were embryos in the bellies of your mothers. So justify not yourselves; He is the Best Knower of him who feareth Him.

# 4817

Observedest thou him who turned away?

# 4818

And gave little, and then stopped?

# 4819

Is with him knowledge of the unseen so that he seeth?

# 4820

Hath he not been told of that which is in the writs of Musa.

# 4821

And of Ibrahim who faithfully fulfilled?

# 4822

To wit, that a burthened soul shall not bear the burthen of another.

# 4823

And that for man shall be naught save that wherefor he endeavoureth.

# 4824

And that his endeavour shall be presently observed.

# 4825

Thereafter he shall be recompensed therefor with the fullest recompense.

# 4826

And that Unto thy Lord is the goal.

# 4827

And that it is He Who causeth to laugh and causeth to weep.

# 4828

And that it is He Who causeth to die and causeth to live.

# 4829

And that He createth the pair, the male and the female.

# 4830

From seed when it is emitted.

# 4831

And that upon Him is another bringing forth.

# 4832

And that it is He Who enricheth and preserveth property.

# 4833

And that it is He Who is the Lord of Sirius.

# 4834

And that He destroyed the former 'A-ad.

# 4835

And that Thamud! He left not.

# 4836

And also the people of Nuh aforetime. Verily they were even greater wrong-doers and more contumacious.

# 4837

And the subverted cities He overthrew.

# 4838

Then covered them with that which covered them.

# 4839

Which then of thy Lord's benefits wilt thou doubt?

# 4840

This is a warner of the warners of old.

# 4841

There hath approached the approaching Hour.

# 4842

None, except Allah, can avert it.

# 4843

At this discourse then marvel ye?

# 4844

And laugh and not weep?

# 4845

And ye are behaving proudly.

# 4846

So prostrate yourselves before Allah and worship.

# 4847

The Hour hath drawn nigh, and the moon hath been rent in sunder.. And if they behold a sign, they turn away and say: magic continuous.

# 4848

And if they behold a sign, they turn away and say: "magic continous"

# 4849

And they belied, and they followed their lusts; and every affair cometh to a final goal.

# 4850

And assuredly there hath come Unto them tidings wherein is a deterrent.

# 4851

Wisdom consummate. But warnings avail not.

# 4852

Wherefore withdrew thou from them. The Day whereon the sum- moner Will summon mankind Unto a thing unpleasant.

# 4853

With looks downcast they will come forth, from the tombs, as though they were locusts scattered abroad.

# 4854

Hastening toward the summoner. The infidels will say: this is a day diffrcult.

# 4855

There belied before them the people of Nuh. So they belied Our bondman Nuh and said: \`a madman;' and moreover he was reproven.

# 4856

Thereupon he prayed Unto his Lord: verily am overcome, so vindicate me.

# 4857

Then We opened the portals of heaven with water poured out.

# 4858

And We made the earth break forth with springs; SO that the water met for an affair already decreed.

# 4859

And We bare him on a thing of planks and nails.

# 4860

Moving forward under Our eyes: a requital for him who had been rejected.

# 4861

And assuredly We left it for a sign. Is there then anyone who would be admonished?

# 4862

So how dreadful have been My torment and My warning!

# 4863

And assuredly We have made the Qur'an easy for admonition; is there then any one who would be admonished?

# 4864

And there belied the 'A-ad; so how dreadful have been My torment and warning!

# 4865

Verily We! We sent against them a raging Wind On a day of calamity continuous.

# 4866

Carrying men away as though they were trunks of palm-trees uprooted.

# 4867

So how dreodful have been My torment and My warning.

# 4868

And assuredly We have made the Qur'an easy for admonition; is therethen any one who would be admonished!

# 4869

And the Thamud belied the warnings.

# 4870

And they said: a mere humanbeing from amongst us, and single! shall we follow him! verily then we should fall in error and madness.

# 4871

Hath the Admonition been laid upon him from amongst us! Aye! he is a liar insolent.

# 4872

They shall know tomorrow whichsoever is a liar insolent.

# 4873

Verify We are sending the she-camel as a test for them, so watch them thou and have patience.

# 4874

And declare thou Unto them that water hath been divided between them; every drinking shall be by turns.

# 4875

Then they called their fellow, and he took the sword and hamstrung her,

# 4876

So how dreadful have been My torment and My warnings.

# 4877

Verily We We sent upon them one shout, and they became as the stubble of a fold-builder.

# 4878

And assuredly We have made the Qur'an eary for admanirion: is there then any one who would be admonished.

# 4879

The people of Lut belied the warnings.

# 4880

Verily We! We sent upon them a gravel-storm save the household of Lut; them We delivered at early dawn.

# 4881

As a favour from us. Thus We recompense him who giveth thanks.

# 4882

And assuredly he had warned them of Our grasp, but: they doubted the warnings.

# 4883

And assuredly they solicited him for his guests: then We wiped out their eyes: taste then My torment and My warnings.

# 4884

And assuredly there met them early in the morning a torment settled.

# 4885

Taste then My torment and My warnings.

# 4886

And assuredly We have made the Qur'an easy for admonition; is there then any one who would be admonished.

# 4887

And assuredly Unto the household of Fir'awn came the warning.

# 4888

They belied Our signs everyone thereof; whereof We laid hold of them with the grip of our Mighty, Powerful.

# 4889

Are your infidels better than these? Or is there an immunity for you in the Writs?

# 4890

Or is it that they say: we are a multitude prevailing!

# 4891

Anon will their multitude be vanquished, and they will turn the back.

# 4892

Aye! the Hour is their appointed term, and the Hour shall be far more grievous and far more bitter.

# 4893

Verily the culprits shall be in great error and madness.

# 4894

On the Day whereon they shall be dragged into the Fire upon their faces, it shall be said Unto them: taste the touch of the Scorching.

# 4895

Veriiy everything! We have created it by a measure.

# 4896

And Our commandment shall be but one, as the twinkling of an eye.

# 4897

And assuredly We have destroyed your likes; so is there any one who shall be admonished?

# 4898

And everything they have wrought is in the Writs.

# 4899

And everything, small and great, hath been written down.

# 4900

Verily the God-fearing will be in Gardens and among rivers.

# 4901

In a good seat, near a Sovereign Omnipotent.

# 4902

The Compassionate.

# 4903

Hath taught the Qur'an.

# 4904

He created man.

# 4905

He taught distinctness.

# 4906

The sun and the moon are in a reckoning.

# 4907

And the herbs and the trees do obe isance."

# 4908

And the heaven! He hath elevated it, and He hath set the balance.

# 4909

That ye should not trespass in respect of the balance.

# 4910

And observe the weight with equity, and make not deficient the balance.

# 4911

And the earth! He hath lain it out for the creatures.

# 4912

Therein are fruit and palm-trees sheathed.

# 4913

And grain chaffed and other food.

# 4914

Which, then, of the benefits of your Lord, will ye twain belie?

# 4915

He created man of clay like, Unto pottery.

# 4916

And He created the Jinn of a flame of fire.

# 4917

Which, then, of the benefits of your Lord will ye twain belie

# 4918

He is Lord of the two easts and Lord of the two wests.

# 4919

Which, then, of the benefits of your Lord will ye twain belie?

# 4920

He hath let loose the two seas.

# 4921

In-between the twain is a barrier which they pass not.

# 4922

Which, then, of the benefits of your Lord will ye twain belie?

# 4923

There come forth from the twain the pearl and the coral.

# 4924

Which, then, of the benefits of your Lord will ye twain belie?

# 4925

His are the ships with elevated sails upon the sea like mountains.

# 4926

Which, then, of the benefits of your Lord will ye twain belie?

# 4927

Everyone that is thereon will Pass away.

# 4928

And there will remain the countenance of thine Lord, Owner of Majesty and Beneficence.

# 4929

Which, then, of the benefits of your Lord, will ye twain belie?

# 4930

Of Him beggeth whosoever is in the heavens and the earth; every day He is in a new affair.

# 4931

Which, then, of the benefits of your Lord will ye twain belie?

# 4932

Anon We shall direct Our selves to you, O ye two classes.

# 4933

Which, then, of the benefits of your Lord will ye twain belie?

# 4934

O assembly of Jinn and man! if ye be able to pass out of the regions of the heavens and the earth, then pass out; ye can not pass out except with authority.

# 4935

Which, then, of the benefits of your Lord will ye twain belie?

# 4936

There shall be sent against you both flame of fire and smoke, and ye shall not be able to defend yourselves.

# 4937

Which, then, of the benefits of your Lord will ye twain belie?

# 4938

And when the heaven will be rent in sunder and will become rosy like Unto red hide.

# 4939

Whfch, then, of the benefits of your Lord will ye twain belie!

# 4940

Of his sin will be questioned that Day neither man nor jinn.

# 4941

Which, then, of the benefits of your Lord will ye twain belie?

# 4942

The culprits will be recognised by their marks, and will be lain hold of by the forelocks and the feet.

# 4943

Which, then, of the benefits of your Lord will ye twain belie?

# 4944

Yonder is the Hell which the culprits belied.

# 4945

Going round between it and balling water fierce.

# 4946

Which, then, of the benefits of your Lord will ye twain belie?

# 4947

And for him who dreadeth the standing before his Lord will be two Gardens.

# 4948

Which, then, of the benefits of your Lord will ye twain belie?

# 4949

With spreading branches.

# 4950

Which, then, of the benefits of your Lord will ye twain belie?

# 4951

In which, will be two fountains running.

# 4952

Which, then, of the benefits of your Lord will ye twain belie?

# 4953

In which will be of every fruit two kinds.

# 4954

Which, then, of the benefits of your Lord will ye twain belie?

# 4955

Reclining on carpets whereof the linings will be of brocade; and the fruit of the two Gardens shall be near at hand.

# 4956

Which, then, of the benefits of your Lord will ye twain belie?

# 4957

Therein shall be those of refraining looks whom before them hath deflowered neither man nor jinn.

# 4958

Which, then, of the benefits of Your Lord will ye twain belie?

# 4959

As though they are jacinth and coral.

# 4960

Which, then, of the benefits of your Lord will ye twain belie?

# 4961

Shall the recompense of kindness be aught save kindness?

# 4962

Which, then, of the benefits of your Lord will ye twain belie?

# 4963

And beside the two there will be two other Gardens.

# 4964

Which, then, of the benefits of your Lord will ye twain beli?

# 4965

Dark-green.

# 4966

Which, then, of the benefits of your Lord will ye twain belie?

# 4967

In which will be two fountains gushing forth.

# 4968

Which, then, of the benefits of your Lord will ye twain belie?

# 4969

In which will be fruit, the date-palm and pomegranate.

# 4970

Which, then, of the benefits of Your Lord will ye twain belie?

# 4971

Therein will be damsels agreeable and beauteous.

# 4972

Which, then, of the benefits of your Lord will ye twain belie?

# 4973

Fair ones, confined in tents.

# 4974

Which, then, of the benefits of Your Lord will ye twain belie?

# 4975

There hath deflowered them neither man nor jinn.

# 4976

Which, then, of the benefits of Your Lord will ye twain belie?

# 4977

Reclining upon cushions green and carpets beauteous.

# 4978

Which, then, of the benefits of your Lord will ye twain belie?

# 4979

Blest be the name of thine Lord, Owner Of Majesty and Beneficence!

# 4980

When there happeneth Event.

# 4981

There is about its happening no lie.

# 4982

Abasing exalting.

# 4983

This will happen when the earth is shaken, shaken

# 4984

And the mountains are crumbled, crumbled.

# 4985

So that they become dust seattered.

# 4986

And ye are classes three.

# 4987

Those on the right hand; how happy shall those on the right hand be!

# 4988

And those on the left hand; how miserable shall those on the left hand be!

# 4989

And the preceders are the pre-ceders.

# 4990

Those! they shall be the brought nigh,

# 4991

In Gardens of Delight.

# 4992

A multitude from the ancients.

# 4993

And a few from the later generations.

# 4994

On couches in wrought with gold.

# 4995

Reclining thereon facing each other.

# 4996

There shall go round Unto them youths ever-young.

# 4997

With goblets and ewers and a cup of limpid drink.

# 4998

Whereby there shall be neither headiness nor will they be inebriated.

# 4999

And with fruit from that which they choose.

# 5000

And with flesh of fowls from that Which they desire.

# 5001

And there will be fair ones large eyed.

# 5002

The likes Unto pearls hidden.

# 5003

A recompense for that which they have been working.

# 5004

Therein they hear no vain or sinful discourse.

# 5005

Nought but the saying: peace! peace!

# 5006

And the fellows on the right hand; how be happy shall the fellows on the right hand be!

# 5007

Midst lote-trees thornless.

# 5008

And plantains laden with fruit.

# 5009

And a shade ever-spread.

# 5010

And water everflowing.

# 5011

And fruit abundant.

# 5012

Neither ending nor forbidden.

# 5013

And carpets raised.

# 5014

Verily We! We have created those maidens by a creation.

# 5015

And have made them virgins.

# 5016

Loving, of equal age.

# 5017

For the fellows on the right hand.

# 5018

A multitude from the ancients.

# 5019

And a multitude from the later generations.

# 5020

And the fellows on the left hand; how miserable Shall the fellows on the left hand be!

# 5021

Amidst scorching wind and scalding water.

# 5022

And the shade of black smoke.

# 5023

Neither cool nor pleasant.

# 5024

Verily they have been heretofore affluent.

# 5025

And they have been persisting in the heinous offence.

# 5026

And they were wont to say: when we have died and become dust and bones, shall we, then, verily be raised?

# 5027

We and our fathers of old?

# 5028

Say thou: verily the ancients and those of later generations:

# 5029

Are going to be assembled on the appointed time of a Day Known.

# 5030

Then verily ye, O ye erring, denying people.

# 5031

Shall surely eat of the tree of Az-Zqqum.

# 5032

And shall fill therewith your bellies.

# 5033

And shall be drinkers thereon of boiling water.

# 5034

Drinkers even as the drinking of thirsty camels.

# 5035

This shall be their entertainment on the Day of Requital.

# 5036

We! it is We Who created you: wherefore confess ye not?

# 5037

Behold! - that which ye emit.

# 5038

Create him ye, or are We the Creator?

# 5039

We! it is We Who have decreed death Unto you all. And We are not to be outrun.

# 5040

That We may substitute others like Unto you and produce you into that which ye know not.

# 5041

And assuredly ye have fully known the first Production Wherefore heed ye not?

# 5042

Behold! - that which ye sow.

# 5043

Cause it ye to grow, or are We the Grower?

# 5044

If We willed, surely We would make it chaff, so that ye would be left wondering.

# 5045

Verily we are undone.

# 5046

Aye! we are deprived!

# 5047

Behold! - the water which ye drink:

# 5048

Send it down ye from the raincloud, or are We the Sender down?

# 5049

If We willed, surely We would make it brackish. Wherefore give ye not thanks?

# 5050

Behold! - the fire which ye strike out:

# 5051

Produce ye the tree thereof, or are We the Producer?

# 5052

We! it is We Who made it a reminder and a provision Unto the campers.

# 5053

Wherefore hallow thou the name of thy Lord, the Mighty.

# 5054

I swear by the setting of the stars -

# 5055

And verily that is a mighty oath, if ye but knew!

# 5056

That it is a Recitation honourable.

# 5057

In a Book Hidden.

# 5058

Which none can touch except the purified.

# 5059

It is a revelation from the Lord of the worlds.

# 5060

Is it this discourse that ye hold lightly?

# 5061

And make it your provision that ye should belie it?

# 5062

Wherefore then - when the soul cometh up to the wind-pipe -

# 5063

And ye are then looking on.

# 5064

And We are nigher Unto him than ye are, but ye behold not-

# 5065

Wherefore then, if ye are not to be requited

# 5066

Cause ye it not to return, if ye say sooth?

# 5067

Then if he be of the broughtnigh.

# 5068

For him shall be comfort, and fragrance and a Garden of Delight.

# 5069

And if he be of the fellows on the right hand,

# 5070

Then: peace Unto thee, for thou art of those on the right hand.

# 5071

And if he be of the beliers, the erring,

# 5072

Then an entertainment of boiling water.

# 5073

And roasting in a Blaze.

# 5074

Verily this! this is the very truth.

# 5075

Wherefore hallow thou the name of thy Lord, the Mighty!

# 5076

Whatsoever is in the heavens and the earth halloweth Allah; and He is the Mighty, the Wise.

# 5077

His is the dominion of the heavens and the earth; He giveth life and He causeth to die; and He is over everything Potent.

# 5078

He is the First and the Last, and the OutWard and the inward, and He is of everything the Knower.

# 5079

He it is Who created the heavens and the earth in six days; then He established Himself on the Throne. He knoweth whatsoever plungeth into the earth and whatsoever cometh forth therefrom, and whatsoever descendeth from the heaven and whatsoever ascendeth thereto; and He is with you wheresoever ye be. And Allah is of whatsoever ye work a Beholder.

# 5080

His is the dominion of the heavens and the earth, and Unto Allah will all affairs be brought back.

# 5081

He plungeth the night into the day, and plungeth the day into the night, and He is the Knower of whatsoever is in the breasts.

# 5082

Believe in Allah and His apostle, and expend of that whereof He hath made you successors to. Those of you who believe and expend - theirs shall be a great hire.

# 5083

And what aileth you that ye believe not in Allah whereas the apostle is calling you to believe in your Lord, and He hath already taken your bond, if ye are going to be believers?

# 5084

He it is Who sendeth down Unto His bondman manifest signs that He may bring you forth from darknesses into the light; and verily Allah is Unto you Tender, Merciful.

# 5085

And what aileth you that ye expend not in the way of Allah, when Allah's shall be the inheritance of the heavens and the earth! Those among you who expended and fought before the victory shall not be held equal They are mightier in rank than those who expended and fought afterwards; Unto each hath Allah promised good; and Allah is of whatsoever ye work Aware.

# 5086

Who is he that will lend Allah a goodly loan, so that He may multiply it for him, and his shall be a hire honourable?

# 5087

Mention the Day whereon thou shalt see the believing men and believing women, their light running before them and on their right hands: glad tidings Unto you To-day: Gardens whereunder rivers flow, abiders therein they will be. That! it is the mighty achievement.

# 5088

It shall be the Day whereon the hypocritical men and hypocritical women will say Unto those who believe: wait for us that we may borrow some of your light. Then betwixt them there will be set a high wall, wherein will be a door, the inside whereof hath mercy, while the outside thereof is toward the torment.

# 5089

They will cry unto them: have we not been with you? They will say: 'yea! but ye tempted your souls, and ye Waited, and ye dubitated, and your vain desires beguiled you until the affair of Allah came, and in respect to Allah the beguiler beguiled you.

# 5090

To-day therefore no ransom will be accepted of you nor of those who openly disbelieved; your abode is the Fire; that is your companion; a hapless destination.

# 5091

Is not the time yet come unto those who believe, that their hearts should humble themselves to the admonition of Allah and to the truth which hath come down, and that they become not as those who were vouchsafed the Book aforetime, and the time become extended unto them, and so their hearts became hard? And many of them are transgressors

# 5092

Know that Allah quickeneth earth after the death thereof. Surely We have propounded unto you the signs, that haply ye may reflect.

# 5093

Verily the alms-giving men and alms-giving women--and they are lending unto Allah a goodly lone--it shall be multiplied for them and theirs shall be a hire honourable.

# 5094

And those who believe in Allah and His apostles - those! they are the saints and martyrs in the sight of their Lord; theirs will be their full hire and their light. And those who disbelieved and belied Our signs--they shall be the fellows of the Blaze.

# 5095

Know that the life of the world is but a play and a pastime, and an adornment and a self-glorification among you and vying in respect of riches and children; as the likeness of vegetation after rains whereof the growth pleaseth the husbandmen, then it withereth and thou seest it becoming yellow, then it becometh chaff. And in the Hereafter there is both a grievous torment and forgiveness from Allah and His pleasure, and the life of the world is but a vain bauble.

# 5096

Strive with one another in hastening toward forgiveness from your Lord and toward a Garden whereof the width is as the width of the heavens and the earth, gotten ready for those who beiieve in Allah and His apostles. This is the grace of Allah; He vouchsafeth It Unto whomsoever He will; and Allah is Owner of mighty grace.

# 5097

Naught of distress befalleth the earth or your persons but it is inscribed in the Book even before We have created them. Verily with Allahs that is easy.

# 5098

This is announced lest ye sorrow for the sake of that which hath escaped you, or exult over that which He hath vouchsafed Unto you: And Allah loveth not any vainglorious boaster:

# 5099

Ihey who are niggardly and command mankind to niggardliness. And whosoever turneth away, then verily Allah! He is the Self-sufficient, the praise-worthy.

# 5100

Assuredly We sent Our apostles with evidences, and We sent down With them the book and the balance, that people might observe equity. And We sent down iron wherein is great violence and also advantages Unto mankind, and that Allah may know him who succoureth Him, unseen, and His apostles. Verily Allah is Strong, Mighty.

# 5101

And assuredly We sent Nuh and Ibrahim, and We placed in the posterity of the twain the prophecy and the Book. Then of them some are guided ones, and many of them are transgressors.

# 5102

Thereafter in their footsteps We caused Our apostles to follow, and We caused lsa, son Of Maryam, to follow them, and We vouchsafed Unto him the Injil, and We placed In the hearts of those who followed him tenderness and mercy. And asceticism! they innovated it- We prescribed it not for them Only seeking Allah's pleasure yet they tended it not with tendence due thereto. So We vouchsafed Unto such of them as believed their hire, and many of them are transgressors.

# 5103

O ye who believe! fear Aliah and believe in His apostle; He will vouch safe Unto you two portions of His mercy and will appoint for you a light wherewith ye will walk, and He will forgive you. And Allah is Forgiving, Merciful.

# 5104

This He will award that the people of the Book may know that they control naught of the grace of Allah, and that the grace is in Allah's hand; He vouchsafeth it Unto whomsoever He wilt, And Allah is Owner of mighty grace.

# 5105

Of a surety Allah hath heard the saying of her that disputed with thee concerning her husband and bewailed Unto Allah; and Allah hath heard your mutual discourse. Verlly Allah Is Hearing, Beholding.

# 5106

As to those among you who put away their wives by pronouncing zihar their mothers they are not. Their mothers are but those who gave them birth; and verily they utter a saying disputable and false. And verily Allah is Pardoning, Forgiving.

# 5107

Those who put away their wives by pronouncing zihar and thereafter would retract that which they have said, then upon them is the freeing of a slave before the twain touch each other. That is that wherewith ye are exhorted; and Allah is of whatsoever ye work Aware.

# 5108

And whosoever findeth not a slave to free on him is the fasting for two months in succession before the twain touch each other, and on him who is not able to do so is the feeding of sixty needy ones. That is in order that ye may believe in Allah and His apostle; and these are the ordinances of Allah. And for the infidels is a torment afflictive.

# 5109

Verily those who oppose Allah and His apostle shall be abased even as those before them were abased; and of a surety We have sent down manifest signs. And for the infidels will be a torment ignominious.

# 5110

On the Day whereon Allah will raise them all together and declare Unto them that which they have worked. Allah hath taken count thereof, whilst they forget it. And Allah is over everything a Witness.

# 5111

Observest thou not that Allah knoweth whatsoever is in the heavens and whatsoever is in the earth! There is no whispering among three but He is their fourth, nor among five but He is their sixth, nor fewer than that nor more but He is with them wheresoever they may be; and thereafter He will declare Unto them, on the Day of Judgment, that which they have worked. Verily Allah is of everything Knower.

# 5112

Observest thou not those who were forbidden whispering and they afterwards returned to that which they had been forbidden; and they whisper Unto each Other of sin, transgression and disobedience reward the apostle! And when they came Unto thee, they greet thee with that wherewith Allah greeteth thee not, and say within themselves: wherefore god tormented us not for that which we say? Sufficient Unto them is Hell, where in they will roast: a hapless destination!

# 5113

O ye who believe! when ye whisper together, whisper not of sin, transgression and disobedience toward the apostle; but whisper for virtue and piety. And fear Allah Unto Whom ye will be gathered.

# 5114

Whisper is only from the Satan that he may grieve those who believe; and he can harm them not at all save with the leave of Allah. Wherefore in Allah let the believers trust.

# 5115

O ye who believe! when it is said Unto you: make room in your assemblies, then make room; Allah will make room for you. And when it is said: rise up, then rise up; Allah will exalt those who believe among you and those who are vouchsafed knowledge, in degrees. And Allah is of whatsoever ye work Aware.

# 5116

O ye who believe! when ye go to whisper with the apostle, offer alms before your whispering; that is better for you and purer. Then if ye find not the wherewith, then verily Allah is Forgiving, Merciful.

# 5117

Shrink ye at your offering the alms before your whispering! Then, when ye could do it not, and Allah relented toward you, establish prayer and pay the poor-rate and obey Allah and His apostle. And Allah is Aware of that which ye work.

# 5118

Beholdest thou not those who take for friends a people with whom Allah is angered? They are neither of you nor of them, and they swear to a lie while they know.

# 5119

Allah hath gotten ready for them a torment grievous; verily vile is that which they have been working.

# 5120

They have taken their oaths as a shield, and they have hindered others from the way of Allah; wherefore theirs shall be a torment ignominious.

# 5121

There will not avail them against Allah their riches or their children at all. Th are the fellows of the Fire; therein they will be abiders.

# 5122

This shall befall on a Day whereon Allah shall raise them all together; then they will swear Unto Him even as they swear Unto you, deeming themselves up on aught. Lo! verily they! they are the liars.

# 5123

The Satan hath overpowered them, and so hath caused them to forget the remembrance of Allah. These are the band of the Satan. Lo! verily it is the Satan's band that shall be the losers.

# 5124

Verily those; who oppose Allah and His apostle - they are among the lowest.

# 5125

Allah hath prescribed: surely shall overcome, and My apostles. Verily Allah is strong, Mighty.

# 5126

Thou shalt not find a people who believe in Allah and the Last Day befriending those who oppose Allah and His apostle, even though they be their fathers or their sons or their brethren or their kindred. These! He hath inscribed faith on their hearts and hath strengthened them with a spirit from Him: and He shall make them enter Gardens whereunder rivers flow as abiders therein. Allah is well pleased with them, and they are well pleased with Him. These are Allah's band. Lo! verily it is the Allah's band that are the blissful.

# 5127

Whatsoever is in the heavens and whatsoever is in the earth halloweth Allah, and He is the Mighty, the Wise.

# 5128

He it is that drave forth those of the people of the Book who disbelieved from their homes at the first gathering, Ye imagined no that they would go -forth; and they imagined that their fortresses would protect them against Allah. Wherefore Allah came upon them whence they reckoned not, and cast terror in their hearts so that they made their houses desolate with their own hands and the hands of the believers. So learn a lesson. O ye endued with insight!

# 5129

And had not Allahg prescribed banishment for them, surely He would have tormented them in the world; and theirs in the Hereafter is the torment of the Fire.

# 5130

That is because they opposed Allah and His apostle, and whosoever opposeth Allah, then verily Allah is Stern in chastisement.

# 5131

Whatsoever fine palms ye cut down or left standing on roots there of, it was by the leave of Allah, and in order that He might abase the transgressors.

# 5132

And as to that which Allah restored Unto His apostle from them, ye rushed neither horse nor camel upon it but Allah giveth His apostles mastery over whomsoever He will. And Allah Is -over everything potent.

# 5133

Whatsoever Allah may restore Unto His apostle from the people of the cities is due Unto Allah and Unto the apostle and Unto the near of kin and the orphans and the needy and the wayfarer, so that it may not be confined to the rich among you. And whatsoever the apostle giveth you, take; and whatsoever he forbiddeth you, refrain from. And fear Allah; verily Allah is Stern in chastisement.

# 5134

And it is due Unto the poor Muhajirs who have been driven forth from their homes and their substance, seeking grace from Allah and His goodwill and succouring Allah and His apostle. These! they are the truthful.

# 5135

And it is also due Unto those who are settled in the dwelling and the faith before them, loving those who have migrated Unto them, and finding in their breasts no desire for that which hath been given them, and preferring them above themselves even though there was want amongst them. And whosoever is Preserved from covetousness of his soul, then those! - they are the blissful.

# 5136

And it is also due Unto those who came after them, saying: 'Our Lord! forgive us and our brethren who have preceded us in the faith, and place not in our hearts any rancour toward those who had believed. Our Lord! verily Thou art Tender, Merciful.'

# 5137

Beholdest thou not: those who dissemble saying Unto their brethren who disbelieve among the people of the Book: if ye are driven forth we shall surely go forth with you, and we, shall not ever obey anyone in your respect, and if ye are attacked, we shall surely succour you. And Allah beareth witness that surely they are liars.

# 5138

Surely if they are driven forth, they shall not; go forth with them, and surely if they are attacked, they shall succour them, not, and even ifs they succoured them they would turn their backs; and then they shall not be succoured.

# 5139

Surely ye are more awful in their breasts than Allah. That is because they are a people who understand not.

# 5140

They shall not fight against you, not even together, except in fenced townships or from behind walls. Their violence among themselves is strong; thou deemest them enjoined, whereas their hearts are diverse. That is because they are a people who reflect not.

# 5141

They are like those a little before them; they tasted the ill-effect of their affair, and theirs shall be a torment afflictive.

# 5142

They are like the Satan, when he saith Unto man: 'disbelieve,' then, when he disbelieveth, saith: verily I am quit of thee, verily I fear Allah, the Lord of the Worlds.

# 5143

Wherefore the end of the twain will be that they will be in the Fire, as abiders there in; that is the meed of the wrong-doers.

# 5144

O ye who believe! fear Allah, and let every soul look to that which it sendeth forward for the morrow. And fear Allah; veril Allah is Aware of that which ye work.

# 5145

And be not as those who forgot Allah, wherefore He caused them to forget their own souls. Those! they are the transgressors.

# 5146

Not equal are the fellows of the Fire and the fellows of the Garden. Fellows of the Garden! they are the achievers!

# 5147

Had We sent down this Qur'an upon a mountain, thou wouldst surely have seen it humbling itself and cleaving in sunder for fear of Allah. Such similitudes We propound Unto mankind that haply they may reflect.

# 5148

He is Allah, there is no God but He; Knower of the unseen and the seen. He is the Compassionate, the Merciful.

# 5149

He is Allah, there is no God but He, the Sovereign, the Holy, the Author of Safety, the Giver of Peace, the Protector, the Mighty, the Mender, the Majestic. Hallowed be Allah from all that they associate!

# 5150

He is Allah, the Creator, the Maker, the Fashioner; His are the excellent names. Him halloweth whatsoever is in the heavens and the earth, and He is the Mighty, the Wise.

# 5151

O ye who believe! take not Mine enemy and your enemy for friends, showing affection toward them, whilst they of a surety disbelieve in that which hath come Unto you of the truth, and have driven forth the apostle and yourselves because ye believe in Allah, your Lord, if ye have come forth to strive in My way and to seek My goodwill. Ye secretly show them affection, while I am best Knower of that which ye conceal and that which ya make known! And whosoever of you doth this, he hath surely strayed from the straight path.

# 5152

Should they come upon you, they will be enemies Unto you and will stretch out against you their hands and their tongues with evil; and fain would they that ye should disbelieve.

# 5153

There will profit you neither your kindred nor your children on the Day of Resurrection. He shall decide between; and Allah is of that which ye you work Beholder.

# 5154

Surely there hath been an excellent pattern for you in Ibrahim and those with him, when they said Unto their people; verily we are quit of you and of that which ye worship beside Allah; we renounce you; and surely there hath appeared between us and you hostility and hatred for evermore until ye believe in Allah alone, - except the saying of Ibrahim Unto his father: surely I shall beg forgiveness for thee, and I have no power with Allah for thee at all. Our Lord! in Thee we put our trust, and Unto Thee we turn, and Unto Thee is the journeying.

# 5155

Our Lord! make us not a trial for those who disbelieve, and forgive us, our Lord! verily Thou! Thou art the Mighty, the Wise.

# 5156

Assuredly there hath been in them for you an excellent pattern-for him who hopeth for Allah and the last Day. And whosoever turneth away, then verily Allah! He is the Self-sufficient, the Praiseworthy.

# 5157

Belike Allah may appoint between you and those of them whom ye hold as enemies affection. And Allah is Potent, and Allah is Forgiving, Merciful.

# 5158

Allah forbiddeth you not that ye should deal benevolently and equitably with those who fought not against you on accouct of religion nor drave you out from your homes; verily Allah loveth the equitable,

# 5159

Allah only forbiddeth you with regard to those who fought against you on account of religion and drave you out from your homes and helped in driving you out, that ye should befriend them. And whosoever shall befriend them, then those! they are the wrong-doers.

# 5160

O ye who believe! when believing women come Unto you as emigrants examine them. Allah is the best Knower of their faith. Then if ye know them to be true believers, send them not back Unto the infidels; they are not lawful Unto them, nor are they lawful Unto them. And give them that which they have expended. Nor is it any crime in you if ye marry them when ye have given their hires. And hold not to the ties of the infidel women, and ask back that which ye have expended, and let them ask back that which they have expended. That is the judgment of Allah; He judgeth between you, And Allah is Knowing, Wise.

# 5161

And if any of your wives hath been left with the infidels, and then ye have retaliated, then give Unto those whose wives have gone away the like of that which they have expended, and fear Allah in whom ye are believers.

# 5162

O Prophet! when believing women come Unto thee swearing fealty Unto thee, that they shall not associate aught with Allah, nor they shall steal, nor they shall commit fornication, nor they shall slay their children, nor they shall produce any falsehood that they have fabricated between their hands and feet, nor they shall disobey thee in anything reputable, then accept thou their fealty, and pray to Allah for their forgiveness. Verily Allah is Forgiving, Merciful.

# 5163

O ye who believe! befriend not a people against whom Allah is Wroth. Surely they have despaired of tHe Hereafter even as have despaired the entombed of the infidels. S

# 5164

Whatsoever is in the heavens and whatsoever is in the earth halloweth Allah. And He is the Mighty, the Wise.

# 5165

O ye who believe! wherefore say ye that which ye do not?

# 5166

Most odious it is Unto Allah that ye should Say that which ye do not.

# 5167

Verily Allah loveth those who fight in His way drown up in ranks, as though they were a structure well compacted.

# 5168

And recall what time Musa said Unto his people: O my people! wherefore hurt ye me, When surely ye know that verily I am Allah's apostle Unto you! Then when they sweryed, Allah made their hearts swerve; and Allah guideth not a transgressing people.

# 5169

And recall what time Isa, son of Maryam, said: children of Israi'l! verily I am Allah's apostle Unto you, confirming the Taurat which was before me, and giving the glad tidings of an apostle who cometh after me: his name will be Ahmad. Then when he brought Unto them evidences, they said: this is magic manifest.

# 5170

And who is a greater wrong-doer than he who fabricateth against Allah a lie even as he is summoned Unto Islam? And Allah guideth not a wrongdoing people.

# 5171

Fain would they extinguish the light of Allah is with their mouths and Allah is going to perfect His light, even though averse may be the infidels.

# 5172

He it is Who hath sent His apostle with the guidance and the true religion, that He may make it triumph over all religion, even though averse may be associaters.

# 5173

O ye who believe! shall direct you to a merchandise that will deliver you from a torment afflictive?

# 5174

It is that ye should believe in Allah and His apostle and strive in the way of Allah with your riches and Your lives That is best for you, if ye only knew!

# 5175

He will forgive you your sins, and make YOu enter Gardens whereunder rivers flow, and happy abodes in Gardens Everlasting. That is the mighty achievement.

# 5176

And also another blessing which ye love: succour from Allah and a speedy victory. And bear thou the glad tidings Unto the believers.

# 5177

O ye who believe! be Allah's helpers, even as 'Isa, son of Maryam, said Unto the disciples: who shall be my helpers Unto Allah? The disciples said: we are Allah's helpers. Then a part of the Children of Israil believed, and part disbelieved. Then We strengthened those who believed against their foe; wherefore they became triumphant.

# 5178

Whatsoever is in the heavens and whatsoever is in the earth halloweth Allah, the Sovereign, the Holy, the Mighty, the Wise.

# 5179

He it is Who hath raised amdist the unlettered ones an apostle from among themselves, rehearsing Unto them His revelations and purifying them and teaching them the Book and Wisdom, though they have been aforetime in error manifest.

# 5180

And also others of them who have not yet joined them. And He is the Mighty; the Wise.

# 5181

That is the grace of Allah: He vouchsafeth it on whomsoever He will. And Allah is the Owner of mighty Grace.

# 5182

The likeness of those who were laden with the Taurat and then they bare it not, is as the likeness of the ass bearing tomes. Hapless is the likeness of the people who belie the signs of Allah. And Allah guideth not a wrong doing people. J

# 5183

Say thou: O ye e who are Judaised! if ye imagine at ye are the friends of Allah above mankind, then wish for death if ye be truthful.

# 5184

And they will never wish there for, because of that which their hands have sent forward. And Allah is the Knower of he wrong-doers.

# 5185

Say thou: verily the death which ye flee from! then verily it will meet you and thereafter ye will be brought back Unto the Knower of the unseen and the seen, and He will declare Unto you that which ye have been working.

# 5186

O ye who believe! when the call to prayer is made on the day of Friday then repair Unto the remembrance of Allah and leave off bargaining. That is better for you if ye know

# 5187

Then, when the prayer is ended, disperse in the land and seek of Allah's grace, and remember Allah much, that haply ye may thrive.

# 5188

And when they beheld merchandise or sport, they flocked thereto, and left thee standing. Say thou: that which is with Allah is better than sport and better than merchandise; and Allah is the Best of providers.

# 5189

When the hypocrites come Unto thee, they say: we bear witness that thou art indeed the apostle of Allah. Allah knoweth that thou art indeed His apostle, and Allah beareth witness that; the hypocrites are indeed liars.

# 5190

They have taken their oaths for a shield; then they turn away men from the way of Allah. Verily vile is that which they have been working.

# 5191

That is, because they believed, and thereafter disbelieved, wherefore their hearts are sealed, so that they understand not.

# 5192

And when thou beholdest them, their persons please thee: and if they speak, thou listenest to their discourse; they are as though they were blocks of wood propped up. They deem every shout to be against them. They are the enemy; so beware of them. Perish them Allah! whither are they deviating!

# 5193

And when it is said Unto them: come! that the apostle of Allah may ask forgiveness for you, they twist their heads, and thou beholdest them retire, while they are stiff-necked.

# 5194

Equal it is Unto them: whether thou askest forgiveness for them or askest not forgiveness for them, Allah shall forgive them not. Verily Allah guideth not a transgressing people.

# 5195

They are the ones who say: expend not on those who are with Allah's apostle, that they may disperse; whereas Allah's are the treasures of the heavens and the earth; yet the hypocrites understand not.

# 5196

They say: surely, if we return to Madina the mightier shall drive out the meaner thence: whereas might is Allah's and His apostle's and the believers; yet the hypocrites know not.

# 5197

O ye who believe let not your riches or your children divert you from the remembrance of Allah. And whosoever doth that then those! they are the losers.

# 5198

And expend of that wherewith We have provided you afore death cometh Unto one of you, and he saith: 'my Lord! wouldst Thou not defer me for a short term, so that I would give alms and become of the righteous.

# 5199

And Allah deferreth not a soul when its term- hath come; and Allah is Aware of that which ye do.

# 5200

Whatsoever is in the heavens and whatsoever is in the earth halloweth Allah. His is the dominion; and His is the praise; and He is over everything potent.

# 5201

He it is Who hath created you; then of you some are Infidels and of you some are believers; and Allah is of that which ye Work Beholder.

# 5202

He hath created the heavens and the earth with truth, and hath formed you, and hath made-your forms goodly; and Unto Him Is the return.

# 5203

He knoweth whatsoever is In the heavens and the earth, and He knoweth whatsoever ye keep secret, and whatsoever ye make known; and Allah is the Knower of whatsoever is in the breasts.

# 5204

Hath not the tidings reached you of those who disbelieved aforetime, and so tasted the evil consequence of their affair, and theirs will be a torment afflictive?

# 5205

That was because their apostles were wont to come Unto them with evidences, but they said: shall a mere human bein guide us? Wherefore they disbelieved and turned away; and Allah needed them not. And Allah is Self Sufficient, Praiseworthy.

# 5206

Those who dlsbelieve assert that they shall not be raised. Say thou 'Yea! by my Lord, ye shall surely be raised, and then Unto you shall be declared that which ye have worked; and that is for Allah easy.

# 5207

Wherefore believe in Allah and His apostle and the Light which We have sent down: And Allah is of that which ye work Aware.

# 5208

Remember the Day whereon He shall assemble you, the Day of Assembly; that shall be the Day of Mutual Loss and Gain. And whosoever believeth in Allah and worketh righteously from him He will expiate His misdeeds and will make him enter Gardens whereunder rivers flow, as abiders therein for evermore. That is the mighty achievement.

# 5209

And they who disbelieve and belie Our Signs! those shall be fellows of the Fire, as abiders therein; a hapless destination.

# 5210

No calamity befalleth save by Allah's leave. And whosoever believeth in Allah, his heart He guideth. And Allah is of everything Knower.

# 5211

Obey Allah and obey the apostlle; then if ye turn away, on Our apostle is only the preaching manifest.

# 5212

Allah! there is no God but He! In Allah, therefore, let the believers put their trust.

# 5213

O ye who believe! verily of your wives and your children there is an enemy Unto you; wherefore beware of them. And if ye pardon and pass over and forgive, then verily Allah is Forgiving, Merciful.

# 5214

Your riches and your children are but a temptation; and Allah! with Him is a mighty hire.

# 5215

Wherefore fear Allah as much as ye are able, and hearken and obey, and expend, for the benefit of your souls. And whosoever is protected from niggardliness of his soul - those! they are the blissful.

# 5216

If ye lend Unto Allah a goodly loan, He will multiply it Unto you and will forgive you; and Allah is Appreciator, Forbearing.

# 5217

Knower of the unseen and the seen, the Mighty, the Wise.

# 5218

O Prophet! when ye divorce women, divorce them before their waitrng-period; and count the waiting period; and fear Allah, your Lord. Drive them not out of their houses, nor should they go forth, unless they commit a manifest indecency. These are the bounds of Allah; and whosoever trespasseth the bounds of Allah, hath surely wronged himself. Thou knowest not, that haply Allah may hereafter bring something new to pass.

# 5219

Then when they have attained their term, either retain them reputably, or part from them reputably, and take as witnesses two just men from among you, and set up your testimony for Ailah. Thus is exhorted he who believeth in Allah and the Last Day. And whosoever feareth Allah He maketh for him an outlet.

# 5220

And He provideth for him from whence he reckoneth not upon. And whosoever putteth his trust in Allah He will suffice him. Verily Allah is sure to attain His purpose, and Allah hath appointed Unto everything a measure.

# 5221

And as to such of your women as have despaired of menstruation, if ye be in doubt thereof, their waiting period is three months, as also of those who have not yet menstruated. And as to those with burthens, their term is when they lay down their burthen. And whosoever feareth Allah, He maketh his affair Unto him easy.

# 5222

That is the commandment of Allah which He hath sent down Unto you. And whosoever feareth Allah, He Will expiate his misdeeds from him, and will magnify for him his hire.

# 5223

Lodge them wheresoever ye lodge yourselves; according to your means; and hurt them not so as to straiten them. And if they are with burthen, expend on them until they lay down their burthen. Then, if they suckle their children for you, give them their hire, and take counsel together reputably. And if ye make hardship for one another, then another woman will suckle for him.

# 5224

Let the man of means expend according to his means; and whosoever is stinted in his subsistence let him expend of that which Allah hath given him. Allah tasketh not a soul except according to that which He hath vouchsafed it. Anon Allah will appoint after hardship ease.

# 5225

And how many a city trespassed the commandment of its Lord and His apostles! Wherefore We reckoned with them a stern reckoning, and We tormented them With a torment unheard of.

# 5226

Wherefore they tasted the evil consequence of their affair, and the end of their affair was loss.

# 5227

Allah hath gotten ready for them a grievous torment; so fear Allah, O men of understanding! those who have believed. Surely He hath sent down Unto you an admonition.

# 5228

An apostle reciting Unto you the revelations of Allah as evidences, that he may bring forth those who believe and work righteous works from darknesses into light. And whosoever believeth in Allah and worketh righteously, him He will cause to enter Gardens whereunder rivers flow, as abiders for evermore. Surely Allah hath made for him an excellent provision.

# 5229

Allah it is Who hath created seven heavens, and of the earth the like thereof; the commandment cometh down between them, that ye may know that Allah is over everything Potent, and that Allah! He encompasseth everything in knowledge.

# 5230

O prophet! why makest thou unlawful that which Allah hath made lawful Unto thee, seeking the good-will of thy wives! And Allah is Forgiving, Merciful.

# 5231

Surely Allah hath ordained for you absolution from your oaths; and Allah is your Patron and He is the Knower, the Wise.

# 5232

And recall what time the Prophet confided a story Unto one of his spouses, then she disclosed it, and Allah apprised him thereof, he made known part thereof and Withheld part. Then, when he had apprised her of it, she said: who hath acquainted thee therewith! He said the Knower, the Aware hath acquainted me.

# 5233

If ye twain turn Unto Allah repentant, it is well, surely your hearts are so inclined, and if ye support each other against him, then verily Allah! his friend is He and Jibril and so are the righteous believers; and furthermore the angels are his aiders.

# 5234

Belike his Lord, if he divorce you, will give him in exchange wives better than you, Muslims, believers, devout, penitent, worshippers, given to fasting, both non-virgins and virgins.

# 5235

O ye who believe! protect yourselves and your households from a Fire the fuel whereof is mankind and stones, over which are angels, stern, strong; they disobey not Allah in that which He commandeth them, and do that which they are commanded.

# 5236

O ye who disbelieve! excuse not yourselves To-day; ye are only being requited for that which ye have been working.

# 5237

O ye who believe! turn Unto Allah with a sincere repentance. Belike your Lord will expiate from you your misdeeds and cause you to enter Gardens whereunder rivers flow, on the Day whereon Allah will not humiliate the prophet and those who believe with him. Their light will be running before them and on their right hands, and they will say: our Lord! perfect for us our light, and forgive us; verily Thou art over everything Potent.

# 5238

O Prophet! strive hard against the infidels and the hypocrites, and be stern Unto them. And their abode is Hell: a hapless destination!

# 5239

Allah propoundeth for those who disbelieve the similitude of the wife of Nuh and the wife of Lut. They were under two of our righteous bondmen; then they defrauded them. Wherefore the twain availed them naught against Allah, and it was said: enter ye twain the Fire with those who enter.

# 5240

And Allah propoundeth for those who believe the similitude of the wife Of Fir'awn, when she said: 'my Lord! build me in Thine presence a house in the Garden, and deliver me from Fir'awn and his handiwork, and deliver me from the transgressing people.

# 5241

And the similitude of Maryram daughter of lmran, who preserved her chastity, wherefore We breathed in it Of Our Spirit. And she testified to the words of her Lord and His Books and she was of the devout.

# 5242

Blest be He in whose hand is the dominion, and He is over everything Potent.

# 5243

Who hath created death and life that He might prove you, as to which of you is excellent in work. And He is the Mighty, the Forgiver.

# 5244

Who hath created seven heavens in storeys. Thou shalt not behold in the Compassionates creation any over-sight; then repeat thy look, beholdest thou any crack?

# 5245

Then repeat thy look twice over, and thy look will return Unto thee dim and It will have become wearied out.

# 5246

And assuredly We have bedecked the nearest heaven with lamps, and We have made them missiles for satans: and for them We have gotten ready the torment of the Blaze.

# 5247

And for those who disbelieve in their Lord will be the torment of Hell; and a hapless destination!

# 5248

When they will be cast thereinto, they will hear thereof a braying even as it balleth up,

# 5249

Well-nigh it bursteth with rage. So oft as a company is cast thereinto, the keepers thereof will ask them: came there not Unto you a warner?

# 5250

They will say: yea! surely there came a warner Unto us, but we belied, and said: God hath not sent down aught, are naught but in a great error.

# 5251

And they will say: had we been wont to hearken or to reflect, we had not been among the fellows of the Blaze.

# 5252

So they shall confess their sin. Far away they-be, the fellows of the Blaze!

# 5253

Verily those who dread their Lord unseen, theirs shall be forgiveness and a great hire.

# 5254

And whather ye keep your discourse secret or publish it, verily He is the Knower of that which is in the breasts.

# 5255

Shall not He Who hath created know? And He is the Subtile, the Aware.

# 5256

He it is Who hath made the earth Unto you subservient, so go forth in the regions thereof, and eat of His provision. And Unto Him is the Resurrection.

# 5257

Are ye secure that He who is in the heaven will not sink the earth with you and then it should quake?

# 5258

Or are ye secure that He Who is in the heaven will not send against you a whirlwind? Anon ye shall know what wise hath been My warning.

# 5259

And assuredly those before them belied; then what wise hath been My wrath!

# 5260

Behold they not the birds above them, outstretching their wings and they also withdraw them? Naught holdeth them except the Compassionate. Verily He is of everything Beholder.

# 5261

Who. is he that can be an army Unto you and succour you, beside the Compassionate! The infidelsjb are but in delusion.

# 5262

Who is he that can provide for you, should He withhold His provision? Aye! they persists in perverseness and aversion.

# 5263

Is he, then, who goeth about grovelling upon his face better directed, or he who walketh evenly on a straight path?

# 5264

Say thou: He it is who hath brought you forth and hath endowed you with hearing and sights and hearts. Little thanks it is ye give!

# 5265

Say thou: He it is Who hath spread you over the earth, and Unto Him ye shall be gathered.

# 5266

And they say: when will this promise be fulfilled, if ye say sooth?

# 5267

Say thou: the knowledge is only with Allah, and but a warner manifest.

# 5268

But when they will behold it proximating sad will be the countenances of those who disbelieve, and it will be said: this is that which ye have been calling for.

# 5269

Say thou: bethink ye if Allah destroy me and those with me; or have mercy on us, who will protect the infidels from a torment afflictive?

# 5270

Say thou: He is the Compassionate; in Him we have believed, and in Him we have put our trust. -And anon ye will know who it is that is in error manifest.

# 5271

Say thou: bethink ye, were your water to be sunk away, who then could bring you water welling-up?

# 5272

Nun By the pen and by that which they inscribe.

# 5273

Thou art nor, through the grace of thy Lord, mad.

# 5274

And verily thine shall be a hire unending."

# 5275

And verily thou art of a high and noble disposition.

# 5276

Anon thou wilt see and they will see:

# 5277

Which of you is afflicted with madness.

# 5278

Verily thy Lord! He is the best Knower of him who strayeth from His path, and He is the best Knower of the guided one,

# 5279

Wherefore obey not thou the beliers.

# 5280

Fain would they that thou shouldst be pliant, so that they will be pliant.

# 5281

And obey not: thou any swearer ignominous.

# 5282

A defamer, spreader abroad of slander.

# 5283

Hinderer of the good, trespasser; sinner.

# 5284

Gross, and therewithal ignoble-

# 5285

Because he is owner of riches and children.

# 5286

When Our revelations are rehearsed Unto him, he saith: fables of the ancients.

# 5287

Anon We shall brand him on snout.

# 5288

Verily We! We have proved them even as We proved the fellows of a garden when they swarethat they would surely reap it in the morning.

# 5289

And they made not the exception.

# 5290

Wherefore an encircling visitation visited it even as they slept on.

# 5291

Then in the morning it became as though it had been reaped.

# 5292

Then they cried out Unto each other in the morning,

# 5293

Saying: go out betimes to your tilth if ye would reap.

# 5294

So they went off speaking to each other in a low voice:

# 5295

Let there not enter upon you today any needy man.

# 5296

And they went out betimes determined in purpose.

# 5297

Then when they beheld it, they said: verily we have strayed.

# 5298

Aye! it is we who are deprived!

# 5299

The most moderate of them said: said I not Unto you, wherefore hallow him ye not!

# 5300

They said: hallowed be Our Lord! verily we have been wrong- doers.

# 5301

Then they turned to each other reproaching

# 5302

They said: woe Unto us! verily we! we have been arrogant.

# 5303

Belike our Lord may exchange for us better garden than this; verily we are Unto our Lord beseechers.

# 5304

Such is the torment. And the torment of the Hereafter is far greater; if they but knew.

# 5305

Verily for the God-fearing, are with their Lord Gardens of Delight.

# 5306

Shall We then make the Muslims like the culprits?

# 5307

What aileth you? How ill ye judge!

# 5308

Is there with you a Book wherein ye study:

# 5309

That therein is yours that which. ye may choose?

# 5310

Or have ye oaths from us reaching to the Day of Resurrection, that you shall be that which ye judge?

# 5311

Ask then, which of them will stand thereof a surety?

# 5312

Have they associate gods? Then let them produce their associate gods if they say sooth!

# 5313

Remember the Day whereon the shank shall be bared and they shall be called upon to Prostrate themselves, but they shall not be able.

# 5314

Downcast will be their looks; abjectness will overspread them. Surely they had been called upon to Prostrate themselves while yet they were whole.

# 5315

Let Me alone with him who belieth this discourse; step by step We lead them on when they perceive not.

# 5316

And I bear with them; verily My contrivance is sure.

# 5317

Askest thou a hire from them so that they are laden with debt?

# 5318

Is with them the unseen, so that they write down?

# 5319

Be patient thou, then, with thy Lord's judgment, and be thou not like him of the fish, when he cried out while he was in anguish.

# 5320

Had not grace from his Lord reached him, he had surely been cast into the wilderness in a plight.

# 5321

Then his Lord chose him and made him of the righteous.

# 5322

And those who disbelieve well-nigh cause thee to stumble with their looks when they hear the Admonition, and they say: verily he is mad.

# 5323

While it is naught but an admonition Unto the worlds.

# 5324

The Inevitable Calamity!

# 5325

What is the Inevitable Calamity?

# 5326

And what shall make thee know that which the Inevitable Calamity is.

# 5327

The tribes of Thamud and 'Aad belied the Striking Day.

# 5328

As for Thamud, they were destroyed by the outburst.

# 5329

And as for 'Aad they were destroyed by a wind, furious. roaring.

# 5330

To which He subjected them for seven nights and eight days in succession, so that thou mightest have seen men during it lying prostrate, as though they were stumps of palms ruined.

# 5331

Beholdest thou any of them remaining?

# 5332

And Fir'awn and those before him and the overturned cities committed sin.

# 5333

And they disobeyed their Lord's apostle, so He laid hold of them with a grip increasing.

# 5334

Verily We! when the water rose, We bare you upon the traversing ark.

# 5335

That We might make it Unto you an admonition, and thot it might be retained by the retaining ears.

# 5336

And when the Trumpet shall sound a single blast.

# 5337

And the earth and the mountains shall be borne and the twain shall be crushed with a single crash.

# 5338

Then on that Day shall happen the Event.

# 5339

And the heaven shall be rent in sunder, it on that Day shall be frail.

# 5340

And the angels shall be on the borders thereof; and on that Day eight shall bear over them the Throne of thy Lord.

# 5341

The Day whereon ye shall be mustered nothing hidden by you shall be hidden.

# 5342

Then as to him who will be vouchsafed his book in his right hand, he shall say: here! read my book!

# 5343

Verily I was sure that I should be a meeter of my reckoning.

# 5344

Then he shall be in a life well-pleasing -

# 5345

In a Garden lofty.

# 5346

Clusters whereof shall be near at hand.

# 5347

Eat and drink with benefit for that which ye sent on beforehand in dayspast.

# 5348

Then as to him who shall be vouchsafed his book in his left hand, he shall say: Oh! would that I had not been vouchsafed my book.

# 5349

Nor known whatever was my reckoning!

# 5350

Oh, would that it had been the ending!

# 5351

My riches have: availed me not;

# 5352

There hath perished from me my authority.

# 5353

Lay hold of him and chain him;

# 5354

Then in the Scorch roast him

# 5355

Then, in a chain whereof the length is seventy Cubits, bind him.

# 5356

Verily he was wont not to believe in Allah, the Mighty.

# 5357

Nor he urged on others the feeding of the poor.

# 5358

Wherefore for him here this Day there is no friend.

# 5359

Nor any food save filthy corruption.

# 5360

None shall eat it but the sinners.

# 5361

I swear by that which ye see.

# 5362

And that which ye see not.

# 5363

That it is surely the speech brought by messenger honourable.

# 5364

And it is not the speech of a poet. Little it is that ye believe

# 5365

Nor is it the speech of a sooth- sayer. Little are ye admonished.

# 5366

It is a Revelation from the Lord of the worlds.

# 5367

And if he had forged concerning us some discourses.

# 5368

We surely had lain hold of him by the right hand.

# 5369

And then severed his life-vein.

# 5370

And not one of you would have withheld us from punishing him.

# 5371

And verily it is an Admonition Unto the God-fearing.

# 5372

And verily We! We know that some among you are beliers thereof.

# 5373

And verily it shall be an occasion of anguish Unto the infidels.

# 5374

And verily it is the truth of assured certainty.

# 5375

Wherefore hallow thou the name of thy Lord, the Mighty.

# 5376

There hath asked an asker for the torment about to befall.

# 5377

The infidels, of which there is no averter.

# 5378

From Allah, Owner of the ascending steps.

# 5379

Whereby the angels ascend Unto Him and also the spirit, On a Day whereof the measure is fifty thousand years.

# 5380

Wherefore be thou patient with a becoming patience.

# 5381

Verily they behold it afar off.

# 5382

And We behold it nigh.

# 5383

It shall befall on a Day whereon the heaven shall become like Unto dregs of oil.

# 5384

And then the mountains shall become like Unto wool dyed.

# 5385

And not a friend shall ask a friend,

# 5386

Though they shall be made to see one another. Fain would the guilty ransom himself from the torment of that Day by his children.

# 5387

And his spouse and his brother.

# 5388

And his kin that sheltered him.

# 5389

And all who are on the earth; so that this might deliver him.

# 5390

By no means! Verily it is a Flame.

# 5391

Flaying off the scalp-skin.

# 5392

It shall calll him who turneth back and backslideth.

# 5393

And masseth and then hoardeth.

# 5394

Verily man is formed impatient.

# 5395

When evil toucheth him, he is bewailing.

# 5396

And when good toucheth him he is begrudging.

# 5397

Not so are the prayerful.

# 5398

Who are at their prayer constant.

# 5399

And those in whose riches is a known right.

# 5400

For the beggar and the destitute.

# 5401

And those who testify to the Day of Requital.

# 5402

And those who are fearful of their Lord's torment -

# 5403

Verily the torment of their Lord is not a thing to feel secure from.

# 5404

And those who of their private parts are guards.

# 5405

Save in regard to their spouses or those whom their right hands own; so verily they are not blameworthy -

# 5406

And whosoever seeketh beyond that, then it is those who are the trespassers

# 5407

And those who of their trusts and their covenant are keepers.

# 5408

And those who stand firm in their testimonies.

# 5409

And those who of their prayer are observant.

# 5410

Those shall dwell in Gardens, honoured.

# 5411

What aileth those who disbelieve, toward thee hastening.

# 5412

On the right and on the left, in companies?

# 5413

Coveteth every man of them, that he shall enter the Garden of Delight?

# 5414

By no means! veriiy We! We have created them from that which they know.

# 5415

I swear by the Lord of the easts and the wests, that, vierly We are Able.

# 5416

To replace them by others better than they; and We are not to be outrun.

# 5417

Wherefore let thou them alone plunging in vanity and sporting until they meet their Day which they are promised.

# 5418

The Day whereon they shall come forth from the sepulchres hastily, as though they were to an altar hurrying.

# 5419

Downcast shall be their looks; abjectness shall overspread them. Such is the Day which they are promised.

# 5420

Verily We! We sent Nuh Unto his people saying: warn thy people ere there come Unto them torment afflictive.

# 5421

He said: O my people! verily I am Unto you a warner manifest.

# 5422

Worship Allah, and fear Him, and obey me.

# 5423

He will forgive you your sins, and will defer you to an appointed term. Verily the term of Allah when it cometh shall not be deferred, if ye but knew.

# 5424

He said: my Lord! verily have called my people night and day.

# 5425

And my calling hath only increased them in fleeing.

# 5426

And verily so oft as I call them, that Thou mayest forgive them, they place their fingers into their ears, and wrap themselves with their garments, and persist, and are stiff-necked.

# 5427

Then verily have called Unto them publicly:

# 5428

Then verily spake Unto them openly, and secretly also I addressed them.

# 5429

And I said: ask forgiveness of your Lord; verily He is ever Most Forgiving.

# 5430

He will send the heaven upon you copiously;

# 5431

And He will add Unto you riches and children and will appoint Unto you gardens and will appoint Unto you rivers.

# 5432

What aileth you that ye expect not in Allah majesty!

# 5433

And surely He hath created you by stages.

# 5434

Behold ye not in what wise Allah hath created seven heavens in storeys.

# 5435

And hath placed the moon therein for a light, and hath made the sun a lamp?

# 5436

And Allah hath caused you to grow from the earth as a growth.

# 5437

And thereafter He will cause you to return thereinto, and He will bring you forth a forthbringing.

# 5438

And Allah hath made the earth Unto you an expanse.

# 5439

That of it ye may traverse the ways open.

# 5440

Nuh said. my Lord! verily they have disobeyed me and followed them whose riches and children have only increased them in loss.

# 5441

And who have plotted a tremendous plot

# 5442

And who have said: ye shall not leave your gods; nor Shall ye leave Wadd nor Suwa', nor Yaghuth, nor Ya'uq nor Nasr.

# 5443

And surely they have misled many. And increase Thou these wrong-doers in naught save error.

# 5444

And because of their misdeeds they were drowned, and then they were made to enter a Fire. Then they found not for themselves, beside Allah, any helpers.

# 5445

And Nuh said: my Lord! leave not upon the earth of the infidels one inhabitant.

# 5446

Verily if Thou shouldst leave them, they Will mislead Thine bondmen and will beget not save sinning infidels,

# 5447

My Lord! forgive me and my parents and him who entereth my house as a believer, and believing men and believing women, and increase not the wrong-doers in aught save ruin!

# 5448

Say thou: it hath been revealed Unto me that a company of the Jinn listened, and said, verily we have listened to a Recitation wondrous.

# 5449

Guiding Unto rectitude; wherefore we have believed therein, and we shall by no means associate with our Lord anyone.

# 5450

And He - exalted be the majesty of our Lord!-hath taken neither a spouse nor a son.

# 5451

And the foolish among us were wont to forge lie against Allah exceedingly.

# 5452

And verily we! we had imagined that humankind and Jinn would never forge against Allah a lie.

# 5453

And persons among humankind have been seeking refuge with persons of the Jinn, so that they increased them in evil disposition.

# 5454

And indeed they imagined, even as ye imagined, that Allah will not raise any one.

# 5455

And we sought to reach the heaven; then we found it filled with a strong guard and darting meteors.

# 5456

And we were wont to sit on seats therein to listen; but whosoever listeneth now findeth for him a dartin meteor in wait.

# 5457

And we know not whether evil is boded for those who are on the earth, or whether their Lord intendeth for them a right direction.

# 5458

And of us there are some righteous, and of us are some otherwise; we have been following very diverse.

# 5459

And we known that we cannot frustrate Allah in the earth, nor can we frustrate Him by flight.

# 5460

And when we heard the Message of guidance, we believed therein; and whosoever believeth in his Lord, he shall fear neither diminution nor wrong.

# 5461

And of us some are Muslims, and of us some are deviators. Then whosoever hath embraced Islam - such have endeavoured after a Path of rectitude.

# 5462

And as for the deviators, for Hell they shall be fuel.

# 5463

And had they kept to the path surely We would have watered them with rain plenteous.

# 5464

That We might try them there by. And whosoever turneth aside from the remembrance of his Lord, him He shall thrust into a torment vehement.

# 5465

And the prostrations are for Allah; wherefore call not along with Allah anyone.

# 5466

And when the bondman of Allah stood calling upon Him, they well nigh pressed on him stifling.

# 5467

Say thou: I simply call upon Allah, and I associate not with Him any-one.

# 5468

Say thou: 'verily own not for you power of hurt nor of benefit

# 5469

Say thou: 'verily none can protect me from Allah, nor can I find beside Him any refuge.

# 5470

Mine is but the publishing from Allah and His messages; and whosoever disobeyeth Allah and His apostle, his portion verily is the Hell-Fire as abiders therein for evermore.

# 5471

They shall go on denying until they; behold that which they are promised wherefore then they shall know who were weaker in protectors and fewer in number.

# 5472

Say thou: know not whather that which ye are promised is nigh, or whether my Lord hath appointed for it a distant term.

# 5473

He is the Knower of the unseen, and He discloseth not His unseen Unto anyone.

# 5474

Save Unto an apostle chosen. And then He causeth to go before him and behind him a guard.

# 5475

That He may know that they have preached the message of their Lord. And He comprehendeth whatever is with them, and He keepeth count of everything numbered.

# 5476

O thou enwrapped!

# 5477

Stay up the night long save a little -

# 5478

A half thereof, or abate a little thereof,

# 5479

Or increase thereto. And intone the Qur'an with a measured intontion. s

# 5480

Verily We! anon We shall cast upon thee a weighty word.

# 5481

Verily the rising by night! it is most curbing and most conducive to right speech.

# 5482

Verily there is for thee by day occupation prolonged.

# 5483

And remember thou the name of thy Lord, and devote thyself to Him with an exclusive devotion.

# 5484

Lord of the east and the west! No God is there but He! Wherefore take Him for thy trustee.

# 5485

And bear thou with patience whatsoever they say, and depart from them with a becoming departure.

# 5486

And let Me alone with the beliers, owners of ease: and respite thou them a little.

# 5487

Verily with us are heavy fetters and Scorch.

# 5488

And a food that choketh and a torment afflictive.

# 5489

On a Day whereon the earth and the mountains shall quake, and the mountains shall become a sand-heap poured forth.

# 5490

Verily We! We have sent Unto you an apostle, a witness over you, even as We sent Unto Fir'awn an apostle.

# 5491

Then Fir'awn disobeyed the apostle, wherefore We laid hold of him with a painful hold.

# 5492

How then, if ye disbelieve, shall ye escape, on a Day which shall make children grey-headed.

# 5493

And the heaven shall be split there in. His promise needs must be fulfilled.

# 5494

Verily this is an admonition; let him therefore, who will, choose a way Unto his Lord.

# 5495

Verily thy Lord knoweth that thou stayest up near two- thirds of the night, Or half thereof, or a third thereof, and also a party of those who are with thee. And Allah measureth the night and the day. He knoweth that ye can compute it not, He hath relented toward you. Wherefore recite now of the Qur'an, so much as is easy. He knoweth that there will be among you some diseased, and others shall be travelling in the land seeking grace of Allah, and others shall be fighting in the way of Allah. Wherefore recite thereof so much as is easy; and establish the prayer and give the poor-rate and lend Unto Allah a goodly loan. Whatsoever good ye shall send on for your souls, ye shall find it with Allah, better and greater in reward. And ask forgiveness of Allah; verily Allah is Forgiving, Merciful.

# 5496

O thou enveloped?

# 5497

Arise, and warn.

# 5498

And thine Lord magnify!

# 5499

And thine raiment purify.

# 5500

And pollution shun.

# 5501

And bestow not favour that thou mayest receive more.

# 5502

And for the good-will of thy Lord be thou patient.

# 5503

Then when the horn shall be blown,

# 5504

That shall be - that Day-a day hard.

# 5505

For the infidels, not easy.

# 5506

Let Me alone with him whom I created lonely.

# 5507

And for whom I appointed wealth extended.

# 5508

And sons present by his side.

# 5509

And for whom I smoothed everything.

# 5510

And who yet coveteth that shall increase.

# 5511

By no means! Verily he hath been Unto Our signs a foe.

# 5512

Anon I shall afflict him with a fearful woe.

# 5513

Verily he considered, and devised.

# 5514

Perish he! How moliciously he devised!

# 5515

And again perish he! How maliciously he devised!

# 5516

Then looked he,

# 5517

Then frowned he and scowled.

# 5518

Then turned he back, and grew stiff-necked.

# 5519

Then he said: naught is this but magic from of old;

# 5520

Naught is this but the word of Man.

# 5521

Anon shall I roast him into the Scorching Fire.

# 5522

And what knoweth thou that which the Scorching Fire?

# 5523

It shall not spare, nor leave.

# 5524

. Scorching the skin.

# 5525

Over it are appointed nineteen.

# 5526

And We have appointed none but the angels to be wardens of the Fire. And their number we have made only a trial for those who disbelieve, so that those who are vouchsafed the Book may be convinced, and that those who believe may increase in faith, and that those who are vouchsafed the Book and the believers may not doubt, and that those in whose hearts is a disease and the infidels may say: what meaneth Allah by this description! In this wise Allah sendeth astray whomsoever He will, and guideth whomsoever He will. And none knoweth the hosts of thy Lord but He. And it is naught but an admonition Unto man.

# 5527

By no means! By the moon,

# 5528

By the night when it with draweth.

# 5529

By the morning when it brighteneth.

# 5530

Verily it is one of the greatest woes.

# 5531

A warning Unto humankind -

# 5532

A warning Unto him of you who shall go forward or who chooseth to lag behind.

# 5533

Every soul will be a pledge for that which it hath earned,

# 5534

Save the fellows of the right.

# 5535

In Gardens; they shall be asking,

# 5536

Concerning the culprits:

# 5537

What led you into the Scorching Fire?

# 5538

They will say. 'we have not been of those who prayed.

# 5539

And we have not been feeding the poor.

# 5540

And we have been wading with the waders.

# 5541

And we have been belying the Day of Requital.

# 5542

until there came to us the certainty.

# 5543

Then there will not Profit them intercision of the interceders,

# 5544

What aileth them, therefore, that they are from the Admonition turning away?

# 5545

As though they were asses startled."

# 5546

Fleeing away from a lion.

# 5547

Aye! every one of them desireth that: he should be vouchsafed scrolls expanded.

# 5548

By no means! Aye, they fear not the Hereafter.

# 5549

By no means! Verily this Qur'an is an Admonition.

# 5550

So whosoever willeth may heed it.

# 5551

And they shall not heed unless Allah Willeth. He is the Lord of piety. and the Lord of forgiveness

# 5552

I swear by the Day of Resurrection.

# 5553

And I swear by the self-reproaching soul.

# 5554

Deemest man that We shall not assemble his bones?

# 5555

Yea! WE are Able to put together evenly his finger-tips.

# 5556

Aye! man desireth that he may sin before him.

# 5557

He asketh: when will the Day of Resurrection be?

# 5558

When, then, the sight shall be confounded.

# 5559

And the moon shall be ecliped.

# 5560

And the sun and the moon shall be joined.

# 5561

On that Day shall man say: whither is the fleeing.

# 5562

By no means! NO refuge!

# 5563

Unto thy Lord that Day is the recourse.

# 5564

To man will be declared on that Day that which he hath sent on and left behind.

# 5565

Aye! man against himself shall be an enlightenment.

# 5566

Although he may put forth his pleas.

# 5567

Move not thy tongue therewith that thou mayest hasten therewith.

# 5568

Verily upon us is the collecting thereof and the reciting thereof.

# 5569

Wherefore when We reciteit, follow thou the reciting thereof.

# 5570

And thereafter verily upon us is is the expounding thereof.

# 5571

By no means! Verily ye love the Herein.

# 5572

And leave the Hereafter.

# 5573

Countenances on that Day shall be resplendent,

# 5574

Looking toward their Lord.

# 5575

And countenances on that Day shall be scowling.

# 5576

Imagining that there will befall them a waiste-breaking calomity.

# 5577

By no means! When it cometh up to he collar-bone.

# 5578

And it is cried. who can charm?

# 5579

And he bethinketh that it is the time of parting.

# 5580

And one shank is entangled with the other shank.

# 5581

Unto thy Lord that Day is the drive.

# 5582

He neither believed nor prayed,

# 5583

But he belied and turned away.

# 5584

Then he departed Unto his house hold conceitedly.

# 5585

Woe Unto thee; woe!

# 5586

Again, woe Unto thee, woe!

# 5587

Deemest man that he is to be left uncontrolled?

# 5588

Was he not a sperm of emission emitted?

# 5589

Then he became a clot; then He created him and formed him.

# 5590

And made of him the two sexes, male and female.

# 5591

Is not That One then Able to quicken the dead?

# 5592

Surely there hath come upon man a space of time when he was not a thing worth mentioning.

# 5593

Verily We! We created man from a sperm of mixtures, that We might prove him, wherefore We made him hearing, seeing.

# 5594

Verily We! We shewed him the way; then he becometh either thankful or ingrate.

# 5595

Verily We! We have gotten ready for the infidels chains and collars and a Blaze.

# 5596

Verily the pious shall drink of a cup whereof the admixture is like Unto camphor.

# 5597

From a fountain whence the bondmen of Allah will drink, causing it to gush abundantly.

# 5598

They fulfill their vow and dread a Day the evil whereof shall be widespreading.

# 5599

And they feed with food, for love of Him, the needy, and the orphan and the captive.

# 5600

Saying: we feed you only for the sake of Allah; we desire not from you any recompense or thanks.

# 5601

Verily we dread from our Lord a Day grim and distressful.

# 5602

Wherefore Allah shall preserve them from the evil of that Day, and shall cause them to meet brightness and joy.

# 5603

And shall recompense them for that which they patiently bare with a Garden and silken garment.

# 5604

Reclining therein upon couches, they shall behold therein neither sun nor hurting cold.

# 5605

And close upon them will be the shades thereof, and low will hang the clusters thereof greatly.

# 5606

And brought round amongst them will be vessels of silver and also goblets of glass.

# 5607

Godblets of silver, they shall have filled them to exact measure.

# 5608

And therein they shall be given to drink of a cup whereof the admixture will be ginger.

# 5609

From a fountain therein, named Salsabil.

# 5610

And there shall go round Unto them youths ever-young. When thou seest them thou wouldst deem them pearls unstrung.

# 5611

And when thou lookest them thou shalt behold delight and a dominion magnificent.

# 5612

Upon them shall be garments of fine green silk and of brocades. And adorned they shall be with bracelets of silver: and their Lord shall give them drink a beverage pure.

# 5613

Verily this is for you by way of recompense, and your endeavour hath been accepted.

# 5614

Verily We! it is We Who have revealed Unto thee the Qur'an, a gradual revelation.

# 5615

Wherefore persevere thou with the commandment of thy Lord, and obey not thou of them, any sinner or ingrate.

# 5616

And remember thou the name of thy Lord in the morning and in the evening.

# 5617

And during the night - worship Him; and hallow Him the livelong night.

# 5618

Verily those love the Herein, and leave in front of them a heavy day.

# 5619

It it We Who creared them and made them firm of make. And whenever We list, We can replace them with others like Unto them.

# 5620

Verily this is an admonition; then whosoever Will, may choose a way Unto his Lord.

# 5621

And ye will not, unless Allah willeth. Verily Allah is ever Knowing, Wise.'

# 5622

He maketh whomsoever He listeth to enter His mercy. And the wrong-doers! for them He hath gotten ready a torment afflective.

# 5623

By the winds sent forth with beneficence.

# 5624

And those raging swiftly;

# 5625

By the spreading winds spreading.

# 5626

And the scattering wind scattering.

# 5627

And those winds that bring down the remembrance.

# 5628

By way of excuse or warning.

# 5629

Verily that which ye are promised is about to befall.

# 5630

So when stars are effaced.

# 5631

And when the heaven is cloven asunder.

# 5632

And when the mountains are carried away by wind.

# 5633

And when the apostles are collected at the appointed time,

# 5634

For what day is it timed?

# 5635

For the Day of Decision.

# 5636

And what knowest thou what the Day of Decision is?

# 5637

Woe on that day Unto the beliers

# 5638

Destroyed We not the ancients?

# 5639

Thereafter We shall cause to follow them the latter ones.

# 5640

In this wise We do with the culprits.

# 5641

Woe on that day Unto the beliers!

# 5642

Created We you not of water despicable,

# 5643

Which We placed in a depository safe.

# 5644

Till a limit known?

# 5645

So We decreed. How excellent are We as decreers!

# 5646

Woe on that day Unto the beliers!

# 5647

Have We not made the earth a receptacle.

# 5648

Both for the living and the dead,

# 5649

And have placed therein firm and tall mountains and given you to drink of water fresh

# 5650

Woe on that day Unto the beliers!

# 5651

'Depart Unto that which ye were wont to belie.

# 5652

Depart Unto the shadow three branched:

# 5653

Neither shading nor availing against the flame.

# 5654

Verily it shall cast forth sparks like Unto a castle.

# 5655

As though they were camels yellow tawny.

# 5656

Woe on that day Unto the beliers!

# 5657

This is a Day whereon they shall not be able to speak.

# 5658

Nor shall they be permitted so that they might excuse themselves.

# 5659

Woe on that day Unto the beliers!

# 5660

This is the Day of Decision, We have assembled both ye and the ancients.

# 5661

If now ye have any craft, try that craft upon Me.

# 5662

Woe on the day Unto the beliers!

# 5663

Verily the God-fearing shall be amid shades and springs,

# 5664

And fruits such as they shall desire.

# 5665

'Eat and drink with relish that which ye have been working.

# 5666

Verily We! in this wise We recompense the well-doers.

# 5667

Woe on that day Unto the beliers!

# 5668

'Eat and enjoy a little; verily ye are culprits.

# 5669

Woe on that day Unto the beliers!

# 5670

And when it is said Unto them: 'bow down, they bow not down.

# 5671

Woe on that day Unto the beliers!

# 5672

In what discourse, then, after it, will they believe?

# 5673

Of what ask they?

# 5674

Of the mighty Announcement,

# 5675

Concerning which they differ.

# 5676

By no means! anon they shall know.

# 5677

Again, by no means! anon they shall know.

# 5678

Have We not made the earth an expanse.

# 5679

And the mountains as stakes?

# 5680

And We have created you in pairs.

# 5681

And We have made your sleep as a rest.

# 5682

And We have made the night a covering.

# 5683

And We have made the day for seeking livelihood.

# 5684

And We have builded over you seven strong heavens.

# 5685

And We have set therein lamps glowing.

# 5686

And We have sent down from the rain-clouds water plenteous.

# 5687

So that We bring forth thereby corn and vegetation.

# 5688

And gardens thick with trees.

# 5689

Verily the Day of Decision is a time appointed.

# 5690

It is a Day whereon the trumpet will be blown, and ye will come in multitudes.

# 5691

And the heaven will have been opened, and it will have become doors.

# 5692

And the mountains will have been removed away, and they will have become as mirage.

# 5693

Verily the Hell is an ambuscade:

# 5694

For the exorbitant a receptacle.

# 5695

They will tarry therein for ages.

# 5696

They will not taste therein cool or any drink.

# 5697

Save scalding water and corruption.

# 5698

Recompense fitted!

# 5699

Verily they were wont not to look for a reckoning.

# 5700

And they belied Our revelations with strong belying.

# 5701

And everything We have recorded in a book.

# 5702

Taste therefore. We shall not increase you in aught but torment.

# 5703

Verily for the God-fearing is an achievement.

# 5704

Gardens enclosed and vineyards,

# 5705

And full-breasted maidens of equal age.

# 5706

And a cup overflowing.

# 5707

They will hear therein no babble nor falsehood:

# 5708

A recompense from thy Lord-a gift sufficient -

# 5709

From the Lord of the heavens and the earth and of whatsoever is in bet-ween them, the Compassionate with Whom they can demand not audience.

# 5710

On the Day whereon the spirits and the angels will stand arrayed, they will not be able to speak save him whom the Compassionate giveth leave and who speaketh aright.

# 5711

That is the Sure Day. Whosoever therefore willeth, let him betake Unto his Lord a resort.

# 5712

Verily We! We have warned you of a torment nigh at hand, a Day whereon a man shall behold that which his hands have sent forth, and the infidel will say: would that I were dust!

# 5713

By the angels who drag forth vehemently.

# 5714

By the angels who release with gentle release.

# 5715

By the angels who glide swimmingiy,

# 5716

And then they speed with foremost speed.

# 5717

And then they manage the affair,

# 5718

A Day shall come whereon the quaking will quake,

# 5719

And there will follow it the next blast.

# 5720

Hearts on that Day will be throbbing;

# 5721

Their looks will be downcast.

# 5722

They say: shall we indeed be restored to the first state,

# 5723

When we have become bones decayed!

# 5724

They say: that then shall be a losing return.

# 5725

It will be only one scaring shout,

# 5726

And lo! they all shall appear on the surface.

# 5727

Hath there come Unto thee the story of Musa!

# 5728

Recall what time his Lord called Unto him in the holy vale of Tuwa.

# 5729

Saying:'go thou Unto Fir'awn; verily he hath waxen exorbitant.

# 5730

Then say thou: 'wouldst thou to be purified?

# 5731

Then shall guide thee Unto thy Lord so that thou shalt fear.

# 5732

Then he shewed him the great sign.

# 5733

Yet he belied and disobeyed.

# 5734

Then he turned back striving.

# 5735

Then he gathered and cried aloud,

# 5736

And he said: I am Your Lord, most high.

# 5737

Wherefore Allah laid hold of him with the punishment of the Hereafter and of the present.

# 5738

Verily herein is lesson for him who feareth.

# 5739

Are ye harder to create or the heaven which He hath builded?

# 5740

He hath raised the height thereof and perfected it.

# 5741

And He made dark its night, and brought forth its sunshine.

# 5742

And the earth!- thereafter He stretched it out.

# 5743

And he brought forth therefrom its water, and its pasture.

# 5744

And the mountains! - He established them firm:

# 5745

A provision for you and your cattle.

# 5746

Then when the Grand Calamity shall come

# 5747

The Day whereon man shall rember whatsoever he had striven for.

# 5748

And the Scorch will be made apparent to any one who beholdeth.

# 5749

Then as for him who waxed exorbitant,

# 5750

And who chose the life of the world,

# 5751

Verily the Scorch! that shall be his resort.

# 5752

And as for him who dreaded standing before his Lord, and restrained his soul from lust,

# 5753

Verily the Garden! -that shall be his resort.

# 5754

They question thee of the Hour:'when will its arrival be?

# 5755

Wherein art thou concerred with the declaration thereof!

# 5756

Unto thy Lord is the Knowledge of the limit fixed therefor.

# 5757

Thou art but a warner Unto him who feareth.

# 5758

On the Day whereon they behold it, it will appear to them as though they had not tarried save an evening or the morn thereof.

# 5759

He frowned and turned away.

# 5760

Because there came Unto him a blind man.

# 5761

How canst thou know, whether haply he might be cleansed,

# 5762

Or be admonished, so that the admonition might have profited him?

# 5763

As for him who regardeth himself self-sufficient-

# 5764

Unto him thou attendest.

# 5765

Whereas it is not on thee that he is not cleansed.

# 5766

And as for him who cometh Unto thee running,

# 5767

And he feareth'-

# 5768

Him thou neglectest!

# 5769

By no means! Verily it is an admonition.

# 5770

So whosoever willeth-let him be admonished therewlth.

# 5771

Inscribed in Writs honoured,"

# 5772

Exalted, Purified,

# 5773

By the hands of scribes.

# 5774

Honourable and virtuous.

# 5775

Perish man! how ungrateful he is!

# 5776

Of what thing hath He created him?

# 5777

Of a drop of seed. He created him and formed him according to a measure.

# 5778

Then the way He made easy.

# 5779

Then He caused him to die and made him to be buried.

# 5780

Then when He listeth, He shall raise him to life.

# 5781

By no means He performed not that which He had commanded him.

# 5782

Let man look at his food:

# 5783

It is We Who pour forth water, pouring,

# 5784

Thereafter We cleave the earth in clefts,

# 5785

Then We cause therein the grain to grow,

# 5786

And grapes and vegetables

# 5787

And olives and palms

# 5788

And enclosed gardens luxuriant.

# 5789

And fruits and herbage:

# 5790

A provision for you and for your cattle.

# 5791

Then when cometh the Deafening Cry-

# 5792

On the Day whereon a man shall flee from his brother,

# 5793

And his mother and his father,

# 5794

And his wife and his sons;

# 5795

For every one of them on that Day shall be business enough to occupy

# 5796

Faces on that Day shall be beaming,

# 5797

Laughing, rejoicing.

# 5798

And faces on that Day! upon them shall be gloom.

# 5799

Dust shall cover them

# 5800

Those! they are the infidels, the ungodly.

# 5801

When the sun shall be wound round,

# 5802

And when the stars shall dart down,

# 5803

And when the mountains shall be made to pass away,

# 5804

And when the she-camels big with young shall be abandoned,

# 5805

And when the wild beasts shall be gathered together,

# 5806

And when the seas shall be filled,

# 5807

And when the souls he paired,

# 5808

And when the girl buried alive shall be asked:

# 5809

For what sin she was slain.

# 5810

And when the Writs shall be lain open,

# 5811

And when the heaven shall be stripped,

# 5812

And when the Scorch shall be made to blaze,

# 5813

And when the Garden shall be brought nigh,

# 5814

Then every soul shall know that which it: hath presented.

# 5815

I swear by the receding stars.

# 5816

Moving swiftly and hiding themselves,

# 5817

And by the night when it departeth,

# 5818

And by the morning when it shineth forth,

# 5819

Verily it is a Word brought by a messenger honoured,

# 5820

Owner of strength, of established dignity with the Lord of the Throne.

# 5821

Obeyed one there; trustWorthy.

# 5822

Nor is your companion distracted.

# 5823

Assuredly he beheld him in the horizon manifest.

# 5824

And he is of the unseen not a tenacious concealer.

# 5825

Nor is it the word of a Satan accursed.

# 5826

Whither then go ye?

# 5827

This is naught but an Admonition Unto the worlds-

# 5828

Unto whomsoever of you willeth to walk straight.

# 5829

And ye shall not will unless it be that Allah, the Lord of the worlds, willeth.

# 5830

When the heaven shall be cleft,

# 5831

And when the stars shall be scattered,

# 5832

And when the seas are flowed out,

# 5833

And when the graves are ransacked,

# 5834

Each soul shall know that which it sent afore and that which it left behind.

# 5835

O man! what hath beguiled thee concerning thy Lord, the Bountiful,

# 5836

Who created thee, then moulded thee, then proportioned thee?

# 5837

In whatsoever form He listed He constructed thee.

# 5838

By no means! Aye, ye belie the the Requital.

# 5839

Verify there are for you guardians,

# 5840

Honourablel scribes.

# 5841

They know whatsoever ye do.

# 5842

Verily the pious shall be in Delight.

# 5843

And verily the ungodly shall be in a Scorch.

# 5844

Roasted they shall be therein on the Day of Requital.

# 5845

And thence they shall not be allowed to be absent.

# 5846

And what shall make thee know whatsoever the Day of Requital is?

# 5847

Again, what shall make thee know whatsoever the Day of Requital is?

# 5848

It is a Day whereon no soul shall own aught of power for any soul; and the command on that Day will be Allah's.

# 5849

Woe Unto the scrimpers:

# 5850

Those who, when they take by measure from mankind, exact the full,

# 5851

And who, when they measure Unto them or weigh for them, diminish.

# 5852

Imagine such men not that they shall be raised up?

# 5853

On a mighty Day.

# 5854

A Day whereon mankind shall stand before the Lord of the worlds?

# 5855

By no means! Verily the record of the ungodly is in Sijjin.

# 5856

And what will make thee know whatsoever the record in Sijjin is?

# 5857

A record of misdeeds written.

# 5858

Woe on that Day unto the belviers-

# 5859

Those who belie the Day of Requital.

# 5860

And none belieth it save each trespasser, sinner.

# 5861

And when Our revelations are rehearsed Unto him, she saith:'fables of the ancients!

# 5862

By no means!' Aye! encrusted upon their hearts is that which they have been earning.

# 5863

By no means! Verily on that Day from their Lord they will be shut Out.

# 5864

Then verily they will be roasted into the Scorch.

# 5865

Then it will be said: 'this is that which ye were wont to belie.'

# 5866

By no means! Verily the record of the virtuous shall be in 'Illiyun.

# 5867

And what will make thee know whatsoever the record in Illiyun is?

# 5868

A record of good deeds written.

# 5869

To which bear witness those brought nigh.

# 5870

Verily the virtuous shall be in Delight,

# 5871

Reclining on couches, looking on.

# 5872

Thou wilt recognize in their faces the brightness of delight.

# 5873

They will be given to drink of pure wine, sealed.

# 5874

The seal thereof will be of musk and to this end let the aspirers aspire -

# 5875

And admixture thereof will be Water of Tasnim:

# 5876

A fountain whereof will drink those brought nigh.

# 5877

Veriiy those who have sinned were wont at those who had believed to laugh,

# 5878

And, when they passed them, to wink at each other,

# 5879

And when they returned to their household they returned jesting.

# 5880

And when they saw them, they said: verily these are the strayed ones.

# 5881

Whereas they were not sent over them as watchers.

# 5882

Wherefore Today, those who believed at the infidels are laughing,

# 5883

Reclining on couches, looking on.

# 5884

The infidels have indeed been rewarded for that which they had been doing.

# 5885

When the heaven is sundered.

# 5886

And it hearkeneth to its Lord, and is duteous,

# 5887

And when the earth shall be stretched forth.

# 5888

And shall cast forth that which is therein, and shall become empty.

# 5889

And it hearkeneth to its Lord, and is duteous.

# 5890

O man! verily thou art toiling toward thy Lord a painful toiling, and art about to meet Him.

# 5891

Then as to him who shall be given his book in his right hand -

# 5892

His account shall presently be taken by an easy reckoning.

# 5893

And he shall return Unto his people joyfully.

# 5894

And as to him who shall be given his book from behind his back-

# 5895

He shall presently call for death,

# 5896

And he shall roast into a Blaze.

# 5897

Verily he was among his people joyous.

# 5898

Verily he imagined that he would not be back.

# 5899

Yea! his Lord had ever been beholding him.

# 5900

I swear by the afterglow of sunset,

# 5901

And by the night and that which it driveth together,

# 5902

And by the moon when she becometh full.

# 5903

Surely ye shall ride layer upon layer.

# 5904

What aileth them then, that they believe not,

# 5905

And that, when the Qur'an is read Unto them, they prostrate not them-selves!

# 5906

Yea those who disbelieve belie.

# 5907

Whereas Allah knoweth best that which they cherish.

# 5908

Wherefore announce thou Unto them a torment afflictive.

# 5909

But those who believe and work righteous works, theirs shall be a hire unending.

# 5910

By the heaven adorned with big stars.

# 5911

And by the Day promised,

# 5912

And by the Day witnessing and the Day witnessed,

# 5913

Perish the fellows of the ditch,

# 5914

Of fire fuel-fed,

# 5915

When they sat by it

# 5916

And to that which they did to the believers were witnesses.

# 5917

And they persecuted them for naught save that they believed in Allah, the Mighty, the Praiseworthy

# 5918

Him, Whose is the dominion of heavens and the earth. And Allah is over everything a Witness.

# 5919

Verily those who affected the believing men and the believing women, and then repented not, theirs shall be the torment of Hell, and theirs shall be the torment of burning.

# 5920

Verily those who believed and worked righteons works, theirs shall be Gardens whereunder the rivers flow; that is the supreme achievement.

# 5921

Verily the grip of thine Lord is severe.

# 5922

Verily He! He it is who beginneth and repeateth it.

# 5923

And He is the Fogiving, the Loving,

# 5924

Lord of the Throne, the Glorious,

# 5925

Doer of whatsoever He intendeth.

# 5926

Hath there come Unto thee the story of the hosts-

# 5927

Of the Fir'awn and the Thamud?

# 5928

But those who disbelieve are engaged in denial.

# 5929

Whereas Allah is, from behind them, Encompassing.

# 5930

Aye! it is a Recitation glorious,

# 5931

Inscribed in a tablet preserved.

# 5932

By the heaven and the night-comer

# 5933

And what shall make thee know that which the night-comer is?-

# 5934

It is the star shing brightly.

# 5935

No soul is there but hath over it a watcher.

# 5936

So let man look - from what is he created.

# 5937

He is created from a water drip-ping,

# 5938

That issueth from between the loins and the breast-bones.

# 5939

Verily He is Able to restore him,

# 5940

On a Day whereon secrets shall be out.

# 5941

Then he shall have no power nor any helper.

# 5942

By the heaven which returneth,

# 5943

And by the earth which splitteth,

# 5944

Verily, it is a discourse distinguishing.

# 5945

And it is not a frivolity.

# 5946

Verily they are plotting a plot.

# 5947

And I am plotting a plot.

# 5948

So respite thou the infidels - respite them gently,

# 5949

Hallow thou the name of thine Lord, the Most High,

# 5950

Who hath created and then proportioned,

# 5951

And Who hath disposed and then guided,

# 5952

And Who bringeth forth the pasturage,

# 5953

Then maketh it to stubble dusky.

# 5954

We shall enable thee to recite, and then thou shalt not forget,

# 5955

Save that which Allah may will. Verily He knoweth the public and that which is hidden.

# 5956

And We shall make easy Unto thee the easy way.

# 5957

Wherefore admonish thou; admonition hath surely profited,

# 5958

Admonished is he indeed who feareth,

# 5959

And the wretched shunneth it-.

# 5960

He Who shall roast into the Great Fire,

# 5961

Wherein he shall neither die nor live,

# 5962

He indeed hath attained bliss who hath cleansed himself,

# 5963

And who remembereth the name of his Lord, and then prayeth.

# 5964

But ye prefer the life of this world,

# 5965

Whereas the Hereafter is better and more lasting.

# 5966

Verily this is in Writs ancient

# 5967

Writs of Ibrahim and Musa.

# 5968

Hath there come Unto thee the story of the Enveloping Event?

# 5969

Faces on that Day shall be downcast,

# 5970

Travailing, worn.

# 5971

They shall roast into the scalding Fire,

# 5972

Given to drink of a spring fiercely boiling.

# 5973

No food shall be theirs save bitter thorn,

# 5974

Which shall neither nourish nor avail against hunger.

# 5975

Faces on that Day shall be de lighted,

# 5976

With their endeavour well pleased.

# 5977

They shall be in a Garden lofty:

# 5978

They shall hear therein no vain discourse;

# 5979

Therein shall be a spring running!

# 5980

Therein shall be couches elevated!

# 5981

And goblets ready placed!

# 5982

And cushions ranged!

# 5983

And carpets ready spread,

# 5984

Look they not at the camels, how they are created?

# 5985

And at the heaven, how it is raised?

# 5986

And at the mountains, how they are rooted?

# 5987

And at the earth, how it is outspread?

# 5988

Admonish thou then; thou art but an admonisher.

# 5989

Thou art not over them a warden.

# 5990

But whosoever will turn back and disbelieve -

# 5991

Him Allah shall torment with the greatest torment.

# 5992

Verily Unto us is their reckoning.

# 5993

Then verily on us is their reckoning.

# 5994

By the dawn,

# 5995

And by ten nights,

# 5996

And by the even and the odd,

# 5997

And by the night when it departeth,

# 5998

Indeed in that there is an oath for a man of sense.

# 5999

Bethinkest thou not in what wise thy Lord did with the 'A'ad:

# 6000

The people of many-columned lram.

# 6001

The like of which was not built in the cities,

# 6002

And With Thamud who hewed out rocks in the vale,

# 6003

And with Fir'awn, owner of the stakes -

# 6004

Who all waxed exorbitant in the cities,

# 6005

And multiplied therein corruption.

# 6006

Wherefore thy Lord poured on them the scourge of His torment.

# 6007

Verily thy Lord is in an ambuscade,

# 6008

As for man - when his Lord proveth him and so honoureth him and is bounteous Unto him, then he saith: 'my Lord hath honoured me,

# 6009

And when He proveth him, and so stinteth Unto him his provision, he saith: 'my Lord hath despised me.

# 6010

By no means! But ye honour not the orphan,

# 6011

Nor urge upon each other the feeding of the poor,

# 6012

And devour the inheritance devouring greedily,

# 6013

And ye love riches with exceeding love.

# 6014

By no means! when the earth shall be ground with grinding, grinding,

# 6015

And thy Lord shall come and the angels, rank on rank.

# 6016

And the Hell on that Day shall be brought nigh. On that Day man shall remember, but how will remembrance avail him?

# 6017

He will say. 'would that I had sent before for this life of mine!

# 6018

Wherefore on that Day none shall torment with His torment.

# 6019

Nor shall any bind with His bond.

# 6020

O thou peaceful soul!

# 6021

Return Unto thine Lord well pleased and well-pleasing.

# 6022

Enter thou among My righteous bondmen!

# 6023

And enter thou My Garden.

# 6024

I swear by yonder city

# 6025

And thou shalt be allowed in yonder city -

# 6026

And by the begetter and that which he begat,

# 6027

Assuredly We have created man in trouble.

# 6028

Deemest he that none will overpower him?

# 6029

He saith: 'I have wasted riches plenteous.

# 6030

Deemest he that none beholdeth him?

# 6031

Have We not, made for him two eyes

# 6032

And a tongue and two lips,

# 6033

And shown Unto him the two highways?

# 6034

Yet he attempteth not the steep,

# 6035

And what shall make thee understand that which the steep is?

# 6036

It is freeing the neck,

# 6037

Or, feeding, in a day of privation,

# 6038

An orphan, of kin,

# 6039

Or a poor man cleaving to the dust.

# 6040

Then he became of those who believed and enjoined on each other steadfastness and enjoined on each other compassion.

# 6041

These are the fellows of the righthand.

# 6042

And those who disbelieve Our signs - they are the fellows of the lefthand.

# 6043

Over them shall be Fire closing round.

# 6044

By the sun and his morning bright-ness,

# 6045

By the moon, when she followeth him,

# 6046

By the day when it glorifieth him.

# 6047

By the night; when it envelopeth him,

# 6048

By the heaven and Him Who builded it,

# 6049

By the earth and Him Who spread it forth,

# 6050

By the soul and Him Who propertioned it,

# 6051

And inspired it with the wickedness thereof and the piety thereof,

# 6052

Surely blissful is he who hath cleansed, it,

# 6053

And miserable is he who hath buried it.

# 6054

Thamud belied in their exorbitance.

# 6055

What time the greatest wretch of them rose up.

# 6056

Then the apostle of Allah said Unto them: beware of the she-camel of Allah and her drink.

# 6057

Then they belied him, and they hamstrung her; wherefore their Lord overwhelmed them for their crime, and made it equal.

# 6058

And He feared not the consequence thereof

# 6059

By the night when it envelopeth,

# 6060

By the day when it appeareth in glory,

# 6061

By Him Who hath created the male and the female,

# 6062

Verily your endeavour is diverse.

# 6063

Then as for him who giveths and feareth Him.

# 6064

And testifieth to the Good,

# 6065

Unto him therefore We shall indeed make easy the path to ease.

# 6066

And as for him who stinteth and is heedless,

# 6067

And who belieth the Good,

# 6068

Unto him therefore We shall Indeed make easy the path to hardship.

# 6069

And his substance will avail him not when he perisheth.

# 6070

Verify on us is the guidance

# 6071

And verify Ours is both the Hereafter and the life present.

# 6072

Wherefore have warned you of Fire flaming,

# 6073

None shall roast therein but the most wretched,

# 6074

Who belieth and turneth away.

# 6075

And avoid it shall the most pious,

# 6076

Who giveth away his substance that he may be cleansed,

# 6077

And who hath no favour from anyone to recompense.

# 6078

But only seeking the Countenance of his Lord the Most High.

# 6079

And presently he shall become wellpleased.

# 6080

By the morning brightness,

# 6081

By the night when it darkeneth,

# 6082

Thy Lord hath not forsaken thee, nor is He displeased.

# 6083

And the Hereafter is indeed better Unto thee than the life present.

# 6084

And presently thy Lord shall give Unto thee so that thou shalt be be well-pleased.

# 6085

Found He not thee an orphan, so He sheltered thee?

# 6086

And He found thee wandering, so He guided thee,

# 6087

And He found thee destitute, so He enriched thee.

# 6088

Wherefore as to the orphan, be thou not Unto him overbearing.

# 6089

And as to the beggar, chide thou him not.

# 6090

And as to the favour of thine Lord discourse thou thereof.

# 6091

Have We not opened forth for thee thy breast?

# 6092

And We have taken off from thee thy burthen,

# 6093

Which weighed down thy back.

# 6094

And We have upraised for thee thy renown.

# 6095

Then verily along with every hardship is ease.

# 6096

Verily along with every hardship is ease.

# 6097

Then when thou becometh relieved, toil;

# 6098

And Unto thine Lord, attend.

# 6099

By the fig, by the olive,

# 6100

By Mount Sinai,

# 6101

By the yonder secure city,

# 6102

Assuredly We have created man in goodliest mould,

# 6103

Thereafter We cause him to return to the lowest of the low,

# 6104

Save those who believe and work righteous Works. Theirs shall be hire unending.

# 6105

What hencefort shall make thee belie the Requital?

# 6106

Is not Allah the Greatest of the rulers?

# 6107

Recite thou in the name of thy Lord Who hath created -

# 6108

Hath created man from a clot!

# 6109

Recite thou: And thy Lord is the Most Bounteous,

# 6110

Who hath taught mankind by the pen -

# 6111

Hath taught man that which he knew not.

# 6112

By no means: Verily man exorbitateth.

# 6113

As he bethinkest himself selfsufficient.

# 6114

Verily Unto thy Lord is the return.

# 6115

Bethinkest thou him who forbiddeth,

# 6116

A bondman of Ours when he prayeth \*

# 6117

Bethinkest thou, if he is himself guided,

# 6118

Or he commandeth piety?

# 6119

Bethinkest thou, if he belieth and turneth away?

# 6120

Knoweth he not that Allah beholdeth?

# 6121

By no means! If he desist not We shall seize and deal him by the forelock -

# 6122

A forelock, lying, sinning.

# 6123

Then, let him call his assembly,

# 6124

We also shall call the infernal guards.

# 6125

By no means! Obey not thou him. Continue to adore, and continue to draw nigh.

# 6126

Verily We! We have sent it down on the night of Power.

# 6127

And what shall make thee know that which the night of Power is?

# 6128

The night of Power is better than a thousand months.

# 6129

The angels and the spirit descend therein by the command of their Lord with His decrees for every affair.

# 6130

It is all peace, until the rising of the dawn.

# 6131

Those who disbelieved from among the People of the Book and the associaters could not break off, until there had come Unto them the evidence.

# 6132

An apostle from Allah rehearsing Writs cleansed.

# 6133

Wherein are discourses eternal.

# 6134

And those who are vouchsafed the Book divided not save after there had come Unto them the evidence.

# 6135

And they were commanded not but that they should worship Allah, keeping religion pure for him, as upright men, and that they should establish prayer and give the poor-rate, And that is the right religion.

# 6136

Verily those who disbelieve from among the people of the Book and the associaters shall be cast into the Hell-fire, as abiders therein. These! they are the worst of the creation.

# 6137

Verily those who believe and work righteous works - these! they are the best of the creation.

# 6138

Their recompense with their Lord shall be Gardens Everlasting, whereunder rivers flow - as abiders therein for evermore. Well-pleases will be Allah with them and well-pleased will be they with Him, That is for him who feareth his Lord.

# 6139

When the earth is shaken by the shaking thereof,

# 6140

And the earth bringeth forth her burthens,

# 6141

And man saith: what aileth her?

# 6142

On that Day she will tell out the tidings thereof.

# 6143

Because thy Lord will inspire her.

# 6144

On that Day mankind will proceed in bands, that they may be shewn their works.

# 6145

Then whosoever hath worked good of an atom's weight shall behold it

# 6146

And whosoever hath worked ill Of an atom's weight shall behold it.

# 6147

By the chargers panting,

# 6148

And striking off fire by dashing their hoofs.

# 6149

And raiding at dawn

# 6150

And therein raising dust.

# 6151

And cleaving their way therein into the host,

# 6152

Verily man is Unto his Lord ungrateful.

# 6153

And verily to that he is witness.

# 6154

And verily in the love of wealth he is vehement,

# 6155

Knoweth he not - when that which is in the graves, shall be ransacked?

# 6156

And there shall be brounht to light that which is in the breasts?

# 6157

Verily their Lord on that Day will be of them Aware.

# 6158

The Striking!

# 6159

What is the Striking?

# 6160

What shall Make thee know that which the Striking is?

# 6161

A Day whereon mankind shall become as moths scattered,

# 6162

And the mountains shall become as wool carded,

# 6163

Then as for him whose balances are heavy,

# 6164

He shall be in a lifewell-pleasing.

# 6165

And as for him whose balances are light,

# 6166

His dwelling shall be the Abyss.

# 6167

And what shall make thee know that which she is?

# 6168

A Fire vehemently hot!

# 6169

The emulous desire of abundance engrosseth you,

# 6170

Until ye visit the graves.

# 6171

Lo! presently ye shall know.

# 6172

Again lo! presently ye shall know.

# 6173

Lo! would that ye knew now with the surety of knowledge!

# 6174

Surely ye shall behold theScorch.

# 6175

Then ye shall surely beholdwith the surety of vision.

# 6176

Then, on that Day, ye shall surely be asked of the delights.

# 6177

By the time,

# 6178

Verily man is in loss,

# 6179

But not those who themselves believe and work righteous works, and enjoin upon each other the truth, and enjoin upon each other endurance.

# 6180

Woe Unto every slanderer, traducer,

# 6181

Who amasseth wealth; and counteth it.

# 6182

He bethinketh that his wealth shall abide for him.

# 6183

By no means! He shall surely be cast into the Crushing Fire.

# 6184

And what shall make thee know that which the Crushing Fire is?

# 6185

Fire of Allah, Kindled,

# 6186

Which mounteth up to the hearts.

# 6187

Verily it shall close upon them,

# 6188

In pillars stretched forth.

# 6189

Hast thou not observed what wise thy Lord dealt with the fellows of the elephant?

# 6190

Put He not their stratagem to straying.

# 6191

And He sent against them birds in flocks.

# 6192

They hurled upon them stones of baked clay;

# 6193

Then He rendered them as stubble devoured.

# 6194

For the keeping of the Quraish

# 6195

For their keeping to the journey in the winter and the summer-

# 6196

Let them worship the Lord of this House,

# 6197

Who hath fed them against hunger; and hath rendered them secure from fear.

# 6198

Beholdest thou him who belieth the Requital?

# 6199

It is he who pusheth away the orphan,

# 6200

And urgeth not the feeding of the poor,

# 6201

Woe, therefore, Unto such performers of prayer.

# 6202

As are of their prayer careless.

# 6203

They who would be seen,

# 6204

And who withholds even common necessaries.

# 6205

Verily We! We have given thee Kauthar.

# 6206

Wherefore pray thou Unto thy Lord, and sacrifice.

# 6207

Verily it is thy traducer who shall be tail-less.

# 6208

Say thou: O ye infidels!

# 6209

I worship not, that which ye worship.

# 6210

Nor are ye the worshippers of that which I worship.

# 6211

And I shall not be a worshipper of that which ye have worshipped,

# 6212

Nor will ye be worshippers of that which I worship,

# 6213

Yours shall be your requital, and mine shall be my requital.

# 6214

When there cometh the succour of Allah and the victory,

# 6215

And thou beholdest mankind entering the religion of Allah in crowds,

# 6216

Then hallow the praise of thy Lord, and ask forgiveness of Him. Verily He is ever Relenting.

# 6217

Perish the two hands of Abu Lahab, and perish he!

# 6218

His substance availed him not, nor that which he earned.

# 6219

Anon he shall roast into Fire having flame.

# 6220

And his wife also: the firewood carrier;

# 6221

On her neck shall be a cord of twisted fibre.

# 6222

Say thou: He is Allah, the One!

# 6223

Allah, the Independent,

# 6224

He begetteth not, nor Was He begotten.

# 6225

And there hath never been co-equal with Him anyone.

# 6226

Say thou; I seek refuge with the Lord of the daybreak.

# 6227

From the evil of that which He hath created,

# 6228

And from the evil of the darken when it cometh,

# 6229

And from the evil of the women blowers upon knots,

# 6230

And from the evil of the envier when he envieth.

# 6231

Say thou: I seek refuge with the Lord of mankind,

# 6232

The King of mankind,

# 6233

The God of mankind,

# 6234

From the evil of the sneaking whisperer

# 6235

Who whispereth Unto the breasts of mankind,

# 6236

Whether of Jinn or of mankind.

