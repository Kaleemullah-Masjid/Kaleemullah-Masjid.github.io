<!--
Quran Translation
Name: Ahmed Raza Khan
Translator: Ahmed Raza Khan
Language: English
ID: en.ahmedraza
Last Update: July 17, 2011
Source: Tanzil.net
-->

# 1

Allah - beginning with the name of - the Most Gracious, the Most Merciful.

# 2

All praise is to Allah, the Lord Of The Creation.

# 3

The Most Gracious, the Most Merciful

# 4

Owner of the Day of Recompense

# 5

You alone we worship and from You alone we seek help (and may we always).

# 6

Guide us on the Straight Path.

# 7

The path of those whom You have favoured – Not the path of those who earned Your anger – nor of those who are astray.

# 8

Alif-Laam-Meem. (Alphabets of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 9

This is the exalted Book (the Qur’an), in which there is no place for doubt; a guidance for the pious.

# 10

Those who believe without seeing (the hidden), and keep the (obligatory) prayer established, and spend in Our cause from what We have bestowed upon them.

# 11

And who believe in this (Qur’an) which has been sent down upon you, O beloved Prophet, (Mohammed – peace and blessings be upon him) and what was sent down before you; and are certain of the Hereafter.

# 12

It is they who are on guidance from their Lord; and they are the successful.

# 13

As for those whose fate is disbelief, whether you warn them or do not warn them – it is all one for them; they will not believe. (Because their hearts are sealed – see next verse).

# 14

Allah has sealed their hearts and their ears, and on their eyes is a covering; and for them is a terrible punishment.

# 15

And among the people are some\* that say, “We believe in Allah and the Last Day\*\*” whereas they are not believers! (\* The hypocrites \*\* the Day of Resurrection)

# 16

They wish to deceive Allah and the believers; and in fact they deceive none except themselves and they do not have any understanding.

# 17

In their hearts is a disease, so Allah has increased their disease; and for them is a painful punishment, because of their lies.

# 18

And when it is said to them, “Do not cause turmoil in the earth”, they say, “We are only peacemakers!”

# 19

Pay heed! It is they who are mischievous, but they do not have sense.

# 20

And when it is said to them, “Believe as the others believe”, they say, “Shall we believe as the foolish believe?” It is they who are the fools, but they do not know.

# 21

And when they meet with the believers, they say, “We believe”; and when they are alone with their devils, they say, “We are undoubtedly with you, we were just mocking!”

# 22

Allah (befitting His Majesty) mocks them, leaving them to wander blindly in their rebellion.

# 23

These are the people who purchased error in exchange of guidance – so their bargain did not profit them, and they did not know how to trade.

# 24

Their example is like that of one who kindled a fire; and when it lit up all that was around it, Allah took away their light and left them in darkness, unable to see anything.

# 25

Deaf, dumb and blind; and they are not to return.

# 26

Or like a rainstorm from the sky, in which are darkness, thunder and lightning; they thrust their fingers in their ears due to the thunderclaps, fearing death; and Allah has the disbelievers encompassed.

# 27

It seems the lightning may snatch away their sight from them; whenever it flashes they walk in it, and when it darkens they stand still; if Allah willed, He could take away their hearing and their sight; indeed Allah is Able to do all things.

# 28

O mankind! Worship your Lord, Who has created you and those before you, in the hope of attaining piety.

# 29

The One Who has appointed the earth a base for you, and the sky a canopy – and caused water to pour down from the sky, thereby producing fruits as food for you; and do not knowingly set up rivals to Allah!

# 30

And if you are in any doubt concerning what We have sent down upon Our distinguished bondman (Prophet Mohammed – peace and blessings be upon him), bring forth a single surah (chapter) equal to it; and call upon all your supporters, other than Allah, if you are truthful.

# 31

And if you are unable to bring forth (one chapter) – and We declare that you can never bring one – then fear the fire (of hell), the fuel of which is men and stones; kept ready for the disbelievers.

# 32

And give glad tidings to those who believe and do good deeds; that for them are Gardens beneath which rivers flow; when they are provided with a fruit of the Gardens, they will say, “This is the same food as what was given to us before” whereas it is in resemblance; and in the Gardens are pure spouses for them; and they shall abide in it forever.

# 33

Indeed Allah does not, for the sake of explanation, shy to illustrate an example of anything, whether it is of a gnat or something further (inferior) than it; so the believers know it is the Truth from their Lord; as for the disbelievers, they say, “What does Allah intend by such an example?” He misleads many thereby, and He guides many thereby; and with it He misleads only those who are rebellious.

# 34

Those who break the covenant of Allah after ratifying it – and sever what Allah has ordered to join, and who cause turmoil (evil / religious chaos) in the earth; it is they who are the losers.

# 35

What has made you disbelieve in Allah? Whereas you were dead and He gave you life; then He will give you death, then bring you to life again, and then it is to Him you will return!

# 36

It is He Who created for you all that is in the earth; then He inclined towards the heaven, therefore fashioning it as proper seven heavens; and He knows everything.

# 37

And (remember) when your Lord said to the angels, “I am about to place My Caliph in the earth”; they said, “Will You place (as a caliph) one who will spread turmoil in it and shed blood? Whereas we glorify You with praise and proclaim Your Sanctity”; He said, “I know what you do not.”

# 38

And Allah the Supreme taught Adam all the names (of things), then presented them to the angels, saying, “Tell Me the names of these, if you are truthful.”

# 39

They said, “Purity is to You! We do not have any knowledge except what You have taught us! Indeed You only are the All Knowing, the Wise.”

# 40

He said “O Adam! Inform them the names”; and when Adam had informed them their names, He said, “Did I not tell you that I know all the secrets of the heavens and the earth? And I know all what you disclose and all what you hide?”

# 41

And (remember) when We ordered the angels to prostrate before Adam, so they all prostrated, except Iblis (Satan – devil); he refused and was proud – and became a disbeliever.

# 42

And We said, “O Adam! You and your wife dwell in this Garden, and eat freely from it wherever you please – but do not approach this tree for you will become of those who transgress.”

# 43

So the devil destabilised them in it and removed them from where they were – and We said, “Go down, one of you is an enemy to the other; and for a fixed time you shall stay on earth and feed in it.”

# 44

Then Adam learnt from his Lord certain words (of revelation), therefore Allah accepted his repentance; indeed He only is the Most Acceptor of Repentance, the Most Merciful. (See Verse 7:23)

# 45

We said, “Go down from Paradise, all of you; then if some guidance comes to you from Me – so whoever follows My guidance, for such is neither fear nor any grief.”

# 46

And those who disbelieve and deny Our signs, are the people of fire (hell); they will remain in it forever.

# 47

O Descendants of Israel (Jacob)! Remember My favour which I bestowed upon you, and fulfil your covenant towards Me, I shall fulfil My covenant towards you; and fear Me alone.

# 48

And accept faith in what I have sent down (the Qur’an), which confirms what is with you (the Torah / Bible), and do not be the first to disbelieve in it – and do not exchange My verses for an abject – and fear Me alone.

# 49

And do not mix the truth with falsehood, nor purposely conceal the truth.

# 50

And keep the (obligatory) prayer established, and pay the charity, and bow your heads with those who bow (in prayer).

# 51

What! You enjoin righteousness upon people while you forget (to practise it) yourselves, whereas you read the Book? Do you not have sense?

# 52

And seek help in patience and prayer; and truly it is hard except for those who prostrate before Me with sincerity.

# 53

Who know that they have to meet their Lord, and that it is to Him they are to return.

# 54

O Descendants of Israel! Remember the favour of Mine, which I bestowed upon you and gave you superiority over others of your time. (by sending the Noble Messengers to your nation)

# 55

And fear the Day (of Resurrection) when no soul will be exchanged for another, nor will any intercession be accepted for the disbelievers, nor will they be set free in lieu of compensation nor will they be helped.

# 56

(And remember) When We rescued you from Firaun’s people, for they were inflicting you with a dreadful torment, slaying your sons and sparing your daughters; that was a tremendous trial from your Lord (or a great reward).

# 57

And when We split the sea for you thereby rescuing you, and drowned the Firaun's people in front of your eyes.

# 58

And when We made a commitment with Moosa (Moses) for forty nights – then behind him you started worshipping the calf, and you were unjust.

# 59

Then after that We pardoned you so that you may be grateful.

# 60

And when We gave Moosa the Book (Taurat / Torah) and the criterion to judge right from wrong, so that you may attain guidance.

# 61

And when Moosa said to his people, “O my people! You have wronged yourselves by taking the calf,\* therefore turn in repentance to your Creator, therefore kill each other; this is better for you before your Creator”; He therefore accepted your repentance; indeed He only is the Most Acceptor of Repentance, the Most Merciful. (\* as your deity for worship)

# 62

And when you said “O Moosa! We will not believe you till we clearly see Allah”; so the thunder seized you while you were watching.

# 63

Then We brought you back to life after your death, so that you may be grateful.

# 64

And We made the clouds a canopy for you and sent down Manna and Salwa (birds) on you; “Eat of the pure things We have provided you”; they did not wrong Us in the least, but indeed they wronged themselves.

# 65

And when We said, “Enter this town and eat freely from what is in it, and enter the gate whilst prostrating, and say, ‘May our sins be forgiven’ – We will forgive you your sins; and We will soon increase the reward for the righteous.”

# 66

But the unjust changed the word that had been ordered for another one, so We sent down a punishment on them from the skies, the recompense of their disobedience.

# 67

And when Moosa asked for water for his people, We said, “Strike this rock with your staff”; thereupon twelve springs gushed forth from it; each group recognised its drinking-place; “Eat and drink from what Allah has provided, and do not roam about the earth making turmoil in it.”

# 68

And when you said, “O Moosa! We shall never put up with only one kind of food, so call upon your Lord to produce for us what the earth grows – some herbs, cucumbers, corn, lentils and onions”; he said, “What! You wish to exchange the better for something inferior? Therefore settle down in Egypt or any city, where you will get what you demand”; and disgrace and misery were destined for them; and they returned towards Allah’s wrath; that was because they disbelieved in Allah’s signs and wrongfully martyred the Prophets; that was for their disobedience and transgression.

# 69

Indeed the believers (the Muslims) and those among the Jews, the Christians, and the Sabeans who sincerely accept faith in Allah and the Last Day\* and do good deeds – their reward is with their Lord; and there shall be no fear upon them nor shall they grieve. (\* i.e. convert to Islam)

# 70

And when We made a covenant with you and raised the Mount above you; “Accept and hold fast to what We give you, and remember what is in it, so that you may attain piety.”

# 71

Then after that, you turned away; and were it not for the munificence of Allah and His mercy, you would be among the losers.

# 72

And you certainly know of those amongst you who transgressed in the matter of Sabth (Sabbath – Saturday) – We therefore said to them, “Become apes, despised!”

# 73

So We made this incident (of that town) a warning to the surrounding towns (others of their time) and to succeeding generations, and a lesson for the pious.

# 74

And (remember) when Moosa said to his people, “Allah commands you to sacrifice a cow”; they said, “Are you making fun of us?” He answered, “Allah forbid that I should be of the ignorant!”

# 75

They said, “Pray to your Lord that He may describe the cow”; said Moosa, “He says that it is a cow neither old nor very young but between the two conditions; so do what you are commanded.”

# 76

They said, “Pray to your Lord that He may reveal its colour to us”; answered Moosa, “Indeed He says it is a yellow cow, of bright colour, pleasing to the beholders.”

# 77

They said, “Pray to your Lord that He may clearly describe the cow to us, we are really in a doubt as to which cow it is; and if Allah wills, we will attain guidance.”

# 78

Said Moosa, “He says, ‘She is a cow not made to work, neither ploughing the soil nor watering the fields; flawless and spotless’; they said, “You have now conveyed the proper fact”; so they sacrificed it, but seemed not to be sacrificing it (with sincerity).

# 79

And (remember) when you slew a man and were therefore accusing each other concerning it; and Allah wanted to expose what you were hiding.

# 80

We therefore said, “Strike the dead man with a part of the sacrificed cow”; this is how Allah will bring the dead to life, and shows you His signs so that you may understand!

# 81

Then after it, your hearts hardened – so they are like rocks, or even harder; for there are some rocks that rivers gush forth from them; and some that water flows from them when they split asunder; and there are rocks that fall down for the fear of Allah; and Allah is not unaware of your deeds.

# 82

So O Muslims, do you wish for the Jews to accept faith in you whereas a group of them used to listen to the Words of Allah, and then after having understood it, purposely changed it?

# 83

And when they meet the believers, they say, “We believe”; but when they are in isolation with one another they say, “You clarify to the believers from what Allah has disclosed to you, so that they may evidence it against you before your Lord? So have you no sense?”

# 84

Do they not know that Allah knows all whatever they hide and whatever they disclose?

# 85

And among them are the unlearned that do not know anything of the Book except to recite something therefrom or parts of their own fabrications; they are in absolute illusion.

# 86

Therefore woe is to those who write the Book with their hands; and they then claim, “This is from Allah” in order to gain an abject (worldly) price for it; therefore woe to them for what their hands have written, and woe to them for what they earn with it.

# 87

And they said, “The fire will not touch us except for a certain number of days”; say, “Have you taken a covenant from Allah – then Allah will certainly not break His covenant – or do you say something concerning Allah what you do not know?”

# 88

Yes, why not?\* The one who earns evil and his sin surrounds him; he is from the people of fire (hell); they will remain in it forever. (You will remain in the fire forever).

# 89

And those who believe and do good deeds – they are the People of Paradise; they will abide in it forever.

# 90

And (remember) when We took a covenant from the Descendants of Israel that, “Do not worship anyone except Allah; and be good to parents, relatives, orphans and the needy, and speak kindly to people and keep the prayer established and pay the charity”; thereafter you retracted, except some of you; and you are those who turn away.

# 91

And when We took a covenant from you that, “Do not shed the blood of your own people nor turn out your own people from your colonies”; you then acknowledged it and you are witnesses.

# 92

Then it is you who began slaying each other and you drive out a group of your people from their homeland – providing support against them (to their opponents) through sin and injustice; and if they come to you as captives you redeem them, whereas their expulsion itself is forbidden to you; so do you believe in some of Allah’s commands and disbelieve in some? So what is the reward of those who do so, except disgrace in this world? And on the Day of Resurrection they will be assigned to the most grievous punishment; and Allah is not unaware of your deeds.

# 93

These are the people who bought the worldly life in exchange of the Hereafter – so their punishment will not be lightened, nor will they be helped.

# 94

And indeed We gave Moosa (Moses) the Book and subsequent to him, sent Noble Messengers one after another – and We gave Eisa (Jesus), the son of Maryam (Mary), clear proofs and supported him with the Holy Spirit; so when a Noble Messenger from Allah comes to you bringing what you yourselves do not desire, you grow arrogant; so you disbelieve in a group of the Prophets and another group of Prophets you slay!

# 95

And the Jews said, “Our hearts are covered”; in fact Allah has cursed them because of their disbelief, so only a few of them accept faith.

# 96

And when the Book from Allah (the Holy Qu’ran) came to them, which confirms the Book in their possession (the Taurat / Torah) – and before that they used to seek victory through the medium of this very Prophet (Mohammed – peace and blessings be upon him) over the disbelievers; so when the one whom they fully recognised (the Holy Prophet) came to them, they turned disbelievers – therefore Allah’s curse is upon the disbelievers.

# 97

How abject is the price for which they exchange their lives that they should disbelieve in what Allah has sent down, jealous that Allah should reveal of His grace to whomever He wills of His bondmen! So they deserved wrath upon wrath; and for the disbelievers is a disgraceful punishment.

# 98

And when it is said to them, “Believe in what Allah has sent down", they say, “We believe in what was sent down to us, and disbelieve in the rest” – whereas it is the Truth confirming what they possess! Say (to them, O dear Prophet Mohammed – peace and blessings be upon him), “Why did you then martyr the earlier Prophets, if you believed in your Book?”

# 99

And indeed Moosa came to you with clear signs, and after it you worshipped the calf – and you were unjust.

# 100

And remember when We made a covenant with you and raised the Mount Tur (Sinai) above you; “Accept and hold fast to what We give you, and listen”; they said, “We hear and we disobey”; and the calf was still embedded in their hearts because of their disbelief; say (O dear Prophet Mohammed – peace and blessings be upon him), “What an evil command is what your faith orders you, if you are believers!”

# 101

Say (O dear Prophet Mohammed – peace and blessings be upon him), “If the abode of the Hereafter in the sight of Allah is for you alone and none else, then long for death if you are truthful!”

# 102

And they will never long for it, because of the evil deeds they have done in the past; and Allah knows the unjust, very well.

# 103

And you will surely find them the greediest among mankind for life; and (likewise) among the polytheists (idolaters); each one of them yearns to live a thousand years; and the grant of such age will not distance him from the punishment; and Allah is seeing their misdeeds.

# 104

Say (O dear Prophet Mohammed – peace and blessings be upon him), “Whoever is an enemy to Jibreel (Gabriel)” – for it is he who has brought down this Qu’ran to your heart by Allah’s command, confirming the Books before it, and a guidance and glad tidings to Muslims. –

# 105

“Whoever is an enemy to Allah, and His angels and His Noble Messengers, and Jibreel and Mikaeel (Michael) -, then (know that), Allah is an enemy of the disbelievers.”

# 106

We have indeed sent down to you clear signs; and none will disbelieve in them except the sinners.

# 107

And is it that whenever they make a covenant, only a group of them throws it aside? In fact, most of them do not have faith.

# 108

And when a Noble Messenger from Allah came to them, confirming the Book(s) which they possessed, a group of those who have received the Book(s) flung the Book of Allah behind their backs as if they were totally unaware!

# 109

And they followed what the devils used to read during the rule of Sulaiman (Solomon – peace and blessings be upon him); and Sulaiman did not disbelieve, but the devils disbelieved – they teach people magic; and that which was sent down to the two angels, Harut and Marut in Babylon; and the two (angels) never taught a thing to anyone until they used to say, “We are only a trial, therefore do not lose your faith” and they used to learn from them that by which they cause division between man and his wife; and they cannot harm anyone by it except by Allah’s command; and they learn what will harm them, not benefit them; and surely they know that whoever bargains for this will not have a share in the Hereafter; and for what an abject thing they have sold themselves; if only they knew!

# 110

And had they believed and been pious, then the recompense from Allah is extremely good; if only they knew!

# 111

O People who Believe, do not say (to the Prophet Mohammed- peace and blessings be upon him), “Raena (Be considerate towards us)” but say, “Unzurna (Look mercifully upon us)", and listen attentively from the start; and for the disbelievers is a painful punishment. (To disrespect the Holy Prophet – peace and blessings be upon him – is blasphemy.)

# 112

Those who disbelieve – the People given the Book(s) or the polytheists – do not wish that any good be sent down upon you from your Lord; and Allah chooses whomever He wills by His Mercy; and Allah is the Most Munificent.

# 113

When We abrogate a verse or cause it to be forgotten, We will bring one better than it or one similar; do you not know that Allah is Able to do all things?

# 114

Do you not know that for Allah only is the kingship of the heavens and the earth? And except Allah, you have neither a protector nor any supporter?

# 115

Do you wish to ask your Noble Messenger a question similar to what Moosa was asked before? And whoever chooses disbelief instead of faith has gone astray from the Right Path.

# 116

Many among People given the Book(s) wished to turn you to disbelief after you had accepted faith; out of hearts’ envy, after the truth has become very clear to them; so leave them and be tolerant, until Allah brings His command; indeed Allah is Able to do all things.

# 117

And keep the prayer established, and pay the charity; and whatever good you send ahead for yourselves, you will find it with Allah; indeed Allah is seeing your deeds.

# 118

And the People given the Book(s) said, “None will enter Paradise unless he is a Jew or a Christian”; these are their own imaginations; say (O dear Prophet Mohammed – peace and blessings be upon him), “Bring your proof, if you are truthful.”

# 119

Yes, why not? Whoever submits his face for the sake of Allah, and is virtuous, his reward is with his Lord; and there shall be no fear upon them nor shall they grieve.

# 120

And the Jews said, “The Christians are nothing” – and the Christians said, “The Jews are nothing” whereas they both read the Book; and the ignorant spoke similarly; so Allah will judge between them on the Day of Resurrection, concerning the matter in which they dispute.

# 121

And who is more unjust than one who prevents the name of Allah being mentioned in the mosques, and strives for their ruin? It did not befit them to enter the mosques except in fear; for them is disgrace in this world, and a terrible punishment in the Hereafter.

# 122

And the East and the West, all belong to Allah – so whichever direction you face, there is Allah’s Entity (Allah’s Mercy is directed towards you); indeed Allah is the All Capable, (His powers and reach are limitless), the All Knowing.

# 123

And they said, “Allah has taken an offspring for Himself” – Purity is to Him! In fact, all that is in the heavens and the earth, is His dominion; all are submissive to Him.

# 124

The Originator of the heavens and the earth – and when He commands a thing, He only says to it, “Be", and it thereupon happens.

# 125

And the ignorant people said, “Why does not Allah speak to us, or some sign come to us?” Those before them had also spoken in the same way as they speak; their hearts (and of those before them) are all alike; undoubtedly, We have made the signs clear for the people who have faith.

# 126

Undoubtedly, We have sent you (O dear Prophet Mohammed – peace and blessings be upon him) with the truth, giving glad tidings and conveying warning, and you will not be questioned about the people of hell.

# 127

And never will the Jews or the Christians be pleased with you, until you follow their religion; say, “The guidance of Allah only is the (true) guidance”; and were you (the followers of this Prophet) to follow their desires after the knowledge has come to you, you would then not have a protector or aide against Allah.

# 128

Those to whom We have given the Book, read it in the manner it should be read; it is they who believe in it; and those who deny it – it is they who are the losers.

# 129

O Descendants of Israel! Remember the favour of Mine which I bestowed upon you and made you superior to all others of your time. (By sending Noble Messengers among you).

# 130

And fear the day when no soul will be exchanged for another, nor will they be set free in lieu of compensation, nor will any intercession benefit the disbelievers, nor will they be helped.

# 131

And (remember) when Ibrahim’s (Abraham’s) Lord tested him in some matters and he fulfilled them; He said, “I am going to appoint you as a leader for mankind”; invoked Ibrahim, “And of my offspring”; He said, “My covenant does not include the unjust (wrong-doers).”

# 132

And remember when We made this House (at Mecca) a recourse for mankind and a sanctuary; and take the place where Ibrahim stood, as your place of prayer; and We imposed a duty upon Ibrahim and Ismail (Ishmael), to fully purify My house for those who go around it, and those who stay in it (for worship), and those who bow down and prostrate themselves.

# 133

And (remember) when Ibrahim prayed, “My Lord! Make this city a place of security and bestow upon its people various fruits as providence – for those among them who believe in Allah and the Last Day (of Resurrection)”; He answered, “And whoever disbelieves, I shall provide him also some subsistence and then compel him towards the punishment of fire (hell); and that is a wretched place to return.”

# 134

And (remember) when Ibrahim was raising the foundations of the House, along with Ismail; (saying), “Our Lord! Accept it from us; indeed You only are the All Hearing, the All Knowing.”

# 135

“Our Lord! And make us submissive towards you and from our offspring a nation obedient to You – and show us the ways of our worship, and incline towards us with Your mercy; indeed You only are the Most Acceptor of Repentance, the Most Merciful.”

# 136

“Our Lord! And send towards them a Noble Messenger, from amongst them, to recite to them Your verses, and to instruct them in Your Book and sound wisdom\*, and to fully purify them; indeed You only are the Almighty, the Wise.” (The traditions of the Holy Prophet – sunnah and hadith – are called wisdom.)

# 137

And who will renounce the religion of Ibrahim except him who is a fool at heart? We indeed chose him (Ibrahim) in this world; and indeed in the Hereafter he is among those worthy of being closest to Us.

# 138

When his Lord said to him, “Submit”, he said, “I have submitted to the Lord Of The Creation.”

# 139

And Ibrahim willed the same religion upon his sons, and also did Yaqub (Jacob); (saying), “O my sons – indeed Allah has chosen this religion for you; therefore do not die except as Muslims (those who submit to Him).”

# 140

In fact, some of you yourselves were present when death approached Yaqub and when he said to his sons, “What will you worship after me?” They said, “We shall worship Him Who is your God, and is the God of your fathers, Ibrahim and Ismail and Ishaq (Isaac) – the One God; and to Him we have submitted ourselves.”

# 141

This was a nation that has passed away; for them is what they earned, and yours is what you earn; and you will not be questioned about their deeds.

# 142

And the People given the Book(s) said, “Become Jews or Christians – you will attain the right path”; say (O dear Prophet Mohammed – peace and blessings be upon him), “No – rather we take the religion of Ibrahim, who was far removed from all falsehood; and was not of the polytheists.”

# 143

Say, “We believe in Allah and what is sent down to us and what was sent down to Ibrahim, and Ismael, and Ishaq, and Yaqub, and to their offspring, and what was bestowed upon Moosa and Eisa (Jesus), and what was bestowed upon other Prophets – from their Lord; we do not make any distinction, in belief, between any of them; and to Allah we have submitted ourselves.”

# 144

And if they believe in the same way you have believed, they have attained guidance; and if they turn away, they are clearly being stubborn; so Allah will soon suffice you (O dear Prophet Mohammed – peace and blessings be upon him) against them; and He only is the All Hearing, the All Knowing.

# 145

“We have taken the colour (religion) of Allah; and whose colour (religion) is better than that of Allah? And only Him do we worship.”

# 146

Say (O dear Prophet Mohammed – peace and blessings be upon him), “What! You dispute with us concerning Allah, whereas He is our Lord and also yours? Our deeds are with us and with you are your deeds; and only to Him do we sincerely belong.”

# 147

“In fact you claim that Ibrahim, and Ismail, and Ishaq, and Yaqub, and their offspring were Jews or Christians”; say, “Do you know better, or does Allah?”; and who is more unjust than one who has the testimony from Allah and he hides it? And Allah is not unaware of your deeds.

# 148

They were a group that has passed away; for them is what they earned, and for you is what you earn; and you will not be questioned about their deeds.

# 149

So now the foolish people will say, “What has turned the Muslims away from the qiblah (prayer direction) which they formerly observed?”; proclaim, “To Allah only belong the East and the West; He guides whomever He wills upon the Straight Path.”

# 150

And so it is that We have made you the best nation\* for you are witnesses\*\* against mankind, and the Noble Messenger is your guardian and your witness; and (O dear Prophet Mohammed – peace and blessings be upon him) We had appointed the qiblah which you formerly observed only to see (test) who follows the Noble Messenger, and who turns away; and it was indeed hard except for those whom Allah guided; and it does not befit Allah’s Majesty to waste your faith! Indeed Allah is Most Compassionate, Most Merciful towards mankind. (\* The best Ummah is that of Prophet Mohammed – peace and blessings be upon him. \*\* The Holy Prophet is a witness from Allah.)

# 151

We observe you turning your face, several times towards heaven (O dear Prophet Mohammed – peace and blessings be upon him); so We will definitely make you turn (for prayer) towards a qiblah which pleases you; therefore now turn your face towards the Sacred Mosque (in Mecca); and O Muslims, wherever you may be, turn your faces (for prayer) towards it only; and those who have received the Book surely know that this is the truth from their Lord; and Allah is not unaware of their deeds. (Allah seeks to please the Holy Prophet – peace and blessings be upon him.)

# 152

And even if you were to bring all the signs to the People given the Book(s), they would not follow your qiblah; nor should you follow their qiblah; nor do they follow each others qiblah; and were you (the followers of this Prophet) to follow their desires after having received knowledge, you would then surely be unjust.

# 153

Those to whom We gave the Book(s) recognise the Prophet (Mohammed – peace and blessings be upon him) as men (or they) recognise their own sons; and undoubtedly a group among them purposely conceals the truth.

# 154

This is the Truth from your Lord, therefore (O those who listen) beware – do not be in doubt.

# 155

And each one has a direction towards which he inclines, therefore strive to surpass others in good deeds; Allah will bring you all together, wherever you may be; indeed Allah may do as He wills.

# 156

And wherever you come from, turn your face towards the Sacred Mosque; and indeed it is the truth from your Lord; and Allah is not unaware of your deeds.

# 157

And O dear Prophet (Mohammed – peace and blessings be upon him) wherever you come from, turn your face towards the Sacred Mosque; and wherever you may be, O Muslims, turn your faces towards it only, so that people may not have an argument against you – except those among them who do injustice; therefore do not fear them, and fear Me; and this is in order that I complete My favour upon you and that you may attain guidance. –

# 158

The way We have sent to you a Noble Messenger from among you, who recites to you Our verses and purifies you, and teaches you the Book and sound wisdom\*, and teaches you what you did not know. (The traditions / sayings of the Holy Prophet – peace and blessings be upon him).

# 159

Therefore remember Me, I will cause you to be spoken of and acknowledge My rights, and do not be ungrateful.

# 160

O People who Believe! Seek help from patience and prayer; indeed Allah is with those who patiently endure.

# 161

And do not utter regarding those who are slain in Allah's cause as “dead”; in fact they are alive, but it is you who are unaware.

# 162

And We will surely test you with some fear and hunger, and with paucity of wealth and lives and crops; and give glad tidings to those who patiently endure. –

# 163

Those who say when calamity befalls them, “Indeed we belong to Allah and indeed it is to Him we are to return.”

# 164

These are the people upon whom are the blessings from their Lord, and mercy; and it is they who are on guidance.

# 165

Undoubtedly Safa and Marwah\* are among the symbols of Allah; so there is no sin on him, for whoever performs the Hajj (pilgrimage) of this House (of Allah) or the Umrah (lesser pilgrimage), to go back and forth between them; and whoever does good of his own accord, then (know that) indeed Allah is Most Appreciative (rewards virtue), the All Knowing. (These are 2 hillocks near the Holy Ka’aba)

# 166

Indeed those who hide the clear proofs and the guidance which We sent down, after We made it clear to mankind in the Book – upon them is the curse of Allah and the curse of those who curse.

# 167

Except those who repent and do reform and disclose (the truth) – so I will accept their repentance; and I only am the Most Acceptor of Repentance, the Most Merciful.

# 168

Indeed upon those who disbelieved, and died as disbelievers, is the curse of Allah and of the angels and of men combined.

# 169

They will remain in it forever; neither will the punishment be lightened for them, nor will they be given respite.

# 170

Your God is One God; there is no God except Him – the Most Gracious, the Most Merciful.

# 171

Indeed in the creation of the heavens and the earth, and in the continuous alternation of night and day, and the ships which sail the seas carrying what is of use to men, and the water which Allah sends down from the sky thereby reviving the dead earth and dispersing all kinds of beasts in it, and the movement of the winds, and the obedient clouds between heaven and earth – certainly in all these are signs for the intelligent.

# 172

And some people create for themselves Gods (objects of worship) other than Allah, with devotion (love) equal to the devotion of Allah; and the believers do not love anybody with love equal to the love of Allah; and what will be their state, when the punishment will be before the eyes of the unjust (disbelievers)? For all power belongs wholly to Allah, and because Allah’s punishment is very severe.

# 173

(The day) when the leaders will be disgusted with their followers – and they shall see their punishment, and all their links will be cut off.

# 174

And the followers will say, “If we were to return (to earth), we would break off from them like they have broken off from us”; this is how Allah will show them their deeds as despair for them; and they will never come out from the fire (hell).

# 175

O mankind! Eat from what is lawful and clean in the earth; and do not follow the footsteps of the devil; undoubtedly he is your open enemy.

# 176

For he will only instruct you towards the evil and the shameful, and that you fabricate matters concerning Allah, what you do not know.

# 177

And when it is said to them, “Follow what Allah has sent down”, they say, “On the contrary, we shall follow what we found our forefathers upon”; What! Even if their forefathers had no intelligence, or guidance?!

# 178

And the example of the disbelievers is similar to one who calls upon one that hears nothing except screaming and yelling; deaf, dumb, blind – so they do not have sense.

# 179

O People who Believe! Eat of the good things We have provided you, and be grateful to Allah if it is only Him you worship.

# 180

He has forbidden for you only the carrion, and blood, and flesh of swine, and the animal that has been slaughtered while proclaiming the name of anyone other than Allah; so there is no sin on him who is compelled and does not eat out of desire, nor eats more than what is necessary; indeed Allah is Oft Forgiving, Most Merciful.

# 181

Those who hide the Book sent down by Allah and exchange it for an abject price – they only fill their bellies with fire and Allah will not speak to them on the Day of Resurrection nor will He purify them; and for them is a painful punishment.

# 182

They are the people who purchased error in exchange of guidance, and torment in exchange of pardon; so how much can they bear the fire?

# 183

This is because Allah has sent down the Book with the truth; and indeed those who caused disagreement in the Book are, surely, disputants in the extreme.

# 184

Basic virtue is not just to turn faces to the East and the West, but true righteousness is that one must believe in Allah and the Last Day and the angels and the Book and the Prophets; and out of love for Allah, to give treasured wealth to relatives and to the orphans and the needy and the traveller, and to those who ask, and to set slaves free; and to keep the prayer established and to pay the charity; and those who fulfil their obligations when they make an agreement; and the patient during times of calamity, in hardships and during holy war; it is they who have proved true to their word; it is they who are the pious.

# 185

O People who Believe! Retribution is made obligatory for you in the matter of those killed unjustly; a freeman for a freeman, and a slave for a slave, and a female for a female; and for him who is partly forgiven by his brother, seek compensation with courtesy and make payment in proper manner; this is a relief and a mercy upon you, from your Lord; so after this, a painful punishment is for whoever exceeds the limits.

# 186

And there is life for you in retribution, O men of understanding, so that you may avoid.

# 187

It is ordained for you that when death approaches one of you, and he leaves behind wealth, he must bequeath it to parents and near relatives in accordance with tradition; this is a duty upon the pious.

# 188

So whoever changes the will after he has heard it – its sin is only upon those who change it; indeed Allah is the All Hearing, the All Knowing.

# 189

Then if one fears that the will maker (the deceased) has done injustice or sin, and he makes a reconciliation between the parties, there shall be no sin upon him; indeed Allah is Oft Forgiving, Most Merciful.

# 190

O People who Believe! Fasting is made compulsory for you, like it was ordained for those before you, so that you may attain piety.

# 191

For a certain number of days only; so whoever is sick among you, or on a journey, the same number in other days; and those who do not have the strength for it must give a redemption by feeding a needy person; so whoever increases the good of his own accord, it is better for him; and fasting is better for you, if only you realise.

# 192

The month of Ramadan in which was sent down the Qur’an – the guidance for mankind, the direction and the clear criteria (to judge between right and wrong); so whoever among you witnesses this month, must fast for the (whole) month; and whoever is sick or on a journey, may fast the same number in other days; Allah desires ease for you and does not desire hardship for you – so that you complete the count (of fasts), and glorify Allah’s greatness for having guided you, and so that you may be grateful.

# 193

And O dear Prophet (Mohammed – peace and blessings be upon him), when My bondmen question you concerning Me, then surely I am close; I answer the prayer of the supplicant when he calls on Me, so they must obey Me and believe in Me, so that they may attain guidance.

# 194

Going to your wives during the nights of the fast is made lawful for you; they are coverings for you and you are coverings for them; Allah knows that you were deceiving yourselves (in this respect), so He accepted your penance and forgave you; so cohabit with them and seek what Allah has destined for you – and eat and drink until the white thread becomes distinct to you from the black thread at dawn – then complete the fast till nightfall; and do not touch women while staying in seclusion for worship in the mosques; these are the limits imposed by Allah, so do not go near them; this is how Allah explains His verses to mankind so that they may attain piety.

# 195

And do not unjustly devour the property of each other, nor take their cases to judges in order that you may wrongfully devour a portion of other peoples’ property on purpose.

# 196

They ask you, (O dear Prophet Mohammed – peace and blessings be upon him), regarding the crescents; say, “They are indicators of time for mankind and for Hajj (the pilgrimage)”; and it is not a virtue at all that you enter the houses by demolishing their back portions, but in reality virtue is piety; and enter the houses using their gates – and keep fearing Allah, hoping that you achieve success.

# 197

And fight in Allah's cause against those who fight you and do not exceed the limits; and Allah does not like the transgressors.

# 198

And slay the disbelievers wherever you find them, and drive them out from where they drove you out, and the turmoil they cause is worse than slaying; and do not fight them near the Sacred Mosque until they fight you there; so if they fight you, slay them; this is the punishment of the disbelievers.

# 199

Then if they desist, then indeed Allah is Oft Forgiving, Most Merciful.

# 200

And fight them until no mischief remains, and only Allah is worshipped; then if they desist, do not harm them, except the unjust.

# 201

The sacred month for the sacred month, and respect in lieu of respect; harm the one who harms you, to the extent as he did – and keep fearing Allah, and know well that Allah is with the pious.

# 202

And spend your wealth in Allah's cause, and do not fall into ruin with your own hands; and be virtuous; undoubtedly the righteous are the beloved of Allah.

# 203

And perform Hajj (greater pilgrimage) and Umrah (lesser pilgrimage) for Allah; and if you are prevented, send sacrifice whatever is available; and do not shave your heads until the sacrifice reaches its destination; so whoever among you is sick or has an ailment in the head, must pay a compensation by fasting or charity or sacrifice; then when you are in peace – and whoever takes the advantage of combining the Hajj and Umrah, it is compulsory for him to sacrifice whatever is available; and whoever cannot afford it, must fast for three days while on the pilgrimage, and seven when you have returned to your homes; these are ten in all; this decree is for him who is not a resident of Mecca; and keep fearing Allah and know well that Allah’s punishment is severe.

# 204

The Hajj is during the well-known months; and for one who intends to perform the Hajj in it – neither is there to be mention of cohabitation in the presence of women, nor any sin, nor a fight with anyone till the completion of Hajj; and whatever good you do, Allah knows it; and take provision along with you for the best provision is piety; and keep fearing Me, O men of understanding!

# 205

It is no sin for you that you seek the bounty of your Lord; so when you return from Arafat, remember Allah near the Sacred Symbol (Mash’ar al Haram) – and remember Him in the manner He has guided you; and indeed, before this, you were of the astray.

# 206

Then, O people of Quraish, you too must return from the place where the people return from, and ask forgiveness from Allah; indeed Allah is Oft Forgiving, Most Merciful.

# 207

So when you have completed your Hajj rites, remember Allah as you used to remember your forefathers, in fact more than that; and among the people are some that say, “Our Lord! Give us in this world” – and he does not have a portion in the Hereafter.

# 208

And among them are some that say, “Our Lord! Give us good in the world and good in the Hereafter, and save us from the punishment of fire!”

# 209

For such is a portion from what they have earned; and Allah is Swift At Taking Account.

# 210

And remember Allah in the counted days; so whoever hastens by departing in two days, there is no sin on him; and whoever stays on, there is no sin for him – for the pious; and keep fearing Allah, and know well that it is to Him you will be raised.

# 211

And among men is one whose conversation may please you in the life of this world, and he brings Allah as witness to what is in his heart, whereas he is the biggest quarreller!

# 212

And when he turns away, he creates turmoil in the earth and destroys crops and lives; and Allah is not pleased with turmoil.

# 213

And when it is said to him, “Fear Allah”, he becomes more resolute in committing sin – therefore hell is sufficient for such; and that is indeed, a very wretched resting place.

# 214

And among men is one who sells himself to seek the pleasure of Allah; and Allah is Most Compassionate towards the bondmen.

# 215

O People who Believe! Enter Islam in full – and do not follow the footsteps of the devil; indeed he is your open enemy.

# 216

And if you renege, even after the clear commands have come to you, then know well that Allah is Almighty, Wise.

# 217

What are they waiting for, except that Allah’s punishment should come through stretched clouds and the angels descend and the matter be finished? And all matters are directed only towards Allah.

# 218

Ask the Descendants of Israel how many clear signs We gave them; and whoever alters Allah’s favour which came to him, then indeed Allah’s punishment is severe.

# 219

The life of this world is made to appear beautiful in the sight of the disbelievers, and they make fun of the believers; and the pious will be above them on the Day of Resurrection; and Allah may give to whomever He wills, without account.

# 220

Mankind was on one religion; so Allah sent Prophets giving glad tidings and warnings – and with them sent down the true Book to judge between mankind on their differences; and only those to whom it was given created disputes regarding the Book, after clear commands had come to them, due to hostility of one another; so Allah, by His command, made the truth clear to the believers, concerning their disputes; and Allah may guide whomever He wills to the Straight Path.

# 221

Are you under the illusion that you will enter Paradise whereas the suffering, which came to those before you, has not yet come to you? Hardship and adversity befell them and they were shaken, to the extent that the Noble Messenger and the believers along with him said, “When will the help of Allah come?”; pay heed! Allah’s help is surely near.

# 222

They ask you what they should spend; say, “Whatever you spend for good, is for parents and near relatives and orphans and the needy and the traveller”; and whatever good you do, indeed Allah knows it.

# 223

Fighting in Allah's cause is ordained for you, whereas it is disliked by you; and it is possible that you hate a thing which is better for you; and it is possible that you like a thing which is bad for you; and Allah knows, and you do not know.

# 224

They ask you the decree regarding fighting in the sacred month; say (O dear Prophet Mohammed – peace and blessings be upon him), “Fighting in it is a great sin; and to prevent from the way of Allah, and not to believe in Him and to prevent (people) from the Sacred Mosque and to expel its residents – these are greater sins before Allah"; and the turmoil they cause is worse than killing; and they will keep fighting you till they turn you away from your religion, if they can; and whoever among you turns renegade and dies as a disbeliever, then their deeds are wasted in this world and in the Hereafter; and they are the people of hell; they will remain in it forever.

# 225

Those who believed, and those who migrated for the sake of Allah, and fought in Allah's cause – they are hopeful of gaining Allah’s mercy; and Allah is Oft Forgiving, Most Merciful.

# 226

They ask you the decree regarding wine (intoxicants) and gambling; say (O dear Prophet Mohammed – peace and blessings be upon him), “In both is great sin, and some worldly benefit for men – but their sin is greater than their benefit”; and they ask you what they should spend; say, “That which remains spare (surplus)”; this is how Allah explains His verses to you, so that you may think.

# 227

Before you execute your deeds of this world and of the Hereafter; and they ask you the decree regarding orphans; say, “To do good towards them is better; and if you combine your expenses with theirs, they are your brothers”; and Allah knows very well the one who spoils from him who improves; and if Allah willed, He could have put you in hardship; and Allah is Almighty, Wise.

# 228

And do not marry polytheist women until they become Muslims; for undoubtedly a Muslim bondwoman is better than a polytheist woman, although you may like her; and do not give your women in marriage to polytheist men until they accept faith; for undoubtedly a Muslim slave is better than a polytheist, although you may like him; they invite you towards the fire; and Allah invites towards Paradise and forgiveness by His command; and explains His verses to mankind so that they may accept guidance.

# 229

And they ask you the decree concerning menstruation; say, “It is an impurity, so stay away from women at such times, and do not cohabit with them until they have cleansed themselves; so when they have cleansed themselves, cohabit with them the way Allah has determined for you”; indeed Allah loves those who repent profusely, and loves those who keep clean.

# 230

Your women are a tillage for you; so come into your tillage as you will; and first perform the deeds that benefit you; and keep fearing Allah, and know well that you have to meet Him; and (O dear Prophet Mohammed – peace and blessings be upon him) give glad tidings to the Muslims.

# 231

And do not make Allah a target of your oaths, by pledging against being virtuous and pious, and against making peace among mankind; and Allah is All Hearing, All Knowing.

# 232

Allah does not take you to task for oaths which are made unintentionally but He does take you to task for deeds which your hearts have done; and Allah is Oft Forgiving, Most Forbearing.

# 233

Those who swear not to touch their wives have four months’ time; so if they turn back during this period, indeed Allah is Oft Forgiving, Most Merciful.

# 234

And if they firmly decide to divorce them, Allah is All Hearing, All Knowing.

# 235

And divorced women shall restrain themselves for three menstrual periods; and it is not lawful for them to conceal what Allah has created in their wombs if they believe in Allah and the Last Day; and their husbands have the right to take them back, during this time, if they desire reconciliation; and the women also have rights similar to those of men over them, in accordance with Islamic law – and men have superiority over them; and Allah is Almighty, Wise.

# 236

This type of divorce is up to twice; the woman must then be retained on good terms or released with kindness; and it is not lawful for you to take back from women a part of what you have given them except when both fear that they may not be able to stay within the limits established by Allah; so if you fear that they may not be able to observe the limits of Allah, then it is no sin on them if the woman pays to get her release; these are the limits set by Allah, so do not exceed them; and those who transgress Allah’s limits are the unjust.

# 237

Then if he divorces her the third time, she will not be lawful to him until she has stayed with another husband; then if the other husband divorces her, it is no sin for these two to reunite if they consider that they can keep the limits of Allah established; these are the limits set by Allah which He explains for people of intellect.

# 238

And when you have divorced women, and their term reaches its end, either retain them on good terms within this period or release them with kindness; and do not retain them in order to hurt them, hence transgressing the limits; and he who does so harms only himself; and do not make the signs of Allah the objects of ridicule; and remember Allah’s favour that is bestowed upon you and that He has sent down to you the Book and wisdom, for your guidance; keep fearing Allah and know well that Allah knows everything. (The traditions of the Holy Prophet – sunnah and hadith – are called wisdom.)

# 239

And when you have divorced women and they complete their waiting period – then O guardians of such women, do not prevent them from marrying their husbands if they agree between themselves in accordance with Islamic law; this lesson is for those among People who Believe in Allah and the Last Day; this is purer for you, and cleaner; and Allah knows and you do not know.

# 240

And mothers shall breast-feed their children for two full years – for those who wish to complete the term of milk feeding; and the father of the child must provide for food and clothing of the mother in accordance with custom; no one will be burdened except with what he can bear; a mother should not be harmed because of her child, nor he to whom the child is born be harmed because of his child (or a mother should not harm the child nor he to whom the child is born should harm the child); and the same is incumbent on the guardian in place of the father; then if the parents desire to wean the child by mutual consent and consultation, it is no sin for them; and if you wish to give your children out to a (milk feeding) nurse, it is no sin for you, provided you pay to them what is agreed, with kindness; and keep fearing Allah, and know well that Allah is seeing what you do.

# 241

And those among you who die leaving wives behind them, then such widows shall restrain themselves for four months and ten days; so when their term is completed, O guardians of such women, there is no sin on you in what the women may decide for themselves in accordance with Islamic law; and Allah is Well Aware of what you do.

# 242

And there is no sin on you if you propose marriage to women while they are hidden from your view, or hide it in your hearts; Allah knows that you will now remember them, but do not make secret pacts with women except by decent words recognised by Islamic law; and do not consummate the marriage until the written command reaches its completion; know well that Allah knows what is in your hearts, therefore fear Him; and know well that Allah is Oft Forgiving, Most Forbearing.

# 243

There is no sin upon you if you divorce women while you have not touched them or appointed their bridal money; and give them some provision; the rich according to their means, and the poor according to their means; a fair provision according to custom; this is a duty upon the virtuous.

# 244

If you divorce them before you have touched them and have appointed the bridal money, then payment of half of what is agreed is ordained unless the women forgo some of it, or he in whose hand is the marriage tie, pays more; and O men, your paying more is closer to piety; and do not forget the favours to each other; indeed Allah is seeing what you do.

# 245

Guard all your prayers, and the middle prayer; and stand with reverence before Allah.

# 246

And if you are in fear, pray while on foot or while riding, as you can; when you are in peace remember Allah the way He has taught you, which you did not know.

# 247

And those among you who die leaving wives behind them – they should bequeath for their wives a complete provision for one full year without turning them out; so if they go out themselves, there is no sin on you regarding what they do of themselves in a reasonable manner; and Allah is Almighty, Wise.

# 248

And for divorced women also, is a complete provision in reasonable manner; this is a duty upon the pious.

# 249

This is how Allah explains His verses to you so that you may understand.

# 250

Did you (O dear Prophet Mohammed – peace and blessings be upon him) not see those who left their homes, whereas they numbered in thousands, fearing death? So Allah said to them, “Die”; He then brought them back to life; indeed Allah is Most Munificent towards mankind, but most men are ungrateful.

# 251

And fight in Allah's cause and know well that Allah is All Hearing, All Knowing.

# 252

Is there someone who will lend an excellent loan to Allah, so that He may increase it for him several times over? And Allah restricts and eases (the sustenance) – and it is to Him that you will return.

# 253

Did you (O dear Prophet Mohammed – peace and blessings be upon him) not see a group of the Descendants of Israel, after Moosa? When they said to one of their Prophets (Shamueel – Samuel), “Appoint a king for us so that we may fight in Allah’s way”? He said, “Do you think you would refrain from fighting if it is made obligatory for you?” They said, “What is the matter with us that we should not fight in Allah’s cause, whereas we have been driven away from our homeland and our children?” So when fighting was ordained for them, they all turned away, except a few; and Allah is Well Aware of the unjust.

# 254

And their Prophet said to them, “Indeed Allah has sent Talut (Saul) as your king”; they said, “Why should he have kingship over us whereas we deserve the kingship more than he, and nor has he been given enough wealth?” He said, “Indeed Allah has chosen him above you, and has bestowed him with vast knowledge and physique”; and Allah may bestow His kingdom on whomever He wills; and Allah is Most Capable, All Knowing.

# 255

And their Prophet said to them, “Indeed the sign of his kingdom will be the coming of a (wooden) box to you, in which from your Lord is the contentment of hearts and containing some souvenirs (remnants) left behind by the honourable Moosa and the honourable Haroon (Aaron), borne by the angels; indeed in it is a great sign\* for you if you are believers.” (The remnants of pious persons are blessed by Allah.)

# 256

So when Talut left the city along with the armies, he said, “Allah will surely test you with a river; so whoever drinks its water is not mine – and whoever does not drink is mine – except him who takes it in the hollow of his hand”; so they all drank it, except a few of them; thereafter when Talut and the believers with him had crossed the river, they said, “We do not have power this day to face Jalut (Goliath) and his armies”; those who were certain of meeting Allah said, “Many a times has a smaller group overcome a bigger group by Allah’s command; and Allah is with the steadfast.”

# 257

And when they confronted Jalut and his armies they invoked, “Our Lord! Pour (bestow abundantly) on us patience (fortitude), and keep our feet steady, and help us against the disbelieving people.”

# 258

So they routed them by the command of Allah; and Dawud (David) slew Jalut, and Allah gave him the kingdom and wisdom, and taught him all whatever He willed; and if Allah does not ward off some men by others, the earth will be destroyed, but Allah is Most Munificent towards the entire creation.

# 259

These are the verses of Allah, which We recite to you (O dear Prophet Mohammed – peace and blessings be upon him) with truth; and undoubtedly you are one of the Noble Messengers.

# 260

These are the Noble Messengers, to whom We gave excellence over each other; of them are some with whom Allah spoke, and some whom He exalted high above all others; and We gave Eisa (Jesus), the son of Maryam, clear signs and We aided him with the Holy Spirit; and if Allah willed, those after them would not have fought each other after the clear evidences had come to them, but they differed – some remained on faith and some turned disbelievers; and had Allah willed, they would not have fought each other; but Allah may do as He wills.

# 261

O People who Believe! Spend in Allah's cause, from what We have provided you, before the advent of a day in which there is no trade, and for the disbelievers neither any friendship nor intercession; and the disbelievers themselves are the unjust.

# 262

Allah – there is no God except Him; He is Alive (eternally, on His own) and the Upholder (keeps others established); He never feels drowsy nor does He sleep; to Him only belongs all whatever is in the heavens and all whatever is in the earth; who is he that can intercede\* with Him except by His command? He knows what is in front of them and what is behind them; and they do not achieve anything of His knowledge except what He wills; His Throne (of Sovereignty) encompasses the heavens and the earth; and it is not difficult for Him to guard them; and He is the Supreme, the Greatest. (This Verse is popularly known as Ayat Al-Kursi. It has a special status and reciting it carries great reward. \*Prophet Mohammed – peace and blessings be upon him – will be the first one to be granted the permission to intercede, others will follow.)

# 263

There is no compulsion at all in religion; undoubtedly the right path has become very distinct from error; and whoever rejects faith in the devil (false deities) and believes in Allah has grasped a very firm handhold; it will never loosen; and Allah is All Hearing, All Knowing.

# 264

Allah is the Guardian of the Muslims – He removes them from realms of darkness towards light; and the supporters of disbelievers are the devils – they remove them from light towards the realms of darkness; it is they who are the people of fire; they will remain in it forever.

# 265

Did you (O dear Prophet Mohammed – peace and blessings be upon him) not see him who argued with Ibrahim (Abraham) concerning his Lord, as Allah had given him the kingdom? When Ibrahim said, “My Lord is He Who gives life and causes death”, he answered, “I give life and cause death”; Ibrahim said, “So indeed it is Allah Who brings the sun from the East – you bring it from the West!” – the disbeliever was therefore baffled; and Allah does not guide the unjust.

# 266

Or like him\* who passed by a dwelling and it had fallen flat on its roofs; he said, “How will Allah bring it to life, after its death?”; so Allah kept him dead for a hundred years, then brought him back to life; He said, “How long have you stayed here?”; he replied, “I may have stayed for a day or little less”; He said, “In fact, you have spent a hundred years – so look at your food and drink which do not even smell stale; and look at your donkey whose bones even are not intact – in order that We may make you a sign for mankind – and look at the bones how We assemble them and then cover them with flesh”; so when the matter became clear to him, he said, “I know well that Allah is Able to do all things.” (Prophet Uzair – peace be upon him.)

# 267

And when Ibrahim said, “My Lord! Show me how You will give life to the dead”; He said, “Are you not certain (of it)?” Ibrahim said, “Surely yes, why not? But because I wish to put my heart at ease”; He said, “Therefore take four birds (as pets) and cause them to become familiar to you, then place a part of each of them on separate hills, then call them – they will come running towards you; and know well that Allah is Almighty, Wise.” (Prophet Ibrahim called the dead birds and they did come running towards him.)

# 268

The example of those who spend their wealth in Allah’s way is similar to that of a grain which has sprouted seven stalks and in each stalk are a hundred grains; and Allah may increase it still more than this, for whomever He wills; and Allah is Most Capable, All Knowing.

# 269

Those who spend their wealth in Allah’s way and thereafter do not express favour nor cause injury (hurt the recipient’s feelings), their reward is with their Lord; there shall be no fear upon them nor shall they grieve.

# 270

Speaking kind words and pardoning are better than charity followed by injury; and Allah is the Independent, Most Forbearing.

# 271

O People who Believe! Do not invalidate your charity by expressing favour and causing injury – like one who spends his wealth for people to see, and does not believe in Allah and the Last Day; his example is similar to that of a rock covered with dust and hard rain fell on it, leaving it as a bare rock; they shall get no control over (or benefit from) anything they have earned; and Allah does not guide the disbelievers.

# 272

And the example of those who spend their wealth in order to seek Allah’s pleasure and to make their hearts steadfast, is similar to that of a garden on a height – hard rain fell on it, so bringing forth its fruit twofold; so if hard rain does not reach it, the dew is enough; and Allah is seeing your deeds.

# 273

Would any of you like that he may own a garden of dates and grapes, with rivers flowing beneath it – in it are all kinds of fruits for him – and he reaches old age and has young children; therefore a windstorm containing fire came to the garden, burning it? This is how Allah explains His verses to you, so that you may give thought.

# 274

O People who Believe! Spend a part of your lawful earnings, and part of what We have produced from the earth for you – and do not (purposely) choose upon the flawed to give from it (in charity) whereas you would not accept it yourselves except with your eyes closed towards it; and know well that Allah is Independent, Most Praised.

# 275

The devil scares you of poverty and bids you to the shameful; and Allah promises you forgiveness from Him, and munificence; and Allah is Most Capable, All Knowing.

# 276

Allah bestows wisdom on whomever He wills; and whoever receives wisdom has received abundant goodness; but none heed advice except men of understanding.

# 277

And whatever you spend or pledge to do, Allah is aware of it; and the unjust do not have supporters.

# 278

If you give charity openly, what an excellent deed it is! And if you secretly give it to the poor, it is the best for you; and it will redeem some of your sins; and Allah is Aware of your deeds.

# 279

It is not your duty (O dear Prophet Mohammed – peace and blessings be upon him) to make them accept guidance – but Allah guides whomever He wills; and whatever good thing you spend is beneficial for yourselves; and it is not right for you to spend except to seek Allah’s pleasure; and whatever you spend will be repaid to you in full, and you will not be wronged. –

# 280

(Spend) For the poor who are restricted while in Allah's cause, who cannot travel in the land (for earning) – the unwise think they are wealthy because of their restraint; you will recognise them by their faces; they do not seek from people in order to avoid grovelling; and Allah knows whatever you spend in charity.

# 281

Those who spend their wealth by night and day, secretly and openly – their reward is with their Lord; and there shall be no fear upon them nor shall they grieve.

# 282

Those who devour usury will not stand up on the Day of Judgement, except like the one whom an evil jinn has deranged by his touch; that is because they said, “Trade is also like usury!”; whereas Allah has made trading lawful and forbidden usury; for one to whom the guidance has come from his Lord, and he refrained therefrom, is lawful what he has taken in the past; and his affair is with Allah; and whoever continues earning it henceforth, is of the people of fire; they will remain in it for ages.

# 283

Allah destroys usury and increases charity; and Allah does not like any ungrateful, excessive sinner.

# 284

Indeed those who believed and did good deeds and kept the prayer established and paid the charity – their reward is with their Lord; and there shall be no fear upon them nor shall they grieve.

# 285

O People who Believe! Fear Allah and forego the remaining usury, if you are Muslims.

# 286

And if you do not, then be certain of a war with Allah and His Noble Messenger; and if you repent, take back your principal amount; neither you cause harm to someone, nor you be harmed.

# 287

And if the debtor is in difficulty, give him respite till the time of ease; and your foregoing the entire debt from him is still better for you, if only you realise.

# 288

And fear the day in which you will be returned to Allah; and every soul will be paid back in full what it had earned, and they will not be wronged.

# 289

O People who Believe! If you make an agreement for debt for a specified time, write it down; and appoint a scribe to write it for you with accuracy; and the scribe must not refuse to write in the manner Allah has taught him, so he must write; and the liable person (debtor) should dictate it to him and fear Allah, Who is his Lord, and not hide anything of the truth; but if the debtor is of poor reasoning, or weak, or unable to dictate, then his guardian must dictate with justice; and appoint two witnesses from your men; then if two men are not available, one man and two women from those you would prefer to be witnesses, so that if one of them forgets, the other can remind her; and the witnesses must not refuse when called upon to testify; do not feel burdened to write it, whether the transaction is small or big – write it for up to its term’s end; this is closer to justice before Allah and will be a strong evidence and more convenient to dispel doubts amongst yourselves – except when it is an instant trade in which exchange is carried out immediately, there is no sin on you if it is not written down; and take witnesses whenever you perform trade; and neither the scribe nor the witnesses be caused any harm (or they cause any harm); and if you do, it would be an offence on your part; and fear Allah; and Allah teaches you; and Allah knows everything.

# 290

And if you are on a journey and cannot find a scribe, then a mortgage (deposit) must be handed over; and if one of you trusts the other, the one who is trusted may return the mortgage entrusted to him and fear Allah, his Lord; and do not hide testimony; and if one hides it, his heart is sinful from within; and Allah knows what you do.

# 291

To Allah only belongs all whatever is in the heavens and all whatever is in the earth; and whether you disclose what is in your hearts or hide it, Allah will take account of it from you; so He will forgive whomever He wills and punish whomever He wills; and Allah is Able to do all things.

# 292

The Noble Messenger believes in what has been sent down to him by his Lord, and so do the believers; all have accepted faith in Allah and His angels and His Books and His Noble Messengers; saying, “We do not make any distinction, in believing, between any of His Noble Messengers”; and they said, “We hear, and we obey; Your forgiveness be granted, O our Lord, and towards You is our return.”

# 293

Allah does not burden anyone, except with something within its capacity; beneficial for it is the virtue it earned, and harmful for it is the evil it earned; “Our Lord! Do not seize us if we forget or are mistaken; our Lord! And do not place on us a heavy burden (responsibility) as You did on those before us; our Lord! And do not impose on us a burden, for which we do not have the strength; and pardon us – and forgive us – and have mercy on us – You are our Master, therefore help us against the disbelievers.”

# 294

Alif-Laam-Meem. (Alphabets of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 295

Allah – none is worthy of worship, except Him, He is Alive (eternally, on His own) and the Upholder (keeps others established).

# 296

He has sent down to you (O dear Prophet Mohammed – peace and blessings be upon him) this true Book (the Holy Qur’an), confirming the Books before it, and He sent down the Taurat (Torah) and the Injeel (Bible). –

# 297

Before this, a guidance to mankind; and sent down the Judgement (Criterion to judge between right and wrong); indeed for those who disbelieved in the verses of Allah, is a severe punishment; and Allah is the Almighty, the Avenger (of the wrong).

# 298

Indeed nothing is hidden from Allah, neither in the earth nor in the heavens.

# 299

It is He Who fashions (moulds) you in your mothers’ wombs as He wills; none is worthy of worship except Him, the Almighty (the Most Honourable), the Wise.

# 300

It is He Who has sent down to you (O dear Prophet Mohammed – peace and blessings be upon him) this Book (the Qur’an) containing the verses that have a clear meaning – they are the core of the Book – and other verses the meanings of which are indistinct; those in whose hearts is deviation pursue the verses having indistinct meanings, in order to cause turmoil and seeking its (wrongful) interpretation; and only Allah knows its proper interpretation; and those having sound knowledge say, “We believe in it, all of it is from our Lord”; and none accept guidance except the men of understanding.

# 301

“Our Lord! Do not deviate our hearts after You have guided us, and bestow mercy on us from Yourself; indeed You only are the Great Bestower.”

# 302

“Our Lord! Indeed You will gather all mankind for a Day about which there is no doubt"; indeed Allah’s promise does not change.

# 303

Indeed for those who disbelieve, neither their wealth nor their offspring will help to save them in the least from Allah; and it is they who are fuel for the fire.

# 304

Like the way of Firaun’s people, and those before them; they denied Our signs; so Allah seized them because of their sins; and Allah’s punishment is severe.

# 305

Say (O dear Prophet Mohammed – peace and blessings be upon him) to the disbelievers, “Very soon you shall be overcome and driven towards hell; and that is a wretched resting-place.”

# 306

Indeed there was a sign for you in the two groups that clashed; one army fighting in Allah's cause, against the other of disbelievers, whom they (the Muslims) saw with their eyes, as twice their own number; and Allah strengthens with His help whomever He wills; indeed in this is a lesson for the intelligent, to be learnt by observing.

# 307

Beautified is for mankind the love of these desires – women, and sons, and heaps of gold and piled up silver, and branded horses, and cattle and fields; this is the wealth of the life of this world; and it is Allah, with Whom is the excellent abode.

# 308

Say (O dear Prophet Mohammed – peace and blessings be upon him), “Shall I inform you of something better than that? For the pious, with their Lord, are Gardens beneath which rivers flow – they will abide in it forever – and pure wives, and Allah’s pleasure”; and Allah sees the bondmen.

# 309

Those who say, “Our Lord! we have accepted faith, so forgive us our sins and save us from the punishment of fire.”

# 310

The steadfast, and the truthful, and the reverent, and who spend in Allah's cause, and who seek forgiveness in the last hours of the night (before dawn).

# 311

Allah has given witness that there is none worthy of worship (God) except Him – and the angels and the scholars also give witness, established with justice (with truth) – there is no God except Him, the Almighty, the Wise.

# 312

Indeed the only true religion in the sight of Allah is Islam; those who had received the Books differed only after the knowledge came to them, due to their hearts’ envy; and whoever disbelieves in the signs of Allah, then Allah is Swift At Taking Account.

# 313

Then if they argue with you, (O dear Prophet Mohammed – peace and blessings be upon him) say, “I have submitted my face (self) to Allah and likewise have my followers”; and say to the People given the Book(s) and the illiterate, “Have you submitted (accepted Islam)?” If they submit, they have attained the right path – and if they turn away (reject), then your duty is only to convey this command; and Allah is seeing the bondmen.

# 314

Those who disbelieve in the signs of Allah, and wrongfully martyr the Prophets, and slay people who enjoin justice – so give them the glad tidings of a painful punishment.

# 315

They are those whose deeds are wasted in this world and in the Hereafter; and they do not have any aides.

# 316

Did you not see them who have received a part of the Book – when called towards the Book of Allah for judging between them, a group of them opposes it and turns away?

# 317

They dared to do this because they say, “The fire will definitely not touch us except for a certain number of days”; and they are deceived in their religion by the lies they fabricated.

# 318

So what will be (their state) when We bring all of them together for the Day (of Resurrection) about which there is no doubt; and every soul will be paid back in full for what it has earned, and they will not be wronged.

# 319

Invoke (O dear Prophet Mohammed – peace and blessings be upon him), “O Allah! Owner Of The Kingdom – You bestow the kingdom on whomever You will, and You take back the kingdom from whomever You will; and You give honour to whomever You will, and You humiliate whomever You will; only in Your Hand (control) lies all goodness; indeed, You are Able to do all things.”

# 320

“You cause part of the night to pass into the day, and You cause part of the day to pass into the night; and You bring forth the living from the dead, and You bring forth the dead from the living; and You give to whomever You will, without account.”

# 321

The Muslims must not befriend the disbelievers, in preference over the Muslims; whoever does that has no connection whatsoever with Allah, except if you fear them; Allah warns you of His wrath; and towards Allah only is the return.

# 322

Say, (O dear Prophet Mohammed – peace and blessings be upon him), “Whether you hide or reveal whatever is in your hearts, Allah knows it all; and He knows all whatever is in the heavens and all whatever is in the earth; and Allah has control over all things.”

# 323

On the Day when every soul will be confronted with all the good that it has done; and all the evil that it has done – it will wish that perhaps there would have been a great distance between itself and the punishment; and Allah warns you of His punishment; and Allah is Most Compassionate towards His bondmen.

# 324

Proclaim, (O dear Prophet Mohammed – peace and blessings be upon him), “O mankind! If you love Allah, follow me – Allah will love you and forgive you your sins”; and Allah is Oft Forgiving, Most Merciful.

# 325

Proclaim, “Obey Allah and the Noble Messenger”; so if they turn away – then Allah is not pleased with the disbelievers.

# 326

Indeed Allah chose Adam, and Nooh, and the Family of Ibrahim, and the Family of Imran over the creation.

# 327

They are the descendants one of another; and Allah is the All Hearing, the All Knowing.

# 328

(Remember) When the wife of Imran said, “My Lord! I pledge to you what is in my womb – that it shall be dedicated purely in Your service, so accept it from me; indeed You only are the All Hearing, the All Knowing.”

# 329

So when she gave birth to it, she said, “My Lord! I have indeed given birth to a girl!” And Allah well knows what she gave birth to; and the boy she had prayed for is not like this girl; “And I have named her Maryam and I give her and her offspring in Your protection, against Satan the outcast.”

# 330

So her Lord fully accepted her (Maryam), and gave her an excellent development; and gave her in Zakaria’s guardianship; whenever Zakaria visited her at her place of prayer, he found new food with her; he said, “O Maryam! From where did this come to you?” She answered, “It is from Allah; indeed Allah gives to whomever He wills, without limit account.” (Miracles occur through the friends of Allah.)

# 331

It is here that Zakaria prayed to his Lord; he said, “My Lord! Give me from Yourself a righteous child; indeed You only are the Listener Of Prayer.”

# 332

And the angels called out to him while he was standing, offering prayer at his place of worship, “Indeed Allah gives you glad tidings of Yahya (John), who will confirm a Word (or sign) from Allah, – a leader, always refraining from women, a Prophet from one of Our devoted ones.”

# 333

He said, “My Lord! How can I have a son when old age has reached me and my wife is barren?” He said, “This is how Allah brings about, whatever He wills.”

# 334

He said, “My Lord! Determine a sign for me”; He said, “The sign is that you shall not be able to speak to mankind for three days except by signs; and remember your Lord profusely, and proclaim His Purity before sunset and at dawn.”

# 335

And when the angels said, “O Maryam! Indeed Allah has chosen you and purified you, and has this day, chosen you among all the women of the world.”

# 336

“O Maryam! Stand in reverence before your Lord, prostrate yourself and bow along with those who bow.”

# 337

These are tidings of the hidden, which We secretly reveal to you (O dear Prophet Mohammed – peace and blessings be upon him); and you were not present with them when they threw their pens to draw lots, to know who should be the guardian of Maryam; nor were you present with them when they were quarrelling. (Yet you know of these things – this is a proof of your being a Prophet.)

# 338

And remember when the angels said, “O Maryam! Allah gives you glad tidings of a Word from Him, whose name is the Messiah, Eisa the son of Maryam – he will be honourable in this world and in the Hereafter, and among the close ones (to Allah).”

# 339

“He will speak to people while he is in the cradle and in his adulthood, and will be of the devoted ones.”

# 340

She said, “My Lord! How can I bear a child when no man has ever touched me?” He said, “This is how Allah creates whatever He wills; when He wills a thing, He only says to it, ‘Be’ – and it happens immediately.”

# 341

“And Allah will teach him the Book and wisdom, and the Taurat (Torah) and the Injeel (Bible).”

# 342

“And he will be a Noble Messenger towards the Descendants of Israel saying, ‘I have come to you with a sign from your Lord, for I mould a birdlike sculpture from clay for you, and I blow into it and it instantly becomes a (living) bird, by Allah’s command; and I heal him who was born blind, and the leper, and I revive the dead, by Allah’s command; and I tell you what you eat and what you store in your houses; undoubtedly in these (miracles) is a great sign for you, if you are believers.’ (Several miracles bestowed to Prophet Eisa are mentioned here.)

# 343

‘And I come confirming the Taurat (Torah) – the Book before me – and to make lawful for you some of the things which were forbidden to you, and I have come to you with a sign from your Lord – therefore fear Allah and obey me.’

# 344

‘Undoubtedly Allah is the Lord of all – mine and yours – so worship Him only; this is the Straight Path.’”

# 345

So when Eisa sensed their disbelief he said, “Who will be my aides towards (in the cause of) Allah?” The disciples said, “We are the aides of Allah’s religion; we believe in Allah, and you bear witness that we are Muslims.”

# 346

“Our Lord! We have believed in what You have sent down and we follow the Noble Messenger, therefore record us among the witnesses of the truth.”

# 347

And the disbelievers conspired (to kill Eisa), and Allah covertly planned to destroy them; and Allah is the best of secret planners.

# 348

Remember when Allah said, “O Eisa! I will keep you alive till your full age, and raise you towards Me, and cleanse you of the disbelievers and give your followers dominance over the disbelievers until the Day of Resurrection; then you will all return to Me, so I shall judge between you concerning the matter in which you dispute.”

# 349

“So I shall mete a severe punishment to those who disbelieve, in this world and in the Hereafter; and they will not have any supporters.”

# 350

“And for those who believed and did good deeds, Allah will give them their full reward; and Allah does not like the unjust.”

# 351

These are some verses that We recite to you, and advice full of wisdom.

# 352

The example of Eisa with Allah is like that of Adam; He created him (Adam) from clay and then said to him, “Be” – and it thereupon happens!

# 353

O listener! (followers of this Prophet) This is the Truth from your Lord, so never be of those who doubt.

# 354

Therefore say to those who dispute with you (O dear Prophet Mohammed – peace and blessings be upon him) concerning Eisa after the knowledge has come to you, “Come! Let us summon our sons and your sons, and our women and your women, and ourselves and yourselves – then pray humbly, thereby casting the curse of Allah upon the liars!” (The Christians did not accept this challenge.)

# 355

This undoubtedly is the true narrative; there is none worthy of worship except Allah; and Allah is the Almighty, the Wise.

# 356

So if they turn away, then indeed Allah knows those who cause turmoil.

# 357

Say (O dear Prophet Mohammed – peace and blessings be upon him), “O People given the Book(s)! Come towards a word which is common between us and you, that we shall worship no one except Allah, and that we shall not ascribe any partner to Him, and that none of us shall take one another as lords besides Allah”; then if they do not accept say, “Be witness that (only) we are Muslims.”

# 358

O People given the Book(s)! Why do you argue about Ibrahim, whereas the Taurat (Torah) and the Injeel (Bible) were not sent down until after him? So do you not have sense?

# 359

Listen! This was what you argued about – of which you have some knowledge – why do you then argue about the matter you do not have any knowledge of? And Allah knows whereas you do not know.

# 360

Ibrahim was neither a Jew nor a Christian; but he was a Muslim, free from all falsehood; and was not of the polytheists.

# 361

Undoubtedly among all mankind who have the best claim to Ibrahim are those who followed him, and this Prophet (Mohammed – peace and blessings be upon him) and the believers; and Allah is the Guardian of the believers.

# 362

A group among the People given the Book(s) desire that if only they could lead you astray; and they only make themselves astray, and they do not have sense.

# 363

O People given the Book(s)! Why do you disbelieve in the signs of Allah, whereas you yourselves are witnesses?

# 364

O People given the Book(s)! Why do you mix the truth with falsehood and conceal the truth, whereas you know?

# 365

And a group among the People given the Book(s) said, “Believe in what has been sent down to the believers in the morning and deny it by evening – perhaps they (the Muslims) may turn back (disbelieve).”

# 366

“And do not believe in anyone except him who follows your religion”; say (O dear Prophet Mohammed – peace and blessings be upon him), “Only Allah’s guidance is the true guidance” – (so why not believe in it) if someone has been given similar to what was given to you, or if someone may be able to evidence it against you before your Lord; say (O dear Prophet Mohammed – peace and blessings be upon him), “Undoubtedly the munificence lies only in Allah’s Hand (control); He may bestow upon whomever He wills; and Allah is Most Capable, All Knowing.”

# 367

“He chooses by His mercy, whomever He wills; and Allah is the Owner of Great Munificence.”

# 368

Among the People given the Book(s) is one who, if you trust him with a heap of treasure, will return it to you; and among them is one who, if you trust him with (just) one coin, will not return it to you unless you constantly stand over him (keep demanding); that is because they say, “We are not obliged in any way, in the case of illiterates”; and they purposely fabricate lies against Allah.

# 369

Yes, why not? Whoever fulfilled his pledge and practised piety – and indeed Allah loves the pious.

# 370

Those who accept abject prices in exchange of Allah’s covenant and their oaths, do not have a portion in the Hereafter – Allah will neither speak to them nor look towards them on the Day of Resurrection, nor will He purify them; and for them is a painful punishment.

# 371

And amongst them are some who distort (change words of) the Book with their tongues, so that you may think that this also is in the Book whereas it is not in the Book; and they say, “This is from Allah” whereas it is not from Allah; and they fabricate lies against Allah, whereas they know.

# 372

It is not for any human to whom Allah has given the Book and wisdom and Prophethood, that he should afterwards say to the people, “Leave (the worship of) Allah and be my worshippers” – but he will surely say, “Be sincere worshippers of Allah, because you teach the Book and you preach from it.”

# 373

And nor will he command you to appoint the angels and the Prophets as Gods; would he (a Prophet) command you to disbelieve after you have become Muslims?

# 374

And remember when Allah took a covenant from the Prophets; “If I give you the Book and knowledge and the (promised) Noble Messenger (Prophet Mohammed – peace and blessings be upon him) comes to you, confirming the Books you possess, you shall positively, definitely believe in him and you shall positively, definitely help him”; He said, “Do you agree, and accept My binding responsibility in this matter?” They all answered, “We agree”; He said, “Then bear witness amongst yourselves, and I Myself am a witness with you.”

# 375

So those who turn away after this – it is they who are the sinners.

# 376

So do they desire a religion other than the religion of Allah, whereas to Him has submitted whoever is in the heavens and the earth, willingly or grudgingly, and it is to Him they will return?

# 377

Say, “We believe in Allah and what is sent down to us and what was sent down to Ibrahim, and Ismael, and Ishaq, and Yaqub (Jacob) and their sons, and that which came to Moosa and Eisa and the Prophets, from their Lord; we do not make any distinction, in belief, between any of them, and to Him we have submitted ourselves.”

# 378

And if one seeks a religion other than Islam, it will never be accepted from him; and he is among the losers in the Hereafter.

# 379

Why should Allah will guidance for the people who disbelieved, after their having accepted faith and bearing witness that the Noble Messenger is a true one, and after clear signs had come to them? And Allah does not guide the unjust.

# 380

The recompense of such is that on them is the curse of Allah and of the angels and of men combined.

# 381

Remaining in it forever; their punishment will not be lightened, nor will they get any respite.

# 382

Except those who repented thereafter and reformed themselves; then indeed Allah is Oft Forgiving, Most Merciful.

# 383

Indeed those who disbelieve after having accepted faith, and advance further in their disbelief – their repentance will never be accepted; and it is they who are the astray.

# 384

Those who disbelieved and died as disbelievers – an earth full of gold will never be accepted from any one of them, even if he offers it, for his freedom; for them is a painful punishment and they do not have any aides.

# 385

You can never attain virtue until you spend in Allah's cause the things you love; and Allah is Aware of whatever you spend.

# 386

All food was lawful for the Descendants of Israel (Jacob), except what Israel forbade for himself, before the Taurat (Torah) was sent down; say, “Bring the Taurat and read it, if you are truthful.”

# 387

So henceforth whoever fabricates lies against Allah – it is they who are the unjust.

# 388

Say (O dear Prophet Mohammed – peace and blessings be upon him), “Allah is truthful; so follow the religion of Ibrahim, who was free from all falsehood; and he was not of the polytheists.”

# 389

Indeed the first house that was appointed as a place of worship for mankind, is the one at Mecca (the Holy Ka’aba), blessed and a guidance to the whole world;

# 390

In it are clear signs – the place where Ibrahim stood (is one of them); and whoever enters it shall be safe; and performing the Hajj (pilgrimage) of this house, for the sake of Allah, is a duty upon mankind, for those who can reach it; and whoever disbelieves – then Allah is Independent (Unwanting) of the entire creation!

# 391

Say (O dear Prophet Mohammed – peace and blessings be upon him), “O People given the Book(s)! Why do you not believe in the verses (or signs) of Allah, whereas your deeds are being witnessed by Allah?”

# 392

Say (O dear Prophet Mohammed – peace and blessings be upon him), “O People given the Book(s)! Why do you prevent those who have accepted faith from the way of Allah, seeking to cause deviation in it, whereas you yourselves are witnesses to it? And Allah is not unaware of your deeds!”

# 393

O People who Believe! If you obey some of People given the Book(s), they will definitely turn you into disbelievers after your having accepted faith.

# 394

And how can you disbelieve, whereas Allah’s verses are recited to you and His Noble Messenger is present amongst you?! And whoever takes the support of Allah is indeed guided to the right path.

# 395

O People who Believe! Fear Allah in the manner He should rightfully be feared, and do not die except as Muslims.

# 396

And hold fast to the rope of Allah, all of you together, and do not be divided; and remember Allah’s favour on you, that when there was enmity between you, He created affection between your hearts, so due to His grace you became like brothers to each other; and you were on the edge of a pit of fire (hell), so He saved you from it; this is how Allah explains His verses to you, so that you may be guided.

# 397

And there should be a group among you that invites to goodness, and enjoins good deeds and forbids immorality; it is they who are the successful.

# 398

And do not be like those who became divided and disputed after the clear signs had come to them; and for them is a terrible punishment.

# 399

On the Day (of Resurrection) when some faces will be shining and some faces black; so, (to) those whose faces are blackened, “What! You disbelieved after you had accepted faith! Therefore now taste the punishment, the result of your disbelief.”

# 400

And those whose faces will be shining, are in the mercy of Allah; they will abide in it forever.

# 401

These are the verses of Allah, which We recite to you (O dear Prophet Mohammed – peace and blessings be upon him), with truth; and Allah does not wish any injustice to the creation.

# 402

And to Allah only belongs all whatever is in the heavens and all whatever is in the earth; and towards Allah only is the return of all matters.

# 403

You are the best among all the nations that were raised among mankind – you enjoin good deeds and forbid immorality and you believe in Allah; and if the People given the Book(s) believed it would be better for them; some of them are believers (Muslims) and most of them are disbelievers. (The best Ummah is that of Prophet Mohammed – peace and blessings be upon him.)

# 404

They cannot harm you except cause some trouble; and if they fight against you, they will turn their backs on you; then they will not be helped.

# 405

Disgrace has been destined for them – wherever they are they shall not find peace, except by a rope from Allah and a rope from men – and they have deserved the wrath of Allah, and misery is destined for them; that is because they used to disbelieve in the signs of Allah, and unjustly martyr the Prophets; that was for their disobedience and transgression.

# 406

All of them are not alike; among the People given the Book(s) are some who are firm on the truth – they recite the verses of Allah in the night hours and prostrate (before Him).

# 407

They accept faith in Allah and the Last Day, and enjoin good deeds and forbid immorality, and hasten to perform good deeds; and they are the righteous.

# 408

And they will not be denied the reward of whatever good they do; and Allah knows the pious.

# 409

Indeed those who disbelieve – neither their wealth nor their offspring will help save them in the least, from Allah; and they are the people of fire; remaining in it forever.

# 410

The example of what they spend in this worldly life is similar to the freezing cold wind which struck the fields of a nation who wronged themselves, and destroyed it completely; and Allah did not oppress them, but it is they who wronged themselves.

# 411

O People who Believe! Do not share your secrets with others – they do all they can to ruin you; they desire the maximum harm for you; enmity has been revealed from their speech, and what they hide in their breasts is greater; we have explained the signs clearly to you, if you have intelligence.

# 412

Listen! It is you who love them and they do not love you, whereas the fact is that you believe in all the Books; when they meet you they say, “We believe”; and when they are alone they chew their fingers at you with rage; say, “Die in your frenzy!” Allah knows well what lies within the hearts.

# 413

If some good reaches you, they feel unhappy; and if misfortune befalls you, they will rejoice; and if you remain steadfast and pious, their evil scheme will not harm you in the least; undoubtedly all what they do is encompassed by Allah.

# 414

And remember O dear Prophet (Mohammed – peace and blessings be upon him) when you came forth from your house in the morning, appointing the believers on positions of battle; and Allah is All Hearing, All Knowing.

# 415

When two groups among you almost decided to show cowardice – and Allah is their Protector; and in Allah only should the believers trust.

# 416

Allah indeed aided you at Badr when you had no means; so fear Allah – so that you may be thankful.

# 417

When you O dear Prophet (Mohammed – peace and blessings be upon him) said to the believers, “Is it not sufficient for you that your Lord may support you by sending down three thousand angels?”

# 418

Yes, why not? If you patiently endure and remain pious, and the disbelievers attack you suddenly, your Lord will send down five thousand marked angels to help you.

# 419

And Allah did not bestow this victory except for your happiness, and only that your hearts may attain peace with it; and there is no help except from Allah, the Almighty, the Wise.

# 420

So He may cut off a part of the disbelievers, or disgrace them so that they return unsuccessful.

# 421

This matter is not for you to decide – whether He guides them to repent or punishes them, for they are the unjust.

# 422

And to Allah only belongs all whatever is in the heavens and all whatever is in the earth; He may forgive whomever He wills, and punish whomever He wills; and Allah is Oft Forgiving, Most Merciful.

# 423

O People who Believe! Do not devour usury doubling and quadrupling it; and fear Allah, hoping that you achieve success.

# 424

And save yourselves from the fire which is prepared for disbelievers.

# 425

And obey Allah and the Noble Messenger, hoping that you gain mercy. (Obeying the Prophet is in fact obeying Allah.)

# 426

And rush towards forgiveness from your Lord, and towards a Paradise that can hold all the heavens and the earth in its width – prepared for the pious.

# 427

Those who spend in Allah’s cause, in happiness and in grief, and who control their anger and are forgiving towards mankind; and the righteous are the beloved of Allah.

# 428

And those who, when they commit an immoral act or wrong themselves, remember Allah and seek forgiveness of their sins – and who forgives sins except Allah? And those who do not purposely become stubborn regarding what they did.

# 429

For such the reward is forgiveness from their Lord, and Gardens beneath which rivers flow – abiding in it forever; what an excellent reward for the performers (of good deeds)!

# 430

Some traditions have been tried before you – therefore travel in the land and see what sort of fate befell those who denied.

# 431

This is an explanation for mankind, a guidance and an advice to the pious.

# 432

And do not be negligent nor grieve – it is you who will be victorious if you are believers.

# 433

If you have been struck by some misfortune, so they (the disbelievers) too have been struck earlier with the same misfortune; these are the days in which We have allotted turns to people; and so that Allah may make known the believers and may bestow martyrdom to some of you; and Allah does not befriend the unjust.

# 434

And so that Allah may purify\* the believers, and destroy the disbelievers. (\* Forgive them their sins, if any.)

# 435

What! You assume that you will enter Paradise while Allah has not yet tested your warriors, nor yet tested the steadfast?

# 436

And you used to wish for death before you met it; so now you see it before your eyes.

# 437

And Mohammed (peace and blessings be upon him) is purely\* a Noble Messenger; there have been Noble Messengers before him; so if he departs or is martyred, will you turn back on your heels? So whoever turns back on his heels does not cause any harm to Allah; and Allah will soon reward the thankful. (\* Neither God nor an angel, but a human being with the highest spiritual status.)

# 438

And no soul can die except by Allah’s command – a time has been appointed for each; whoever desires the rewards of this world, We bestow upon him from it; and whoever desires the reward of the Hereafter, We bestow upon him from it; and We shall soon reward the thankful.

# 439

And many Prophets have fought in Allah’s cause – and many devoted men were with them; so neither did they lose heart due to the calamities that befell them in Allah's cause, nor did they weaken and nor were they subdued; and the steadfast are the beloved of Allah.

# 440

And they never said anything except that they invoked, “Our Lord! Forgive us our sins and the excesses committed during our efforts, and keep our feet steady, and bestow us help over the disbelievers.”

# 441

So Allah gave them the reward of this world and the best of rewards in the Hereafter; and Allah loves the righteous.

# 442

O People who Believe! If you obey the disbelievers, they will make you turn back on your heels, so you will then turn back as losers.

# 443

In fact, Allah is your Master; and He is the Best Supporter.

# 444

Soon We shall cast awe in the hearts of disbelievers because they have appointed partners to Allah, for which He has not sent any proof; their destination is hell; and what a wretched abode for the unjust!

# 445

And indeed Allah has proved true His promise to you, when you used to slay the disbelievers by His command; until the time you people lost courage and disputed about the order and disobeyed after Allah had shown you what pleases you; some of you desired the world, and some of you desired the Hereafter; thereafter He turned you away from them in order to test you; and undoubtedly He has forgiven you; and Allah is Most Munificent towards the Muslims.

# 446

When you were leaving, unconcerned without turning to look back at anyone, and from another group Our Noble Messenger was calling you (to fight); so He gave you sorrow in lieu of sorrow, and then forgave you so that you do not grieve over what has been lost or over the calamity that befell you; and Allah is Well Aware of what you do.

# 447

Then after grief, He sent down a peaceful slumber (calm), which engulfed a group among you – and another party kept fearing for their own lives, thinking wrongfully of Allah – like the thoughts of ignorance; they say, “Do we have any authority in this matter?” Say (O dear Prophet Mohammed – peace and blessings be upon him), “All authority lies only with Allah”; they hide in their hearts what they do not reveal to you; they say, “Had we any control, we would not have been slain here”; say, “Even if you had been in your houses, those destined to be slain would have come forth to their places of slaying; and in order that Allah may test what is in your breasts and reveal whatever is in your hearts”; and Allah knows well what lies within the hearts.

# 448

Indeed those of you who turned back on the day when the two armies met – for it was the devil who caused them to waver, because of some of their deeds; and undoubtedly Allah has forgiven them; indeed Allah is Oft Forgiving, Most Forbearing.

# 449

O People who Believe! Do not be like the disbelievers who said regarding their brothers who went on a journey or on holy war, “If they had been here with us they would not have died or been killed” – so that Allah may make it as despair in their hearts; and Allah gives life and causes death; and Allah is seeing your deeds.

# 450

And if you are killed in Allah’s way or die, then the pardon from Allah and mercy are better than all what they hoard.

# 451

And whether you are killed or you die, towards Allah you will be gathered.

# 452

So what a great mercy it is from Allah that you (O dear Prophet Mohammed – peace and blessings be upon him), are lenient towards them; and if you had been stern and hardhearted (unsympathetic) they would have certainly been uneasy in your company; so forgive them and intercede for them and consult with them in the conduct of affairs; and when you decide upon something, rely upon Allah; indeed Allah loves those who trust (Him).

# 453

If Allah supports you, no one can overcome you; and if He forsakes you, who is there who can then help you? And in Allah only should the Muslims trust.

# 454

And it is unimaginable that any Prophet would hide something; and whoever hides it, will bring what he hid with him on the Day of Resurrection; then every soul will be paid in full for whatever they earned; and they will not be wronged.

# 455

So is one who follows the will of Allah equal to one who has incurred the wrath from Allah and whose home is the fire? And what a wretched place to return!

# 456

They are in different ranks before Allah; and Allah sees their deeds.

# 457

Allah has indeed bestowed a great favour upon the Muslims, in that He sent to them a Noble Messenger (Prophet Mohammed – peace and blessings be upon him) from among them, who recites to them His verses, and purifies them, and teaches them the Book and wisdom; and before it, they were definitely in open error. (The Holy Prophet Mohammed – peace and blessings be upon him – is one of Allah’s greatest favours to mankind.)

# 458

So will you say when disaster strikes you, though you had struck them with twice as much, “Where has this come from?” Say (to them, O dear Prophet Mohammed – peace and blessings be upon him), “It has come from yourselves”; indeed Allah is Able to do all things.

# 459

And the calamity that struck you on the day the two armies met, was by Allah’s command – and in order that He may make known the believers.

# 460

And in order to expose them who turned hypocrites; and it was said to them, “Come, fight in Allah's cause, or repel the enemy”; they answered, “If we knew how to fight, we would certainly have been with you”; and on that day they were nearer to open disbelief than to professed faith; they utter with their mouths what is not in their hearts; and Allah knows well what they hide. –

# 461

Those who spoke regarding their brothers while they themselves stayed back at home, “Had they listened to us, they would not have been slain”; say (to them, O dear Prophet Mohammed – peace and blessings be upon him), “Then avert your own death, if you are truthful!”

# 462

And do not ever assume that those who are slain in Allah's cause, are dead; in fact they are alive with their Lord, receiving sustenance. (Death does not mean extinction, it is the passing of the soul from this world to another. In case of virtuous believers, their bodies do not rot after death and they remain “alive”, in the manner Allah has ordained for them.)

# 463

Happy over what Allah has bestowed upon them from His grace, and rejoicing for those who will succeed them, and have not yet joined them; for on them is no fear nor any grief.

# 464

They rejoice because of the favours from Allah and (His) munificence, and because Allah does not waste the reward of the believers.

# 465

Those who responded to the call of Allah and His Noble Messenger after they had been grieved; for the virtuous and the pious among them is a great reward.

# 466

Those to whom the people said, “The people have gathered against you, therefore fear them”, so their faith was further increased; and they said, “Allah is Sufficient for us – and what an excellent (reliable) Trustee (of affairs) is He!”

# 467

So they returned with the favour and munificence from Allah, in that no harm reached them; they followed what pleased Allah; and Allah is Extremely Munificent.

# 468

It is the devil who threatens with his friends; so do not fear them and fear Me, if you have faith.

# 469

And O dear Prophet (Mohammed – peace and blessings be upon him) do not grieve for those who rush towards disbelief; they cannot cause any harm to Allah; and Allah does not will to assign them any portion in the Hereafter; and for them is a terrible punishment.

# 470

Those who have purchased disbelief in exchange of faith cannot cause any harm to Allah; and for them is a painful punishment.

# 471

And never must the disbelievers be under the illusion that the respite We give them is any good for them; We give them respite only for them to further advance in their sins; and for them is a disgraceful punishment.

# 472

Allah will not leave you, O People who Believe (the Muslims) in your present state, till He separates the evil from the good; and it does not befit Allah’s Majesty to give you, the common men, knowledge of the hidden, but Allah does chose from His Noble Messengers whomever He wills; so believe in Allah and His Noble Messengers; and if you believe and practice piety, for you is a great reward. (Allah gave the knowledge of the hidden to the Holy Prophet – peace and blessings be upon him.)

# 473

And never must those who act miserly upon what Allah has bestowed upon them of His grace, think that it is good for them; in fact it is harmful for them; soon what they had withheld will be collars round their necks on the Day of Resurrection; and Allah only is the Inheritor (Owner) of the heavens and the earth; and Allah is Well Aware of what you do.

# 474

Undoubtedly Allah heard them who said, “Allah is needy, and we are the wealthy”; We shall keep recorded their saying and their wrongfully martyring of the Prophets; and We shall say, “Taste the punishment of the fire!”

# 475

“This is the recompense of what your hands have sent ahead and Allah does not oppress the bondmen.”

# 476

Those who say, “Allah has agreed with us that we should not believe in any Noble Messenger until he comes with the command to offer a sacrifice, which a fire (from heaven) shall devour”; say (O dear Prophet Mohammed – peace and blessings be upon him), “Many Noble Messengers did come to you before me, with clear signs and with this command which you state – why did you then martyr them, if you are truthful?”

# 477

So O dear Prophet (Mohammed – peace and blessings be upon him) if they are denying you, Noble Messengers who came before you had also been denied, who had come with clear signs and Scriptures and the clear Book.

# 478

Every soul must taste death; and only on the Day of Resurrection will you be fully recompensed; so the one who is saved from the fire and is admitted into Paradise – he is undoubtedly successful; and the life of this world is just counterfeit wealth.

# 479

You will surely be tried in respect of your property and lives, and you will surely hear much wrong from those who were given the Book before you, and from the polytheists; and if you remain steadfast and remain pious, it is then an act of great courage.

# 480

And remember when Allah took a covenant from the People given the Book(s) that, “You shall definitely preach it to the people and not hide it”; so they flung it behind their backs and gained an abject price for it; so what a wretched bargain it is!

# 481

Do not ever think of those who rejoice for their deeds and wish to be praised without doing (good deeds) – do not ever think that they are safe from the punishment; and for them is a painful punishment.

# 482

And for Allah only is the kingship of the heavens and the earth; and Allah is Able to do all things.

# 483

Undoubtedly in the creation of the heavens and the earth and the alternation of night and day are signs for the intelligent.

# 484

Those who remember Allah while standing, and sitting, and reclining on their sides, and ponder about the creation of the heavens and the earth; “O our Lord! You have not created this without purpose; Purity is to You, therefore save us from the punishment of fire.”

# 485

“O our Lord! You have indeed given disgrace to whomever You put in the fire (of hell); and the unjust do not have any supporters.”

# 486

“O our Lord! We have heard a proclaimer calling towards faith, (saying) ‘Believe in your Lord’ so we have accepted faith; Our Lord! Therefore forgive us our sins, and wipe out our evil deeds, and make us die among the virtuous.”

# 487

“O our Lord! And give us what You have promised us through Your Noble Messengers, and do not humiliate us on the Day of Resurrection; indeed You do not break the promise.”

# 488

So their Lord accepted their prayer, for I do not waste the efforts of any (righteous) worker, male or female; you are all one among yourselves; so those who migrated and were driven out from their homes and were harassed in My cause, and fought, and were slain – I will certainly wipe out all their sins and will certainly admit them into Gardens beneath which rivers flow; a reward from Allah; and only with Allah is the best reward.

# 489

O listener (followers of this Prophet)! Do not ever be deceived by the disbelievers’ free movements in the cities.

# 490

It is a brief usage; their home is hell; and what an evil resting-place!

# 491

But for those who fear their Lord are Gardens beneath which rivers flow – abiding in it for ever – the hospitality from their Lord; and that which is with Allah, is the best for the righteous.

# 492

And undoubtedly there are some among the People given the Book(s), who accept faith in Allah and what is sent down to you and what was sent down to them – their hearts are submitted humbly before Allah – they do not exchange the verses of Allah for an abject price; they are those whose reward is with their Lord; indeed Allah is Swift At Taking Account.

# 493

O People who Believe! Endure and surpass your enemies in endurance, and guard the frontiers of the Islamic nation; and keep fearing Allah, hoping that you may succeed.

# 494

O mankind! Fear your Lord Who created you from a single soul and from it created its spouse and from them both has spread the multitude of men and women; fear Allah in Whose name you claim (your rights from one another) and be mindful of your blood relations; indeed Allah is always seeing you.

# 495

And give the orphans their wealth and do not exchange the pure for the foul; and do not devour (or use up) their wealth, mixing it with your own; this is indeed a great sin.

# 496

And if you fear that you will not be just towards orphan girls, marry the women whom you like – two at a time, or three or four; then if you fear that you cannot keep two women equally then marry only one or the bondwomen you own; this is closer to your not doing injustice.

# 497

And give the women their bridal money willingly; then if they willingly give you a part of it, eat (use) it with joy and fruition.

# 498

And do not give the foolish their wealth which is in your custody – those for whom Allah has put you in charge to maintain (look after) – and feed and clothe them from it, and speak kindly to them.

# 499

And test the orphans till they are fit to get married (reach full age); then if you find them of proper judgement, hand over their wealth to them; and do not devour it by spending excessively and hastily, fearing that they will grow up; and whoever is not in need must abstain; and whoever is needy may use from it in a reasonable measure; and when you hand over their wealth to them, get witnesses over them; and Allah is Sufficient to take account.

# 500

For men is a share from what the parents and near relatives leave behind, and for women is a share from what the parents and near relatives leave behind, whether the wealth (inheritance) is small or large; the share is a fixed one.

# 501

And if relatives and orphans and the needy are present at the time of disbursement, give them something from it and speak to them with kindness.

# 502

And those people must fear, who if they die leaving behind them young children would be afraid for them; so they must fear Allah and speak with fairness.

# 503

Indeed those who unjustly devour the wealth of orphans only fill their bellies with fire; and soon they will go into a blazing pit.

# 504

Allah commands you concerning your children; the son’s share is equal to that of two daughters; and if there are only daughters, for them is two-thirds of the inheritance, even if they are more than two; and if there is only one daughter, for her is half; and to each of the deceased’s parents a sixth of the inheritance, if he has children; and if the deceased has no children but leaves behind parents, then one third for the mother; and if he has several brothers and sisters, a sixth for the mother, after any will he may have made and payment of debt; your fathers and your sons – you do not know which of them will be more useful to you; this is the share fixed by Allah; indeed Allah is All Knowing, Wise.

# 505

And from what your wives leave, half is for you if they do not have any child; or if they have a child for you is a fourth of what they leave, after any will they may have made or debt to be paid; and to the women is a fourth of what you leave behind, if you do not have any child; or if you have a child then an eighth of what you leave behind, after any will you may have made, or debt to be paid; and if a deceased does not leave behind a mother, father or children but has a brother or a sister through a common mother, then to each of them a sixth; and if they (brothers and sisters) are more than two, then they shall all share in a third, after any will that may have been made or debt to be paid, in which the deceased has not caused a loss (to the heirs); this is the decree of Allah; and Allah is All Knowing, Most Forbearing.

# 506

These are the limits of Allah; and whoever obeys Allah and His Noble Messenger – Allah will admit him into Gardens beneath which rivers flow – abiding in it forever; and this is the great success.

# 507

And whoever disobeys Allah and His Noble Messenger and crosses all His limits – Allah will put him in the fire (of hell), in which he will remain forever; and for him is a disgraceful punishment.

# 508

And take testimony from four chosen men amongst you, against the women among you who commit adultery; and if they testify, confine those women in the houses until death takes them away or Allah creates a solution for them.

# 509

And punish them both, the man and the woman, whoever are guilty of it (adultery); then if they repent and become pious, leave them; indeed Allah is the Most Acceptor Of Repentance, Most Merciful.

# 510

Undoubtedly the repentance which Allah has by His grace made obligatory upon Himself to accept, is only the repentance of those who commit sin in folly and then soon repent – towards them does Allah incline in mercy; and Allah is the All Knowing, the Wise.

# 511

And that repentance is not of those who constantly commit sins, and when death approaches one of them, he says, “I repent now”, nor of those who die as disbelievers; for them, We have kept prepared a painful punishment.

# 512

O People who Believe! It is not lawful for you to forcibly become the women’s heirs; and do not restrain women with the intention of taking away a part of bridal money you gave them, unless they openly commit the shameful; and deal kindly with them; and if you do not like them, so it is possible that you dislike a thing in which Allah has placed abundant good.

# 513

And if you wish to change one wife for another and you have given her heaps of treasure, do not take back anything from it; will you take it back by slander and open sin?

# 514

And how will you take it back whereas you have become unveiled before each other, and they have taken a strong pledge from you?

# 515

And do not marry the women who were wedded to your fathers (and grand fathers), except what has already passed; that is indeed an act of shame and great wrong; and an evil way.

# 516

Forbidden for you are your mothers, and your daughters, and your sisters, and your father’s sisters, and your mother’s sisters, and your brothers’ daughters and your sisters’ daughters, and your foster-mothers (who breast-fed you), and their daughters (your foster-sisters), and your wives’ mothers (mothers-in-law), and your wives’ daughters who are under your protection – born of the women with whom you have cohabited; and if you have not cohabited with them, then it is no sin for you to marry their daughters; and (forbidden are) the wives of your own sons (and foster-sons and grandsons) and the keeping of two sisters together in marriage, except what has already passed; indeed Allah is Oft Forgiving, Most Merciful.

# 517

And all married women are forbidden for you except the wives of disbelievers who come into your possession as bondwomen; this is Allah’s decree for you; and other than these, all women are lawful for you so that you seek them in exchange of your wealth in proper wedlock, not adultery; therefore give the women you wish to marry, their appointed bridal money; and after the appointment (of bridal money) there is no sin on you if you come to a mutual agreement; indeed Allah is All Knowing, Wise.

# 518

And whoever among you does not have in marriage free, believing women due to poverty, should marry from the believing bondwomen you own; and Allah knows well your faith; you are from one another; therefore marry them with the permission of their masters, and give them their bridal money according to custom, they becoming (faithful) wives, not committing mischief or secretly making friends; so when they are married and commit the shameful, for them is half the punishment prescribed for free women; this is for one among you who fears falling into adultery; and to practice patience is better for you; and Allah is Oft Forgiving, Most Merciful.

# 519

Allah wills to explain His commands to you and show you the ways of those before you, and to incline towards you with His mercy; and Allah is All Knowing, Wise.

# 520

And Allah wills to incline towards you with His mercy; and those who pursue their own pleasures wish that you be far separated from the Straight Path.

# 521

Allah wills to lessen your burden; and man was created weak.

# 522

O People who Believe! Do not unjustly devour the property of each other, except through trade by mutual agreement; and do not kill one another; indeed Allah is Most Merciful upon you.

# 523

And whoever does that through injustice and oppression, We shall soon put him in the fire; and this is easy for Allah.

# 524

If you keep avoiding the cardinal sins that are forbidden to you, We will forgive you your other (lesser) sins and admit you into a noble place.

# 525

And do not long for things by which Allah has given superiority to some of you over others; for men is the share of what they earn; and for women the share from what they earn; and seek from Allah His munificence; indeed Allah knows everything.

# 526

And for all, We have appointed heirs – from whatever the parents and near relatives leave behind; and to those with whom you have made an agreement, give them their dues; indeed all things are present before Allah.

# 527

Men are in charge of women, as Allah has made one of them superior to the other, and because men spend their wealth for the women; so virtuous women are the reverent ones, guarding behind their husbands the way Allah has decreed guarding; and the women from whom you fear disobedience, (at first) advise them and (then) do not cohabit with them, and (lastly) beat them; then if they obey you, do not seek to do injustice to them; indeed Allah is Supreme, Great.

# 528

And if you fear a dispute between husband and wife, send an arbitrator from the man’s family and an arbitrator from the woman’s family; if these two wish conciliation, Allah will unite them; indeed Allah is All Knowing, Well Aware.

# 529

And worship Allah and do not ascribe any partner to Him, and be good to parents, and to relatives, and orphans, and the needy, and the related neighbour and the unrelated neighbour, and the close companion and the traveller; and your bondwomen; indeed Allah does not like any boastful, proud person. –

# 530

Those who are misers and preach miserliness to others, and hide what Allah has bestowed upon them from His munificence; and We have kept ready a disgraceful punishment for the disbelievers.

# 531

And those who spend their wealth in order for people to see, and do not accept faith in Allah nor the Last Day; and whoever has Satan (the devil) as a companion – so what an evil companion is he!

# 532

And what would they lose, if they had believed in Allah and the Last Day and spent from what Allah has bestowed upon them? And Allah knows them very well.

# 533

Allah does not commit even the least injustice; and if there is a good deed, He doubles it and gives from Himself a great reward.

# 534

So how will it be when We bring a witness from each nation (religion), and We bring you (O dear Prophet Mohammed – peace and blessings be upon him) as a witness and a watcher over them? (The Holy Prophet is a witness from Allah.)

# 535

On that day, those who disbelieved and disobeyed the Noble Messenger will wish that they be buried and the ground levelled above them; and they will not be able to hide anything from Allah.

# 536

O People who Believe! Do not approach the prayer when you are intoxicated until you have the sense to understand what you say, nor in the state of impurity until you have bathed except while travelling; and if you are ill or on a journey or one of you returns from answering the call of nature or you have cohabited with women, and you do not find water, then cleanse (yourself) with clean soil – therefore stroke your faces and your hands with it; indeed Allah is Most Pardoning, Oft Forgiving.

# 537

Did you not see those who received a portion of the Book, that they purchase error and wish that you too go astray from the right path?

# 538

Allah well knows your enemies; Allah is Sufficient as a Guardian, and Allah is Sufficient as a Supporter.

# 539

Some of the Jews interchange the words from their places and say, “We hear and disobey” – and they say “Hear- may you not be able to hear” – and they say “Raena (Be considerate towards us)” distorting it with their tongues and in order to slander religion; had they said, “We hear and we obey” and “Kindly listen to us, O dear Prophet,” and “Look mercifully upon us, O dear Prophet”, it would have been much better for them and more just – but Allah has cursed them for their disbelief; so they do not believe except a little.

# 540

O People given the Book(s)! Believe in what We have sent down confirming the Book which you possess, before We transform some faces so turning them towards their backs, or curse them like We had cursed the people of Sabth; and (know that) the Allah’s command is always carried out!

# 541

Undoubtedly Allah does not forgive (the sin of) disbelieving in Him and forgives anything lower than it to whomever He wills; and whoever ascribes partners to Allah has invented a tremendous sin.

# 542

Did you not see those who proclaim their piety (cleanliness of deeds)? In fact Allah purifies whomever He wills, and no injustice, even equal to the hair upon a date seed will be done to them.

# 543

See how they fabricate lies against Allah! And this is a sufficient manifest sin.

# 544

Did you not see those who received a portion of the Book, that they believe in idols and the devil, and say regarding the disbelievers that they are more rightly guided than the Muslims?

# 545

It is they whom Allah has cursed; and for those whom Allah has cursed, you (Prophet Mohammed – peace and blessings be upon him) will never find any supporter.

# 546

Do they have some share in the kingship?- if it were, they would not give to mankind even a single sesame.

# 547

Or do they envy people due to what Allah has given them from His grace? In that case, We bestowed the Book and the wisdom upon the family of Ibrahim (Abraham), and We gave them a great kingdom.

# 548

So some of them believed in it and some of them turned away from it; and sufficient is hell, a blazing fire!

# 549

We shall soon put those who disbelieve in Our signs into the fire; whenever their skins are cooked (fully burnt) We shall change them for new skins so they may taste the punishment (again and again); indeed Allah is Almighty, Wise.

# 550

And those who believed and did good deeds, We shall soon admit them into Gardens beneath which rivers flow – abiding in it forever; in it for them are pure wives – and We shall admit them into places of plentiful shade.

# 551

Indeed Allah commands you to hand over whatever you hold in trust, to their owners – and that whenever you judge between people, judge with fairness; undoubtedly Allah gives you an excellent advice; indeed Allah is All Hearing, All Seeing.

# 552

O People who Believe! Obey Allah and the Noble Messenger and those amongst you who are in authority; so if there is a dispute amongst you concerning any matter, refer it to Allah and the Noble Messenger (for judgement) if you believe in Allah and the Last Day; this is better and has the best outcome.

# 553

Did you not see those whose claim is that they believe in what has been sent down on you and what was sent down before you, and they then wish to make the devil their judge, whereas they were ordered to completely reject him? And the devil wishes to mislead them far astray.

# 554

And when they are told, “Come towards the Book sent down by Allah and to the Noble Messenger,” you will see that the hypocrites turn their faces away from you.

# 555

What will be their state, if some calamity befalls them as a result of what their own hands have sent before them – and then they come to you (O dear Prophet Mohammed – peace and blessings be upon him), swearing by Allah that, “Our goal was only to do good and create harmony"?

# 556

The secrets of their hearts are well known to Allah; so avoid them and explain to them, and speak to them clearly in their affairs.

# 557

And We did not send any Noble Messenger except that he be obeyed by Allah’s command; and if they, when they have wronged their own souls, come humbly to you (O dear Prophet Mohammed – peace and blessings be upon him) and seek forgiveness from Allah, and the Noble Messenger intercedes for them, they will certainly find Allah as the Most Acceptor Of Repentance, the Most Merciful.

# 558

So O dear Prophet (Mohammed – peace and blessings be upon him), by oath of your Lord, they will not be Muslims until they appoint you a judge for the disputes between them – and then whatever you have decided, they should not find opposition to it within their hearts, and they must accept it wholeheartedly.

# 559

And had We decreed for them to slay themselves or to leave their homes and families, only a few of them would have done it; and if they did what they are advised to, it would be good for them, and would have strengthened faith.

# 560

And were it so, We would bestow upon them a great reward from Ourselves.

# 561

And would certainly guide them to the Straight Path.

# 562

And whoever obeys Allah and His Noble Messenger, will be with those upon whom Allah has bestowed grace – that is, the Prophets and the truthful and the martyrs and the virtuous; and what excellent companions they are!

# 563

This is Allah’s munificence; and Allah is Sufficient, the All Knowing.

# 564

O People who Believe! Be cautious, then advance towards the enemy in small numbers or all together.

# 565

Indeed among you is one who will certainly loiter behind; then if some disaster were to befall you, he would say, “It was Allah’s grace upon me that I was not present with them!”

# 566

And were you to receive Allah’s munificence (a bounty), he would surely say – as if there had been no friendship between you and him – “Alas – if only I had been with them, I would have achieved a great success!”

# 567

So those who sell the life of this world for the Hereafter, must fight in Allah's cause; and We shall bestow a great reward upon whoever fights in Allah's cause, whether he is martyred or is victorious.

# 568

And what is the matter with you, that you should not fight in Allah’s cause and for the feeble men, and women, and children, who invoke, “Our Lord! Liberate us from this town, the people of which are unjust; and give us a protector from Yourself; and give us a supporter from Yourself.” (Allah has created many supporters for the believers.)

# 569

The believers fight for Allah’s cause; and the disbelievers fight for the devil’s cause – so fight against the friends of the devil; undoubtedly the devil’s conspiracy is weak.

# 570

Did you not see those to whom it was said, “Restrain your hands, keep the prayer established and pay the charity”; but when fighting was ordained for them, some of them started fearing people, the way they feared Allah – or even greater! And they said, “Our Lord! Why have You ordained fighting for us? If only You would have let us live some more!” Say (O dear Prophet Mohammed – peace and blessings be upon him), “The usage of this world is meagre; and the Hereafter is better for the pious; and you will not be wronged even (the weight of) a single thread.”

# 571

Death will come to you wherever you may be, even if you were in strong fortresses; if some good reaches them they say, “This is from Allah”; and if any misfortune reaches them, they say, “This is from you”; say, “Everything is from Allah”; what is wrong with these people, that they do not seem to understand anything?

# 572

Whatever good reaches you, O listeners, is from Allah, and whatever ill reaches you is from yourselves; and We have sent you (O dear Prophet Mohammed – peace and blessings be upon him) as a Noble Messenger towards all mankind; and Allah is Sufficient, as a Witness.

# 573

Whoever obeys the Noble Messenger has indeed obeyed Allah; and for those who turn away – We have not sent you as their saviour.

# 574

And they say, “We have obeyed”; and when they go away from you, a group of them spend the night conspiring against what they had said; and Allah records what they conspired by night; therefore O dear Prophet (Mohammed – peace and blessings be upon him) avoid them and rely upon Allah; and Allah is Sufficient as a Trustee (of affairs).

# 575

So do they not ponder about the Qur’an? And had it been from anyone besides Allah, they would certainly find much contradiction in it.

# 576

And when any news of safety or fear comes to them, they speak of it publicly; and had they referred it to the Noble Messenger and to those among them having authority, those among them who are able to infer would certainly learn the truth of the matter from them; and were it not for Allah’s munificence upon you, and His mercy, all of you would have certainly followed Satan – except a few.

# 577

Therefore O dear Prophet, fight in Allah's cause; you will not be burdened except for yourself, and urge the believers (to fight); it is likely that Allah will curb the strength of the disbelievers; and Allah's strike is most stinging and His punishment the most severe.

# 578

Whoever makes a noble intercession will have a share of it, and whoever makes an evil intercession will have a share of it; and Allah is Able to do all things.

# 579

And when you are greeted with some words, greet back with words better than it or with the same; indeed Allah will take account of everything.

# 580

Allah! There is none worthy of worship except Him; He will surely gather you all on the Day of Resurrection in which there is no doubt; and whose Words are more true than those of Allah? (Allah does not lie.)

# 581

So what is the matter with you that you got divided into two groups concerning the hypocrites, whereas Allah has inverted them because of their misdeeds? Do you wish to guide one whom Allah has sent astray? And for one whom Allah sends astray, you will not find a way.

# 582

They wish that you too should turn disbelievers the way they did, so that you all may become equal – so do not befriend any of them until they forsake their homes and families in Allah’s cause; then if they turn back, seize them and kill them wherever you find them; and do not take any of them as a friend nor as a supporter.

# 583

Except those who are related to the people between whom and you is a treaty, or who come to you with their hearts no longer having the will to fight you or to fight their own people; had Allah willed, He would certainly have given them power over you so that they would have surely fought you; then if they avoid you and do not wage war against you and make an offer of peace – then Allah has not kept for you a way against them.

# 584

You will now find others who desire that they should be safe from you and also safe from their own people; whenever their people turn them towards war, they fall headlong into it; so if they do not avoid (confronting) you nor submit an offer of peace nor restrain their hands, seize them and kill them wherever you find them; and they are the ones against whom We have given you clear authority.

# 585

It is not rightful for a Muslim to kill another Muslim, unless it occurs by mistake; and the one who mistakenly kills a Muslim must set free a Muslim slave and pay blood-money to the family of the slain, except if they forego it; and if the victim is of a people who are hostile to you, and the killer is a Muslim, then only the setting free of a Muslim slave (is obligatory); and if the victim is from a people between whom and you there is a treaty, then blood-money must be paid to his family and the setting free of a Muslim slave; therefore one who has no means must fast for two consecutive months; this is his penance before Allah; and Allah is All Knowing, Wise.

# 586

And whoever slays a Muslim on purpose, his reward will be hell – to remain in it for ages – and Allah has wreaked wrath upon him and has cursed him and kept prepared a terrible punishment for him.

# 587

O People who Believe! When you go forth to fight in holy war, make a proper study, and do not say to the one who greets you, “You are not a Muslim,” – you seek the means of this worldly life; so with Allah are the bounties in plenty; you too were like this before, then Allah bestowed His favour on you, therefore you must make a proper study; indeed Allah knows whatever you do.

# 588

The Muslims who stay back from holy war without proper excuse, are not equal to the Muslims who fight in Allah's cause with their wealth and lives; Allah has bestowed higher ranks to the warriors who strive with their wealth and lives, than those who stay back; and Allah has promised good to all; and Allah has favoured the warriors upon those who stay back, with a great reward.

# 589

Ranks (of honour) from Him, and forgiveness, and mercy; and Allah is Oft Forgiving, Most Merciful.

# 590

The angels ask the people whose souls they remove while they were wronging themselves, “What were you engaged in?” They reply, “We were powerless in the land”; the angels say, “Was Allah’s earth not spacious enough for you to have migrated in it?” The destination for such is hell; and a very wretched place to return.

# 591

Except those who were forcibly subdued among men, and the women and children, unable to devise a plan and unaware of the way.

# 592

So for such, it is likely that Allah will pardon them; and Allah is Most Pardoning, Oft Forgiving.

# 593

Whoever migrates for Allah's cause will find much shelter and abundant capacity in the earth; and whoever leaves his home, migrating towards Allah and His Noble Messenger, and death seizes him, his reward then lies entrusted with Allah; and Allah is Oft Forgiving, Most Merciful.

# 594

And when you travel in the land, it is no sin for you to curtail some of your obligatory prayers; if you fear that disbelievers may cause you harm; undoubtedly the disbelievers are open enemies to you.

# 595

And when you (O dear Prophet Mohammed – peace and blessings be upon him) are among them and lead them in prayer, only a group of them should be with you, and they must keep their weapons with them; so when they have performed their prostrations they should move away behind you; and the other group that had not prayed, must come and offer prayers in your leadership, keeping their guard and weapons with them; the disbelievers wish that you neglect your arms and your means so they may overpower you with a single attack; it is no sin for you to lay aside your arms due to rain or if you are sick; and keep your guard; undoubtedly Allah has kept prepared a disgraceful punishment for the disbelievers.

# 596

So when you have offered your prayers remember Allah while standing, sitting and reclining; and when you feel secure, offer prayers in the usual manner; indeed prayers are a time bound obligatory duty upon the Muslims.

# 597

Do not relax in pursuit of the disbelievers; if you are suffering, they also suffer as you do; and you expect from Allah what they do not; and Allah is All Knowing, Wise.

# 598

We have indeed sent down the true Book towards you (O dear Prophet Mohammed – peace and blessings be upon him), so that you may judge between men, in the way Allah may show you; and do not plead on behalf of the treacherous.

# 599

And seek forgiveness from Allah; indeed Allah is Oft Forgiving, Most Merciful.

# 600

And do not plead on behalf of those who deceive themselves; indeed Allah does not like any treacherous, excessive sinner.

# 601

They hide from men and do not hide from Allah, whereas Allah is with them when they plan in their hearts that which displeases Him; and Allah has their deeds encompassed.

# 602

Pay heed! It is you people who argued on their behalf in the life of this world; so who will fight on their behalf with Allah on the Day of Resurrection, or who will be their pleader?

# 603

And whoever does evil or wrongs his own soul and then seeks forgiveness from Allah, will find Allah Oft Forgiving, Most Merciful.

# 604

And whoever earns sin, his earnings will only be against himself; and Allah is the Knowing, Wise.

# 605

And whoever commits a mistake or a sin, then blames it on someone innocent has indeed burdened himself with infamy and a manifest crime.

# 606

And O dear Prophet, were it not for Allah’s munificence and His mercy upon you, a group among them would have wished to deceive you; and they only mislead themselves and will not harm you at all; and Allah has sent down upon you the Book and wisdom, and taught you all what you did not know\*; and upon you is Allah’s great munificence. (Allah gave the knowledge of the hidden to the Holy Prophet – peace and blessings be upon him.)

# 607

Most of their discussions do not contain any good, except of the one who enjoins charity or goodness or peace-making among people; whoever does that to seek the pleasure of Allah – We shall soon give him a great reward.

# 608

And whoever opposes the Noble Messenger after the right path has been made clear to him, and follows a way other than that of the Muslims, We shall leave him as he is, and put him in hell; and what a wretched place to return!

# 609

Allah does not forgive (the greatest sin) that partners be ascribed with Him – and He forgives all that is below (lesser sins) it, to whomever He wills; and whoever ascribes partners with Allah has indeed wandered far astray.

# 610

The polytheists do not worship Allah, except some females; and they do not worship anyone except the rebellious Satan.

# 611

The one whom Allah has cursed; and the devil said, “I swear, I will certainly take an appointed portion of Your bondmen,” –

# 612

“And I will surely lead them astray, and I will certainly arouse desires in them, and I will definitely order them so they will pierce animals’ ears, and I will definitely order them so they will alter Allah’s creation”; and whoever chooses the devil for a friend instead of Allah, has indeed suffered a manifest loss.

# 613

The devil promises them and arouses desires in them; and the devil does not give them promises except of deceit.

# 614

The destination for such is hell; they will not find any refuge from it.

# 615

And those who believed and did good deeds – We shall soon admit them into Gardens beneath which rivers flow, abiding in them for ever and ever; a true promise from Allah; and whose Words are more true than those of Allah? (Allah does not lie.)

# 616

The affair does not rest on your thoughts, nor the cravings of the People given the Book(s); whoever does wrong will get the recompense of it – and will not find, other than Allah, any friend or any supporter.

# 617

And whoever does some good deeds, be it a man or woman, and is a Muslim, will be admitted to Paradise and they will not be wronged even to the extent of one sesame.

# 618

And whose religion is better than one who submits his self to Allah and is virtuous and follows the religion of Ibrahim, who was far removed from all falsehood? And Allah made Ibrahim His close friend.

# 619

And to Allah only belongs all whatever is in the heavens and all whatever is in the earth; and Allah has control over all things.

# 620

And they ask you the decree concerning women; say, “Allah gives you a decree concerning them – and what is recited to you from the Qur’an concerning orphan girls, that you are not giving them which is ordained for them, and you are avoiding marrying them – and concerning the weak children, and that you must firmly establish justice in dealing with the orphans’ rights; and whatever good deeds you do, then Allah is Well Aware of it.”

# 621

And if a woman fears ill treatment from her husband or disinterest, so it is no sin for them if they reach an agreement of peace between themselves; and peace is better; and the heart is trapped in greed; and if you do good and practice piety, then Allah is Well Aware of it.

# 622

And you will never be able to deal equally between women however much you may desire – therefore do not be totally inclined towards one leaving the other in uncertainty; and if you do good and practice piety, then (know that) Allah is Oft Forgiving, Most Merciful.

# 623

And if the two separate, Allah will make each one independent of the other, with His Capability; and Allah is Most Capable, Wise.

# 624

And to Allah only belongs all whatever is in the heavens and all whatever is in the earth; and indeed We have commanded those who received the Books before you, and commanded you, that keep fearing Allah; and if you disbelieve, undoubtedly to Allah only belongs all whatever is in the heavens and all whatever is in the earth; and Allah is Independent, Worthy Of All Praise.

# 625

And to Allah only belongs all whatever is in the heavens and all whatever is in the earth; and Allah is Sufficient as a Trustee (of affairs).

# 626

O people! He can remove you and bring others, if He wills; and Allah is Able to do that.

# 627

Whoever desires the reward of this world, then with Allah only lie both – the rewards of this world and of the Hereafter; and Allah is All Hearing, All Seeing.

# 628

O People who Believe! Be firm in establishing justice, giving witness for Allah, even if it is harmful to yourselves or parents or relatives; whether the one you testify against is wealthy or poor, for in any case Allah has the greater right over it; then do not follow your wishes for you may stray from the truth; and if you distort testimony or turn away, then Allah is Well Aware of your deeds.

# 629

O People who Believe! Have faith in Allah and His Noble Messenger and the Book He has sent down upon this Noble Messenger of His, and the Book He sent down before; and whoever does not accept faith in Allah and His angels and His Books and His Noble Messengers and the Last Day, has undoubtedly wandered far astray.

# 630

Indeed those who believe, then disbelieve and then again believe, then again disbelieve, and go further in their disbelief – Allah will never forgive them, nor ever guide them to the path.

# 631

Give glad tidings to the hypocrites, that for them is a painful punishment.

# 632

Those who leave the Muslims to befriend the disbelievers; do they seek honour from them? Then (know that) undoubtedly all honour is for Allah.

# 633

And indeed Allah has sent down to you in the Book that whenever you hear the signs of Allah being rejected or being made fun of, do not sit with those people, until they engage in some other conversation; or else you too are like them; undoubtedly Allah will gather the hypocrites and the disbelievers, all together, into hell.

# 634

Those who keep watching your circumstances; so if a victory comes to you from Allah, they say, “Were we not with you?”; and if victory is for disbelievers, they say, “Did we not have control over you, and protect you from the Muslims?” Allah will judge between you all on the Day of Resurrection; and Allah will not provide the disbelievers any way over the Muslims.

# 635

Undoubtedly the hypocrites, in their fancy, seek to deceive Allah whereas He will extinguish them while making them oblivious; and when they stand up for prayer, they do it unwillingly and for others to see, and they do not remember Allah except a little.

# 636

Fluctuating in the middle; neither here (in faith) nor there (in disbelief); and for one whom Allah sends astray, you will not find a way.

# 637

O People who Believe! Do not befriend disbelievers in place of Muslims; do you wish to give Allah a clear proof against you?

# 638

Undoubtedly the hypocrites are in the deepest segment of hell; and you will never find any supporter for them.

# 639

Except those who repented and reformed themselves and held fast to Allah’s rope and made their religion sincerely only for Allah – so they are with the Muslims; and Allah will soon bestow upon the believers a great reward.

# 640

And what will Allah gain by punishing you, if you acknowledge the truth and accept faith? And Allah is Most Appreciative, All Knowing.

# 641

Allah does not like disclosure of evil matters except by the oppressed; and Allah is All Hearing, All Knowing.

# 642

If you do any good openly or in secret, or pardon someone’s evil – then indeed Allah is Oft Forgiving, Able.

# 643

Those who disbelieve in Allah and His Noble Messengers, and seek to cause division between Allah and His Noble Messengers, and say, “We believe in some and disbelieve in others,” and wish to choose a way between faith and disbelief; –

# 644

These are the real disbelievers; and for the disbelievers We have kept prepared a disgraceful punishment.

# 645

And those who believe in Allah and all His Noble Messengers and do not make any distinction in belief between any of them – to them Allah will soon give them their reward; and Allah is Oft Forgiving, Most Merciful.

# 646

O dear Prophet (Mohammed – peace and blessings be upon him) the People given the Book(s) ask you, to cause a Book to be sent down on them from heaven – so they had asked something even greater from Moosa, for they said, “Show Allah to us, clearly” – so the thunder seized them on account of their sins; then they chose the calf (for worship) after clear signs had come to them, then We forgave this; and We bestowed Moosa with a clear dominance.

# 647

We then raised the mount (Sinai) above them to take a covenant from them and decreed them that, “Enter the gate while prostrating” and decreed them that, “Do not cross the limits of the Sabbath,” and We took from them a firm covenant.

# 648

So Allah cursed them because of their constantly breaking their covenant – and they disbelieved in the signs of Allah, and they used to wrongfully martyr the Prophets, and because they said, “Our hearts are covered”; in fact Allah has set a seal upon their hearts due to their disbelief, so that they do not accept faith, except a few.

# 649

And because they disbelieved and slandered Maryam with a tremendous accusation.

# 650

And because they said, “We have killed the Messiah, Eisa the son of Maryam, the Messenger of Allah”; they did not slay him nor did they crucify him, but a look-alike was created for them; and those who disagree concerning it are in doubt about it; they know nothing of it, except the following of assumptions; and without doubt, they did not kill him.

# 651

In fact Allah raised him towards Himself; and Allah is Almighty, Wise.

# 652

There is not one of the People given the Book(s), who will not believe in him (Eisa) before his death; and on the Day of Resurrection he will be a witness against them.

# 653

So due to the great injustices committed by the Jews, We forbade them some of the good things which were earlier lawful for them, and because they prevented many people from Allah’s way.

# 654

And because they used to take usury whereas they were forbidden from it, and they used to wrongfully devour people’s wealth; and for the disbelievers among them, We have kept prepared a painful punishment.

# 655

But those among them who are firm in knowledge and who have faith, believe in what is sent down upon you (O dear Prophet Mohammed – peace and blessings be upon him), and what was sent down before you, and those who keep the prayer established and those who pay the charity, and those who believe in Allah and the Last Day; to such, We shall soon bestow a great reward.

# 656

Indeed We sent a divine revelation to you (Prophet Mohammed – peace and blessing be upon him) as We did send divine revelations to Nooh (Noah) and the Prophets after him; and We sent divine revelations to Ibrahim (Abraham) and Ismael (Ishmael) and Ishaq (Isaac) and Yaqub (Jacob) and their offspring, and Eisa (Jesus) and Ayyub (Job) and Yunus (Jonah) and Haroon (Aaron) and Sulaiman (Solomon), and We bestowed the Zaboor (the Holy Book) upon Dawud (David).

# 657

And to the Noble Messengers whom We have mentioned to you before, and to the Noble Messengers We have not mentioned to you; and Allah really did speak to Moosa.

# 658

Noble Messengers giving glad tidings and declaring warnings, in order that people may not have any argument against Allah, after the (advent of) Noble Messengers; and Allah is Almighty, Wise.

# 659

But Allah is the Witness of what He has sent down upon you – He has sent it down by His knowledge; and the angels are witnesses; and sufficient is Allah’s testimony.

# 660

Indeed those who disbelieved and prevented (others) from the way of Allah, have undoubtedly wandered far astray.

# 661

Indeed those who disbelieved and crossed the limits – Allah will never forgive them, nor guide them to a way.

# 662

Except the path of hell, in which they will remain for ever and ever; and that is easy for Allah.

# 663

O mankind! This Noble Messenger (Prophet Mohammed – peace and blessings be upon him) has come to you with the truth from your Lord, so accept faith for your own good; and if you disbelieve, then undoubtedly to Allah only belongs all whatever is in the heavens and in the earth; and Allah is All Knowing, Wise.

# 664

O People given the Book(s)! Do not exaggerate in your religion nor say anything concerning Allah, but the truth; the Messiah, Eisa the son of Maryam, is purely a Noble Messenger of Allah, and His Word; which He sent towards Maryam, and a Spirit from Him; so believe in Allah and His Noble Messengers; and do not say “Three”; desist, for your own good; undoubtedly Allah is the only One God; Purity is to Him from begetting a child; to Him only belongs all whatever is in the heavens and all whatever is in the earth; and Allah is a Sufficient Trustee (of affairs).

# 665

The Messiah does not at all hate being a bondman of Allah, and nor do the close angels; and whoever hates worshipping Him and is conceited – so very soon He will gather them all towards Him.

# 666

Then to those who believed and did good deeds, He will pay their wages in full and by His munificence, give them more; and to those who hated (worshipping Him) and were proud, He will inflict a painful punishment; and they will not find for themselves, other than Allah, any supporter nor any aide.

# 667

O mankind! Indeed the clear proof from your Lord has come to you, and We have sent down to you a bright light. (The Holy Prophet is a Clear Proof from Allah.)

# 668

So those who believed in Allah and held fast to His rope – He will admit them into His mercy and munificence, and will guide them on the Straight Path towards Himself.

# 669

O dear Prophet (Mohammed – peace and blessings be upon him), they ask you for a decree; say, “Allah decrees you concerning the solitary person (without parents or children); if a man dies childless and has a sister, for her is half the inheritance; and the man is his sister’s heir if the sister dies childless; and if there are two sisters, for them is two-thirds of the inheritance; so if there are brothers and sisters, both men and women, the male’s share is equal to that of two females; and Allah explains clearly to you, so that you do not go astray; and Allah knows all things.”

# 670

O People who Believe! Fulfil your words (agreements); the mute animals are made lawful for you (to eat) except what will be declared to you after this, but do not assume hunting as lawful when you are on the pilgrimage; indeed Allah commands whatever He wills.

# 671

O People who Believe! Do not make lawful the symbols of Allah nor the sacred months nor the sacrificial animals sent to Sacred Territory (around Mecca) nor the animals marked with garlands, nor the lives and wealth of those travelling towards the Sacred House (Kaa’bah) seeking the munificence and pleasure of their Lord; and when you have completed the pilgrimage, you may hunt; and let not the enmity of the people who had stopped you from going to the Sacred Mosque tempt you to do injustice; and help one another in righteousness and piety – and do not help one another in sin and injustice – and keep fearing Allah; indeed Allah’s punishment is severe.

# 672

Forbidden for you are carrion, and blood, and flesh of swine, and that which has been slaughtered while proclaiming the name of any other than Allah, and one killed by strangling, and one killed with blunt weapons, and one which died by falling, and that which was gored by the horns of some animal, and one eaten by a wild beast, except those whom you slaughter; and (also forbidden is) that which is slaughtered at the altar (of idols) and that which is distributed by the throwing of arrows (as an omen); this is an act of sin; this day, the disbelievers are in despair concerning your religion, so do not fear them and fear Me; this day have I perfected your religion for you\* and completed My favour upon you, and have chosen Islam as your religion; so whoever is forced by intense hunger and thirst and does not incline towards sin, then indeed Allah is Oft Forgiving, Most Merciful. (\*Prophet Mohammed – peace and blessings be upon him – is the Last Prophet.)

# 673

They ask you (O dear Prophet Mohammed – peace and blessings be upon him) what is made lawful for them; say, “Pure things are made lawful for you, and the beasts (and birds) of prey which you have trained and use for hunting, (and) you teach them what Allah has taught you; so eat what they kill and leave for you, and mention Allah’s name upon it – and keep fearing Allah; indeed Allah is Swift At Taking Account.”

# 674

This day the pure things are made lawful for you; and the food of the People given the Book(s) is lawful for you – and your food is lawful for them – and likewise are the virtuous Muslim women and the virtuous women from the people who received the Book(s) before you when you give them their bridal money – marrying them, not committing adultery nor as mistresses; and whoever turns a disbeliever after being a Muslim, all his deeds are wasted and he will be among the losers in the Hereafter.

# 675

O People who Believe! When you wish to stand up for prayer, wash your faces, and your hands up to the elbows, and pass wet palms over your heads and wash your feet up to the ankles; and if you need a bath, clean yourselves thoroughly; and if you are sick or on a journey, or one of you returns from answering the call of nature, or you have cohabited with women, and you do not find water, then cleanse (yourself) with clean soil – therefore stroke your soiled palms over your faces and your hands with it; Allah does not will to place you in hardship, but He wills to fully purify you and complete His favour upon you, so that you may be grateful.

# 676

And remember Allah’s favour upon you and the covenant He took from you when you said, “We hear and we obey” – and fear Allah; indeed Allah knows what lies within the hearts.

# 677

O People who Believe! Firmly establish the commands of Allah, giving testimony with justice – and do not let the enmity of anyone tempt you not to do justice; be just; that is nearer to piety – and fear Allah; indeed Allah is Well Aware of your deeds.

# 678

It is Allah’s promise to those who believe and are righteous, that for them will be forgiveness and a great reward.

# 679

And those who disbelieve and deny Our signs – it is they who are the people of hell.

# 680

O People who Believe! Remember Allah’s favour upon you, when a people wished to extend their hands against you, so He restrained their hands from you; and keep fearing Allah; and Muslims must rely only upon Allah.

# 681

Undoubtedly Allah made a covenant with the Descendants of Israel, and We appointed twelve chiefs among them; and Allah said, “Indeed I am with you; surely, if you establish the prayer and pay the charity, and believe in My Noble Messengers and respect\* them, and lend an excellent loan to Allah, I will surely forgive your sins, and I will surely admit you into Gardens beneath which rivers flow; then after this, if any of you disbelieves, he has certainly gone astray from the Straight Path." (To honour the Holy Prophet – peace and blessings be upon him – is part of faith. To disrespect him is blasphemy.)

# 682

So We cursed them because of them constantly breaking their covenant, and hardened their hearts; they shift the Words of Allah from their places, and have forgotten a large portion of the advices that were given to them; and you will constantly learn of deceits from them, except a few; so forgive them and excuse them; indeed Allah loves the virtuous.

# 683

And We made a covenant with those who proclaimed, “We are Christians” – they then forgot a large portion of the advices given to them; We have therefore instilled enmity and hatred between them till the Day of Resurrection; and Allah will soon inform them of what they were doing.

# 684

O People given the Book(s)! Indeed this Noble Messenger (Prophet Mohammed – peace and blessings be upon him) of Ours has come to you, revealing to you a lot of the things which you had hidden in the Book, and forgiving a lot of them; indeed towards you has come a light\* from Allah, and a clear Book. (\* The Holy Prophet is a light from Allah).

# 685

With it, Allah guides whoever obeys the will of Allah to the paths of peace, and takes them out of darkness towards light by His command, and guides them to the Straight Path.

# 686

They have indeed become disbelievers who say, “Messiah, the son of Maryam is certainly Allah”; say, “Who can then do anything against Allah, if He wills to destroy the Messiah, the son of Maryam, and his mother and everyone on earth?” And for Allah only is the kingship of the heavens and the earth and all that is between them; He creates whatever He wills; and Allah is Able to do all things.

# 687

The Jews and the Christians said, “We are the sons of Allah and His beloved ones”; say, “Why does He then punish you for your sins? In fact you are human beings, part of His creation; He forgives whomever He wills, and punishes whomever He wills; and for Allah only is the kingship of the heavens and the earth and all that is between them – and towards Him is the return.”

# 688

O People given the Book(s)! Indeed this Noble Messenger (Prophet Mohammed – peace and blessings be upon him) of Ours has come to you, revealing to you Our commands, after the Noble Messengers had stopped arriving for ages, for you might claim, “Never did any Harbinger of Glad Tidings or Herald of Warning come to us” – so this Harbinger of Glad Tidings and Herald of Warning has come to you; and Allah is Able to do all things.

# 689

And when Moosa said to his people, “O my people! Remember Allah’s favour upon you, that He created Prophets among you, and made you kings, and has now given you what He has not given to any one else in this world.”

# 690

“O my people! Enter the holy land which Allah has decreed for you and do not turn back, for you will turn back as losers.”

# 691

They said, “O Moosa! In it lives a very strong nation – and we shall never enter it, until they have gone away from there; so when they have gone away from there, we will enter it.”

# 692

So two men who were among those who feared Allah and whom Allah had favoured said, “Enter upon them by force, through the gate; if you enter the gate, victory will be yours; and depend only upon Allah, if you have faith.”

# 693

They said, “O Moosa! We will never enter it whilst they are there, so you and your Lord go and fight – we shall remain seated here.”

# 694

Said Moosa, “My Lord! I have no control except over myself and my brother, so keep us separated from the disobedient nation.” (Do not count us among them).

# 695

Said Allah, “The (holy) land is therefore forbidden for them for forty years; they will wander in the earth; so do not grieve for these disobedient people.”

# 696

And recite to them the true tale of the two sons of Adam; when both of them offered a sacrifice each – hence the sacrifice of one was accepted and not accepted from the other; he (the other) said, “I swear I will kill you”; he answered, “Allah accepts only from the pious.”

# 697

“Indeed, if you do extend your hand against me to kill me, I will not extend my hand against you to kill you; I fear Allah, the Lord Of The Creation.”

# 698

“I only desire that you alone should bear my sin and your own sin – hence you become of the people of hell; and that is the proper punishment of the unjust.”

# 699

So his soul incited him to kill his brother – he therefore killed him, and was therefore ruined.

# 700

So Allah sent a crow scratching the ground, to show him how to hide his brother’s corpse; he said, “Woe to me! I was not even capable enough to be like this crow, so I would hide my brother’s corpse”; and he turned remorseful.

# 701

For this reason; We decreed for the Descendants of Israel that whoever kills a human being except in lieu of killing or causing turmoil in the earth, so it shall be as if he had killed all mankind; and whoever saves the life of one person, is as if he had saved the life of all mankind; and undoubtedly Our Noble Messengers came to them with clear proofs – then after this indeed many of them are oppressors in the earth.

# 702

The only reward of those who make war upon Allah and His Noble Messenger and cause turmoil in the land is that they be all be killed or crucified, or their hands and feet cut off from alternate sides, or they be banished far away from the land; this is their degradation in the world, and for them in the Hereafter is a great punishment.

# 703

Except those who repent before you apprehend them; so know well that Allah is Oft Forgiving, Most Merciful.

# 704

O People who Believe! Fear Allah, and seek the means towards Him, and strive in His cause, in the hope of attaining success.

# 705

Indeed if the disbelievers owned all that is in the earth and a similar one in addition to it, and they offered it as a ransom to save themselves from the punishment of the Day of Resurrection, it would not be accepted from them; and for them is a painful punishment.

# 706

They will wish to come out of hell, and will not come out of it – and for them is an unending punishment.

# 707

And cut off the hands of those men or women who are thieves – a recompense of their deeds, a punishment from Allah; and Allah is Almighty, Wise.

# 708

So if one repents after his wrongdoing and reforms himself, Allah will incline towards him with His mercy; indeed Allah is Oft Forgiving, Most Merciful.

# 709

Do you not know that to Allah only belongs the kingship of the heavens and the earth? He punishes whomever He wills, and forgives whomever He wills; and Allah is Able to do all things.

# 710

O Noble Messenger (Prophet Mohammed – peace and blessings be upon him)! Do not let yourself be aggrieved by the people who rush towards disbelief – those who say with their mouths, “We believe” but whose hearts are not Muslims; and some Jews; they listen a great deal to falsehood, and to other people who do not come to you; shifting Allah’s Words from their correct places; and say, “If this command is given to you, obey it, but if this is not given to you, then refrain”; and the one whom Allah wills to send astray, you will never be able to help him in the least against Allah; they are those whose hearts Allah did not will to cleanse; for them is disgrace in this world, and for them is a great punishment in the Hereafter.

# 711

The excessively eager listeners of falsehood, extreme devourers of the forbidden; so if they come humbly to you (Prophet Mohammed – peace and blessings be upon him), judge between them or shun them; and if you turn away from them they cannot harm you at all; and if you do judge between them, judge with fairness; indeed Allah loves the equitable.

# 712

And why should they wish to be judged by you, when they have the Taurat with them, in which exist the commands of Allah and yet they turn away from it? And they will not accept faith.

# 713

Undoubtedly We sent down the Taurat, in which is guidance and light; the Jews were commanded according to it by Our obedient Prophets, and the rabbis and the religious jurists for they were commanded to protect Allah’s Book, and were witnesses to it; so do not fear men, and fear Me, and do not exchange My verses for an abject price; and whoever does not judge according to what is sent down by Allah – it is they who are disbelievers.

# 714

And in the Taurat, We made it obligatory upon them that, “A life (is the retribution) for a life, and an eye for an eye, and a nose for a nose, and an ear for an ear, and a tooth for a tooth, and for wounds is a retribution”; then whoever willingly agrees to retribution, it shall redeem him of his sin; and whoever does not judge according to what is sent down by Allah – it is they who are the unjust.

# 715

And We brought Eisa the son of Maryam, following the footsteps of those Prophets, confirming the Taurat which preceded him – and We bestowed upon him the Injeel (Bible) in which is guidance and light, and confirms the Taurat which preceded it, and a guidance and an advice to the pious.

# 716

And the People of Injeel must judge by what Allah has sent down in it; and whoever does not judge according to what is sent down by Allah – it is they who are the sinners.

# 717

And O dear Prophet (Mohammed – peace and blessings be upon him) We have sent down the true Book upon you, confirming the Books preceding it, and a protector and witness over them – therefore judge between them according to what is sent down by Allah, and O listener, do not follow their desires, abandoning the truth which has come to you; We have appointed for you all, a separate (religious) law and a way; and had Allah willed He could have made you one nation, but the purpose (His will) is to test you by what He has given you, therefore seek to surpass one another in good deeds; towards Allah only you will all return, so He will inform you concerning the matter in which you disputed.

# 718

And therefore, O Muslims, judge between them according to what is sent down by Allah, and do not follow their desires, and be cautious of them so that they may not divert you from some commands which have been sent down to you; then if they turn away, know that Allah’s will is to punish them for some of their sins; and indeed many men are disobedient.

# 719

So do they wish a judgement of ignorance? And whose judgement is better than that of Allah, for the people who are certain?

# 720

O People who Believe! Do not make the Jews and the Christians your friends; they are friends of one another; and whoever among you befriends them, is one of them; indeed Allah does not guide the unjust.

# 721

You will now see those in whose hearts is a disease, that they rush towards the Jews and the Christians, saying, “We fear that a misfortune will possibly befall us”; so it is likely that Allah may soon bring victory, or a command from Himself, so they will remain regretting what they had hidden in their hearts.

# 722

And the believers say, “Are these the ones who swore by Allah most vehemently in their oaths, that they are with you?” All their deeds are destroyed, so they are ruined.

# 723

O People who Believe! Whoever among you reneges from his religion, so Allah will soon bring a people who are His beloved ones and Allah is their beloved, lenient with the Muslims and stern towards disbelievers – they will strive in Allah’s cause, and not fear the criticism of any accuser; this is Allah’s munificence, He may give to whomever He wills; and Allah is the Most Capable, the All Knowing.

# 724

You do not have any friends except Allah and His Noble Messenger and the believers who establish the prayer and pay the charity, and are bowed down before Allah.

# 725

And whoever takes Allah and His Noble Messenger and the Muslims as friends – so undoubtedly only the party of Allah is victorious.

# 726

O People who Believe! Those who have made your religion a mockery and a sport, and those who received the Book before you, and the disbelievers – do not befriend any of them; and keep fearing Allah, if you have faith.

# 727

And when you call to prayer, they mock and make fun of it; this is because they are people without any sense.

# 728

Say, “O People given the Book(s)! What do you dislike in us – except that we believe in Allah and what is sent down to us and what was sent down before, and because most of you are disobedient?”

# 729

Say, “Shall I tell you of those who are in a worse position than this, in Allah’s sight? It is those whom Allah has cursed and has wreaked His wrath upon and turned some of them into apes and swine, and worshippers of the devil; theirs is a worse destination and they have wandered further astray from the Straight Path.”

# 730

And when they come to you, they say, “We are Muslims” whereas they were disbelievers when they came in, and disbelievers when they went out; and Allah knows very well, what they hide.

# 731

And you will see many of them rushing towards sin and oppression, and to devour the forbidden; undoubtedly what they do is extremely evil.

# 732

Why do not their priests and monks forbid them from speaking evil and devouring the forbidden? Undoubtedly what they do is extremely evil.

# 733

And the Jews said, “Allah’s hand is tied"; may their hands be tied – and they are accursed for saying so! In fact, both His hands\* are free, He bestows upon whomever He wills; and O dear Prophet, this Book which has been sent down upon you from your Lord will cause many of them to advance in their rebellion and disbelief; and We have instilled enmity and hatred between them till the Day of Resurrection; whenever they ignite the flame of war, Allah extinguishes it, and they strive to create chaos in the land; and Allah does not love the mischievous. (\* This is a metaphor used to express Allah’s power).

# 734

If the People given the Book(s) had accepted faith and been pious, We would have certainly redeemed them of their sins and would have certainly taken them into serene Gardens.

# 735

And had they kept the Taurat and the Injeel established, and what was sent down towards them from their Lord, they would have received sustenance from above and from beneath their feet; among them is a group who is fair; but most of them commit extremely evil deeds.

# 736

O Noble Messenger (Prophet Mohammed – peace and blessings be upon him)! Convey all what has been sent down upon you from your Lord; and if you do not, then you have not conveyed any of His messages; and Allah will protect you from the people; indeed Allah does not guide the disbelievers.

# 737

Say, “O People given the Book(s)! You are nothing until you establish the Taurat and the Injeel, and what was sent down towards you from your Lord”; and this Book which has been sent down upon you from your Lord will cause many of them to advance in their rebellion and disbelief; so do not at all grieve for the disbelievers.

# 738

Indeed those who call themselves Muslims – and similarly among the Jews, and the Sabeans, and the Christians\* – whoever sincerely accepts faith in Allah and the Last Day, and does good deeds – so there shall be no fear upon them nor shall they grieve. (Whoever among them converts to Islam).

# 739

We made a covenant with the Descendants of Israel and sent Noble Messengers towards them; whenever a Noble Messenger came to them with whatever was not according to their own desires, they denied some of them and some they slew.

# 740

And they assumed that there will be no punishment, so they turned blind and deaf – then Allah accepted their penance, then again many of them turned blind and deaf; and Allah is seeing their deeds.

# 741

They are certainly disbelievers who say, “Allah is actually the Messiah, the son of Maryam”; whereas the Messiah had said, “O Descendants of Israel, worship Allah Who is my Lord and (also) your Lord”; undoubtedly whoever ascribes partners with Allah, then Allah has forbidden Paradise for him; his destination is hell; and the unjust do not have any supporters.

# 742

They are certainly disbelievers who say, “Indeed Allah is the third of the three Gods”; whereas there is no God except the One God; and if they do not desist from their speech, undoubtedly a painful punishment will reach those among them who die as disbelievers.

# 743

So why do they not incline towards Allah and seek His forgiveness? And Allah is Oft Forgiving, Most Merciful.

# 744

The Messiah, the son of Maryam, is purely a Noble Messenger; many Noble Messengers have passed before him; and his mother is a truthful woman; they both used to eat food; see how We make the signs clear for them, and see how they turn away!

# 745

Say (O dear Prophet Mohammed – peace and blessings be upon him), “What! You worship, other than Allah, that which is neither the controller of your losses nor of your benefits? And Allah only is the All Hearing, the All Knowing.”

# 746

Say, “O People given the Book(s)! Do not wrongfully commit injustice in your religion, and do not follow the people who earlier went astray, and led many others astray, and wandered away from the Straight Path.”

# 747

Those among the Descendants of Israel who turned disbelievers were cursed by the tongue of Dawud, and of Eisa the son of Maryam; it was because of their disobedience and their rebellion.

# 748

They did not restrain one another from the evil they used to do; undoubtedly they used to commit extremely evil deeds.

# 749

You will see that many of them make friends with the disbelievers; what an evil thing they had sent ahead for themselves, for Allah’s wrath came upon them and they will remain in the punishment, forever.

# 750

Had they believed in Allah and this Prophet (Mohammed – peace and blessings be upon him) and what is sent down upon him, they would not befriend the disbelievers, but most of them are disobedient.

# 751

You will certainly find the Jews and the polytheists as the greatest enemies of the Muslims; and you will find the closest in friendship to the Muslims those who said, “We are Christians”; that is because scholars and monks are among them, and they are not proud.

# 752

And when they listen to what has been sent down to the Noble Messenger (Prophet Mohammed – peace and blessings be upon him), you observe their eyes overflowing with tears because they have recognised the truth; they say, “Our Lord, we have accepted faith – therefore record us among the witnesses of the truth.”

# 753

“And what is the matter with us, that we should not believe in Allah and this truth which has come to us? And we hope that our Lord will admit us along with the righteous.”

# 754

So because of their saying, Allah bestowed them with Gardens beneath which rivers flow, in which they will abide forever; and this is the reward of the virtuous.

# 755

And those who disbelieved and denied Our signs, are the people of hell.

# 756

O People who Believe! Do not forbid the pure things, which Allah has made lawful for you, and do not cross the limits; indeed Allah dislikes the transgressors.

# 757

Eat of the sustenance which Allah has given you, the lawful and the pure – and fear Allah in Whom you believe.

# 758

Allah does not take you to task for oaths which are made unintentionally but He does take you to task for oaths which you ratify; so the redemption of such oaths is to provide food to ten needy persons equal to the average of what you feed your family, or to clothe them, or to free one slave; and for one who has no means, is the fasting for three days; this is the redemption of your oaths when you have sworn; and fulfil your oaths; this is how Allah explains His verses to you, so that you may be thankful.

# 759

O People who Believe! Wine (all intoxicants), and gambling, and idols, and the darts are impure – the works of Satan, therefore keep avoiding them so that you may succeed.

# 760

The devil only seeks to instil hatred and enmity between you with wine and gambling, and to prevent you from the remembrance of Allah and from prayer; so have you desisted?

# 761

And obey Allah and obey the Noble Messenger, and be cautious; then if you turn away, so know that the duty of Our Noble Messenger is only to plainly convey the message.

# 762

Upon those who accepted faith and did good deeds, there shall be no sin for whatever they have consumed in the past, provided they fear and continue to believe and do good deeds, then again fear and continue to believe, and then again fear and remain virtuous; and Allah loves the virtuous.

# 763

O People who Believe! Allah will surely test you with some prey that is within reach of your hands and your spears, so that Allah may make known those who fear Him without seeing; so henceforth, a painful punishment is for anyone who transgresses.

# 764

O People who Believe! Do not kill prey while you are on the pilgrimage; and whoever among you kills it intentionally, so its recompense is that he shall give a similar domestic animal (for sacrifice), two honest men among you rendering the command, the sacrifice being brought to the Kaa’bah – or he gives as redemption, food for some needy persons, or fasts for the same number of days, so that he may taste the consequences of his deed; Allah has forgiven what has passed; and henceforth whoever does it, Allah will take recompense from him; and Allah is Almighty, Avenger.

# 765

It is lawful for you to hunt from the sea and to eat from it, for your benefit and that of the travellers; and hunting on land is forbidden for you while you are on the pilgrimage; and fear Allah, towards Whom you will arise.

# 766

Allah has made the Kaa’bah, the respected house, a cause for peoples survival, and the Sacred Month, and the sacrifices in the holy land, and the garlanded animals; this is so that you may be convinced that Allah knows all whatever is in the heavens and all whatever is in the earth, and that Allah is the All Knowing.

# 767

Know well that Allah’s punishment is severe, and that Allah is Oft Forgiving, Most Merciful.

# 768

There is no duty upon the Noble Messenger except to convey the command; and Allah knows all what you disclose and all what you hide.

# 769

Say, “The impure (evil) and the pure (good) are not equal, even though the abundance of the impure may attract you; therefore keep fearing Allah, O men of intellect, so that you may succeed.”

# 770

O People who Believe! Do not ask about matters which, if disclosed to you, would be disliked by you; and if you ask about them while the Qur’an is being sent down, they will be disclosed to you; Allah has forgiven these; and Allah is Oft Forgiving, Most Forbearing.

# 771

A nation before you asked about such matters and then disbelieved in them.

# 772

Allah has not appointed (commanded to sacrifice) the camel with ears sliced (Bahira) or the she-camel (Saibah) or the she-goat (Wasilah) or the breeding camel (Hami), but the disbelievers fabricate lies against Allah; and most of them do not have any sense at all.

# 773

And when it is said to them, “Come towards what Allah has sent down and towards the Noble Messenger”, they say, “Sufficient for us is what we found our forefathers upon”; even if their forefathers did not have knowledge nor had guidance?

# 774

O People who Believe! Fear for your own souls; he who has strayed cannot harm you in the least if you are on guidance; towards Allah only you will all return – He will then inform you of what you used to do.

# 775

O People who Believe! The witnesses between you when death approaches any one of you, at the time of making a will, should be two reliable men from among you, or two from another tribe in case you are travelling in the land and the event of death approaches you; engage them after the prayers, and if you doubt, they must swear by Allah that, “We shall not exchange our oaths for any price even if he is a near relative, nor will we hide the testimony of Allah – if we do, then surely we are of the sinners.”

# 776

Then if it is later known that both of them committed sin, two others may take their place, from those who were caused the most harm by the false testimony, and they must swear by Allah that, “Our testimony is more accurate than the testimony of these two, and we have not exceeded the limits – if we do, then surely we shall be of the unjust.”

# 777

This is more suitable than their bearing testimony as they wish or fear that some oaths may be made void, after their taking oath; so fear Allah and heed the commands; and Allah does not guide the disobedient.

# 778

On the day when Allah will gather all the Noble Messengers, and then say, “What response did you get?” They will submit, “We do not have any knowledge; indeed it is only You, Who knows all the hidden.”

# 779

When Allah will say, “O Eisa, the son of Maryam! Remember My favour upon you and your mother; when I supported you with the Holy Spirit; you were speaking to people from the cradle and in maturity; and when I taught you the Book and wisdom and the Taurat and the Injeel; and when you used to mould a birdlike sculpture from clay, by My command, and blow into it – so it (the living bird) used to fly by My command, and you used to cure him who was born blind and cure the leper, by My command; and when you used to raise up the dead, by My command; and when I restrained the Descendants of Israel against you when you came to them with clear proofs, and the disbelievers among them said, ‘This is nothing but clear magic’.”

# 780

“And when I inspired into the hearts of the disciples that, ‘Believe in Me and in My Noble Messenger’; they said, ‘We accept faith, and be witness that we are Muslims.’”

# 781

When the disciples said, “O Eisa, the son of Maryam! Will your Lord send down a table spread (with food) for us from heaven?” He said, “Fear Allah, if you are believers.”

# 782

They said, “We wish to eat from it and so that our hearts be convinced and to see that you have spoken the truth to us, and that we may be witnesses upon it.”

# 783

Eisa, the son of Maryam, said, “O Allah, O our Lord! Send down to us a table spread from heaven, so that it may become a day of celebration for us – for our former and latter people – and a sign from You; and give us sustenance – and You are the Best Provider Of Sustenance.”

# 784

Said Allah, “Indeed I shall send it down to you; so thereafter whoever disbelieves amongst you – I will surely mete out to him a punishment with which I shall not punish anyone else in the whole world.”

# 785

And when Allah will say, “O Eisa, the son of Maryam! Did you say to the people, ‘Appoint me and my mother as two Gods, besides Allah’?” He will submit, “Purity is to You! It is not proper for me to say something for which I do not have a right; if I have said it, then surely You know it; You know what lies in my heart, and I do not know what is in Your knowledge; indeed You only know all the hidden.”

# 786

“I have not told them except what You commanded me, that ‘Worship Allah, Who is my Lord and is also your Lord’; I was aware of them till I was among them; and when You raised me, only You watched over them; and all things are present before You.”

# 787

“If you punish them, then indeed they are Your slaves; and if you forgive them, then indeed You only are the Almighty, the Wise.”

# 788

Proclaimed Allah, “This is a day on which the truthful will benefit from their truthfulness; for them are Gardens beneath which rivers flow, in which they will abide for ever and ever; Allah is pleased with them and they are pleased with Allah; this is the greatest success.”

# 789

To Allah only belongs the kingship of the heavens and the earth and all that is in them: and He is Able to do all things.

# 790

All praise is to Allah, Who has created the heavens and the earth, and has created darkness and light; yet the disbelievers appoint equals (false deities) to their Lord!

# 791

It is He Who has created you from clay, and then decreed a term for you; and it is a fixed promise before Him, yet you still doubt!

# 792

And He is Allah (the God) of the heavens and in the earth; He knows all, your secrets and your disclosures, and He knows your deeds.

# 793

And never does a sign come to them from among the signs of Allah, except that they\* turn away from it. (\* The disbelievers)

# 794

So indeed they denied the truth\* when it came to them; so now the tidings of the thing they used to mock at, will come to them. (Prophet Mohammed -peace and blessings be upon him, or the Holy Qur’an).

# 795

Do they not see how many civilisations We destroyed before them, whom We had established more firmly in the earth than We have established you, and We sent on them abundant rain from the sky, and made the rivers flow beneath them? So we destroyed them because of their sins, and created another civilisation after them.

# 796

And had We sent down to you (O dear Prophet Mohammed – peace and blessings be upon him) something written on paper so that they could feel it with their hands, even then the disbelievers would have said, “This is nothing but clear magic.”

# 797

And they said, “Why has not an angel been sent down to him?” And had We sent down an angel, then the matter would have been finished, and they would not get any respite.

# 798

And had we appointed an angel as a Prophet, We would still have made him as a man and would keep them in the same doubt, as they are now in.

# 799

And certainly, O dear Prophet (Mohammed – peace and blessings be upon him) the Noble Messengers before you have also been mocked at, so those who laughed at them were themselves ruined by their own mocking.

# 800

Proclaim, “Travel in the land, and see what sort of fate befell those who denied.”

# 801

Say, “To Whom does all whatever is in the heavens and the earth, belong?” Proclaim, “To Allah”; He has made mercy obligatory upon His grace; undoubtedly, He will surely gather you all together on the Day of Resurrection in which there is no doubt; those who put their souls to ruin, do not accept faith.

# 802

And to Him only belongs all whatever exists in the night and in the day; and He only is the All Hearing, the All Knowing.

# 803

Say, “Shall I choose as a supporter someone other than Allah, Who is the Originator of the heavens and the earth and Who feeds and does not need to eat?” Say, “I have been ordered to be the first to submit myself (to Him), and O people, do not be of the polytheists.”

# 804

Say, “If I disobey my Lord, I then fear the punishment of the Great Day (of Resurrection).”

# 805

Indeed Allah’s mercy has been upon him, from whom the punishment has been averted on that Day; and this is the clear success.

# 806

And if Allah afflicts you with some misfortune, then there is none who can remove it, except Him; and if He sends you some good fortune, then (know that) He is Able to do all things.

# 807

He is the Omnipotent over His bondmen; and He is the Wise, the Aware.

# 808

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Whose testimony is the greatest?” Say, “Allah is the Witness between me and you; and this Qur’an has been sent down upon me, so I may warn you with it and whomever it may reach; so do you bear witness that there are other Gods along with Allah?” Say, “I do not bear witness to it”; Say, “He is the only One God and I do not have any relation with whatever you ascribe as partners (to Him).”

# 809

The people to whom We gave the Book(s) recognise this Prophet (Mohammed – peace and blessings be upon him) as they recognise their own sons; those who put their own souls to ruin, do not accept faith.

# 810

And who is more unjust than one who fabricates lies against Allah or denies His signs? Undoubtedly, the unjust will never succeed.

# 811

And on the day when We will resurrect everyone together, then say to the polytheists, “Where are those partners (your false deities) whom you professed?”

# 812

Then they had no fabrication except that they said, “By Allah, our Lord, we were never polytheists!”

# 813

Observe how they lied against themselves, and how they lost the things they fabricated!

# 814

And among them is one who listens to you; and We have put covers upon their hearts so they may not understand it, and deafness in their ears; and (even) if they see all the signs, they will not believe in them; to the extent that when they come to you to debate with you, the disbelievers say, “This is nothing but stories of former people.”

# 815

And they stop (others) from it and run away from it; and they ruin none except themselves, and they do not have sense.

# 816

And if you see them when they will be placed above hell, they will say, “Alas, if only we might be sent back and not deny the signs of our Lord, and become Muslims!”

# 817

In fact it has become clear to them what they used to hide before; and were they to be sent back, they would commit the same which they were forbidden to, and undoubtedly they are liars.

# 818

And they said, “There is no other life except our life of this world, and we are not to be raised.”

# 819

And if you see when they are placed before their Lord, He will say, “Is this not real (the truth)? They will say, “Yes – why not, by our Lord!” He will say, “So now taste the punishment – the recompense of your disbelief.”

# 820

Those who denied their meeting with Allah, have indeed failed; to the extent that when the Last Day suddenly came upon them they said, “Woe to us that we failed to believe in it” – and they carry their burdens on their backs; what an evil burden they carry!

# 821

The life of this world is nothing except a pastime and sport; and undoubtedly the abode of the Hereafter is better for the pious; so do you not have sense?

# 822

We know well that their statement grieves you – so they do not deny you (Prophet Mohammed – peace and blessings be upon him) but in fact the unjust deny the signs of Allah.

# 823

And indeed Noble Messengers have been denied before you, so they patiently bore the denial and torture till Our help reached them; and there is none to alter the decisions of Allah; and the news of the Noble Messengers have already reached you.

# 824

And if their turning away has grieved you, then if you can, seek a tunnel into the earth or a ladder into the sky to bring a sign for them; and if Allah willed, He could have brought them all together upon guidance, so O listener (followers of this Prophet) do not ever be of the ignorant.

# 825

It is only those who hear (with sincere hearts) that accept faith; and Allah will raise these people dead of heart, then towards Him they will be herded.

# 826

And they said, “Why has no sign been sent down upon him from his Lord?” Say, “Indeed Allah is Able to send down a sign”, but most of them are totally ignorant.

# 827

And there is not an animal moving in the earth nor a bird flying on its wings, but they are a nation like you; We have left out nothing in this Book – then towards their Lord they will be raised.

# 828

And those who deny Our signs are deaf and dumb in realms of darkness; Allah may send astray whomever He wills; and may place on the Straight Path whomever He wills.

# 829

Say, “What is your opinion – if the punishment of Allah comes upon you or the Hour arrives, will you call upon anyone (deity) besides Allah; if you are truthful?”

# 830

“In fact you will only call upon Him, and if He wills, He may remove that because of which you prayed to Him, and you will forget the partners (you ascribe to Him).”

# 831

And We have indeed sent Noble Messengers towards the nations that were before you – We therefore seized them with hardship and adversity so that, in some way, they may humbly plead.

# 832

So why did they not humbly plead when Our punishment came to them? But their hearts were hardened and the devil made all their deeds appear good to them!

# 833

So when they forgot the advices made to them, We opened the gates of all things for them; to the extent that when they were rejoicing for what they had received, We seized them suddenly, hence they remained dejected.

# 834

The origins of the unjust people were therefore cut off; and all praise is to Allah, Lord Of The Creation.

# 835

Say, “What is your opinion – if Allah were to take away your hearing and your sight and seal your hearts, then is there a God besides Allah who could restore it for you?” Observe how We explain the verses to them, yet they turn away!

# 836

Say, “What is your opinion – if the punishment of Allah were to come upon you suddenly or openly (with forewarning), who would be destroyed except the disbelieving people?”

# 837

And We did not send Noble Messengers except as Heralds of glad tidings and warnings; so upon those who accept faith and reform themselves, shall be no fear nor shall they grieve.

# 838

And those who deny Our signs – the punishment will afflict them for their disobedience.

# 839

Say (O dear Prophet Mohammed – peace and blessings be upon him), “I do not say to you that I possess the treasures of Allah, nor do I say that I gain knowledge of the hidden on my own, nor do I say to you that I am an angel; I only follow what is divinely revealed to me”; say, “Will the blind and the sighted ever be equal? So do you not think?”

# 840

And with this Qur’an warn those who fear, that they will be raised towards their Lord in a state when, except Allah, there will be no protector for them nor an intercessor, so that they may be pious.

# 841

And do not repel those who call upon their Lord in the morning and evening, seeking His pleasure; you are not responsible for their account nor are they responsible for your account – then your repelling them would be far from justice.

# 842

And similarly We have made some as a trial for others – that the wealthy disbelievers upon seeing the needy Muslims say, “Are these whom Allah has favoured among us?” Does not Allah recognise those who are thankful?

# 843

And when those who believe in Our signs come humbly in your presence, say to them, “Peace be upon you – your Lord has prescribed mercy for Himself by His grace – that whoever among you commits a sin by folly and thereafter repents and reforms (himself), then indeed Allah is Oft Forgiving, Most Merciful.”

# 844

And this is how We explain Our verses clearly and so that the way of the criminals become well exposed.

# 845

Say, “I have been forbidden to worship those whom you worship other than Allah”; say, “I do not follow your desires – if it were, I would then go astray and not be on the right path.”

# 846

Say, “I am on the clear proof from my Lord, whereas you deny Him; I do not have what you are impatient for; there is no command except that of Allah; He states the truth and He is the Best of Judges."

# 847

Say, “If I had the thing for which you are impatient, then the matter between me and you would have already been decided”; and Allah is Well Aware of the unjust.

# 848

And it is He Who has the keys of the hidden – only He knows them; and He knows all that is in the land and the sea; and no leaf falls but He knows it – and there is not a grain in the darkness of the earth, nor anything wet or dry, which is not recorded in a clear Book.

# 849

And it is He Who removes your souls at night (while asleep) and knows whatever you commit by day; then He raises you again during the day, to complete the term appointed (for you); then it is to Him that you are to return – He will then inform you of what you used to do.

# 850

And He is Omnipotent over His bondmen and sends guardians over you; to the extent that when death comes to one of you, Our angels remove his soul, and they do not err.

# 851

They (the souls) are then returned towards their True Lord – Allah; pay heed! Only His is the command; and He is the Swiftest At Taking Account.

# 852

Say, “Who rescues you from the calamities of the land and the sea – Whom you call upon crying loudly and in whispers that, ‘If we are saved from this we will surely be grateful’?”

# 853

Say, “Allah delivers you from these and from all distresses – yet you ascribe partners to Him!”

# 854

Say, “He is Able to send punishment upon you from above you or from beneath your feet, or to cause you to fight each other by dividing you into different groups, and make you taste the harshness of one another”; observe how We explain the verses so that they may understand.

# 855

And your people (O dear Prophet Mohammed – peace and blessings be upon him) denied it whereas this is undoubtedly the truth; say, “I am not responsible for you.”

# 856

All matters have a fixed time and soon you will come to know.

# 857

And O listener (followers of this Prophet) when you see those who argue in Our verses, turn away from them until they engage in another topic; and if the devil causes you to forget, then do not sit with the unjust after remembering.

# 858

And the pious are not accountable for them in the least, apart from the giving of advice so that they may avoid.

# 859

And forsake those who have made their religion a mockery and play, and whom the worldly life has deceived – and advise them with this Qur’an so that a soul may not be seized for what it earns; other than Allah it will not have a protector nor an intercessor; and if it offers every recompense in exchange for itself, it will not be accepted from it; these are the ones who are seized for their own deeds; for them is boiling water to drink and a painful punishment, as a recompense of their disbelief. (The disbelievers will not have any intercessors.)

# 860

Say, “Shall we worship, other than Allah, that which neither benefits us nor harms us, and (therefore) be turned back after Allah has guided us, like one whom the devils have led astray in the earth – bewildered?; his companions call him to the path (saying), ‘Come here’”; say, “Indeed only the guidance of Allah is (the true) guidance; and we are commanded to submit to the Lord Of The Creation.”

# 861

“And to keep the (obligatory) prayer established and to fear Him; and it is to Him that you are to be raised.”

# 862

And it is He Who perfectly created the heavens and the earth; and when He will say “Be” on the Day (of resurrection) to all the extinct things, it will happen immediately; His Word is true; and it will be His kingship on the day when the Trumpet is blown; All Knowing of all the hidden and the revealed; and He only is the Wise, the Aware.

# 863

And remember when Ibrahim said to his father (paternal uncle) Azar, “What! You appoint idols as Gods? Indeed I find you and your people in open error.” (Prophet Ibrahim was rightly guided since birth).

# 864

And likewise We showed Ibrahim the entire kingdom of the heavens and the earth and so that he be of those who believe as eyewitnesses.

# 865

So when the night became dark upon him he saw a star; he said (to Azar / the people), “(You portray that) this is my Lord?”; then when it set he said, “I do not like the things that set.”

# 866

Then when he saw the moon shining, he said, “(You proclaim that) this is my Lord?”; then when it set, he said, “If my Lord had not guided me\*, I too would be one of these astray people.” (\* Prophet Ibrahim was rightly guided before this event).

# 867

Then when he saw the sun shining brightly, he said, “(You say that) this is my Lord? This is the biggest of them all!”; then when it set he said, “O people! I do not have any relation with the whatever you ascribe as partners (to Him).”

# 868

“I have directed my attention towards Him Who has created the heavens and the earth, am devoted solely to Him, and am not of the polytheists.”

# 869

And his people argued with him; he said, “What! You dispute with me concerning Allah? So He has guided me; and I do not have any fear of whatever you ascribe as partners, except what my Lord wills (to happen); my Lord’s knowledge encompasses all things; so will you not accept advice?”

# 870

“And how should I fear whatever you ascribe as partners, whilst you do not fear that you have ascribed partners to Allah – for which He has not sent down on you any proof? So which of the two groups has more right to refuge, if you know?”

# 871

Those who believed and did not mix it with injustice (disbelief), the refuge is only for them, and only they are on guidance.

# 872

And this is Our argument, which We gave Ibrahim against his people; We raise to high ranks whomever We will; indeed your Lord is Wise, All Knowing.

# 873

And We bestowed upon him Ishaq (Isaac) and Yaqub (Jacob); We guided all of them; and We guided Nooh before them and of his descendants, Dawud and Sulaiman and Ayyub and Yusuf and Moosa and Haroon; and this is the way We reward the virtuous.

# 874

And (We guided) Zakaria and Yahya (John) and Eisa and Elias; all these are worthy of Our proximity.

# 875

And Ismael (Ishmael) and Yasa’a (Elisha) and Yunus (Jonah) and Lut (Lot); and to each one during their times, We gave excellence over all others.

# 876

And some of their ancestors and their descendants and their brothers; and We chose them and guided them to the Straight Path.

# 877

This is the guidance of Allah, which He may give to whomever He wills among His bondmen; and had they ascribed partners (to Allah), their deeds would have been wasted.

# 878

These are the ones whom We gave the Book and the wisdom and the Prophethood; so if these people do not believe in it, We have then kept ready for it a nation who do not reject (the truth).

# 879

These are the ones whom Allah guided, so follow their guidance; say (O dear Prophet Mohammed – peace and blessings be upon him), “I do not ask from you any fee for the Qur’an; it is nothing but an advice to the entire world.”

# 880

And they (the Jews) did not realise (or appreciate) the importance of Allah as was required when they said, “Allah has not sent down anything upon any human being”; say, “Who has sent down the Book which Moosa brought, a light and guidance for mankind, which you have divided into different papers, some which you show and hide most of them? And (by which) you are taught what you did not know nor did your forefathers?” Say, “Allah” – then leave them playing in their indecency.

# 881

And this is the blessed Book which We have sent down, confirming the Books preceding it, and in order that you may warn the leader of all villages and all those around it in the entire world; and those who believe in the Hereafter accept faith in this Book, and guard their prayers.

# 882

Who is more unjust than one who fabricates lies against Allah or says, “I have received divine inspiration”, whereas he has not been inspired at all – and one who says, “I will now reveal something similar to what Allah has sent down”? And if you see when the unjust are in the throes of death and the angels are with their hands outstretched; (saying) “Surrender your souls; this day you shall be given a disgraceful punishment – the recompense of your fabricating lies against Allah, and your scorning His signs.”

# 883

“And indeed you (the disbelievers) have now come to Us alone as We had created you at first, and you have left behind you all the wealth and riches We had bestowed upon you; and We do not see your intercessors along with you, whom you claimed to possess a share in you; indeed the link between yourselves is cut off, and you have lost all what you contended.”

# 884

Indeed it is Allah Who splits the grain and the seed; it is He Who brings forth living from the dead, and it is He Who brings forth dead from the living; such is Allah; so where are you reverting?

# 885

It is He Who breaks dawn (by splitting the dark); and He has made the night a calmness, and the sun and the moon a count (for time); this is the command set by the Almighty, the All Knowing.

# 886

And it is He Who has created the stars for you, so that you may find your way by them in the darkness of the land and the sea; indeed We have explained Our verses in detail for the people of knowledge.

# 887

And it is He Who has created you from a single soul – then you have to stop over\* in one place and stay entrusted\*\* in another; indeed We have explained Our verses in detail for people of understanding. (\* This earth. \*\* The grave.)

# 888

And it is He Who sends down water from the sky; so with it We produced all things that grow; hence We produce from it vegetation from which We bring forth grains in clusters; and from the pollen of dates, dense bunches – and gardens of grapes and olives and pomegranates, similar in some ways and unlike in some; look at its fruit when it bears yield, and its ripening; indeed in it are signs for the people who believe.

# 889

And out of sheer ignorance they have ascribed jinns as partners of Allah, whereas it is He Who created them, and they have invented sons and daughters for Him! Purity and Supremacy is to Him, from all what they ascribe.

# 890

The Originator of the heavens and the earth; how can He possibly have a child when, in fact, He does not have a spouse? And He has created all things; and He knows everything.

# 891

Such is Allah, your Lord; and none is worthy of worship except Him; the Creator of all things – therefore worship Him; and He is the Trustee over all things.

# 892

Eyes do not encompass Him – and all eyes are within His domain\*; He is the Most Subtle, the Fully Aware. (\* control / knowledge)

# 893

“Enlightening proofs came to you from your Lord; so whoever observes, it is for his own good; and whoever is blind, it is for his own harm; and I am not a guardian over you.”

# 894

And this is how We explain Our verses in different ways that they (the disbelievers) may say to you, (O dear Prophet Mohammed – peace and blessings be upon him), “You have studied” – and to make it clear for the people of knowledge.

# 895

Follow what is divinely revealed to you from your Lord; there is none worthy of worship except Him; and turn away from the polytheists.

# 896

And if Allah willed, they would not ascribe (any partner to Him); We have not made you as a guardian over them; and you are not responsible for them.

# 897

Do not abuse those whom they worship besides Allah lest they become disrespectful towards Allah’s Majesty, through injustice and ignorance; likewise, in the eyes of every nation, We have made their deeds appear good – then towards their Lord they have to return and He will inform them of what they used to do.

# 898

And they swore by Allah vehemently in their oaths that if any sign came to them, they will certainly believe in it; say, “The signs are with Allah, and what do you people know that if they came to them, they will not believe.”

# 899

And We revert their hearts and their eyes – the way they had not believed the first time – and We leave them to keep wandering blindly in their rebellion.

# 900

And had We sent down the angels towards them, and had the dead spoken to them, and had We raised all things in front of them, they would still not have believed unless Allah willed – but most of them are totally ignorant.

# 901

And similarly We have appointed enemies for every Prophet – devils from men and jinns – one inspires the other with fabrications to deceive; and had your Lord willed they would not do so, therefore leave them with their fabrications.

# 902

And in order that the hearts of those who do not believe in the Hereafter may lean towards it and that they may like it, and earn the sins which they are to earn.

# 903

“So shall I seek the command other than that of Allah, whereas it is He Who has sent down the detailed Book towards you?” And those whom We gave the Book know that this is the truth sent down from your Lord, so O listener, (followers of this Prophet) do not ever be of those who doubt.

# 904

And the Word of your Lord is complete in truth and justice; there is none to change His Words; He is the All Hearing, the All Knowing.

# 905

And O listener, (followers of the Prophet) most of the people on earth are such that were you to obey them, they would mislead you from Allah’s way; they follow only assumptions and they only make guesses.

# 906

Your Lord well knows who has strayed from His way; and He well knows the people on guidance.

# 907

So eat from that over which Allah’s name has been mentioned, if you believe in His signs.

# 908

And what is the matter with you that you should not eat from that over which Allah’s name has been mentioned whereas He has explained in detail to you all what is forbidden to you except when you are forced (by circumstances) towards it? And indeed many lead astray by their own desires, out of ignorance; indeed your Lord well knows the transgressors.

# 909

And give up the open and hidden sins; those who earn sins will soon receive the punishment of their earnings.

# 910

And do not eat that on which Allah’s name has not been mentioned, and indeed that is disobedience; and undoubtedly the devils inspire in the hearts of their friends to fight with you; and if you obey them, you are then polytheists.

# 911

And will the one who was dead and so We raised him to life and set for him a light with which he walks among the people, ever be like the one who is in realms of darkness never to emerge from them? Similarly, the deeds of disbelievers are made to appear good to them.

# 912

And similarly, We have made in every town leaders among its criminals that they may conspire in it; and they do not conspire except against themselves and they do not have perception.

# 913

And when a sign comes to them, they say, “We will not believe until we are given the same which Allah’s Noble Messengers were given”; Allah knows best where to place His message (prophethood); soon the guilty will be afflicted with disgrace before Allah and a severe punishment due to their scheming.

# 914

And whomever Allah wills to guide, He opens his bosom for Islam; and whomever He wills to send astray, He makes his bosom narrow and firmly bound as if he were being forced by someone to climb the skies; this is how Allah places the punishment on those who do not believe.

# 915

And this is the Straight Path of your Lord; We have explained in detail Our verses for the people who accept advice.

# 916

For them is the abode of peace with their Lord and He is their Master – the result of their deeds.

# 917

And the Day when He will raise them all and will proclaim, “O you group of jinns, you have enticed a lot of men”; and their human friends will submit, “Our Lord, some of us have benefited from one another and have reached the appointed term which You had set for us”; He will say, “Your home is hell – remain in it for ever, except whomever Allah wills”; O dear Prophet (Mohammed – peace and blessings be upon him), indeed your Lord is the Wise, the All Knowing.

# 918

And similarly We empower some of the oppressors over others – the recompense of their deeds.

# 919

“O you groups of jinns and men! Did not the Noble Messengers amongst you come to you reciting My verses and warning you of confronting this day?” They will say, “We testify against ourselves” – and the worldly life deceived them and they will testify against themselves that they were disbelievers.

# 920

This is because your Lord does not unjustly destroy townships for their people may be unaware.

# 921

And for everyone are ranks from what they do; and your Lord is not unaware of their deeds.

# 922

And O dear Prophet (Mohammed – peace and blessings be upon him), your Lord is the Perfect (Not needing anything), the Merciful; O people! If He wills, He can remove you and bring others in your stead – the way He created you from the descendants of others.

# 923

Indeed the thing which you are promised will definitely come to pass, and you cannot escape.

# 924

Say (O dear Prophet Mohammed – peace and blessings be upon him), “O my people! Keep on with your works\* in your positions, I am doing mine; soon you will come to know for whom is the abode of the Hereafter; undoubtedly the unjust are never successful.” (\* This is said as a challenge)

# 925

And among the crops and animals that Allah has created, they assigned (only) a portion to Him and therefore said “This is for Allah” – in their opinion – “and this is for our partners (false deities)”; so the portion for their partners does not reach Allah; and the portion for Allah reaches their partners; what an evil judgement they impose!

# 926

And similarly, their partners (the devils) have made the killing of their children seem righteous in the sight of many of the polytheists, in order to ruin them and make their religion blurred to them; and if Allah willed they would not do so, therefore leave them alone with their fabrications.

# 927

And they said, “These cattle and crops are forbidden; only those whom we wish can eat them” – in their opinion – and some cattle are those which they have forbidden riding upon, and some cattle over which they do not mention the name of Allah while slaughtering – all this is fabricating lies against Allah; He will soon repay them for their fabrications.

# 928

And they said, “The animals in the bellies of such cattle are purely for our males and forbidden to our women; and if the animal is stillborn, they all have a share of it”; soon Allah will repay them for their utterances; indeed He is Wise, All Knowing.

# 929

Indeed ruined are those who slay their children out of senseless ignorance and forbid the sustenance which Allah has bestowed upon them, in order to fabricate lies against Allah; they have undoubtedly gone astray and not attained the path.

# 930

It is He Who produces gardens spread on the ground and above, and the date-palm, and crops of various flavours, and the olive and the pomegranate, similar in some respects and unlike in others; eat from its fruit when it bears yield, and pay the due (obligatory charity) from it on the day it is harvested; and do not be wasteful; indeed the wasteful are not liked by Allah.

# 931

And from the cattle, some for burdens, some spread on the earth; eat of the sustenance which Allah has bestowed upon you, and do not follow the footsteps of the devil; undoubtedly he is your open enemy.

# 932

“Eight males and females; one pair of sheep and one of goats”; say, “Has He forbidden the two males or the two females, or what the two females carry in their wombs? Answer with some knowledge, if you are truthful.”

# 933

“And a pair of camels and a pair of oxen”; say, “Has He forbidden the two males or the two females, or what the two females carry in their wombs? Were you present when Allah commanded this to you?” So who is more unjust than one who fabricates a lie against Allah in order to lead mankind astray with his ignorance? Indeed Allah does not guide the unjust.

# 934

Say (O dear Prophet Mohammed – peace and blessings be upon him), “I do not find in what is sent down to me any eatable prohibited to a consumer, except if it is carrion, or blood flowing from blood vessels, or the flesh of swine – for that is indeed foul, or the sin causing animal over which the name of any other than Allah is taken at the time of slaughtering; so for one compelled by circumstances, neither himself desiring nor eating more than necessary, indeed your Lord is Oft Forgiving, Most Merciful.”

# 935

And for the Jews We forbade all animals with claws; and forbade them the fat of oxen and sheep except which is on their backs or joined to their intestines or to the bone; We awarded this to them for their rebellion; and indeed, surely, We are truthful.

# 936

Then if they deny you (O dear Prophet Mohammed – peace and blessings be upon him) say, “Your Lord has boundless mercy; and His wrath is never withdrawn from the culprits.”

# 937

The polytheists will now say, “Had Allah willed, we would not have ascribed partners (to Him) nor would have our forefathers, nor would we have forbidden anything”; similarly those before them had denied, till the time they tasted Our punishment; say, “Do you have any knowledge so you can offer it to us? You follow only assumptions and only make guesses.”

# 938

Say, “Then only Allah’s argument is the complete one; so had He willed, He would have guided you all.”

# 939

Say, “Bring your witnesses who can testify that Allah has forbidden this”; then if they do testify, O listener (followers of this Prophet) do not bear witness along with them and do not follow the desires of those who deny Our signs, and of those who do not believe in the Hereafter and who ascribed equals to their Lord.

# 940

Say, “Come – so that I may recite to you what your Lord has forbidden for you that ‘Do not ascribe any partner to Him and be good to parents; and do not kill your children because of poverty; We shall provide sustenance for all – you and them; and do not approach lewd things, the open among them or concealed; and do not unjustly kill any life which Allah has made sacred; this is the command to you, so that you may have sense.’

# 941

‘And do not approach the wealth of an orphan except in the best manner, till he reaches his adulthood; and measure and weigh in full, with justice; We do not burden any soul except within its capacity; and always speak fairly, although it may be concerning your relative; and be faithful only to Allah’s covenant; this is commanded to you, so that you may accept advice.’”

# 942

“And that, ‘This is My Straight Path, so follow it; and do not follow other ways for they will sever you from His way; this is commanded to you, so that you may attain piety.’”

# 943

Then We gave the Book to Moosa, to complete the favour on one who is virtuous, and an explanation of all things, a guidance and a mercy, so they may believe in meeting their Lord.

# 944

And this (the Qur’an) is the blessed Book which We have sent down; so follow it and be pious, so there may be mercy upon you.

# 945

For you (the disbelievers) may say, “The Book was sent down only to two groups (Jews and Christians) before us; and we were totally unaware of what they read and taught.”

# 946

Or may say that, “If the Book had been sent down to us, we would have been more upon guidance than them”; so the clear proof and guidance and mercy has come to you, from your Lord; so who is more unjust than one who denies the signs of Allah, and turns away from them? We shall soon punish those who turn away from Our signs with a great punishment, the recompense of their turning away.

# 947

What are they waiting for – except that the angels come to them, or the punishment from your Lord, or one of the signs of your Lord? On the day when the (foretold) sign of your Lord comes, not a single soul who had not earlier accepted faith nor earned any good from its faith, will benefit from accepting faith; say, “Wait – we too are waiting.”

# 948

You (O dear Prophet Mohammed – peace and blessings be upon him) have no concern with those who divided their religion and became several groups; their case is only with Allah – He will then inform them of what they used to do.

# 949

For one who brings one good deed, are ten like it; and one who brings an ill-deed will not be repaid but with one like it, and they will not be wronged.

# 950

Say, “Indeed my Lord has guided me to the Straight Path; the right religion, (of) the community of Ibrahim who was free from all falsehood; and was not a polytheist.”

# 951

Say, “Undoubtedly my prayers and my sacrifices, and my living and my dying are all for Allah, the Lord Of The Creation.”

# 952

“He has no partner; this is what I have been commanded, and I am the first Muslim.”

# 953

Say, “Shall I seek a Lord other than Allah, whereas He is Lord of all things?” And whatever a soul earns is itself responsible for it; and no load bearing soul will bear anyone else’s load; then towards your Lord you have to return and He will inform you about the matters you differed.

# 954

And it is He who made you caliphs (viceroys) in the earth and ranked some of you high above others, in order that He may test you with what He has bestowed upon you; indeed it does not take time for your Lord to mete out punishment; and indeed, surely, He is Oft Forgiving, Most Merciful.

# 955

Alif-Laam-Meem-Saad. (Alphabets of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 956

O dear Prophet (Mohammed – peace and blessings be upon him), a Book has been sent down upon you, therefore may not your heart be disinclined towards it, so that you may give warning with it, and as an advice for the Muslims.

# 957

O mankind, follow what has been sent down to you from your Lord, and do not follow other administrators, abandoning this (the Holy Qur’an); very little do you understand.

# 958

And many a township did We destroy – so Our punishment came to them at night or while they were sleeping at noon.

# 959

Therefore they uttered nothing when Our punishment came to them, except that they said, “Indeed we were the unjust.”

# 960

So undoubtedly We shall question those to whom Our Noble Messengers went, and indeed We shall question the Noble Messengers.

# 961

So indeed We shall inform them with Our knowledge and We were not absent.

# 962

And on that Day, the weighing will truly be done; so those whose scales prove heavy are the successful.

# 963

And those whose scales are light are the people who put themselves to ruin – the recompense of the injustice they used to do to Our signs.

# 964

And indeed We established you in the earth and in it created for you the means of livelihood; very little thanks do you offer!

# 965

And indeed We created you, then designed you and then ordered the angels, “Prostrate before Adam”; so they all prostrated, except Iblis (Satan); he did not become of those who prostrate.

# 966

Said Allah, “What prevented you, that you did not prostrate when I commanded you?” Answered Iblis, “I am better than him; You created me from fire whereas You created him from clay.”

# 967

Said Allah, “Therefore go down from here – it does not befit you to stay here and be proud – exit, you are of the degraded.”

# 968

He said, “Give me respite till the day when people will be resurrected.”

# 969

Said Allah, “You are given respite.”

# 970

He said, “Hence I swear by the fact that You sent me astray, I will certainly lay in wait for them on Your Straight Path.”

# 971

“Then I will certainly approach them – from their front and from behind them and from their right and from their left; and You will find most of them not thankful.”

# 972

He said, “Exit from here, rejected, outcast; indeed whoever among them follows your bidding, I will fill hell with all of you.”

# 973

And said, “O Adam! You and your wife dwell in Paradise – therefore eat from it from wherever you wish, and do not approach this tree for you will become of those who transgress.”

# 974

Then Satan created apprehensions in their hearts in order to disclose to them matters of their shame which were hidden from them, and said, “Your Lord has forbidden you from this tree, for you may become angels or immortals.”

# 975

And he swore to them, “Indeed I am a well-wisher for both of you.”

# 976

So he brought them down with deception; and when they tasted from that tree, their shame became manifest to them and they began attaching the leaves of Paradise on themselves; and their Lord said to them, “Did I not forbid you from that tree, and tell you that Satan is an open enemy to you?”

# 977

They both submitted, “Our Lord! We have wronged ourselves; so if You do not forgive us and have mercy on us, then surely, we are of the losers.”

# 978

He said, “Go down, one of you is a foe unto the other; and for a fixed time you shall stay on earth and feed in it.”

# 979

He said, “You shall live there and there shall you die, and from there only you will be raised.”

# 980

O Descendants of Adam! We have sent down to you a garment to conceal your shame, and another garment for your elegance; and the garment of piety – that is the best; this is among the signs of Allah, so that they may remember.

# 981

O Descendants of Adam, beware! Do not let Satan put you in trial the way he removed your parents from Paradise and had their garments removed so that their shame become visible to them; indeed he and his tribe see you from where you do not see them; indeed We have made the devils the friends of those who do not believe.

# 982

And when they commit any shameful act they say, “We found our forefathers on it and Allah has commanded it to us”; say, “Indeed Allah does not ordain shamelessness; what! You attribute things to Allah, which you do not know?”

# 983

Say, “My Lord has ordained justice; and set your attention straight every time you offer pray and worship Him, as only His devoted worshippers; the way He brought you into being, in the same manner will you return.”

# 984

He has guided one group, and one group’s error has been proved; instead of Allah, they have chosen the devil as their friend and they assume that they are on guidance!

# 985

O Descendants of Adam! Adorn yourself when you go to the mosque, and eat and drink, and do not cross limits; indeed He does not like the transgressors.

# 986

Say, “Who has forbidden the adornment of Allah which He has brought forth for His bondmen, and the good food?” Say, “That is for the believers in this world, and on the Day of Resurrection it will be for them only”; this is how We explain Our verses in detail for people of knowledge.

# 987

Say, “My Lord has forbidden the indecencies, the apparent among them and the hidden, and sin and wrongful excesses, and forbidden that you ascribe partners with Allah for which He has not sent down any proof, and forbidden that you say things concerning Allah of which you do not have knowledge.”

# 988

And every group has a promise; so when its promise comes, it cannot be postponed for a moment or brought forward.

# 989

O Descendants of Adam! If Noble Messengers from among you come to you narrating My verses – so whoever practices piety and reforms – upon him shall be no fear nor shall he grieve.

# 990

And those who denied Our signs and were conceited towards them, are the people of hell-fire; they will remain in it forever.

# 991

So who is more unjust than one who fabricated a lie against Allah or denied His signs? Their written fate will reach them; until when Our sent angels come to remove their souls, hence they say to them, “Where are they whom you used to worship besides Allah?” They say, “We have lost them” and they testify against themselves that they were disbelievers.

# 992

Allah says to them, “Join the groups of jinns and mankind who have entered hell before you”; when a group enters, it curses the other; until when they have all gone in, the latter groups will say regarding the former, “Our Lord! It is these who led us astray, so give them double the punishment of the fire”; He will say, “For each one is double – but you do not know.”

# 993

And the preceding groups will say to the latter, “So you too were no better than us, therefore taste the punishment for what you have done!”

# 994

Indeed those who denied Our signs and were conceited towards them – the gates of the heavens will not be opened for them nor will they enter Paradise until the camel goes through the needle’s eye\*; and this is the sort of reward We give the guilty. (\* Which will never happen.)

# 995

Their beds and their coverings – both are fire; and this is the sort of reward We give the unjust.

# 996

And those who accepted faith and performed good deeds according to their capacity – We do not burden any one, except within its capacity – are the people of Paradise; they shall abide in it forever.

# 997

And We have removed resentment from their hearts – rivers will flow beneath them; and (while entering Paradise) they will say, “All praise is to Allah, Who guided us to this; we would not have attained the right path if Allah had not guided us; indeed the Noble Messengers of our Lord brought the truth”; and it is proclaimed, “You have received this Paradise as an inheritance for what you used to do.”

# 998

And the people of Paradise said to the people of hell, “We have surely received what our Lord had truly promised us – so have you also received what your Lord had truly promised?” They said, “Yes”; and an announcer between them proclaimed, “The curse of Allah is upon the unjust.” –

# 999

“Those who prevent from the path of Allah and wish to distort it; and who disbelieve in the Hereafter.”

# 1000

Between Paradise and Hell is a veil; and on the Heights will be some men who will recognise them all by their foreheads; and they call to the people of Paradise, “Peace be upon you”; they have not entered Paradise and they yearn for it.

# 1001

And when their eyes turn towards the people of hell, they will say, “Our Lord! Do not put us along with the unjust.”

# 1002

And the men on the Heights will call to some men whom they recognise by their foreheads, and say, “What benefit did your derive from your populace and from what you prided in?”

# 1003

“Are these the people (Muslims) regarding whom you swore that Allah would not have mercy on them at all? Whereas to the Muslims it has been said ‘Enter Paradise; you shall have no fear nor any grief.’”

# 1004

And the people of hell will cry out to the people of Paradise, “Provide us some benefit from your water or from the food Allah has provided you”; they will say, “Indeed Allah has forbidden both to the disbelievers.”

# 1005

People who made their religion a sport and pastime, and whom the worldly life deceived; so this day We will disregard them, the way they had neglected their confronting of this day, and the way they used to deny Our signs.

# 1006

And indeed We brought to them a Book, which We have explained in detail with a great knowledge – a guidance and a mercy for people who believe.

# 1007

What do they await, except for the result foretold by that Book to appear? The day when the result foretold by it occurs, those who had previously forgotten it from the beginning (the disbelievers) will exclaim, “Indeed the Noble Messengers of our Lord had brought the truth! Do we have any intercessors who may intercede for us? Or can we be returned (to earth), so we may do contrary to what we have done before?” Indeed they have put themselves into ruin, and have lost the things they fabricated.

# 1008

Indeed your Lord is Allah Who created the heavens and the earth in six days, then in the manner befitting His Majesty, ascended the Throne (of control); He covers the night with the day, which hastily follows it, and made the sun and the moon and the stars subservient to His command; pay heed! Only He has the power to create and command; Most Auspicious (Propitious) is Allah, the Lord Of The Creation.

# 1009

Pray to your Lord crying humbly, and softly; indeed He does not love the transgressors.

# 1010

And do not spread turmoil in the earth after its reform, and pray to Him with fear and hope; indeed Allah’s mercy is close to the virtuous.

# 1011

And it is He Who sends the winds giving glad tidings, ahead of His mercy; until when they come bearing heavy clouds, We drove it towards a city devoid of vegetation, and then rained water upon it, then produced fruits of various kinds from it; this is how We will bring forth the dead, so that you may heed advice.

# 1012

And from the good land comes forth its vegetation by the command of Allah; and from the infertile land, nothing comes forth except a little with difficulty; this is how We explain Our signs in different ways, for people who are thankful.

# 1013

Indeed We sent Nooh to his people – he therefore said, “O my people! Worship Allah – you do not have any God except Him; indeed I fear for you the punishment of the Great Day (of Resurrection).”

# 1014

The leaders of his people said, “Indeed we see you in open error.”

# 1015

He said, “O my people! There is no straying in me – I am in fact a Noble Messenger from the Lord Of The Creation.”

# 1016

“Conveying to you the messages of my Lord and wishing good for you, and I know from Allah what you do not know.”

# 1017

“And are you surprised that an advice came to you from your Lord through a man amongst you, so that he may warn you and that you may fear, and so that there be mercy upon you?”

# 1018

In response they denied him, so We rescued him and those with him in the ship, and We drowned those who denied Our signs; indeed they were a blind group.

# 1019

And We sent Hud to the people of Aad from their own community; he said, “O my people! Worship Allah – you do not have any God except Him; so do you not fear?”

# 1020

The disbelieving leaders of his people said, “Indeed we consider you foolish and think you are a liar.”

# 1021

He said, “O my people! I do not have any concern with foolishness and I am in fact a Noble Messenger from the Lord Of The Creation.”

# 1022

“I convey to you the messages of my Lord and am your trustworthy well-wisher.”

# 1023

“And are you surprised that an advice came to you from your Lord through a man amongst you, so that he may warn you? Remember when He made you the successors of Nooh’s people, and enlarged your bodies; therefore remember Allah’s favours, so that you may attain good.”

# 1024

They said, “Have you come to us in order that we worship only Allah, and abandon those whom our ancestors worshipped?! So bring upon us what you promise us, if you are truthful.”

# 1025

He said, “Indeed the punishment and the wrath of your Lord have fallen upon you; what! You needlessly dispute with me regarding the names you and your ancestors have fabricated? Allah has not sent down any proof concerning them; therefore wait – I too await with you.”

# 1026

We therefore rescued him and those with him by a great mercy from Us, and We cut off the lineage of those who denied Our signs – and they were not believers.

# 1027

And We sent Saleh to the tribe of Thamud, from their own community; he said, “O my people! Worship Allah – you do not have any God except Him; indeed a clear proof has come to you from your Lord; this is Allah’s she-camel – a sign for you – so leave her free to feed in Allah’s earth, and do not touch her with evil intentions for a painful punishment will seize you.”

# 1028

“And remember when He made you successors of A’ad and gave you a region in the earth, so you now build palaces in the soft plains and carve houses in rocks; therefore remember Allah’s favours and do not roam the earth spreading turmoil.”

# 1029

The proud leaders of his people (mockingly) said to the weak Muslims, “Do you know that Saleh is (really) the Noble Messenger of his Lord?” They said, “We believe in whatever he has been sent with.”

# 1030

The proud ones said, “We deny what you have believed in.”

# 1031

So they hamstrung the she-camel and rebelled against the command of their Lord and said, “O Saleh! Bring upon us what you promise us, if you are a Noble Messenger.”

# 1032

Therefore the earthquake seized them, so at morning they remained lying flattened in their homes.

# 1033

Saleh therefore turned away from them and said, “O my people! Indeed I did deliver my Lord’s message to you and wished you good, but you do not want well-wishers.” (The people in the graves can hear the speech of those who are on earth.)

# 1034

And We sent Lut – when he said to his people, “What! You commit the shameful acts which no one in the creation has ever done before you?”

# 1035

“You lustfully go towards men, instead of women! In fact, you have transgressed the limits.”

# 1036

And his people had no answer except to say, “Turn them out of your dwellings; these are people who wish purity!”

# 1037

And We rescued him and his family, except his wife – she became of those who stayed behind.

# 1038

And We rained a shower (of stones) upon them; therefore see what sort of fate befell the culprits!

# 1039

And We sent Shuaib to Madyan from their community; he said, “O my people! Worship Allah – you do not have any God except Him; indeed a clear proof has come to you from your Lord, so measure and weigh in full and do not give the people their goods diminished, and do not spread turmoil in the earth after it is organised; this is for your good, if you believe.”

# 1040

“And do not be seated on every road in order to scare the travellers, and to prevent from Allah’s path the people who believe in Him, wishing to distort it; and remember when you were few and He increased your numbers; and see what sort of fate befell the mischievous!”

# 1041

“And if a group among you believes in what I have been sent with, and another group does not believe, then wait until Allah judges between us; and Allah’s judgement is the best of all.”

# 1042

The proud leaders of his people said, “O Shuaib, we swear we will banish you and the Muslims who are with you, from our town or you must return to our religion”; he said, “Even though we detest it?”

# 1043

“We shall then have fabricated a lie against Allah if we return to your religion after Allah has rescued us from it; and it is not for any of us Muslims to return to your religion except if Allah, Who is our Lord, wills; the knowledge of our Lord encompasses all things; in Allah only we have trusted; our Lord! Decide with justice between us and our people – and Yours is the best decision.”

# 1044

And the disbelieving leaders of his people said, “If you obey Shuaib, you will indeed be in a loss.”

# 1045

Therefore the earthquake seized them – so at morning they remained lying flattened in their homes.

# 1046

As if those who denied Shoaib had never lived in those homes; those who denied Shoaib, were themselves ruined.

# 1047

So Shoaib turned away from them saying, “O my people! Indeed I did deliver my Lord’s message to you and gave you sound advice; so why should I grieve for the disbelievers?” (The people in the graves can hear the speech of those who are on earth.)

# 1048

And never did We send any Prophet to a dwelling but We seized its people with hardship and adversity so that they may become humble.

# 1049

Then We changed the misfortune into prosperity to the extent that they became numerous and said, “Indeed grief and comfort did reach our ancestors” – so We seized them suddenly in their neglect.

# 1050

And had the people of the dwellings believed and been pious, We would have surely opened for them the blessings from the sky and from the earth, but in fact they denied, and We therefore seized them on account of their deeds.

# 1051

Do the people of the dwellings not fear that Our wrath may come upon them at night while they are asleep?

# 1052

Or do the people of the dwellings not fear that Our wrath may come upon them during the day, while they are playing?

# 1053

Are they oblivious to Allah’s secret plan? So none is unafraid of Allah’s secret plan except the people of ruin!

# 1054

Or did not those who inherited the land after its owners, get enough guidance that if We will, We can afflict them with calamity for their sins? And We set seals upon their hearts so they do not hear.

# 1055

These are the dwellings – the affairs of which We relate to you (Prophet Mohammed – peace and blessings be upon him); and indeed their (respective) Noble Messengers came to them with clear proofs; so they were not able to believe in what they had denied before; this is how Allah sets seals upon the hearts of disbelievers.

# 1056

And We found most of them not true to their words; and indeed We found most of them disobedient.

# 1057

Then after them, We sent Moosa with our signs to Firaun and his court members, but they did injustice to those signs; therefore see what sort of fate befell the mischievous!

# 1058

And Moosa said, “O Firaun! Indeed I am a Noble Messenger from the Lord Of The Creation.”

# 1059

“It is obligatory for me not to speak concerning Allah except the truth; I have come to you all with a clear sign from your Lord, therefore let the Descendants of Israel go with me.”

# 1060

Said Firaun, “If you have come with a sign, then present it if you are truthful!”

# 1061

Therefore Moosa put down his staff – it immediately turned into a visible python.

# 1062

And putting his hand in his bosom, withdrew it – so it shone brightly before the beholders.

# 1063

Said the chieftains of Firaun’s people, “He is really an expert magician.”

# 1064

“He wishes to expel you all from your kingdom; so what do you advise?”

# 1065

They said, “Stop him and his brother, and send announcers to the cities to gather people.”

# 1066

“To bring all the expert magicians to you.”

# 1067

And the magicians came to Firaun, and said, “Will we get some reward if we are victorious?”

# 1068

He said, “Yes, and you will then become close to me.”

# 1069

They said, “O Moosa! You may throw first – or shall we be the first to throw?”

# 1070

He said, “You throw”; when they threw, they cast a magic spell upon the people’s eyes and terrified them, and they brought a great magic.

# 1071

And We inspired Moosa that, “Put forth your staff”; it immediately began swallowing up their fabrications.

# 1072

So the truth was proved and their works were disproved.

# 1073

They were therefore defeated here and they turned back humiliated.

# 1074

And the magicians were obliged to fall prostrate.

# 1075

They said, “We have accepted faith in the Lord Of The Creation.”

# 1076

“The Lord of Moosa and Haroon.”

# 1077

Said Firaun, “You have accepted faith in Him before I gave you permission! This is indeed a grand conspiracy you have plotted in the city, in order to expel its people from it; so now you will come to know!”

# 1078

“I swear I will cut off your hands and your feet from alternate sides and then crucify you all.”

# 1079

They said, “We shall return to our Lord.”

# 1080

“And what did you dislike in us, except that we believed in the signs of our Lord when they came to us? Our Lord! Pour (bestow abundantly) patience on us, and bestow us death as Muslims.”

# 1081

The chieftains of Firaun’s people said, “Are you releasing Moosa and his people to cause turmoil in the land, and for Moosa to abandon you and your appointed deities?” He said, “We shall now slay their sons and spare their women; and indeed we have power over them.”

# 1082

Moosa said to his people, “Seek the help of Allah and patiently endure; indeed the Owner of the earth is Allah – He appoints as its successor whomever He wills; and the final triumph is for the pious.”

# 1083

They said, “We have been oppressed before you came to us, and after you have come to us”; he said, “It is likely that your Lord may destroy your enemy and in his place make you the rulers of the earth, and then see what deeds you perform.”

# 1084

And indeed We seized the people of Firaun with a famine of several years and with reduction of fruits, so that they may follow advice.

# 1085

So when good would reach them they would say, “This is for us”; and when misfortune reached them, they would infer it as ill omens of Moosa and his companions; pay heed! The misfortune of their ill luck lies with Allah, but most of them are unaware.

# 1086

And said, “You may come with any sign to us, in order to cast a magic spell on us – yet by no means are we going to believe in you.”

# 1087

We therefore sent against them the flood and the locusts and the vermin (or insects) and the frogs and the blood – separate signs; in response they were proud and were a guilty people.

# 1088

And whenever the punishment came upon them they said, “O Moosa! Pray to your Lord for us, by means of His covenant which you have; indeed if you lift the punishment from us we will surely accept faith in you and let the Descendants of Israel go with you.”

# 1089

Consequently whenever We lifted the punishment from them for a term which they must reach, they used to then turn away.

# 1090

We therefore took revenge from them; so We drowned them in the sea for they used to deny Our signs and were ignoring them.

# 1091

And We made the people who were oppressed, the inheritors of the eastern and western parts of the land in which We placed blessings; and the good promise of your Lord was fulfilled for the Descendants of Israel – the reward of their patience; and We destroyed whatever Firaun and his people built and whatever they had contrived.

# 1092

And We transported the Descendants of Israel across the sea – so they came across a people who used to squat in seclusion in front of their idols; they said, “O Moosa! Make a God for us, the way they have so many Gods!” He said, “You are indeed an ignorant people.”

# 1093

“The condition they are in is, in fact, one of destruction – and all what they do is utter falsehood.”

# 1094

He said, “Shall I seek for you a God other than Allah, whereas He has given you superiority above the entire world?” (By sending His message towards you).

# 1095

And remember when We rescued you from Firaun’s people who were afflicting you with a dreadful torment; slaughtering your sons and sparing your daughters; and in it was a great favour from your Lord.

# 1096

And We agreed with Moosa a covenant for thirty nights (of solitude) and completed it by adding ten to them, so the covenant of His Lord amounted to forty nights in full; and Moosa said to his brother Haroon, “Be my deputy over my people and make reform and do not allow the ways of the mischievous to enter.”

# 1097

And when Moosa presented himself upon Our promise, and his Lord spoke to him, he said, “My Lord! Show me Your Self, so that I may see You”; He said, “You will never be able to see Me, but look towards the mountain – if it stays in its place, then you shall soon see Me”; so when his Lord directed His light on the mountain, He blew it into bits and Moosa fell down unconscious; then upon regaining consciousness he said, “Purity is to You! I incline towards You, and I am the first Muslim.”

# 1098

Said Allah, “O Moosa! I have chosen you from mankind by (bestowing) My messages and by My speech; so accept what I have bestowed upon you and be among the thankful.”

# 1099

And We wrote for him on the tablets, the advice for all things and the details of all things; and commanded “Accept it firmly and command your people to choose its good advices; soon I shall show you people the destination of the disobedient.”

# 1100

“And I shall turn away from My signs the people who unjustly wish to be admired in the earth; and if they see all the signs, they would not believe them; and if they see the path of guidance, they would not prefer to tread it; and if they see the way of error, they would present themselves to tread it; that is because they denied Our signs and were ignoring them.

# 1101

And those who denied Our signs and the confronting of the Hereafter – all their deeds are wasted; what recompense will they get, except what they used to do?

# 1102

And behind Moosa, his people moulded a calf from their ornaments – a lifeless body making sounds like a cow; did they not see that it neither speaks to them nor guides them in any way? They chose it (for worship), and were unjust.

# 1103

And when they repented and realised that they had gone astray, they said, “If our Lord does not have mercy on us and forgive us, we are ruined.”

# 1104

And when Moosa returned to his people, angry and upset, he said, “What an evil way you have handled affairs on my behalf, behind me; did you hasten upon the command of your Lord?” And he cast down the stone tablets, and catching hold of his brothers hair, began pulling him towards him; said Haroon said, “O the son of my mother! The people thought I was weak and would have probably killed me; so do not make my enemies laugh at me and do not identify me with the unjust.”

# 1105

He submitted, “My Lord! Forgive me and my brother and admit us into Your mercy; and You are the Most Merciful of all those who show mercy.”

# 1106

Indeed those who took the calf – the punishment from their Lord, and humiliation will reach them in the life of this world; and this is the way We reward those who fabricate lies.

# 1107

And those who performed misdeeds and then repented and accepted faith – so after that, your Lord is Oft Forgiving, Most Merciful.

# 1108

And when the anger of Moosa abated, he picked up the stone tablets; and in their texts are guidance and mercy for those who fear their Lord.

# 1109

And Moosa chose seventy men from his people for Our promise; therefore when the earthquake seized them, he submitted, “My Lord! If You had willed You could have destroyed them and me, even earlier! Will You destroy us for the deeds which the ignorant among us did? That is not but Your testing us; with it You send astray whomever You will and guide whomever You will; You are our Master, so forgive us and have mercy on us, and You are the Best of the Forgiving.”

# 1110

“And destine good for us in this world and in the Hereafter – We have indeed inclined towards You”; He said, “I give My punishment to whomever I will; and My mercy encompasses all things; so I shall soon destine favours for those who fear and pay the charity, and they believe in Our signs.”

# 1111

“Those who will obey this Noble Messenger (Prophet Mohammed – peace and blessings be upon him), the Herald of the Hidden who is untutored\* (except by Allah), whom they will find mentioned in the Taurat and the Injeel with them; he will command them to do good and forbid them from wrong, and he will make lawful for them the good clean things and prohibit the foul for them, and he will unburden the loads and the neck chains which were upon them; so those who believe in him, and revere\*\* him, and help him, and follow the light which came down with him – it is they who have succeeded." (\*The Holy Prophet was taught by Allah Himself – see Surah 55 Al-Rahman. \*\*To honour the Holy Prophet – peace and blessings be upon him – is part of faith. To disrespect him is blasphemy.)

# 1112

Say (O dear Prophet Mohammed – peace and blessings be upon him), “O people! Indeed I am, towards you all, the Noble Messenger of Allah – for Whom (Allah) only is the kingship of the heavens and the earth; there is none worthy of worship, except Him – giving life and giving death; therefore believe in Allah and His Noble Messenger, the Prophet who is untutored (except by Allah), who believes in Allah and His Words, and obey him (the Prophet) to attain guidance.” (Prophet Mohammed – peace and blessings be upon him – is the Prophet towards all mankind.)

# 1113

And among the people of Moosa is a group that shows the true path, and establishes justice with it.

# 1114

And We divided them into twelve tribes, as separate groups; and when his people asked him for water, We revealed to Moosa, “Strike the rock with your staff”; so twelve springs gushed forth from it; each group recognised its drinking-place; and We made the clouds a canopy over them and sent down the Manna and the Salwa (birds) on them; “Eat of the good things we have provided you”; and they did not wrong Us in the least, but they used to wrong themselves.

# 1115

And remember when they were commanded, “Reside in this township and eat whatever you wish in it, and say ‘Sins are forgiven’ and enter the gate prostrating – We will forgive you your sins; We shall soon bestow more upon the virtuous.”

# 1116

So the unjust among them changed the words, contrary to what they had been commanded – consequently We sent down upon them a punishment from the sky – the recompense of their injustice.

# 1117

And ask them (O dear Prophet Mohammed – peace and blessings be upon him) of the township that was by the sea; when they used to exceed in the matter of the Sabbath – when their fish used to come swimming atop the water in front of them on the day of Sabbath and not come on the days it was not Sabbath; this is how We used to test them, due to their disobedience.

# 1118

And when a group among them said, “Why do you preach to a people whom Allah is going to destroy or mete out a severe punishment?” They said, “To have an excuse before your Lord, and that perhaps they may fear.”

# 1119

And when they forgot the advices they had been given, We rescued those who forbade evil, and seized the unjust with a dreadful punishment – the recompense of their disobedience.

# 1120

Consequently when they rebelled against the command to refrain, We said to them, “Be apes, despised!”

# 1121

And remember when your Lord announced the command that till the Day of Resurrection I will certainly send such oppressors against them, who will inflict them with a dreadful punishment; indeed your Lord is swift in meting out punishment; and indeed He is Oft Forgiving, Most Merciful.

# 1122

And We divided them in the earth as separate groups; some of them are righteous and some are the other type; and We tested them with good (favours) and evil things (adversities) so that they may return.

# 1123

And after them in their place, came those unworthy successors who inherited the Books – they accept the goods of this world (as bribes) and say, “We shall soon be forgiven”; and if similar goods come to them again, they would accept it; was not the covenant taken from them in the Book, that they must not relate anything to Allah except the truth, and they have studied it? And indeed the abode of the Hereafter is better for the pious; so do you not have sense?

# 1124

And those who hold fast to the Book, and have kept the prayer established; and We do not waste the wages of the righteous.

# 1125

And when We raised the Mount (Sinai) above them as if it were a canopy, and they thought that it would fall upon them; “Accept firmly what We have given you, and remember what is in it, so that you may become pious.”

# 1126

And remember when your Lord brought forth the generations from the backs of the Descendants of Adam, and made them their own witness; “Am I not your Lord?”; they all said, “Yes surely You are, why not? We testify”; for you may say on the Day of Resurrection that, “We were unaware of this.”

# 1127

Or you may say, “It is our ancestors who first ascribed partners (to Allah) and we were (their) children after them; so will You destroy us on account of the deeds of the followers of falsehood?”

# 1128

And this is how We explain the verses in different ways, and so that they may return.

# 1129

And O dear Prophet (Mohammed – peace and blessings be upon him) recite to them the case of the one to whom We gave Our revelations, and in response he departed from them completely – so Satan went after him – he therefore became of the astray.

# 1130

And had We willed We could have raised him because of the revelations, but he clung to the earth and followed his own desires; his condition therefore is like that of a dog; if you attack him he hangs out his tongue and if you leave him he hangs out his tongue; this is the state of the people who denied Our signs; therefore preach, so that they may give thought.

# 1131

What an evil example is of those who denied Our signs and used to wrong only their own souls.

# 1132

Whomever Allah guides – only he is on the right path; and whomever He sends astray – it is they who are the losers.

# 1133

And indeed We have created many jinns and men for hell; they have hearts in which their is no understanding; and the eyes they do not see with; and the ears they do not hear with; they are like cattle – in fact more astray; it is they who are the neglectful.

# 1134

And for Allah only are the best names, so invoke Him by them; and abandon those who depart from the truth regarding His names; they will soon receive the reward of their deeds.

# 1135

And from Our creation is a group that shows the truth and establishes justice with it.

# 1136

And those who denied Our signs – We shall soon steadily lead them towards the punishment, from the place they will not know.

# 1137

And I will give them respite; indeed My secret plan is extremely solid.

# 1138

Do they not ponder that their companion is far removed from insanity? In fact he is clearly a Herald of Warning.

# 1139

Have they not pondered deeply regarding the kingdom of the heavens and the earth, and whatever things Allah created? And that possibly their promise (of death) may have come near? So after this\*, in what will they believe? (\*Advent of the Last Prophet and the Holy Qur’an.)

# 1140

For one whom Allah sends astray, there is none to guide him; and He leaves them to wander in their rebellion.

# 1141

They ask you about the Resurrection, as to when it is destined; say, “Indeed its knowledge is with my Lord; only He will manifest it at its time; it is proving cumbersome in the heavens and the earth; it will not come to you except suddenly”; they question you as if you have researched it deeply; say, “Indeed its knowledge is with Allah only but most people do not know.”

# 1142

Say, “I have no autonomy to benefit or hurt myself, except what Allah wills; and were I to procure knowledge of the hidden on my own, it would be that I had accumulated a lot of good; and no misfortune would touch me; I am purely a Herald of Warning and Glad Tidings to the people who believe.”

# 1143

It is He Who created you from a single soul, and from him made its mate for him to gain comfort with her; so when the male covered her, she was burdened lightly in her womb, and she therefore moved easily carrying it; and when she felt the burden heavy, they both cried to their Lord Allah, “Indeed You may give to us a child as You will, so we will surely be thankful.”

# 1144

So when He bestowed them a normal child, they ascribed partners (to Him) in respect of what He had bestowed upon them; therefore Supreme is Allah, above all that they ascribe as partners.

# 1145

Do they (the disbelievers) ascribe (false deities) that which do not create anything, but are themselves created?

# 1146

And cannot provide any help to them, nor do they help themselves?

# 1147

And if you call the disbelievers to guidance, they do not follow you; it is the same for you, whether you invite them or remain silent.

# 1148

Indeed those whom you (the disbelievers) worship besides Allah are slaves like you – so call them and they may answer you, if you are truthful!

# 1149

Do they have feet to walk with? Or have they hands to hold with? Or have they eyes to see with? Or have they ears to hear with? Say, “Call upon your ascribed partners and conspire against me, and do not give me respite.”

# 1150

“Indeed my Protector is Allah Who has sent down the Book; and He befriends the righteous.”

# 1151

“And those whom you worship besides Him cannot help you nor do they help themselves.”

# 1152

And if you call them to guidance they do not listen; and you (Prophet Mohammed – peace and blessings be upon him) observe them looking towards you, whereas they do not perceive anything.

# 1153

And O dear Prophet (Mohammed – peace and blessings be upon him) adopt forgiveness, and enjoin virtue, and turn away from the ignorant.

# 1154

And O listener! If the devil provokes you, seek the refuge of Allah; indeed He is All Hearing, All Knowing.

# 1155

Indeed those who fear get alerted whenever a temptation from the devil troubles them, and they perceive immediately.

# 1156

And the devils pull those who their brothers into error, and then do not make any relaxation.

# 1157

And O dear Prophet (Mohammed – peace and blessings be upon him) when you do not bring to them a verse, they say, “Why did you not fabricate it?” Say, “I follow only what is divinely revealed to me from my Lord”; this (the Holy Qur’an) is an enlightenment from your Lord, and a guidance and a mercy for the Muslims.

# 1158

And when the Qur’an is recited, listen to it attentively and keep silent, so that you receive mercy.

# 1159

And remember your Lord within your hearts humbly and with fear, and softly with your tongues, morning and evening, and do not be of the neglectful.

# 1160

Indeed those who are with your Lord are not conceited towards worshipping Him, and they proclaim His Purity and it is to Him they prostrate. (Command of Prostration # 1)

# 1161

They ask you O dear Prophet (Mohammed – peace and blessings be upon him) concerning the war booty; say, “Allah and the Noble Messenger are the owners of the war booty; so fear Allah and maintain friendship among yourselves; and obey Allah and His Noble Messenger, if you have faith."

# 1162

Only they are the believers whose hearts fear when Allah is remembered, and their faith advances when His verses are recited to them, and who trust only in their Lord.

# 1163

Those who keep the prayer established and spend in Our cause from what We have bestowed upon them.

# 1164

These are the true Muslims; for them are ranks before their Lord, and forgiveness and an honourable sustenance.

# 1165

The way your Lord caused you, O dear Prophet to come forth from your home with the truth; and indeed a group of Muslims were unhappy about it.

# 1166

Disputing with you regarding the truth after it had been made clear, as if they were being herded towards a visible death.

# 1167

And remember when Allah promised you that one of the two groups (of enemies) is for you, and you wished to get the one that posed no danger, and Allah willed to prove the truth with His Words, and to cut the origins of the disbelievers.

# 1168

In order that He may prove the truth and disprove falsehood, even if the criminals get annoyed.

# 1169

When you (Prophet Mohammed – peace and blessings be upon him) were seeking the help of your Lord, so He answered your prayers that, “I will help you with a row of thousands of angels.”

# 1170

And Allah did this just for your happiness and for your hearts to gain contentment; and help does not come except from Allah; indeed Allah is Almighty, Wise.

# 1171

When He made the slumber overcome you, so it was as a peacefulness from Him, and sent down water from the sky upon you to purify you with it, and to remove the impurity of Satan from you, and to give your hearts fortitude and firmly establish your feet with it.

# 1172

And when O dear Prophet, your Lord was inspiring the angels that, “I am with you – so make the believers stand firm; I will soon instil fear into the hearts of the disbelievers, so strike above the disbelievers’ necks and hit their each and every bone joint.”

# 1173

This is because they opposed Allah and His Noble Messenger; and whoever opposes Allah and His Noble Messenger – then indeed Allah’s punishment is severe.

# 1174

Therefore taste this for now, and along with it for the disbelievers is the punishment of fire.

# 1175

O People who Believe! When you confront a large army of disbelievers in battle, do not turn your backs to them.

# 1176

And on that day whoever turns his back to them, except for a battle strategy or to join one’s own company, has then turned towards Allah’s wrath, and his destination is hell; and what an evil place of return!

# 1177

So you did not slay them, but in fact Allah slew them; and O dear Prophet (Mohammed – peace and blessings be upon him) you did not throw (the sand) when you did throw, but in fact Allah threw; and in order to bestow an excellent reward upon the Muslims; indeed Allah is the All Hearing, the All Knowing.

# 1178

Therefore take this, and (know that) Allah will weaken the scheme of the disbelievers.

# 1179

O disbelievers! If you seek a judgement, then this judgement has come to you; and if you desist, it is better for you; and if you return to mischief, We will punish you again; and your populace will not benefit you, however large it may be – and besides this, Allah is with the Muslims.

# 1180

O People who Believe! Obey Allah and His Noble Messenger, and do not turn away from him after you have heard him speak.

# 1181

And do not be like those who said, “We have heard”, whereas they do not hear.

# 1182

Indeed the worst beasts in the sight of Allah are those (people) who are deaf, dumb – who do not have any sense.

# 1183

And had Allah found any goodness in them, He would have made them hear; and had He made them hear they would, in the end, have turned away and gone back.

# 1184

O People who Believe! Present yourselves upon the command of Allah and His Noble Messenger, when the Noble Messenger calls you towards the matter that will bestow you life; and know that the command of Allah becomes a barrier between a man and his heart’s intentions, and that you will all be raised towards Him.

# 1185

And fear the turmoil which will certainly not fall only upon a few selected unjust people among you; and know that Allah’s punishment is severe.

# 1186

And remember when you were only a few and meek in the land, and feared that men may snatch you away – He therefore gave you refuge and strengthened you with His help, and gave you good things as sustenance, so that you may be thankful.

# 1187

O People who Believe! Do not betray Allah and His Noble Messenger, nor purposely defraud your trusts.

# 1188

And know that your wealth and your children are a test, and that with Allah is an immense reward.

# 1189

O People who Believe! If you fear Allah, He will bestow upon you (the criterion) that with which you will separate the truth from falsehood, and He will unburden your misdeeds and forgive you; and Allah is the Extremely Munificent.

# 1190

And remember O dear Prophet when the disbelievers were scheming against you to either imprison you, or to kill you or to banish you; and they were scheming, and Allah was making His secret plan; and Allah’s secret plan is the best.

# 1191

And when Our verses are recited to them they say, “Yes, we have heard – if we wanted we could also say something like this – these are nothing but stories of former people!”

# 1192

And when they said, “O Allah! If this (the Qur’an) is really the truth from You, then shower upon us a rain of stones from the sky, or bring upon us some painful punishment.”

# 1193

And it is not for Allah to punish them while you O dear Prophet (Mohammed – peace and blessings be upon him) are amongst them; and Allah will not punish them as long as they are seeking forgiveness. (Prophet Mohammed – peace and blessings be upon him – is a mercy unto mankind.)

# 1194

And what is with them that Allah should not punish them, whereas in fact they prevent from the Sacred Mosque and they are not worthy (of being the custodians) of it; only the pious are its befitting custodians, but most of them do not have knowledge.

# 1195

And their prayer near the Kaa’bah is nothing except whistling and clapping; “So now taste the punishment – the result of your disbelief.”

# 1196

Indeed the disbelievers spend their wealth in order to prevent people from the way of Allah; so they will spend it now, and then regret over it, then they will be defeated; and the disbelievers will be gathered towards hell.

# 1197

In order that Allah may separate the filthy from the pure, and placing the filthy atop one another, make a heap and throw them into hell; it is they who are the losers.

# 1198

Say to the disbelievers that if they desist, what has passed will be forgiven to them; and if they do the same, the tradition of former people has already passed.

# 1199

And fight them until no mischief remains and the entire religion is only for Allah; then if they desist, Allah sees all what they do.

# 1200

And if they turn away, then know that Allah is your Master; so what an Excellent Master and what an Excellent Supporter!

# 1201

And know that whatever you take as war booty, a fifth of that belongs to Allah and His Noble Messenger, and to relatives, and orphans, and the needy, and the traveller – if you have accepted faith in Allah and what We sent down to Our bondman on the decisive day – the day when two armies had met; and Allah is Able to do all things.

# 1202

When you were on the near bank and the disbelievers on the far bank, and the caravan below you; and had you made an agreement between one another, you would have failed to reach on the appointed time – but this is in order that Allah may complete a thing that must be done – that he who dies may die by a clear proof and he who lives may live by a clear proof; and indeed Allah is surely, All Hearing, All Knowing.

# 1203

When O dear Prophet, Allah used to show the disbelievers in your dream as only a few\*; and O Muslims, had He shown them to you as many, you would have certainly lost courage and disputed over the affair, but Allah rescued (you); indeed He knows what lies within the hearts. (\* They numbered more but their actual strength was equal to only a few.)

# 1204

And when at the time of fighting He made the disbelievers seem few to you, and you as few in their sight, in order for Allah to conclude the matter that must be done; and towards Allah is the return of all matters.

# 1205

O People who Believe! When you meet an army, hold firm and remember Allah profusely, in order that you succeed.

# 1206

And obey Allah and His Noble Messenger, and do not dispute with one another for you will lose courage again and your strength will be lost, and patiently endure; indeed Allah is with those who patiently endure.

# 1207

And do not be like those who came out from their houses proudly, and to be seen by men, and they prevent people from Allah’s way; and all their actions are within Allah’s control.

# 1208

And when Satan made their deeds seem good in their sight and said, “This day no one can overpower you, and you are under my protection”; so when the two armies came face to face, he scrambled back and said, “I am unconcerned with you – I can see what is not visible to you – I fear Allah”; and Allah’s punishment is severe.

# 1209

When the hypocrites and those in whose hearts is a disease were saying, “These Muslims are proud of their religion”; and whoever trusts Allah, then indeed Allah is Almighty, Wise.

# 1210

And if you see the angels when they are removing the souls of the disbelievers, hitting them on their faces and their backs; “Taste more of the punishment of the fire!” (Punishment in the grave is proven by this verse.)

# 1211

“This is the recompense of what your own hands have sent ahead, and Allah does not oppress His bondmen.”

# 1212

Like the ways of Firaun’s people, and those before them; they disbelieved in the signs of Allah – therefore Allah seized them on account of their sins; indeed Allah is Most Powerful, Severe in Punishing.

# 1213

This is because Allah does not change the favour He has bestowed upon any people until they first change themselves, and indeed Allah is All Hearing, All Knowing.

# 1214

Like the ways of Firaun’s people and those before them; they denied the signs of Allah – We therefore destroyed them on account of their sins and We drowned the people of Firaun; and they all were unjust.

# 1215

Indeed the worst beasts in the sight of Allah are the people who disbelieve and do not accept faith.

# 1216

Those with whom you made a treaty, then they break their agreement each time and do not fear.

# 1217

So if you find them in battle, kill them in a manner which makes those behind them scamper back, in the hope that they may learn a lesson.

# 1218

And if you apprehend treachery from a nation, then throw back their treaty towards them in reciprocity; indeed Allah does not like the treacherous.

# 1219

And never may the disbelievers pride that they have escaped; indeed they can never defeat.

# 1220

And keep ready for them the maximum of forces you can and the maximum number of horses you can keep tethered, in order to instil awe in the hearts of those who are the enemies of Allah and who are your enemies, and in the hearts of some others whom you do not know; Allah knows them; and whatever you spend in Allah's cause will be repaid to you in full and you will never be in a loss.

# 1221

And if they incline towards peace, you too lean towards it, and trust Allah; indeed He only is the All Hearing, the All Knowing.

# 1222

And if they wish to deceive you, then indeed Allah is Sufficient for you; it is He Who has given you strength, with His help and with the Muslims.

# 1223

And has created harmony among their hearts; if you had spent all that is in the earth you could not have created harmony among their hearts, but Allah has created harmony among them; indeed He only is Almighty, Wise.

# 1224

O Herald of the Hidden! Allah is Sufficient for you and for all these Muslims who follow you.

# 1225

O Herald of the Hidden! Urge the believers to fight; if there are twenty persevering men among you, they shall overcome two hundred; and if there are a hundred among you, they shall overcome a thousand disbelievers because the disbelievers are a people who do not have sense.

# 1226

So now Allah has made an ease upon you and He knows that you are weak; so if there are a hundred persevering men among you, they shall overcome two hundred; and if there are a thousand among you, they shall overcome two thousand by the command of Allah; and Allah is with those who patiently endure.

# 1227

It does not befit any Prophet to capture the disbelievers alive until he has profusely shed their blood in the land; you people desire the wealth of this world; and Allah wills the Hereafter, and Allah is Almighty, Wise.

# 1228

Had Allah not pre-destined a matter then, O Muslims, a terrible punishment would have come upon you due to the ransom you took from the disbelievers.

# 1229

Therefore benefit from the booty you have received, lawful and good; and keep fearing Allah; indeed Allah is Oft Forgiving, Most Merciful.

# 1230

O Herald of the Hidden! Say to the captives whom you possess, “If Allah finds any goodness in your hearts, He will give you better than what has been taken from you, and will forgive you; and Allah is Oft Forgiving, Most Merciful.”

# 1231

And if they wish to deceive you, they have already been disloyal to Allah, because of which He has given these disbelievers in your control; and Allah is All Knowing, Wise.

# 1232

Indeed those who accepted faith and left their homes and belongings for Allah, and fought with their wealth and their lives in Allah's cause, and those who gave shelter and provided help, are the heirs of one another; and those who believed but did not leave their homes – you have no right in their estates until they migrate; and if they seek help from you in the matter of religion then it is your duty to provide help, except against the people between whom and you is a treaty; and Allah sees your deeds.

# 1233

And the disbelievers are the heirs of one another – if you do not do so, there will be turmoil in the land and a great chaos.

# 1234

And those who believed and migrated and fought in Allah's cause, and those who gave shelter and provided help – it is they who are the true believers; for them is pardon, and an honourable sustenance.

# 1235

And those who afterwards believed and migrated and fought along with you – they too are from among you; and family members (blood relations) are nearer to one another in the Book of Allah; indeed Allah knows everything.

# 1236

Severance of ties is proclaimed by Allah and on behalf of His Noble Messenger, towards the polytheists with whom you had a treaty.

# 1237

Travel freely in the land for four months, and bear in mind that you cannot escape from Allah, and that Allah will humiliate the disbelievers.

# 1238

And proclaim from Allah and His Noble Messenger to all men on the day of the Great Pilgrimage (Haj) that Allah is disgusted with the polytheists, and so is His Noble Messenger; so if you repent it is better for you; but if you turn away, then know that you cannot escape from Allah; and give the disbelievers the glad tidings of a painful punishment.

# 1239

Other than those polytheists with whom you had a treaty, and they have not diminished anything from your treaty nor supported anyone against you – therefore fulfil their treaty up to the appointed term; indeed Allah befriends the pious.

# 1240

Then when the sacred months have passed, slay the polytheists wherever you find them, and catch them and make them captive, and wait in ambush for them at every place; then if they repent and keep the prayer established and pay the charity, leave their way free; indeed Allah is Oft Forgiving, Most Merciful.

# 1241

And O dear Prophet (Mohammed – peace and blessings be upon him), if a polytheist seeks your protection, give him protection so that he may hear the Word of Allah, and then transport him to his place of safety; this is because they are an unwise people.

# 1242

How can there be a treaty with Allah and with His Noble Messenger for the polytheists, except for those with whom you made a treaty near the Sacred Mosque? So as long as they remain firm on the treaty for you, you too remain firm for them; indeed Allah is pleased with the pious.

# 1243

Therefore how – when they are such that if they gain control over you, they would not have regard for any relations nor for any treaty? They please you with their mouths whereas their hearts contain rejection; and most of them are disobedient.

# 1244

They exchanged the verses of Allah for an abject price, therefore prevented from His way; indeed what they do is extremely evil.

# 1245

In respect of the Muslims, they do not keep regard for any relations nor any pacts; it is they who are the rebels.

# 1246

Then if they repent and keep the prayer established and pay the charity, they are your brothers in religion; and we explain Our verses in detail for the people of knowledge.

# 1247

And if they break their promises after making a treaty and malign your religion, then fight the leaders of disbelief – indeed their promises are nothing – in the hope that they may desist.

# 1248

Will you not fight the people who broke their promises, and intended to expel the Noble Messenger whereas they had started it? Do you fear them? So Allah has more right that you should fear Him, if you have faith.

# 1249

So fight them – Allah will punish them at your hands, and He will disgrace them and assist you over them, and He will soothe the hearts of the believers.

# 1250

And He will remove the anxiety of their hearts; and Allah may accept the repentance of whomever He wills; and Allah is All Knowing, Wise.

# 1251

Are you under the illusion that you would be left just like this, whereas Allah has not yet made known those of you who will fight and not confide their secrets with anyone except Allah and His Noble Messenger and the Muslims? And Allah is Well Aware of your deeds.

# 1252

It does not befit the polytheists to assemble in Allah’s mosques after themselves bearing witness of their disbelief; in fact all their deeds are wasted; and they will remain in the fire forever.

# 1253

Only those enliven the mosques of Allah who believe in Allah and the Last Day and establish prayer and pay the obligatory charity and fear none except Allah – so it is likely that they will be among the people of guidance.

# 1254

So have they taken the quenching of the pilgrims’ thirst and servicing of the Sacred Mosque as equal (in merit) to him who accepted faith in Allah and the Last Day, and fought in Allah’s way? They are not equal before Allah; and Allah does not guide the unjust.

# 1255

Those who accepted faith, and left their homes and fought with their wealth and their lives in Allah’s way have a greater rank before Allah; and it is they who have succeeded.

# 1256

Their Lord gives them the glad tidings of His mercy and His pleasure, and the Gardens in which are everlasting favours for them.

# 1257

They will abide in it for ever and ever; indeed with Allah is the great reward.

# 1258

O People who Believe! Do not consider your fathers and your brothers as your friends if they prefer disbelief over faith; and whoever among you befriends them – then it is he who is the unjust.

# 1259

Say, “If your fathers, and your sons, and your brothers, and your wives, and your tribe, and your acquired wealth, and the trade in which you fear a loss, and the houses of your liking – if all these are dearer to you than Allah and His Noble Messenger and fighting in His way, then wait until Allah brings about His command; and Allah does not guide the sinful.”

# 1260

Indeed Allah helped you on many occasions – and on the day of Huneyn – when you prided in your multitude, so it did not benefit you at all, and the earth despite being vast became restricted for you – then you turned back and returned.

# 1261

Then Allah sent down His calm upon His Noble Messenger and upon the Muslims, and sent down armies you did not see, and punished the disbelievers; and such is the reward of the deniers.

# 1262

Then afterwards Allah will give repentance to whomever He wills; and Allah is Oft Forgiving, Most Merciful.

# 1263

O People who Believe! The polytheists are utterly filthy\*; so after this year do not let them come near the Sacred Mosque; and if you fear poverty\*\*, then Allah will soon make you wealthy with His grace, if He wills; indeed Allah is All Knowing, Wise. (\* Filthy in body and soul. \*\*Due to loss of trade.)

# 1264

Fight against the People given the Book(s) who do not accept faith in Allah and the Last Day, and who do not treat as forbidden what is forbidden by Allah and by His Noble Messenger, and who do not follow the true religion, until they pay the tariff with their own hands with humiliation.

# 1265

And the Jews said, “Uzair is the son of Allah”, and the Christians said “The Messiah is the son of Allah”; they utter this from their own mouths; they speak like the former disbelievers; may Allah kill them; where are they reverting!

# 1266

They have taken their rabbis and their monks as Gods besides Allah and (also) Messiah the son of Maryam; and they were not commanded except to worship only One God – Allah; none is worthy of worship except Him; Purity is to Him from all that they ascribe as partners (to Him).

# 1267

They wish to extinguish the light of Allah with their mouths, but Allah will not agree except that He will perfect His light, even if the disbelievers get annoyed.

# 1268

It is He Who has sent His Noble Messenger with guidance and the true religion, in order to prevail over all other religions – even if the polytheists get annoyed.

# 1269

O People who Believe! Indeed many of the (Jewish) rabbis and the (Christian) monks unjustly devour people's wealth and prevent from Allah’s way; and those who hoard up gold and silver and do not spend it in Allah’s way – so them give the glad tidings of a painful punishment.

# 1270

The day when it will be heated in the fire of hell, and their foreheads and their sides and their backs will be branded with them; “Here is what you hoarded for yourselves; so now taste the joy of your hoarding!”

# 1271

Indeed the number of months before Allah is twelve – in the Book of Allah – since the day He created the heavens and the earth, of which four are sacred; this the straight religion; so do not wrong yourselves in those months; and constantly fight against the polytheists as they constantly fight against you; and know well that Allah is with the pious.

# 1272

Their postponing of the months is nothing but furtherance in disbelief – the disbelievers are misled by it – they decree it lawful in one year and regard it forbidden in another year, in order to equate to the number of the months which Allah has made sacred, and to make lawful what Allah has forbidden; their evil deeds seem good in their sight; and Allah does not guide the disbelievers.

# 1273

O People who Believe! What is the matter with you, that when it is said to you, “Migrate in Allah's cause”, you sit on the ground with heaviness? Have you preferred this worldly life over the Hereafter? And the wealth of the life of this world, in comparison with the Hereafter, is but only a little.

# 1274

If you do not migrate, He will afflict you with a painful punishment and bring other people in your stead and you will not be able to harm Him in the least; and Allah is Able to do all things.

# 1275

If you do not help him (Prophet Mohammed – peace and blessings be upon him), Allah has helped him – when he had to go forth due to the mischief of the disbelievers, just as two men\* – when they were in the cave, when he was saying to his companion “Do not grieve; indeed Allah is with us”; then Allah caused His calm to descend upon him and helped him with armies you did not see, and disgraced the word of the disbelievers; and Allah’s Word is supreme; and Allah is the Almighty, the Wise. (\* The Holy Prophet migrated only with S. Abu Bakr (who later became the first caliph) as his sole companion.)

# 1276

Migrate – whether willingly or with a heavy heart and fight in Allah's cause with your wealth and your lives; this is better for you, if you realise.

# 1277

Had there been some wealth near at hand or a short journey, they would have certainly accompanied you, but the difficult path became very distant for them; and they will now swear by Allah that “Had we been able, we would have surely accompanied you”; they destroy their own souls; and Allah knows that undoubtedly, they are indeed liars.

# 1278

May Allah forgive you\*; why did you permit them\*\* until the truthful ones had been manifested to you and the liars been exposed? (\* This is an expression of love for the Holy Prophet – peace and blessings be upon him. \*\* The hypocrites had been permitted to stay back from the holy war.)

# 1279

And those who believe in Allah and the Last Day will not seek exemption from you for not fighting with their wealth and their lives; and Allah well knows the pious.

# 1280

Only those ask for such an exemption from you who do not believe in Allah and the Last Day, and whose hearts are in doubt – so they waver in their doubts.

# 1281

And if going forth were acceptable to them, they would have made preparations for it, but Allah Himself disliked their getting up (to fight) so He filled them with laze and it was said “Continue sitting with those who remain seated.”

# 1282

If they had gone forth among you, you would then not gain any increase from them except trouble, and seeking to cause turmoil they would run rumours among you; and their spies are among you; and Allah well knows the unjust.

# 1283

Indeed they had sought to cause turmoil at the outset, and O dear Prophet the scheme turned otherwise\* for you, so much so that the truth came and the command of Allah appeared, and they disliked it. (\* In your favour.)

# 1284

And among them is one who requests you that, “Grant me exemption (from fighting) and do not put me to test”; pay heed! They have indeed fallen into trial; and indeed hell surrounds the disbelievers.

# 1285

If good befalls you they dislike it; and were some calamity to befall you, they would say, “We had resolved our matters in advance”, and would turn away rejoicing.

# 1286

Say, O dear Prophet “Nothing shall befall us except what Allah has destined for us; He is our Master; and the Muslims must rely only on Allah.”

# 1287

Say, “What do you wait for to happen to us, except one of the two good things?\* And for you, we look forward to Allah afflicting you with a punishment from Himself or by our hands; so wait – we too await with you.” (\*Death in Allah’s way or victory.)

# 1288

Say, “Spend willingly or with a heavy heart, it will never be accepted from you; indeed you are a disobedient people.”

# 1289

And their spending was not stopped being accepted, except because they disbelieved in Allah and His Noble Messenger, and they come to prayer with heavy hearts, and they do not spend except unwillingly.

# 1290

So let not their riches or their children surprise you; Allah only intends to punish them in the life of this world with these things and that they die only as disbelievers.

# 1291

And they (the hypocrites) swear by Allah that they are from among you (Muslims); and they are not from among you – however those people are afraid.

# 1292

If they find some refuge, or caves, or a place to hide, they will break the bonds and return there.

# 1293

And among them is one who slanders you regarding the distribution of charity; so if they receive some of it they would be happy – and if not, thereupon they get displeased!

# 1294

How excellent it would be, if they were pleased with what Allah and His Noble Messenger had given them and said, “Allah suffices us; Allah will now give us by His munificence, and (so will) Allah’s Noble Messenger – and towards Allah only are we inclined.”

# 1295

The obligatory charity\* is only for the destitute and the really needy, and those who collect it, and for those in whose hearts the love of Islam needs to be instilled\*\*, and to free slaves, and to debtors, and in Allah's cause\*\*\*, and to the traveller; this is decreed by Allah; and Allah is All Knowing, Wise. (\* This applies only to Zakat. \*\* The new convert to Islam. \*\*\* To the fighter having no provisions for holy war.)

# 1296

And among them (the hypocrites) are those who trouble\* the Herald of the Hidden (the Prophet) and say, “He is only ears\*\*”; say “He is a listener for your good, he believes in Allah and believes in what the Muslims say, and is a mercy for the Muslims among you”; and for those who trouble the Noble Messenger of Allah, is a painful punishment. (\*To disrespect / trouble the Holy Prophet – peace and blessings be upon him – is blasphemy. \*\*He believes whatever he is told.)

# 1297

They swear by Allah in your presence in order to please you; whereas Allah – and His Noble Messenger – had more right that they should have pleased Him if they had faith.

# 1298

Do they not know that for one who opposes Allah and His Noble Messenger, is the fire of hell, to remain in it forever? This is the greatest humiliation.

# 1299

The hypocrites fear for a chapter being revealed regarding them, which may disclose what is hidden in their hearts; say, “Keep mocking; Allah will certainly disclose what you fear.”

# 1300

And if you ask them, they will say, “We were just having fun and pastime”; say, “What! You mock at Allah and His verses and His Noble Messenger?”

# 1301

“Do not feign excuses, you have turned disbelievers after becoming Muslims”; if We forgive some of you\*, We shall punish others because they were guilty. (\* One who kept quiet and later repented.)

# 1302

The hypocrite men and women are all the same; enjoining wrong and forbidding right, and being tight-fisted\*; they have forgotten Allah, so Allah has forsaken them; indeed the hypocrites – it is they who are really disobedient. (\* Not spending in Allah's cause)

# 1303

Allah has promised the hypocrite men and hypocrite women and the disbelievers, the fire of hell in which they will remain forever; that is sufficient for them; and Allah’s curse is upon them; and for them is a never ending punishment.

# 1304

Like those who were before you – they were mightier than you in strength, and had more wealth and children than you; so they spent their portion – you spent your portion just as those before you spent their portion and you fell into shame (sin) like they had fallen into shame; their deeds have been wasted in the world and in the Hereafter; it is they who are the losers.

# 1305

Did not the news of those before them reach them – the people of Nooh, and the A’ad, and the Thamud – the people of Ibrahim, the people of Madyan and the dwellings that were overturned? Their Noble Messengers had brought clear proofs to them; so it did not befit Allah’s Majesty to oppress them, but in fact they wronged themselves.

# 1306

And the Muslim men and Muslim women are the friends of one another; enjoining right and forbidding wrong, and keeping the prayer established and paying the obligatory charity, obeying Allah and His Noble Messenger; these are upon whom Allah will soon have mercy; indeed Allah is the Almighty, the Wise.

# 1307

Allah has promised the Muslim men and Muslim women, Gardens beneath which rivers flow – they will abide in it forever – and pure dwellings in Gardens of everlasting stay; and the greatest (reward) is Allah’s pleasure; this is the supreme success.

# 1308

O Herald of the Hidden! Fight against the disbelievers and the hypocrites, and be stern with them; and their destination hell; and what an evil place to return!

# 1309

And they swear by Allah that they did not say it; whereas indeed they had certainly uttered the words of disbelief, and after having entered Islam turned disbelievers and had wished for what they did not get; and what annoyed them except that Allah, and His Noble Messenger, made them prosperous with His grace? So if they repent, it is better for them; and if they turn away, Allah will afflict them with a painful punishment – in this world and the Hereafter; and they will have neither a protector nor any supporter in the entire earth.

# 1310

And among them are those who made a covenant with Allah that, “If He gives us by His munificence, we will surely give charity and surely become righteous.”

# 1311

Therefore when Allah gave them by His munificence, they hoarded it and turning their faces, went back.\* (\* Reneged on their promise).

# 1312

So following this, Allah put hypocrisy in their hearts until the day when they will meet Him – the result of their breaching the promise made to Allah, and because they lied.

# 1313

Do they not know that Allah knows their secrets and the schemes they whisper, and that Allah is the All Knowing of all the hidden?

# 1314

Those who find fault in the Muslims who give the charity wholeheartedly and in those who gain nothing except from their own toil – so they mock at them; Allah will punish them for their mocking; and for them is a painful punishment.

# 1315

Whether you (O dear Prophet Mohammed – peace and blessings be upon him) ask forgiveness for them\* or not ask forgiveness for them; even if you ask forgiveness for them seventy times, Allah will not forgive them; that is because they disbelieved in Allah and His Noble Messenger, and Allah does not guide the sinful. (\* for the hypocrites.)

# 1316

Those who were left behind rejoiced that behind the Noble Messenger of Allah they had remained seated, and they were unwilling to fight in Allah's cause with their lives or their wealth, and said “Do not venture out in the heat”; say, “The fire of hell is the hottest”; if only they understood!

# 1317

So they should laugh a little and weep much; the reward of what they used to earn.

# 1318

Then if Allah takes you back to a group of them and they seek permission from you to go out to fight, say to them, “You shall never go out with me nor ever fight with me against any enemy; you were happy to remain seated for the first time, therefore remain seated with those who stay behind.”

# 1319

And never offer funeral prayers for any of them\* who dies, nor stand by his grave\*\*; indeed they disbelieved in Allah and His Noble Messenger, and they died as sinners. (\* It is forbidden to offer funeral prayers for the hypocrites. \*\* To ask forgiveness for them).

# 1320

And do not be surprised at their wealth or their children; Allah only wills to torment them with it in this world, and that they pass away upon disbelief.

# 1321

And when a chapter is sent down that “Accept faith in Allah and fight along with His Noble Messenger”, the men of means among them seek exemption from you and say, “Leave us, for us to be with those who sit.”

# 1322

They preferred to be with the women who stay behind, and their hearts have been sealed, so they do not understand.

# 1323

But the Noble Messenger and those who accepted faith with him, fought with their wealth and lives; and for them only are the virtues (rewards); and it is they who have achieved the goal.

# 1324

Allah has kept ready for them Gardens beneath which rivers flow, abiding in it forever; this is the greatest success.

# 1325

And came the ignorant\* who make excuses seeking exemption, and those who lied to Allah and His Noble Messenger remained seated; a painful punishment will soon reach the disbelievers among them. (\* of faith)

# 1326

There is no reproach upon the old nor upon the sick nor upon those who do not have the means to spend, provided they remain faithful to Allah and His Noble Messenger; and there is no way of reproach against the virtuous; and Allah is Oft Forgiving, Most Merciful.

# 1327

Nor against those who humbly present themselves before you in order that you provide them a mount, and receive an answer from you that “I do not have any beast to carry you” – and so they turn back with eyes overflowing with tears, due to the sorrow that they could not find the means to spend.

# 1328

The way (of reproach) is only against those who seek exemption from you although they are rich; they preferred to be with the women who stay behind – and Allah has sealed their hearts, so they do not know anything.

# 1329

They will make excuses to you when you return to them; say, “Do not make excuses – we shall never believe you – Allah has given us your tidings; and Allah and His Noble Messenger will now see your deeds, and then you will return to Him Who knows everything, the hidden and the visible – He will inform you of all what you used to do.”

# 1330

They will now swear by Allah before you, when you return to them, in order that you do not pay attention to them; so do not bother about them; they are indeed filthy; and their destination is hell; the reward of what they used to earn.

# 1331

They swear before you that you may be pleased with them; so if you become pleased with them, then indeed Allah will never be pleased with the sinful.

# 1332

The ignorant are more severe in disbelief and hypocrisy, and deserve to remain ignorant of the commands which Allah has revealed to His Noble Messenger; and Allah is All Knowing, Wise.

# 1333

And some of the ignorant are those who when spending in Allah's cause consider it a ransom, and await the coming of the cycles (of misfortunes) upon you; upon them only is the evil cycle of misfortune; and Allah is All Hearing, All Knowing.

# 1334

And some villagers are those who believe in Allah and the Last Day, and consider the spending as the means of obtaining proximity to Allah and obtaining the prayers of the Noble Messenger; pay heed! Yes indeed it is the means of proximity for them; Allah will soon admit them into His mercy; indeed Allah is Oft Forgiving, Most Merciful.

# 1335

And leading everyone, the first are the Muhajirs\* and the Ansar\*\*, and those who followed them with virtue – Allah is pleased with them and they are pleased with Him, and He has kept ready for them Gardens beneath which rivers flow, to abide in it for ever and ever; this is the greatest success. (\* The immigrants. \*\*Those who helped the immigrants.)

# 1336

And some of the illiterates around you are hypocrites; and some of the people of Medinah; hypocrisy has become ingrained in them; you do not know them\*; We know them; We shall soon punish them twice\*\* – they will then be consigned towards the terrible punishment.\*\*\* (\*Until now or as well as We do. \*\* In life and in the grave \*\*\* of hell.)

# 1337

And there are others who have acknowledged their sins and mixed a good deed with another that was bad; it is likely that Allah will accept their repentance; indeed Allah is Oft Forgiving, Most Merciful.

# 1338

O dear Prophet (Mohammed – peace and blessings be upon him) take the obligatory charity from their wealth, by which you may cleanse them and make them pure, and pray in their favour; indeed your prayer is the contentment of their hearts; and Allah is All Hearing, All Knowing.

# 1339

Do they not know that Allah only accepts repentance of His bondmen and He takes the charity\* and that Allah only is the Most Acceptor of Repentance, the Most Merciful? (\* into His control.)

# 1340

And say “Keep on with your works – Allah will now see your deeds, and so will His Noble Messenger and the Muslims; and soon you will return to the One Who knows everything – the hidden and the visible – so He will inform you of what you used to do.”

# 1341

And some are kept waiting for Allah’s command – He may punish them or accept their repentance; and Allah is All Knowing, Wise.

# 1342

And those (hypocrites) who built a mosque to cause harm, and due to disbelief, and in order to cause divisions among the Muslims, and to await the one who is at the outset an opponent of Allah and His Noble Messenger; and they will surely swear that “We wished only good”; and Allah is witness that they are indeed liars.

# 1343

Never stand (for worship) in that mosque\*; indeed the mosque\*\* that has been founded on piety from the very first day deserves that you should stand in it; in it are the people who wish to thoroughly cleanse themselves; and Allah loves the clean. (\*The mosque built by the hypocrites. \*\* The mosque at Quba, built by the Holy Prophet and his companions. The merit of praying 2 Raka’ Nawafil in it is equal to the reward of an Umrah.)

# 1344

So is one who established his foundation upon the fear of Allah and upon His pleasure better, or the one who laid his foundation upon the brink of a falling precipice, so it fell along with him into the fire of hell? And Allah does not guide the unjust.

# 1345

The building which they erected will constantly keep disturbing their hearts unless their hearts are torn to pieces; and Allah is All Knowing, Wise.

# 1346

Indeed Allah has purchased from the Muslims their lives and their wealth in exchange of Paradise for them; fighting in Allah's cause, slaying and being slain; a true promise incumbent upon His mercy, (mentioned) in the Taurat and the Injeel and the Qur’an; who fulfils His promise better than Allah? Therefore rejoice upon your deal that you have made with Him; and this is the great success.

# 1347

Those who repent, those who worship, those who praise, those who fast, those who bow, those who prostrate, those who show right and forbid wrong and those who keep the limits of Allah in sight; and give glad tidings to the Muslims.

# 1348

It does not befit the Prophet and those who believe, to pray for the forgiveness of polytheists even if they may be their relatives, after it has become clear to them that they are the people of hell.

# 1349

And the seeking of forgiveness for his father (paternal uncle) by Ibrahim was only because of a promise he had made to him; then when it became clear to him that he was an enemy of Allah, Ibrahim broke off ties with him; indeed Ibrahim is surely very soft-hearted, most forbearing.

# 1350

And it does not befit Allah’s Majesty to send a nation astray after He has guided them until He has made clear to them what they should avoid; indeed Allah knows everything.

# 1351

Indeed for Allah only is the kingship of the heavens and the earth; He gives life and He gives death; and other than Allah, you have neither a Protector nor any Supporter.

# 1352

Indeed Allah’s mercy inclined towards the Herald of the Hidden, and the Muhajirs and the Ansar who stood by him in the time of hardship, after it was likely that the hearts of a group among them would turn away – He then inclined towards them with mercy; indeed He is Most Compassionate, Most Merciful upon them.

# 1353

And also upon the three who were kept in waiting; when the earth, vast as it is, was restricted for them, and they became weary of their own lives and became certain that there is no refuge from Allah except with Him; He then accepted their repentance in order that they remain repentant; indeed Allah is the Most Acceptor of Repentance, the Most Merciful.

# 1354

O People who Believe! Fear Allah, and be with the truthful.

# 1355

It did not befit the people of Medinah and the people of the villages around them, to stay behind the Noble Messenger of Allah, nor to consider their own lives dearer than his life; that is because the thirst or the pain or the hunger that afflicts them in Allah's cause, and the step they tread on a place that angers the disbelievers, and whatever harm they cause the enemy – a good deed is recorded for them in lieu of all of these; indeed Allah does not waste the wages of the virtuous.

# 1356

And whatever they spend, small or great, or any valley they cross – it is all recorded for them, so that Allah may reward them for their best deeds.

# 1357

And it is not possible for the Muslims that all of them go out; so it should be that a party from each group goes forth in order to gain knowledge in religion, and upon returning they warn their people in the hope that they may avoid.

# 1358

O People who Believe – fight the disbelievers who are near to you, and let them find severity in you, and know well that Allah is with the pious.

# 1359

And whenever a chapter is sent down, some of them say, “Whose faith among you has this promoted?” So it has promoted the faith of the believers and they are rejoicing!

# 1360

And for those in whose hearts is a disease, it has added filth to their filth, and they died as disbelievers.

# 1361

Do they not observe that they are tested once or twice every year? Yet they do not repent, nor do they heed advice!

# 1362

And whenever a chapter is sent down, one of them looks at the other; “Is there someone watching you?” – and then they turn away; Allah has inverted their hearts because they are a people who do not understand.

# 1363

Indeed there has come to you a Noble Messenger from among you – your falling into hardship aggrieves him, most concerned for your well being, for the Muslims most compassionate, most merciful.

# 1364

Then if they turn away, say (O dear Prophet Mohammed – peace and blessings be upon him), “Allah suffices me; there is no worship except for Him; only Him have I trusted, and He is the Lord Of The Great Throne.”

# 1365

Alif-Lam-Ra\*; these are verses of the Book of wisdom. (\*alphabets of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 1366

Are people amazed that We have sent to a man among them, the divine revelation that “Warn the people and convey glad tidings to the believers that for them with their Lord is the place\* of truth”? The disbelievers say, “Indeed he is an open magician.” (\* Positions of honour on the Day of Resurrection or in heaven.)

# 1367

Indeed your Lord is Allah Who created the heavens and the earth in six days, then as befits His Majesty, established Himself upon the Throne\* – He plans all matters; there is no intercessor except after His permission;\* such is Allah, your Lord – therefore worship Him; so do you not ponder? (\* Of Control over everything.\*\* Prophet Mohammed (peace and blessings be upon him) will be the first to be granted permission to intercede.)

# 1368

Towards Him only you all are to return; the promise of Allah; indeed He creates for the first time and then after its extinction creates it again, in order to give those who believe and do good deeds, the reward of justice; and for the disbelievers, boiling water to drink and a painful punishment – the recompense of their disbelief.

# 1369

It is He Who created the sun radiating and the moon shining and appointed positions for it, for you to know the number of the years, and the account; Allah has not created it except with the truth; He explains the verses in detail for the people of knowledge.

# 1370

Indeed in the alternation of the day and night, and all that Allah has created in the heavens and the earth, are signs for people who are pious.

# 1371

Indeed those who do not expect to meet Us and have preferred the worldly life and are content with it, and those who neglect Our signs, –

# 1372

Their destination is hell – the recompense of their deeds.

# 1373

Indeed those who accepted faith and did good deeds, their Lord will guide them due to their faith; rivers will flow beneath them in the Gardens of favours.

# 1374

Their prayers in it will be, “Purity is to You, O Allah” and their greetings in it will be, “Peace”; and the conclusion of their prayers is, “All praise is to Allah, the Lord Of The Creation.”

# 1375

Were Allah to send misfortune to the people as quickly as they hasten for the good\*, their appointed term would have been finished; so We leave those who do not expect to meet Us, to wander in their rebellion. (\* The way they wish the good to reach them quickly.)

# 1376

And when some hardship reaches man he prays to Us, while reclining and sitting and standing; and when We remove his hardship, he goes away as if he had never prayed to Us because of any hardship; this is how the deeds of the transgressors are made seeming good to them.

# 1377

And indeed We destroyed several generations before you when they crossed the limits – and their respective Noble Messengers came to them with clear proofs, but they were not such as would believe; this is how We reward the guilty.

# 1378

Then We appointed you as caliphs in the earth after them, in order that We might see what deeds you perform.

# 1379

And when Our clear verses are recited to them, the people who do not expect to meet Us say, “Bring a Qur’an other than this one, or change it”; say (O dear Prophet Mohammed – peace and blessings be upon him), “I do not have the right to change it on my own; I only follow what is divinely revealed to me; if I were to disobey my Lord\*, then I fear the punishment of the Great Day (of Resurrection). (\* Which is impossible.)

# 1380

Say, “Had Allah willed I would not have recited it to you nor would He have made it known to you; so before this\* I have spent an age among you; so do you not have sense?” (\* Before Allah’s command to recite the Qur’an to you.)

# 1381

So who is more unjust than one who fabricates a lie concerning Allah and denies His signs? Indeed the guilty shall never prosper.

# 1382

And they worship the thing other than Allah, which neither harms them nor benefits them\*, and they say, “These are our intercessors\*\* before Allah”; say, “What! You inform Allah of something which in His knowledge does not exist in the heavens or in the earth?” Purity and Supremacy are to Him, above their association. (\* Some things like the sun, stars, trees are useful but they too are created by Allah. Their worship will not benefit – in fact it is harmful \*\* Only the virtuous will be granted permission by Allah to intercede.)

# 1383

Mankind were only one nation\* and then they differed, and had it not been for a promise\*\* from your Lord, the matters in which they differed would have been decided here itself. (\* On one proper faith. \*\* The account on the Last Day.)

# 1384

And they say, “Why is not a sign sent down upon him from his Lord?” Proclaim, (O dear Prophet Mohammed – peace and blessings be upon him), “The hidden is only for Allah, therefore wait; I too am waiting with you.”

# 1385

And when We give mankind the taste of mercy after some hardship which had afflicted them, they immediately start conspiring against Our signs; proclaim, “The secret plan of Allah is the fastest”; indeed Our angels record your scheming.

# 1386

It is He Who transports you over the land and the sea; to the extent that when you are in ships – and the ships sail with them with a favourable breeze and they rejoice at it – a gust of strong wind reaches them and waves come to them from every side and they realise that they are surrounded, – thereupon they pray to Allah as His sincere bondmen that, “If You rescue us from this, we will surely be thankful.”

# 1387

Then when He rescues them, they start wrongfully committing oppression in the earth; O mankind! Your oppression is only a torment against yourselves; derive the benefit until you live in this world; you have then to return to Us and thereupon We shall show you your misdeeds.

# 1388

The example of the life of this world is similar to the water which We sent down from the sky, so due to it the earth’s vegetation grew in abundance – that which men and cattle eat; to the extent that when the earth has taken on her ornaments and is well beautified, and her owners thought that it is within their control, Our command came to it at night or at day – so We made it harvested as if it had not existed yesterday; this is how We explain the verses for the people who ponder.

# 1389

And Allah calls to the abode of peace, and guides whomever He wills on the Straight Path.

# 1390

For the people of virtue, is goodness and more than that; and neither will the blackness nor disgrace come upon their faces; it is they who are the people of Paradise; they will abide in it forever.

# 1391

And (for) those who earned evil\*, the recompense of evil is equal to it – and disgrace will come upon them; they will have no one to save them from Allah; as if their faces are covered with pieces of the dark night; it is they who are the people of the fire; they will remain in it forever. (\* The disbelievers.)

# 1392

And on the day when We raise all of them together, then say to the polytheists, “Stay in your place – you and your partners (false deities)”; so We shall separate them from the believers, and their partners will say to them, “When did you ever worship us!?”

# 1393

“Therefore Allah suffices as a Witness between us and you, that we were not even aware that you worshipped us!”

# 1394

Here will every soul come to know what it has sent ahead, and they will be returned to Allah – their true Master, and they will lose all that they used to fabricate.

# 1395

Say, (O dear Prophet Mohammed – peace and blessings be upon him), “Who provides you sustenance from the sky and the earth? Or Who is the Owner of the ears and the eyes? And Who brings forth the living from the dead and Who brings forth the dead from the living? And Who plans all matters?” So they will now say, “Allah”; therefore say, “Then why do you not fear?”

# 1396

So such is Allah, your True Lord; therefore what remains after the truth, except error? So where are you reverting?

# 1397

This is how the Word of your Lord is proved concerning the sinful, so they will not believe.

# 1398

Say, “Is there any one among your partners (false deities) that can create for the first time and then after its extinction, create it again?” Proclaim, “Allah creates for the first time and then after its extinction, creates it again – so where are you reverting?”

# 1399

Say, “Is there any among your partners that shows the right path?” Say, “Allah shows the right path; so who should be obeyed – the One Who shows the right path, or one who does not even find the right path unless he is guided? So what has happened to you? What sort of a judgement you impose!”

# 1400

And most of them do not follow anything except assumptions; indeed assumption does not serve the least purpose (in place) of the truth; indeed Allah knows their deeds.

# 1401

And this noble Qur’an is not such that anyone can invent it, without Allah revealing it – but it surely is a confirmation of the Books preceding it and is an explanation of all that is written on the (preserved) tablet – there is no doubt in it – it is from the Lord Of The Creation.

# 1402

What! They dare say that “He has fabricated it”? Say, “Then bring one chapter like it and, other than Allah, call everyone you can if you are truthful.”

# 1403

On the contrary, they denied the thing the knowledge of which they could not master, whereas they have not yet seen its outcome; similarly those before them had denied, therefore see what sort of fate befell the unjust!

# 1404

And among them is one who accepts faith in it, and among them is one who does not accept faith in it; and your Lord well knows the mischievous.

# 1405

And if they deny you, say, “For me are my deeds, and for you are your deeds; you have no concern with what I do, and I have no relation with what you do.”

# 1406

And among them are some who listen to you; so will you make the deaf hear even if they do not have any sense?

# 1407

And among them is one who gazes at you; so will you guide the blind\* even if they cannot perceive? (\* Deaf or blind to guidance.)

# 1408

Indeed Allah does not oppress men at all, but they do wrong themselves.

# 1409

And on the day when He will raise all of them together, as if they had never stayed on earth except for a moment during the day, they will recognise one another; for completely ruined are those who denied the meeting with Allah and were not on guidance.

# 1410

And whether We show you (O dear Prophet Mohammed – peace and blessings be upon him) part of what We promise them or whether We call you towards Us before it – in any case they have to return to Us – then Allah is the Witness of their deeds.

# 1411

And in every nation was a Noble Messenger (from Allah); so when their Noble Messenger came to them, they were judged with fairness, and they were not wronged.

# 1412

And they say, “When will this promise come, if you are truthful?”

# 1413

Say, “I have no autonomy to benefit or hurt myself, except what Allah wills\*; for every nation is a fixed promise; when their promise comes, they cannot postpone it nor can they advance it one moment. (\* To empower me.)

# 1414

Say, “What is your opinion – if His punishment comes upon you at night or during the day, so what is there in it for which the guilty are being hasty?”

# 1415

“So will you believe it only when it has occurred? What! You believe in it now, whereas you were impatient\* for it before? (\* Eagerly demanding for it to occur.)

# 1416

Then the unjust will be told, “Taste the punishment forever; and you will be repaid only what you used to earn.”

# 1417

And they ask you “Is it a reality\*?” Say, “Yes, by oath of my Lord, indeed surely it is a reality, and you will not be able to escape.” (\* The punishment of the hereafter.)

# 1418

And if each unjust soul owned everything that is in the earth, it would have certainly given it in order to redeem itself; and they secretly felt repentant when they saw the punishment; and it has been judged between them with fairness and they will not be wronged.

# 1419

Pay heed! Indeed everything that is in the heavens and the earth belongs only to Allah; pay heed! Indeed Allah’s promise is true, but most of them do not know.

# 1420

And He gives life and gives death, and towards Him you will return.

# 1421

O mankind! The advice has come to you from your Lord and a cure for the hearts – and guidance and mercy for believers.

# 1422

Say, “Upon Allah’s munificence and upon His mercy – upon these should the people rejoice”; that is better than all their wealth and possessions.

# 1423

Say, “What is your opinion – (regarding) the sustenance that Allah has sent down for you? So you have, on your own, deemed lawful and unlawful in it!”; say, “Has Allah given you permission for it, or do you fabricate a lie against Allah?”

# 1424

And what do they, who fabricate lies against Allah, assume will be their state on the Day of Resurrection? Indeed Allah is Most Munificent upon mankind, but most people are not thankful.

# 1425

And whatever work you (O dear Prophet Mohammed – peace and blessings be upon him) are engaged in and recite a part of the Qur’an from Him, and whatever you people do, We are Witness upon you from the time you begin it; and there is nothing in the earth or in the heaven worth the weight of the smallest particle hidden from your Lord, nor anything smaller or greater than it, which is not recorded in a clear Book.

# 1426

Pay heed! Indeed upon the friends of Allah is neither any fear, nor any grief. (The friends of Allah are the best in the creation.)

# 1427

Those who have accepted faith and practice piety.

# 1428

There are good tidings for them in the life of this world and in the Hereafter; the Words of Allah cannot change; this is the supreme success.

# 1429

And do not grieve at their speech (O dear Prophet Mohammed – peace and blessings be upon him); indeed all honour is for Allah and He is the All Hearing, the All Knowing.

# 1430

Indeed all those in the heavens and all those in the earth are in Allah’s control; and what do those who pray to the partners instead of Allah, follow? They do not follow anything except assumption, and they only make guesses.

# 1431

It is He Who created the night for you so that you may gain rest in it and the day giving sight; indeed in this are signs for the people who heed.

# 1432

They said, “Allah has created a son for Himself”- Purity is to Him! He is the Perfect (Unwanting, free of needs); to Him only belongs all whatever is in the heavens and all whatever is in the earth; “You do not have any proof of this; do you say a thing concerning Allah which you do not know?”

# 1433

Say, “Indeed those who fabricate lies against Allah will never succeed.”

# 1434

Enjoying a little in the earth, they have then to return to Us – We will then make them taste a severe punishment, the recompense of their disbelief.

# 1435

Read to them the story of Nooh; when he told his people, “O my people – if my standing here and reminding you of Allah’s signs have been intolerable for you – so I have trusted only Allah – then work jointly and strengthen your work along with your false deities, leaving no doubt regarding your work – then do whatever you can to me, and do not give me respite.”

# 1436

“Then if you turn away, I do not ask any fee from you; my reward is only upon Allah, and I am commanded to be of the Muslims.”

# 1437

In response they denied him, so We rescued him and those with him in the ship, and made them caliphs, and We drowned those who denied Our signs; therefore see what sort of fate befell those who had been warned!

# 1438

Then after him, We sent other Noble Messengers to their respective people – so they came to them with clear proofs – so they were not such as to believe in what they had denied before; this is how We set seals upon the hearts of rebels.

# 1439

Then after them, We sent Moosa and Haroon along with Our signs, to Firaun and his court members, so they were proud and were a guilty people.

# 1440

So when the truth came to them from Us, they said, “Indeed this is a clear magic.”

# 1441

Said Moosa, “What! You speak in this manner regarding the truth when it has come to you? Is this magic? And magicians never succeed.”

# 1442

They said, “Have you two come to us to revert us from what we found our fathers upon, and that the leadership in the land may only be for you two? And we shall never believe in you both.”

# 1443

And Firaun said, “Bring every expert magician to me.”

# 1444

So when the magicians came, Moosa said to them, “Cast whatever you intend to cast.”

# 1445

Therefore when they had cast, Moosa said, “This what you have brought, is magic; Allah will now make it void; indeed Allah does not make the works of the mischievous successful.”

# 1446

“And Allah will prove the truth by His Words, even if the guilty get annoyed.”

# 1447

So none accepted faith in Moosa, except a few descendants of his people, fearing Firaun and his court members, that they would force them to revert; and indeed Firaun was a rebel in the land; and indeed he crossed the limits.

# 1448

And Moosa said, “O my people! If you have accepted faith in Allah, then you should rely only upon Him, if you are Muslims.”

# 1449

They said, “We have relied only upon Allah; Our Lord! Do not make us a test\* for the unjust people.” (\* By giving them power over us.)

# 1450

“And with Your mercy, rescue us from the disbelievers.”

# 1451

And We sent the divine revelation to Moosa and his brother that, “Build houses for your people in Egypt and make your houses as places of worship, and keep the prayer established, and give glad tidings to the Muslims.”

# 1452

And Moosa prayed, “Our Lord! You have given Firaun and his chiefs adornment and wealth in the life of this world, our Lord, that they may lead astray from Your path; our Lord! Destroy their riches and harden their hearts so that they may not accept faith until they witness the painful punishment.”

# 1453

He said, “The prayer of you two is accepted, therefore remain firm, and do not follow the way of the unwise.”

# 1454

And We transported the Descendants of Israel across the sea, therefore Firaun and his army pursued them with rebellion and injustice; until when the drowning overcame him he cried, “I accept faith that there is no True God except the One in Whom the Descendants of Israel believe, and I am a Muslim.”

# 1455

“What! Now?\* Whereas you were disobedient from the start and you were mischievous!” (This was said to Firaun.\* Accepting faith at the time of death is of no use.)

# 1456

“This day We shall salvage your body so that you may be a sign for those after you; and indeed most people are neglectful of Our signs.”

# 1457

And indeed We provided the Descendants of Israel a place of honour, and bestowed good sustenance to them; and they did not fall into dispute except after the knowledge had come to them; indeed your Lord will judge between them on the Day of Resurrection concerning the matters in which they used to differ.

# 1458

And if you, O listener, have any doubt in what We have sent down towards you, then question those who have read the Book before you; undoubtedly, towards you has come the truth from your Lord, therefore do not be of those who doubt.

# 1459

And never be of those who denied the signs of Allah, for you will then be of the losers.

# 1460

Indeed those for whom the Word of your Lord has proved true, will not believe.

# 1461

Even if every sign comes to them, until they witness the painful punishment.

# 1462

So if only had there been one dwelling\* that believed and its belief would have benefited it – except the nation of Yunus (Jonah)! When they accepted faith, We removed the disgraceful punishment in the life of this world from them, and let them enjoy for a while. (\* That was destroyed after being warned.)

# 1463

And if your Lord willed, all those who are in the earth – everyone of them – would have accepted faith; so will you (O dear Prophet Mohammed – peace and blessings be upon him) force the people until they become Muslims?

# 1464

And no soul can accept faith except by the command of Allah; and He sets the punishment upon those who do not have sense.

# 1465

Proclaim, “Observe what is in the heavens and the earth”; and the signs and the Noble Messengers do not benefit the people who are not destined to believe.

# 1466

So what are they waiting for, except the days similar to the days of those who passed away before them? Say, “Then wait! I too am waiting with you.”

# 1467

Then We shall save Our Noble Messengers and the believers – this is it; it is incumbent upon Our mercy to save the Muslims.

# 1468

Say (O dear Prophet Mohammed – peace and blessings be upon him), “O people! If you are in doubt concerning my religion, then (know that) I will never worship those whom you worship instead of Allah – but I worship Allah Who will give you death; and I am commanded to be of the believers.”

# 1469

“And that ‘Set your face straight\* for religion, apart from all others; and never be of those who ascribe partners (to Allah)’.” (\* Your intention sincerely for religion.)

# 1470

“And other than Allah, do not worship that which cannot benefit you nor cause you harm; then if you do so, you would be of the unjust.” (\* Some things like the sun, stars, trees are useful but they too are created by Allah. Their worship will not benefit – in fact it is harmful.)

# 1471

“And if Allah afflicts you with some suffering, there is none who can remove it except Him; and if He wills good for you, there is none who can repel His munificence; He bestows it upon whomever He wills from among His bondmen; He is the Oft Forgiving, the Most Merciful.” (\* Help, cure, monetary aid etc., whatever benefit derived from any source, reaches us because Allah has given the source this power and is actually through the grace and mercy of Allah.)

# 1472

Say, “O people! The truth\* has come to you from your Lord; so whoever came to guidance, has come to guidance for his own benefit; and whoever strayed, has strayed for his own harm; and I am not a trustee over you.” (\* Prophet Mohammed – peace and blessings be upon him, or Islam or the Qur’an.)

# 1473

And (O dear Prophet Mohammed – peace and blessings be upon him) follow what is divinely revealed to you, and have patience till Allah gives His command; and He is the Best of Rulers.

# 1474

Alif-Lam-Ra\*; “This is a Book, the verses of which are full of wisdom – then explained in detail – from the Wise, the Well Aware.” (\* Alphabets of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 1475

“That do not worship anyone except Allah; indeed I am for you a Herald of Warning and Glad Tidings, from Him.”

# 1476

“And ask forgiveness from your Lord and incline towards Him in repentance, He will provide you excellent sustenance until the appointed time and will bestow superiority to every one who excels; and if you turn away, I then fear the punishment of the Great Day upon you.”

# 1477

“To Allah only you have to return, and He is Able to do all things.”

# 1478

Pay heed! They fold up their breasts in order to conceal from Allah; pay heed! Even when they fully cover themselves up with their clothes, Allah knows all that what hide and all what they disclose; indeed He knows what is in the hearts.

# 1479

And there is none that walks upon the earth whose sustenance does not depend on the mercy of Allah – He knows where it shall stay and where it shall be deposited; everything is in a clearly explaining Book.

# 1480

And it is He Who created the heavens and the earth in six days – and His Throne was upon the water – so that He might test you, as to who among you have the best deeds\*; and if you (O dear Prophet Mohammed – peace and blessings be upon him) say, “Indeed you will be raised again after death”, the disbelievers will surely say, “This is nothing but clear magic.” (\* The creation of all things is in order to test mankind.)

# 1481

And if We postpone the punishment upon them for a specified time, they will surely say, “What holds it back?” Pay heed! On the day when it comes upon them, it will not be averted from them, and the very punishment they mocked at will encompass them.

# 1482

And if We bestow man the enjoyment of some mercy from Us and later withdraw it from him; surely he is most despairing, ungrateful.

# 1483

And if We bestow upon him the enjoyment of a favour after a misfortune that had befallen him, he will surely say, “The evils have gone away from me”; indeed he is jubilant, boastful.

# 1484

Except those who patiently endured and did good deeds; for them is forgiveness, and a great reward.

# 1485

So will you forsake part of what is divinely revealed to you and be disheartened because they say, “Why has not a treasure been sent down along with him?”, or “An angel should have come with him”? You are purely a Herald of Warning\*; and Allah is the Guardian over all things. (\* Therefore do not grieve over their sayings.)

# 1486

What! They dare say that “He has fabricated it”? Say “Therefore bring ten fabricated chapters like these, and call on everyone you can other than Allah, if you are truthful.”

# 1487

So O Muslims, if they are unable to reply to this challenge of yours, then know well that it is sent down only with the knowledge of Allah; and that except Him, there is no real God; so will you now accept?

# 1488

Whoever desires the life of this world and its comforts, We shall give them the full reward for their deeds in it, and not make any reduction in it.

# 1489

These are the ones for whom there is nothing in the Hereafter except the fire; and all that they did there has gone to waste and all their deeds are destroyed.

# 1490

So is the one who is upon the clear proof\* from his Lord, and comes a witness upon it from Allah, and before it the Book of Moosa, a leader and a mercy; they accept faith in it; and whoever denies it from all the groups, then the fire is promised for him; so O listener, do not have any doubt concerning it; indeed it is the truth from your Lord; but most people do not believe. (\* The Jews who accepted faith in the Qur’an.)

# 1491

And who is more unjust than the one who fabricates a lie against Allah? They will be presented before their Lord, and the witnesses\* will say, “These are they who lied concerning their Lord; the curse of Allah be upon the unjust!” (\* The Prophets and angels.)

# 1492

Those who prevent from the way of Allah and wish deviation in it; and it is they who disbelieve in the Hereafter.

# 1493

They will not be able to escape in the earth, nor do they have any protecting friends apart from Allah; they will have punishment upon punishment; they were unable to hear, nor used to see. (\* Hear or see the truth.)

# 1494

It is they who put their souls into ruin, and they lost all that they used to fabricate.

# 1495

They will be, unnecessarily, the greatest losers in the Hereafter.

# 1496

Indeed those who believed and performed good deeds and directed themselves towards their Lord – they are the people of Paradise; they will abide in it forever.

# 1497

The example of the two groups is like one being blind and deaf, and the other seeing and hearing; are they equal in condition? So do you not ponder?

# 1498

And indeed We sent Nooh to his people that, “Indeed I am for you a clear Herald of Warning.”

# 1499

“That you must worship none except Allah; indeed I fear the punishment of the calamitous day upon you.”

# 1500

The chiefs of his people, who were disbelievers, said, “We see that you are just a mortal like us, and we do not see anyone following you except the most lowly among us, without insight; and we do not find any merit in you above us – in fact, we consider you liars.”

# 1501

He said, “O my people! What is your opinion – if I am on a clear proof from my Lord and He has bestowed mercy upon me from Him, so you remained blind towards it; shall we force it upon you although you dislike it?”

# 1502

“And O my people! I do not ask any wealth from you for it; my reward is only upon Allah, and I am not going to repel the Muslims; indeed they will meet their Lord, but I find you people completely ignorant.”

# 1503

“And O my people! Who would rescue me from Allah if I repel them? So do you not think?”

# 1504

“And I do not say to you, ‘I have the treasures of Allah’ nor that ‘I gain knowledge of the hidden’, nor do I say that, ‘I am an angel’ nor do I say to those whom your sights consider lowly, that Allah will never give them any good; Allah well knows what is in their hearts; if I do so, I would then be of the unjust.”

# 1505

They said, “O Nooh, you have disputed with us and disputed in the extreme, therefore bring upon us what you promise us, if you are truthful.”

# 1506

He said, “Allah will surely bring that upon you if He wills, and you will not be able to escape.”

# 1507

“And my advice will not benefit you if I wish you good, when Allah wills to keep you astray; He is your Lord and to Him you will return.”

# 1508

What! They dare say that, “He has fabricated it”? Say, “If I may have fabricated it, then my sin is upon me, and I am unconcerned with your sins.”

# 1509

And it was divinely revealed to Nooh that “None of your people will become Muslims, except those who have already accepted faith – therefore do not grieve at what they do.”

# 1510

“And build the ship in front of Us, and by Our command, and do not speak to Me regarding the unjust; they will surely be drowned.”

# 1511

And Nooh builds the ship; and whenever the chiefs of his people passed by him, they used to laugh at him; he said, “If you laugh at us, then a time will come when we will laugh at you just as you laugh.”

# 1512

“So now you will come to know – upon whom comes the punishment that disgraces him, and upon whom descends the punishment that continues forever.”

# 1513

To the extent that when Our command came and the oven overflowed, We said, “Board into the ship a couple – male and female – from every kind, and your family members, except those upon whom the Word has been passed\*, and all other Muslims”; and only a few Muslims were with him. (\* Whose fate has been sealed.)

# 1514

And he said, “Board it – upon Allah’s name is its movement and its stopping; indeed my Lord is surely Oft Forgiving, Most Merciful.”

# 1515

And the same carries them amid waves like mountains; and Nooh called out to his son whereas he was standing apart, “O my son! Embark along with us\*, and do not be with the disbelievers.” (\* As a Muslim.)

# 1516

He said, “I shall take the refuge of a mountain – it will save me from the water”; said Nooh, “Today there is none who can rescue from the punishment of Allah, except upon whom He has mercy”; and the wave came in between them, so he remained amongst the drowning.

# 1517

And it was commanded, “O earth, swallow your water and, O sky, stop” – and the water was dried up and the matter was completed – and the ship stopped upon the mount Al-Judi and it was said, “Away with the unjust nation!”

# 1518

And Nooh prayed to his Lord – submitted he, “My Lord! Indeed my son is also of my family, and surely Your promise is true and You are the Greatest Ruler of all.”

# 1519

He said, “O Nooh, he is not of your family; his deeds are most improper; therefore do not ask Me a thing of which you do not have knowledge; I advise you not to be unwise.”

# 1520

He submitted, “My Lord! I seek your refuge from asking you the thing of which I do not have knowledge; and if You do not forgive me and do not have mercy on me, I would then be a loser.”

# 1521

It was said, “O Nooh! Alight from the ship along with peace from Us and the blessings that are upon you and upon some groups that are with you; and some groups are those whom We shall let enjoy this world and then a painful punishment from Us will reach them.”

# 1522

These are the tidings of the hidden, which We reveal to you (O dear Prophet Mohammed – peace and blessings be upon him); you did not know them nor did your people, before this; therefore patiently endure; indeed the excellent fate is for the pious.

# 1523

And towards the people of A’ad, their fellow man Hud; he said, “O my people! Worship Allah – there is no other True God except Him; you are purely fabricators.”

# 1524

“O my people! I do not ask any fee from you for it; my reward is only upon Him Who has created me; so do you not have sense?”

# 1525

“And O my people! Seek forgiveness from your Lord, then incline towards Him in repentance – He will send abundant rain from the sky upon you and will give you much more strength than you have – and do not turn away committing crimes!”

# 1526

They said, “O Hud! You have not come to us with any proof and we will not forsake our deities upon your saying, nor will we believe you.”

# 1527

“We only say that you have been severely struck by one of our deities”; he said, “I make Allah a witness, and you all bear witness that I have no relation with whatever you ascribe (as partners to Allah)”-

# 1528

“Besides Him – therefore all of you scheme against me and do not give me respite.”

# 1529

“I rely upon Allah, Who is my Lord and your Lord; there is not a creature that walks, whose forelock is not in His control; indeed my Lord can be found on the Straight Path.”

# 1530

“Then if you turn away, I have conveyed to you what I was sent with towards you; and my Lord will bring others in your stead; and you will not be able to cause Him any harm; indeed my Lord is a Guardian over all things.”

# 1531

And when Our command came, We rescued Hud and the Muslims who were with him, by Our mercy; and We saved them from a severe punishment.

# 1532

And these are the A’ad – they denied the signs of their Lord and disobeyed His Noble Messengers and followed the commands of every stubborn disobedient.

# 1533

And a curse followed them in the world, and on the Day of Resurrection; pay heed! Indeed A’ad disbelieved in their Lord; away with A’ad, the people of Hud!

# 1534

And to the Thamud tribe, We sent their fellow man Saleh; he said, “O my people! Worship Allah, there is no other True God except Him; He created you from the earth and established you in it, so seek forgiveness from Him and incline towards Him in repentance; indeed my Lord is Close, Acceptor of Prayer.”

# 1535

They said, “O Saleh! You seemed very promising among us, before this – What! You forbid us from worshipping the deities of our forefathers? And indeed we have fallen into a deeply intriguing doubt concerning what you call us to.”

# 1536

He said, “O my people! What is your opinion – if I am on clear proof from my Lord and He has bestowed upon me mercy from Him, so who will rescue me from Allah if I disobey Him? So you will not increase anything for me, except loss!”

# 1537

“And O my people! This is the she-camel of Allah – a sign for you – so let her graze in Allah’s earth, and do not touch her with an evil intention for an imminent punishment will reach you.”

# 1538

In response they hamstrung her, he therefore said, “Enjoy a further three days in your homes; this is a promise that will not be untrue.”

# 1539

Therefore when Our command came, We rescued Saleh and the Muslims who were with him by Our mercy, and from the disgrace of that day; indeed your Lord is the Strong, the Almighty.

# 1540

And the terrible scream seized the unjust – so at morning they remained lying flattened in their homes.

# 1541

As if they had never lived there; indeed the tribe of Thamud disbelieved in their Lord; away with the Thamud!

# 1542

And indeed Our angels came to Ibrahim with glad tidings – they said, “Peace”; he answered, “Peace” and without delay brought a roasted calf.

# 1543

And when he saw their hands not reaching towards it, he thought they were pretending and inwardly started fearing them; they said, “Do not be afraid – we are sent to the people of Lut.”

# 1544

And his wife was standing by and she started laughing\*, so We gave her glad tidings regarding Ishaq, and following Ishaq, regarding Yaqub.\*\* (\* She was glad that the disbelieving people of Lut would be destroyed.\*\* The birth of these two.)

# 1545

She said, “Oh woe to me – will I bear a child whereas I am an old woman, and this my husband, is an old man? This is something really extraordinary.”

# 1546

The angels said, “Do you wonder at the command of Allah? Allah’s mercy and His blessings be upon you, O people of this house; indeed He only is Most Praiseworthy, Most Honourable.”

# 1547

And when Ibrahim’s fear abated and the glad tidings reached him, he argued with Us regarding the people of Lut.

# 1548

Indeed Ibrahim is most forbearing, very soft hearted, penitent.

# 1549

“O Ibrahim, turn away from this; indeed your Lord’s command has come; and indeed a punishment will come upon them, which will not be averted.”

# 1550

And when Our angels came to Lut, he was distressed for them and was disheartened due to them, and said, “This is a day of great hardship.”

# 1551

And his people came running towards him; and they were in the habit of committing evil deeds; he said, “O my people! These women of the tribe are my daughters\* – they are purer for you – therefore fear Allah and do not disgrace me in the midst of my guests; is there not even a single righteous man among you?” (\* The wives of those people.)

# 1552

They said, “You know that we have no right to the daughters of your tribe; and you obviously know what we desire.”

# 1553

He said, “If only I had the strength against you or were able to get the refuge of some strong support!”

# 1554

The angels said, “O Lut! We are the sent ones of your Lord – they cannot get to you, therefore during the night take your entire household with you – and not one of you may turn around and see – except your wife\*; she too will be afflicted with the same as they will be; indeed their promise is at morn; is not the morning imminent?” (\* She was a disbeliever and sided with the culprits.)

# 1555

So when Our command came, We turned that township upside down and showered it continuously with stones of fired clay.

# 1556

That are marked, in the custody your Lord; and those stones are not at all far from the unjust!

# 1557

And to Madyan their fellow man Shuaib; he said, “O my people! Worship Allah – there is no other True God except Him; and do not make reductions in measure and weight – indeed I see you prosperous, and I fear the punishment of the Besieging Day (of Resurrection) upon you.”

# 1558

“O my people! Measure and weigh in full with justice, and do not give the people their goods diminished, and do not roam about in the earth causing turmoil.”

# 1559

“That which remains from Allah’s bestowal is better for you, if you believe; and I am not at all a guardian over you.”

# 1560

They said, “O Shuaib! Does your prayer command you that we forsake the deities of our forefathers or that we may not do as we wish with our own property? Yes indeed – only you are very intelligent, most righteous\*.” (\* They mocked at him with sarcasm.)

# 1561

He said, “O my people! What is your opinion – if I am on a clear proof from my Lord and He has bestowed me with an excellent sustenance from Him (shall I ignore all this?); and the matter I forbid you to do, I do not wish that I myself act against it; I only intend to make improvements as far possible; my guidance is only from Allah; I rely only upon Him and towards Him only do I incline.”

# 1562

“And O my people! May not your opposition to me occasion the coming upon you of the thing similar to what befell the people of Nooh or the people of Hud or the people of Saleh; and the people of Lut are not at all far from you!”

# 1563

“Ask forgiveness from your Lord and then incline towards Him in repentance; indeed my Lord is Most Merciful, Most Affectionate.”

# 1564

They said, “O Shuaib! We do not understand most of what you say, and indeed we perceive you weak among us; were it not for your relatives, we would have stoned you; and in our sight, you have no respect at all.”

# 1565

He said, “O my people! Is the pressure upon you from my relatives, worth more than Allah? And you put Him\* behind your backs; indeed whatever you do is all within my Lords’ control.” (\* His command / my preaching.)

# 1566

“And O my people! Keep on with your works in your positions, I am doing mine; very soon you will come to know – upon whom comes the punishment that will disgrace him, and who is the liar; and wait – I too am waiting with you.”

# 1567

And when Our command came, We rescued Shuaib and the Muslims who were with him by Our mercy; and the terrible scream seized the unjust – so at morning they remained lying flattened in their homes.

# 1568

As if they had never lived there; away with the Madyan, just as the Thamud were removed afar!

# 1569

And indeed We sent Moosa with Our revelations and a clear domination.

# 1570

Towards Firaun and his court members, thereupon they followed the commands of Firaun; and the work of Firaun was not proper.

# 1571

He will lead his people on the Day of Resurrection, therefore landing them into hell; and what a wretched place to land into!

# 1572

And a curse followed them in the world, and on the Day of Resurrection; what a wretched gift is what they received.

# 1573

These are the tidings of the townships, which We relate to you (O dear Prophet Mohammed – peace and blessings be upon him) – some of them still stand and some are cut off.

# 1574

And We did not oppress them at all, but it is they who wronged themselves – therefore their deities, whom they worshipped other than Allah, did not in the least benefit them when your Lord’s command came; and due to them, they increased nothing but ruin.

# 1575

And similar is the seizure of your Lord when He seizes the townships upon their injustice; indeed His seizure is painful, severe.

# 1576

Indeed in this is a sign for one who fears the punishment of the Hereafter; this is the day on which everyone will be gathered, and this is the Day of Attendance.

# 1577

And We do not postpone it except for a fixed term.

# 1578

When that day comes, no one will speak without His permission; so among them are the ill-fated and the fortunate.

# 1579

So those who are ill-fated, are in the fire – they will bray like donkeys in it.

# 1580

Remaining in it as long as the heavens and the earth remain, except as much as your Lord willed\*; indeed your Lord may do whatever, whenever, He wills. (\* Remaining forever even after the heavens and the earth are destroyed.)

# 1581

So those who are fortunate are in Paradise – abiding in it as long as the heavens and the earth remain, except as much as your Lord willed; this is the everlasting favour.

# 1582

So O listener (followers of this Prophet), do not fall into doubt by what these disbelievers worship; they only worship just as their forefathers worshipped before; and indeed we shall pay them their due in full, undiminished.

# 1583

And indeed We gave Moosa the Book, hence there was discord regarding it; and were it not for a Word that had been previously passed from your Lord, the matter would have immediately been decided regarding them; and indeed they are in an intriguing doubt concerning it.

# 1584

And indeed to each and every one, your Lord will fully repay his deeds; He is Informed of their deeds.

# 1585

Therefore remain firm the way you are commanded to, and those who have turned along with you, and O people – do not rebel; indeed He is seeing your deeds.

# 1586

And do not incline towards the unjust, for the fire will touch you – and you do not have any supporter other than Allah – then you will not be helped.

# 1587

And keep the prayer established at the two ends of the day and in some parts of the night; indeed good deeds wipe out the evil deeds; this is an advice to those who heed it.

# 1588

And have patience, for Allah does not waste the wages of the righteous.

# 1589

So why were not there some people, from the generations before you, who had some goodness remaining in them in order to prevent (others) from causing turmoil in the earth? Except a few among them – the very ones whom We had rescued; and the unjust remained pursuing what they were given, and they were guilty.

# 1590

And your Lord is not such as to destroy townships without reason, while their people are righteous.

# 1591

And had your Lord willed, He would have made mankind one nation – and they will always keep differing.

# 1592

Except those upon whom your Lord had mercy; and this is why He created them; and the Word of your Lord has been concluded that, “Indeed I will, surely, fill hell with jinns and men combined.”

# 1593

And We relate to you all the accounts of Noble Messengers, in order to steady your heart with it; and in this the truth has come to you, and for the Muslims a preaching and advice.

# 1594

And say to the disbelievers, “Keep on with your works in your places; we are carrying out ours.”

# 1595

“And wait – we too are waiting.”

# 1596

“And for Allah only are the hidden of the heavens and of the earth, and towards Him only is the return of all matters – therefore worship Him and trust Him; and your Lord is not unaware of what you do.”

# 1597

Alif-Lam-Ra\*; these are verses of the clear Book. (\* Alphabets of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 1598

Indeed We have sent down an Arabic Qur’an, so that you may perceive.

# 1599

We relate to you the best narrative because We have sent the divine revelation of this Qur’an, to you; although surely you were unaware before this.

# 1600

Remember when Yusuf (Joseph) said to his father, “O my father! I saw eleven stars and the sun and the moon – I saw them prostrating to me.”

# 1601

He said, “O my child! Do not relate your dream to your brothers, for they will hatch a plot against you; indeed Satan is an open enemy towards mankind.”

# 1602

“And this is how your Lord will choose you and teach you how to interpret events, and will perfect His favours upon you and upon the family of Yaqub, the way He perfected it upon both your forefathers, Ibrahim and Ishaq; indeed your Lord is All Knowing, Wise.”

# 1603

Indeed in Yusuf and his brothers are signs\* for those who enquire\*\*. (\* Of the truthfulness of Prophet Mohammed – peace and blessings be upon him. \*\* The Jews who enquired about their story.)

# 1604

When they said, “Indeed Yusuf and his brother\* are dearer to our father than we are, and we are one group; undoubtedly our father is, clearly, deeply engrossed in love.” (\* Of the same mother.)

# 1605

“Kill Yusuf or throw him somewhere in the land, so that your father’s attention may be directed only towards you, and then after it you may again become righteous!”

# 1606

A speaker among them said, “Do not kill Yusuf – and drop him into a dark well so that some traveller may come and take him away, if you have to.”

# 1607

They said, “O our father! What is the matter with you that you do not trust us with Yusuf, although we are in fact his well-wishers?”

# 1608

“Send him with us tomorrow so that he may eat some fruits and play, and indeed we are his protectors.”

# 1609

He said, “I will indeed be saddened by your taking him away, and I fear that the wolf may devour him, whilst you are unaware of him.” (\* Prophet Yaqub knew of what was about to happen.)

# 1610

They said, “If the wolf devours him, whereas we are a group, then surely we are useless!”

# 1611

So when they took him away – and all of them agreed that they should drop him in the dark well; and We sent the divine revelation to him, “You will surely tell them of their deed at a time when they will not know.”

# 1612

And at nightfall they came to their father, weeping.

# 1613

Saying, “O our father! We went far ahead while racing, and left Yusuf near our resources – therefore the wolf devoured him; and you will not believe us although we may be truthful.”

# 1614

And they brought his shirt stained with faked blood; he said, “On the contrary – your hearts have fabricated an excuse for you; therefore patience is better; and from Allah only I seek help against the matters that you relate.”

# 1615

And there came a caravan – so they sent their water-drawer, he therefore lowered his pail; he said, “What good luck, this is a boy!”; and they hid him as a treasure; and Allah knows what they do.

# 1616

And the brothers sold him for an improper price, a limited number of coins; and they had no interest in him.

# 1617

And the Egyptian who purchased him said to his wife, “Keep him honourably – we may derive some benefit due to him or we may adopt him as our son”; and this is how we established Yusuf in the land, and that We might teach him how to interpret events; and Allah is Dominant upon His works, but most men do not know.

# 1618

And when he matured to his full strength, We bestowed him wisdom and knowledge; and this is how We reward the virtuous.

# 1619

And the woman in whose house he was, allured him not to restrain himself and she closed all the doors – and said, “Come! It is you I address!”; he said, “(I seek) The refuge of Allah – indeed the governor is my master – he treats me well; undoubtedly the unjust never prosper.”

# 1620

And indeed the woman desired him; and he too would have desired her were he not to witness the sign of his Lord\*; this is what We did, to turn away evil and lewdness from him; indeed He is one of Our chosen bondmen. (\* Allah saved him and he never desired this immorality.)

# 1621

And they both raced towards the door, and the woman tore his shirt from behind, and they both found her husband at the door; she said, “What is the punishment of the one who sought evil with your wife, other than prison or a painful torture?”

# 1622

Said Yusuf, “It was she who lured me, that I may not guard myself” – and a witness from her own household testified; “If his shirt is torn from the front, then the woman is truthful and he has spoken incorrectly.”

# 1623

“And if his shirt is torn from behind, then the woman is a liar and he is truthful.”

# 1624

So when the governor saw his shirt torn from behind, he said, “Indeed this is a deception of women; undoubtedly the deception of women is very great.”

# 1625

“O Yusuf! Disregard this – and O woman! Seek forgiveness for your sin; indeed you are of the mistaken.”

# 1626

And some women of the city said, “The governor’s wife is seducing her young slave; indeed his love has taken root in her heart; and we find her clearly lost.”

# 1627

And when she heard of their secret talk, she sent for them and prepared cushioned mattresses for them and gave a knife to each one of them and said to Yusuf, “Come out before them!” When the women saw him they praised him and cut their hands, and said, “Purity is to Allah – this is no human being; this is not but an honourable angel!”

# 1628

She said, “This is he on whose account you used to insult me; and indeed I tried to entice him, so he safeguarded himself; and indeed if he does not do what I tell him to, he will surely be imprisoned, and will surely be humiliated.”

# 1629

He said, “O my Lord! Prison is dearer to me than the deed they invite me to; and if You do not repel their deceit away from me, I may incline towards them and be unwise.”

# 1630

So his Lord heard his prayer and repelled the women’s deceit away from him; indeed He only is the All Hearing, the All Knowing.

# 1631

Then after having seeing all the signs, they all decided that he should be imprisoned for some time.

# 1632

And two young men went to prison along with him; one of them said, “I dreamt that I am pressing wine”; the other said, “I dreamt that I am carrying some bread upon my head from which birds were eating”; “Tell us their interpretation; indeed we see that you are virtuous.”

# 1633

Said Yusuf, “The food which you get will not reach you, but I will tell you the interpretation of this before it comes to you; this is one of the sciences my Lord has taught me; indeed I did not accept the religion of the people who do not believe in Allah and are deniers of the Hereafter.”

# 1634

“And I have chosen the religion of my forefathers, Ibrahim and Ishaq and Yaqub; it is not rightful for us to ascribe anything as a partner to Allah; this is a grace of Allah upon us and upon mankind, but most men are not thankful.”

# 1635

“O both my fellow-prisoners! Are various lords better, or One Allah, the Dominant above all?”

# 1636

“You do not worship anything besides Him, but which are merely names coined by you and your forefathers – Allah has not sent down any proof regarding them; there is no command but that of Allah; He has commanded that you do not worship anyone except Him; this is the proper religion, but most people do not know.”

# 1637

“O my two fellow-prisoners! One of you will give his lord (the king) wine to drink; regarding the other, he will be crucified, therefore birds will eat from his head; the command has been given concerning the matter you had enquired about.”

# 1638

And of the two, Yusuf said to the one whom he sensed would be released, “Remember me, in the company of your lord”; so Satan caused him to forget to mention Yusuf to his lord, he therefore stayed in prison for several years more.

# 1639

And the king said, “I saw in a dream seven healthy cows whom seven lean cows were eating, and seven green ears of corn and seven others dry; O court-members! Explain my dream, if you can interpret dreams.”

# 1640

They answered, “These are confused dreams – and we do not know the interpretation of dreams.”

# 1641

And of the two the one who was released said – and after a long time he had remembered – “I will tell you its interpretation, therefore send me forth.”

# 1642

“O Yusuf! O truthful one! Explain for us the seven healthy cows which seven lean cows were eating and the seven green ears of corn and seven others dry, so I may return to the people, possibly they may come to know.”

# 1643

He said, “You will cultivate for seven years continuously; so leave all that you harvest in the ear, except a little which you eat.”

# 1644

“Then after that will come seven hard years which will devour all that you had stored for them, except a little which you may save.”

# 1645

“Then after that will come a year when the people will be given rain and in which they will extract juices.”

# 1646

And the king said, “Bring him to me”; so when the bearer came to him, Yusuf said, “Return to your lord and ask him what is the status of the women who had cut their hands; indeed my Lord knows their deception.”

# 1647

The king said, “O women! What was your role when you tried to entice Yusuf?” They answered, “Purity is to Allah – we did not find any immorality in him”; said the wife of the governor, “Now the truth is out; it was I who tried to entice him, and indeed he is truthful.”

# 1648

Said Yusuf, “I did this so that the governor may realise that I did not betray him behind his back, and Allah does not let the deceit of betrayers be successful.”

# 1649

“And I do not portray my soul as innocent; undoubtedly the soul excessively commands towards evil, except upon whom my Lord has mercy; indeed my Lord is Oft Forgiving, Most Merciful.”

# 1650

And the king said, “Bring him to me so that I may choose him especially for myself”; and when he had talked to him he said, “Indeed you are today, before us, the honourable, the trusted.”

# 1651

Said Yusuf, “Appoint me over the treasures of the earth; indeed I am a protector, knowledgeable.”

# 1652

And this is how We gave Yusuf the control over that land; to stay in it wherever he pleased; We may convey Our mercy to whomever We will, and We do not waste the wages of the righteous.

# 1653

And undoubtedly the reward of the Hereafter is better, for those who accept faith and remain pious.

# 1654

And Yusuf’s brothers came and presented themselves before him, so he recognised them whereas they remained unaware of him.

# 1655

And when he provided them with their provisions he said, “Bring your step-brother to me; do you not see that I measure in full and that I am the best host?”

# 1656

“And if you do not bring him to me, there shall be no measure (provisions) for you with me and do not ever come near me.”

# 1657

They said, “We will seek him from his father – this we must surely do.”

# 1658

He said to his slaves, “Place their means back into their sacks, perhaps they may recognise it when they return to their homes, perhaps they may come again.”

# 1659

So when they returned to their father, they said, “O our father! The provisions have been denied to us, therefore send our brother with us so that we may bring the provisions, and we will surely protect him.”

# 1660

He said, “Shall I trust you regarding him the same way I had trusted you earlier regarding his brother? Therefore Allah is the Best Protector; and He is More Merciful than all those who show mercy.”

# 1661

And when they opened their belongings they found that their means had been returned to them; they said, “O our father! What more can we ask for? Here are our means returned to us; we may get the provision for our homes and guard our brother, and get a camel-load extra; giving all these is insignificant for the king.”

# 1662

He said, “I shall never send him with you until you give me an oath upon Allah that you will bring him back to me, unless you are surrounded”; and (recall) when they gave him their oath that “Allah’s guarantee is upon what we say.” (\* He knew that Bin Yamin would be restrained.)

# 1663

And he said, “O my sons! Do not enter all by one gate – and enter by different gates; I cannot save you against Allah; there is no command but that of Allah; upon Him do I rely; and all those who trust, must rely only upon Him.”

# 1664

And when they entered from the place where their father had commanded them to; that would not at all have saved them against Allah – except that it was Yaqub’s secret wish, which he fulfilled; and indeed he is a possessor of knowledge, due to Our teaching, but most people do not know.

# 1665

And when they entered in the company Yusuf, he seated his brother close to him and said, “Be assured, I really am your brother – therefore do not grieve for what they do.”

# 1666

And when he had provided them their provision, he put the drinking-cup in his brother’s bag, and then an announcer cried, “O people of the caravan! You are indeed thieves!”

# 1667

They answered and turned towards them, “What is it you cannot find?”

# 1668

They said, “We cannot find the king’s cup, and for him who brings it is a camel-load, and I am its guarantor.”

# 1669

They said, “By Allah, you know very well that we did not come here to cause turmoil in the land, and nor are we thieves!”

# 1670

They said, “And what shall be the punishment for it, if you are liars?”

# 1671

They said, “The punishment for it is that he in whose bag it shall be found, shall himself become a slave for it; this is how we punish the unjust.”

# 1672

So he first searched their bags before his brother’s bag, then removed it from his brother’s bag; this was the plan We had taught Yusuf; he had no right to take his brother by the king’s law, except if Allah wills; We may raise in ranks whomever We will; and above every possessor of knowledge is another scholar.

# 1673

They said, “If he steals, then indeed his brother has stolen before”; so Yusuf kept this in his heart and did not reveal it to them; he replied within himself, “In fact, you are in a worse position; and Allah well knows the matters you fabricate.”

# 1674

They said, “O governor! He has a very aged father, so take one of us in his stead; indeed we witness your favours.”

# 1675

He said, “The refuge of Allah from that we should take anyone except him with whom our property was found – we would then surely be unjust.”

# 1676

So when they did not anticipate anything from him, they went away and started consulting each other; their eldest brother said, “Do you not know that your father has taken from you an oath upon Allah, and before this, how you had failed in respect of Yusuf? Therefore I will not move from here until my father permits or Allah commands me; and His is the best command.”

# 1677

“Return to your father and then submit, ‘O our father! Indeed your son has stolen; we were witness only to what we know and we were not guardians of the unseen.’

# 1678

‘And ask the township in which we were, and the caravan in which we came; and indeed we are truthful.’”

# 1679

Said Yaqub, “Your souls have fabricated an excuse for you; therefore patience is excellent; it is likely that Allah will bring all\* of them to me; undoubtedly only He is the All Knowing, the Wise.” (\* All three including Yusuf.)

# 1680

And he turned away from them and said, “Alas – the separation from Yusuf!” and his eyes turned white with sorrow, he therefore kept suppressing his anger.

# 1681

They said, “By Allah, you will keep remembering Yusuf till your health fails you or you lose your life.”

# 1682

He said, “I complain of my worry and grief only to Allah, and I know the great traits of Allah which you do not know.”

# 1683

“O my sons, go and search for Yusuf and his brother, and do not lose hope in the mercy of Allah; indeed none lose hope in the mercy of Allah except the disbelieving people.”

# 1684

Then when they reached in the company of Yusuf they said, “O governor! Calamity has struck us and our household, and we have brought goods of little value, so give us the full measure and be generous to us; undoubtedly Allah rewards the generous.”

# 1685

He said, “Are you aware of what you did to Yusuf and his brother when you were unwise?”

# 1686

They said, “Are you, in truth you, really Yusuf?” He said, “I am Yusuf and this is my brother; indeed Allah has bestowed favour upon us; undoubtedly whoever practices piety and patience – so Allah does not waste the wages of the righteous.”

# 1687

They said, “By Allah, undoubtedly Allah has given you superiority over us, and we were indeed guilty.”

# 1688

He said, “There is no reproach on you, this day! May Allah forgive you – and He is the Utmost Merciful, of all those who show mercy.”

# 1689

“Take along this shirt of mine and lay it on my father’s face, his vision will be restored; and bring your entire household to me.” (Prophet Yusuf knew that this miracle would occur.)

# 1690

When the caravan left Egypt, their father said\*, “Indeed I sense the fragrance of Yusuf, if you do not call me senile.” (\* Prophet Yaqub said this in Palestine, to other members of his family. He could discern the fragrance of Prophet Yusuf’s shirt from far away.)

# 1691

They said, “By Allah, you are still deeply engrossed in the same old love of yours.”

# 1692

Then when the bearer of glad tidings came, he laid the shirt on his face, he therefore immediately regained his eyesight\*; he said, “Was I not telling you? I know the great traits of Allah which you do not know!” (This was a miracle that took place by applying Prophet Yusuf’s shirt.)

# 1693

They said, “O our father! Seek forgiveness for our sins, for we were indeed guilty.”

# 1694

He said, “I shall soon seek forgiveness for you from my Lord; indeed He only is the Oft Forgiving, the Most Merciful.”

# 1695

So when they all reached in Yusuf’s company, he kept his parents close to him, and said, “Enter Egypt, if Allah wills, in safety.”

# 1696

And he seated his parents on the throne, and they all prostrated before him; and Yusuf said, “O my father! This is the interpretation of my former dream; my Lord has made it true; and indeed He has bestowed favour upon me, when He brought me out of prison and brought you all from the village, after Satan had created a resentment between me and my brothers; indeed my Lord may make easy whatever He wills; undoubtedly He is the All Knowing, the Wise.”

# 1697

“O my Lord! you have given me a kingdom\* and have taught me how to interpret some events; O Creator of the heavens and the earth – you are my Supporter in the world and in the Hereafter; cause me to die as a Muslim, and unite me with those who deserve Your proximity.” (\* Prophethood and the rule over Egypt. Prophet Yusuf said this prayer while his death approached him.)

# 1698

These are some tidings of the Hidden which We divinely reveal to you (O dear Prophet Mohammed – peace and blessings be upon him); and you were not with them when they set their task and when they were scheming.

# 1699

And however much you long for, most men will not accept faith.

# 1700

You do not ask them any fee in return for it; this is not but an advice to the entire world.

# 1701

And how many signs exist in the heavens and the earth, over which most people pass and remain unaware of them!

# 1702

And most of them are such that they do not believe in Allah except while ascribing partners (to Him)!

# 1703

Do they remain complacent over Allah’s punishment coming and surrounding them, or the Last Day coming suddenly upon them whilst they are unaware?

# 1704

Proclaim, “This is my path – I call towards Allah; I, and whoever follows me, are upon perception; and Purity is to Allah – and I am not of the polytheists.”

# 1705

And all the Noble Messengers We sent before you, were exclusively men – towards whom We sent the divine revelations, and were dwellers of townships; so have not these people travelled in the land and seen what sort of fate befell those before them? And undoubtedly the abode of the Hereafter is better for the pious; so do you not have sense?

# 1706

To the extent that when the Noble Messengers lost hope from the visible means, and the people thought that they had spoken wrongly, Our help came to them – therefore whoever We willed was saved; and Our punishment is never averted from the guilty.

# 1707

Indeed in their tidings is enlightenment for the men of understanding; this (the Qur’an) is not some made up story but a confirmation of the Books before it, and a detailed explanation of all things, and a guidance and a mercy for the Muslims.

# 1708

Alif-Lam-Meem-Ra\*; these are verses of the Book; and that which has been sent down upon you from your Lord is true, but most men do not believe. (\* Alphabets of the Arabic language – Allah and to whomever He reveals, know their precise meanings.)

# 1709

It is Allah Who raised up the heavens without columns for you to observe, then (in the manner befitting His Majesty) established Himself upon the Throne (of control), then subjected the sun and the moon; each one runs for up to an appointed term; Allah plans the works and explain the signs in detail, so that you may believe in meeting with your Lord.

# 1710

And it is He Who spread out the earth and made mountains as anchors and rivers in it; and in it made all kinds of fruits in pairs – He covers the night with the day; indeed in this are signs for people who ponder.

# 1711

And in the earth are various regions, and are close to each other – and gardens of grapes and fields, and date-palms, growing from a single branch and separately, all being given one water; and in fruits, We make some better than others in eating; indeed in this are signs for people of intellect.

# 1712

And if you are amazed, then indeed the amazement is at their saying that, “Will we, after having turned to dust, be created anew?” They are those who have disbelieved in their Lord; and they are those who will have shackles around their necks; and they are the people of hell; remaining in it forever.

# 1713

And they urge you to hasten the punishment before the mercy, whereas the punishments of those before them have concluded; and indeed your Lord gives the people a sort of pardon\* despite their injustice; and indeed the punishment of your Lord is severe. (\* By delaying their punishment despite their disbelief.)

# 1714

The disbelievers say, “Why is not a sign sent down upon him from his Lord?” You are purely a Herald of Warning, and a guide for all nations.

# 1715

Allah knows all what is inside the womb of every female, and every increase and decrease of the wombs; and all things are with Him by a set measure.

# 1716

The All Knowing of all things hidden and visible, the Great, the Supreme.

# 1717

Equal\* are the one among you who speaks softly and one who speaks aloud, and one who is hidden during the night and one who walks during the daytime. (\* For Allah.)

# 1718

For man are angels of alternating duties, in front and behind him, who guard him by Allah’s command; indeed Allah does not change His favour upon any nation until they change their own condition; and when Allah wills misfortune for a nation, it cannot be repelled; and they do not have any supporter besides Him.

# 1719

It is He Who shows you the lightning, for fear and for hope, and raises the heavy clouds.

# 1720

And the thunder proclaims His purity with praise, and the angels out of fear of Him; and He sends the bolt of lightning – it therefore strikes upon whom He wills, whilst they are disputing concerning Allah; and severe is His seizure.

# 1721

Only the prayer to Him is truthful; and whomever they pray to besides Him, do not hear them at all, but like one who has his hands outstretched towards water that it may come into his mouth, and it will never come; and every prayer of the disbelievers remains wandering.

# 1722

And to Allah only prostrate all those who are in the heavens and in the earth, willingly or helplessly – and their shadows – every morning and evening. (Command of prostration # 2).

# 1723

Say (O dear Prophet Mohammed – peace and blessings be upon him), “Who is the Lord of the heavens and the earth?” Proclaim, “Allah”; Say, “So have you appointed such as supporters besides Him, who can neither benefit nor harm themselves?”; say, “Will the blind and the sighted ever be equal? Or will the realms of darkness and the light ever be equal?” Have they appointed such as partners to Allah who created something like Allah did? Therefore their creation and His creation seemed alike to them? Proclaim, “Allah is the Creator of all things, and He Alone is the Dominant over all.”

# 1724

He sent down water from the sky, so valleys flowed according to their measure, therefore the water flow brought forth the froth swollen upon it; and upon which they ignite the fire, to make ornaments and tools, from that too rises a similar froth; Allah illustrates that this is the example of the truth and the falsehood; the froth then bursts and disappears; and that which is of use to people, remains in the earth; this is how Allah illustrates the examples.

# 1725

For those who obeyed the command of Allah is goodness and if those who did not obey Him owned all that is in the earth and in addition a similar one like it, they would give it to redeem their souls; it is they who will have a wretched account, and their destination is hell; and what a wretched resting place!

# 1726

So will he, who knows that what is sent down upon you from your Lord is the truth, ever be equal to him who is blind? Only the men of understanding heed advice.

# 1727

Those who fulfil the pact of Allah, and do not renege on the covenant.

# 1728

Those who unite what Allah has commanded to be united, and fear their Lord, and apprehend the evil of the account.

# 1729

Those who were patient in order to gain their Lord’s pleasure and kept the prayer established and spent in Our cause part of what We bestowed upon them, secretly and openly, and repel evil by responding with goodness – for them is the gain of the final abode.

# 1730

The everlasting Gardens of Eden which they will enter, and the deserving among their forefathers and their wives and their descendants – the angels will enter upon them from every gate.

# 1731

(Saying), “Peace be upon you, the recompense of your patience – so what an excellent gain is the final abode!”

# 1732

And those who break the pact of Allah after its ratification, and sever what Allah has commanded to be joined, and spread turmoil in the earth – their share is only the curse and their destiny is the wretched abode.

# 1733

Allah eases and restricts the sustenance for whomever He wills; and the disbelievers rejoiced upon the life of this world; and the life of this world, as compared with the Hereafter, is just a brief utilisation.

# 1734

And the disbelievers said, “Why was not a sign sent down upon him from his Lord?” Proclaim, “Indeed Allah sends astray whomever He wills, and guides towards Himself the one who comes towards Him.”

# 1735

“Those who accepted faith and whose hearts gain solace from the remembrance of Allah; pay heed! Only in the remembrance of Allah is the solace of hearts!”

# 1736

“Those who accepted faith and did good deeds – for them is joy and an excellent outcome.”

# 1737

Similarly We sent you (O dear Prophet Mohammed – peace and blessings be upon him) towards the nation, before whom other nations have passed away, for you to recite to them the divine revelations We sent down to you, whereas they are denying the Most Gracious; proclaim, “He is my Lord – there is no worship except for Him; I rely only upon Him and only towards Him is my return.”

# 1738

And were such a Qur’an to come that would cause the mountains to move, or the earth to split asunder, or the dead to speak, even then these disbelievers would not believe; in fact, all matters are only at Allah’s discretion; so have not the Muslims despaired in that, had Allah willed, He would have guided all mankind? Disasters shall continue to strike the disbelievers on account of their deeds, or descend near their homes until Allah’s promise comes; indeed Allah does not break the promise.

# 1739

And indeed the Noble Messengers before you were also mocked – I therefore gave the mockers respite for some days and then seized them; so how (dreadful) was My punishment!

# 1740

So is He who keeps a watch over the deeds of every soul (equal to their appointed partners)? And (yet) they ascribe partners to Allah! Proclaim, “Just name them – or is it that you inform Him of something which in His knowledge does not exist in the earth – or is it just superficial talk?” In fact, their deceit seems good to the disbelievers and are prevented from the path; and whomever Allah sends astray, so there is none to guide him.

# 1741

They will be punished in the life of this world, and indeed the punishment of the Hereafter is the most severe; and there is none to save them from Allah.

# 1742

A description of the Paradise which is promised to the pious; rivers flow beneath it; its fruits are unending, and its shade; this is the reward of those who fear; and the fate of the disbelievers is fire.

# 1743

And those to whom We gave the Book\* rejoice at what is divinely revealed to you\*\*; and of those groups are some who deny parts of it; proclaim, “I am commanded only that I worship Allah and not ascribe any partner to Him; towards Him do I call, and towards Him only I have to return.” (\* Scholars among the Jews and Christians who accepted faith. \*\* The Holy Qur’an.)

# 1744

And similarly We have revealed this as a command in Arabic; and O listener (follower of this Prophet), if you follow their desires after the knowledge having come to you, then you will have neither a supporter nor any saviour against Allah.

# 1745

And indeed We sent Noble Messengers before you, and made wives and children for them; and it is not the task of any Noble Messenger to bring a sign except by Allah’s command; and all promises have a time prescribed.

# 1746

Allah erases and confirms whatever He wills; and only with Him is the real script.

# 1747

And whether We show you a promise that is given to them, or call you to Us before it – so in any case, upon you is just the conveyance\*, and for Us is the taking of the account. (\* Of the message.)

# 1748

Do they not perceive that We are reducing their dwellings from all directions? And Allah gives the command – there is none that can postpone His command; and He spends no time in taking account.

# 1749

And indeed those before them had plotted; therefore Allah Himself is the Master of all strategies; He knows all what every soul earns; and soon will the disbelievers realise for whom is the final abode.

# 1750

The disbelievers say, “You are not a (Noble) Messenger (of Allah)”; proclaim, “Allah is a Sufficient Witness between me and you, and (so is) he who has knowledge of the Book.”

# 1751

Alif-Lam-Ra; it is a Book which We have sent down upon you (O dear Prophet Mohammed – peace and blessings be upon him) so that you may bring forth people from the realms of darkness into light – by the command of their Lord, towards the path of the Most Honourable, the Most Praiseworthy.

# 1752

Allah – because all that is in the heavens and in the earth belongs only to Him; and woe is for the disbelievers through a severe punishment.

# 1753

To whom the worldly life is dearer than the Hereafter, and who prevent from the way of Allah and wish deviations in it; they are in extreme error.

# 1754

And We sent every Noble Messenger with the same language as his people\*, so that he may clearly explain to them; then Allah sends astray whomever He wills, and He guides whomever He wills; and He only is the Most Honourable, the Wise. (\* Prophet Mohammed (peace and blessings be upon him) was taught all the languages as he is sent towards all.)

# 1755

And indeed We sent Moosa along with Our signs that, “Bring your people from the realms of darkness into light – and remind them of the days of Allah\*; indeed in them are signs for every greatly enduring, grateful person.” (\* When various favours were bestowed – in order to give thanks and be patient.)

# 1756

And when Moosa said to his people, “Remember Allah’s favour upon you when He rescued you from the people of Firaun who were inflicting you with a dreadful torment, and were slaying your sons and sparing your daughters; and in it occurred a great favour of your Lord.”\* (\* On the 10th day of Moharram – therefore the Jews used to fast on that day as thanksgiving.)

# 1757

And remember when your Lord proclaimed, “If you give thanks, I will give you more, and if you are ungrateful then (know that) My punishment is severe.”

# 1758

And Moosa said, “If you and all who are in the earth turn disbelievers, then indeed Allah is definitely Independent (Unwanting), Most Praiseworthy.”

# 1759

Did not the tidings of those before you reach you? The people of Nooh, and the A’ad and the Thamud, and those after them? Only Allah knows them; their Noble Messengers came to them with clear proofs, they therefore raised their hands towards their own mouths, and said, “We disbelieve in what you have been sent with, and we are in a deeply intriguing doubt regarding the path you call us to.”

# 1760

Their Noble Messengers said, “What! You doubt concerning Allah, the Creator of the heavens and the earth? He calls you that He may forgive some of your sins and until the time of death give you a life free from punishment”; they said, “You are just human beings like us; you wish to prevent us from what our forefathers used to worship – therefore now bring some clear proof to us.”

# 1761

Their Noble Messengers said to them, “We are indeed human beings like you, but Allah bestows favour upon whomever He wills, among His bondmen\*; it is not our task to bring any proof to you except by the command of Allah; and only upon Allah must the Muslims rely.” (\* Therefore Prophets and other men are not equal in status.)

# 1762

“And what is the matter with us that we should not rely on Allah? He has in fact shown us our ways; and we will surely be patient upon the troubles you cause us; and those who trust must rely only upon Allah.”

# 1763

And the disbelievers said to their Noble Messengers, “We will surely expel you from our land, unless you accept our religion”; so their Lord sent them the divine revelation that, “Indeed We will destroy these unjust people.”

# 1764

“And indeed We will establish you in the land after them; this is for him who fears to stand before Me and fears the commands of punishment declared by Me.”

# 1765

And they sought a decision, and every stubborn rebel was destroyed.

# 1766

Hell went after him, and he will be made to drink liquid pus\*. (\* Discharged from the wounds of other people in hell.)

# 1767

He will sip it with difficulty but be unable to swallow, and death will approach him from every side and he will not die; and a severe punishment is after him.

# 1768

The state of those who disbelieve in their Lord is that their deeds are like ashes which the strong wind blew away on a stormy day; they got nothing from all that they earned; this is the extreme error.

# 1769

Have you not seen that Allah has created the heavens and the earth with true purpose? If He wills, He can remove you all and bring a new creation.

# 1770

And this is not at all difficult for Allah.

# 1771

They will all publicly come in the presence of Allah – then those who were weak will say to those who were the leaders, “We were your followers – is it possible for you to avert some of Allah’s punishment from us?” They will answer, “If Allah had guided us, we would have guided you; it is the same for us, whether we panic or patiently endure – we have no place of refuge.” (\* This conversation will take place between the disbelievers and their leaders.)

# 1772

And Satan will say when the matter has been decided, “Indeed Allah had given you a true promise – and the promise I gave you, I made it untrue to you; and I had no control over you except that I called you and you obeyed me; so do not accuse me, blame only yourselves; neither can I help you, nor can you help me; I have no concern with your ascribing me as a partner (to Allah); indeed for the unjust is a painful punishment.”

# 1773

And those who believed and did good deeds will be admitted into Gardens beneath which rivers flow, abiding in it forever, by the command of their Lord; their greeting in it is “Peace”.

# 1774

Did you not see how Allah illustrated the example of a sacred saying? Like a sacred tree, which has firm roots and branches reaching into heaven.

# 1775

Bearing fruit at all times by the command of its Lord; and Allah illustrates examples for people so that they may understand.

# 1776

And the example of a bad saying is like a filthy tree, which is cut off above the ground, therefore not having stability.

# 1777

Allah keeps the believers firm upon the truth in the life of this world and in the Hereafter; and Allah sends the unjust astray; and Allah may do whatever He wills.

# 1778

Did you not see those who exchanged the grace of Allah for ungratefulness and led their people down to the home of destruction?

# 1779

Which is hell; they will enter it; and what a wretched place of stay!

# 1780

And they ascribed equals to Allah to mislead from His way; say, “Enjoy a while, for your end will be the fire.”

# 1781

Say to the bondmen of Mine who believe, that they must keep the prayer established and spend in Our way from what We have given them, secretly and publicly, before the advent of a day in which there will be no trade nor friendship.

# 1782

It is Allah Who created the heavens and the earth, and sent down water from the sky, therefore producing some fruits for you to eat; and subjected the ships for you, that they may sail upon the sea by His command; and subjected the rivers for you.

# 1783

And subjected the sun and the moon for you, which are constantly moving; and has subjected the night and the day for you.

# 1784

And He gave you much of what you seek; and if you enumerate the favours of Allah, you will never be able to count them; indeed man is very unjust, most ungrateful.

# 1785

And remember when Ibrahim prayed, “O my Lord! Make this town (Mecca) a safe one, and safeguard me and my sons from worshipping idols.”

# 1786

“O my Lord! The idols have led many people astray; so whoever followed me, is indeed mine; and whoever disobeyed me – then indeed You are Oft Forgiving, Most Merciful.”

# 1787

“O our Lord! I have settled some of my descendants in a valley having no cultivation, near Your Sacred House – O our Lord! So that they may keep the prayer established, therefore incline some hearts of men towards them, and provide them fruits to eat – perhaps they may be thankful.”

# 1788

“O our Lord! You know what we hide and what we disclose; and nothing is hidden from Allah, neither in the earth nor in the heavens.”

# 1789

“All praise is to Allah Who gave me Ismail and Ishaq, in my old age; indeed my Lord is the Listener of Prayer.”

# 1790

“O my Lord! Maintain me as one who establishes prayer, and some of my descendants; O our Lord! and accept my prayer.”

# 1791

“O our Lord! And forgive me, and my parents, and all the Muslims on the day when the account will be established.”

# 1792

And do not ever assume that Allah is unaware of what the unjust do; He does not give them respite but for a day in which the eyes will become fixed, staring.

# 1793

They shall come out running in bewilderment, with their heads raised, their gaze not returning to them; and their hearts will not have any calm.

# 1794

And warn the people of a day when the punishment will come upon them, therefore the unjust will say, “O our Lord! Give us respite for a little while – for us to obey Your call and follow the Noble Messengers”; (It will be said) “So had you not sworn before that, ‘We have not to move to any place else from the earth’?”

# 1795

“And you dwelt in the houses of those who had wronged themselves and it became very clear to you how We had dealt with them, and We illustrated several examples for you.”

# 1796

And indeed they carried out their scheme, and their scheming is within Allah’s control; and their scheme was not such that could move these mountains\*. (\* The revelations / signs of Allah.)

# 1797

So do not ever assume that Allah will not fulfil His promise to His Noble Messengers; indeed Allah is the Dominant, the Avenger.

# 1798

On the day when the earth will be changed to other than this earth, and the heavens – and they will all come forth standing before Allah, the One, the Dominant above all.

# 1799

And on that day you will see the guilty linked together in chains.

# 1800

Their cloaks will be of pitch and fire will cover their faces.

# 1801

In order that Allah may repay each soul what it had earned; indeed Allah spends no time in judging the account.

# 1802

This is the message to be conveyed to all mankind – and in order to warn them with it, and for them to know that He is the only One God, and for men of understanding to heed advice.

# 1803

Alif-Lam-Ra; these are verses of the Book and the bright Qur’an.

# 1804

The disbelievers will ardently wish that if only they had been Muslims! (At the time of death / in their graves / on the Day of Resurrection.)

# 1805

Leave them to eat and enjoy, and for aspiration to involve them in play – so they will shortly come to know.

# 1806

And every dwelling that We destroyed, had a known decree for it.

# 1807

No group may advance its appointed promise nor postpone it.

# 1808

And they said, “O you upon whom the Qur’an has been sent, you are indeed insane.”

# 1809

“Why do you not bring angels to us, if you are truthful?”

# 1810

We do not send down angels without reason, and if the angels descend they would not get any respite!

# 1811

Indeed We have sent down the Qur’an, and indeed We Ourselves surely are its Guardians. (This is one of the miracles of the Qur’an – no one has been able to change even one letter of its text, despite every effort. It has remained in its original form since the 6th Century (A. D) and will remain so forever. Other Holy Books such as the Torah and the Bible have lost their originality.)

# 1812

And indeed We sent Noble Messengers before you, to the former nations.

# 1813

And never does a Noble Messenger come to them, but they mock at him.

# 1814

This is how We make the mocking\* enter the hearts of the guilty. (\* The acts of disbelief.)

# 1815

They do not believe in him, and the tradition of earlier nations has passed.

# 1816

And if We open for them a gate in the heavens, to ascend it through the day –

# 1817

Even then they would say, “Our sights have been hypnotised – in fact, a magic spell has been cast upon us.”

# 1818

And indeed We created towers in the skies, and beautified it for the beholders.

# 1819

And We have kept it guarded from every outcast devil.

# 1820

Except one who comes to eavesdrop – therefore a bright flame goes after him.

# 1821

And We spread out the earth, and placed mountains as anchors in it, and in it grew all things by a proper measure.

# 1822

And created livelihoods for you in it, and created those for whom you do not provide the sustenance.

# 1823

And there is not a thing the treasure\* of which is not with Us; and We do not send it down except by a known measure. (\* The power to create it.)

# 1824

And We sent the winds that relieve the clouds’ burden, therefore caused water to descend from the sky, then give it to you to drink; and you are not at all its treasurers.

# 1825

And indeed it is We Who give life and it is We Who cause death, and We are the Inheritors.

# 1826

And indeed We know those among you who came forward and indeed We know those among you who remained behind.

# 1827

Indeed your Lord only will raise them all on the Day of Resurrection; indeed only He is Wise, All Knowing.

# 1828

Indeed We created man from sounding clay made out of black smelly mud.

# 1829

And created the jinn before him, from smokeless fire.

# 1830

And recall when your Lord said to the angels, “I will create man from sounding clay made out of black smelly mud.”

# 1831

“Therefore when I have properly fashioned him and breathed into him a chosen noble soul from Myself, fall down before him in prostration.”

# 1832

Therefore all the angels, each and every one of them, fell prostrate.

# 1833

Except Iblis (Satan); he refused to be among those who prostrated.

# 1834

Said Allah, “O Iblis! What happened to you that you stayed apart from those who prostrated?”

# 1835

He answered, “It does not befit me to prostrate myself to a human whom You have created from sounding clay made out of black smelly mud.”

# 1836

Said Allah, “Therefore exit from Paradise, for you are an outcast.”

# 1837

“And indeed you are accursed till the Day of Judgement.”

# 1838

He said, “My Lord! Grant me respite till the day when they will all be raised.”

# 1839

Said Allah, “You are of those given respite.”

# 1840

“Till the Day of a well-known time.”

# 1841

He said, “My Lord! I swear by the fact that You sent me astray, I shall distract them in the earth, and I shall lead all of them astray.”

# 1842

“Except those among them who are Your chosen bondmen.”

# 1843

Said Allah, “This path\* leads straight towards Me.” (\* The path of the chosen bondmen.)

# 1844

“Indeed you do not have any power over My bondmen, except those wanderers who follow you.” (The devil is unsuccessful in tempting Allah’s chosen bondmen to commit sin.)

# 1845

And indeed hell is the promise for all of them.

# 1846

It has seven gates; for each gate is a portion assigned from them.

# 1847

Indeed the pious are amidst Gardens and springs.

# 1848

“Enter them with peace, in safety.”

# 1849

And We have removed any resentments which were in their breasts – they are brothers, sitting face to face on thrones.

# 1850

Neither any hardship is to reach them in it, nor are they to be expelled from it.

# 1851

Inform My bondmen that undoubtedly, I surely am the Oft-Forgiving, the Most Merciful.

# 1852

And that indeed the punishment of Mine is a painful punishment.

# 1853

And inform them of Ibrahim’s guests.

# 1854

When the angels came to him and said, “Peace"; he said, “We feel afraid of you.”

# 1855

They said, “Do not fear – we convey to you the glad tidings of a knowledgeable boy.”

# 1856

He said, “Do you convey to me the glad tidings upon old age reaching me? So upon what do you convey glad tidings?” (\* Prophet Ibrahim said this out of surprise.)

# 1857

They said, “We have given you true tidings, therefore do not lose hope.”

# 1858

He said, “Who is it that despairs from the mercy of his Lord, except those who are astray?”

# 1859

He said, “And what is your next task, O the sent angels?”

# 1860

They said, “We have been sent towards a guilty nation.”

# 1861

“Except the family of Lut; we shall rescue all of them.”

# 1862

“Except his wife – we have decided that she is of those who will stay behind.”

# 1863

And when the sent angels came to the house of Lut.

# 1864

He said, “You are an unfamiliar people.”

# 1865

They said, “In fact we have brought to you the matter which these people doubted.”

# 1866

“And we have brought to you a true command, and indeed we are truthful.”

# 1867

“Therefore journey with your household while a portion of the night remains, and you tread behind them – and none of you may turn around and see, and proceed directly to the place you are commanded to.”

# 1868

And We informed him the decision of this command, that at morning the root of the disbelievers would be cut off.

# 1869

And the people of the city came rejoicing. (\* To the house of Prophet Lut.)

# 1870

He said, “These are my guests – do not dishonour me.”

# 1871

“And fear Allah and do not disgrace me.”

# 1872

They said, “Had we not forbidden you from meddling in the affairs of anyone?”

# 1873

He said, “These women of our tribe are my daughters, if you have to.”

# 1874

By your life O dear Prophet (Mohammed – peace and blessings be upon him) – they are indeed straying in their intoxication.

# 1875

Therefore the scream overcame them at sunrise.

# 1876

And We turned the township upside down and rained upon them stones of heated clay.

# 1877

Indeed in this are signs for people who perceive.

# 1878

And indeed that township is upon a road still in use.

# 1879

Indeed in this are signs for the believers.

# 1880

And indeed the Dwellers of the Woods were unjust.

# 1881

We therefore took revenge from them; and indeed both these townships are situated on an open road.

# 1882

And the people of the Hijr (rocks) denied the Noble Messengers.

# 1883

And We gave them Our signs, and they remained averse to them.

# 1884

And they used to carve dwellings in the hills, without fear.

# 1885

So the scream overcame them at morning.

# 1886

Therefore their earnings did not in the least benefit them.

# 1887

And We have not created the heavens and the earth and all that is between them, except with the Truth; and indeed the Last Day will come, therefore (O dear Prophet Mohammed – peace and blessings be upon him), forbear graciously.

# 1888

Indeed your Lord only is the Great Creator, the All Knowing.

# 1889

And indeed We have given you seven verses that are repeated, and the great Qur’an.

# 1890

Do not direct your eyes towards the things We have given to some of their couples to enjoy, and do not at all grieve because of them, and take the Muslims within the folds of your mercy.

# 1891

And proclaim, “Indeed I, yes I, am the clear Herald of Warning.”

# 1892

(Of a punishment) Like the one We sent down upon the dividers.

# 1893

Those who broke the Word of Allah into several parts. (Those who broke the Torah / Bible or changed its text – or those who called the Qur’an a fabrication / poetry.)

# 1894

Therefore, by your Lord, We shall question every one of them.

# 1895

About all what they used to do.

# 1896

Therefore publicly announce what you are commanded, and turn away from the polytheists.

# 1897

Indeed We suffice you against these mockers.

# 1898

Those who ascribe another God along with Allah; so they will soon come to know.

# 1899

And indeed We know that you are disheartened by their speech.

# 1900

Therefore proclaim the Purity of your Lord with praise, and be of those who prostrate.

# 1901

And keep worshipping your Lord, till death\* comes to you. (\* The certainty.)

# 1902

The command of Allah is arriving soon, therefore do not seek to hasten it; Purity and Supremacy are to Him, above all the partners (they ascribe).

# 1903

He sends down the angels with the soul of faith – the divine revelations – towards those among His bondmen He wills that, “There is no worship except for Me, therefore fear Me.”

# 1904

He created the heavens and the earth with the truth; Supreme is He above their ascribing of partners (to Him).

# 1905

He created man from a drop of fluid, yet he is an open quarreller!

# 1906

And He created cattle; in them are warm clothing and uses for you, and you eat from them.

# 1907

And in them is your elegance, when you bring them home at evening, and when you leave them to graze.

# 1908

And they transport your loads to a town where you could not reach except utterly exhausted; indeed your Lord is Most Compassionate, Most Merciful.

# 1909

And horses, and mules, and donkeys so that you may ride them, and for adornment; and He will create what you do not know\*. (\* All modern means of transport – by air, sea, land and even in space – evidence this.)

# 1910

And the middle path rightly leads to Allah – any other path is wayward; and had He willed He would have brought all of you upon guidance.

# 1911

It is He Who sent down water from the sky – you drink from it, and from it are trees you use as pasture.

# 1912

With this water He produces for you crops, and olives, and dates, and grapes, and all kinds of fruit; indeed in this is a sign for people who ponder.

# 1913

And He subjected the night and the day for you – and the sun and the moon; and the stars are subjected to His command; indeed in this are signs for people of intellect.

# 1914

And the things He has created for you in the earth, of numerous colours; indeed in this is a sign for people who remember.

# 1915

And it is He Who subjected the sea for you, so you eat fresh meat from it, and extract ornaments from it which you wear; and you see ships ploughing through it and in order that you may seek His munificence and that you may give thanks.

# 1916

And He placed mountains as anchors in the earth so that it may not shake along with you, and streams and roads for you to find course.

# 1917

And landmarks; and they are guided by the star.

# 1918

So will He Who creates ever be like one who does not create? So do you not heed advice?

# 1919

And if you enumerate the favours of Allah, you will never be able to count them; indeed Allah is Oft Forgiving, Most Merciful.

# 1920

And Allah knows what you conceal and what you disclose.

# 1921

And those whom they worship other than Allah, do not create anything but are themselves created.

# 1922

They are dead, not alive; and they do not know when will the people be raised.

# 1923

Your God is One God; so those who do not believe in the Hereafter – their hearts deny and they are proud.

# 1924

Certainly Allah knows what they hide and what they disclose; indeed He does not like the proud.

# 1925

And when it is said to them, “What has your Lord sent down?”, they say, “The tales of former people.”

# 1926

In order to bear their full burdens on the Day of Resurrection, and some burdens of those whom they mislead with their ignorance; pay heed! What an evil burden they bear!

# 1927

Indeed those before them had plotted, so Allah seized the foundations of their building, therefore the roof fell down upon them from a height, and the punishment came upon them from a place they did not know.

# 1928

Then on the Day of Resurrection He will disgrace them and proclaim, “Where are My partners, concerning whom you disputed”; the people of knowledge will say, “All disgrace and evil is upon the disbelievers this day.”

# 1929

Those whose souls the angels remove whilst they were wronging themselves; so now they will plead “We never used to do any wrong”; "Yes you did, why not? Indeed Allah well knows what you used to do."

# 1930

“So now enter the gates of hell, remaining in it for ever”; so what an evil destination for the arrogant!

# 1931

And it was said to the pious, “What has your Lord sent down?” They said, “Goodness”; for those who did good in this world is goodness, and the final home is the best; and indeed what an excellent final home for the pious.

# 1932

Everlasting Gardens of Eden which they will enter, beneath which rivers flow – in it they will get whatever they wish; this is how Allah rewards the pious.

# 1933

Those whose souls the angels remove in a state of purity, saying, “Peace be upon you – enter Paradise, the reward of your deeds.”

# 1934

So what are they waiting for, except that the angels come upon them or that your Lord’s punishment comes? Those before them did exactly this; and Allah did not oppress them at all, but it is they who used to wrong themselves.

# 1935

So the evils of their deeds struck them, and what they used to mock at surrounded them.

# 1936

And the polytheists said, “Had Allah willed, we would not have worshipped anything besides Him – neither we nor our forefathers – and nor would we have forbidden anything, whilst being disassociated with Him”; those before them did exactly this; so what is (incumbent) upon the Noble Messengers, except to plainly convey (the message)?

# 1937

And indeed We sent to every nation a Noble Messenger (proclaiming) that “Worship Allah and beware of the devil”; therefore Allah guided some of them, and error proved true upon some of them; therefore travel in the land and see what sort of fate befell the deniers!

# 1938

If you (O dear Prophet Mohammed – peace and blessings be upon him) desire for their guidance, then indeed Allah does not guide one whom He misleads, and they do not have any aides.

# 1939

And they swore by Allah most vehemently in their oaths that, “Allah will not raise up the dead”; yes He will, why not? A true promise obligatory upon Him, but most men do not know.

# 1940

In order that He may make clear to them the matter in which they differed, and the disbelievers may realise that they were liars.

# 1941

And Our command for anything to occur, when We will it, is that We only say to it, “Be” – and it thereupon happens.

# 1942

And to those who migrated in Allah's cause after being oppressed, We shall indeed give them a good place in the world, and indeed the reward of the Hereafter is extremely great; if only the people knew!

# 1943

Those who patiently endured and who rely only upon Allah.

# 1944

And We did not send before you except men, towards whom We sent divine revelations – so O people, ask the people of knowledge if you do not know. (\* All the Prophets were men.)

# 1945

Along with clear proofs and writings; and We have sent down this Remembrance towards you (O dear Prophet Mohammed – peace and blessings be upon him) so that you may explain to mankind what has been revealed towards them, and that they may ponder.

# 1946

So do they who conspire evils, not fear that Allah may bury them in the earth, or that the punishment may come to them from a place they do not know?

# 1947

Or that He may seize them while they move here and there, for they cannot escape?

# 1948

Or that He may seize them whilst constantly ruining them? For indeed your Lord is Most Compassionate, Most Merciful.

# 1949

And have they not observed that the shadows of the things Allah has created incline to the right and to the left, in prostration to Allah, and that they are servile?

# 1950

And to Allah only prostrates whatsoever is in the heavens and whatsoever moves in the earth, and the angels – and they are not proud.

# 1951

They bear upon themselves the fear of their Lord, and do only what they are commanded.

# 1952

And Allah has proclaimed, “Do not ascribe two Gods; indeed He is the only One God; therefore fear Me alone.”

# 1953

And to Him only belongs all whatever is in the heavens and in the earth, and obeying Him only is obligatory; so will you fear anyone other than Allah?

# 1954

And whatever blessings you have, are all from Allah – then whenever misfortune reaches you, towards Him only do you seek refuge.

# 1955

And then, when He averts the misfortune from you, a group among you starts ascribing partners to their Lord!

# 1956

In order to deny the favours We have given them; so enjoy a little; for you will soon come to know.

# 1957

And for things unknown, they assign a portion of the sustenance We have given them; by Allah – you will certainly be questioned regarding all that you used to fabricate.

# 1958

And they assign daughters to Allah – Purity is to Him! – and assign for themselves what they wish.

# 1959

And when one among of them receives the glad tidings of a daughter, his face turns black for the day, and he remains seething.

# 1960

Hiding from the people because of the evil of the tidings; “Will he keep her with disgrace, or bury her beneath the earth?”; pay heed! Very evil is the judgement they impose!

# 1961

Those who do not believe in the Hereafter, for them only is the evil state; and the Majesty of Allah is Supreme; and He only is the Most Honourable, the Wise.

# 1962

Were Allah to seize people on account of their injustices, He would not have left anyone walking on the earth, but He gives them respite up to an appointed promise; then when their promise comes they cannot go back one moment nor come forward.

# 1963

And they assign to Allah that which is abhorred by themselves, and their tongues speak the lies that goodness is for them; so it occurred that for them is the fire, and they have crossed the limits.

# 1964

By Allah, We indeed sent Noble Messengers to several nations before you, but Satan made their misdeeds appear good to them – so he only is their companion this day, and for them is a punishment, most painful.

# 1965

And We did not send down this Book towards you except for you to clearly explain to them the matters in which they may differ, and a guidance and a mercy for the believers.

# 1966

And Allah sent down water from the sky and with it revived the earth after its death; indeed in this is a sign for people who keep ears\*. (\* That listen to the truth.)

# 1967

And indeed in cattle is a lesson for you; We provide you drink from what is in their bellies – pure milk from between the excretion and the blood, palatable for the drinkers.

# 1968

And from the fruits of date and grapes, for you make juices and good nourishment from them; indeed in this is a sign for people of intellect.

# 1969

And your Lord inspired the bee that, “Build homes in hills, and in trees, and in rooftops.”

# 1970

“Then eat from all kinds of fruits, and tread the ways of your Lord which are soft and easy for you”; from their bellies comes a drink of various colours, in which is health for mankind; indeed in this is a sign for people who ponder.

# 1971

And Allah created you, and will then remove your souls; and among you is one who is sent back to the most lowly age, so knowing nothing after having had knowledge; indeed Allah knows everything, is Able to do all things.

# 1972

And Allah has made some among you superior above others in livelihood; so those to whom the superiority is given, will not return their livelihood to their slaves, so they may all become equal in this respect; so do they deny the favours of Allah?

# 1973

And Allah has created for you wives of your own breed, and has given you from your wives, sons and grandsons, and has provided sustenance for you from good things; so do they believe in falsehood and deny the favours of Allah?

# 1974

And they worship such besides Allah, who do not have power to provide them any sustenance from the heavens or the earth, nor can they do anything.

# 1975

Therefore do not ascribe equals to Allah; indeed Allah knows whereas you do not know.

# 1976

Allah has illustrated an example – there is a slave, himself the property of another, not owning anything – and another one upon whom We have bestowed a good livelihood from Us, he therefore spends from it, secretly and publicly; will they be equal? All praise is to Allah; in fact, most of them do not know.

# 1977

And Allah has illustrated an example – two men – one of them dumb, unable to do anything, and he is a burden on his master – wherever his master sends him, he brings back no good; will he be equal to one who gives the command of justice and is on the Straight Path?

# 1978

And for Allah only are the hidden things of the heavens and the earth, and the matter of Resurrection is not but like the batting of an eyelid – in fact closer than this; indeed Allah is Able to do all things.

# 1979

And Allah brought you forth from your mothers’ wombs, whilst you did not know anything\* – and gave you ears and eyes and hearts, for you to be grateful. (\* Prophet Mohammed and Prophet Jesus, among others, are exceptions to this rule – peace and blessings be upon them.)

# 1980

Have they not seen the birds, subservient in the open skies? No one holds them up except Allah; indeed in this are signs for the people who believe.

# 1981

And Allah has given you houses for staying, and made some houses from the hides of animals, which are easy for you on your day of travel and on the day of stopover – and from their wool, and fur, and hair, some household items and utilities for a while.

# 1982

And Allah has provided you shade with the things He has created, and created for you refuge in the hills, and created some clothing for you to protect you from the heat, and some clothing to protect you during conflict; this is how He completes His favour upon you, so that you may obey.

# 1983

Then if they turn away, O dear Prophet, (Mohammed – peace and blessings be upon him) upon you is nothing but to clearly convey (the message).

# 1984

They recognise the favour\* of Allah and then deny it, and most of them are disbelievers. (\* Prophet Mohammed (peace and blessings be upon him) and / or all the favours of Allah.)

# 1985

And the day when We will raise up a witness from every nation – then there will be no leave for the disbelievers, nor will they be appeased.

# 1986

And when the unjust will see the punishment, from that time on it will not be lightened for them, nor will they get respite.

# 1987

And when the polytheists will see their ascribed partners, they will say, “Our Lord! These are our partners whom we used to worship besides You”; so they will strike back at them with the saying, “You are indeed liars!”

# 1988

And on that day they will fall humbly before Allah, and they will lose all that they used to fabricate.

# 1989

Those who disbelieved and prevented from the way of Allah – We added punishment upon the punishment – the recompense of their mischief.

# 1990

And the day when We will raise from every group, a witness from among them, in order to testify against them and will bring you O dear Prophet (Mohammed – peace and blessings be upon him) as a witness upon them all; and We have sent down this Qur’an upon you which is a clear explanation of all things, and a guidance and a mercy and glad tidings to the Muslims.

# 1991

Indeed Allah decrees the commands of justice and kindness, and of giving to relatives, and forbids from the shameful and evil and rebellion; He advises you so that you may pay heed.

# 1992

And fulfil the covenant of Allah when you have made the promise, and do not break your oaths after ratifying them, and you have made Allah a Guarantor over you; indeed Allah knows your deeds.

# 1993

And do not be like the woman broke her thread into bits after she had manufactured it; you make your oaths a phoney excuse between yourselves lest one nation may not be more than the other; Allah just tries you with it; and He will surely clarify for you on the Day of Resurrection, the matters in which you differed.

# 1994

Had Allah willed He would have made you all one nation, but He sends astray whomever He wills and guides whomever He wills; and you will certainly be questioned regarding your deeds.

# 1995

And do not make your oaths phoney excuses between yourselves, so that a foot may not slip after being steadfast and you may taste evil because you were preventing from Allah’s way; and lest you be severely punished.

# 1996

And do not exchange the covenant of Allah to procure an abject price; that which is with Allah is better for you, if you know.

# 1997

What you have will perish, and that which is with Allah will remain forever; and indeed We shall pay the patiently enduring a recompense which befits the best of their deeds.

# 1998

Whoever does good deeds – whether a male or female – and is a Muslim, We shall sustain him an excellent life, and shall certainly pay them a recompense which befits the best of their deeds.

# 1999

And when you recite the Qur’an, seek the refuge of Allah from Satan the outcast.

# 2000

Indeed he has no power over the believers and who rely only upon their Lord.

# 2001

Satan’s power is only over those who make friendship with him and ascribe him as a partner (in worship).

# 2002

And when We replace a verse\* by another – and Allah well knows what He sends down – the disbelievers say, “You are just fabricating”; in fact most of them do not know. (\* The command of one verse by another.)

# 2003

Proclaim, “The Holy Spirit\* has rightly brought it down from your Lord, to make the believers steadfast, and a guidance and glad tidings for the Muslims.” (\* Angel Jibreel – peace and blessings be upon him.)

# 2004

And indeed We know that they say, “This Qur’an is being taught by some other man”; the one they refer to speaks a foreign language, whereas this is clear Arabic!

# 2005

Those who disbelieve in the signs of Allah – Allah does not guide them, and for them is a punishment, most painful.

# 2006

Only those who do not believe in Allah’s signs attribute lies and fabrications; and they themselves are liars.

# 2007

The one who disbelieves in Allah after accepting faith – except him who is forced to and whose heart is still firmly upon faith – but whoever is wholeheartedly a disbeliever, upon them is the wrath of Allah; and for them is a great punishment.

# 2008

This is because the worldly life was dearer to them than the Hereafter; and because Allah does not guide such disbelieving people.

# 2009

These are the ones whose hearts, ears, and eyes Allah has sealed; and they are the neglectful.

# 2010

So it occurred that they are the losers in the Hereafter.

# 2011

Then indeed your Lord – for those who migrated after they had been oppressed, and then fought and remained patient – indeed your Lord is then, surely, Oft Forgiving, Most Merciful.

# 2012

The day when every soul will come quarrelling against itself, and every soul will be fully repaid for what it did, and they will not be wronged.

# 2013

And Allah has illustrated an example of a township – which dwelt in peace and security, its provisions coming in abundance from every side – in response the township started being ungrateful of Allah’s favours, therefore Allah made it taste the punishment by covering it with a cloak of starvation and fear, on account of their deeds.

# 2014

And indeed a Noble Messenger came to them from among them – in response they denied him, and therefore the punishment seized them, and they were unjust.

# 2015

Therefore eat the lawful and good sustenance Allah has provided you, and be grateful for the blessings of your Lord, if you worship Him.

# 2016

Only these are forbidden for you – the carrion, and blood, and flesh of swine, and that which has been slaughtered while proclaiming the name of any other besides Allah; so one who is compelled and does not eat out of desire, nor more than what is necessary, then indeed Allah is Oft Forgiving, Most Merciful.

# 2017

And do not say – the lie which your tongues speak – “This is lawful, and this is forbidden” in order to fabricate a lie against Allah; indeed those who fabricate lies against Allah will never prosper.

# 2018

A little enjoyment – and for them is a punishment, most painful.

# 2019

And especially for the Jews We forbade which We related to you earlier; and We did not oppress them, but it is they who wronged themselves.

# 2020

Then indeed your Lord – for those who unwittingly commit evil and then repent and reform themselves – indeed your Lord is then, surely, Oft Forgiving, Most Merciful.

# 2021

Indeed Ibrahim was a leader, obedient to Allah, and detached from all; and he was not a polytheist.

# 2022

Grateful for His blessings; Allah chose him and guided him to the Straight Path.

# 2023

And We gave him goodness in this world; and indeed in the Hereafter he is worthy of proximity.

# 2024

And then We sent you (O dear Prophet Mohammed – peace and blessings be upon him) the divine revelation that, “Follow the religion of Ibrahim, who was free from all falsehood; and was not a polytheist.”

# 2025

The Sabbath was made obligatory only upon those who differed in it; and indeed your Lord will judge between them on the Day of Resurrection concerning the matter in which they differed.

# 2026

Call towards the path of your Lord with sound planning and good advice, and debate with them in the best possible way; indeed your Lord well knows him who has strayed from His path, and He well knows the guided.

# 2027

And if you mete out punishment, then punish similarly as you were afflicted; and if you patiently endure, then indeed patience is better for the patiently enduring.

# 2028

And O dear Prophet (Mohammed – peace and blessings be upon him) patiently endure – and your patience is only due to the guidance of Allah – and do not grieve for them, and do not be disheartened by their deceits.

# 2029

Indeed Allah is with the pious and the virtuous.

# 2030

Purity is to Him Who took His bondman in a part of the night from the Sacred Mosque to the Aqsa Mosque around which We have placed blessings, in order that We may show him Our great signs; indeed he is the listener, the beholder. (This verse refers to the physical journey of Prophet Mohammed – peace and blessings be upon him – to Al Aqsa Mosque and from there to the heavens and beyond. The entire journey back to Mecca was completed within a small part of the night.)

# 2031

And We gave Moosa the Book, and made it a guidance for the Descendants of Israel that, “Do not appoint anyone as a Trustee besides Me.”

# 2032

The descendants of those whom We boarded along with Nooh; he was indeed a grateful bondman.

# 2033

And We decreed for the Descendants of Israel in the Book that, “You will indeed create great turmoil in the earth twice, and you will surely become very proud.”

# 2034

So when the first of those promises came, We sent upon you Our extremely militant bondmen – they therefore entered the cities pursuing you; and this was a promise that had to be fulfilled.

# 2035

We then reversed your attack upon them, and aided you with wealth and sons and increased your numbers.

# 2036

If you do good deeds, you will for your own good – and if you commit evil, it is for yourself; therefore when the second of those promises came – so the enemy maim your faces, and enter the mosque as they had entered it the first time, and destroy until they ruin all they could capture.

# 2037

It is likely that your Lord may have mercy on you; and if you repeat the mischief, We will repeat the punishment; and We have made hell a prison for the disbelievers.

# 2038

Indeed this Qur’an guides to the most Straight Path, and gives glad tidings to the believers who do good deeds, that for them is a great reward.

# 2039

And those who do not believe in the Hereafter – We have kept prepared for them a punishment, most painful.

# 2040

And man prays for evil like the way he seeks goodness; and man is very hasty.

# 2041

And We created the night and the day as two signs – We therefore kept the sign of the night indistinct, and the sign of the day visible – so that you may seek the munificence of your Lord, and know the calculation of the years, and the accounting; and We have explained all things in detail, distinctively.

# 2042

And We have attached the destiny of every man to his neck; and We shall bring forth a register for him on the Day of Resurrection, which he will find open.

# 2043

It will be said, “Read your ledger; this day you are sufficient to take your own account.”

# 2044

Whoever came to guidance, has come for his own good; and whoever went astray, has strayed for his own ruin; and no burdened soul will bear another’s burden; and We never punish until We have sent a Noble Messenger.

# 2045

And when We will to destroy a township We send the commands to its prosperous people, thereupon they do not obey them, and so the Word is proved upon it – We therefore destroy and ruin it.

# 2046

And many a generation We did destroy after Nooh! And Allah is Sufficient, Aware of the sins of His bondmen, the Beholder.

# 2047

Whoever desires this fleeting one, We may give him quickly – whatever We will, to whomever We will; and then assign hell for him; for him to enter it condemned, pushed around.

# 2048

And whoever desires the Hereafter and strives for it accordingly, and is a believer – so only their effort has borne fruit.

# 2049

We provide help to all – to these and to those, by the bestowal of your Lord; and there is no constraint on the bestowal of your Lord.

# 2050

Observe how We have given superiority to some over others; and indeed the Hereafter is the greatest in rank and the highest in excellence.

# 2051

O listener, do not set up another God with Allah, for you will then remain seated condemned, helpless.

# 2052

And your Lord has ordained that you do not worship anyone except Him, and treat your parents with kindness; if either of them or both reach old age in your presence, do not say “Uff”\* to them and do not rebuff them, and speak to them with the utmost respect. (\* Any expression of disgust.)

# 2053

And lower your wing humbly for them, with mercy, and pray, “My Lord! Have mercy on them both, the way they nursed me when I was young.”

# 2054

Your Lord is Well Aware of what is in your hearts; if you are worthy, then indeed He is Oft Forgiving for those who repent.

# 2055

And give the relatives their rights, and to the needy, and to the traveller; and do not waste needlessly.

# 2056

Indeed those who needlessly waste are brothers of the devils; and the devil is very ungrateful to his Lord.

# 2057

And if you turn away from these\*, expecting the mercy of your Lord, for which you hope, then speak to them an easy word. (\* The companions of the Holy Prophet, who sought his assistance.)

# 2058

And do not keep your hand tied to your neck nor open it completely, lest you remain seated – reproached, weary.

# 2059

Indeed your Lord eases the livelihood and restricts it, for whomever He wills; He Well Knows, Beholds His bondmen.

# 2060

And do not kill your children, fearing poverty; We shall provide sustenance to them as well as to you; indeed killing them is a great mistake.

# 2061

And do not approach adultery – it is indeed a shameful deed; and a very evil way.

# 2062

And do not wrongfully kill any living being which Allah has forbidden; and for whoever is slain wrongfully, We have given the authority to his heir, so he should not cross limits in slaying; he will surely be helped.

# 2063

And do not approach the wealth of the orphan except in the best possible way, till he reaches adulthood; and fulfil the promise; indeed the promise will be asked about.

# 2064

And correctly measure when you measure, and weigh correctly with the scales; this is better, and has a better outcome.

# 2065

And do not pursue the matter you do not have the knowledge of; indeed the ear, and the eye, and the heart – each of these will be questioned.

# 2066

And do not walk haughtily on the earth; you can never split the earth, nor be as high as the hills.

# 2067

Of all this related before, the evil among it is disliked by your Lord.

# 2068

This is part of the divine revelations of wisdom that your Lord has sent down to you (O dear Prophet Mohammed – peace and blessings be upon him); and O listener, do not set up another God with Allah, for you will then be thrown into hell – rebuked, rebuffed.

# 2069

Has your Lord chosen sons for you, and created daughters for Himself from among the angels? Indeed you utter a profound word!

# 2070

And We have explained in this Qur’an in various ways, for them to understand; and it increases nothing except their hatred towards it.

# 2071

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “If there were other Gods besides Him” – as they utter – “then they would have certainly found a way towards\* the Owner of the Throne!”. (\* To fight against Him.)

# 2072

Purity and Supremacy are to Him from what they utter, a Great Supremacy!

# 2073

The seven heavens and the earth and all those in them say His Purity; and there is not a thing that does not proclaim His purity with praise, but you do not understand their proclamation of purity; indeed He is Most Forbearing, Oft Forgiving.

# 2074

And when you read the Qur’an O dear Prophet (Mohammed – peace and blessings upon him), We created an invisible barrier between you and those who do not believe in the Hereafter.

# 2075

And We placed covers upon their hearts so they may not understand it, and deafness in their ears; and when you mention your Only Lord in the Qur’an, they flee turning their backs in hatred.

# 2076

We know well why they listen when they lend ears to you, and when they discuss among themselves, when the unjust say, “You have not followed except a man who is under a magic spell.”

# 2077

See the kind of examples they invent for you! They therefore strayed, so cannot find a path.

# 2078

And they say, “When we have become bones and decomposed, will we really be raised up anew?”

# 2079

Proclaim, “Become stones or iron.”

# 2080

“Or some other creation which you deem great”; so they will now say, “Who will create us again?”; proclaim, “He Who created you for the first time”; so now they will mockingly shake their heads at you, and question, “When is this going to occur?”; say, “It could perhaps be soon.”

# 2081

“The day when He will call you and you will come praising Him, thinking you have stayed only a little.”

# 2082

And tell My bondmen to speak that which is the best; undoubtedly Satan sows discord among them; indeed Satan is man’s open enemy.

# 2083

Your Lord knows you well; if He wills He may have mercy upon you, or if He wills, He may punish you; and We have not sent you (O dear Prophet Mohammed – peace and blessings be upon him) as a guardian over them.

# 2084

And your Lord knows well all those who are in the heavens and the earth; and indeed among the Prophets We gave excellence to some above others, and We gave the Zaboor to Dawud.

# 2085

Proclaim, “Call upon those whom you assume besides Allah – so they do not have any power to relieve the misfortune from you nor to avert it.”

# 2086

The devoted bondmen whom these disbelievers worship, themselves seek the means of proximity from their Lord, that who among them is the closest (to his Lord), and hope for His mercy and fear His punishment; indeed the punishment of your Lord is to be feared.

# 2087

And there is no such dwelling but which We shall destroy before the Day of Resurrection, or punish it severely; this is written in the Book.

# 2088

And We remained constrained from sending such signs, because the former people denied them; and We gave the Thamud the she-camel for enlightenment, so they oppressed it; and We do not send such signs except to warn.

# 2089

And when We proclaimed to you, “Indeed all mankind is within the control of your Lord”; and We did not create the spectacle\* which We showed you except to try mankind, and the Tree\*\* which is cursed in the Qur’an; and We warn them – so nothing increases for them except extreme rebellion. (\* The Ascent of the Holy Prophet to the heavens and beyond, which the disbelievers denied as just a dream. \*\* The Zakkum tree which will grow in hell and be the food for its inhabitants.)

# 2090

And recall when We ordered the angels that, “Prostrate before Adam” – so they all prostrated except Iblis; he said, “Shall I prostrate before one whom You have created from clay?”

# 2091

He said, “Behold this\* – the one whom You have honoured above me – if You give me respite till the Day of Resurrection, I will surely crush his descendants, except a few.” (\* Prophet Adam.)

# 2092

He said, “Be gone – therefore whoever among them follows you – so hell is the recompense for you all, a sufficient punishment.”

# 2093

“And mislead those whom you can among them with your voice, and raise an army against them with your cavalry and infantry, and be their partner in wealth and children, and give them promises”; and Satan does not promise them except with deception.

# 2094

“Indeed My bondmen\* – you do not have any power over them”; and your Lord is Sufficient as a Trustee. (\* The chosen virtuous bondmen)

# 2095

Your Lord is He Who sails the ship upon the seas for you, so that you may seek His munificence; indeed He is Most Merciful upon you.

# 2096

And when calamity strikes you upon the sea, all those whom you worship are lost, except Him; then when He rescues you towards land, you turn away; and man is extremely ungrateful.

# 2097

Are you unafraid that He may bury an edge of the same land along with you, or send a shower of stones upon you, and you find no supporter for yourselves?

# 2098

Or are you unafraid that He may again take you back to the sea, then send against you a ship-breaking gust of wind, therefore drowning you because of your disbelief – then you may not find for yourself anyone to come after Us for this?

# 2099

Indeed We have honoured the Descendants of Adam and transported them over land and sea, and gave them good things as sustenance, and made them better than most of Our creation.

# 2100

On the day when We shall summon every group along with its leader; so whoever is given his register in his right hand – these will read their accounts and their rights will not be suppressed even a thread. (\* They will be given the full reward.)

# 2101

Whoever is blind\* in this life will be blind in the Hereafter, and even more astray. (\* To the truth – disbelieving.)

# 2102

And it was close that they were about to mislead you somewhat from the divine revelation We sent to you, for you to attribute something else\* to Us; and if it were\*\*, they would have accepted you as a friend. (\* Other than the divine revelation. \*\* Which is impossible.)

# 2103

And had We not kept you steadfast, possibly you might have inclined to them just a little.

# 2104

And if it were\*, We would then have made you taste a double life and a double death – you would then not find any supporter against Us. (\* Which is impossible.)

# 2105

And indeed it was close that they frighten you in the land for them to oust you from it – and if it were, they would not have stayed after you, but a little.

# 2106

The tradition of the Noble Messengers We sent before you – and you will not find Our rules changing.

# 2107

Keep the prayer established, from the declining of the sun until darkness of the night, and the Qur’an at dawn; indeed the angels witness the reading of the Qur’an at dawn.

# 2108

And forego sleep\* in some part of the night – an increase for you\*\*; it is likely your Lord will set you on a place where everyone will praise you\*\*\*. (\* For worship. \*\* Obligatory only upon the Holy Prophet. \*\*\* On the Day of Resurrection.)

# 2109

And pray, “My Lord! Admit me with the truth and take me out with the truth\*, and give me from Yourself a helpful dominance\*\*.” (\* Wherever I come or go \*\* Through spread of Islam.)

# 2110

And proclaim, “The Truth has arrived and falsehood has vanished; indeed falsehood had to vanish.” (\* With the arrival of the Last Prophet – Mohammed peace and blessings be upon him)

# 2111

And We send down in the Qur’an that which is a cure for the Muslims, and a mercy – and it increases only ruin for the unjust.

# 2112

And when We bestow favours upon man, he turns away and goes far away towards himself; and when evil touches him he despairs.

# 2113

Proclaim, “Each one works according to his own pattern; and your Lord well knows him who is more upon guidance.”

# 2114

They ask you concerning the soul; proclaim “The soul is an entity by the command of my Lord, and you have not received knowledge except a little.”

# 2115

And if We willed We could have taken away the revelations which We have sent to you – you would then not find anyone who could advocate for you before Us for this.

# 2116

Except the mercy of your Lord; indeed His munificence upon you (O dear Prophet Mohammed – peace and blessings be upon him) is extremely great.

# 2117

Proclaim, “If all mankind and jinns agree to bring an equivalent to the Qur’an, they will not be able to bring its equal – even if they were to help each other.”

# 2118

And indeed We have illustrated all kinds of examples in the Qur’an for mankind – so most men did not accept, except to be ungrateful.

# 2119

And they said, “We will not accept faith in you, until you cause a spring to gush forth from the earth for us.”

# 2120

“Or you have a garden of date-palms and grapes, and you make gushing rivers to flow in it.”

# 2121

“Or you cause the sky to fall upon us in pieces like you said – or bring Allah and the angels as Witness.”

# 2122

“Or you have a house of gold, or you ascend up into heaven; and even then we shall not believe in your ascent unless you send down a book upon us, which we may read”; say (O dear Prophet Mohammed – peace and blessings be upon him), “Purity is to my Lord – who am I except a human, sent by Allah?” (\* These can be done, only when Allah commands.)

# 2123

And what prevented people from believing when the guidance came to them, except their saying that, “What! Allah has sent a human as a Noble Messenger?”?

# 2124

Proclaim, “If there were angels walking peacefully on the earth, We would send down only an angel from heaven, as a Noble Messenger towards them.”

# 2125

Proclaim, “Allah is Sufficient as Witness between me and you all; indeed He is Well Aware of, the Beholder of His bondmen.”

# 2126

And only he whom Allah guides, is upon guidance; and whomever He sends astray – you will therefore not find for them any supporters besides Him; and We shall raise them by their faces on the Day of Resurrection – blind, dumb and deaf; their destination is hell; whenever it is about to extinguish, We will inflame it more for them.

# 2127

This is their reward because they disbelieved in Our signs and said, “When we are bones and decomposed, will we really be created again and raised up again?”

# 2128

Do they not see that Allah Who has created the heavens and the earth is Able to create people similar to them, and has set a term for them in which there is no doubt? So the unjust do not accept without being ungrateful.

# 2129

Proclaim, “If you owned the treasures of the mercy of my Lord, you would hoard them too for fear that they may get spent; and man is a big miser.”

# 2130

And indeed We gave Moosa nine clear signs, therefore ask the Descendants of Israel when he came to them – in response Firaun said, “O Moosa – I think you are under a magic spell.”

# 2131

He said, “You certainly know that these have not been sent down except by the Lord of the heavens and the earth, the eye-openers\* for the hearts; and I think that you, O Firaun, will surely be ruined.” (\* The signs which enlighten the hearts.)

# 2132

He therefore wished to expel them from the earth, so We drowned him and his companions, all together.

# 2133

And after him, We said to the Descendants of Israel, “Reside in this land – then when the promise of the Hereafter comes, We will bring you all huddled together.”

# 2134

And We sent down the Qur’an with the truth, and it has come down only for the truth; and We did not send you except as a Herald of glad tidings and warnings.

# 2135

And We sent down the Qur’an in parts, that you may gradually recite it to the people, and We sent it down slowly in stages.

# 2136

Proclaim, “Whether you accept faith in it or not”; indeed those who received knowledge before the Qur’an came, fall down prostrate on their faces when it is recited to them.

# 2137

And they say, “Purity is to our Lord – indeed the promise of our Lord had to come true.”

# 2138

And they fall down on their faces weeping, and this Qur’an increases their humility. (Command of prostration # 4).

# 2139

Proclaim, “Pray calling (Him) Allah or calling (Him) the Most Gracious; whichever name you call with – they are all His magnificent names; and do not offer your prayers very loudly or very softly, and seek a way between them.”

# 2140

And say, “All praise is to Allah, Who has not chosen a son for Himself, and none is His partner in kingship, and none is His supporter due to weakness, and say ‘Allah is Great’ to proclaim His greatness.”

# 2141

All praise is to Allah Who sent down the Book upon His bondman, and has not kept any deviation in it.

# 2142

A just Book, to warn of Allah’s severe punishment, and to give glad tidings to the believers who do good deeds, that for them is an excellent reward.

# 2143

In which they will abide forever.

# 2144

And to warn those who say “Allah has chosen a child.”

# 2145

They do not have any knowledge of it – nor did their forefathers; profound is the word that comes out of their mouths; they only speak a lie.

# 2146

Possibly you may risk your life by grieving (O dear Prophet Mohammed – peace and blessings be upon him) for them if they do not believe in this narration.

# 2147

We have indeed placed all that is on the earth as its adornment in order that We may test them, who among them has the best deeds.

# 2148

And indeed We shall one day make all that is on it a barren plain.

# 2149

Did you know that the People of the Cave and People close to the Woods, were Our exceptional signs?

# 2150

When the young men took refuge in the Cave – then said, “Our Lord! Give us mercy from Yourself, and arrange guidance for us in our affair.”

# 2151

We then thumped upon their ears in the Cave for a number of years. (\* Put them to sleep.)

# 2152

We then awakened them to see which of the two groups more accurately tells the period they had stayed.

# 2153

We shall narrate their account to you accurately; they were young men who believed in their Lord, and We increased the guidance for them.

# 2154

And We made their hearts steadfast when they stood up and said, “Our Lord is the Lord of the heavens and the earth – we shall not worship any other deity except Him – if it were, we have then said something excessive.”

# 2155

“These – the people of ours – have set up Gods besides Allah; why do they not bring a clear proof regarding them? And who is more unjust than one who fabricates a lie against Allah?”

# 2156

“And when you have disassociated yourself from them and all what they worship besides Allah – so take refuge in the Cave – your Lord will spread His mercy for you and arrange ease for you in your affairs.”

# 2157

And O dear Prophet (Mohammed – peace and blessings be upon him) you will see the sun that when it rises it shifts away to the right of their cave, and when it sets it shifts away to their left, and they are in the open ground of that cave; this is from among the signs of Allah; whomever Allah guides – only he is therefore guided; and whomever He sends astray – you will never find for him a friend who guides.

# 2158

And you may think they are awake, whereas they are asleep; and We turn them over to the right and the left – and their dog is on the threshold of the cave, with its paws outstretched; O listener, were you to look at them closely, you would turn back running away from them, and be filled with their dread.

# 2159

And similarly We awakened them so that they may enquire about each other; a speaker among them said, “How long have you stayed here?” Some among them said, “We have stayed a day or part of a day”; the others said, “Your Lord well knows how long you have stayed; therefore send one of you to the city with this silver coin – he may then check which food available there is purer, in order to bring some of it for you to eat – and he must be courteous and not inform anyone about you.”

# 2160

“Indeed if they come to know about you, they will stone you or turn you back to their religion – and if so, you will never prosper.”

# 2161

And this is how We made them known for people to know that the promise of Allah is true and that there is no doubt concerning the Last Day; when the people began disputing among themselves regarding them, they said, “Construct a building over their cave”; their Lord well knows them; those who dominated in this matter said, “We promise we will build a mosque over them.”

# 2162

So the people will now say, “They are three, their dog is the fourth”; and some will say, “They are five, their dog is the sixth” – just blind guesses; and some will say, “They are seven, and their dog is the eighth”; proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “My Lord well knows their number – no one knows them except a few”; therefore do not debate concerning them except what has occurred, and do not ask any of the People of the Book(s) anything concerning them.

# 2163

And never say about anything that, “I will do this tomorrow.”

# 2164

Except “If Allah wills”; and remember your Lord when you forget, and say, “It is likely that my Lord will guide me to a more accurate way of virtue than this.”

# 2165

And they stayed in their Cave for three hundred years\* and nine more\*. (\* 300 according to the Solar calendar and 309 according to the Lunar calendar.)

# 2166

Say, “Allah well knows how long they stayed; for Him only are the hidden of the heavens and the earth; how well He sees and hears! They do not have any supporter besides Him; and He does not associate anyone in His command.”

# 2167

And recite the Book of your Lord which has been divinely revealed to you; there is none who can change His Words; and you will never find a refuge besides Him.

# 2168

And restrain yourself along with those who pray to their Lord morning and evening, seeking His pleasure; and may not your sight fall on anything besides them; would you desire the adornment of the life of this world? And do not follow him whose heart We have made neglectful of Our remembrance – the one who has followed his own desires and his matter has crossed the limits.

# 2169

And proclaim, “The Truth is from your Lord”; so whoever wills may accept faith, and whoever wills may disbelieve – We have indeed prepared for the disbelievers a fire the walls of which will surround them; if they plead for water, their plea will be answered with water like molten metal which shall scald their faces; what an evil drink it is; and what an evil destination is hell!

# 2170

Indeed those who believed and did good deeds – We do not waste the reward of those whose deeds are good.

# 2171

For them are everlasting Gardens of Eden, beneath which rivers flow – in it they will be given bracelets of gold to adorn, and shall wear green clothes made of fine silk and gold embroidery, reclining upon thrones in it; what an excellent reward; and what an excellent abode is Paradise!

# 2172

And relate to them the account of the two men – to one We gave two gardens of grapes, and covered them with date-palms and kept farms between them.

# 2173

Both the gardens gave yields and gave no shortfall in it – and We made a river to flow between the two.

# 2174

And he had fruit; he therefore said to his companion – and he used to debate with him – “I exceed you in wealth, and am more powerful in respect of men.”

# 2175

He went into his garden and wronging himself said, “I do not think that this will ever perish.”

# 2176

“I do not think that the Last Day will ever be established – and even if I return to my Lord I will surely find a haven better than this garden.”

# 2177

His companion debating with him answered, “What! You disbelieve in Him Who has created you from dust, then from a drop of liquid, and then created you as a complete man?”

# 2178

“But I just say that only Allah is my Lord, and I do not ascribe anyone as a partner to my Lord.”

# 2179

“And why was it not that you would have said when you entered your garden, ‘Whatever Allah wills – we do not have any strength except with the help of Allah’ – if you had observed me lesser than you in wealth and children.”?

# 2180

“So it is likely that my Lord will give me a garden better than yours, and send bolts of lightning from the skies on your garden – it therefore turns into a barren plain.”

# 2181

“Or its water may sink into the earth, so you may never be able to find it.”

# 2182

And his fruits were surrounded – he therefore remained helplessly wringing his hands upon all that he had spent on it – and it lay fallen on its canopy – and he says, “If only I had not ascribed any partner to my Lord!”

# 2183

And he had no group to help him against Allah, nor was he capable of taking revenge.

# 2184

Here brought to light is that the authority is only for Allah, the True; the reward He bestows is the best, and believing in Him has the best outcome.

# 2185

And relate to them the example of the life of this world – like water which We sent down from the sky, therefore vegetation of the earth grew forth in abundance with it to become dry hay which the winds scatter; and Allah is the Controller of all things.

# 2186

Wealth and sons are ornaments of the life of this world; and good deeds that last – their reward is better before your Lord, and are better in respect of hope.

# 2187

And the Day when We move the hills and you see the earth flattened plain, and We shall raise all of them together – so not leaving out any one of them.

# 2188

And everyone shall be presented before your Lord in rows; “Indeed you have come to Us exactly as We had created you for the first time – in fact you thought that We shall never appoint a promised time for you!”

# 2189

And the Book shall be placed – and you will see the guilty dreading what is written in it and saying, “Woe to us – what sort of a Book is this that it has not left out any small sin nor a great one, which it has not included!” And they found all that they did confronting them; and your Lord does not wrong any one.

# 2190

And recall when We commanded the angels that, “Prostrate before Adam” – so they all prostrated, except Iblis; he was of the jinn, he therefore rebelled against his Lord’s command; “What! You choose him and his offspring as your friends instead of Me, whereas they are your enemies?” And what an evil alternative did the unjust get.

# 2191

Neither did I make them witness the creations of the heavens and the earth, nor witness their own creation; nor does it befit My Majesty to choose misleaders as aides.

# 2192

And the Day when He will proclaim, “Call those partners of Mine whom you had assumed” – so they will call out to them – they will not answer them, and We shall create a field of destruction between them.

# 2193

And when the guilty see hell, they will be certain of falling into it, and will find no place to escape from it.

# 2194

And We have indeed illustrated all kinds of examples for mankind in this Qur’an; and man is the most quarrelsome of all.

# 2195

And what prevented men from accepting faith when guidance came to them, and from asking forgiveness from their Lord except that the tradition of the former nations come upon them or that they confront various kinds of punishments?

# 2196

And We do not send the Noble Messengers except as Heralds of glad tidings and warnings; and the disbelievers debate by means of falsehood to drive away the Truth with it, and they took My signs and warnings they were given, as a mockery!

# 2197

And who is more unjust than one who, when reminded of the signs of his Lord, turns away from them and forgets what his hands have sent forward? We have put covers on their hearts so as not to understand the Qur’an, and deafness in their ears; and even if you call them to guidance, they will never attain the right path.

# 2198

And your Lord is the Oft Forgiver, the Merciful; if He seized them for their deeds, He would soon send the punishment upon them; but for them is an appointed time from which they will not find any refuge.

# 2199

And these towns – We destroyed them when they committed injustice, and We had set an appointed time for their destruction.

# 2200

And recall when Moosa said to his assistant, “I will not give up until I reach the place where the two seas meet or until I have progressed for ages.”

# 2201

And when they reached the place where the two seas meet, they forgot about their fish, and it took its way into the sea, making a tunnel. (The dead fish came alive and went into the water.)

# 2202

So when they had gone beyond that place, Moosa said to his assistant, “Bring our breakfast – we have indeed faced great exertion in this journey of ours.”

# 2203

He said, “Just imagine – when we had taken shelter near the rock, so indeed I forgot the fish; and none but Satan caused me to forget to mention it; and the fish took its way into the sea – its amazing!”

# 2204

Said Moosa, “This is exactly what we wanted”; so they came back retracing their steps.

# 2205

So they found a bondman\* from amongst Our (chosen) bondmen, to whom We had given mercy from Us, and had bestowed the inspired knowledge from Ourselves. (\* Hazrat Khidr – peace be upon him.)

# 2206

Moosa said to him, “May I stay with you upon the condition that you will teach me the righteousness that you have been taught?”

# 2207

He said, “You will never be able to patiently stay with me.”

# 2208

“And how will you bear something which your knowledge does not encompass?”

# 2209

Said Moosa, “Allah willing, you will soon find me patient and I will not do anything against your instructions.”

# 2210

He said, “Therefore if you stay with me, do not ask me about anything until I myself mention it to you.”

# 2211

So they both set out; until when they had boarded the boat, the chosen bondman ruptured the boat; said Moosa, “Did you make a hole in the boat in order to drown its passengers? You have indeed done an evil thing.”

# 2212

He said, “Did I not say that you will never be able to patiently stay with me?”

# 2213

Said Moosa, “Do not apprehend me upon my forgetting, and do not impose difficulty on me in my task.”

# 2214

So they set out again; until when they met a boy, the chosen bondman slew him – Moosa said, “Did you slay an innocent soul not in retribution for another? You have indeed done an extremely evil thing.”

# 2215

He said, “Did I not tell you that you will never be able to patiently stay with me?”

# 2216

Said Moosa, “If I ask you anything after this, do not stay with me; indeed your condition from me is fulfilled.”

# 2217

So they both set out again; until they came to the people of a dwelling – they asked its people for food – they refused to invite them – then in the village they both found a wall about to collapse, and the chosen bondman straightened it; said Moosa, “If you wished, you could have taken some wages for it!”

# 2218

He said, “This is the parting between you and me; I shall now tell you the interpretation of the matters you could not patiently bear.”

# 2219

“In respect of the boat – it belonged to the poor people who worked on the river, so I wished to flaw it – and behind them was a king who would capture every sound ship.”

# 2220

“And in respect of the boy – his parents were Muslims and we feared that he may incite them to rebellion and disbelief.”

# 2221

“So we wished that their Lord may bestow them a child – better, purer and nearer to mercy.”

# 2222

“And in respect of the wall – it belonged to two orphan boys of the city, and beneath it was their treasure, and their father was a virtuous man; therefore your Lord willed that they should reach their maturity and remove their treasure; by the mercy of your Lord; and I have not done this at my own command; this is the interpretation of the matters you could not patiently bear.” (\* Hazrat Khidr was given the knowledge of the hidden – as in all three explanations he gave).

# 2223

And they ask you regarding Zul-Qarnain; say, “I shall recite his story to you.”

# 2224

Indeed We gave him authority in the land and bestowed him the means of everything.

# 2225

He therefore pursued a purpose.

# 2226

To the extent that when he reached the setting-place of the sun, he found it setting in a muddy spring, and found a nation there; We said, “O Zul-Qarnain – either punish them or choose kindness for them.”

# 2227

He submitted, “Regarding one who has done injustice, we shall soon punish him – he will then be brought back to his Lord, Who will punish him severely.”

# 2228

“And regarding one who believed and did good deeds – so his reward is goodness; and we shall soon give him an easy command.”

# 2229

He again pursued a purpose.

# 2230

To the extent that when he reached the rising-place of the sun, he found it rising upon a nation for which We had not kept any shelter from it.

# 2231

So it is; and Our knowledge encompasses all that he possessed.

# 2232

He again pursued a purpose.

# 2233

Until, when he came between two mountains, he found before them a nation that did not appear to understand any speech.

# 2234

They said, “O Zul-Qarnain – indeed Yajuj and Majuj\* are spreading chaos in the land – so shall we assign for you a consideration upon the condition that you set up a wall between us and them?” (\* Gog and Magog.)

# 2235

He said, “That which my Lord has given me control over is better, therefore help me with strength – I shall set up a barrier between you and them.”

# 2236

“Give me sheets of iron”; until when he had raised the wall equal to the edge of the two mountains, he said, “Blow”; to the extent that he made it ablaze – he said, “Bring me molten copper to pour upon it.”

# 2237

Therefore Yajuj and Majuj were neither able to surmount it, nor could they pierce it.

# 2238

He said, “This is the mercy of my Lord; then when the promise of my Lord arrives, He will blow it to bits; and my Lord’s promise is true.”

# 2239

And on that day We shall release them in groups surging like waves one after another, and the Trumpet will be blown – so We shall gather them all together. (\* Gog and Magog will come out during the time of Eisa (Jesus – when he comes back to earth) and cause great destruction in the land.)

# 2240

And We shall bring hell in front of the disbelievers.

# 2241

The ones whose eyes were covered from My remembrance, and who could not bear to hear Truth.

# 2242

Do the disbelievers assume that they will be able to choose My bondmen as supporters other than Me? Indeed We have prepared hell to welcome the disbelievers.

# 2243

Say (O dear Prophet Mohammed – peace and blessings be upon him), “Shall we inform you whose are the most failed works?”

# 2244

“Of those whose efforts are lost in (pursuit of) the life of this world, and they think that they are doing good deeds.”

# 2245

The people who disbelieved in the signs of their Lord and in the meeting with Him, therefore all their deeds are in vain –We shall therefore not establish any weighing for them on the Day of Resurrection.

# 2246

This is their reward – hell – because they disbelieved, and made a mockery of My verses and My Noble Messengers.

# 2247

Indeed those who believed and did good deeds – their welcome are the Gardens of Paradise.

# 2248

They will abide in it for ever, never wanting to shift from it.

# 2249

Proclaim, “If the sea became ink for the Words of my Lord, the sea would indeed be used up and the Words of my Lord would never – even if we bring another like it for help.”

# 2250

Proclaim, “Physically I am a human\* like you – my Lord sends divine revelations to me – that your God is only One God; so whoever expects to the meet his Lord must perform good deeds and not ascribe anyone as a partner in the worship of his Lord.” (\* Human but not equal to you, in fact the greatest in spiritual status.)

# 2251

Kaf-Ha-Ya-A’in-Sad. (\* Alphabets of the Arabic language – Allah and to whomever He reveals know their precise meanings.)

# 2252

This is the remembrance of the mercy of your Lord upon His bondman Zakaria.

# 2253

When he softly prayed to his Lord.

# 2254

He submitted, “O my Lord – my bones have become weak and old age shines forth from my head, and O my Lord, I have never been disappointed in my prayer to you.”

# 2255

“And I fear my relatives after me and my wife is barren therefore bestow upon me from Yourself one who will take up my work.”

# 2256

“He being my successor and the heir of the Descendants of Yaqub (Jacob); and my Lord, make him a cherished\* one.” (\* Make him a Prophet among the Descendants of Israel.)

# 2257

“O Zakaria! We give you the glad tidings of a son whose name is Yahya (John) – before him, We have not created anyone of this name.”

# 2258

He submitted, “My Lord – how can I have a son whereas my wife is barren and I have reached infirmity due to old age?”

# 2259

He (the angel) said, “So it is; your Lord says, ‘This is easy for Me – in fact I created you before this, at a time when you did not exist.’”

# 2260

He said, “My Lord, give me a sign”; He said, “Your token is that you will not speak to people for three nights, although in proper health.”

# 2261

He therefore emerged upon his people from the mosque, and told them through gestures, “Keep proclaiming the Purity (of your Lord) morning and evening.”

# 2262

“O Yahya – hold the Book firmly”; and We gave him Prophethood in his infancy. (Prophet Yahya was only 2 years old at that time.)

# 2263

And compassion from Ourselves, and chastity; and he was extremely pious.

# 2264

And was good to his parents and not forceful, nor disobedient.

# 2265

And peace is upon him the day he was born, and the day he will taste death, and the day he will be raised alive.

# 2266

And remember Maryam in the Book; when she went away from her family to a place towards east.

# 2267

So there she screened herself from them; We therefore sent Our Spirit towards her – he appeared before her in the form of a healthy man. (Angel Jibreel – peace be upon him.)

# 2268

She said, “I seek the refuge of the Most Gracious from you – if you fear God.”

# 2269

He said, “I am indeed one sent by your Lord; so that I may give you a chaste son.”

# 2270

She said, “How can I bear a son? No man has ever touched me, nor am I of poor conduct!”

# 2271

He said, “So it is; your Lord has said, ‘This is easy for Me’; and in order that We make him a sign for mankind and a Mercy from Us; and this matter has been decreed.”

# 2272

So she conceived him, and she went away with him to a far place.

# 2273

Then the pangs of childbirth brought her to the base of the palm-tree; she said, “Oh, if only had I died before this and had become forgotten, unremembered.”

# 2274

(The angel) Therefore called her from below her, “Do not grieve – your Lord has made a river flow below you.”

# 2275

“And shake the trunk of the palm-tree towards you – ripe fresh dates will fall upon you.” (This was a miracle – the date palm was dry and it was winter season.)

# 2276

“Therefore eat and drink and appease your eyes; so if you meet any person then say, ‘I have pledged a fast (of silence) to the Most Gracious – I will therefore not speak to any person today.’”

# 2277

So carrying him in her arms, she brought him to her people; they said, “O Maryam, you have indeed committed a great evil!”

# 2278

“O sister of Haroon, neither was your father an evil man nor was your mother of poor conduct!”

# 2279

Thereupon she pointed towards the child; they said, “How can we speak to an infant who is in the cradle?”

# 2280

The child proclaimed, “I am Allah’s bondman; He has given me the Book and made me a Herald of the Hidden (a Prophet).”

# 2281

“And He has made me blessed wherever I be; and ordained upon me prayer and charity, as long as I live.”

# 2282

“And has made me good to my mother and not made me forceful, ill-fated.”

# 2283

“And peace is upon me the day I was born, and on the day I shall taste death, and on the day I will be raised alive.”

# 2284

This is Eisa (Jesus), the son of Maryam; a true statement, in which they doubt.

# 2285

It does not befit Allah to appoint someone as His son – Purity is to Him! When He ordains a matter, He just commands it, “Be” – and it thereupon happens.

# 2286

And said Eisa, “Indeed Allah is my Lord and your Lord – therefore worship Him; this is the Straight Path.”

# 2287

Then groups among them differed; so ruin is for the disbelievers from the witnessing of a Great Day.

# 2288

Much will they listen and much will they see, on the Day when they come to Us, but today the unjust are in open error.

# 2289

And warn them of the Day of Regret when the matter will have been decided; and they are in neglect, and they do not accept faith.

# 2290

Indeed We shall inherit the earth and all that is on it, and only towards Us will they return.

# 2291

And remember Ibrahim in the Book; he was very truthful, a Herald of the Hidden (a Prophet).

# 2292

When he said to his father,\* “O my father – why do you worship one which neither hears nor sees, and cannot benefit you in any way?” (\* His uncle Azar.)

# 2293

“O my father, indeed a knowledge has come to me which did not come to you – therefore follow me, I will show you the Straight Path.”

# 2294

“O my father, do not be a bondman of the devil; indeed the devil is disobedient towards the Most Gracious.”

# 2295

“O my father, I fear that a punishment from the Most Gracious may reach you, so you would become a companion of the devil.”

# 2296

He said, “What! You turn away from my Gods, O Ibrahim? If you do not desist, I will certainly stone you, and keep no relation with me for a long while.”

# 2297

He said, “Stop it – peace be upon you; I shall seek forgiveness for you from my Lord; indeed He is very kind to me.”

# 2298

"And I shall remain separated from you and all that you worship other than Allah and shall worship my Lord; possibly, by worshipping my Lord, I will not be amongst the unfortunate.”

# 2299

So when he had separated from them and what they worshipped other than Allah, We bestowed him Ishaq and Yaqub; and We made each of them a Herald of the Hidden.

# 2300

And We gave them Our mercy, and assigned for them a true and high repute.

# 2301

And remember Moosa in the Book; he was indeed a chosen one, and he was a Noble Messenger, a Herald of the Hidden.

# 2302

We called him from the right side of the mountain Tur, and brought him close to reveal Our secret.

# 2303

And with Our mercy We bestowed upon him his brother Haroon, a Prophet.

# 2304

And remember Ismail in the Book; he was indeed true to his promise and was a Noble Messenger, a Prophet.

# 2305

He used to command his people to offer prayer and give charity, and was liked by his Lord.

# 2306

And remember Idrees in the Book; he was indeed very truthful, a Prophet.

# 2307

And We lifted him to a high position. (Living with soul & body in heaven, after his death.)

# 2308

It is these upon whom Allah has bestowed favour among the Prophets, from the descendants of Adam; and from those whom We boarded along with Nooh; and from the descendants of Ibrahim and Israel; and from those whom We guided and chose; when the verses of the Most Gracious were recited to them, they fell down, prostrating and weeping. (\* Command of Prostration # 5.)

# 2309

And after them came the unworthy successors who squandered prayer and pursued their own desires, so they will soon encounter the forest of Gai in hell.

# 2310

Except those who repented and accepted faith and did good deeds – so these will enter heaven, and they will not be deprived\* in the least. (\* Of their due reward.)

# 2311

Everlasting Gardens of Eden, which the Most Gracious has promised to His bondmen in the unseen; indeed His promise will come.

# 2312

They will not hear any lewd talk in it, but only Peace; and in it for them is sustenance, every morning and evening.

# 2313

It is the Paradise that We will bequeath to those among Our bondmen who remain pious.

# 2314

(Said Angel Jibreel to Prophet Mohammed – peace and blessings be upon them) “And we angels do not come down except by the command of your Lord; to Him only belongs all that is ahead of us and all that is behind us and all that is between them; and your Lord is not forgetful.”

# 2315

Lord of the heavens and the earth and all that is between them – therefore worship Him and be firm in His worship; do you know any other of the same name as His?

# 2316

And says man, “When I am dead, will I soon be brought forth alive?”

# 2317

Does not man remember that We created him before this, and he was non existent?

# 2318

So by your Lord, We shall assemble them and the devils – all of them – and bring them around hell, fallen on their knees.

# 2319

We shall then pick out from every group the one who was most arrogant towards the Most Gracious.

# 2320

Moreover, We well know those who most deserve to be burned in hell.

# 2321

And there is none among you who shall not pass over hell; this is an obligatory affair, binding upon your Lord. (Allah will make everyone pass over the back of hell – on a thin bridge.)

# 2322

We shall then rescue the pious – and leave the unjust in it, fallen on their knees.

# 2323

And when Our clear verses are recited to them, the disbelievers say to the Muslims, “Which group has a better home, and a better alliance?”

# 2324

And many a generation We did destroy before them, who exceeded them in wealth and pomp!

# 2325

Proclaim, “For one in error – so the Most Gracious may give him respite; to the extent that when they see the thing which they are promised – either the punishment or the Last Day; so then they will come to know for whom is the evil rank and whose army is weak.”

# 2326

And Allah will increase the guidance for those who have received guidance; and good deeds that remain have the best reward before your Lord, and the best outcome.

# 2327

So have you seen him who denied Our signs and says, “I shall certainly be given wealth and children?”

# 2328

Has he seen the Hidden, or has he made a pact with the Most Gracious?

# 2329

Never; We shall now record what he says and give him a prolonged punishment.

# 2330

And it is We only Who shall inherit what he says (belongs to him), and he will come to Us, alone.

# 2331

And they have chosen Gods besides Allah, so that they may provide them strength!

# 2332

Never; soon they will deny ever worshipping them, and will turn into their opponents.

# 2333

Did you not see that We sent devils upon the disbelievers, so they excite them abundantly?

# 2334

So do not be impatient for them (O dear Prophet Mohammed – peace and blessings be upon him); We are only completing their number.\* (\* The number of days left for them or their evil deeds.)

# 2335

On the day when We shall assemble the righteous towards the Most Gracious, as guests.

# 2336

And drive the guilty towards hell, thirsty.

# 2337

People do not own the right to intercede, except those\* who have made a covenant with the Most Gracious. (\* The Holy Prophets and virtuous people will be given the permission to intercede. Prophet Mohammed – peace and blessings be upon him – will be the first to intercede.)

# 2338

And the disbelievers said, “The Most Gracious has chosen an offspring.”

# 2339

You have indeed brought an extremely grave speech!

# 2340

The heavens are close to being torn apart by it, and the earth being split asunder, and the mountains succumbing and falling down.

# 2341

Due to their ascribing of an offspring to the Most Gracious.

# 2342

And it does not befit the Most Gracious to choose an offspring!

# 2343

All those who are in the heavens and the earth will come to the Most Gracious as His bondmen.

# 2344

He knows their number and has counted each one of them.

# 2345

And each one of them will come before Him on the Day of Resurrection, alone.

# 2346

Indeed those who believed and did good deeds – the Most Gracious will appoint love for them. (In the hearts of other believers.)

# 2347

We have therefore made this Qur’an easy upon your tongue, (O dear Prophet Mohammed – peace and blessings be upon him) for you to announce glad tidings with it to those who fear, and warn those who are quarrelsome.

# 2348

And many a generation We did destroy before them; do you see any one of them or hear their faintest sound?

# 2349

Ta-Ha.\* (O dear Prophet Mohammed – peace and blessings be upon him) (Alphabets of the Arabic language – Allah and to whomever He reveals know their precise meanings.)

# 2350

We have not sent down this Qur’an upon you (O dear Prophet Mohammed – peace and blessings be upon him) for you to fall into hardship! (Either because he used to pray at length during the night or because he was distressed due to the disbelievers not accepting faith.)

# 2351

Except as a reminder for one who fears.

# 2352

Sent down by One Who created the earth and the lofty heavens.

# 2353

The Most Gracious Who, befitting His Majesty, took to the Throne (of control).

# 2354

To Him only belongs all whatever is in the heavens and all whatever is in the earth, and all whatever is between them, and all whatever is beneath this wet soil.

# 2355

And if you speak aloud – so He surely knows the secret and that which is more concealed.

# 2356

Allah – there is no worship except for Him; His only are the best names.

# 2357

And did the news of Moosa reach you?

# 2358

When he saw a fire and said to his wife, “Wait – I have seen a fire – perhaps I may bring you an ember from it or find a way upon the fire.”

# 2359

So when he came near the fire, it was announced, “O Moosa!”

# 2360

“Indeed I am your Lord, therefore take off your shoes; indeed you are in the holy valley of Tuwa!”

# 2361

“And I have chosen you, therefore listen carefully to what is divinely revealed to you.”

# 2362

“Indeed it is Me, Allah – there is no God except I – therefore worship Me and keep the prayer established for My remembrance.”

# 2363

“The Last Day will surely come – it was close that I hide it from all – in order that every soul may get the reward of its effort.” (He revealed it to His Prophets, so that people may fear and get ready. The exact time is not revealed to the people.)

# 2364

“Therefore never let one, who does not accept faith in it and follows his own desires, prevent you from accepting this, so then you become ruined.”

# 2365

“And what is this in your right hand, O Moosa?”

# 2366

He said, “This is my staff; I support myself on it, and I knock down leaves for my sheep with it, and there are other uses for me in it.”

# 2367

He said, “Put it down, O Moosa!

# 2368

So Moosa put it down – thereupon it became a fast moving serpent.

# 2369

He said, “Pick it up and do not fear; We shall restore it to its former state.”

# 2370

“And put your hand inside your armpit – it will come out shining white, not due to any illness – one more sign.”

# 2371

“In order that We may show you Our great signs.”

# 2372

“Go to Firaun, he has rebelled.”

# 2373

Said Moosa, “My Lord, open up my breast for me.”

# 2374

“And make my task easy for me.”

# 2375

“And untie the knot of my tongue.”

# 2376

“In order that they may understand my speech.”

# 2377

“And appoint for me a viceroy from among my family.”

# 2378

“That is Haroon, my brother.”

# 2379

“Back me up with him.”

# 2380

“And make him a partner in my task.”

# 2381

“In order that we may profusely proclaim Your Purity.”

# 2382

“And profusely remember You.”

# 2383

“Indeed You see us.”

# 2384

He said, “O Moosa, you have been granted your prayer.”

# 2385

“And indeed We had bestowed upon you a favour one more time.”

# 2386

“When We inspired in your mother’s heart whatever was to be inspired.”

# 2387

“That, ‘Put him into a chest and cast it into the river, so the river shall deposit it on to a shore – therefore one who is an enemy to Me and you, shall pick him up’; and I bestowed upon you love from Myself; and for you to be brought up in My sight.”

# 2388

“When your sister went, then said, ‘Shall I show you the people who may nurse him?’ And We brought you back to your mother in order to soothe her eyes and that she may not grieve; and you killed a man, so We freed you from sorrow, and tested you to the maximum; you therefore stayed for several years among the people of Madyan; then you came (here) at an appointed time, O Moosa.”

# 2389

“And I created you especially for Myself.”

# 2390

“You and your brother, both go with My signs, and do not slacken in My remembrance.”

# 2391

“Both of you go to Firaun; he has indeed rebelled.”

# 2392

“And speak to him courteously, that perhaps he may ponder or have some fear.”

# 2393

They both submitted, “Our Lord – indeed we fear that he may oppress us or deal mischievously.”

# 2394

He said, “Do not fear – I am with you, All Hearing and All Seeing.”

# 2395

“Therefore go to him and say, ‘We are the sent ones of your Lord, therefore let the Descendants of Israel go with us, and do not trouble them; we have indeed brought to you a sign from your Lord; and peace be upon him who follows the guidance.’

# 2396

‘It has indeed been revealed to us that the punishment is upon the one who denies and turns away.’”

# 2397

Said Firaun, “So who is the Lord of you both, O Moosa?”

# 2398

He said, “Our Lord is One Who gave everything its proper shape, then showed the path.”

# 2399

Said Firaun, “What is the state of the former generations?”

# 2400

He said, “Their knowledge is with my Lord, (recorded) in a Book; my Lord neither strays nor forgets.”

# 2401

The One Who has made the earth a bed for you and kept operative roads for you in it and sent down water from the sky; so with it We produced different pairs of vegetation.

# 2402

Eat, and graze your cattle; indeed in this are signs for people of intellect.

# 2403

From the earth We have created you, and to it We shall return you, and from it We shall raise you again.

# 2404

And indeed We showed him all Our signs – so he denied them and did not accept.

# 2405

He said, “Have you come to us in order to expel us from our land by your magic, O Moosa?”

# 2406

“So we will also produce before you a similar magic, therefore set up an agreed time between us and you, from which neither we nor you shall turn away, at a level place.”

# 2407

Said Moosa, “Your meeting is the day of the festival, and that the people be assembled at late morning.”

# 2408

So Firaun went away and gathered his schemes,\* then came. (\* 72000 magicians and their materials.)

# 2409

Moosa said to them, “Ruin is to you – do not fabricate a lie against Allah, that He may destroy you by a punishment; and indeed one who fabricates lies has failed.”

# 2410

So they differed with one another in their task, and secretly conferred.

# 2411

They said, “Undoubtedly these two are magicians for sure, who wish to expel you from your land by the strength of their magic, and destroy your exemplary religion!”

# 2412

“Therefore strengthen your scheme, and come forth in rows; indeed whoever dominates this day has succeeded.”

# 2413

They said, “O Moosa, either you throw first – or shall we throw first?”

# 2414

He said, “Rather, you may throw”; thereupon their cords and their staves, by the strength of their magic, appeared to him as if they were (serpents) moving fast.

# 2415

And Moosa sensed fear in his heart.

# 2416

We said, “Do not fear – it is you who is dominant.”

# 2417

“And cast down which is in your right hand – it will devour all that they have fabricated; what they have made is only a magician’s deceit; and a magician is never successful, wherever he comes.”

# 2418

Therefore all the magicians were thrown down prostrate – they said, “We accept faith in the One Who is the Lord of Haroon and Moosa.”

# 2419

Said Firaun, “You accepted faith in him before I permitted you! He is indeed your leader who taught you magic; I therefore swear, I will cut off your hands and your legs from alternate sides, and crucify you on the trunks of palm-trees, and you will surely come to know among us two, whose punishment is more severe and more lasting.”

# 2420

They said, “We shall never prefer you above the clear proofs that have come to us from the One Who has created us – therefore carry out what you want to; only in the life of this world will you be able to!”

# 2421

“Indeed we have accepted faith in our Lord, so that He may forgive us our sins and the magic which you forced us to perform; and Allah is Better, and the Most Lasting.”

# 2422

Indeed the one who comes guilty to his Lord – so undoubtedly for him is hell; neither dying nor living in it.

# 2423

And the one who presents himself as a believer before Him, having done good deeds – so for them are the high ranks.

# 2424

Everlasting Gardens of Eden beneath which rivers flow, abiding in them for ever; and this is the reward of one who became pure.

# 2425

And We divinely inspired Moosa that, “Journey with My bondmen in a part of the night and strike a dry path in the sea for them, you shall have no fear of Firaun getting to you, nor any danger.”

# 2426

So Firaun went after them with his army – therefore the sea enveloped them, the way it did.

# 2427

And Firaun led his people astray, and did not guide them.

# 2428

O Descendants of Israel, indeed We rescued you from your enemy, and We made a covenant with you on the right side of Mount Tur, and sent down Manna and Salwa upon you.

# 2429

“Eat the good clean things We have provided you, and do not exceed the limits in respect of it causing My wrath to descend upon you; and indeed the one on whom My wrath descended, has fallen.”

# 2430

And indeed I am Most Oft Forgiving for him who repented and accepted faith and did good deeds, and then remained upon guidance.

# 2431

“And why did you come in haste ahead of your people, O Moosa?”

# 2432

He submitted, “They are here, just behind me – and O my Lord, I hastened towards You, in order to please You.”

# 2433

He said, “We have therefore tried your people after you came, and Samri has led them astray.”

# 2434

So Moosa turned back to his people, angry and grieving; he said, “O my people, had not your Lord given you a good promise? Did a long time pass away for you, or did you wish that your Lord’s wrath come upon you, therefore you broke your promise with me?”

# 2435

They said, “We did not renege on our promise to you on our own will, but we were made to carry the burdens of ornaments of the people, so we cast them – and similarly did Samri cast.”

# 2436

He therefore made a calf for them – a lifeless body, making sounds like a cow – so they said, “This is your God and the God of Moosa; whereas Moosa has forgotten.”

# 2437

So do they not see that it does not answer to any of their speech? And has no power to cause them any harm or benefit?

# 2438

And undoubtedly Haroon had told them before it that, “O my people – you have needlessly fallen into trial because of this; and indeed your Lord is the Most Gracious, therefore follow me and obey my command.”

# 2439

They said, “We will continue to squat\* before it, till Moosa returns to us.” (\* Continue worshipping it.)

# 2440

Said Moosa, “O Haroon – what prevented you when you saw them going astray?”

# 2441

“That you did not come after me? So did you disobey my order?”

# 2442

He said, “O son of my mother, do not clutch my beard nor the hair on my head; I feared that you may say, ‘You have caused a division among the Descendants of Israel and did not wait for my advice.’”

# 2443

Said Moosa, “And what is your explanation, O Samri?”

# 2444

He said, “I witnessed what the people did not witness – I therefore took a handful from the tracks\* of the angel, then threw it\*\* – and this is what seemed pleasing to my soul.” (\* The marks left behind by the mount of Angel Jibreel. \*\* Into the mouth of the calf.)

# 2445

Said Moosa, “Therefore go away, for in this life your punishment is that you exclaim ‘Do not touch!’\* And indeed for you is a time appointed, which you cannot break; and look at your deity, in front of which you remained squatting the whole day; we swear we will surely burn it and, smashing it into bits, discharge it into the river.” (\* He was cursed with a disease.)

# 2446

“Your God is only Allah – other than for Whom there is no worship; His knowledge encompasses all things.”

# 2447

This is how We relate the former tidings to you (O dear Prophet Mohammed – peace and blessings be upon him); and We have given you a Remembrance\* from Ourselves. (\*The Holy Qur’an.)

# 2448

Whoever turns away from it, will bear a burden on the Day of Resurrection.

# 2449

They will remain in it forever – what an evil burden it will be for them on the Day of Resurrection!

# 2450

On the day when the Trumpet is blown and We shall assemble the guilty on that day, blue -eyed.

# 2451

Whispering secretly among themselves, “You have not stayed on earth but for ten days.”

# 2452

We know well what they will utter, whereas the wisest among them will say, “You have stayed just for a day.”

# 2453

They ask you regarding the mountains; proclaim, “My Lord will blow them into bits and scatter them.”

# 2454

“Therefore leaving the earth just as an empty plain.”

# 2455

“In which you shall neither see ups nor downs.”

# 2456

On that day they will run after a caller, there will be no deviation in it; and voices shall become hushed before the Most Gracious, so you will not hear except a faint sound.

# 2457

On that day no one’s intercession shall benefit except his to whom the Most Gracious has given permission and whose word He has liked. (The Holy Prophets and virtuous people will be given the permission to intercede. Prophet Mohammed – peace and blessings be upon him – will be the first to intercede.)

# 2458

He knows all that is before them and all that is behind them, whereas their knowledge cannot encompass it.

# 2459

And all faces shall bow before the Living, the All Sustaining; and the one who bore the burden of injustice, has failed.

# 2460

And the one who does some good deeds, and is a Muslim – he shall have no fear of injustice, nor suffer any loss.

# 2461

And this is how We revealed it as an Arabic Qur’an, and in different ways gave promises of punishment, that they may fear or it may create some pondering in their hearts.

# 2462

Therefore Supreme is Allah, the True King; and do not hasten in the Qur’an (O dear Prophet Mohammed – peace and blessings be upon him) until its divine revelation has been completed to you; and pray, “My Lord, bestow me more knowledge.”

# 2463

And indeed before this We made a covenant with Adam, so he forgot, and We did not find its intention (in him).

# 2464

And when We commanded the angels, “Prostrate before Adam” – so they all prostrated, except Iblis; he refused.

# 2465

We therefore said, “O Adam, he is your and your wife’s enemy, so may he not get you both out from heaven, so you then fall into hardship.”

# 2466

“Indeed for you in heaven is that you may never be hungry nor be unclothed.”

# 2467

“And that you never feel thirsty nor hot sunshine hurt you.”

# 2468

So the devil incited him, saying, “O Adam, shall I show you the tree of immortality and a kingdom that does not erode?”

# 2469

So they both ate from it – thereupon their shame became manifest to them, and they started applying on themselves the leaves of heaven; and Adam lapsed in obeying his Lord, so did not reach his goal. (Of achieving immortality)

# 2470

Then his Lord chose him, and inclined towards him with His mercy, and guided him.

# 2471

He said, “Both of you go down from heaven, one of you is an enemy to the other; then if the guidance from Me comes to you – then whoever follows My guidance, will not go astray nor be ill-fated.”

# 2472

“And the one who turned away from My remembrance – for him is a confined existence, and We shall raise him blind on the Day of Resurrection.”

# 2473

He will say, “O my Lord, why have You raised me blind, whereas I was sighted?”

# 2474

He will say, “Similarly did Our signs come to you but you forgot them; and in the same way, nobody will heed you today.”

# 2475

And this is how We reward him who transgresses and does not accept faith in the signs of his Lord; and indeed the punishment of the Hereafter is the most severe and more lasting.

# 2476

So did they not gain guidance from (knowing) how many generations We have destroyed before them, among whose dwellings they walk? Indeed in it are signs for men of intellect.

# 2477

And had not a command of your Lord been passed, then the punishment would have gripped them – and had a term not been appointed.

# 2478

Therefore (O dear Prophet Mohammed – peace and blessings be upon him), patiently forbear upon their speech, and praising your Lord proclaim His Purity, before the sun rises and before it sets; and proclaim His Purity at some times of the night and at the two ends of the day, in the hope that you be pleased. (\*With the great reward from your Lord)

# 2479

And O listener, do not extend your eyes towards what We have given to disbelieving couples to enjoy – the bloom of the worldly life – so that We may test them with it; and the sustenance of your Lord is the best, and more lasting.

# 2480

And command your household to establish prayer, and yourself be steadfast in it; We do not ask any sustenance from you; We will provide you sustenance; and the excellent result is for piety.

# 2481

And the disbelievers said, “Why does he not bring to us a sign from his Lord?”; did not the explanation of what is in the former Books, come to them?

# 2482

And had We destroyed them with some punishment before the advent of a Noble Messenger, they would have certainly said, “Our Lord, why did You not send a Noble Messenger to us, so we would have followed Your signs, before being humiliated and disgraced?”

# 2483

Proclaim, “Each one is waiting; so you too wait; very soon you will come to know who are the people of the right path, and who has attained guidance.”

# 2484

The people’s reckoning is near, whereas they are in neglect, turned away!

# 2485

Whenever a new advice comes to them from their Lord, they do not listen to it except while playing.

# 2486

Their hearts are involved in play; and the unjust secretly conferred, “What is he, except another a human like you?! So do you follow magic although you have perceived?”

# 2487

And the Prophet said, “My Lord knows all that is spoken in the heavens and in the earth; and He only is the All Hearing, the All Knowing."

# 2488

Rather they said, “These are confused dreams, but in fact he has fabricated it – but in fact he is a poet; so he must bring us some sign, like those who were sent before.”

# 2489

There is not a township before them which did not believe which We have not destroyed; so will they believe?

# 2490

And We did not send (Prophets) before you except men, to whom We sent divine revelations – therefore, O people, ask the people of knowledge if you do not know.

# 2491

And We did not create them without bodies so they would not eat food – nor that they abide on earth forever.

# 2492

We then fulfilled the promise to them, therefore rescued them and whomever We willed, and destroyed the transgressors.

# 2493

We have indeed sent down towards you a Book, in which is your repute; so do you not have sense?

# 2494

And many a township did We destroy, for they were unjust, and We created other nations after them.

# 2495

And when they tasted Our punishment, they immediately started fleeing from it.

# 2496

The angels said to them, “Do not flee and return to the comforts that were given to you and to your homes, perhaps you will be questioned.”

# 2497

They cried, “Woe to us, we were indeed unjust!”

# 2498

So they kept saying this until We made them cut off, extinguished.

# 2499

And We have not created the heavens and the earth and all that is between them, unnecessarily.

# 2500

If We willed to choose a pastime, We could have chosen it from Ourselves – if We wanted to.

# 2501

But in fact We hurl the truth upon falsehood, so it scatters its brains – thereupon it vanishes; and for you is the ruin due to the matters you fabricate.

# 2502

And to Him only belong all those who are in the heavens and in the earth; and those with Him are not conceited towards worshipping Him, nor do they tire.

# 2503

They say His Purity night and day, and do not slacken.

# 2504

Have they appointed from the earth, Gods that create something?

# 2505

If other than Allah, there were Gods\* in the heavens and the earth, they would be destroyed; therefore Purity is to Allah, Owner of the Throne, from the matters that they fabricate. (\* Which is not possible. \*\* The heavens and the earth.)

# 2506

He is not questioned whatever He does, whereas they will all be questioned.

# 2507

Or have they set up other Gods besides Allah? Say, “Bring your proof; this is the remembrance of those with me and those before me”; but in fact most of them do not know the Truth, so they turn away.

# 2508

And We did not send any Noble Messenger before you, but We divinely revealed to him that, “There is no God except I (Allah), therefore worship Me alone.”

# 2509

And they said, “The Most Gracious has chosen a son – Purity is to Him! In fact they are honourable bondmen.”

# 2510

They do not speak before He has, and they act only at His command.

# 2511

He knows what is before them and what is behind them, and they do not intercede except for him whom He likes, and they fear with awe of Him. (The Holy Prophets and virtuous people will be given the permission to intercede. Prophet Mohammed – peace and blessings be upon him – will be the first to intercede.)

# 2512

And the one among them who says, “I am a God beside Allah” – We shall reward him with hell; this is how We punish the unjust.

# 2513

Did not the disbelievers observe that the heavens and the earth were together, so We parted them, and we made every living thing from water? So will they not accept faith?

# 2514

And We have placed mountains as anchors in the earth so that it may not shake with them; and We kept wide roads in it, so that they may find guidance.

# 2515

And We have made the sky a roof, protected; and they turn away from its signs.

# 2516

And it is He Who created the night and the day, and the sun and the moon; each one floats in an orbit.

# 2517

And before you, We did not appoint on earth a never-ending life for any human; will they, if you depart, become immortal?

# 2518

Every living being must taste death; and We test you with harm and with good – a trial; and to Us only you have to return.

# 2519

And when the disbelievers see you, they do not appoint you except as an object of mockery; “Is he the one who speaks ill of your Gods?”; whereas they deny the remembrance of the Most Gracious Himself!

# 2520

Man has been created hasty; very soon I shall show you My signs, do not be impatient.

# 2521

And they say, “When will this promise occur, if you are truthful?

# 2522

If only the disbelievers realised the time when they will not be able to stop the fire from their faces and from their backs – and nor are they to be helped.

# 2523

In fact it will suddenly come upon them, therefore shocking them, and they will not be able to repel it nor will they be given respite.

# 2524

And indeed the Noble Messengers before you were mocked at, but their mockery ruined the mockers themselves.

# 2525

Proclaim, “Who guards you night and day from the Most Gracious?” In fact they have turned away from the remembrance of their Lord.

# 2526

Do they have some Gods who protect them from Us? Neither can they save themselves nor save their friends from Us.

# 2527

But in fact We have given these (disbelievers) and their fathers a benefit to the extent that life became long for them; so do they not see that We are reducing the land from its borders? So will these be victorious?

# 2528

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him) “I warn you only with the divine revelation; and the deaf do not hear the call when warned.”

# 2529

And if a whiff of your Lord’s punishment were to touch them, they would certainly say, “Woe to us – we were indeed unjust!”

# 2530

And We shall set up the scales of justice on the Day of Resurrection – therefore no soul will be wronged in the least; and if a thing is equal to a grain of mustard seed, We will bring it; and We are Sufficient to (take) account.

# 2531

And indeed We gave Moosa and Haroon the Judgement\* and a light and an advice for the pious. (\* The Holy Book Taurat.)

# 2532

Those who fear their Lord without seeing and who apprehend the Last Day.

# 2533

This is a blessed remembrance, sent down by Us; so do you deny it?

# 2534

And indeed We bestowed Ibrahim with guidance from the beginning, and We were Aware of him.

# 2535

When he said to his father and his people, “What are these idols before whom you squat (worshipping)?”

# 2536

They said, “We found our forefathers worshipping them.”

# 2537

He said, “Indeed you all – you and your forefathers – were in open error.”

# 2538

They said, “Have you brought the Truth to us, or are you just making fun?”

# 2539

He said, “In fact, your Lord is the Lord of the heavens and the earth, the One Who created them; and I am of those who testify to it.”

# 2540

“And, by oath of Allah, I shall seek to harm your idols after you have gone away and turned your backs.”

# 2541

He shattered them all, except the biggest among them, that perhaps they may question it.

# 2542

They said, “Who has done this to our Gods? He is indeed cruel!”

# 2543

Some among them said, “We heard a youth speak ill of them – the one called Ibrahim.”

# 2544

They said, “Therefore bring him in front of the people, perhaps they may testify.”

# 2545

They said, “Did you do this to our Gods, O Ibrahim?”

# 2546

Said he, “Rather, their chief may have done it; so question them, if they can speak.”

# 2547

So they turned towards their own selves and (inwardly) said, “Indeed you yourselves are unjust.”

# 2548

Again they were inverted upon their heads; saying, “You know well that these do not speak.”

# 2549

He said, “What! You worship, instead of Allah, one that neither benefits you nor harms you?”

# 2550

“Disgrace be upon you and all the idols whom you worship instead of Allah; so do you not have sense?”

# 2551

They said, “Burn him and help your Gods, if you want to.”

# 2552

We said, “O fire, become cool and peaceful upon Ibrahim.”

# 2553

And they wished to cause him harm, so We made them the greatest of losers.

# 2554

And We rescued him and Lut towards the land which We have blessed for the entire world.

# 2555

And We bestowed him Ishaq, and Yaqub the grandson; and We made all of them worthy of Our proximity.

# 2556

And We made them leaders who guide by Our command, and We sent them the divine revelation to do good deeds and to keep the prayer established and to give charity; and they used to worship Us.

# 2557

And We gave Lut the kingdom and knowledge, and We rescued him from the township that committed vile deeds; indeed those evil people were disobedient.

# 2558

And We admitted him into Our mercy; indeed he is among those who deserve Our proximity.

# 2559

And before this when Nooh called Us – We therefore heard his prayer and rescued him and his household from the great calamity.

# 2560

And We helped him against the people who denied Our signs; indeed they were evil people, We therefore drowned them all.

# 2561

And remember Dawud and Sulaiman, when they were deciding the dispute of a field, when some people’s sheep had strayed into it at night; and We were Present at the time of their deciding.

# 2562

And We explained the case to Sulaiman; and to both We gave the kingdom and knowledge; and subjected the hills to proclaim the Purity along with Dawud, and (also subjected) the birds; and these were Our works.

# 2563

And We taught him to make a garment for you, to protect you from your hurt; so will you be thankful?

# 2564

And We subjected the fast wind for Sulaiman, which moved by his command towards the land in which We have placed blessings; and We know everything.

# 2565

And among the devils, were those who dived (in water) for him and did works other than this; and We had kept them restrained.

# 2566

And remember Ayyub (Job), when he called his Lord that, “Hardship has afflicted me, and You are the Most Merciful of all those who have mercy.”

# 2567

We therefore heard his prayer and removed the adversity that had afflicted him, and We gave him his family and in addition bestowed along with them a similar number, by mercy from Ourselves – and an advice for the people who worship.

# 2568

And remember Ismail, and Idrees, and Zul-Kifl; they were all patiently enduring.

# 2569

And We admitted them into Our mercy; indeed they are among those who deserve Our proximity.

# 2570

And remember Zun-Noon,\* when he left in anger, assuming that We would not restrict him – he therefore called out in the realms of darkness, saying, “There is no God except You, Purity is to You; I have indeed committed a lapse.” (\* Prophet Yunus – peace and blessings upon him)

# 2571

We therefore heard his prayer and rescued him from grief; and similarly We shall rescue the Muslims.

# 2572

And remember Zakaria, when he prayed to his Lord, “O my Lord – do not leave me alone, and You are the Best Inheritor.

# 2573

We therefore heard his prayer; and bestowed him Yahya, and cured his wife for him; indeed they used to hasten to perform good deeds, and pray to Us with hope and fear; and used to weep before Us.

# 2574

And remember the woman who maintained her chastity, We therefore breathed Our Spirit into her and made her and her son a sign for the entire world.

# 2575

Indeed this religion of yours, is one religion; and I am your Lord, therefore worship Me.

# 2576

And others have shattered their works into pieces among themselves; all have to return to Us.

# 2577

So whoever does some good deeds, and is a believer, then his efforts will not be ignored; and We are recording it.

# 2578

And it is forbidden for any township which We have destroyed, that they may return. (Once the disbelievers face death, their return to earth is impossible.)

# 2579

Till the time when Yajuj and Majuj are released, and they will be flowing down from every height.

# 2580

And the True Promise has come near – thereupon the eyes of the disbelievers will become fixed, staring wide; saying “Woe to us – we were in neglect of this, but in fact we were unjust.”

# 2581

“Indeed you\* and all that you worship\*\* besides Allah, are the fuel of hell; in it you must go.” (\* All disbelievers \*\* Idols and disbelievers who claimed to be Gods. The Prophets like Eisa and Uzair who were worshipped are exempt from this, and so are Maryam, and trees and the moon etc.)

# 2582

“Had these been Gods they would not go into hell; and they have to remain in it.”

# 2583

They will bray in it and not be able to hear anything in it.

# 2584

Indeed those to whom Our promise of goodness has been made, have been kept far away from hell.

# 2585

And they will not hear its faintest sound; and they will forever abide in whatever their hearts desire.

# 2586

The greatest fear will not aggrieve them, and the angels will welcome them; saying “This is your day, which you were promised.”

# 2587

The day when We shall roll up the heavens as the recording angel rolls up the register of deeds; We shall make him similar to Our making him the first time; this is a promise upon Us; We certainly have to do it.

# 2588

And indeed We wrote, after the reminder in the Zaboor that, “My virtuous bondmen will inherit the earth.”

# 2589

This Qur’an is sufficient for people who are devout.

# 2590

And We did not send you (O dear Prophet Mohammed – peace and blessings be upon him) except as a mercy for the entire world. (Prophet Mohammed – peace and blessings be upon him – is the Prophet towards all mankind.)

# 2591

Proclaim, “It is divinely revealed to me that your God is the only One God – Allah; do you therefore become Muslims?”

# 2592

Then if they turn away, proclaim, “I have proclaimed a war against you on equal terms; and what do I know whether the promise which is given to you, is close or far?”

# 2593

“Indeed Allah knows whatever is said, and knows all what you conceal.”

# 2594

“And what do I know – it may be a trial for you, and an enjoyment for a time.”

# 2595

And the Prophet submitted, “My Lord – render the true judgement”; “And only the help of Our Lord, the Most Gracious, is sought against all what you fabricate.”

# 2596

O people, fear your Lord; indeed the earthquake of the Last Day is a tremendous thing.

# 2597

On the day when you will witness it, every nursing mother will forget her nurseling and every pregnant one will discharge her burden, and you (O dear Prophet Mohammed – peace and blessings be upon him) will see people as if they are drunk, whereas they will not be intoxicated, but the fact is that Allah’s punishment is very severe.

# 2598

And among people are some who argue concerning Allah without knowing, and blindly follow every rebellious devil.

# 2599

(The devil) Upon whom is decreed that whoever befriends him, he will certainly mislead him and show him the path to hell.

# 2600

O people, if you doubt your revival on the Day of Resurrection, then ponder that We created you from dust, then from a drop of liquid, then from a clot, then from a piece of flesh formed and without form, so that We show you Our signs for you; and We keep whomever We want inside the mothers’ wombs up to an appointed time, then extract you as infants, then in order that you reach your puberty; and among you is one who dies earlier, and among you is one put to the most abject age, so after having knowledge, knows nothing; and you see the earth desolate, then when We sent down water upon it, it freshened up and developed and produced beautiful pairs of all kinds.

# 2601

This is because Allah only is True and because He will revive the dead, and because He is Able to do all things.

# 2602

And because the Last Day will come, there is no doubt in it – and because Allah will revive those who are in the graves.

# 2603

And there is one who argues concerning Allah without having knowledge nor any proof nor a clear text.

# 2604

With his neck turned away from the truth, in order to deceive from the way of Allah; for him is disgrace in this world and on the Day of Resurrection We shall make him taste the punishment of fire.

# 2605

“This is the recompense of what your hands have sent ahead, and Allah does not oppress His bondmen."

# 2606

And there are some men who worship Allah upon an edge; then if some good occurs to them, they are content; and if some trial comes, they turn way upon their faces; a loss of this world and the Hereafter; and this is the complete loss.

# 2607

They worship such, beside Allah, which neither harms them nor benefits them; this only is the extreme error.

# 2608

They worship one from whom harm is expected more than the benefit; indeed what an evil master and indeed what an evil friend!

# 2609

Indeed Allah will admit those who believed and did good deeds, into Gardens beneath which rivers flow; indeed Allah does whatever He wills.

# 2610

Therefore whoever assumes that Allah will not assist His Prophet (Mohammed – peace and blessings be upon him) in this world and the Hereafter, should extend a rope upwards and hang himself, and then see whether his scheme has taken away what he envies.

# 2611

And so it is, that We sent down this Qur’an – clear verses – and that Allah guides whomever He wills.

# 2612

Indeed the Muslims, and the Jews, and the Sabeans, and the Christians and the fire worshippers and the polytheists – indeed Allah will decide between all of them on the Day of Resurrection; indeed Allah witnesses all things.

# 2613

Did you not see that for Allah prostrate those who are in the heavens and in the earth, and the sun, and the moon, and the stars, and the hills, and the trees, and the beasts, and many among mankind; and there are many upon whom the punishment has been decreed; and he whom Allah disgraces – there is none to give him honour; indeed Allah may do whatever He wills. (Command of Prostration # 6)

# 2614

These are the two groups who fought concerning their Lord; so those who disbelieved – garments of fire have been fashioned for them; and boiling water will be poured onto their heads.

# 2615

With which will melt what is in their bellies, and their skins.

# 2616

And for them are rods of iron.

# 2617

Whenever they wish to come out of it due to suffocation, they will be returned to it again and it will be commanded, “Taste the punishment of fire!”

# 2618

Indeed Allah will admit those who believed and did good deeds into Gardens beneath which rivers flow – in it they will be made to wear armlets of gold, and pearls, and in it their garment is silk.

# 2619

And they were guided to sacred speech; and they were shown the path of the Most Praiseworthy.

# 2620

Indeed those who have disbelieved and prevent from the way of Allah and from this Sacred Mosque, which We have appointed for all mankind – its resident and the foreigner have the same rights in it; and whoever wrongfully intends injustice in it – We shall make him taste a painful punishment.

# 2621

And remember when We showed Ibrahim the right place of the Sacred House (mosque) and commanded that, “Do not ascribe anything as a partner to Me, and keep My House clean for those who encircle it and those who stay in it (for worship) and those who bow and prostrate.”

# 2622

“And publicly announce the pilgrimage to all people – they will come to you, on foot and on every lean she-camel, coming from every far distant journey.” (The announcement by Prophet Ibrahim reached each and every soul.)

# 2623

In order that they may gain their benefit, and mention the name of Allah on the appointed days as He has bestowed the sustenance to them – the inarticulate animals; therefore eat from them yourself and feed the distressed destitute.

# 2624

They must then remove their dirt and fulfil their pledges and go around the Free House.

# 2625

So it is; and whoever reveres the sacred things of Allah – that is then a goodness for him in the sight of his Lord; the inarticulate animals are lawful to you except those the forbidding of which is recited to you, therefore shun the filth of idols, and avoid false speech.

# 2626

Devoting yourself to Allah, not ascribing any partner to Him; and whoever ascribes partners to Allah is as if he has fallen from the sky and the birds snatch him or the wind blows him away to a far-off place.

# 2627

So it is; and whoever reveres the symbols of Allah – this is then part of the piety of the hearts.

# 2628

In the cattle are benefits for you up to a fixed time and then they are to be brought to the Free House.

# 2629

And for every nation We have appointed a sacrifice, that they may mention the name of Allah over the inarticulate animal which He has provided them; so (remember) your God is One God, therefore submit only to Him; and give glad tidings (O dear Prophet Mohammed – peace and blessings be upon him) to the humble.

# 2630

Those whose hearts fear when Allah is mentioned, and those who patiently endure whatever befalls them, and those who keep the prayer established, and who spend part of what We have provided to them.

# 2631

And the large sacrificial animals – the camels and the cows – We have made them among the symbols of Allah, there is goodness for you in them; therefore mention the name of Allah over them with their one leg tied and standing on three feet; then when their flanks have fallen, eat from it yourself and feed the one who patiently awaits, and the beggar; this is how We have given them in your control, so that you be grateful.

# 2632

Never does their flesh nor their blood reach Allah, but your piety successfully reaches Him; this is how We have given them in your control so that you may speak His Greatness for guiding you; and O dear Prophet (Mohammed – peace and blessings be upon him) give glad tidings to the virtuous.

# 2633

Indeed Allah repels the afflictions of the Muslims; indeed Allah does not like any extremely disloyal ingrate.

# 2634

Permission is granted to those against whom the disbelievers wage war, as they are being wronged; and indeed Allah is Able to assist them.

# 2635

Those who were unjustly expelled from their homes just because they said, “Allah is Our Lord”; and had Allah not repelled some men by means of other men, the abbeys, churches, synagogues and mosques – in which the name of Allah is profusely mentioned – would definitely be demolished; and indeed Allah will assist the one who helps His religion; indeed surely Allah is Almighty, Dominant.

# 2636

The people who, if We give them control in the land, would keep the prayer established and pay charity and enjoin virtue and forbid from evil; and for Allah only is the result of all works.

# 2637

If they belie you (O dear Prophet Mohammed – peace and blessings be upon him), then indeed the people of Nooh, and the tribes of A’ad and Thamud have belied before them.

# 2638

And (so did) the people of Ibrahim and the people of Lut.

# 2639

And the people of Madyan; and Moosa was belied, so I gave the disbelievers respite and then seized them, so how (dreadful) was My punishment!

# 2640

And many a township did We destroy, for they were oppressors – so they now lie flat on their roofs, and many a well lying useless and many a palace in ruins.

# 2641

So have they not travelled in the land, to have hearts with which to understand and ears to hear with? So it is not the eyes that are blind, but it is the hearts in the bosoms, that are blind.

# 2642

And they ask you for the punishment – they are impatient – and Allah will not make His promise untrue; and indeed a single day before Allah is like a thousand years in your calculation.

# 2643

And to many a township did I give respite although they were oppressors; then I seized them; and towards Me is the return.

# 2644

Proclaim, “O mankind, I am for you only a clear Herald of Warning.”

# 2645

So those who believed and did good deeds, for them are forgiveness, and an excellent sustenance.

# 2646

And those who strive in Our signs with the intention of disputing, are the people of fire.

# 2647

And all the Noble Messengers or Prophets whom We sent before you – it occurred with all of them – that whenever they recited (the message) Satan included a bit (from his own speech) in their recitation to the people; so Allah obliterates what Satan includes and then Allah fortifies His verses; and Allah is All Knowing, Wise.

# 2648

So that He may make what the devil includes a trial for those in whose hearts is a disease, and those whose hearts are hardened; indeed the unjust are extremely quarrelsome.

# 2649

And so that the people given the knowledge may know that it is the truth from your Lord, in order that they may accept faith in it, therefore their hearts may humble before Him; and indeed Allah will guide the believers on the Straight Path.

# 2650

And the disbelievers will always be in doubt of it, to the extent that the Last Day will suddenly come upon them, or will come upon them the punishment of a day the result of which is not at all good for them.

# 2651

For Allah only is the kingship on that day; He will judge between them; so those who believed and did good deeds are in Gardens of content.

# 2652

And those who disbelieved and denied Our signs – for them will be a disgraceful punishment.

# 2653

And those who left their homes and belongings in Allah's cause and were then killed or died – Allah will therefore indeed provide for them an excellent sustenance; and indeed the sustenance bestowed by Allah is the best.

# 2654

He will certainly admit them to a place they will love; and indeed Allah is All Knowing, Most Forbearing.

# 2655

So it is; and whoever retaliates similarly to the affliction he was made to suffer, and then he is wronged again – so Allah will definitely assist him; indeed Allah is Oft Pardoning, Oft Forgiving.

# 2656

This is because Allah inserts the night into a part of the day and inserts the day into a part of the night, and because Allah is All Hearing, All Seeing.

# 2657

This is because Allah only is the Truth, and what they worship other than Him, is itself falsehood, and because Allah only is the Supreme, the Great.

# 2658

Did you not see that Allah sent down water from the sky, so the earth became green at morn? Indeed Allah is Pure, Aware.

# 2659

To Him only belongs all that is in the heavens and all that is in the earth; and indeed Allah only is the Perfect (Not Needing Anything), the Most Praiseworthy.

# 2660

Did you not see that Allah has given in your control all that is in the earth – and the ship that moves upon the sea by His command? And He restricts the heavens that it may not fall on to the earth except by His command; indeed Allah is Most Compassionate, Most Merciful upon mankind.

# 2661

And it is He Who gave you life, then will cause you to die, and will then revive you; indeed man is very ungrateful.

# 2662

For each nation We have made the rules of worship for them to follow – so never should they quarrel with you in this matter – and call them towards your Lord; indeed you are upon the Straight Path.

# 2663

And if they quarrel with you, say, “Allah well knows your evil deeds.”

# 2664

Allah will judge between you on the Day of Resurrection concerning what you dispute.

# 2665

Did you not realise that Allah knows all that is in the heavens and in the earth? Indeed all this is in a Book; indeed this is easy for Allah.

# 2666

And they worship those instead of Allah regarding whom He has not sent down any proof, and those regarding whom they themselves do not have any knowledge; and there are no supporters for the unjust.

# 2667

And when Our clear verses are recited to them, you will see traces of anger in the faces of the disbelievers; possibly they may attack those who recite Our verses to them; say, “Shall I show you what is worse than your current state? That is the fire! Allah has promised it to the disbelievers; and what a wretched place to return!”

# 2668

O people, an example is being illustrated therefore listen to it attentively; “Those whom you worship besides Allah can never create a fly even if they all come together for it; and if a fly took away something from them, they cannot retrieve that from it; how weak are the seeker and the sought!”

# 2669

They did not realise the importance of Allah as was His right; indeed Allah is Almighty, Dominant.

# 2670

Allah chooses the Noble Messengers from the angels, and from men; indeed Allah is All Hearing, All Seeing.

# 2671

He knows all that is before them and all that is behind them; and towards Allah is the return of all matters.

# 2672

O People who Believe, bow and prostrate yourselves, and worship your Lord, and do good deeds in the hope of attaining salvation.

# 2673

And fight in Allah's cause as is the true manner of fighting; He has preferred you and has not kept any hardship upon you in religion; the religion of your father Ibrahim; Allah has named you Muslims – in the previous Books and in this Qur’an, so that the Noble Messenger be your guardian and witness, and you be witness against other people; therefore keep the prayer established and give charity, and hold fast to the rope of Allah; He is your Master; so what an excellent Master and what an excellent Supporter!

# 2674

Successful indeed are the believers.

# 2675

Those who humbly cry in their prayers.

# 2676

And who do not incline towards indecent matters.

# 2677

And who pay the (obligatory) charity.

# 2678

And who guard their private organs.

# 2679

Except from their wives or the legal bondwomen that they possess, for then there is no blame upon them.

# 2680

So whoever desires more than these two – they are crossing the limits.

# 2681

And those who keep proper regard for their trusts and their pledges.

# 2682

And who guard their prayers.

# 2683

They are the inheritors.

# 2684

Those who will get the inheritance of Paradise; they will abide in it forever.

# 2685

Indeed We created man from a chosen soil.

# 2686

Then made him a drop of fluid in a secure shelter.

# 2687

We then turned the drop of fluid into a clot of blood, then the clot into a small lump of flesh, then the lump into bones, then covered the bones with flesh; then developed it in a different mould; therefore Most Auspicious is Allah, the Best Creator.

# 2688

Then after that, certainly all of you are to die.

# 2689

Then you will all be raised on the Day of Resurrection.

# 2690

And indeed We have created seven paths above you; and We are not unmindful of the creation.

# 2691

And We sent down water from the sky in proper measure, then stored it in the earth; and indeed We are Able to take it away!

# 2692

So with it We produced gardens of date-palms and grapes for you, in which is abundant fruit for you and you eat therefrom.

# 2693

And created the tree that comes forth from Mount Sinai – that grows containing oil and curry for the eaters.

# 2694

And indeed in the cattle is a lesson for you; We give you to drink what is in their bellies, and there are many benefits for you in them, and in them is your food.

# 2695

And you are carried on them and on the ship.

# 2696

And indeed We sent Nooh towards his people – he therefore said, “O my people! Worship Allah, you do not have any other God except Him; so do you not fear?”

# 2697

So the disbelieving chieftains of his people said, “He is just a human like you, he wishes to become your leader; and had Allah willed, He would have sent down angels; We did not hear this in the case of our forefathers.”

# 2698

“He is not but a man insane, therefore wait for some time.”

# 2699

Submitted Nooh, “My Lord! Help me as they deny me.”

# 2700

So We sent him the divine revelation that, “Make the ship in front of Our sight, and by Our command – then when Our command comes and the oven overflows, embark in it two of every couple, and from your household except those upon whom the Word has been decreed; and do not speak to Me in respect of these unjust people; they will surely be drowned.”

# 2701

“And when you and those with you have safely boarded the ship say, ‘All praise is to Allah Who has rescued us from the unjust.’”

# 2702

And pray, “My Lord! Cause me to alight at a blessed place – and You are the Best of all who bring to settle.”

# 2703

Indeed, surely in this are signs and indeed surely, We were examining.

# 2704

Then after them, We created another generation.

# 2705

So We sent among them a Noble Messenger from among them (saying), “Worship Allah, you do not have any other God except Him; so do you not fear?”

# 2706

And said the leaders of his people, who disbelieved and denied the confronting of the Hereafter – and We had given them comfort in the worldly life – that, “He is nothing but a human like you, he eats from what you eat and drinks from what you drink.”

# 2707

“If you were to obey a human like yourselves, then surely you are losers!”

# 2708

“Does he promise you that when you die and turn into dust and bones, you will be raised again?”

# 2709

“How remote, (really) how remote is the promise you are given!”

# 2710

“There is nothing except our life of this world, we die and we live, and we are not to be raised.”

# 2711

“He is just a man who has fabricated a lie against Allah, and we are not going to believe him.”

# 2712

He said, “My Lord! Help me as they deny me.”

# 2713

Said Allah, “They will soon wake up at morn, regretting.”

# 2714

So the true Scream seized them – We therefore made them like rotten hay; so away with the unjust people!

# 2715

Then after them, We created other generations.

# 2716

No nation can go before its term ends nor stay back.

# 2717

We then sent our Noble Messengers, one after another; whenever a nation’s Noble Messenger came to it they denied him, We therefore united the succeeding with the old, and made them history; so far removed be the people who do not believe!

# 2718

We then sent Moosa and his brother Haroon, with Our signs and a clear proof.

# 2719

Towards Firaun and his court members – in response they were haughty, and they were in dominance.

# 2720

They therefore said, “Shall we believe in two humans like ourselves, whereas their nation is servile to us?”

# 2721

So they denied them – therefore became of those who were destroyed.

# 2722

And indeed We gave Moosa the Book, that they may attain guidance.

# 2723

And We made the son of Maryam (Prophet Eisa) and his mother a sign, and We gave them shelter on a height, a place to stay and visible springs.

# 2724

“O Noble Messengers, eat good clean things, and do good deeds; I know all that you do.”

# 2725

“And indeed this religion of yours is one religion only and I am your Lord, therefore fear Me.”

# 2726

But their nations broke their tasks into pieces; every group happy with what it has.

# 2727

So leave them in their intoxication till a time.

# 2728

Do they assume that the wealth and sons which We provide them –

# 2729

Are quickly giving them goodness? In fact, they do not know.

# 2730

Indeed those who are overwhelmed due to the fear of their Lord –

# 2731

And those who believe in the signs of their Lord –

# 2732

And those who do not ascribe any partner to their Lord –

# 2733

And those who give what they give and their hearts fear for they have to return to their Lord.

# 2734

These people hasten to perform goodness, and it is they who shall reach it first.

# 2735

And We do not burden any soul beyond its capacity, and with Us is a Book\* that speaks the truth, and they will not be wronged. (\* The preserved tablet or the record of one’s deeds.)

# 2736

On the contrary, their hearts are in neglect of this and their works are different than those of the believers, the works that they are doing.

# 2737

To the extent that when We seized the wealthy among them with punishment, they immediately began imploring.

# 2738

“Do not implore this day; you will not be helped by Us.”

# 2739

“My verses were recited to you, so you used to turn back on your heels.”

# 2740

“Priding yourself in serving the Sacred Mosque; at night you utter indecent stories in it, while discarding the truth.”

# 2741

Have they not pondered the matter, or did that come to them, which did not come to their forefathers?

# 2742

Or is it that they did not recognise their Noble Messenger, therefore they consider him alien?

# 2743

Or they say, “He is afflicted by a demon”; in fact he brought the Truth to them, and most of them dislike the Truth.

# 2744

And had the Truth followed their desires, then indeed the heavens and the earth and all those who are in them would be destroyed; in fact We brought to them a thing in which lay their repute, so they are turned away from their own repute.

# 2745

Do you (O dear Prophet Mohammed – peace and blessings be upon him) ask any fee from them? So the reward of your Lord is the best; and He is the Best Provider of Sustenance.

# 2746

And indeed you call them to the Straight Path.

# 2747

And indeed those who do not believe in the Hereafter are deviated from the Straight Path.

# 2748

And if We have mercy upon them and remove the calamity which has befallen them, they would still stubbornly persist, wandering in their rebellion.

# 2749

And indeed We grasped them with punishment, so neither did they submit themselves to their Lord, nor do they cry humbly.

# 2750

To the extent that when We opened the gate of a severe punishment for them, they thereupon lie despairingly in it.

# 2751

And it is He Who has created ears and eyes and hearts for you; very little is the right you acknowledge.

# 2752

And it is He Who has spread you in the earth, and towards Him you are to be raised.

# 2753

And it is He Who gives life and causes death, and for Him are the alternations of night and day; so do you not have sense?

# 2754

On the contrary, they said the same as what the former people used to say.

# 2755

They say, “Will we, when we die and turn into dust and bones, be raised again?”

# 2756

“Indeed this promise was given to us and before us to our forefathers – this is nothing but stories of earlier people.”

# 2757

Say O dear Prophet (Mohammed – peace and blessings be upon him), “To Whom does the earth and all that is in it belong to, if you know?”

# 2758

Thereupon they will say, “To Allah”; proclaim, “Therefore why do you not ponder?”

# 2759

Say, “Who is the Lord of the seven heavens, and the Lord of the Tremendous Throne?”

# 2760

Thereupon they will say, “Such greatness is only that of Allah”; say, “So why do you not fear?”

# 2761

Say, “In Whose hand is the control over all things, and He provides refuge, and none can provide refuge against Him, if you know?”

# 2762

Thereupon they will say, “Such greatness is only that of Allah”; say, “Then by what magic are you deceived?”

# 2763

In fact We brought the Truth to them, and indeed they are liars.

# 2764

Allah has not chosen any child, nor any other God along with Him – were it so, each God would have taken away its creation, and each one would certainly wish superiority over the other; Purity is to Allah above all the matters they fabricate.

# 2765

The All Knowing, of every hidden and the visible – so Supremacy is to Him over their ascribing of partners (to Him).

# 2766

Pray, “My Lord! If You show me the promise they are given,”

# 2767

“Therefore my Lord, do not group me with the unjust.”

# 2768

And indeed We are Able to show you the promise they are given.

# 2769

Repel evil with the best deeds; We well know the matters that they fabricate.

# 2770

And submit, “My Lord! I seek Your refuge from the instigation of the devils.”

# 2771

“And my Lord, (I seek) Your refuge from their coming to me.”

# 2772

Until, when death comes to one\* of them, he says, “O my Lord, send me back!” (The disbelievers)

# 2773

“Perhaps I may do some good deeds in what I have left behind”; this is just a word that he utters from his mouth; and confronting them is a barrier until the day in which they will be raised.

# 2774

So when the Trumpet is blown – so there will neither be any relationship among them\* that day, nor will they ask about one another. (The disbelievers)

# 2775

Therefore the ones whose scales prove heavy – they are the successful.

# 2776

And the ones whose scales prove light – it is they who put their lives into ruin, remaining in hell forever.

# 2777

The fire shall scorch their faces, and they will remain dejected in it.

# 2778

“Were not My verses recited to you, so you used to deny them?”

# 2779

They will say, “Our Lord! Our ill-fate overcame us, and we were the astray people.”

# 2780

“Our Lord, remove us from hell – then if we do the same, we are the unjust.”

# 2781

Allah will say, “Remain rebuked in it, and do not speak to Me.”

# 2782

"Indeed there was a group among My bondmen who said, 'Our Lord! We have accepted faith, therefore forgive us and have mercy on us, and You are the Best Among The Merciful.' ”

# 2783

“So you took them for a mockery until your mocking at them made you forget My remembrance, and you used to laugh at them!”

# 2784

“Indeed this day I have rewarded them for their endurance, so that it is they who are the successful.”

# 2785

He will say, “How long did you stay on earth, counting by the number of years?

# 2786

They will say, “We stayed a day or part of a day, so ask those who keep count.”

# 2787

He will say, “You stayed but only a little, if you knew.”

# 2788

So do you think that We have created you needlessly, and that you do not have to return to Us?

# 2789

So Most Supreme is Allah, the True King; there is no God except Him; Lord of the Throne of Honour.

# 2790

And the one who worships any other God along with Allah – of which he does not have any proof – his account is with his Lord; indeed there is no salvation for the disbelievers.

# 2791

And (O dear Prophet Mohammed – peace and blessings be upon him) say, “My Lord! Forgive and have mercy, and You are the Best of all the Merciful.

# 2792

This is a chapter which We have sent down and decreed its commands, and in which We have sent down clear verses, in order that you may ponder.

# 2793

The adulteress and the adulterer – punish each one of them with a hundred lashes; and may you not have pity on them in the religion to Allah, if you believe in Allah and the Last Day; and a group of believers must witness their punishment.

# 2794

The adulterer shall not marry except an adulteress or a polytheist woman, and none shall marry an adulteress except an adulterer or a polytheist; and this is forbidden for the believers.

# 2795

And those who accuse chaste women and do not bring four witnesses to testify – punish them with eighty lashes and do not ever accept their testimony; and it is they who are the wicked.

# 2796

Except those who repent after this and reform themselves; so indeed Allah is Oft Forgiving, Most Merciful.

# 2797

And those who accuse their wives and do not have witnesses except their own statements – for such the testimony is that he bear the testimony four times by the name of Allah that he is truthful.

# 2798

And the fifth time, that the curse of Allah be upon him if he is a liar.

# 2799

And the punishment shall be averted from the woman if she bears the testimony four times by the name of Allah, that the man is a liar.

# 2800

And the fifth time, that the wrath of Allah be upon her if the man is truthful.

# 2801

And were it not for Allah’s munificence and His mercy upon you and that Allah is the Acceptor of Repentance, the Wise – He would then have unveiled you.

# 2802

Indeed those who have brought this great accusation are a group from among you; do not consider it bad for you; on the contrary, it is good for you; for each man among them is the sin that he has earned; and for the one among them who played the greatest part in it – for him is a terrible punishment.

# 2803

Why was it not that the believing men and women, when you heard it, thought good of their own people, and had said, “This is a clear accusation”?

# 2804

Why did they not bring four witnesses upon it? Since they did not bring witnesses, they themselves are liars before Allah.

# 2805

And were it not for Allah’s munificence and His mercy upon you in the world and in the Hereafter, a terrible punishment would have reached you for the discussions you fell into.

# 2806

When you rumoured with your tongues after hearing such matters, and uttered with your mouths about which you had no knowledge, and you considered it light; and that, in the sight of Allah, is very great.

# 2807

And why was it not that, when you heard it, you would have said, “It does not befit us to speak regarding this; Purity is to You, O Allah – this is a great accusation.”

# 2808

Allah advises you never to speak like this again, if you have faith.

# 2809

And Allah clearly explains the verses for you; and Allah is All Knowing, Wise.

# 2810

Indeed those who wish that slander should spread among the Muslims – for them is a painful punishment in this world and in the Hereafter; and Allah knows, and you do not know.

# 2811

And were it not for Allah’s munificence and His mercy upon you, and that Allah is Forgiving, Most Merciful – you would have tasted its outcome.

# 2812

O People who Believe! Do not follow the footsteps of the devil; and whoever follows the footsteps of the devil – so he will only bid the indecent and the evil; and were it not for Allah’s munificence and His mercy upon you, none of you would ever become pure – but Allah purifies whomever He wills; and Allah is All Hearing, All Knowing.

# 2813

And may not those who possess superiority (in wealth) among you and possess capacity, swear not to give to the relatives and to the needy, and to immigrants in Allah's cause; and they should forgive and forbear; do you not like that Allah may forgive you? And Allah is Oft Forgiving, Most Merciful.

# 2814

Indeed those who accuse the innocent virtuous, believing women – upon them is a curse in this world and in the Hereafter; and for them is a terrible punishment.

# 2815

On the day when their tongues and their hands and their feet will testify against them, regarding what they used to do.

# 2816

On that day Allah will give them their true punishment, and they will know that Allah only is the Clear Truth.

# 2817

Vile women for vile men, and vile men for vile women; and virtuous women for virtuous men, and virtuous men for virtuous women; such are innocent of what these people say; for them are forgiveness, and an honourable sustenance.

# 2818

O People who Believe! Do not enter the houses except your own until you obtain permission and have conveyed peace upon its inhabitants; this is better for you, in order that you may ponder.

# 2819

And if you do not find anyone in them, even then do not enter without the permission of their owners; and if it is said to you, “Go away” then go away – this is much purer for you; and Allah knows your deeds.

# 2820

There is no sin upon you to enter houses not made especially for someone’s habitation, and you have permission for its use; and Allah knows what you disclose and what you hide.

# 2821

Command the Muslim men to keep their gaze low and to protect their private organs; that is much purer for them; indeed Allah is Aware of their deeds.

# 2822

And command the Muslim women to keep their gaze low and to protect their chastity, and not to reveal their adornment except what is apparent, and to keep the cover wrapped over their bosoms; and not to reveal their adornment except to their own husbands or fathers or husbands’ fathers, or their sons or their husbands’ sons, or their brothers or their brothers’ sons or sisters’ sons, or women of their religion, or the bondwomen they possess, or male servants provided they do not have manliness, or such children who do not know of women’s nakedness, and not to stamp their feet on the ground in order that their hidden adornment be known; and O Muslims, all of you turn in repentance together towards Allah, in the hope of attaining success. (It is incumbent upon women to cover themselves properly.)

# 2823

And enjoin in marriage those among you who are not married, and your deserving slaves and bondwomen; if they are poor, Allah will make them wealthy by His munificence; and Allah is Most Capable, All Knowing.

# 2824

And those who do not have the means to get married must keep chaste till Allah provides them the resources by His munificence; and the bondwomen in your possession who, in order to earn something, seek a letter of freedom from you – then write it for them if you consider some goodness in them; and help them in their cause with Allah’s wealth which He has bestowed upon you; and do not force your bondwomen into the dirty profession, while they wish to save themselves, in order to earn some riches of the worldly life; and if one forces them then indeed Allah, upon their remaining compelled, is Oft Forgiving, Most Merciful.

# 2825

And indeed We have sent down towards you clear verses, and some account of those who preceded you, and advice for the pious.

# 2826

Allah is the Light of the heavens and the earth; the example of His light is like a niche in which is a lamp; the lamp is in a glass; the glass is as if it were a star shining like a pearl, kindled by the blessed olive tree, neither of the east nor of the west – it is close that the oil itself get ablaze although the fire does not touch it; light upon light; Allah guides towards His light whomever He wills; and Allah illustrates examples for mankind; and Allah knows everything. (The Holy Prophet is a light from Allah)

# 2827

In the houses (mosques) which Allah has commanded to erect and in which His name is taken – praising Allah in them at morn and evening,

# 2828

(Are) Those men, whom neither any bargain nor any trade distracts from the Remembrance of Allah and from establishing the prayer and from paying the charity – they fear the day when the hearts and the eyes will be overturned.

# 2829

In order that Allah may reward them for their best deeds and by His munificence, bestow upon them an increased reward; and Allah gives sustenance to whomever He wills, without account.

# 2830

And those who disbelieved – their deeds are like a mirage in the wasteland, so the thirsty may believe it to be water; to the extent that when he came close to it, he found it is nothing and found Allah close to him, so He filled his account; and Allah is Swift At Taking Account.

# 2831

Or like realms of darkness on a deep sea, which is covered by a wave, the wave covered by another wave, and above it is a cloud; layers of darkness upon darkness; if he removes his hand it does not seem visible; and the one to whom Allah does not provide light – there is no light for him anywhere.

# 2832

Have you not seen that all those who are in the heavens and the earth praise Allah, and the birds with their wings spread (also praise Him)? Each one has learnt its prayers and its words of praise; and Allah knows their deeds.

# 2833

And for Allah only is the kingship of the heavens and the earth; and towards Allah is the return.

# 2834

Have you not seen that Allah slowly transports the clouds, then gathers them together, then heaps them together, so you see the rain coming forth from between them? And from the sky He sends down hail from the mountains of ice, then sends them upon whomever He wills, and averts them from whomever He wills; it is close that the flash of its lightning take away the eyesight.

# 2835

Allah alternates the day and the night; indeed in this is a lesson for those who can perceive.

# 2836

And Allah created every animal on earth, from water; so among them is a kind that moves upon its belly; and among them is a kind that moves upon two legs; and among them a kind that moves upon four legs; Allah creates whatever He wills; indeed Allah is Able to do all things.

# 2837

And We indeed sent down clear verses; and Allah may guide whomever He wills to the Straight Path.

# 2838

And they say, “We have accepted faith in Allah and His Noble Messenger, and we obey”; then after that a group among them turns away; and they are not Muslims.

# 2839

And when called towards Allah and His Noble Messenger in order that the Noble Messenger may judge between them, thereupon a group among them turns away.

# 2840

And if the judgement is in their favour, they come towards it willingly.

# 2841

Are their hearts diseased, or do they have doubts, or do they fear that Allah and His Noble Messenger will oppress them? In fact they themselves are the unjust.

# 2842

The saying of the Muslims when they are called towards Allah and His Noble Messenger in order that the Noble Messenger judge between them is that they submit, “We hear and we obey”; and it is they who have attained the goal.

# 2843

And whoever obeys the command of Allah and His Noble Messenger, and fears Allah, and practices piety – so it is they who are the successful.

# 2844

And they swore by Allah most vehemently in their oaths that if you order them, they will go forth to holy war; say, “Do not swear; obedience according to the law is required; indeed Allah knows what you do.”

# 2845

Proclaim, “Obey Allah and obey the Noble Messenger; so if you turn away, then the Noble Messenger is bound only for what is obligatory upon him, and upon you is the duty placed upon you”; and if you obey the Noble Messenger, you will attain guidance; and the Noble Messenger is not liable except to plainly convey.

# 2846

Allah has promised those among you who believe and do good deeds, that He will certainly give them the Caliphate in the earth the way He gave to those before them; and that He will certainly establish for them their religion which He has chosen for them, and will turn their prior fear into peace; they must worship Me and not ascribe anything as a partner to Me; and whoever is ungrateful after this – it is they who are the disobedient.

# 2847

And keep the prayer established and pay the obligatory charity and obey the Noble Messenger, in the hope of attaining mercy.

# 2848

Do not ever think that the disbelievers can escape from Our control in the land; and their destination is the fire; and indeed what a wretched outcome!

# 2849

O People who Believe! The slaves you possess and those among you who have not attained adulthood, must seek your permission on three occasions; before the dawn prayer, and when you remove your garments in the afternoon, and after the night prayer; these three times are of privacy for you; other than these three times, it is no sin for you or for them; moving about around you and among each other; and this is how Allah explains the verses for you; and Allah is All Knowing, Wise.

# 2850

And when the boys among you reach adulthood, then they too must seek permission like those before them had sought; this is how Allah explains His verses for you; and Allah is All Knowing, Wise.

# 2851

And the old women residing in houses who do not have the desire of marriage – it is no sin upon them if they discard their upper coverings provided they do not display their adornment; and avoiding even this is better for them; and Allah is All Hearing, All Knowing.

# 2852

There is no restriction upon the blind nor any restraint upon the lame nor any constraint upon the sick nor on any among you if you eat from your houses, or the houses of your fathers, or the houses of your mothers, or the houses of your brothers, or the houses of your sisters, or the houses of your fathers’ brothers, or the houses of your fathers’ sisters, or the houses of your mothers’ brothers, or the houses of your mothers’ sisters, or from the houses you are entrusted the keys of, or from the house of a friend – there is no blame upon you if you eat together or apart; therefore when you enter the houses, say greetings to your people – the excellent prayer at the time of meeting, from Allah, blessed and pure; this is how Allah explains the verses to you in order that you may understand.

# 2853

The believers are only those who accept faith in Allah and His Noble Messenger and when they are present with the Noble Messenger upon being gathered for some task, do not go away until they have taken his permission; indeed those who seek your permission, are those who believe in Allah and His Noble Messenger; so if they seek your permission for some affair of theirs, give the permission to whomever you wish among them, and seek Allah’s forgiveness for them; indeed Allah is Oft Forgiving, Most Merciful.

# 2854

Do not presume among yourselves the calling of the Noble Messenger equal to your calling one another; Allah knows those among you who sneak away by some pretext; so those who go against the orders of the Noble Messenger must fear that a calamity may strike them or a painful punishment befall them. (To honour the Holy Prophet – peace and blessings be upon him – is part of faith. To disrespect him is blasphemy.)

# 2855

Pay heed! Indeed to Allah only belong whatsoever is in the heavens and in the earth; He knows the condition you are in; and on the Day when they are returned to Him, He will then inform them of whatever they did; and Allah knows all things.

# 2856

Most Auspicious is He Who has sent down the Furqan (the Criterion – the Holy Qur’an) upon His chosen bondman for him to be a Herald of Warning to the entire world. (Prophet Mohammed – peace and blessings be upon him – is the Prophet towards all mankind.)

# 2857

The One to Whom belongs the kingship of the heavens and of the earth, and has not chosen a child, and has no partner in His kingship, and He has created everything and kept it in proper measure.

# 2858

And people have appointed other Gods besides Him, those who do not create anything but are themselves created, and those who do not have the power to harm or benefit themselves, and who do not have any authority over death or life nor over resurrection.

# 2859

And the disbelievers said, “This is nothing but a slur he has fabricated and others have helped him upon it”; so indeed the disbelievers have stooped to injustice and lie.

# 2860

And they said, “These are stories of the former people, which he has written down, so they are read to him morning and evening.”

# 2861

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “It is sent down by Him Who knows all the secrets of the heavens and the earth; indeed He Oft Forgiving, Most Merciful."

# 2862

And they said, “What is the matter with this (Noble) Messenger, that he eats food and walks in the markets? Why was not an angel sent down along with him, to give warning along with him?”

# 2863

“Or that he should have obtained a hidden treasure, or should have had a garden from which to eat”; and the unjust said, “You do not follow but a man under a magic spell.”

# 2864

O dear Prophet (Mohammed – peace and blessings be upon him) see how they invent examples for you – they have therefore gone astray, unable find a road.

# 2865

Most Auspicious is He Who, if He wills, may make it much better for you – Gardens beneath which rivers flow, and may create high palaces for you.

# 2866

In fact they deny the Last Day; and We have kept prepared a blazing fire for those who deny the Last Day.

# 2867

When it will see them from afar, they will hear its raging and roaring.

# 2868

And when they are thrown into a narrow place in it, bound in chains, they will pray for death in it.

# 2869

It will be said “Do not pray this day for one death – and pray for many deaths.”

# 2870

Say, “Is this better or the Everlasting Gardens which are promised to those who fear? That is their reward and their outcome.”

# 2871

“In it for them is all that they may desire, abiding in it for ever; a promise incumbent upon your Lord, that is prayed for.”

# 2872

And on the day when He will assemble them and all what they worship instead of Allah – then will say to those deities, “Did you mislead my bondmen or did they themselves forget the path?”

# 2873

They will submit, “Purity is to You – it was not rightful for us to appoint any Master besides You; but You gave them and their forefathers usage to the extent that they forgot Your Remembrance; and they were indeed the people who destroy themselves.”

# 2874

“So the deities have belied what you state – so now you can neither avert the punishment nor help yourself; and whoever among you is unjust, We shall make him taste a terrible punishment.”

# 2875

And all the Noble Messengers We sent before you were like this – eating food and walking in the markets; and We have made some of you a test for others; so will you, O people, patiently endure? And O dear Prophet, your Lord is All Seeing.

# 2876

And those who do not expect to meet Us said, “Why were the angels not sent down to us or we been able to see our Lord?” Indeed they thought too highly of themselves and they turned extremely rebellious.

# 2877

The day when they will see the angels – that day will not be of any happiness for the guilty – and they will cry, “O God, erect a barrier between us and them!”

# 2878

And We turned all the deeds they had performed into scattered floating specks of dust.

# 2879

And for the People of the Garden on that day is a better destination and account, and a better place of afternoon rest.

# 2880

And the day when the sky will be split asunder with clouds and the angels will be sent down in full.

# 2881

The true kingship on that day belongs to the Most Gracious; and that is hard for the disbelievers.

# 2882

And the day when the unjust will gnaw his hands, saying, “Alas, if only I had chosen a way along with the (Noble) Messenger (of Allah)!”

# 2883

“Woe to me – alas, if only I had not taken that one for a friend.”

# 2884

“He indeed led me astray from the advice that had come to me”; and Satan deserts man, leaving him unaided.

# 2885

And the Noble Messenger submitted, “O my Lord – indeed my people took this Qur’an as worthy of being abandoned.”

# 2886

And this is how We had appointed guilty people as enemies to every Prophet; and Allah is Sufficient, to guide and to aid.

# 2887

And the disbelievers say, “Why was the Qur’an not sent down to him all at once?” This is how We sent it in stages, in order to strengthen your heart with it and We read it slowly, in stages.

# 2888

And they will never bring you an example, but We shall bring you a true narration and better than it.

# 2889

Those who will be dragged on their faces towards hell – theirs is the worst destination and they are the most astray.

# 2890

And indeed We gave Moosa the Book and appointed with him his brother Haroon as a deputy.

# 2891

We therefore said, “Go, both of you, to the people who have denied Our signs”; then ruining the people, We destroyed them completely.

# 2892

And the people of Nooh – when they denied the Noble Messengers, We drowned them and made them a sign for mankind; and We have kept prepared a painful punishment for the unjust.

# 2893

And the tribes of A’ad and the Thamud, and the people of the Wells, and many a generation between them.

# 2894

And We illustrated examples to each one of them; and ruining them, annihilated them all.

# 2895

And indeed they have visited the township upon which had rained a harmful rain; so were they not seeing it? In fact, they never expected to be raised again.

# 2896

And when they see you (O dear Prophet Mohammed – peace and blessings be upon him) they take you but as a mockery, “Is this the one whom Allah sent as a (Noble) Messenger?”

# 2897

“Possibly he would have misled us away from our Gods had we not been firm upon them”; soon they will know, when they see the punishment, who was astray from the path.

# 2898

Did you see the one who chose his own desires as his God? So will you accept the responsibility of guarding him?

# 2899

Or do you think that most of them hear or understand something? They are not but like the cattle – in fact more astray from the path than them!

# 2900

O dear Prophet, did you not see your Lord, how He spread the shade? And if He willed, He could have made it still; then We made the sun a proof upon it.

# 2901

We then gradually withdraw it towards Us.

# 2902

And it is He Who made the night a veil for you, and the sleep a rest, and made the day for getting up.

# 2903

And it is He Who sent the winds giving glad tidings before His mercy; and We sent down purifying water from the sky.

# 2904

In order that We may revive a dead city with it, and give it to the many beasts and men that We have created, to drink.

# 2905

And indeed We kept cycles of water among them that they may remember; so most men did not accept, except to be ungrateful.

# 2906

If We willed, We could have sent a Herald of Warning to every village.

# 2907

So do not listen to the disbelievers and, with this Qur’an, fight a great war against them.

# 2908

And it is He Who caused the two joint seas to flow- one is palatable, very sweet, and the other is salty, very bitter; and kept a veil between them and a preventing barrier.

# 2909

And it is He Who created man from water, then appointed relatives and in-laws for him; and your Lord is All Able.

# 2910

And they worship such, other than Allah, which neither benefit nor hurt them; and the disbeliever helps the devil instead of his Lord.

# 2911

And We have not sent you (O dear Prophet Mohammed – peace and blessings be upon him) except as a Herald of glad tidings and warnings.

# 2912

Proclaim, “I do not ask any fee from you for this, except that whoever wills may take the way to his Lord.”

# 2913

And trust the Living One Who will never die, and praising Him proclaim His Purity; and He is Sufficient upon the sins of His bondmen, All Aware.

# 2914

The One Who created the heavens and the earth and all that is between them in six days, then befitting His Majesty, established Himself upon the Throne (of control); the Most Gracious – therefore ask the one who knows, concerning Him!

# 2915

And when it is said to them, “Prostrate to the Most Gracious” – they say, “And what is the Most Gracious? Shall we prostrate to whatever you command us?” And this command only increases the hatred in them. (Command of Prostration # 7)

# 2916

Most Auspicious is He Who created lofty towers in the sky and placed a lamp in it, and the luminous moon.

# 2917

And it is He Who created the alternation of the night and day for one who wishes to remember or intends to give thanks.

# 2918

And the bondmen of the Most Gracious who walk upon the earth humbly, and when the ignorant address them they answer, “Peace”. (Good –bye)

# 2919

And who spend the night prostrating and standing, for their Lord.

# 2920

And who submit, “Our Lord – avert the punishment of hell from us; indeed its punishment is a permanent neck-shackle.”

# 2921

Indeed it is a most wretched abode.

# 2922

And those who, when spending, neither exceed the limits nor act miserly, and stay in moderation between the two.

# 2923

And those who do not worship any other deity along with Allah, and do not unjustly kill any living thing which Allah has forbidden, nor commit adultery; and whoever does this will receive punishment.

# 2924

The punishment shall be increased for him on the Day of Resurrection, and he will remain in it forever, with humiliation.

# 2925

Except one who repents and accepts faith and does good deeds – so Allah will turn their evil deeds into virtues; and Allah is Oft Forgiving, Most Merciful.

# 2926

And whoever repents and does good deeds – so he has inclined towards Allah with repentance as was required.

# 2927

And those who do not give false testimony, and when they pass near some indecency, they pass by it saving their honour.

# 2928

And those who, when they are reminded of the signs of their Lord, do not fall deaf and blind upon them.

# 2929

And who submit, “Our Lord, soothe our eyes with our wives and our children, and make us leaders of the pious.”

# 2930

They will be rewarded the highest position in heaven, the recompense of their patience, and they will be welcomed with honour and greetings of peace.

# 2931

They shall abide in it forever; what an excellent abode and place of stay.

# 2932

Say (O dear Prophet Mohammed – peace and blessings be upon him) “You have no value before My Lord if you do not worship Him; so you have denied – therefore the punishment that remains, will occur.”

# 2933

Ta-Seen-Meem. (Alphabets of the Arabic language – Allah, and to whomever he reveals, know their precise meanings.)

# 2934

These are verses of the clear Book.

# 2935

Possibly you may risk your life (O dear Prophet Mohammed – peace and blessings be upon him) by grieving, because they did not believe.

# 2936

If We will, We can send down on them a sign from the sky so that their leaders would remain bowed before it.

# 2937

And never does a new advice come to them from the Most Gracious, but they turn away from it.

# 2938

Indeed they have denied, so now soon coming upon them are the tidings of what they used to scoff at.

# 2939

Have they not seen the earth, that how many honourable pairs We have created in it?

# 2940

Indeed in this is a sign; and most of them will not accept faith.

# 2941

And indeed your Lord – indeed only He is the Almighty, the Most Merciful.

# 2942

And (remember) when your Lord said to Moosa, “Go to the unjust people.”

# 2943

“The nation of Firaun; will they not fear?”

# 2944

He said, “My Lord, I fear that they will deny me.”

# 2945

“I feel hesitant, and my tongue does not speak fast, therefore make Haroon also a Noble Messenger.”

# 2946

“And they have an accusation against me, so I fear that they may kill me.”

# 2947

He said, “Not like this (any more); both of you go with Our signs, We are with you, All Hearing.”

# 2948

“Therefore approach Firaun then proclaim, ‘We both are Noble Messengers of the Lord Of The Creation.’

# 2949

‘That you let the Descendants of Israel go with us.’”

# 2950

Said Firaun, “Did we do not raise you amongst us, as a child? And you spent many years of your life among us!”

# 2951

“And you committed the deed of yours that you committed, and you were ungrateful.”

# 2952

Said Moosa, “I did that at a time when I was unaware of the consequences.” (In anger – See verse 28:15)

# 2953

“I therefore went away from you as I feared you – so my Lord commanded me and appointed me as one of the Noble Messengers.”

# 2954

“And is this some great reward for which you express favour upon me – that you have enslaved the Descendants of Israel?”

# 2955

Said Firaun, “And what is the Lord Of The Creation?

# 2956

Said Moosa, “Lord of the heavens and the earth and all that is between them; if you believe.”

# 2957

Said Firaun to those around him, “Are you not listening with attention?”

# 2958

Said Moosa, “Your Lord and the Lord of your forefathers preceding you.”

# 2959

Said Firaun, “This (Noble) Messenger of yours, who has been sent towards you, has no intelligence!”

# 2960

He said, “The Lord of the East and the West and all that is between them; if you have sense.”

# 2961

Said Firaun, “If you ascribe any one else as a God other than me, I will surely imprison you.”

# 2962

Said Moosa, “Even if I bring to you something clear?”

# 2963

Said Firaun, “Then bring it, if you are of the truthful.”

# 2964

So Moosa put down his staff and it became a visible serpent.

# 2965

And he drew forth his hand, thereupon it shone bright before the beholders.

# 2966

Said Firaun to the court members around him, “He is indeed an expert magician.”

# 2967

“He wishes to expel you out of your land by his magic; so what is your advice?”

# 2968

They said, “Stop him and his brother, and send gatherers to the cities.”

# 2969

“To bring to you every expert great magician.”

# 2970

So the magicians were gathered at a set time on a day appointed.

# 2971

And it was said to the people, “Have you (also) gathered?”

# 2972

The people said, “Perhaps we may follow the magicians if they are victorious.”

# 2973

So when the magicians came, they said to Firaun, “Will we get some reward if we are victorious?”

# 2974

He said, “Yes, and you will then become close to me.”

# 2975

Moosa said to them, “Cast whatever you intend to cast.”

# 2976

So they threw down their ropes and their staves and exclaimed, “By the honour of Firaun, indeed victory is ours!”

# 2977

Therefore Moosa put forth his staff – so it immediately began swallowing all their fabrications.

# 2978

The magicians therefore fell down prostrate.

# 2979

They said, “We have accepted faith in the Lord Of The Creation.”

# 2980

“The Lord of Moosa and Haroon.”

# 2981

Said Firaun, “You accepted faith in him before I permitted you! He is indeed your leader who taught you magic; so now you will come to know; I swear, I will certainly cut off your hands and your feet from alternate sides, and crucify all of you.”

# 2982

They said, “No harm (in it), we will return to our Lord.”

# 2983

“We hope that our Lord will forgive us our mistakes, as we are the first to believe.”

# 2984

And We sent the divine revelation to Moosa that, “Journey along with My bondmen within the night, for you will be pursued.”

# 2985

So Firaun sent gatherers into the cities.

# 2986

They announced “These people are a small group.”

# 2987

“And indeed they have angered all of us.”

# 2988

“And indeed we are an alert army.”

# 2989

We therefore got them out from the gardens and water springs.

# 2990

And from treasures and nice houses.

# 2991

So it was; and We made the Descendants of Israel its inheritors.

# 2992

So the Firaun’s people followed them at sunrise.

# 2993

And when the two groups saw each other, those with Moosa said, “They have caught us.”

# 2994

Said Moosa, “Never! Indeed my Lord is with me, He will now show me the way.”

# 2995

So We sent the divine revelation to Moosa that, “Strike the sea with your staff”; thereupon the sea parted; so each part was like a huge mountain.

# 2996

And We brought the others close to that place.

# 2997

And We saved Moosa and all those with him.

# 2998

Then drowned the others.

# 2999

Indeed in this is surely a sign, and most of them were not Muslims.

# 3000

And indeed your Lord – only He is the Almighty, the Most Merciful.

# 3001

And recite to them the news of Ibrahim.

# 3002

When he said to his father and his people, “What do you worship?”

# 3003

They said, “We worship idols, and we keep squatting in seclusion before them.”

# 3004

He said, “Do they hear you when you call?”

# 3005

“Or do they benefit you or harm you?”

# 3006

They said, “In fact we found our forefathers doing likewise.”

# 3007

He said, “Do you see these – (the idols) whom you worship?”

# 3008

“You and your forefathers preceding you.”

# 3009

“They are all my enemies, except the Lord Of The Creation.”

# 3010

“The One Who created me, so He will guide me.”

# 3011

“And the One Who feeds me and gives me to drink.”

# 3012

“And when I fall ill, so it is He Who heals me.”

# 3013

“And He will give me death, then resurrect me.”

# 3014

“And the One Who, upon Whom I pin my hopes, will forgive me my mistakes on the Day of Judgement.”

# 3015

“My Lord, bestow me the command and join me with those who deserve your proximity.”

# 3016

“And give me proper fame among the succeeding generations.”

# 3017

“And make me among the inheritors of the Gardens of serenity.”

# 3018

“And forgive my father\* – he is indeed astray.” (His paternal uncle)

# 3019

“And do not disgrace me on the day when everyone will be raised.”

# 3020

“The day when neither wealth will benefit nor will sons.”

# 3021

“Except he who presented himself before Allah, with a sound\* heart.” (Intact or unblemished.)

# 3022

And Paradise will be brought close for the pious.

# 3023

And hell will be revealed for the astray.

# 3024

And it will be said to them, “Where are those whom you used to worship?”

# 3025

“Instead of Allah? Will they help you or retaliate?”

# 3026

So they and all the astray were flung into hell.

# 3027

And all the armies of Iblis. (Satan)

# 3028

And they will say, and they will be quarrelling in it:

# 3029

“By oath of Allah, we were indeed in open error.”

# 3030

“When we considered you equal to the Lord Of The Creation.”

# 3031

“And none misled us but the guilty.”

# 3032

“So now we do not have any intercessors.” (The believers shall have intercessors, the disbelievers none).

# 3033

“Nor a caring friend.”

# 3034

“So if only were we to go back, in order to become Muslims!”

# 3035

Indeed in this is a sign; and most of them were not believers.

# 3036

And indeed your Lord – only He is the Almighty, the Most Merciful.

# 3037

The people of Nooh denied the Noble Messengers.

# 3038

When their fellowman Nooh said to them, “Do you not fear?”

# 3039

“I am indeed a trustworthy Noble Messenger of Allah to you.”

# 3040

“Therefore fear Allah, and obey me.”

# 3041

“And I do not ask from you any fee for it; my reward is only upon the Lord Of The Creation.”

# 3042

“Therefore fear Allah, and obey me.”

# 3043

They said, “Shall we believe in you, whereas the abject people are with you?”

# 3044

He said, “What do I know what their deeds are?”

# 3045

“Indeed their account is only upon my Lord, if you perceive.”

# 3046

“And I will not repel the Muslims.”

# 3047

“I am not but clearly a Herald of Warning.”

# 3048

They said, “O Nooh, if you do not desist you will surely be stoned.”

# 3049

He said, “My Lord, my people have denied me.”

# 3050

“Therefore make a decisive judgement between me and them, and rescue me and the believers along with me.”

# 3051

So We saved him and those with him in a laden ship.

# 3052

Then after it, We drowned the rest.

# 3053

Indeed in this is a sign; and most of them were not believers.

# 3054

And indeed your Lord, only He is the Almighty, the Most Merciful.

# 3055

(The tribe of) A’ad denied the Noble Messengers.

# 3056

When their fellowman Hud said to them, “Do you not fear?”

# 3057

“I am indeed a trustworthy Noble Messenger of Allah to you.”

# 3058

“Therefore fear Allah and obey me.”

# 3059

“And I do not ask from you any fee for it; my reward is only upon the Lord Of The Creation.”

# 3060

“What! You build a structure on every height, to laugh at the passers-by?”

# 3061

“And prefer strong palaces, that perhaps you may live for ever?”

# 3062

“And when you apprehend someone, you seize him mercilessly?”

# 3063

“Therefore fear Allah, and obey me.”

# 3064

“Fear Him Who has aided you with the things you know.”

# 3065

“He aided you with cattle and sons.”

# 3066

“And with gardens and water-springs.”

# 3067

“Indeed I fear upon you the punishment of a Great Day.”

# 3068

They said, “It is the same for us, whether you advise us or not be of the preachers.”

# 3069

“This is nothing but the tradition of former people.”

# 3070

“And we will not be punished.”

# 3071

In response they denied him – We therefore destroyed them; indeed in this is a sign; and most of them were not believers.

# 3072

And indeed your Lord – only He is the Almighty, the Most Merciful.

# 3073

The Thamud tribe denied the Noble Messengers.

# 3074

When their fellowman Saleh said to them, “Do you not fear?”

# 3075

“I am indeed a trustworthy Noble Messenger of Allah to you.”

# 3076

“Therefore fear Allah and obey me.”

# 3077

“And I do not ask from you any fee for it; my reward is only upon the Lord Of The Creation.”

# 3078

“Will you be left peacefully in these favours over here?”

# 3079

“In gardens and water springs?”

# 3080

“And fields and palm-trees, with delicate tendrils?”

# 3081

“And you carve out dwellings in the mountains, with skill?”

# 3082

“Therefore fear Allah and obey me.”

# 3083

“And do not follow those who exceed the limits.”

# 3084

“Those who spread turmoil in the earth, and do no reform.”

# 3085

They said, “You are under a magic spell.”

# 3086

“You are just a human like us; therefore bring some sign if you are truthful.”

# 3087

He said, “This is the she-camel – one day shall be her turn to drink, and on the other appointed day, shall be your turn.”

# 3088

“And do not touch her with evil intentions for the punishment of the Great Day will seize you.”

# 3089

So they hamstrung her, and in the morning could only regret.

# 3090

The punishment therefore seized them; indeed in this is a sign; and most of them were not believers.

# 3091

And indeed your Lord – only He is the Almighty, the Most Merciful.

# 3092

The people of Lut denied the Noble Messengers.

# 3093

When their fellowman Lut said to them, “Do you not fear?”

# 3094

“I am indeed a trustworthy Noble Messenger of Allah to you.”

# 3095

“Therefore fear Allah and obey me.”

# 3096

“And I do not ask from you any fee for it; my reward is only upon the Lord Of The Creation.”

# 3097

“What! Among all the creatures, you commit the immoral acts with men?”

# 3098

“And leave the wives your Lord has created for you? In fact you are people who exceed the limits.”

# 3099

They said, “O Lut, if you do not desist, you will be expelled.”

# 3100

He said, “I am disgusted with your works.”

# 3101

“My Lord, rescue me and my family from their deeds.”

# 3102

We therefore rescued him and his entire family.

# 3103

Except one old woman, who stayed behind.

# 3104

We then destroyed the others.

# 3105

And We showered a rain upon them; so what a wretched rain for those who were warned!

# 3106

Indeed in this is a sign; and most of them were not Muslims.

# 3107

And indeed your Lord – only He is the Almighty, the Most Merciful.

# 3108

The People of the Woods denied the Noble Messengers.

# 3109

When Shuaib said to all of them, “Do you not fear?”

# 3110

“I am indeed a trustworthy Noble Messenger of Allah to you.”

# 3111

“Therefore fear Allah and obey me.”

# 3112

“And I do not ask from you any fee for it; my reward is only upon the Lord Of The Creation.”

# 3113

“Measure in full, and do not be of those who reduce.”

# 3114

“And weigh with a proper balance.”

# 3115

“And do not give the people their goods diminished, and do not roam the earth causing turmoil.”

# 3116

“And fear Him Who created you and the earlier creations.”

# 3117

They said, “You are under a magic spell.”

# 3118

“You are just a human like us, and indeed we consider you a liar.”

# 3119

“Therefore cause a part of the sky to fall upon us, if you are of the truthful.”

# 3120

He said, “My Lord is Well Aware of what you do.”

# 3121

In response they denied him – therefore the punishment of the day of the tent\* seized them; that was indeed a punishment of a Great Day. (The clouds formed a tent and rained fire upon them).

# 3122

Indeed in this is a sign; and most of them were not Muslims.

# 3123

And indeed your Lord – only He is the Almighty, the Most Merciful.

# 3124

And indeed this Qur’an has been sent down by the Lord Of The Creation.

# 3125

The Trustworthy Spirit brought it down. (Angel Jibreel – peace be upon him.)

# 3126

Upon your heart, for you to convey warning.

# 3127

In plain Arabic language.

# 3128

And indeed it is mentioned in the earlier Books.

# 3129

And was this not a sign for them, that the scholars of the Descendants of Israel may recognise this Prophet?

# 3130

And had We sent it down upon a person other than an Arab,

# 3131

In order that he read it to them, even then they would not have believed in it.

# 3132

This is how We have made (the habit of) denying embedded in the hearts of the guilty.

# 3133

They will not believe in it to the extent that they see the painful punishment.

# 3134

So it will come upon them suddenly, whilst they will be unaware.

# 3135

They will therefore say, “Will we get some respite?”

# 3136

So do they wish to hasten Our punishment?

# 3137

Therefore observe, that if We give them some comforts for some years, –

# 3138

And then the promise that is given to them, does come upon them-

# 3139

So of what benefit will be the comforts that they were using?

# 3140

And never did We destroy a township which did not have Heralds of warning, –

# 3141

To advise; and We never oppress.

# 3142

And this Qur’an was not brought down by the devils.

# 3143

They are unworthy of it, nor can they do it.

# 3144

Indeed they have been banished from the place of hearing.

# 3145

Therefore do not worship another deity along with Allah, for you will be punished.

# 3146

And O dear Prophet (Mohammed – peace and blessings be upon him), warn your closest relatives.

# 3147

And spread your wing of mercy for the believers following you.

# 3148

So if they do not obey you, then say, “Indeed I am unconcerned with what you do.”

# 3149

And rely upon (Allah) the Almighty, the Most Merciful.

# 3150

Who watches you when you stand up.

# 3151

And watches your movements among those who prostrate in prayer.

# 3152

Indeed only He is the All Hearing, the All Knowing.

# 3153

Shall I inform you upon whom do the devils descend?

# 3154

They descend on every great accuser, extreme sinner. (The magicians)

# 3155

The devils convey upon them what they heard, but most of them are liars.

# 3156

And the astray follow the poets.

# 3157

Did you not see that they keep wandering in every valley?

# 3158

And they speak what they do not do?

# 3159

Except those who believed and did good deeds, and profusely remembered Allah, and took revenge after they had been wronged\*; and soon the unjust will come to know upon which side they will be overturned\*\*. (\* The Muslim poets who praise Allah and the Prophet. \*\* The disbelievers will be punished.)

# 3160

Ta-Seen\*; these are verses of the Qur’an and the clear Book. (Alphabets of the Arabic language – Allah, and to whomever he reveals, know their precise meanings.)

# 3161

A guidance and glad tidings for the believers.

# 3162

Those who keep the prayer established and pay the charity and are certain of the Hereafter.

# 3163

Those who do not believe in the Hereafter – We have made their deeds seem good to them, so they are astray.

# 3164

It is they for whom is the worst punishment, and they will be the greatest losers in the Hereafter.

# 3165

And indeed you (O dear Prophet Mohammed – peace and blessings be upon him), are taught the Qur’an from the Wise, the All Knowing.

# 3166

(Remember) when Moosa said to his wife, “I have sighted a fire; I will soon bring its news to you, or bring for you an ember from it so that you may warm yourselves.”

# 3167

So when he reached it, it was proclaimed, “Blessed is he who is in the location of the fire (Moosa) and those who are close to it (the angels); and Purity is to Allah, the Lord Of The Creation.”

# 3168

“O Moosa, I am indeed, in truth, Allah the Almighty, the Wise.”

# 3169

“And put down your staff”; so when he saw it writhing like a serpent, he turned moving away without looking back; We said, “O Moosa, do not fear; indeed the Noble Messengers do not fear in My presence.”

# 3170

“Except the one\* who does injustice and then after evil changes it for virtue – then indeed I am Oft Forgiving, Most Merciful.” (Other than the Prophets.)

# 3171

“And put your hand inside your armpit – it will come out shining white, not due to any illness; a sign among the nine signs towards Firaun and his people; they are indeed a lawless nation.”

# 3172

Then when Our enlightening signs came to them, they said, “This is clear magic.”

# 3173

And they denied them – whereas in their hearts they were certain of them – due to injustice and pride; therefore see what sort of fate befell the mischievous!

# 3174

And We indeed bestowed great knowledge to Dawud and Sulaiman; and they both said, “All praise is to Allah, Who bestowed us superiority over many of His believing bondmen.”

# 3175

And Sulaiman became Dawud’s heir; and he said, “O people, we have indeed been taught the language of birds, and have been given from all things; this surely is a manifest favour.”

# 3176

And assembled together for Sulaiman were his armies of jinns and men, and of birds – so they had to be restricted.

# 3177

Until when they came to the valley of the ants, a she ant exclaimed, “O ants, enter your houses – may not Sulaiman and his armies crush you, unknowingly.”

# 3178

He therefore smiled beamingly at her speech\*, and submitted, “My Lord, bestow me guidance so that I thank you for the favour which You bestowed upon me and my parents, and so that I may perform the good deeds which please You, and by Your mercy include me among Your bondmen who are worthy of Your proximity.” (Prophet Sulaiman heard the voice of the she ant from far away.)

# 3179

And he surveyed the birds – he therefore said, “What is to me that I do not see the Hudhud (hoopoe), or is he really absent?”

# 3180

“I will indeed punish him severely or slay him, or he must bring to me some clear evidence.”

# 3181

So Hudhud did not stay absent for long, and presenting himself submitted, “I have witnessed a matter that your majesty has not seen, and I have brought definite information to you from the city of Saba.”

# 3182

“I have seen a woman who rules over them, and she has been given from all things, and she has a mighty throne.”

# 3183

“I found her and her nation prostrating before the sun instead of Allah, and Satan has made their deeds seem good to them thereby preventing them from the Straight Path – so they do not attain guidance.”

# 3184

“Why do they not prostrate to Allah, Who brings forth the things hidden in the heavens and the earth, and knows all what you hide and all what you disclose?”

# 3185

“Allah – there is no True God except Him, the Owner of the Great Throne.” (Command of Prostration # 8)

# 3186

Said Sulaiman, “We shall now see whether you spoke the truth or are among the liars.”

# 3187

“Go with this letter of mine and drop it upon them – then move aside from them and see what they answer in return.”

# 3188

The woman said, “O chieftains, indeed a noble letter has been dropped upon me.”

# 3189

“Indeed it is from Sulaiman, and it is (begins) with ‘Allah – beginning with the name of – the Most Gracious, the Most Merciful.’”

# 3190

“That ‘Do not wish eminence above me, and present yourselves humbly to me, with submission.’”

# 3191

She said, “O chieftains, advise me in this matter of mine; I do not give a final decision until you are present with me.”

# 3192

They said, “We possess great strength and are great warriors, and the decision is yours, therefore consider what you will command.”

# 3193

She said, “Indeed the kings, when they enter a township, destroy it and disgrace its honourable people; and this is what they do.”

# 3194

“And I shall send a present to them, then see what reply the envoys bring.”

# 3195

So when the envoy came to Sulaiman, he said, “Are you helping me with wealth? What Allah has bestowed upon me is better than what He has given you; rather it is you who are delighted at your gift.”

# 3196

“Go back to them – so we shall indeed come upon them with an army they cannot fight, and degrading them shall certainly drive them out from that city, so they will be humiliated.”

# 3197

Said Sulaiman, “O court members, which one of you can bring me her throne before they come humbled in my presence?”

# 3198

An extremely evil jinn said, “I will bring it in your presence before you disperse the assembly; and I am indeed strong and trustworthy upon it.”

# 3199

Said one who had knowledge of the Book, “I will bring it in your majesty’s presence before you bat your eyelid”; then when he saw it set in his presence\*, Sulaiman said, “This is of the favours of my Lord; so that He may test me whether I give thanks or am ungrateful; and whoever gives thanks only gives thanks for his own good; and whoever is ungrateful – then indeed my Lord is the Independent (Not Needing Anything), the Owner Of All Praise.” (A miracle which occurred through one of Allah’s friends.)

# 3200

Said Sulaiman, “Disguise her throne in front of her so that we may see whether she finds the way\* or becomes of those who remain unknowing.” (\*Recognises her throne.)

# 3201

Then when she came, it was said to her, “Is your throne like this? She said, “As if this is it! And we came to know about this incident beforehand and submit (to you).”

# 3202

And the thing she used to worship instead of Allah prevented her; she was indeed from the disbelieving people.

# 3203

It was said to her, “Enter the hall”; and when she saw it she thought it was a pool and bared her shins\*; said Sulaiman, “This is only a smooth hall, affixed with glass”; she said, “My Lord, I have indeed wronged myself, and I now submit myself along with Sulaiman to Allah, the Lord Of The Creation.” (\* In order to cross it)

# 3204

And indeed We sent to the Thamud, their fellowman Saleh that, “Worship Allah”, thereupon they became two parties quarrelling.

# 3205

He said, “O my people, why do you hasten upon the evil before the good? Why do you not seek forgiveness from Allah? Perhaps there may be mercy upon you.”

# 3206

They said, “We consider you an evil omen, and your companions”; he said, “Your evil omen is with Allah – in fact you people have fallen into trial.”

# 3207

And there were nine persons in the city who used to cause turmoil in the land and did not wish reform.

# 3208

Swearing by Allah they said to one another, “We will indeed attack him and his family at night, and then say to his heir, ‘We were not present at the time of slaying of this household, and indeed we are truthful.’”

# 3209

So they devised a scheme, and We made our secret plan, and they remained neglectful.

# 3210

Therefore see what was the result of their scheming – We destroyed them and their entire nation.

# 3211

So these are their houses fallen flat, the recompense of their injustice; indeed in this is a sign for people who know.

# 3212

And We rescued those who accepted faith and used to fear.

# 3213

And (remember) Lut when he said to his people, “What! You stoop to the shameful whereas you can see?”

# 3214

“What! You lustfully go towards men, leaving the women?! In fact, you are an ignorant people.”

# 3215

Therefore the answer of his people was nothing except that they said, “Expel the family of Lut from your township; these people wish purity!”

# 3216

We therefore rescued him and his family, except his wife; We had decreed that she is of those who will remain behind.

# 3217

And We showered a rain upon them; so what a wretched rain for those who were warned!

# 3218

Say (O dear Prophet Mohammed – peace and blessings be upon him), “All praise is to Allah, and peace upon His chosen bondmen; is Allah better or what you ascribe as His partners?”

# 3219

Or He Who created the heavens and the earth, and sent down water from the sky for you; so We grew delightful gardens with it; you had no strength to grow its trees; is there a God along with Allah?! In fact they are those who shun the right path.

# 3220

Or He Who made the earth for habitation, and placed rivers within it, and created mountains as anchors for it, and kept a barrier between the two seas? Is there a God along with Allah?! In fact, most of them are ignorant.

# 3221

Or He Who answers the prayer of the helpless when he invokes Him and removes the evil, and makes you inheritors of the earth? Is there a God along with Allah?! Very little do they ponder!

# 3222

Or He Who shows you the path in the darkness of the land and the sea, and He Who sends the winds before His mercy, heralding glad tidings? Is there a God along with Allah?! Supremacy is to Allah above all that they ascribe as partners!

# 3223

Or He Who initiates the creation, then will create it again, and He Who provides you sustenance from the skies and the earth? Is there a God along with Allah?! Proclaim, “Bring your proof, if you are truthful!”

# 3224

Say (O dear Prophet Mohammed – peace and blessings be upon him), “None in the heavens and the earth know the hidden by themselves, except Allah; and they do not know when they will be raised.”

# 3225

Has their knowledge advanced so much as to know the Hereafter? On the contrary, they are in doubt concerning it; in fact they are blind towards it.

# 3226

And the disbelievers said, “Will we, when we and our forefathers have turned into dust, be removed again?”

# 3227

“Indeed this promise was given to us, and before us to our forefathers – this is nothing but stories of former people.”

# 3228

“Proclaim, (O dear Prophet Mohammed – peace and blessings be upon him), “Travel in the land and see what sort of fate befell the guilty.”

# 3229

And do not grieve upon them, nor be distressed because of their scheming.

# 3230

And they say, “When will this promise come, if you are truthful?”

# 3231

Say, “It could be that a part of what you are impatient for is (already) after you.”

# 3232

Indeed your Lord is Most Munificent upon mankind, but most men do not give thanks.

# 3233

And indeed your Lord knows what is hidden in their bosoms, and what they disclose.

# 3234

And all the hidden secrets of the heavens and the earth are (written) in a clear Book. (The Preserved Tablet)

# 3235

Indeed this Qur’an narrates to the Descendants of Israel most of the matters in which they differ.

# 3236

And indeed it is a guidance and a mercy for the Muslims.

# 3237

Indeed your Lord judges between them with His command; and He is the Almighty, the All Knowing.

# 3238

Therefore rely on Allah; you are indeed upon the clear Truth.

# 3239

Indeed the dead\* do not listen to your call nor do the deaf\* listen to your call, when they flee turning back. (The dead and deaf implies the disbelievers.)

# 3240

And you will not guide the blind out of their error; and none listen to you except those who accept faith in Our signs, and they are Muslims.

# 3241

And when the Word (promise) appears upon them, We shall bring forth for them a beast from the earth to speak to them – because the people were not accepting faith in Our signs. (This beast will rise from the earth, when the Last Day draws near.)

# 3242

And the Day when We will raise from every nation an army that denies Our signs – so the former groups will be held back for the latter to join them.

# 3243

Until when they all come together, He will say, “Did you deny My signs whereas your knowledge had not reached it, or what were the deeds you were doing?”

# 3244

And the Word has appeared upon them because of their injustice, so now they do not speak.

# 3245

Did they not see that We created the night for them to rest in, and created the day providing sight? Indeed in this are signs for the people who have faith.

# 3246

And the Day when the Trumpet is blown – so all those who are in the heavens and the earth will be terrified, except whomever Allah wills; and everyone has come to Him, in submission.

# 3247

And you will see the mountains presuming them fixed whereas they will be moving like the clouds; this is Allah’s making, Who created all things with wisdom; indeed He is Informed of what you do.

# 3248

Whoever brings a good deed – for him is a reward better than it; and they will be safe from the terror on that Day.

# 3249

And whoever brings evil – so their faces will be dipped into the fire; what reward will you get, except what you did?

# 3250

“I (Prophet Mohammed – peace and blessings be upon him) have been commanded to worship the Lord of this city, Who has deemed it sacred, and everything belongs to Him; and I have been commanded to be among the obedient.”

# 3251

“And to recite the Qur’an”; so whoever attained the right path, has attained it for his own good; and whoever goes astray – so say, “Indeed I am only a Herald of Warning.”

# 3252

And proclaim, “All praise is to Allah – He will soon show you His signs so you will recognise them”; and (O dear Prophet Mohammed – peace and blessings be upon him) your Lord is not unaware of what you, O people, do.”

# 3253

Ta-Seen-Meem. (Alphabets of the Arabic language – Allah and to whomever he reveals, know their precise meanings.)

# 3254

These are verses of the clear Book.

# 3255

We shall narrate to you the true tidings of Moosa and Firaun, for the people who have faith.

# 3256

Indeed Firaun had achieved dominance in the earth and made its people subservient to him – seeing a group among them weak, he used to kill their sons and spare their women; he was indeed very mischievous.

# 3257

And We willed to favour those who were weak in the earth, and to make them leaders and to make them the inheritors (of the land and wealth of Firaun’s people).

# 3258

And to give them control in the land, and to show Firaun and Haman and their armies what they fear from them.

# 3259

And We inspired the mother of Moosa that, “Suckle him; then when you fear for him, cast him into the river and do not fear nor grieve; We shall indeed return him back to you and make him one of the Noble Messengers.”

# 3260

So the family of Firaun picked him up, in order that he become their enemy and a sorrow upon them; indeed Firaun and Haman and their armies were guilty.

# 3261

And Firaun’s wife said, “This child is the comfort of my eyes and yours\*; do not kill him; perhaps he may benefit us, or we may adopt him as our son” – and they were unaware. (Had Firaun also said the same, Allah would have granted him faith.)

# 3262

And in the morning, the heart of Moosa’s mother became impatient; and she would have almost certainly given away his secret had We not strengthened her heart, so that she may have faith in Our promise.

# 3263

And she said to his sister, “Go after him” – she therefore observed him from far, and they were not aware.

# 3264

And We had already forbidden suckle-nurses for him, so she said, “Shall I show you a household that will nurse this child of yours, and they are his well-wishers?”

# 3265

So We returned him to his mother in order to soothe her eyes and not grieve, and to know that Allah’s promise is true – but most people do not know.

# 3266

And when he reached his maturity and full strength, We gave him wisdom and knowledge; and this is how We reward the virtuous.

# 3267

And he entered the city when its inhabitants were sleeping unaware in the afternoon – he therefore found two men fighting; one was from Moosa’s group, and the other from among his enemies; so the one who was of Moosa’s group pleaded to Moosa for help against him who was of his enemies – therefore Moosa punched him thereby finishing him; he said, “This act was from the devil\*; indeed he is an open enemy, a misleader.” (\* The act of oppressing the man from Bani Israel).

# 3268

He said, “My Lord! I have indeed wronged my soul\* therefore forgive me” – He therefore forgave him; indeed only He is the Oft Forgiving, the Most Merciful. (\* By getting angry.)

# 3269

He said, “My Lord! The way You have bestowed favour upon me, so never will I be a supporter of the guilty.”

# 3270

So he was in the city at morning fearing, waiting to see what happens – thereupon he sighted the one who had appealed to him the day before, crying out to him for help; Moosa said to him, “Indeed you are clearly astray.”

# 3271

So when Moosa wished to apprehend the man who was an enemy to them both, he said, “O Moosa! Do you wish to kill me the way you killed a man yesterday? You only wish to become a strict ruler in the land, and not to make reform.”

# 3272

And a man came running from the outer part of the city; he said, “O Moosa! Indeed the court members are considering killing you, therefore go away – I surely am your well-wisher.”

# 3273

So he left the city in fear, waiting to see what happens; he said, “My Lord! Rescue me from the unjust people.”

# 3274

And when he turned his attention towards Madyan he said, “It is likely that my Lord will show me the right path.”

# 3275

And when he came to the water of Madyan he found a group of men, watering their animals; and away from them he found two women restraining their animals; he said, “What is the matter with you?” They said, “We do not water our animals till all the shepherds water and take away their animals; and our father is very old.”

# 3276

Therefore Moosa watered their animals for them, and then turned towards the shade and said, “My Lord! I am in need of the sustenance you may send down for me.”

# 3277

So one of the two women approached him, walking shyly; she said, “My father is calling you, in order to give you wages because you watered our animals for us”; when Moosa came to him and had told him the story, he said, “Do not fear, you are safe from the unjust people.”

# 3278

One of the two women said, “O my father! Employ him – indeed a strong and trustworthy employee is better.”

# 3279

He said, “I wish to give you one of these two daughters of mine in marriage, the bridal money being that you work for me for eight years; then if you complete ten years, it will be from you; and I do not wish to put you in hardship; Allah willing, you will probably find me of the righteous.”

# 3280

Said Moosa, “This is agreed between me and you; there shall be no claim upon me if I fulfil any of these two terms; and Allah is the Trustee upon this word of ours.”

# 3281

So when Moosa completed his term and was travelling with his wife, he saw a fire in the direction of the Mount (Sinai); he said to his wife “Stay here – I have sighted a fire in the direction of the mount – perhaps I may bring you some news from it, or an ember so that you may warm yourselves.”

# 3282

And when he reached the fire, he was called out to from the right side of the valley in the blessed field, from the tree, “O Moosa! Indeed I am truly Allah, the Lord Of The Creation.”

# 3283

“Put down your staff”; so when Moosa saw it writhing like a serpent, he turned moving away without looking back; “O Moosa! Come forth and do not fear; indeed you are in peace.”

# 3284

“Put your hand inside your armpit – it will come out shining white, not due to any illness; and put your hand on your chest to remove the fear – so these are two proofs from your Lord to Firaun and his court members; indeed they are a lawless people.”

# 3285

He submitted, “My Lord! I killed a soul among them and I fear they will kill me.”

# 3286

“And my brother Haroon – he is more eloquent than I am in speech, therefore in order to help me, appoint him as a Noble Messenger so that he confirms me; I fear that they will deny me.”

# 3287

He said, “We will soon strengthen your arm with your brother, and give you both dominance, so they will not be able to harm you; due to Our signs; you both, and those who will follow you, will be victorious.”

# 3288

Therefore when Moosa came to them with Our clear signs they said, “This is nothing but invented magic, and we never heard anything like this among our forefathers.”

# 3289

And said Moosa, “My Lord well knows him who has brought guidance from Him, and for whom will be the abode the Hereafter; indeed the unjust never attain success.”

# 3290

And Firaun said, “O court members! I do not know of any other God for you, except myself; therefore, O Haman, build a lofty palace for me by baking concrete in order that I may sneak a look at the God of Moosa – and according to me, he is indeed a liar.”

# 3291

And he and his soldiers wrongfully sought greatness in the land, and assumed they would never be brought back to Us.

# 3292

We therefore seized him and his armies, and hurled them into the sea; therefore see what sort of fate befell the unjust!

# 3293

And We made them leaders of the people of hell, inviting towards the fire; and they will not be helped on the Day of Resurrection.

# 3294

And We set a curse after them in this world; and evil is for them on the Day of Resurrection.

# 3295

And We indeed gave Moosa the Book after We had destroyed the former generations, having enlightenment for mankind, and a guidance and a mercy, for them to accept advice.

# 3296

And you (O dear Prophet Mohammed – peace and blessings be upon him) were not on the western side of the Mount when We sent the command of Prophethood to Moosa, and you were not present. (Yet you narrate the account very clearly to the Jews and Christians.)

# 3297

However, We created generations and ages passed by upon them; and nor were you dwelling with the people of Madyan reciting Our verses to them – however it is We Who made the Noble Messengers.

# 3298

And nor were you beside the Mount when We proclaimed – however it is a mercy from your Lord\* so that you may warn a nation towards whom no Herald of Warning came before you, in the hope of their heeding advice. (\*That He has bestowed knowledge of the hidden to you)

# 3299

Otherwise, if some disaster befell them because of what their own hands have sent forward they would say, “Our Lord! Why did you not send a Noble Messenger towards us, so we may have followed Your signs and accepted faith?”

# 3300

So when the Truth\* from Us came to them, they said, “Why has he not been given what was given to Moosa?” Had they not disbelieved in what was earlier given to Moosa? They said, “They are two magicians, who support each other”; and said, “We disbelieve in both of them.” (\* Prophet Mohammed – peace and blessings be upon him).

# 3301

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Therefore bring a Book from Allah which is better guiding than these two – I will follow it – if you are truthful.”

# 3302

So if they do not accept your challenge, then know that they only follow their desires; and who is more astray than one who follows his desires away from the guidance of Allah? Indeed Allah does not guide the unjust.

# 3303

And We indeed sent down the Word continuously for them, so that they may ponder.

# 3304

Those to whom We gave the Book before it, accept faith in it. (Some scholars among Jews / Christians).

# 3305

And when these verses are recited to them, they say, “We accept faith in it – indeed it is the Truth from our Lord – and indeed we had surrendered even before this.”

# 3306

They will be given double the reward, the recompense of their patience – and they repel evil with good, and spend part of what We have provided them.

# 3307

And when they hear indecent speech, they ignore it and say, “For us are our deeds and for you are your deeds; peace be to you (good bye); we are not interested in the ignorant.”

# 3308

Indeed it is not such that you can guide whomever you love, but Allah guides whomever He wills; and He well knows the people upon guidance.

# 3309

And they say, “If we follow the guidance along with you, people would snatch us away from our land”; did We not establish them in a safe Sacred Land, towards which are brought fruits of all kinds – the sustenance from Us? But most of them do not know.

# 3310

And how many towns did We destroy which had stooped to self indulgence! So here lie their dwellings, uninhabited after them except a little; and only We are the Inheritors.

# 3311

And never does your Lord destroy towns until He sends a Noble Messenger to their principal town, reciting Our verses to them; and We never destroy towns unless its people are unjust.

# 3312

And whatever you have been given, is a usage in the life of this world and its adornment; and that which is with Allah is better and more lasting; so do you not have sense?

# 3313

So is he whom We have given a good promise – he will therefore get it – equal to him whom We gave the usage of the life of this world to enjoy, and who will then be brought captive on the Day of Resurrection?

# 3314

On the day when He will call to them – He will therefore proclaim, “Where are those partners of Mine, whom you had assumed?”

# 3315

Those against whom the Word will have proved true will say, “Our Lord! These are they whom we led astray; we led them astray the way we ourselves went astray; we are unconcerned with them and we incline towards You – they never worshipped us!”

# 3316

And it will be said to them, “Call unto your ascribed partners” – so they will call unto them and they will not listen to them, and they will behold the punishment; if only they had obtained guidance!

# 3317

And on the Day when He will call to them and proclaim, “What answer did you give to the Noble Messengers?”

# 3318

So on that Day the tidings will be blinded\* for them, therefore they will not ask one another. (\* They will forget at that moment).

# 3319

So whoever repented and accepted faith and did good deeds, so it is likely that he will be among the successful.

# 3320

And your Lord creates whatever He wills, and chooses; they do not have any power to choose; Purity and Supremacy are to Allah above their ascribing partners (to Him).

# 3321

And your Lord knows what is hidden in their breasts, and what they disclose.

# 3322

And He is Allah – there is no God except Him; only His is the praise in this world and in the Hereafter; and only His is the command, and it is towards Him that you will be returned.

# 3323

Proclaim, “What is your opinion – if Allah makes it night continuously for you till the Day of Resurrection then, other than Allah, who is the God who could bring you light? So do you not heed?”

# 3324

Say, “What is your opinion – if Allah makes it day continuously for you till the Day of Resurrection then, other than Allah, who is the God who could bring you night for you to rest during it? So do you not perceive?”

# 3325

And with His mercy He made the night and day for you, so that you may rest during the night and seek His munificence during the day, and for you to be thankful.

# 3326

On the day when He will call to them – He will therefore proclaim, “Where are those partners of Mine, whom you had assumed?”

# 3327

And We shall proclaim taking out a witness from each group, “Bring your proof” – so they will realise that the Truth (Right) is for Allah, and they will lose all that they had fabricated.

# 3328

Indeed Qaroon was from the people of Moosa – he then oppressed them; and We gave him so many treasures that their keys were a heavy burden for a strong group; when his people said to him, “Do not show off – indeed Allah does not like the boastful.”

# 3329

“And seek the abode of the Hereafter with the wealth that Allah has given you, and do not forget your part in this world, and do favours (to others) the way Allah has favoured you, and do not seek to cause turmoil in the earth; indeed Allah does not like the mischievous.”

# 3330

He said, “I got this only due to a knowledge I have”; and does he not know that before him Allah destroyed the generations who were stronger than him and more in number? And there is no questioning of the guilty regarding their sins.

# 3331

He therefore came before his people in his pomp; said those who desired the worldly life, “If only we were to get what Qaroon has been given – he is indeed very fortunate.”

# 3332

And said those who were given the knowledge, “Woe to you – the reward of Allah is better for one who accepts faith and does good deeds; and only those who are patient will receive it.”

# 3333

We therefore buried him and his house into the earth; so he had no group to help save him from Allah; nor could he take revenge.

# 3334

And those who had the day before desired his status, said in the morning, “It is strange – Allah expands the sustenance for whomever He wills among His bondmen, and restricts it; if Allah had not been gracious to us He would have buried us too; strangely, the disbelievers do not prosper.”

# 3335

This abode of the Hereafter – We make it for those who do not wish greatness in the land nor turmoil; and the Hereafter is only for the pious.

# 3336

Whoever brings virtue, for him is better than it; and whoever brings evil – so those who commit evil will not be repaid except to the extent of their deeds.

# 3337

Indeed He Who has ordained the Qur’an upon you, will surely bring you back to where you wish; proclaim, “My Lord well knows him who came with guidance, and him who is in open error.”

# 3338

And you held no expectations of the Book being sent down upon you, except that it is a mercy from your Lord – therefore never support the disbelievers. (You did not crave for it but trusted in the mercy of your Lord).

# 3339

And never may they prevent you from the verses of Allah after they have been sent down upon you, and call towards your Lord, and never be among those who ascribe partners (to Him).

# 3340

And do not worship any other God along with Allah; there is no God except Him; all things are destructible except His Entity; only His is the command, and it is towards Him that you will be returned.

# 3341

Alif-Lam-Meem. (Alphabets of the Arabic language – Allah and to whomever He reveals, know their precise meanings.)

# 3342

Do men fancy that they will be left just upon their declaring, “We believe”, and they will not be tested?

# 3343

We indeed tested those before them – so Allah will surely test the truthful, and will surely test the liars.

# 3344

Or do they who commit evil deeds imagine that they can escape from Us? What an evil judgement they impose!

# 3345

Whoever expects to meet Allah – then indeed the time appointed by Allah will come; and He is the All Hearing, the All Knowing.

# 3346

And whoever strives in Allah's cause, strives only for his own benefit; indeed Allah is Independent of the entire creation.

# 3347

And those who accepted faith and did good deeds – We will indeed relieve their sins and reward them for the best of their deeds.

# 3348

And upon man We ordained kindness towards parents; and if they strive to make you ascribe a partner with Me, about which you do not have any knowledge, then do not obey them; towards Me only is your return and I will tell you what you used to do.

# 3349

And those who accepted faith and did good deeds – We shall indeed include them among the virtuous.

# 3350

And some people say, “We believe in Allah” – so if they are afflicted with some adversity in Allah’s way, they consider the chaos created by men as the punishment from Allah; and if the help comes from your Lord, they will surely say, “Indeed we were with you”; does not Allah well know what is in the hearts of the entire creation?

# 3351

And indeed Allah will make known the believers, and indeed He will expose the hypocrites.

# 3352

And the disbelievers said to the Muslims, “Follow our path and we will bear your sins”; whereas they will not bear anything from their sins; they are indeed liars.

# 3353

And they will surely bear their own burdens and some other burdens along with their own; and they will undoubtedly be questioned on the Day of Resurrection concerning what they had fabricated.

# 3354

And indeed We sent Nooh to his people – he therefore stayed with them for a thousand years, less fifty; so the flood seized them, and they were unjust.

# 3355

And We rescued him and the people aboard the ship, and made the ship a sign for the entire world.

# 3356

And (remember) Ibrahim – when he said to his people, “Worship Allah and fear Him; that is better for you, if you knew!”

# 3357

“You worship only idols instead of Allah, and only forge a clear lie; indeed those whom you worship instead of Allah do not control your sustenance – therefore seek your sustenance from Allah, and worship Him, and be grateful to Him; it is towards Him that you will be returned.”

# 3358

“And if you deny, then many nations have denied before you; and the Noble Messenger is not responsible except to plainly convey (the message).”

# 3359

Have they not seen how Allah initiates the creation, then will create it again? Indeed that is easy for Allah.

# 3360

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Travel in the land and see how He creates for the first time, then Allah brings forth the next development; indeed Allah is Able to do all things.”

# 3361

He punishes whomever He wills and has mercy upon whomever He wills; and towards Him only you are to return.

# 3362

Neither can you escape (from His control) in the earth nor in the sky; and for you, other than Allah, there is neither a friend nor a supporter.

# 3363

And those who did not believe in My signs and in meeting Me, are those who have no hope of My mercy, and for them is a painful punishment.

# 3364

So his people could not answer him except to say, “Kill him or burn him” – so Allah rescued him from the fire; indeed in this are signs for people who believe.

# 3365

And Ibrahim said, “You have chosen only idols instead of Allah, with whom your friendship is only in the life of this world; then on the Day of Resurrection you will deny and curse each other; and the destination for all of you is hell, and you do not have supporters.”

# 3366

So Lut believed in him; and Ibrahim said, “I migrate towards my Lord; indeed only He is the Almighty, the Wise.”

# 3367

And We bestowed Ishaq and Yaqub to him, and kept the Prophethood and the Book among his descendants, and We gave him his reward in the world; and in the Hereafter he is indeed among those who deserve Our proximity.

# 3368

And We rescued Lut when he said to his people, “You indeed commit the shameful; such that no one in the creation has ever done before you.”

# 3369

“What! You commit the immoral with males, and cut off the roads; and you speak evilly in your gatherings?” So his people had no answer except to say, “Bring the punishment of Allah upon us if you are truthful!”

# 3370

He submitted, “My Lord! Help me against these mischievous people.”

# 3371

And when Our sent angels came with glad tidings to Ibrahim, they said, “We will surely destroy the people of that town; indeed its inhabitants are unjust.”

# 3372

He said, "Lut is in it!”; they said, “We know very well who all are there; we shall rescue him and his family, except his wife; she is of those who will stay behind.”

# 3373

And when Our sent angels came to Lut, he was unhappy at their arrival and was depressed – and they said, “Do not fear or grieve; we will surely rescue you and your family, except your wife, who is of those who will stay behind.”

# 3374

“We will indeed cause a punishment from the sky to descend upon the inhabitants of this town – the recompense of their disobedience.”

# 3375

And We have undoubtedly kept a part of it as a clear sign for people of intellect.

# 3376

And We sent towards Madyan, their fellowman Shuaib – he therefore said, “O my people! Worship Allah, and anticipate the Last Day, and do not roam the earth spreading turmoil.”

# 3377

In response they denied him – thereupon the earthquake seized them – so at morning they remained lying flattened in their homes.

# 3378

And We destroyed the A’ad and the Thamud, and you already know their dwellings; Satan made their deeds appear good to them and prevented them from the path, whereas they could perceive.

# 3379

And (We destroyed) Qaroon, Firaun and Haman; and indeed Moosa came to them with clear signs, so they were arrogant in the land, and they could never escape from Our control.

# 3380

So We caught each one upon his sin; so among them is one upon whom We sent a shower of stones; and among them is one who was seized by the Scream; and among them is one whom We buried in the earth, and among them is one whom We drowned; it did not befit Allah’s Majesty to oppress them, but they were wronging themselves.

# 3381

The example of those who choose masters other than Allah is like that of the spider; it makes the web its house; and indeed the weakest house of all is that of the spider; if only they knew.

# 3382

Allah knows what they worship instead of Him; He is the Almighty, the Wise.

# 3383

And We illustrate these examples for mankind; and none except the knowledgeable understand them.

# 3384

Allah created the heavens and the earth with the truth; indeed in this is a sign for the Muslims.

# 3385

O dear Prophet (Mohammed – peace and blessings be upon him), recite from the Book which has been sent down to you, and establish the prayer; indeed the prayer stops from indecency and evil; and indeed the remembrance of Allah is the greatest; and Allah knows all what you do.

# 3386

And O Muslims, do not argue with the People given the Book(s) except in the best manner – except (with) those among them who oppress, and say, “We believe in what has been sent down towards us and what has been sent towards you – and ours and your God is One, and we have submitted ourselves to Him.”

# 3387

And this is how We sent down the Book to you O dear Prophet (Mohammed – peace and blessings be upon him); so those to whom We gave the Book believe in it; and some of these (polytheists) accept faith in it; and none except the disbelievers reject Our signs.

# 3388

And you (O dear Prophet Mohammed – peace and blessings be upon him) were not reading any Book before it, nor writing with your right hand – if it were, the people of falsehood would surely have doubted.

# 3389

In fact they are clear verses in the hearts of those who have been given knowledge; and none deny Our verses except the unjust.

# 3390

And they said, “Why did not signs come down to him from his Lord?” Say, “Signs are only with Allah; and I am purely a Herald of plain warning.”

# 3391

Is it not enough for them that We have sent down the Book upon you, which is read to them? Indeed in it are mercy and advice for the Muslims.

# 3392

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Allah is Sufficient as a Witness between me and you; He knows all what is in the heavens and in the earth; and those who accepted faith in falsehood and denied faith in Allah – it is they who are the losers.”

# 3393

And they urge you to hasten the punishment; and if a time had not been fixed, the punishment would have certainly come upon them; and it will indeed come upon them suddenly whilst they are unaware.

# 3394

They urge you to hasten the punishment; and indeed hell has encompassed the disbelievers.

# 3395

The day when the punishment will envelop them from above them and from below their feet, and He will say, “Taste the flavour of your deeds!”

# 3396

O My bondmen who believe! Indeed My earth is spacious – therefore worship Me alone.

# 3397

Every soul must taste death; then it is to Us that you will return.

# 3398

And those who believed and did good deeds – indeed We will, surely, place them on high positions in Paradise beneath which rivers flow, abiding in it for ever; what an excellent reward of the performers!

# 3399

Those who patiently endured and who rely only upon their Lord.

# 3400

And many creatures walk upon the earth that do not carry their own sustenance; Allah provides the sustenance to them and to you; and only He is the All Hearing, the All Knowing.

# 3401

And if you ask them, “Who created the heavens and the earth, and subjected the sun and the moon?”, they will surely say, “Allah”; so where are they reverting?

# 3402

Allah eases the sustenance for whomever He wills among His bondmen, and restricts it for whomever He wills; indeed Allah knows all things.

# 3403

And if you ask them, “Who sent down the water from the sky, and with it revived the earth after its death?”, they will surely say, “Allah”; proclaim, “All praise is to Allah”; in fact most of them do not have any sense.

# 3404

And this worldly life is nothing but pastime and game; indeed the abode of the Hereafter – that is indeed the true life; if only they knew.

# 3405

And when they board the ships they pray to Allah, believing purely in Him; so when He delivers them safely to land, they immediately begin ascribing partners (to Him)!

# 3406

In order to be ungrateful for Our favours; and to use the comforts; therefore they will soon come to know.

# 3407

Did they not observe that We have created a refuge in the Sacred Land, and people around them are snatched away? So do they believe in falsehood and are ungrateful for the favours of Allah?

# 3408

And who is more unjust than one who fabricates lies against Allah, or denies the truth\* when it comes to him? Is there not a place in hell for disbelievers? (\* The Holy Prophet and / or the Holy Qur’an).

# 3409

And those who strove in Our way – We shall surely show them Our paths; and indeed Allah is with the virtuous.

# 3410

Alif-Laam-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 3411

The Romans have been defeated.

# 3412

In the nearby land, and after their defeat they will soon be victorious.

# 3413

Within a few (up to nine) years time; only for Allah is the command, before and after; and the believers will rejoice on that day.

# 3414

With the help of Allah; He helps whomever He wills; and only He is the Almighty, the Most Merciful.

# 3415

The promise of Allah; Allah does not renege on His promise, but most people do not know.

# 3416

They know only the visible worldly life; and are totally neglectful of the Hereafter.

# 3417

Have they not inwardly pondered – that Allah has not created the heavens and the earth, and all that is between them, except with truth and a fixed term? And indeed many people deny the meeting with their Lord.

# 3418

And did they not travel in the land to see what sort of fate befell those before them? They were stronger than them, and they cultivated the land and inhabited it more than them, and their Noble Messengers came to them with clear proofs; so it did not befit Allah’s Majesty to oppress them, but it was they who used to wrong themselves.

# 3419

Then the fate of those who committed evil to the extreme was that they denied the signs of Allah and used to mock at them.

# 3420

Allah initiates the creation, then will create it again – then it is to Him that you will return.

# 3421

And on the Last Day– when it is established, the guilty\* will lose all hope. (\* The disbelievers.)

# 3422

And the partners they ascribed will not be their intercessors – and they will deny their partners.

# 3423

And on the Last Day – that day they will all separate.

# 3424

So those who believed and did good deeds – they will be hosted in the Garden.

# 3425

And those who disbelieved, and denied Our signs and confronting the Hereafter – they will be hauled into the punishment.

# 3426

So proclaim the Purity of Allah when you witness the night and the morning.

# 3427

And only His is the praise in the heavens and the earth – and before the day ends and at noon.

# 3428

He brings forth the living from the dead, and brings forth the dead from the living, and He revives the earth after its death; and this how you will be raised.

# 3429

And among His signs is that He created you from dust, and therefore you are human beings spread in the earth.

# 3430

And among His signs is that He created spouses for you from yourselves for you to gain rest from them, and kept love and mercy between yourselves; indeed in this are signs for the people who ponder.

# 3431

And among His signs is the creation of the heavens and the earth, and the differences in your languages and colours; indeed in this are signs for people who know.

# 3432

And among His signs is your sleeping during the night and day, and your seeking His munificence; indeed in this are signs for people who heed.

# 3433

And among His signs is that He shows you the lightning, instilling fear and hope, and sends down water from the sky, so revives the earth after its death; indeed in this are signs for people of intellect.

# 3434

And among His signs is that the heavens and the earth remain established by His command; then when He calls you – from the earth – you will thereupon emerge.

# 3435

And to Him only belong all those who are in the heavens and the earth; all are submissive to Him.

# 3436

And it is He Who initiates the creation, and will then create it again – and this, according to you, should be easier for Him! And for Him only is the Supreme Majesty in the heavens and the earth; and only He is the Almighty, the Wise.

# 3437

He illustrates an example for you from your own selves; do you have for yourselves, among the bondmen you possess, partners in the sustenance We have bestowed upon you, thereby you become equal in respect of it – you fearing them the way you fear each other? This is how We illustrate detailed signs for the people of intellect.

# 3438

Rather the unjust followed their own desires, without knowledge; so who can guide one whom Allah has sent astray? And they do not have supporters.

# 3439

Therefore set your attention for obeying Allah, devoted solely to Him; the foundation set by Allah, upon which He created man; do not change what Allah has created; this is the proper religion – but most people do not know.

# 3440

Inclining towards Him – and fear Him, and keep the prayer established, and never be of the polytheists.

# 3441

Those who broke their religion into several parts and became different groups; every group is happy with what it has.

# 3442

And when some affliction reaches men, they pray to their Lord inclining towards Him – and when He gives them a taste of His mercy, thereupon a group among them begins setting up partners to their Lord!

# 3443

In order to be ungrateful for Our bestowal; “Therefore enjoy”; you will soon come to know.

# 3444

Or have We sent down to them any proof, which therefore tells them of My partners?

# 3445

And when We give people the taste of mercy they rejoice at it; and if an ill fortune reaches them because of what their hands have sent ahead – thereupon they lose hope!

# 3446

And did they not see that Allah eases the sustenance for whomever He wills and restricts it for whomever He wills? Indeed in this are signs for people who believe.

# 3447

Therefore give the relative his right, and to the needy, and to the traveller; this is better for those who seek the pleasure of Allah; and it is they who are the successful.

# 3448

And that which you give upon usury, in order that it may increase the creditors’ property, will not increase before Allah; and the charity you give seeking the pleasure of Allah – only that will increase manifold.

# 3449

It is Allah Who created you and then provided you sustenance, then will cause you to die, and will then give you life again; is there any among your ascribed partners that can do any of these things? Purity and Supremacy are to Him, above their ascribing of partners (to Him)!

# 3450

Chaos appears in the land and the sea because of the evil deeds which people’s hands have earned, in order to make them taste the flavour of some of their misdeeds – in order that they may come back.

# 3451

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Travel in the land, and see what sort of fate befell the former people; and most of them were polytheists.”

# 3452

Therefore set your attention for worshipping, before the day from Allah which cannot be averted – on that day people will be split, separated.

# 3453

Whoever disbelieves, then the calamity of his disbelief is only on him; and those who do good deeds, are preparing for themselves.

# 3454

In order to reward those who believed and did good deeds, by His munificence; indeed He does not like the disbelievers.

# 3455

And among His signs is that He sends winds heralding glad tidings, to make you taste His mercy, and so that the ships may sail by His command, and so that you may seek His munificence, and for you to give thanks.

# 3456

And indeed We sent several Noble Messengers before you, to their nations – so they came to them with clear signs – We therefore took revenge from the guilty; and it is incumbent upon Our mercy, to help the Muslims.

# 3457

It is Allah Who sends the winds raising the clouds – therefore spreads them in the sky as He wills and shatters them – so you see the rain dropping from inside it; so when He delivers it upon whomever He wills among His bondmen, thereupon they rejoice.

# 3458

Although they had lost hope before it was sent down upon them.

# 3459

Therefore observe the result of Allah’s mercy, how He revives the earth after its death; He will indeed resurrect the dead; and He is Able to do all things.

# 3460

And if We send a wind and they see their fields yellow because of it, then indeed they would become ungrateful after it.

# 3461

For you do not make the dead hear nor make the deaf hear the call when they flee, turning back. (The disbelievers are referred to as dead and deaf.)

# 3462

Nor do you guide the blind out of their error; you only make those hear who believe in Our signs, so they have submitted. (The disbelievers are referred to as blind.)

# 3463

It is Allah Who created you weak, then after weakness gave you strength, then after strength gave you weakness and old age; He creates whatever He wills; and only He is the All Knowing, the Able.

# 3464

And on the day when the Last Day is established, the guilty will swear that they did not stay except for an hour; this is how they keep straying.

# 3465

And said those who received knowledge and faith, “You have indeed stayed in the decree of Allah until the Day of Restoration; so this is the Day of Restoration, but you did not know.”

# 3466

So on that day the unjust will not benefit from their excuses, nor will anyone ask them for compensation.

# 3467

And indeed We have illustrated all kinds of examples in this Qur’an for mankind; and indeed if you bring a sign to them, the disbelievers will say, “You are upon nothing but falsehood.”

# 3468

This is how Allah sets seal upon the hearts of the ignorant.

# 3469

Therefore patiently endure, indeed the promise of Allah is true; and may not those who do not have faith make you impatient.

# 3470

Alif-Lam-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 3471

These are verses of the wise Book.

# 3472

Guidance and mercy for the righteous.

# 3473

Those who keep the prayer established and pay the charity and accept faith in the Hereafter.

# 3474

It is they who are on guidance from their Lord, and only they are the successful.

# 3475

And some people buy words of play, in order to mislead from Allah’s path, without knowledge; and to make it an article of mockery; for them is a disgraceful punishment.

# 3476

And when Our verses are recited to him he haughtily turns away as if he did not hear them – as if there is deafness in his ears; so give him the glad tidings of a painful punishment.

# 3477

Indeed those who believed and did good deeds – for them are Gardens of serenity.

# 3478

In which they will abide; it is a true promise of Allah; and only He is the Almighty, the Wise.

# 3479

He created the heavens without any supports visible to you, and cast mountains as anchors into the earth so that it may not shake with you, and spread all kinds of beasts in it; and We sent down water from the sky so thereby grew all kinds of refined pairs in it.

# 3480

Allah has created this – therefore show me what has been created by those other than Him; in fact the unjust are in open error.

# 3481

And indeed We bestowed wisdom to Luqman (saying) that, “Be grateful to Allah”; and whoever is grateful, is grateful for his own good; and whoever is ungrateful – then indeed Allah is the Absolute, the Most Praiseworthy.

# 3482

And remember when Luqman said to his son, and he used to advise him, “O my son! Never ascribe anything as a partner to Allah; indeed ascribing partners to Him is a tremendous injustice.”

# 3483

And We ordained upon man concerning his parents; his mother bore him enduring weakness upon weakness, and his suckling is up to two years – therefore be thankful to Me and to your parents; finally towards Me is the return.

# 3484

And if they force you, that you ascribe a partner to Me a thing concerning which you do not have knowledge – so do not obey them and support them well in the world; and follow the path of one who has inclined towards Me; then towards Me only is your return, and I shall tell you what you used to do.

# 3485

“O my son! If the evil deed is equal to the weight of a mustard-seed, and even if it is in a rock, or in the heavens, or wherever in the earth, Allah will bring it forth; indeed Allah knows all the minutest things, the All Aware.”

# 3486

“O my son! Keep the prayer established, and enjoin goodness and forbid from evil, and be patient upon the calamity that befalls you; indeed these are acts of great courage.”

# 3487

“And do not contort your cheek while talking to anyone, nor boastfully walk upon the earth; indeed Allah does not like any boastful, haughty person.”

# 3488

“And walk moderately and soften your voice; indeed the worst voice is the voice of the donkey.”

# 3489

Did you not see that Allah has made all whatever is in the heavens and all whatever is in the earth, subservient for you and bestowed His favours upon you in full, both visible and hidden? And some men argue regarding Allah, with neither knowledge, nor guidance, nor a clear Book!

# 3490

And when it is said to them, “Follow what Allah has sent down”, they say, “On the contrary, we shall only follow that upon which we found our forefathers”; even if the devil was calling them to the punishment of hell?

# 3491

Whoever submits his face to Allah and is righteous – so he has indeed grasped the firm knot; and towards Allah only is the culmination of all things.

# 3492

And whoever disbelieves – then do not be aggrieved by his disbelief (O dear Prophet Mohammed – peace and blessings be upon him); they have to return to Us, and We will inform them what they were doing; indeed Allah knows what lies within the hearts.

# 3493

We shall give them some usage, then making them helpless take them towards a severe punishment.

# 3494

And if you ask them, “Who created the heavens and the earth?” – they will surely answer, “Allah”; proclaim, “All Praise is to Allah”; in fact most of them do not know.

# 3495

To Allah only belongs whatsoever is in the heavens and in the earth; indeed Allah only is the Absolute, the Most Praiseworthy.

# 3496

And if all the trees in the earth were pens, and the seas were its ink, with seven more seas to back it up – the Words of Allah will not finish; indeed Allah is Almighty, Wise.

# 3497

Creating you all and raising you from the dead are like that of one soul\*; indeed Allah is All Hearing, All Knowing. (He can create you slowly or all at once).

# 3498

O listener, did you not see that Allah brings the night in a part of the day and brings the day in a part of the night, and that He has subjected the sun and the moon – each one runs for its fixed term – and that Allah is Well Aware of your deeds?

# 3499

This is because only Allah is the Truth, and all that they worship besides Him are falsehood, and because only Allah is the Supreme, the Great.

# 3500

Did you not see that the ship sails on the sea by Allah’s grace, so that He may show you some of His signs? Indeed in this are signs for every greatly enduring, grateful person.

# 3501

And if a wave comes upon them like mountains, they pray to Allah believing purely in Him; then when He brings them safely to land, some of them remain upon justice; and none will deny Our signs except an extremely unfaithful, ungrateful person.

# 3502

O mankind! Fear your Lord, and fear the Day in which no father will benefit his child; nor will any good child be of any benefit to the father; indeed Allah’s promise is true; so never may the worldly life deceive you; and never may the great cheat deceive you in respect of Allah’s commands.

# 3503

Indeed Allah has the knowledge of the Last Day! And He sends down the rain; and He knows all what is in the mothers’ wombs; and no soul knows what it will earn tomorrow; and no soul knows the place where it will die; indeed Allah is the All Knowing, the Informer. (He may reveal the knowledge to whomever He wills.)

# 3504

Alif-Lam-Meem. (Alphabets of the Arabic language – Allah and to whomever He reveals, know their precise meanings.)

# 3505

The revelation of the Book is, without doubt, from the Lord Of The Creation.

# 3506

What! They dare say that, “He has fabricated it”? In fact it is the Truth from your Lord, in order that you warn a nation towards whom no Herald of Warning came before you, in the hope of their attaining guidance.

# 3507

It is Allah Who created the heavens and the earth, and all what is between them, in six days, then (befitting His Majesty) established Himself over the Throne (of control); leaving Allah, there is neither a friend nor an intercessor for you; so do you not ponder?

# 3508

He plans (all) the job(s) from the heaven to the earth – then it will return to Him on the Day which amounts to a thousand years in your count.

# 3509

This is the All Knowing – of all the hidden and the visible, the Most Honourable, the Most Merciful.

# 3510

The One Who created all things excellent, and Who initiated the creation of man from clay.

# 3511

Then kept his posterity with a part of an abject fluid.

# 3512

Then made him proper and blew into him a spirit from Him, and bestowed ears and eyes and hearts to you; very little thanks do you offer!

# 3513

And they said, “When we have mingled into the earth, will we be created again?”; in fact they disbelieve in the meeting with their Lord.

# 3514

Proclaim, “The angel of death, who is appointed over you, causes you to die and then towards your Lord you will return.”

# 3515

And if you see when the guilty will hang their heads before their Lord; “Our Lord! We have seen and heard, therefore send us back in order that we do good deeds – we are now convinced!”

# 3516

And had We willed We would have given every soul its guidance, but My Word is decreed that I will certainly fill hell with these jinns and men, combined.

# 3517

“Therefore taste the recompense of your forgetting the confronting of this day of yours; We have abandoned you – now taste the everlasting punishment, the recompense of your deeds!”

# 3518

Only those believe in Our signs who, when they are reminded of them, fall down in prostration and proclaim the Purity of their Lord while praising Him, and are not conceited. (Command of prostration # 9).

# 3519

Their sides stay detached from their beds and they pray to their Lord with fear and hope – and they spend from what We have bestowed upon them.

# 3520

So no soul knows the comfort of the eyes that is kept hidden for them\*; the reward of their deeds. (Paradise)

# 3521

So will the believer ever be equal to the one who is lawless? They are not equal!

# 3522

Those who accepted faith and did good deeds – for them are the Gardens of (everlasting) stay; a welcome in return for what they did.

# 3523

And those who are lawless – their destination is the fire; whenever they wish to come out of it, they will be returned into it, and it will be said to them, “Taste the punishment of the fire you used to deny!”

# 3524

And We shall indeed make them taste the smaller punishment before the greater punishment, so that they may return.

# 3525

And who is more unjust than one who is preached to from the verses his Lord, then he turns away from them? We will indeed take revenge from the guilty.

# 3526

And indeed We bestowed the Book to Moosa, therefore have no doubt in its acquisition, and made it a guidance for the Descendants of Israel.

# 3527

And We made some leaders among them, guiding by Our command, when they had persevered; and they used to accept faith in Our signs.

# 3528

Indeed your Lord will judge between them on the Day of Resurrection concerning the matters in which they used to differ.

# 3529

And did they not obtain guidance by the fact that We did destroy many generations before them, so now they walk in their houses? Indeed in this are signs; so do they not heed?

# 3530

And do they not see that We send the water to the barren land and produce crops with it, so their animals and they themselves eat from it? So do they not perceive?

# 3531

And they say, “When will this decision take place, if you are truthful?”

# 3532

Proclaim, “On the Day of Decision\*, the disbelievers will not benefit from their accepting faith, nor will they get respite.” (\* Of death or of resurrection)

# 3533

Therefore turn away from them and wait – indeed they too have to wait.

# 3534

O Herald of the Hidden (the Prophet), continue to fear Allah and never listen to the disbelievers and the hypocrites; indeed Allah is All Knowing, Wise.

# 3535

And keep following what is sent down to you from your Lord; O people! Indeed Allah is seeing your deeds.

# 3536

And trust Allah; and Allah is Sufficient as a Trustee.

# 3537

Allah has not kept two hearts in the body of any man; nor has He made them your mothers those wives of yours, whom you declare to be your mothers; nor has He made them your sons, whom you have adopted; this is the statement of your mouths; and Allah proclaims the truth and it is He Who shows the path.

# 3538

Call them with their fathers’ names – this is more suitable in the sight of Allah; and if you do not know their fathers, then they are your brothers in the faith, (and your cousins as humans) and your friends; and there is no sin upon you for what you did unknowingly in the past – however it is a sin what you do with your heart’s intention; and Allah is Oft Forgiving, Most Merciful.

# 3539

The Prophet is closer to the Muslims than their own lives, and his wives are their mothers; and the relatives are closer to each other in the Book of Allah, than other Muslims and immigrants, except that you may be kind towards your friends; this is written in the Book.

# 3540

And remember O dear Prophet (Mohammed – peace and blessings be upon him) when We took a covenant from the Prophets – and from you – and from Nooh, and Ibrahim, and Moosa, and Eisa the son of Maryam; and We took a firm covenant from them.

# 3541

So that He may question the truthful regarding their truth; and He has kept prepared a painful punishment for the disbelievers.

# 3542

O People who believe! Remember the favour of Allah upon you when some armies came against you, so We sent against them a windstorm and the armies you could not see; and Allah sees your deeds.

# 3543

When the disbelievers came upon you from above you and from below you, and when the eyes became fixed in stare and the hearts came up to the throats, and you were imagining matters regarding Allah.

# 3544

That proved be the testing ground for the Muslims, and they were subjected to a severe shake.

# 3545

And when the hypocrites, and those in whose hearts is a disease, began saying, “Allah and His Noble Messenger have not given us a promise except one of deceit.”

# 3546

And when a group among said, “O people of Medinah! This is no place of stay for you, therefore go back to your homes”; and a group among them sought exemption from the Prophet by saying, “Our homes are unprotected” whereas their homes were not unprotected; they willed nothing except to flee.

# 3547

And if the armies had come upon them from the outskirts of Medinah and demanded disbelief from them, they would certainly have given them their demand and would not have hesitated in it except a little.

# 3548

And indeed before this they had agreed with Allah that they would not turn their backs; and the covenant of Allah will be questioned about.

# 3549

Proclaim, “Fleeing will never benefit you if you flee from death or killing, and even then you will not be given the usage of this world except a little.”

# 3550

Say, “Who is he who can avert the command of Allah from you, if He wills harm for you or wills to have mercy upon you?” And other than Allah, they will not find any friend or supporter.

# 3551

Indeed Allah knows those among you who prevent others from the holy war, and those who say to their brothers, “Come towards us”; and they do not come to fight, except a few.

# 3552

They reduce the help towards you; so when a fearful time comes, you will observe them looking at you with eyes rolling like one enveloped by death; then when the time of fear is over, they begin slandering you with sharp tongues in their greed for the war booty; they have not accepted faith, therefore Allah has nullified their deeds; and this is easy for Allah.

# 3553

They assume that the armies of the disbelievers have not gone away; and were the armies to come again, their wish would be to go out to the villages seeking information about you; and were they to stay among you even then they would not fight, except a few.

# 3554

Indeed following the Noble Messenger of Allah is better for you – for one who is confident of Allah and the Last Day, and remembers Allah much.

# 3555

And when the Muslims saw the armies, they said, “This is what Allah and His Noble Messenger promised us, and Allah and His Noble Messenger have spoken the truth”; and it did not increase anything for them but faith and acceptance of Allah’s will.

# 3556

Among the Muslims are the men who have proved true what they had covenanted with Allah; so among them is one who has already fulfilled his vow, and among them is one still waiting; and they have not changed a bit.

# 3557

In order that Allah may reward the truthful for their truthfulness, and punish the hypocrites if He wills, or give them repentance; indeed Allah is Oft Forgiving, Most Merciful.

# 3558

And Allah turned back the disbelievers in their hearts’ jealousy, gaining no good; and Allah sufficed the Muslims in their fight; and Allah is Almighty, Most Honourable.

# 3559

And He brought down from their forts, the People given the Book(s) who had supported them, and instilled awe into their hearts – you slay a group among them and another group you make captive.

# 3560

And He bequeathed you their lands and their houses and their wealth, and land that you have not yet set foot upon; and Allah is Able to do all things.

# 3561

O Herald of the Hidden! Say to your wives, “If you desire the worldly life and its adornment – therefore come, I shall give you wealth and a befitting release!”

# 3562

“And if you desire Allah and His Noble Messenger and the abode of the Hereafter – then indeed Allah has kept prepared an immense reward for the virtuous among you.”

# 3563

O the wives of the Prophet! If any among you dares to commit an act contrary to decency, for her will be double the punishment of others; and this is easy for Allah.

# 3564

And whoever among you remains obedient towards Allah and His Noble Messenger and does good deeds – We shall give her double the reward of others, and have kept prepared for her an honourable sustenance.

# 3565

O the wives of the Prophet! You are not like any other women – if you really fear Allah, do not speak softly lest the one in whose heart is a disease have any inclination, and speak fairly.

# 3566

And remain in your houses and do not unveil yourselves like the unveiling prevalent in the times of ignorance, and keep the prayer established, and pay the charity, and obey Allah and His Noble Messenger; Allah only wills to remove all impurity from you, O the People of the Household, and by cleansing you make you utterly pure. (\*The Holy Prophet’s household.)

# 3567

And remember what is recited in your houses, from Allah’s verses and wisdom\*; indeed Allah knows the minutest things, is All Aware. (The Holy Qur’an and the sayings- hadith – of the Holy Prophet.)

# 3568

Indeed the Muslim men and Muslim women, and the believing men and the believing women, and the men who obey and the women who obey, and the truthful men and the truthful women, and the patient men and the patient women, and the humble men and the humble women, and charitable men and the charitable women, and the fasting men and the fasting women, and the men who guard their chastity and the women who guard their chastity, and the men who profusely remember Allah and the women who profusely remember Allah – for all of them, Allah has kept prepared forgiveness and an immense reward.

# 3569

And no Muslim man or woman has any right in the affair, when Allah and His Noble Messenger have decreed a command regarding it; and whoever does not obey the command of Allah and His Noble Messenger, has indeed clearly gone very astray.

# 3570

And O dear Prophet, remember when you said to him upon whom Allah has bestowed favour and you had bestowed favour, “Keep your wife with you, and fear Allah”, and you kept in your heart what Allah willed to make known, and you feared criticism from the people; and Allah has more right that you should fear Him; so when Zaid became unconcerned with her, We gave her to you in marriage, so that there may be no sin upon believers in respect of the wives of their adopted sons when they have become unconcerned with them; and the command of Allah must be carried out.

# 3571

There is no blame upon the Prophet regarding the matter that Allah has decreed for him; it has been Allah’s tradition in those who passed before; and the command of Allah is a certain destiny.

# 3572

Those who deliver the messages of Allah and fear Him, and do not fear anyone except Allah; and Allah is Sufficient to take account.

# 3573

Mohammed (peace and blessings be upon him) is not the father of any man among you – but he is the Noble Messenger of Allah and the Last of the Prophets\*; and Allah knows all things. (\* Prophet Mohammed – peace and blessings be upon him – is the Last Prophet. There can be no new Prophet after him).

# 3574

O People who Believe! Remember Allah profusely.

# 3575

And proclaim His Purity, morning and evening.

# 3576

It is He Who sends blessings upon you\*, and so do His angels, so that He may bring you out from darkness into light; and He is Most Merciful upon the Muslims. (\* Upon the companions of the Holy Prophet).

# 3577

For them the salutation upon their meeting\* is “Peace”; and an honourable reward is kept prepared for them. (\* Upon death / while entering Paradise / meeting with Allah).

# 3578

O Herald of the Hidden! We have indeed sent you as an observing present witness and a Herald of glad tidings and warning.

# 3579

And as a caller towards Allah, by His command, and as a sun that enlightens. (The Holy Prophet is a light from Allah.)

# 3580

And give glad tidings to the believers that for them is Allah’s extreme munificence.

# 3581

And do not please the disbelievers and the hypocrites, and overlook the pain they cause and rely upon Allah; and Allah suffices as a Trustee.

# 3582

O People who Believe! If you marry Muslim women and divorce them without having touched them, so for you there is no waiting period for the women, which you may count; therefore give them some benefit and release them with a proper release.

# 3583

O Herald of the Hidden! We have indeed made lawful for you the wives to whom you have paid their bridal money, and the bondwomen you possess whom Allah gave you as war booty, and the daughters of your paternal uncles, and the daughters of your paternal aunts, and the daughters of your maternal uncles, and the daughters of your maternal aunts, those who migrated with you; and the believing woman if she gifts her life to the Prophet, if the Prophet desires to take her in marriage; this is exclusively for you, not for your followers; We indeed know what We have enjoined upon the Muslims concerning their wives and the bondwomen they possess – this exclusivity for you is so that you may not have constraints; and Allah is Oft Forgiving, Most Merciful.

# 3584

Put back in the order whom you wish among them and give your proximity to whomever you wish; and if you incline towards one whom you had set aside, there is no sin upon you in it; this command is closer to their eyes remaining soothed and not grieving, and all of them remaining happy with whatever you give them; and Allah knows what is in the hearts of you all; and Allah is All Knowing, Most Forbearing.

# 3585

Other women are not permitted for you after these, nor that you change them for other wives even if their beauty pleases you except the bondwomen whom you possess; and Allah is the Guardian over all things.

# 3586

O People who Believe! Do not enter the houses of the Prophet without permission, as when called for a meal but not to linger around waiting for it – and if you are invited then certainly present yourself and when you have eaten, disperse – not staying around delighting in conversation; indeed that was causing harassment to the Prophet, and he was having regard for you; and Allah does not shy in proclaiming the truth; and when you ask the wives of the Prophet for anything to use, ask for it from behind a curtain; this is purer for your hearts and for their hearts; and you have no right to trouble the Noble Messenger of Allah, nor ever marry any of his wives after him; indeed that is a very severe matter in the sight of Allah. (To honour the Holy Prophet – peace and blessings be upon him – is part of faith. To disrespect him is blasphemy.)

# 3587

Whether you disclose a thing or keep it hidden – then indeed Allah knows all things.

# 3588

There is no sin upon your wives in (dealing with) their fathers, or their sons, or their brothers, or their brothers’ sons, or their sisters’ sons or women of their own religion, or their bondwomen; and O women, keep fearing Allah; indeed all things are present in front of Allah.

# 3589

Indeed Allah and His angels send blessings on the Prophet; O People who Believe! Send blessings and abundant salutations upon him. (Everlasting peace and unlimited blessings be upon the Holy Prophet Mohammed.)

# 3590

Indeed those who trouble Allah and His Noble Messenger – upon them is Allah’s curse in the world and in the Hereafter, and Allah has kept prepared a disgraceful punishment for them. (To disrespect / trouble the Holy Prophet – peace and blessings be upon him – is blasphemy.)

# 3591

And those who unnecessarily harass Muslim men and women, have burdened themselves with slander and open sin.

# 3592

O Prophet! Command your wives and your daughters and the women of the Muslims to cover their faces with a part of their cloaks; this is closer to their being recognised and not being harassed; and Allah is Oft Forgiving, Most Merciful. (It is incumbent upon women to cover themselves properly.)

# 3593

If the hypocrites, and those in whose hearts is a disease, and the rumour mongers in Medinah do not desist, We shall then surely impel you against them, so then they will not remain your neighbours in Medinah except for a few days.

# 3594

Accursed – to be caught wherever found and to be slain thoroughly.

# 3595

The tradition of Allah prevalent among those who passed away before; and you will never find the traditions of Allah changing.

# 3596

People ask you regarding the Last Day; proclaim, “Its knowledge is only with Allah; and what do you know, the Last Day may really be near!”

# 3597

Allah has indeed cursed the disbelievers, and has kept prepared for them a blazing fire.

# 3598

In which they will remain forever; in it they will find neither a protector nor any supporter.

# 3599

On the day when their faces will be overturned being roasted inside the fire, they will say, “Alas – if only we had obeyed Allah and obeyed His Noble Messenger!”

# 3600

And they will say, “Our Lord! We followed our chiefs and our elders – so they misled us from the path!”

# 3601

“Our Lord! Give them double the punishment of the fire and send upon them a mighty curse!”

# 3602

O People who Believe! Do not be like the people who troubled Moosa – so Allah freed him from the allegations they had uttered; and Moosa is honourable in the sight of Allah.

# 3603

O People who Believe! Fear Allah, and speak rightly.

# 3604

He will rectify your deeds for you and forgive you your sins; and whoever obeys Allah and His Noble Messenger, has indeed achieved a great success.

# 3605

We indeed offered the trust to the heavens and the earth and the mountains, but they refused it and were afraid of it – and man accepted it; indeed he is one who puts himself into hardship, is extremely unwise.

# 3606

In order that Allah may punish the hypocrite men, and the hypocrite women, and the polytheist men, and the polytheist women – and accept the repentance of believing men and believing women; and Allah is Oft Forgiving, Most Merciful.

# 3607

All praise is to Allah – to Him only belongs all whatever is in the heavens and all whatever is in the earth – and His is the praise in the Hereafter; and He is the Wise, the All Aware.

# 3608

He knows all that goes into the earth and all that comes out of it, and all that descends from the skies and all that ascends into it; and only He is the Most Merciful, the Oft Forgiving.

# 3609

And the disbelievers said, “The Last Day will never come upon us”; proclaim, “Surely yes, why not? By oath of my Lord, it will surely come upon you – the All Knowing of the hidden; nothing is hidden from Him – equal to an atom or less than it or greater – in the heavens or in the earth, but it is in a clear Book.”

# 3610

So that He may reward those who believed and did good deeds; it is these for whom is forgiveness, and an honourable sustenance.

# 3611

And those who strove in Our signs in order to defeat – for them is a punishment from the severe painful punishments.

# 3612

And those who received the knowledge know that what is sent down upon you from your Lord is the truth, and it shows the path of the Most Honourable, the Most Praiseworthy.

# 3613

And the disbelievers said, “Shall we show you a man who will tell you that ‘When you have disintegrated into the smallest pieces, you are to be created again’?”

# 3614

“Has he fabricated a lie against Allah, or is he insane?” Rather those who disbelieve in the Hereafter are in the punishment and extreme error.

# 3615

So did they not see what is before them and what is behind them in the sky and the earth? If We will, We can bury them into the earth or cause a part of the sky to fall on them; indeed in this is a sign for every repentant bondman.

# 3616

And indeed We gave Dawud the utmost excellence from Us; “O the hills and birds, repent towards Allah along with him”; and We made iron soft for him.

# 3617

“Make large coats of armour and keep proper measure while making; and all of you perform good deeds; I am indeed seeing your deeds.”

# 3618

And We gave the wind in Sulaiman’s control – its morning journey equal to a month’s course and the evening journey equal to a month’s course; and We sprung a stream of molten copper for him; and from the jinns, who worked before him by the command of his Lord; and those among them who turned away from Our command – We shall make them taste the punishment of the blazing fire.

# 3619

They made for him whatever he wished – synagogues and statues, basins like ponds, and large pots built into the ground; “Be thankful, O the people of Dawud!” And few among My bondmen are grateful.

# 3620

So when We sent the command of death towards him, no one revealed his death to the jinns except the termite of the earth which ate his staff; and when he came to the ground, the truth about the jinns was exposed – if they had known the hidden, they would not have remained in the disgraceful toil.

# 3621

Indeed for (the tribe of) Saba was a sign in their dwelling-place – two gardens on the right and the left; “Eat the sustenance provided by your Lord and be grateful to Him”; a pure land and an Oft Forgiving Lord!

# 3622

In response they turned away – We therefore sent upon them a tremendous flood, and in exchange of their two gardens gave them two gardens bearing bitter fruit, and tamarisk, and some berries.

# 3623

We gave them this reward – the recompense of their ingratitude; and whom do We punish, except the ungrateful?

# 3624

And We had made several towns upon the road between them and the towns which We had blessed – and kept them according to the length of the journey; “Travel safely in them, by night and by day.”

# 3625

So they said, “Our Lord! Make the stage between our journeys longer” and they wronged themselves – We therefore turned them into fables and scattered them completely with adversity; indeed in this are signs for every greatly enduring, most grateful person.

# 3626

And indeed Iblis made his assumptions regarding them seem true, so they all followed him except the group of Muslims.

# 3627

And Satan had no control over them at all, except that We willed to reveal as to who believes in the Hereafter and who is in doubt of it; and your Lord is a Guardian over all things.

# 3628

Proclaim, “Call those whom you assume (as Gods) besides Allah”; they do not own anything equal even to an atom either in the heavens or in the earth, nor do they have any share in them, nor is any one among them an aide to Allah.

# 3629

And intercession does not benefit before Him, except for one whom He permits; to the extent that when the fear is removed from their hearts by giving permission, they say to each other, “How splendidly has your Lord spoken!” They say, “All that He has proclaimed is the Truth; and He is the Supreme, the Great.”

# 3630

Proclaim, “Who provides you sustenance from the sky and the earth?” Proclaim, “Allah – and indeed either we or you are upon guidance, or in open error.”

# 3631

Proclaim, “You will not be questioned regarding the sins you assume we have committed, nor will we be questioned regarding your misdeeds.”

# 3632

Say, “Our Lord will bring us all together, and then judge truthfully between us; and He is the Best Judge, the All Knowing.”

# 3633

Say, “(Dare you) Show me those whom you have matched with Him – never! Rather only He is Allah, the Most Honourable, the Wise.”

# 3634

And O dear Prophet, We have not sent you except with a Prophethood that covers the entire mankind, heralding glad tidings and warnings, but most people do not know. (Prophet Mohammed – peace and blessings be upon him – is the Prophet towards all mankind.)

# 3635

And they say, “When will this promise come, if you are truthful?

# 3636

Proclaim “For you is the promise of a Day which you cannot postpone by one moment nor can you advance it.”

# 3637

And the disbelievers said, “We shall never believe in this Qur’an nor in the Books that were before it”; and if only you see, when the unjust will be brought before their Lord; they will hurl allegations on one another; those who were subdued will say to those who were conceited, “If it were not for you, we would have certainly accepted faith.”

# 3638

Those who were conceited will say to those who were subdued, “Did we stop you from the guidance after it came to you? In fact you yourselves were guilty!”

# 3639

Those who were subdued will say to those who were conceited, “Rather it was your deceit during night and day, for you commanded us to deny Allah and to set up equals to Him”; and inwardly they began regretting when they saw the punishment; and We placed shackles around the necks of the disbelievers; what recompense will they get except what they used to do?

# 3640

And whenever We sent a Herald of Warning to any town, its wealthy people said, “We disbelieve in what you have been sent with.”

# 3641

And they said, “We are greater in wealth and children; we will not be punished!”

# 3642

Proclaim “Indeed my Lord eases the sustenance for whomever He wills and restricts it for whomever He wills, but most people do not know.”

# 3643

And your wealth and your children are not capable of bringing you near to Us, but one who believes and did good deeds (is brought close); for them is double the reward – the recompense of their deeds and they are in high positions, in peace.

# 3644

And those who strive in Our signs in order to defeat, will be brought into the punishment.

# 3645

Say, “Indeed my Lord eases the sustenance for whomever He wills among His bondmen, and restricts it for whomever He wills; and whatever you spend in Allah's cause, He will restore it; and He is the Best Sustainer.”

# 3646

And on the day when He will raise them all, and then say to the angels, “Did they worship you?”

# 3647

They will say, “Purity is to you – only you are our Supporter, not they; in fact they worshipped the jinns; most of them believed only in them.”

# 3648

So this day you will not have the power to benefit or hurt one another; and We shall say to the unjust, “Taste the punishment of the fire which you used to deny!”

# 3649

And if Our clear verses are recited to them, they say, “He is nothing but a man who wishes to turn you away from the deities of your forefathers!”; and they say, “This is nothing but a fabricated lie”; and said the disbelievers regarding the truth when it reached them, “This is nothing but obvious magic.”

# 3650

And We did not give them any Books which they may read, nor did We send to them any Herald of Warning before you.

# 3651

And those before them had denied – and these have not reached even a tenth of what We had given them – so they denied My Noble Messengers; so how did My rejection turn out?

# 3652

Proclaim, “I advise you just one thing; that stand up for Allah's sake, in twos and ones, and then think”; there is not a trace of insanity in this companion of yours; he is not but a Herald of Warning for you, before the advent of a severe punishment!

# 3653

Say, “Whatever fee I might have asked from you upon this, is yours; my reward is only upon Allah; and He is Witness over all things.”

# 3654

Proclaim, “Indeed my Lord sends down the truth; the All Knowing of all the hidden.”

# 3655

Proclaim, “The truth has come, and falsehood dare not commence nor return.”

# 3656

Proclaim, “If I stray, I stray only for my own harm; and if I attain guidance, it is because of what my Lord has sent down to me; indeed He is All Hearing, Close.”

# 3657

And if only you see, when they will be forced into a terror from which they will be unable to escape, and are seized from a place nearby. (Wherever they go, they are never far).

# 3658

And they will say, “We accept faith in it”; and how can they attain it from so far away? (After they have crossed the limit of life allotted to them.)

# 3659

For they had disbelieved in it before; and they hurl allegations without seeing, from far away.

# 3660

And a barrier is set between them and what they desire\*, as was done for their earlier groups; indeed they are in a doubt that deceives. (To accept faith or return to earth)

# 3661

All praise is to Allah, the Maker of the heavens and the earth, Who assigns angels as messengers – who have pairs of two, three, four wings; He increases in creation whatever He wills; indeed Allah is Able to do all things.

# 3662

No one can withhold the mercy which Allah opens to mankind; and whatever He withholds – so after it, none can release it; and only He is the Most Honourable, the Wise.

# 3663

O people! Remember the favour of Allah upon you; is there a Creator other than Allah who can provide you sustenance from the sky and the earth? There is no God except Him; so where are you reverting?

# 3664

And if they deny you, many Noble Messengers were denied before you; and towards Allah only is the return of all matters.

# 3665

O people! Allah’s promise is indeed true; therefore do not ever let the worldly life deceive you; nor ever let the great cheat deceive you in respect of Allah’s commands.

# 3666

Indeed Satan is your enemy, therefore you too take him as an enemy; he only calls his group so that they become the people of hell!

# 3667

For the disbelievers is a severe punishment; and for those who accepted faith and did good deeds is forgiveness, and an immense reward.

# 3668

So will one whose misdeeds are made seeming good to him – so he deems them good – be ever equal to the one who is upon guidance? Therefore indeed Allah sends astray whomever He wills, and guides whomever He wills; so may not your life be lost in despairing after them; Allah knows their deeds very well.

# 3669

And it is Allah Who sent the winds – so they raise clouds and We then direct it towards a dead city – so with it We revive the earth after its death; and this is how the resurrection will be.

# 3670

Whoever desires honour – therefore all honour belongs to Allah!\* Towards Him only ascends the pure good speech, and He raises high the pious deed; and for those who conspire evil is a severe punishment; and their own conspiracy will be destroyed. (It is Allah Who bestows honour, to whomever He wills.)

# 3671

And Allah created you from clay, then a drop of liquid, then made you as couples; and no female conceives or gives birth except with His knowledge; and every aged being that is given the age, and every one whose life is kept short – all this is in a Book; indeed this is easy for Allah.

# 3672

And the two seas are not alike; this is sweet, very sweet and palatable – and this is salty, bitter; and from each you eat fresh meat and extract the ornament which you wear; and you see the ship cleaving through it, so that you may seek His munificence, and in some way become grateful.

# 3673

He brings the night in a part of the day and He brings the day in a part of the night; and He has subjected the sun and moon; each one runs to its fixed term; such is Allah, your Lord – only His is the kingship; and those whom you worship instead of Him do not own even the husk of a date-seed.

# 3674

If you call them, they do not hear your call; and supposedly if they heard it, they cannot fulfil your needs; and on the Day of Resurrection they will deny your ascribed partnership; and none will inform you like Him Who informs.

# 3675

O people! You are dependant on Allah; and Allah only is the Independent (Absolute, Not Needing Anything), the Most Praiseworthy.

# 3676

If He wills, He can take you away and bring other creatures.

# 3677

And this not at all difficult for Allah.

# 3678

And no burdened soul will carry another soul’s burden; and if a burdened soul calls another to share the burden, no one will carry any part of it, even if he is a close relative; O dear Prophet (Mohammed – peace and blessings be upon him), your warning only benefits those who fear their Lord without seeing and who keep the prayer established; and whoever cleansed himself, has cleansed for his own benefit; and towards Allah only is the return.

# 3679

And the blind and the sighted are not equal!

# 3680

And neither are darkness and brightness!

# 3681

And neither are the shadow and the hot sunshine!

# 3682

And not equal are the living and the dead! Indeed Allah causes them to listen\*, whomever He wills; and you cannot make those who are in the graves\*\* listen. (\* Listen to guidance \*\*The disbelievers are referred to as dead, whose fates are sealed.)

# 3683

You are purely a Herald of Warning.

# 3684

And O dear Prophet (Mohammed – peace and blessings be upon him), We have indeed sent you with the Truth, giving glad tidings and heralding warnings; and there was a Herald of Warning in every group.

# 3685

And if these disbelievers deny you, those before them had also denied; their Noble Messengers came to them with clear proofs and scriptures and the bright Book.

# 3686

Then I seized the disbelievers; so how did denial My rejection turn out?

# 3687

Have you not seen that it is Allah Who causes the water to descend from the sky? So with it We have grown various colourful fruits; and among the mountains are tracks white and red, of different hues, and others dark black.

# 3688

And similarly the colours of men and beasts and cattle, are different; among the bondmen of Allah, only the people of knowledge fear Him; indeed Allah is the Most Honourable, Oft Forgiving.

# 3689

Indeed those who read the Book of Allah, and keep the prayer established, and spend from what We have bestowed upon them in secret and publicly, are hopeful of a trade in which there is never a loss.

# 3690

In order that He may reward them with goodness in full, and further increase it with His munificence; indeed He is Oft Forgiving, Most Appreciative.

# 3691

And the Book which We have divinely revealed to you – that is the Truth, confirming the Books which were before it; indeed Allah is Aware of His bondmen, All Seeing.

# 3692

We then made Our chosen bondmen the inheritors of the Book; so among them is one who wrongs himself; and among them is one who stays on the middle course; and among them is one who, by the command of Allah, surpassed others in good deeds; this is the great favour!

# 3693

They shall enter the Gardens of everlasting stay (Eden) – in which they shall be given to adorn armlets of gold and pearls; and their garment in it is silk.

# 3694

And they will say; “All praise is to Allah Who has put away our grief; indeed Our Lord is Oft Forgiving, Most Appreciative.”

# 3695

“The One Who has, by His munificence, established us in a place of serenity; in which no hardship shall ever reach us nor any fatigue affect us.”

# 3696

And for those who disbelieved is the fire of hell; neither does their final seizure come that they may die, nor is its punishment lightened for them; this is how We punish every extremely ungrateful person.

# 3697

And they shall be screaming in it; “Our Lord! Extricate us, so that we may do good deeds, the opposite of what we used to do”; (It will be said to them) “And did We not give you an age long enough, in which anyone who wants to understand would have understood? And the Herald of Warning did come to you; therefore now taste it – for the unjust do not have any supporter.”

# 3698

Indeed Allah is All Knowing – of all the hidden things in the heavens and in the earth; indeed He knows what lies within the hearts.

# 3699

It is He Who has made you the successors of your predecessors in the earth; so whoever disbelieves – (the harm of) his disbelief falls only on him; and for the disbelievers, their disbelief increases nothing in their Lord’s sight except disgust; and for the disbelievers, their disbelief increases nothing for them except ruin.

# 3700

Proclaim, “Just show me your partners (false deities) whom you worship other than Allah; show me which part of the earth have they created – or do they have any share in the heavens?” Or have We given them some Book, so they are on its clear proofs? In fact the unjust do not give promises to each other, except of deceit.

# 3701

Indeed Allah restrains the heavens and the earth from convulsing; and were they to convulse, who could stop them except Allah? Indeed He is Most Forbearing, Oft Forgiving.

# 3702

And they swore by Allah most vehemently in their oaths, that if a Herald of Warning came to them, they would be more upon guidance than any other group; then when a Herald of Warning did come to them, he increased nothing in them except hatred.

# 3703

Priding themselves in the earth and scheming evil; and the evil scheming falls only upon those who scheme it; so what are they waiting for, except the tradition of the earlier nations? So you will never find the traditions of Allah changing; and you will never find Allah’s law being avoided.

# 3704

And did they not travel in the land in order to see what sort of fate befell those who were before them, whereas they exceeded them in strength? And Allah is not such that anything in the heavens or in the earth can break away from His control; indeed He is All Knowing, Able.

# 3705

If Allah were to seize people upon their deeds, He would leave no creature walking on the surface of the earth, but He gives them respite till a fixed term; and when their term comes – so indeed Allah is observing all His bondmen!

# 3706

Yaa-Seen (Alphabets of Arabic language – Allah and to whomever He reveals, know their precise meanings.)

# 3707

By oath of the wise Qur’an.

# 3708

You (O dear Prophet Mohammed – peace and blessings be upon him) are indeed one of the Noble Messengers.

# 3709

On the Straight Path.

# 3710

(The Qur’an is) Sent down by the Almighty, the Most Merciful.

# 3711

So that you may warn these people whose ancestors were not warned, they are therefore unaware.

# 3712

Undoubtedly, it (their disbelief) has proved true for most of them, so they will not believe.

# 3713

We have indeed put shackles around their necks reaching up to the chins, so they remain facing upwards.

# 3714

And We have set a wall before them and a wall behind them, and covered the top – so they are unable to see anything.

# 3715

And it is the same for them, whether you warn them or do not warn them – they will not believe.

# 3716

You warn only him who follows the advice and fears the Most Gracious without seeing; therefore give him glad tidings of forgiveness and an honourable reward.

# 3717

We will surely bring the dead to life and We record what they send ahead and the signs they will leave behind; and We have accounted all things in a clear Book.

# 3718

And relate to them the signs of the people of the city – when two emissaries came to them.

# 3719

When We had sent two towards them and they denied them both, so We fortified them with a third, and they all said, “Indeed we have been sent to you.”

# 3720

They said, “You are nothing but mortals like us; the Most Gracious has not sent down anything – you are nothing but liars.”

# 3721

They answered, “Our Lord knows that surely, without doubt, we have been sent towards you.”

# 3722

“And our duty is nothing but to plainly convey (the message).”

# 3723

They (the people of the city) said, “We think you are ominous; indeed, if you do not desist, we shall surely stone you to death, and you will surely face a grievous torture at our hands.”

# 3724

They said, “Your evil omens are with you! What! You get annoyed for being advised? In fact you are a people who transgress the limits!”

# 3725

And from the outermost part of the city came a man running; he said, “O my people! Obey those who have been sent.”

# 3726

“Obey those who do not ask any fee from you, and they are on guidance.”

# 3727

“And what is the matter with me that I should not worship Him Who created me, whereas it is towards Him that you are to return?”

# 3728

“What! Shall I appoint Gods other than Allah? So that if the Most Gracious should wish me any harm, their intercession would be of no use to me, nor would they be able to save me?”

# 3729

“Undoubtedly, I am then in open error.”

# 3730

“Indeed I have believed in your Lord, so heed me.”

# 3731

It was said to him, “Enter Paradise”; he said, “If only my people knew!”

# 3732

“The manner in which my Lord has pardoned me and made me of the honoured ones!”

# 3733

And after him, We did not send down any army from heaven against his people, nor did We intend to send down an army.

# 3734

It was just one scream, and with it they were extinguished.

# 3735

And it was said, “Woe to those bondmen – whenever a Noble Messenger comes to them, they mock at him!”

# 3736

Have they not seen how many generations We destroyed before them, which will not return to them?

# 3737

And without exception, all of them will be brought forth before Us.

# 3738

And a sign for them is the dead earth; We gave it life and We produced from it grain, so they eat from it.

# 3739

And We have placed in it gardens of dates and grapes, and We have made springs of water in it.

# 3740

So that they may eat from its fruits, whereas they are not manufactured by their hands! So will they not be grateful?

# 3741

Purity is to Him Who created all pairs, from what the earth grows, and of themselves, and from the things they do not know.

# 3742

And a sign for them is the night; We strip the day out of it, thereupon they are in darkness.

# 3743

And the sun runs its course for its final destination; this is a command of the Almighty, the All Knowing.

# 3744

And We have appointed positions for the moon till it returns like an old branch of the date palm.

# 3745

It is not for the sun to catch up with the moon, nor does the night surpass the day; and each one of them floats in its orbit.

# 3746

And a sign for them is that We lodged them in a laden ship, while they were in their forefathers backs.

# 3747

And We have created for them similar ships, in which they now ride.

# 3748

And if We will, We can drown them, so there would be no help in their distress, nor would they be saved.

# 3749

Unless by mercy from Us, and as a comfort for a while.

# 3750

And when it is said to them, “Beware of what is before you and what is behind you, in the hope of your gaining mercy”, they turn away!

# 3751

And whenever a sign comes to them from the signs of their Lord, they always turn away from it!

# 3752

And when it is said to them, “Spend in Allah’s cause, from what Allah has provided you”, the disbelievers say regarding the believers, “Shall we feed these, whom if Allah willed, would have fed? You are not but in open error!”

# 3753

And they say, “When will this promise be fulfilled, if you are truthful?”

# 3754

They await just one scream, which will overcome them while they are involved in worldly disputes.

# 3755

Therefore neither able to make a will, nor returning to their homes.

# 3756

And the Trumpet will be blown – so they will come forth from the graves, running towards their Lord.

# 3757

Saying, “O our misfortune! Who has raised us from our sleep? This is what the Most Gracious had promised, and the Noble Messengers had spoken the truth!”

# 3758

It is just one scream, and every one of them will be brought together before Us!

# 3759

So this day no soul will be wronged in the least; and you will not be compensated except for your deeds.

# 3760

Indeed this day the dwellers of Paradise are in comfort, with blissful hearts.

# 3761

They and their wives are in shades, reclining on thrones.

# 3762

In it (paradise) are fruits for them and whatever they ask for.

# 3763

Upon them will be “Peace” – a Word from their Merciful Lord!

# 3764

“And be separated (from others) this day, O you criminals!”

# 3765

“O Descendants of Adam! Did I not take a covenant from you that you shall not worship the devil? Undoubtedly, he is your open enemy.”

# 3766

“And that you shall worship Me? This is the Straight Path.”

# 3767

“And he has indeed led a large number of you astray; so did you not have sense?”

# 3768

“This is hell, which you were promised.”

# 3769

“Enter it this day – the recompense of your disbelief.”

# 3770

This day We will set a seal on their mouths, and their hands will speak out to Us and their feet will bear witness to their deeds.

# 3771

And had We willed, We could have quenched their eyes so they would rush towards the path, unable to see a thing.

# 3772

And had We willed, We could have disfigured their faces while they were in their homes, therefore unable to go forward or turn back.

# 3773

And whomever We bring to an old age, We reverse him in creation; so do they not understand?

# 3774

And We have not taught him (Prophet Mohammed- peace and blessings be upon him) to recite poetry, nor does it befit him; it is nothing but an advice and the bright Qur’an.

# 3775

To warn the living\*, and to prove the Word against disbelievers. (Only the believers are deemed alive in Allah’s sight.)

# 3776

Did they not see that We have created animals for them from Our handiwork, so they are their owners?

# 3777

And have subjected the animals for them, so they ride some animals and eat some?

# 3778

And for them in the animals are numerous different benefits and drinks; so will they not be grateful?

# 3779

And they have appointed Gods other than Allah, that perhaps they may be helped!

# 3780

They (the appointed Gods) cannot help them; and they and their armies will come (to Us), as captives.

# 3781

Therefore (O dear Prophet Mohammed – peace and blessings be upon him) do not grieve because of what they (the disbelievers) say; indeed We know what they conceal and what they disclose.

# 3782

And did not man see that We have created him from a drop of semen? Yet he is an open quarreller!

# 3783

And he invents an example for Us, while forgetting his own creation, saying, “Who is such that can revive the bones when they have completely rotted away?”

# 3784

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “They will be revived by the One Who created them the first time; and He is the All Knowing of every creation.”

# 3785

“The One Who has created for you fire from the green tree, so you kindle from it.”

# 3786

And is it not possible for the One Who created the heavens and the earth to create the likes of them? It is surely possible, why not? And He is the Great Creator, the All Knowing of everything.

# 3787

And His only task when He intends a thing is to command it, “Be” – and it thereupon happens!

# 3788

Therefore Purity is to Him in Whose Hand\* is the control over all things and it is towards Him that you will be returned. (Used as a metaphor to mean Power).

# 3789

By oath of those who establish proper ranks.

# 3790

And by oath of those who herd with a stern warning.

# 3791

And by oath of the groups that read the Qur’an.

# 3792

Indeed your God is surely only One.

# 3793

Lord of the heavens and the earth and all that is between them – and the Lord of the sun’s rising points.

# 3794

We have indeed adorned the lowest heaven with stars as ornaments.

# 3795

And to protect it from every rebellious devil.

# 3796

They cannot listen to the speech of those on higher elevations and they are targeted from every side.

# 3797

To make them flee, and for them is a never-ending punishment.

# 3798

Except one who sometimes steals a part, so a blazing flame goes after him.

# 3799

Therefore ask them (O dear Prophet Mohammed – peace and blessings be upon him), “Are they a stronger creation, or are other things of our creation, (the angels, the heavens etc.)?” We have indeed created them from sticky clay.

# 3800

Rather you are surprised, whereas they keep mocking.

# 3801

And they do not understand, when explained to.

# 3802

And whenever they see a sign, they mock at it.

# 3803

And they say, “This is nothing but clear magic.”

# 3804

“When we are dead and have turned into dust and bones, will we certainly be raised again?”

# 3805

“And also our forefathers?”

# 3806

Proclaim, “Yes, and with disgrace.”

# 3807

So that is just a single jolt, thereupon they will begin staring.

# 3808

And will say, “O our misfortune!” It will be said to them, “This is the Day of Justice.”

# 3809

“This is the Day of Judgement, which you used to deny!”

# 3810

“Gather all the unjust persons and their spouses, and all that they used to worship!” –

# 3811

“Instead of Allah – and herd them to the path leading to hell.”

# 3812

“And stop them – they are to be questioned.”

# 3813

“What is the matter with you, that you do not help one another?”

# 3814

In fact this day they have all surrendered.

# 3815

And some of them inclined towards others, mutually questioning.

# 3816

They said, “It is you who used to come to us from our right, in order to sway.”

# 3817

They will answer, “You yourselves did not have faith!”

# 3818

“And we did not have any control over you; but in fact you yourselves were rebellious.”

# 3819

“So the Word of our Lord has proved true upon us; we will surely have to taste (the punishment).”

# 3820

“We therefore led you astray, for we ourselves were astray!”

# 3821

So this day they all are partners in the punishment.

# 3822

This is how We deal with the guilty.

# 3823

Indeed, when it was said to them, “There is no God except Allah”, they were haughty.

# 3824

And they used to say, “Shall we forsake our Gods upon the sayings of a mad poet?”

# 3825

In fact he has brought the Truth, and testified for the Noble Messengers!

# 3826

“You surely have to taste the painful punishment.”

# 3827

“And you will not be compensated except for your deeds.”

# 3828

Except the chosen bondmen of Allah.

# 3829

For them is the sustenance known to Us.

# 3830

Fruits; and they will be honoured.

# 3831

In Gardens of peace.

# 3832

Facing one another on thrones.

# 3833

Cups of wine will be presented to them in rounds, from a spring flowing in front of them.

# 3834

White, delicious for the drinkers.

# 3835

Neither does it intoxicate, nor give a headache.

# 3836

And with them are those who do not set gaze upon men except their husbands, the maidens with gorgeous eyes.

# 3837

As if they were eggs, safely hidden.

# 3838

So one among them turns to the other, questioning. –

# 3839

The speaker among them said, “I had a companion.” –

# 3840

“Who used to tell me, ‘Do you believe it is true?’ –

# 3841

‘That when we are dead and have turned into dust and bones, that we will either be rewarded or punished?’”

# 3842

He said (to others on the thrones), “Will you take a glimpse (into hell) below?”

# 3843

He therefore looked down and saw him amidst the blazing fire.

# 3844

He said, “By Allah, you had nearly ruined me!”

# 3845

“And were it not for the munificence of my Lord, I too would have been seized and brought forth (captive)!”

# 3846

“So are we never to die?” (The people of Paradise will ask the angels, with delight, after the announcement of everlasting life.)

# 3847

“Except our earlier death, and nor will we be punished?”

# 3848

“This is, most certainly, the supreme success.”

# 3849

For such a reward should the workers perform.

# 3850

So is this welcome better, or the tree of Zaqqum?

# 3851

We have indeed made that a punishment for the unjust.

# 3852

Indeed it is a tree that sprouts from the base of hell.

# 3853

Its fruit like the heads of demons.

# 3854

So indeed they will eat from it, and fill their bellies with it.

# 3855

Then after it, indeed for them is the drink of boiling hot water.

# 3856

Then surely their return is towards hell.

# 3857

They had indeed found their forefathers astray.

# 3858

So they hastily follow their footsteps!

# 3859

And indeed before them, most of the former people went astray.

# 3860

And indeed We had sent Heralds of warnings among them.

# 3861

Therefore see what sort of fate befell those who were warned!

# 3862

Except the chosen bondmen of Allah.

# 3863

And indeed Nooh prayed to Us – so what an excellent Acceptor of Prayer We are!

# 3864

And We rescued him and his household from the great calamity.

# 3865

And We preserved his descendants.

# 3866

And We kept his praise among the latter generations.

# 3867

Peace be upon Nooh, among the entire people.

# 3868

This is how We reward the virtuous.

# 3869

He is indeed one of Our high ranking, firmly believing bondmen.

# 3870

We then drowned the others.

# 3871

And indeed Ibrahim is from his (Nooh’s) group.

# 3872

When he came to his Lord, with a sound heart. (Free from falsehood).

# 3873

When he said to his father (paternal uncle) and his people, “What do you worship?”

# 3874

“What! You desire, through fabrication, Gods other than Allah?”

# 3875

“So what do you assume regarding the Lord Of The Creation?” (That He will not punish you?)

# 3876

He then shot a glance at the stars.

# 3877

He then said, “I feel sick (of you)!”

# 3878

And they turned their backs on him and went away. (The pagans thought he would transmit the disease).

# 3879

He then sneaked upon their deities and said, “Do you not eat?”

# 3880

“What is the matter with you, that you do not say anything?”

# 3881

He then began striking them with his right hand, unseen by the people.

# 3882

So the disbelievers came running towards him.

# 3883

He said, “What! You worship what you yourselves have sculpted?”

# 3884

“Whereas Allah has created you and your actions?”

# 3885

They said, “Construct a building (furnace) for him, and then cast him in the blazing fire!”

# 3886

So they tried to execute their evil scheme upon him – We therefore degraded them. (Allah saved him, by commanding the fire to turn cool).

# 3887

And he said, “Indeed I shall go to my Lord Who will guide me.”

# 3888

“My Lord! Give me a meritorious child.”

# 3889

We therefore gave him the glad tidings of an intelligent son.

# 3890

And when he became capable of working with him, Ibrahim said, “O my son, I dreamt that I am sacrificing you – therefore now consider what is your opinion”; he said, “O my father! Do what you are commanded! Allah willing, you will soon find me patiently enduring!”

# 3891

Then (remember) when they both submitted to Allah’s command, and Ibrahim lay his son facing downwards. (The knife did not hurt Ismail)

# 3892

And We called out to him, “O Ibrahim!”

# 3893

“You have indeed made the dream come true”; and this is how We reward the virtuous.

# 3894

Indeed this was a clear test.

# 3895

And We rescued him in exchange of a great sacrifice. (The sacrifice of Ibrahim and Ismail – peace be upon them – is commemorated every year on 10, 11 and 12 Zil Haj).

# 3896

And We kept his praise among the latter generations.

# 3897

Peace be upon Ibrahim!

# 3898

This is how We reward the virtuous.

# 3899

He is indeed one of Our high ranking, firmly believing bondmen.

# 3900

And We gave him the glad tidings of Ishaq, a Herald of the Hidden, from among those who deserve Our proximity.

# 3901

And We sent blessings upon him and Ishaq; and among their descendants – some who do good deeds, and some who clearly wrong themselves.

# 3902

And We indeed did a great favour to Moosa and Haroon.

# 3903

And rescued them and their people from the great calamity.

# 3904

And We helped them, so they were victorious.

# 3905

And We bestowed the clear Book to both of them.

# 3906

And guided them to the Straight Path.

# 3907

And We kept their praise among the latter generations.

# 3908

Peace be upon Moosa and Haroon!

# 3909

This is how We reward the virtuous.

# 3910

Indeed they are two of Our high ranking, firmly believing bondmen.

# 3911

And indeed Ilyas is one of the Noble Messengers.

# 3912

When he said to his people, “Do you not fear?”

# 3913

“What! You worship Baal (an idol) and leave the Best Creator?” –

# 3914

“Allah – Who is your Lord and the Lord of your forefathers?”

# 3915

In response they denied him, so they will surely be brought forth as captives.

# 3916

Except the chosen bondmen of Allah.

# 3917

And We kept his praise among the latter generations.

# 3918

Peace be upon Ilyas!

# 3919

This is how We reward the virtuous.

# 3920

He is indeed one of Our high ranking, firmly believing bondmen.

# 3921

And indeed Lut is one of the Noble Messengers.

# 3922

When We rescued him and his entire household.

# 3923

Except an old woman, who became of those who stayed behind.

# 3924

We then destroyed the others.

# 3925

And indeed you pass over them in the morning. –

# 3926

And during the night; so do you not have sense?

# 3927

And indeed Yunus is one of the Noble Messengers.

# 3928

When he left towards the laden ship.

# 3929

Then lots were drawn and he became of those who were pushed into the sea.

# 3930

The fish then swallowed him and he blamed himself. (For not waiting for Allah’s command.)

# 3931

And were he not one of those who praise. –

# 3932

He would have remained in its belly till the day when all will be raised.

# 3933

We then put him ashore on a plain, and he was sick.

# 3934

And We grew a tree of gourd (as a shelter) above him.

# 3935

And We sent him towards a hundred thousand people, in fact more.

# 3936

So they accepted faith – We therefore gave them usage for a while.

# 3937

Therefore ask them (O dear Prophet Mohammed – peace and blessings be upon him), whether the daughters are for your Lord and the sons for them!

# 3938

Or that have We created the angels as females, while they were present?

# 3939

Pay heed! It is their slander that they say. –

# 3940

That “Allah has offspring”; and indeed, surely, they are liars.

# 3941

“Has he chosen daughters instead of sons?”

# 3942

“What is the matter with you? What sort of a judgement you impose!”

# 3943

“So do you not ponder?”

# 3944

“Or do you have some clear proof?”

# 3945

“Then bring forth your Book, if you are truthful!”

# 3946

And they have appointed a relationship between Him and the jinns; and indeed the jinns surely know that they will be brought forth.

# 3947

Purity is to Allah from the matters they fabricate.

# 3948

Except the chosen bondmen of Allah.

# 3949

Therefore you and all what you worship. (The disbelievers and their deities.)

# 3950

You cannot make anyone rebel against Him.

# 3951

Except the one who will go into the blazing fire.

# 3952

And the angels say, “Each one of us has an appointed known position.”

# 3953

“And indeed we, with our wings spread, await the command.”

# 3954

“And indeed we are those who say His purity.”

# 3955

And indeed the disbelievers used to say, –

# 3956

“If we had some advice from the earlier generations,” –

# 3957

“We would certainly be the chosen bondmen of Allah.”

# 3958

They therefore denied it, so they will soon come to know.

# 3959

And indeed Our Word has already gone forth for Our bondmen who were sent.

# 3960

That undoubtedly, only they will be helped.

# 3961

And surely, only Our army will be victorious.

# 3962

Therefore turn away from them for some time.

# 3963

And watch them, for they will soon see.

# 3964

So are they being impatient for Our punishment?

# 3965

So when it does descend in their courtyards – so what an evil morning it will be for those who were warned!

# 3966

And turn away from them for some time.

# 3967

And wait, for they will soon see.

# 3968

Purity is to your Lord, the Lord of Honour, from all what they say.

# 3969

And peace is upon the Noble Messengers.

# 3970

And all praise is to Allah, the Lord Of The Creation.

# 3971

Saad\* – By oath of the renowned Qur’an, (Alphabet of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 3972

In fact, the disbelievers are in false pride and opposition.

# 3973

Many a generation We did destroy before them – thereupon they cried out whereas it is not the time to escape!

# 3974

And they were surprised that a Herald of Warning came to them from among themselves; and the disbelievers said, “He is a magician, a great liar!”

# 3975

“Has he made all the Gods into One God? This is really something very strange!”

# 3976

And their leaders went about, “Leave him and cling steadfastly to your Gods! Indeed he has a hidden objective in this!”

# 3977

“We never heard of this even in Christianity, the latest religion; this is clearly a newly fabricated matter.”

# 3978

“Is the Qur’an which is sent to him, among us?” In fact they are in a doubt concerning My Book; in fact, they have not yet tasted My punishment.

# 3979

Or do they hold the treasures of the mercy of your Lord, the Almighty, the Great Bestower?

# 3980

Is the kingdom of the heavens and the earth and all that is between them, for them? So would they not just ascend using ropes?

# 3981

This is just one of the disgraced armies, that will be routed there and then.

# 3982

Before them, the people of Nooh had denied, and the tribe of A’ad, and Firaun who used to crucify.

# 3983

And the tribe of Thamud, and the people of Lut, and the People of the Woods; these are the groups.

# 3984

None of them was such that it did not deny the Noble Messengers, therefore My punishment became inevitable.

# 3985

They await just one Scream, which no one can avert.

# 3986

And they said, “Our Lord! Give us our share quickly, before the Day of Reckoning.”

# 3987

Have patience upon what they say, and remember Our bondman Dawud, the one blessed with favours; he is indeed most inclined (towards His Lord).

# 3988

Indeed We subjected the hills to say the praise with him, at night and at morn.

# 3989

And birds gathered together; they were all obedient to him.

# 3990

And We strengthened his kingdom and gave him wisdom and just speech.

# 3991

And did the news of the two disputants reach you? When they scaled over the wall into Dawud’s mosque.

# 3992

When they entered upon David, so he feared them – they said, “Do not fear! We are two disputants, one of whom has wronged the other, therefore judge fairly between us and do not judge unjustly – and show us the right way.”

# 3993

“This is my brother; he has ninety nine ewes and I have one ewe; and he now says ‘Give that one also to me’ – and he is very demanding in speech.”

# 3994

Said Dawud, “He is indeed being unjust to you in that he demands to add your ewe to his ewes; and indeed most partners wrong one another, except those who believe and do good deeds – and they are very few!” Thereupon Dawud realised that We had tested him, so he sought forgiveness from his Lord, and fell prostrate and inclined (towards his Lord). (Command of Prostration # 10)

# 3995

We therefore forgave him this; and indeed for him in Our presence are, surely, proximity and an excellent abode.

# 3996

“O Dawud! We have indeed appointed you as a Viceroy in the earth, therefore judge between mankind with the truth, and do not follow desire for it will lead you astray from Allah’s path; indeed for those who stray away from Allah’s path is a severe punishment, because they forgot the Day of Reckoning.”

# 3997

And We have not created the heaven and the earth and all that is between them without purpose; this is what the disbelievers assume; therefore ruin is for the disbelievers, by the fire.

# 3998

Shall We make those who believe and do good deeds equal to those who spread turmoil in the earth? Or shall We equate the pious with the disobedient?

# 3999

This is a Book which We have sent down upon you, a blessed Book, for them to ponder upon its verses, and for men of intellect to accept advice.

# 4000

And We bestowed Sulaiman to Dawud; what an excellent bondman! He is indeed most inclined.

# 4001

When fast footed steeds were presented to him at evening.

# 4002

Therefore Sulaiman said, “I cherish the love of these horses\*, out of remembrance of my Lord”; he then ordered them to be raced until they vanished in a curtain out of sight. (To be used in holy war.)

# 4003

He then ordered, “Bring them back to me”; and he began caressing their shins and necks.

# 4004

And We indeed tested Sulaiman, and placed a dead body on his throne – he therefore inclined towards His Lord.

# 4005

He said, “My Lord! Forgive me and bestow upon me a kingdom, which shall not befit anyone after me; indeed only You are the Great Bestower.”

# 4006

We therefore gave the wind under his control, moving steadily by his command wherever he wished.

# 4007

And made the demons subservient to him, all builders and divers.

# 4008

And other demons bound in chains.

# 4009

“This is Our bestowal – you may therefore bestow favours or withhold them – you will not be questioned.”

# 4010

And indeed for him in Our presence are, surely, proximity and an excellent abode.

# 4011

And remember Our bondman Ayyub (Job); when he cried out\* to his Lord, “The devil has struck me with hardship and pain.” (After seven years of patience.)

# 4012

We said to him, “Strike the earth with your foot; this cool spring is for bathing and drinking.” (A spring of gushed forth when he struck the earth – this was a miracle.)

# 4013

And We bestowed his household to him and one more similar to it – as a mercy from Us, and as a remembrance for the people of intellect.

# 4014

And We said, “Take a broom in your hand and strike her with it, and do not break your vow”; We indeed found him patiently enduring; what an excellent bondman! He is indeed most inclined.

# 4015

And remember Our bondmen Ibrahim, and Ishaq, and Yaqub – the men of power and knowledge.

# 4016

We indeed gave them distinction with a genuine affair – the remembrance of the (everlasting) abode.

# 4017

And in Our sight, they are indeed the chosen ones, the beloved.

# 4018

And remember Ismail and Yasa’a (Elisha) and Zul-Kifl; and they are all excellent.

# 4019

This is an advice; and indeed for the pious is an excellent abode.

# 4020

Everlasting Gardens – all its gates are open for them.

# 4021

Reclining on pillows, in it they ask for fruits and drinks in plenty.

# 4022

And with them are the pure spouses, who do not set gaze upon men except their husbands, of single age.

# 4023

This is the promise being given to you, for the Day of Reckoning.

# 4024

Indeed this is Our sustenance, which will never end.

# 4025

This is for the virtuous; and indeed for the rebellious is a wretched destination.

# 4026

Hell; which they shall enter; what an evil resting-place!

# 4027

This is for the criminals – so that they may taste it – boiling hot water and pus.

# 4028

And similar other punishments in pairs.

# 4029

“Here is another group that was with you, falling along with you”; they will answer, “Do not give them plenty of open space; they surely have to enter the fire – let them also be confined!”

# 4030

The followers will say, “In fact, for you! May you not get open space! It is you who brought this calamity upon us!” So what a wretched destination.

# 4031

They say, “Our Lord! Whoever has brought this calamity upon us – double the punishment of the fire for him!”

# 4032

And they say, “What is the matter with us that we do not see the men whom we thought were evil?”

# 4033

“Did we mock at them or did our eyes turn away from them?”

# 4034

Indeed this is really true – the people of the hell quarrelling among themselves.

# 4035

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I am purely a Herald of Warning – and there is no God except Allah, the One, the All Dominant.”

# 4036

“Lord of the heavens and the earth and all that is between them – the Almighty, the Oft Forgiving.”

# 4037

Say, “That is a great tidings.”

# 4038

“You are neglectful of it!”

# 4039

“What did I know of the heavenly world, when the angels had disputed.”

# 4040

“I receive only the divine revelations, that I am purely a clear Herald of Warning.”

# 4041

(Remember) When your Lord said to the angels, “I will create a human from clay.” –

# 4042

“So when I have perfected him and breathed into him a spirit from Myself, (you all) fall down before him in prostration.”

# 4043

So all the angels prostrated, every one, without exception.

# 4044

Except Iblis; he was proud and was, from the beginning, a disbeliever.

# 4045

Said Allah, “O Iblis! What prevented you from prostrating before one whom I have created with My hands\*? Have you become proud or were you haughty from the beginning?” (Used as a metaphor).

# 4046

Said Iblis, “I am better than him; You made me from fire, and You have created him from clay!”

# 4047

He said, “Therefore exit from heaven, for you have been outcast.” (To disrespect the Prophets – peace and blessings be upon them – is blasphemy.)

# 4048

“And indeed My curse is upon you till the Day of Judgement.”

# 4049

He said, “My Lord! Therefore give me respite till the day when all will be raised.”

# 4050

Said Allah, “You are therefore among those given respite.”

# 4051

“Until the time of the known day.”

# 4052

He said, “Therefore, by oath of Your honour, I will surely mislead all of them.”

# 4053

“Except Your chosen bondmen among them.”

# 4054

Said Allah, “So this is the truth; and I speak only the truth.” –

# 4055

“That I will fill hell with you and with those among them who follow you, all together.”

# 4056

Say (O dear Prophet Mohammed – peace and blessings be upon him) “I do not ask any fee from you for the Qur’an, and I am not a fabricator.”

# 4057

“It is not but an advice for the entire world.”

# 4058

“And you will come to know of its tidings, after a while.”

# 4059

The revelation of the Book is from Allah, the Most Honourable, the Wise.

# 4060

We have indeed divinely revealed the Book to you (O dear Prophet Mohammed – peace and blessings be upon him) with the truth, therefore worship Allah, as His sincere bondman.

# 4061

Pay heed! Worship is for Allah only; and those who have taken others as their supporters beside Him say; “We worship\* them only so that they get us closer to Allah”; Allah will surely judge between them regarding the matter in which they dispute; indeed Allah does not guide one who is a big liar, extremely ungrateful. (\*The pagans regarded their idols as smaller Gods and worshipped them. So did the Christians. This does not apply to Muslims who only respect their elders, and ask for their blessings.)

# 4062

Were Allah to create a son\* for Himself, He would have chosen any one from His creation! Purity is to Him! He is Allah, the One, the All Dominant. (\*Which is impossible.)

# 4063

It is He Who created the heavens and the earth with the truth; He envelops the night over day and envelops the day over night, and He has subjected the sun and the moon; each one runs for its appointed term; pay heed! He only is the Most Honourable, the Oft Forgiving.

# 4064

It is He Who created you from a single being, and then from the same being created its spouse, and sent down for you eight pairs of animals; He creates you in your mothers’ wombs, from one sort to another, in a triple darkness; such is Allah, your Lord – for Him only is the kingship; there is no God except Him; so where are you being turned away?

# 4065

If you become ungrateful, then (know that) indeed Allah is Independent of you; and He does not like the ungratefulness of His bondmen; and if you give thanks, He is pleased with it for you; and no burdened soul will bear another soul’s burden; you have then to return towards your Lord – He will therefore inform you of what you used to do; undoubtedly, He knows what lies within the hearts.

# 4066

And when some hardship strikes man, he prays to his Lord, inclined only towards Him – then when Allah grants him a favour from Himself, he forgets why he had prayed to Him earlier, and sets up equals to Allah in order to mislead from Allah’s way; proclaim, “Revel in your disbelief for some days; you are indeed of the people of the fire.”

# 4067

Will he, whose night hours pass in obedience while prostrating and standing, fearing the Hereafter and hoping for the mercy of his Lord, ever be equal to the disobedient? Proclaim, “Are the knowledgeable and the ignorant equal?” It is only the men of intellect who heed advice.

# 4068

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “O my slaves who have accepted faith! Fear your Lord; for those who do good deeds in this world is goodness (in return); and Allah’s earth is spacious; it is the steadfast who will be paid their full reward, without account.”

# 4069

Say, “I am commanded that I must worship Allah as His sincere bondman.” (And so must you too.)

# 4070

“And I am commanded that I be the first to submit.”

# 4071

Say, “Were I to disobey my Lord, I too would fear the punishment of the great Day (of Resurrection).”

# 4072

Proclaim, “I worship only Allah, as His sincere bondman.”

# 4073

“Therefore you can worship what you want besides Him!” Say, “The worst losers are those who will lose themselves and their household on the Day of Resurrection; pay heed! This is the plain loss!”

# 4074

Above them are mountains of fire and beneath them are mountains of fire; Allah scares His bondmen with this; “O My bondmen! Fear Me!”

# 4075

And those who stayed away from the worship of idols, and inclined towards Allah – for them are glad tidings; therefore give glad tidings to My bondmen. –

# 4076

Those who heed attentively and follow the best from it; it is these whom Allah has guided, and it is these who have intelligence.

# 4077

So will the one upon whom the Word of punishment has proved true, ever be equal to those who are forgiven? So will you guide and save the one who deserves the fire? (Because the hearts of some disbelievers are sealed).

# 4078

But for those who fear their Lord, are the high chambers with more high chambers built above them – rivers flowing beneath them; a promise of Allah; Allah does not renege on His promise.

# 4079

Did you not see that it is Allah Who sent down water from the sky, and then with it made springs in the earth, and then with it produces crops of various colours, and then it dries up and you see it has become yellow, and He then fragments them into small pieces; indeed in this is a reminder for people of intellect.

# 4080

So will he whose bosom Allah has opened up for Islam – he is therefore upon a light from his Lord – ever be equal to one who is stone hearted? Therefore ruin is for those whose hearts are hardened towards the remembrance of Allah; they are in open error.

# 4081

Allah has sent down the best of Books (the Holy Qur’an), which is consistent throughout, the one with paired statements; the hairs on the skins of those who fear their Lord, stand on end with it; then their skins and their hearts soften, inclined towards the remembrance of Allah; this is the guidance of Allah, He may guide whomever He wills with it; and whomever Allah sends astray, there is no guide for him.

# 4082

So will he who will not have a shield except his own face against the wretched punishment on the Day of Resurrection, ever be equal to one who is forgiven? And it will be said to the unjust, “Taste what you have earned!”

# 4083

Those before them had denied, therefore the punishment came to them from a place they did not know.

# 4084

So Allah made them taste humiliation in the life of this world; and indeed the punishment of the Hereafter is the greatest; if only they knew!

# 4085

And We have indeed illustrated examples of all kinds in this Qur’an, so that they may ponder.

# 4086

The Qur’an in Arabic, having no deviation at all, so that they may be pious.

# 4087

Allah illustrates an example – “A man having several wicked masters as partners, and another man belonging wholly to just one master; are the two equal in comparison?” All praise is to Allah; in fact, most among them do not know.

# 4088

Indeed you (O dear Prophet Mohammed – peace and blessings be upon him) will taste death, and they (the disbelievers) too will die.

# 4089

Then you will dispute before your Lord on the Day of Resurrection.

# 4090

So who is more unjust than one who fabricates a lie against Allah, and denies the truth when it comes to him? Is not the destination of disbelievers in hell?

# 4091

And those who brought this truth and those who testify for it – these are the pious.

# 4092

For them is whatever they wish, before their Lord; this is the reward of the virtuous.

# 4093

So that Allah may relieve them of their worst deeds, and reward them for the best deeds they had done.

# 4094

Is not Allah Sufficient for His slave? And they threaten you with others beside Him! And whomever Allah sends astray – there is no guide for him.

# 4095

And no one can mislead whomever Allah guides; is not Allah the Most Honourable, the Avenger?

# 4096

And if you ask them, “Who has created the heavens and the earth?”, they will surely say, “Allah”; say, “What is your opinion regarding those whom you worship other than Allah – if Allah wills to cause me some hardship, so will they avert the hardship sent by Him? Or if He wills to have mercy upon me, so will they restrain His mercy?” Proclaim, “Allah is Sufficient for me; the people who trust must rely only upon Him.”

# 4097

Proclaim, “O my people! Keep on with your works in your positions, I am doing mine; so you will soon come to know.” –

# 4098

“To whom will come a punishment that will disgrace, and upon whom descends the punishment that never ends.”

# 4099

We have indeed sent down this Book to you with the truth, in order to guide mankind; so whoever attains guidance has attained it is for his own good, and whoever strays, has strayed for his own harm; and you are not at all responsible for them.

# 4100

It is Allah Who gives death\* to living beings at the time of their demise, and to those who do not die, during their sleep; so He restrains the soul on which the decree of death has been passed, and leaves the other till the appointed term; indeed in this are signs for people who reflect. (\*Death is of 2 types – passing to the next world, and sleeping.)

# 4101

What! Have they chosen intercessors against Allah? Proclaim, “What! Even if they do not own anything nor have any intelligence?”

# 4102

Proclaim, “To Allah only\* belongs all the intercession! For Him only is the kingship of the heavens and the earth; and then it is towards you have to return.” (\*Allah does not intercede – He gives the permission to intercede with Him, to whomever He wills.)

# 4103

And when Allah the One God is mentioned, the hearts of those who do not believe in the Hereafter get constricted; and when others (false deities) besides Him are mentioned, they rejoice!

# 4104

Invoke (O dear Prophet Mohammed – peace and blessings be upon him), “O Allah! The Creator of the heavens and the earth, the All Knowing of all the hidden and the open, You will judge between Your bondmen, regarding the matters in which they differed.”

# 4105

And if the unjust owned all that is in the earth, and another one in addition to it, they would surely give it in exchange for freedom from the wretched punishment on the Day of Resurrection; and a matter which they had never imagined, appeared to them from their Lord.

# 4106

And the evils they earned appeared to them, and the thing they used to mock at descended upon them.

# 4107

So when some hardship reaches man, he prays to Us; then later when We bestow a favour upon him, he says, “I obtained this only because of some knowledge”; in fact it is a test, but most of them do not have any knowledge.

# 4108

Those before them also said the same, so their earnings did not benefit them at all.

# 4109

Therefore the evils of their earnings befell them; and those who are unjust among them – soon the evils of the earnings will befall them, and they cannot escape.

# 4110

Do they not know that Allah eases the sustenance for whomever He wills, and restricts it? Indeed in this are signs for the People who Believe.

# 4111

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “O my\* slaves, who have wronged themselves, do not lose hope in Allah’s mercy; indeed Allah forgives all sins; indeed He only is the Oft Forgiving, the Most Merciful.” (All Muslims are truly the slaves of Prophet Mohammed – peace and blessings be upon him.)

# 4112

“And incline towards your Lord and submit to Him, before the punishment comes you and then you may not be helped.”

# 4113

“And follow this, the best among all, which has been sent down towards you from your Lord, before the punishment comes suddenly upon you whilst you are unaware.”

# 4114

So that no soul may say, “Alas! The failures that I committed regarding Allah – and indeed I used to mock!”

# 4115

Or (so that no soul) may say, “If Allah had shown me the right path, I would then be among the pious!”

# 4116

Or (so that no soul) may say when it beholds the punishment, “If only I may be sent back, so that I may do good deeds!”

# 4117

It will be said to him, “Surely yes, why not?\* My signs did come to you, so you denied them and you were haughty and you were a disbeliever.” (They will be mocked at.)

# 4118

And you will see on the Day of Resurrection the fabricators of lies against Allah, with their faces blackened; is not the destination of the haughty in hell?

# 4119

And Allah will rescue the pious, to their place of salvation; neither will the punishment touch them, nor shall they grieve.

# 4120

Allah is Creator of all things; and He only is the Controller of all things.

# 4121

For Him only are the keys of the heavens and the earth; and those who denied the signs of Allah – it is they who are the losers.

# 4122

Say (O dear Prophet Mohammed – peace and blessings be upon him) “So do you instruct me to worship (deities) other than Allah? You ignorant fools!”

# 4123

And it was indeed revealed to you and to those before you; that, “O listener! If you ascribe a partner to Allah, all your deeds will go to waste and you will surely be a loser.”

# 4124

But rather worship only Allah, and be among the thankful!

# 4125

And they did not realise the importance of Allah as was His right; and on the Day of Resurrection, He will compress the lands and the heavens will be rolled up by His power; Purity and Supremacy are to Him, from all what they ascribe as partners.

# 4126

And the Trumpet will be blown, so everyone in the heavens and everyone in the earth will fall unconscious, except whomever\* Allah wills; it will then be blown again, thereupon they will get up staring! (\*Prophet Moosa and / or some angels).

# 4127

And the earth will shine bright by the light of its Lord, and the Book will be established, and the Prophets and this Noble Prophet and the witnesses upon them from this nation will be brought, and it will be judged between them with the truth, and they will not be wronged.

# 4128

And every soul will be repaid for its deeds in full, and He knows very well what they used to do.

# 4129

And the disbelievers will be herded towards hell in groups; to the extent that when they reach it, its gates will be opened, and its guards will say to them, “Did not the Noble Messengers come to you from amongst you, who used to recite to you the verses of your Lord and warn you of confronting this Day?” They will say, “Yes indeed, why not?” But the Word of punishment proved true upon the disbelievers.

# 4130

It will be said, “Enter the gates of hell to remain in it forever”; so what a wretched destination for the haughty!

# 4131

And the mounts of those who feared their Lord will be led towards Paradise, in groups; to the extent that when they reach it, its gates will be opened and its guards will say to them, “Peace be upon you! You have done well! Therefore enter Paradise, to abide in it forever.”

# 4132

And they will say, “All praise is to Allah, Who has made His promise to us come true, and has bequeathed us this land, to stay in Paradise wherever we wish!” So what an excellent reward for the performers!

# 4133

And you will see the angels gathered around the Throne, saying the Purity of their Lord, with praise; and a true judgement will be delivered between the people, and it will be said, “All praise is to Allah, the Lord Of The Creation!”

# 4134

Ha-Meem. (Alphabets of the Arabic Language – Allah, and to whomever he reveals, know their precise meanings.)

# 4135

The revelation of the Book is from Allah, the Most Honourable, the All Knowing.

# 4136

The Forgiver of sin, and the Most Acceptor of Repentance, the Severe in Punishing, the Greatly Rewarding; there is no God except Him; towards Him only is the return.

# 4137

None except the disbelievers dispute the signs of Allah, therefore do not let their free movements in the land deceive you.

# 4138

Before them, the people of Nooh and the groups after them had denied; and every nation intended to apprehend its Noble Messenger, and they fought along with falsehood to avert the truth, so I seized them; so how did My punishment turn out?

# 4139

And this is how the Word of your Lord has proved true upon the disbelievers that they are people of the hell.

# 4140

Those\* who bear the Throne, and those who are around it, say the Purity of their Lord while praising Him, and they believe in Him and seek forgiveness for the believers; “O Our Lord! Your mercy and knowledge encompass all things, therefore forgive those who repented and followed Your path, and save them from the punishment of hell.” (\* The angels.)

# 4141

“O Our Lord! And admit them into the Gardens of everlasting stay which you have promised them, and those who are virtuous among their forefathers and their wives and their offspring; indeed You only are the Most Honourable, the Wise.”

# 4142

“And save them from the evil consequences of sins; and whomever You save from the evil consequences of sins on that Day – so You have indeed had mercy upon him; and this only is the greatest success.”

# 4143

The disbelievers will indeed be called out to – “Indeed Allah’s disgust with you is greater than your own abhorrence of yourselves, whereas you used to deny when you were called towards the faith!”

# 4144

They will say, “O Our Lord! Twice You have given us death and twice You have given us life\* – we now confess to our sins – so is there a way out of the fire?” (From nothingness to life in this world, to death and then Resurrection.)

# 4145

“This has occurred because when Allah the One was prayed to, you used to disbelieve; and when a partner was ascribed with Him, you used to believe; so the command is only for Allah, the Supreme, the Great.”

# 4146

It is He Who shows you His signs, and sends down sustenance from the sky for you; and none accept guidance except those who incline (towards Him).

# 4147

Therefore worship Allah, as His sincere bondmen even if the disbelievers get annoyed.

# 4148

Bestower of High Ranks, Owner of the Throne; it is He Who instils the spirit of faith into the one He wills among His bondmen, in order that he may warn of the Day of Meeting. –

# 4149

A day when they will be fully exposed; nothing from their affairs will be hidden from Allah; “For whom is the kingship this day? For Allah, the One, the All Dominant.”

# 4150

This day each soul will be repaid for what it has earned; no one will be wronged this day; indeed Allah is Swift At Taking Account.

# 4151

And warn them of the day of impending calamity, when hearts will rise up to the throats filled with grief; and the disbelievers will have neither any friend nor any intercessor who will be obeyed. (Intercession will be accepted only for the Muslims, not for the disbelievers)

# 4152

Allah well knows the covert glance and all what lies hidden in the hearts.

# 4153

And Allah renders the true judgement; and those whom they worship instead of Him do not judge at all; indeed Allah only, is the All Hearing, the All Seeing.

# 4154

So did they not travel in the land in order to see what sort of fate befell those before them? Their strength and the signs they left behind in the earth, exceeded them – so Allah seized them on account of their sins, and they had no one to save them from Allah.

# 4155

This occurred because their Noble Messengers came to them with clear signs, thereupon they used to disbelieve, so Allah seized them; indeed Allah is All Powerful, Severe in Punishment.

# 4156

And indeed We sent Moosa with Our signs and a clear proof.

# 4157

Towards Firaun and Haman and Qaroon – in response they said, “(He is) a magician, a big liar!”

# 4158

So when he brought the truth from Our presence to them, they said, “Kill the sons of those who believe in him, and keep their women alive”; and the evil scheme of the disbelievers only keeps wandering astray.

# 4159

And said Firaun, “Allow me to kill Moosa and let him pray to his Lord; I fear that he will change your religion or cause chaos in the land!”

# 4160

Said Moosa, “I seek the refuge of mine and your Lord, from every haughty person who does not believe in the Day of Reckoning.”

# 4161

And said a Muslim man from the people of Firaun, who used to hide his faith, “What! You want to kill a man just because he says, ‘Allah is my Lord’ whereas he has indeed brought clear signs to you from your Lord? And supposedly if he is speaking wrongly, then the calamity of wrongful speech is upon him; and if he is truthful, then part of what he promises you will reach you; indeed Allah does not guide any transgressor, excessive liar.”

# 4162

“O my people! You now rule the earth, dominant; so who will save us from Allah’s punishment if it comes upon us?” Said Firaun, “I only explain to you what I think is correct, and I show you only the right path.”

# 4163

And the believer said, “O my people! I fear for you a day similar to that of the earlier groups!”

# 4164

“Like the tradition of the people of Nooh, and Aad, and Thamud and others after them; and Allah does not will injustice upon bondmen.”

# 4165

“O my people! I fear for you a day on which will be a great outcry!”

# 4166

“A day when you will turn back fleeing; none can save you from Allah; and whomever Allah sends astray, there is no guide for him.”

# 4167

“And indeed Yusuf came to you with clear signs before this, thereupon you remained doubtful concerning what he had brought; to the extent that when he died, you said, ‘Allah will surely not send any Noble Messenger after him’”; this is how Allah sends astray whoever transgresses, is doubtful. –

# 4168

Those who dispute regarding the signs of Allah without any proof having come to them; how very disgusting this is, in the sight of Allah and in the sight of the believers! This is how Allah seals the entire heart of every haughty, rebellious person.

# 4169

And said Firaun, “O Haman! Build a high palace for me, in order that I may reach the routes.” –

# 4170

“The routes of the heavens, in order to glance at the God of Moosa – and indeed I think he is a liar”; this is how the evil deeds of Firaun were made seeming good to him, and he was stopped from the path; and the evil scheme of Firaun was destined to be ruined.

# 4171

And the believer said, “O my people! Follow me, I shall show you the way of righteousness.”

# 4172

“O my people! The life of this world is just a brief usage, and indeed the next abode is one of everlasting stay.”

# 4173

“Whoever commits an evil deed will not be repaid except to the same extent; and whoever does good deeds, whether a man or a woman, and is a Muslim, will be admitted into Paradise, in which they will receive sustenance without account.”

# 4174

“And O my people! What is the matter with me that I call you towards salvation whereas you call me towards hell?”

# 4175

“You call me to disbelieve in Allah and ascribe such as partners to Him, regarding whom I do not have any knowledge – whereas I call you towards the Most Honourable, the Oft Forgiving!”

# 4176

“So it is self evident that what you call me towards has no benefit being prayed to, either in this world or in the Hereafter, and that our return is towards Allah, and that the transgressors only are the people of the fire.”

# 4177

“And soon the time will come when you will remember what I now say to you; and I entrust my tasks to Allah; indeed Allah sees the bondmen.”

# 4178

Therefore Allah saved him from the evils of their scheming, and an evil punishment enveloped the people of Firaun. –

# 4179

The fire – upon which they are presented morning and evening; and when the Last Day is established – “Put the people of Firaun into the most severe punishment.” (Punishment in the grave is proven by this verse.)

# 4180

And when they will quarrel amongst themselves in the fire, those who were weak will say to those who sought greatness, “We were your followers, so will you reduce from us some of the punishment of the fire?”

# 4181

Those who were proud will say, “We are all in the fire – indeed Allah has already passed the judgement among the bondmen.”

# 4182

And those who are in the fire said to its guards, “Pray to your Lord to decrease the punishment upon us for one day.”

# 4183

They said, “Is it not that your Noble Messengers used to come to you with clear signs?” They said, “Why not, surely yes!” They said, “Then you yourselves pray”; and the prayer of the disbelievers is nothing but astray.

# 4184

Indeed We will surely help Our Noble Messengers, and the believers, in the life of this world and on the day when the witnesses will be standing.

# 4185

The day on which the unjust will not gain any benefit from their excuses, and for them is the curse, and for them is the wretched home.

# 4186

And indeed We gave Moosa the guidance, and bequeathed the Book to the Descendants of Israel.

# 4187

A guidance and an advice for the people of intellect.

# 4188

Therefore be patient (O dear Prophet Mohammed – peace and blessings be upon him), undoubtedly Allah’s promise is true, and seek forgiveness for the sins of your own people, and praising your Lord, proclaim His Purity morning and evening.

# 4189

Those who dispute concerning the signs of Allah without any proof having come to them – in their hearts is nothing but a craving for greatness which they shall never achieve; therefore seek the refuge of Allah; indeed He only is the All Hearing, the All Seeing.

# 4190

Certainly the creation of the heavens and the earth is far greater than the creation of men, but most people do not know.

# 4191

And the blind and the sighted are not equal – and neither are the believers who perform good deeds and the wicked equal; how very little do you ponder!

# 4192

Indeed the Last Day will surely come, there is no doubt in it – but most people do not accept faith.

# 4193

And your Lord proclaimed, “Pray to Me, I will accept; indeed those who stay conceited towards worshipping Me, will enter hell in disgrace."

# 4194

It is Allah Who created night for you so that you may gain rest in it, and the day giving sight; indeed Allah is Most Munificent towards mankind, but most people do not give thanks.

# 4195

Such is Allah, your Lord, the Creator of all things; there is no God except Him; so where are you reverting?

# 4196

This is how those who deny the signs of Allah go reverting.

# 4197

It is Allah Who made for you the earth your resting place and the sky a canopy, and moulded you so gave you the best shape, and gave you pure things for sustenance; such is Allah, your Lord; so Most Auspicious is Allah, the Lord Of The Creation.

# 4198

It is He, the Alive – there is no God except Him; therefore worship Him as His sincere bondmen; all praise is to Allah, the Lord Of The Creation.

# 4199

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I have been forbidden to worship those whom you worship besides Allah whilst clear proofs have come to me from my Lord; and I have been commanded to submit to the Lord Of The Creation.”

# 4200

It is He Who created you from clay, then from a drop of liquid, then from a clot of blood, and then brings you forth as a child, then keeps you alive for you to reach adulthood and then to become old; and some among you pass away earlier, and for you to reach an appointed term, and so that you may understand.

# 4201

It is He Who gives life and death; so whenever He wills a thing, He only says to it “Be” – it thereupon happens!

# 4202

Did you not see those who dispute concerning the signs of Allah? Where are they being diverted?

# 4203

Those who denied the Book and what We sent with Our Noble Messengers; so they will soon come to know. –

# 4204

When around their necks will be shackles and chains; they will be dragged. –

# 4205

In boiling water; they will then be ignited\* in the fire. (Like fuel – see verse 2:24)

# 4206

It will then be said to them, “Where are the partners you used to appoint?” –

# 4207

“As rivals to Allah?”; they will say, “We have lost them – in fact we never used to worship anything before!”; this is how Allah sends the disbelievers astray.

# 4208

“This is the recompense of your being happy upon falsehood in the earth, and the recompense of your conceit.”

# 4209

“Enter the gates of hell, to remain in it forever”; so what a wretched destination for the haughty!

# 4210

Therefore be patient (O dear Prophet Mohammed – peace and blessings be upon him), undoubtedly Allah’s promise is true; and whether We show some of what We promise them, or cause you to pass away before it – in any case they will return to Us.

# 4211

Indeed We sent many Noble Messengers before you, so We have related to you the affairs of some among them, and not related the affairs of some; and no Noble Messenger has the right to bring any sign except with the command of Allah; so the time when the command of Allah comes, the true judgement will be delivered and there will the people of falsehood be ruined.

# 4212

It is Allah Who created the animals for you, in order for you to ride some of them, and some to eat.

# 4213

And in them are numerous benefits for you, and for you to reach your hearts’ desires while riding them – and you ride upon them and upon the ships.

# 4214

And He shows you His signs; so which sign of Allah will you deny?

# 4215

Did they not travel in the land to see what sort of fate befell those before them? They were more than these in number, and they exceeded them in strength and the signs they left behind in the earth – so what benefit did they get from what they earned?

# 4216

So when their Noble Messengers came to them with clear signs, they remained happy over the worldly knowledge they possessed, and upon them only reverted what they used to mock at!

# 4217

So when they saw Our punishment, they said, “We accept faith in the One Allah, and reject those whom we ascribed with Him.”

# 4218

So their accepting of faith did not benefit them when they saw Our punishment; the tradition of Allah which has passed among His bondmen; and there were the disbelievers ruined.

# 4219

Ha-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4220

This (Qur’an) is sent down from the Most Gracious, the Most Merciful.

# 4221

A Book the verses of which are explained in detail, the Qur’an in Arabic for people of intellect.

# 4222

Giving glad tidings and heralding warning; so most of them turned away, therefore they cannot listen (to the truth).

# 4223

And they say, “Our hearts are covered against the affair you call us to, and there is deafness in our ears, and there is a barrier between us and you – therefore mind your own business, we are minding ours.”

# 4224

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Physically I am a human like you – I receive the divine revelation that your God is only One God, therefore be upright towards Him and seek forgiveness from Him”; and woe is to the polytheists. –

# 4225

Those who do not give the obligatory charity, and who deny the Hereafter.

# 4226

Indeed for those who believed and did good deeds, is a limitless reward.

# 4227

Say “What! You disbelieve in Him Who created the earth in two days, and you appoint equals to Him? He is the Lord Of The Creation!”

# 4228

And in it He placed mountains as anchors from above it, and blessings in it, and appointed the sustenance for those who dwell in it – all this in four days; a proper answer to those who question.

# 4229

He then inclined towards the heavens and it was smoke – thereupon He said to it and to the earth, “Both of you present yourselves, willingly or with reluctance”; they said, “We present ourselves, with zeal.”

# 4230

He then established them into seven heavens in two days, and to each heaven He sent the command of its affairs; and We decorated the lower heaven with lamps; and for its protection; this is the command set by the Most Honourable, the All Knowing.

# 4231

Then if they turn away say, “I warn you of a thunderbolt like the thunderbolt which came upon A’ad and Thamud.”

# 4232

When their Noble Messengers approached them from front and from behind saying, "Do not worship any one except Allah"; they said, "If our Lord willed, He would surely have sent down angels – we therefore deny whatever you have been sent with.”

# 4233

So regarding the A’ad, they were haughty in the land without right, and they said, “Who is more powerful than us?” Did they not realise that Allah, Who created them, is more powerful than them? And they used to deny Our signs.

# 4234

We therefore sent a violent thunderstorm towards them in their days of misfortune, in order to make them taste a disgraceful punishment in the life of this world; and indeed the punishment of the Hereafter is more disgracing, and they will not be helped.

# 4235

And regarding the Thamud, We showed them the right path – so they chose to be blind above being guided, therefore the thunderbolt of the disgraceful punishment overcame them – the recompense of their deeds.

# 4236

And We rescued those who accepted faith and were pious.

# 4237

And on the day when the enemies of Allah are herded towards the fire, the earlier groups will be restrained till the latter join them.

# 4238

To the extent that when they reach it, their ears and their eyes and their skins will testify against them for what they used to do.

# 4239

And they will say to their skins, “Why did you testify against us?"; they will say, “Allah has made us talk, Who has given all things the power of speech, and it is He Who created you the first time, and it is to Him that you have to return.”

# 4240

And where could you hide from Him, so that your ears and your eyes and your skins may not testify against you? But you had assumed that Allah does not know most of your deeds!

# 4241

And this is the assumption you had regarding your Lord, which has ruined you, so you are now among those who have been defeated.

# 4242

Then if they are patient, even then the fire is their home; and if they plead, none will listen to their pleading.

# 4243

And We appointed companions for them, who made what is before them and what is after them seem good to them, and the Word proved true upon them along with the groups of jinns and men who passed away before them; they were indeed losers.

# 4244

And the disbelievers said, “Do not listen to this Qur’an and engulf it in noise – perhaps you may be victorious this way.”

# 4245

So We will indeed make the disbelievers taste the severe punishment, and indeed We will repay them for their worst deeds.

# 4246

This is the recompense of Allah’s enemies – the fire; they have to stay in it forever; the penalty for denying Our signs.

# 4247

And the disbelievers said, “Our Lord! Show us both – among jinns and men – who misled us, for us to put them beneath our feet so that they be the lowest of the low.”

# 4248

Indeed those who said, “Allah is our Lord” and remained firm upon it – upon them descend the angels, (saying), “Do not fear nor grieve, and be happy for the Paradise which you are promised.”

# 4249

“We are your friends in the life of this world and in the Hereafter; in it for you is all that you may wish for, and for you is all what you ask.”

# 4250

“The hospitality of the Oft Forgiving, Most Merciful.”

# 4251

And whose speech is better than one who calls towards his Lord and does righteous deeds, and says, “I am a Muslim.”?

# 4252

And the good deed and the evil deed will never be equal; O listener! Repel the evil deed with a good one, thereupon the one between whom and you was enmity, will become like a close friend.

# 4253

And none receive this great treasure except those who are patient; and none receives this except one who is extremely fortunate.

# 4254

And O listener! If a distracting thought from the devil reaches you, seek the refuge of Allah; indeed He is the All Hearing, the All Knowing.

# 4255

And the night, and the day, and the sun, and the moon are among His signs; do not prostrate for the sun or the moon, but prostrate for Allah Who has created them, if you are His bondmen.

# 4256

So if these (disbelievers) be haughty, so (in any case) those (the angels) who are with your Lord say His Purity night and day, and they do not get weary. (Command of prostration # 11)

# 4257

And among His signs is that you see the earth lying neglected, so when We sent down water on it, it freshened up and grew forth; indeed He Who gave it life, will revive the dead; indeed He is Able to do all things.

# 4258

Indeed those who distort Our verses are not hidden from Us; so is one who is cast into the fire better, or one who comes in safety on the Day of Resurrection? Do whatever you wish! He is indeed seeing your deeds.

# 4259

Indeed those who denied the Remembrance when it came to them – they are truly ruined; and indeed it is an honourable Book.

# 4260

Falsehood cannot approach it – neither from its front nor from its back; it is sent down by the Wise, the Most Praiseworthy.

# 4261

You will not be told except what was said to the Noble Messengers before you; that “Your Lord is the Owner of Forgiveness, and the Owner of Painful Punishment.”

# 4262

And if We had made it as a Qur’an in a foreign language they would have certainly said, “Why were its verses not explained in detail?” What! The Book in a foreign language, and the Prophet an Arab?! Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “It is a guidance and a cure for the believers”; and there is deafness in the ears of those who do not believe, and it is blindness upon them; as if they are being called from a place far away!

# 4263

And We indeed gave the Book to Moosa, so a dispute was created regarding it; and were it not for a Word that had already gone forth from your Lord, the judgement would have been immediately passed upon them; and indeed they are in an intriguing doubt regarding it.

# 4264

Whoever does good deeds, so it is for his own good, and whoever commits evil, so it is for his own harm; and your Lord does not at all oppress the bondmen.

# 4265

The knowledge of the Last Day is directed towards Him; and no fruit comes out from its cover, and nor does any female conceive or give birth, but with His knowledge; and on the day when He will call out to them, “Where are My partners?” They will say, “We have told you that none among us can testify.”

# 4266

And they have lost what they used to worship before, and be sure, they do not have a place to escape.

# 4267

Man does not weary of seeking goodness; and if some misfortune reaches him, he loses hope, gets disappointed.

# 4268

And if We make him taste Our mercy after the hardship which befell him, he will say, “This is mine! And I do not think that the Last Day will ever be established – and even if I am returned to my Lord, with Him is only goodness for me”; so We shall indeed inform the disbelievers of what they did; and We shall indeed make them taste a solid punishment.

# 4269

And when We favour man, he turns away and goes back afar; and when some hardship reaches him, he comes with a vast prayer!

# 4270

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “What is your opinion – if this Qur’an is from Allah and then you deny it – so who is more astray than whoever is in extreme opposition?”

# 4271

We shall now show them Our signs in all the directions and within their own selves until it becomes clear to them that it is certainly the truth; is not your Lord sufficient as a Witness over all things?

# 4272

Pay heed! They are certainly doubtful regarding the meeting with their Lord; pay heed! He encompasses all things!

# 4273

Ha-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4274

A’in-Seen-Qaf. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4275

This is how Allah the Most Honourable, the All Knowing sends the divine revelation to you (O dear Prophet Mohammed – peace and blessings be upon him) and to those before you.

# 4276

To Him only belongs all whatever is in the heavens and all whatever is in the earth; and He is the Supreme, the Greatest.

# 4277

The heavens nearly split apart from above – and the angels say the Purity of their Lord while praising Him, and seek forgiveness for those on earth; pay heed! Indeed Allah only is the Oft Forgiving, the Most Merciful.

# 4278

And Allah is watching those who have chosen supporters besides Him; and you are not responsible for them.

# 4279

And this is how We have divinely revealed to you the Qur’an in Arabic, for you to warn the people of the mother of all towns – Mecca – and those around it, and to warn of the Day of Assembling of which there is no doubt; a group is in Paradise, and another group is in hell.

# 4280

And had Allah willed, He could have made them all upon one religion, but He admits whomever He wills into His mercy; and the unjust do not have any friend nor any supporter.

# 4281

What! Have they appointed supporters other than Allah? So (know that) Allah only is the Supporter, and He will revive the dead; and He is Able to do all things.

# 4282

“The final decision for the matters in which you differ rests with Allah; such is my Lord – I rely on Him; and towards Him do I incline.”

# 4283

The Maker of the heavens and the earth; He has created pairs for you from yourselves and pairs from the animals; He spreads your generation; nothing is like Him; and He only is the All Hearing, the All Seeing.

# 4284

For Him only are the keys of the heavens and the earth; He increases the sustenance for whomever He wills and restricts it; indeed He is the All Knowing.

# 4285

He has kept for you the same path of religion which He commanded Nooh, and what We divinely reveal to you (O dear Prophet Mohammed – peace and blessings be upon him), and what We had commanded to Ibrahim and Moosa and Eisa that, “Keep the religion proper, and do not create divisions in it”; the polytheists find the matter what you call them to as intolerable; Allah chooses for His proximity whomever He wills, and guides towards Himself whoever inclines (towards Him).

# 4286

And they did not cause divisions except after the knowledge had come to them, because of jealousy among themselves; and were it not for a Word that had already gone forth from your Lord, the judgement would have been passed upon them long ago; and indeed those who inherited the Book after them are in an intriguing doubt regarding it.

# 4287

For this reason, call them (to Islam); and remain firm, as you are commanded to; and do not follow their desires; and say, “I accept faith in whichever Book Allah has sent down; and I am commanded to judge fairly between you; Allah is the Lord of all – ours and yours; for us are our deeds and for you are your misdeeds; there is no debate between us and you; Allah will gather all of us together; and towards Him is the return.”

# 4288

And those who fight regarding Allah after the Muslims have accepted His call, their reasoning does not hold at all before their Lord, and upon them is wrath, and for them is a severe punishment.

# 4289

It is Allah Who has sent down the Book with the truth, and the Scales of Justice; and what do you know – possibly the Last Day could really be near!

# 4290

Those who do not believe in it are impatient for it, and those who believe in it fear it and know that indeed it is the truth; pay heed! Those who doubt the Last Day are certainly in extreme error.

# 4291

Allah is Benevolent upon His bondmen – He bestows sustenance to whomever He wills; and He only is the All Powerful, the Most Honourable.

# 4292

Whoever aspires for the yield of the Hereafter – We increase its yield for him; and whoever aspires for the yield of this world – We give him part of it, and he has no portion in the Hereafter.

# 4293

Or do they have associate deities who have appointed for them a religion, which Allah has not permitted? And were it not for a Word that had already been decided, the judgement would have been passed between them here itself; and indeed for the unjust is a painful punishment.

# 4294

You will see the unjust getting terrified of their own deeds, and (evil of) their deeds will certainly befall them; and (that) those who accepted faith and performed good deeds are in blossoming Gardens of Paradise; for them is whatever they wish from their Lord; this only is the great munificence (of Allah).

# 4295

This is what Allah gives the glad tidings of to His bondmen who accept faith and do good deeds; say (O dear Prophet Mohammed – peace and blessings be upon him) “I do not ask any fee from you upon this, except the love between close ones”; and whoever performs a good deed – We further increase the goodness in it for him; indeed Allah is Oft Forgiving, Most Appreciative.

# 4296

What! They dare say that, “He has fabricated a lie against Allah”? And if Allah wills, He can seal your heart by His mercy and protection\*; and Allah wipes out falsehood and proves the truth by His Words; indeed He knows what lies within the hearts. (\* So that you may not be agonised by what they do).

# 4297

And it is He Who accepts repentance from His bondmen, and pardons sins\*, and knows all your deeds. (Repentance for the cardinal sins, while lesser sins are wiped out by good deeds.)

# 4298

And He accepts the prayers of those who accept faith and do good deeds, and gives them a greater reward by His munificence; and for the disbelievers is a severe punishment.

# 4299

And had Allah increased the sustenance for all His slaves, they would have surely caused turmoil in the land, but He sends it down by a proper assessment as He wills; indeed He is Well Aware of, Seeing His bondmen.

# 4300

And it is He Who sends down the rain when they have despaired, and spreads out His mercy; and He is the Benefactor, the Most Praiseworthy.

# 4301

And among His signs is the creation of the heavens and the earth, and the moving creatures dispersed in it; and He is Able to gather them whenever He wills.

# 4302

And whatever calamity befalls you, is because of what your hands have earned – and there is a great deal He pardons!

# 4303

And you cannot escape in the earth; and you have neither a friend nor any supporter against Allah.

# 4304

And among His signs are the ships sailing on the sea, like hills.

# 4305

If He wills, He can calm the winds so the ships remain still on the sea surface; indeed in this are signs for every greatly enduring, grateful person.

# 4306

Or He can ruin them due to peoples’ sins and He can forgive a great deal.

# 4307

And for those who dispute regarding Our signs to realise; that they do not have a place to escape to.

# 4308

Whatever you have received is only for usage in the life of this world, and that which is with Allah is much better and more lasting – for those who believe and rely upon their Lord.

# 4309

And (for) those who avoid cardinal sins and indecencies, and forgive (even) when they are angry.

# 4310

And those who obeyed the command of their Lord and kept the prayer established; and whose affairs are with mutual consultation; and who spend in Our cause from what We have bestowed upon them.

# 4311

And those who take revenge when rebellion harms them.

# 4312

The retribution of a harmful deed is the harm equal to it; so whoever forgives and makes amends, so his reward is upon Allah; indeed He does not befriend the unjust.

# 4313

And there is no way of reproach against those who take revenge after being wronged.

# 4314

Reproach is only against those who oppress people, and wrongfully spread rebellion in the land; for them is a painful punishment.

# 4315

And indeed whoever patiently endured and forgave – then indeed these are acts of great courage.

# 4316

And whomever Allah sends astray, there is no friend for him against Allah; and you will see the unjust when they behold the punishment saying, “Is there a way to return?”

# 4317

And you will see them being presented upon the fire, cowering with disgrace watching with concealed eyes; and the believers will say, “Indeed ruined are those who have lost themselves and their families on the Day of Resurrection”; pay heed! Indeed the unjust are in a punishment that will never end.

# 4318

And they had no friends to help them against Allah; and there is no way for one whom Allah sends astray.

# 4319

Obey your Lord before the advent of a Day from Allah, which cannot be averted; you will not have any refuge on that day, nor will you be able to deny.

# 4320

So if they turn away from you, We have not sent you as a guardian over them; upon you is nothing but to convey (the message); and when We make man taste some mercy from Us, he rejoices upon it; and if some harm reaches them because of what their own hands have sent before, thereupon man is ungrateful!

# 4321

For Allah only is the kingship of the heavens and the earth; He creates whatever He wills; He may bestow daughters to whomever He wills, and sons to whomever He wills.

# 4322

Or may mix them, the sons and daughters; and may make barren whomever He wills; indeed He is All Knowing, Able.

# 4323

And it is not for any human that Allah may speak to him except as a divine revelation or while the human is on this side of the veil of greatness, or that He sends an angel to reveal by His permission, whatever He wills; indeed He is Supreme, Wise.

# 4324

And this is how We sent the divine revelation to you (O dear Prophet Mohammed – peace and blessings be upon him) – a life giving thing, by Our command; neither did you know the Book nor the detailed commands of religion, but We have made this Qur’an a light by which We guide whomever We will from Our bondmen; and indeed you surely do guide to the Straight Path.

# 4325

The path of Allah – the One to Whom only belongs all whatever is in the heavens and all whatever is in the earth; pay heed! Towards Allah only do all matters return.

# 4326

Ha-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4327

By oath of the clear Qur’an.

# 4328

We have indeed sent it as a Qur’an in the Arabic language, so that you may understand.

# 4329

And the Qur’an is undoubtedly, in the Original Book with Us, surely the exalted, full of wisdom.

# 4330

So shall We divert the advice away from you, because you are a nation that exceeds the limits?

# 4331

And how many Prophets We did send among the earlier people!

# 4332

And whenever any Prophet came to them, they only mocked at him.

# 4333

We therefore destroyed the people who were more forceful than these, and the example of the earlier ones has already gone by.

# 4334

And if you ask them, “Who has created the heavens and the earth?”, they will surely say, “They are created by the Most Honourable, the All Knowing.”

# 4335

The One Who made the earth a bed you, and made roads for you in it, so that you may be guided.

# 4336

And Who sent down water from the sky with a proper measure, so We revived a dead city with it; this is how you will be taken out.

# 4337

And the One Who created all pairs, and made the ships and cattle as rides for you.

# 4338

So that you may properly mount their backs, and may remember your Lord’s favour when you have mounted them, and say, “Purity is to Him, Who has given this ride in our control, and we did not have the strength for it.”

# 4339

“And indeed we have to return to our Lord.”

# 4340

And from\* His bondmen, they appointed a portion for Him; man is indeed an open ingrate. (\* Appointed some of His creation as His sons and daughters).

# 4341

Has He chosen daughters for Himself from His creation, and selected only sons for you?

# 4342

And if one of them is given the glad tidings of what he professes regarding the Most Gracious, his face blackens and he is mournful!

# 4343

And (do they chose for Him) one who is brought up among ornaments, and cannot express herself clearly in debate?

# 4344

And they appoint the angels, who are the bondmen of the Most Gracious, as females; were they present at the time of the angels’ creation? Their declaration will be now recorded and they will be questioned.

# 4345

And they say, “If the Most Gracious had willed, we would not have worshipped them!” They do not know its truth at all; they only make guesses.

# 4346

Or have We given them some Book before this, to which they hold fast?

# 4347

Rather they said, “We found our forefathers upon a religion, and we are following their footsteps.”

# 4348

And similarly, whenever We sent a Herald of Warning before you (O dear Prophet Mohammed – peace and blessings be upon him) into any town, its wealthy people said, “We found our forefathers upon a religion, and we are behind their footsteps.”

# 4349

The prophet said, “What! Even if I bring to you a path better than what you found your forefathers following?”; they said, “We do not believe in whatever you have been sent with.”

# 4350

So We took revenge from them – therefore see what sort of fate befell those who denied!

# 4351

And when Ibrahim said to his father and his people, “I have no relation whatsoever with your deities.”

# 4352

“Except Him Who has created me, for He will soon direct me.” (To my place of migration.)

# 4353

And Ibrahim kept this declaration among his progeny, in order that they may desist.

# 4354

In fact I gave them and their forefathers the usage of this world until the truth and the Noble Messenger who conveyed the message clearly, came to them.

# 4355

And when the truth came to them they said, “This is magic, and we disbelieve in it.”

# 4356

And they said, “Why was the Qur’an not sent down upon some chieftain of these two great towns?” (The chiefs of Mecca and Taif).

# 4357

Are they the distributors of your Lord’s mercy? We have distributed among them their comforts in the life of this world, and gave high status to some over others so that they mock at each other; and the mercy of your Lord is better than all what they hoard.

# 4358

And were it not for that all people be on one religion, We would have made for the disbelievers of the Most Gracious, roofs and stairs of silver which they would climb.

# 4359

And doors of silver for their houses and couches of silver upon which they would recline.

# 4360

And diverse adornments; and all this is usage only of the life of this world; and the Hereafter with your Lord, is for the pious.

# 4361

And whoever is averse to the Remembrance of the Most Gracious, We appoint a devil upon him, who stays with him.

# 4362

And indeed those devils prevent them from the Straight Path, and they think they are on guidance!

# 4363

To the extent that when the disbeliever will be brought to Us, he will say to his devil, “Alas – if only there was the distance\* of east and west, between you and me!” – so what an evil companion\*\* he is! (\* Had I not listened to you. \*\*They will be bound together in chains.)

# 4364

(It will be said to them) “And you will not benefit from them this day, whereas you are unjust – for you are all partners in the punishment.”

# 4365

So will you make the deaf listen or show the path to the blind, and to those who are in open error? (The disbelievers whose hearts are sealed, are deaf and blind to the truth).

# 4366

So if We take you away, We shall then indeed take revenge from them.

# 4367

Or show you what We have promised them – We therefore have complete control over them.

# 4368

Therefore hold fast to what We have divinely revealed to you; indeed you are upon the Straight Path. (The Holy Prophets can never go astray).

# 4369

And it is undoubtedly an honour for you and your people; and you will soon be questioned.

# 4370

And ask them – did any of the Noble Messengers We sent before you, appoint any other Gods except the Most Gracious, whom they used to worship?

# 4371

And indeed We sent Moosa along with Our signs towards Firaun and his chieftains – he therefore said, “Indeed I am a Noble Messenger of the Lord of the Creation.”

# 4372

So when he brought Our signs to them, they started mocking at them!

# 4373

And all the signs We showed them were always greater than the earlier ones; and We seized them with calamities, so that they may return.

# 4374

And they said, “O you magician! Pray for us to your Lord, by the means of His covenant which is with you; we will certainly come to guidance.”

# 4375

So when We averted the calamity from them, they immediately broke the promise!

# 4376

And said Firaun, “O my people! Is not the kingdom of Egypt for me, and these rivers that flow beneath me? So do you not see?”

# 4377

“Or that I am better than him, for he is lowly – and he does not seem to talk plainly.”

# 4378

“So why was he not bestowed with armlets of gold? Or angels should have come with him staying at his side!”

# 4379

So when he had brainwashed his people, they followed him; indeed they were a disobedient nation.

# 4380

So when they made Us wrathful, We took revenge from them – We therefore drowned all of them.

# 4381

So We made them a bygone fable and a lesson for the latter generations.

# 4382

And when the example of the son of Maryam is given, your people laugh at it!

# 4383

And they say, “Are our deities better or he?” They did not say this to you except to unjustly argue; in fact they are a quarrelsome people.

# 4384

He is purely a bondman (of Ours), whom We have favoured upon, and We made him an extraordinary example for the Descendants of Israel.

# 4385

And if We willed, We could have established angels on the earth instead of you.

# 4386

And indeed Eisa is a sign\* of the Last Day, therefore do not ever doubt in the Last Day, and obey Me\*\*; this is the Straight Path. (\* The advent of Prophet Eisa to earth for the second time. \*\* By obeying the Noble Messenger.)

# 4387

And do not ever let the devil stop you; he is indeed your open enemy.

# 4388

And when Eisa came to them with clear signs, he said, “I have come to you with wisdom, and to explain to you some of the matters regarding which you dispute; therefore fear Allah, and obey me.”

# 4389

“Allah is indeed my Lord, and yours – therefore worship Him; this is the Straight Path.”

# 4390

Then the groups differed amongst themselves; therefore ruin is for the unjust by the punishment of an agonising day.

# 4391

What are they waiting for – except the Last Day, that it may suddenly come upon them while they are unaware?

# 4392

Close friends will turn into enemies of one another on that Day, except the pious.

# 4393

To such will be said, “O My bondmen! This day there shall be no fear upon you, nor any grief.”

# 4394

Those who believed in Our signs, and were Muslims.

# 4395

“Enter Paradise – you and your wives – and you will be honoured guests.”

# 4396

“Rounds of golden cups and wine will be presented upon them; and in it is whatever the hearts wish for, and what pleases the eye; and you will stay in it forever.”

# 4397

“And this is the Paradise which is bequeathed to you, because of your deeds.”

# 4398

“For you are many fruits in it, for you to eat therefrom.”

# 4399

Indeed the criminals will stay in the punishment of hell forever.

# 4400

And it will never be lightened upon them, and they will remain in it devastated.

# 4401

And We did not oppress them at all, but they themselves were unjust.

# 4402

And they will cry out, “O Malik\*, ask your Lord to finish us!” He will answer, “Rather you are to stay (forever).” (\*The guard of hell)

# 4403

Indeed We have brought the Truth to you, but most of you detest the Truth.

# 4404

Do they assume that they have made their work thorough? So We shall make Our work thorough.

# 4405

Do they fancy that We do not listen to their whispers and their counselling? Why not, We surely do! And Our angels are with them, writing down.

# 4406

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “If supposedly, the Most Gracious had an offspring\* – I would be the first to worship!” (\*Which is impossible)

# 4407

Purity is to the Lord of the heavens and the earth, the Lord of the Throne, from all what they fabricate.

# 4408

Therefore leave them to utter vile speech and to play, until they confront the day which they are promised.

# 4409

And only He is the God of the heavenly creation and the God of the earthly creation; and He only is the Wise, the All Knowing.

# 4410

And Most Auspicious is He, for Whom is the kingship of the heavens and the earth and all that is between them; and only with Him is the knowledge of the Last Day; and towards Him you are to return.

# 4411

And those whom they worship besides Allah do not have the right of intercession – the right of intercession is only for those who testify to the Truth and have knowledge.

# 4412

And if you ask them as to Who created them, they will surely answer “Allah” – so where are they reverting?

# 4413

And by oath of the saying of My Prophet “O my Lord! These people do not accept faith!”

# 4414

Therefore excuse them and proclaim, “Peace”; for they will soon come to know.

# 4415

Ha-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4416

By oath of this clear Book.

# 4417

We have indeed sent it down in a blessed night – indeed it is We Who warn.

# 4418

During it are distributed all the works of wisdom.

# 4419

By a command from Us – indeed it is We Who send.

# 4420

A mercy from your Lord; indeed He only is the All Hearing, the All Knowing.

# 4421

The Lord of the heavens and the earth and all that is between them; if you people believe.

# 4422

There is no worship except for Him – He gives life and causes death; your Lord and the Lord of your forefathers.

# 4423

Rather they are in doubt, playing.

# 4424

So you await the day when the sky will bring forth a visible smoke. –

# 4425

Which will envelop the people; this is a painful punishment.

# 4426

Thereupon they will say, “O our Lord! Remove the punishment from us – we now accept faith.”

# 4427

How is it possible for them to accept guidance, whereas a Noble Messenger who speaks clearly has already come to them?

# 4428

Whereas they had then turned away from him and said, “He is a madman, tutored!”?

# 4429

We now remove the punishment for some days – so you will again commit the same.

# 4430

The day when We will seize with the greatest seizure – We will indeed take revenge.

# 4431

And before them We indeed tried the people of Firaun, and an Honourable Noble Messenger came to them.

# 4432

Who said, “Give the bondmen of Allah into my custody; I am indeed a trustworthy Noble Messenger for you.”

# 4433

And saying, “And do not rebel against Allah; I have brought a clear proof to you.”

# 4434

“And I take the refuge of my Lord and yours, against your stoning me.”

# 4435

“And if you do not believe in me, then have no relation with me.”

# 4436

He therefore prayed to his Lord, “These are a guilty nation!”

# 4437

We commanded him, “Journey with My bondmen in a part of the night – you will be pursued.”

# 4438

“And leave the sea as it is, parted in several places; indeed that army will be drowned.”

# 4439

How many gardens and water-springs they left behind!

# 4440

And fields and grand palaces!

# 4441

And favours amongst which they were rejoicing!

# 4442

That is what We did; and We made another nation their heirs.

# 4443

So the heavens and the earth did not weep for them, and they were not given respite.

# 4444

And indeed We rescued the Descendants of Israel from a disgraceful torture.

# 4445

From Firaun; he was indeed proud, among the transgressors.

# 4446

And We knowingly chose them, among all others of their time.

# 4447

And We gave them signs in which lay clear favours.

# 4448

Indeed these disbelievers proclaim; –

# 4449

“There is nothing except our dying just once, and we will not be raised.”

# 4450

“Therefore bring back our forefathers, if you are truthful!”

# 4451

Are they better, or the people of Tubba? And those who were before them? We destroyed them; they were indeed criminals.

# 4452

And We did not create the heavens and the earth, and all that is between them, just for play.

# 4453

We did not create them except with the truth, but most of them do not know.

# 4454

Indeed the Day of Decision is the appointment for all of them.

# 4455

The day on which, no friends will benefit each other at all, nor will they be helped. (Except those who are pious – see verse 43:67)

# 4456

Except those upon whom Allah has mercy; indeed He only is the Most Honourable, the Most Merciful.

# 4457

Indeed the tree of Zaqqum, –

# 4458

Is the food of the sinners.

# 4459

Like molten copper; it churns in their bellies.

# 4460

Like the churning of boiling water.

# 4461

“Seize him, and forcibly drag him right to the blazing fire.”

# 4462

“Then pour on his head the punishment of boiling water.”

# 4463

Saying “Taste it! Indeed you only are the most honourable, the dignified!”

# 4464

“Indeed this is what you used to doubt about.”

# 4465

Indeed the pious are in a place of peace.

# 4466

In Gardens and water-springs.

# 4467

They will be dressed in fine silk and embroidery, facing one another (on thrones).

# 4468

So it is; and We have wedded them to maidens with gorgeous eyes.

# 4469

In it they will ask for all kinds of fruit, with safety.

# 4470

They will not taste death again in it, except their former death; and Allah has saved them from the punishment of fire.

# 4471

By the munificence of your Lord; this is the great success.

# 4472

And We have made this Qur’an easy in your language, for them to understand.

# 4473

Therefore wait (O dear Prophet Mohammed – peace and blessings be upon him) – they too are waiting.

# 4474

Ha; Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4475

The sending down of the Book is from Allah, the Most Honourable, the Wise.

# 4476

Indeed in the heavens and the earth are signs for believers.

# 4477

And in your creation, and all the creatures He scatters in the earth – in them are signs for the people who are certain.

# 4478

And in the alternation of night and day, and in the means of sustenance – water – which Allah sends down from the sky whereby He gave life to the earth after its death, and in the movement of the winds – (in all these) are signs for people of intellect.

# 4479

These are the verses of Allah which We recite to you with the truth; so forsaking Allah and His signs, what will they believe in?

# 4480

Ruin is for every great slanderer, excessive sinner.

# 4481

Who hears the verses of Allah which are recited to him, then remains stubborn, proud, as if he did not hear them; therefore give him the glad tidings of a painful punishment.

# 4482

And when he comes to know about any of the verses, he mocks at it; for them is a disgraceful punishment.

# 4483

Hell is after them; and what they have earned will not benefit them at all, nor those whom they have chosen as supporters besides Allah; and for them is a terrible punishment.

# 4484

This is the (true) guidance; and for those who disbelieve in the verses of their Lord is the severest of painful punishments.

# 4485

It is Allah Who has subjected the sea for you so that ships may sail upon it by His command, and for you to seek His munificence, and so that you may give thanks.

# 4486

And has subjected for you all whatever is in the heavens and in the earth, by His command; indeed in this are signs for people who ponder.

# 4487

Tell the believers to ignore those who do not expect the days of Allah, in order that Allah may give a nation the reward of what they used to earn.

# 4488

Whoever does a good deed, so it is for his own good; and whoever commits evil, does for his own harm; and you will then be returned towards your Lord.

# 4489

And indeed We gave the Descendants of Israel the Book, and the rule, and the Prophethood, and gave good things for sustenance and gave them superiority over all others of their time.

# 4490

And We gave them clear proofs in the command; so they did not differ except after the knowledge had come to them – due to jealousy among themselves; indeed your Lord will judge between them on the Day of Resurrection concerning the matter in which they differ.

# 4491

We then placed you (O dear prophet Mohammed – peace and blessings be upon him) upon the clear path of the command, therefore continue following it and do not listen to the desires of the ignorant.

# 4492

Indeed they cannot benefit you at all against Allah; and indeed the unjust are the friends of each other; and Allah is the Friend of the pious.

# 4493

This is an enlightenment for mankind, and a guidance and mercy for the people of faith.

# 4494

Do those who commit evil assume that We will make them equal to those who believe and do good deeds, therefore both becoming equal in life and death? What an evil judgement they impose!

# 4495

And Allah has created the heavens and the earth with the truth, and so that every soul is repaid for what it has earned, and they will not be wronged.

# 4496

Just look at him who makes his desire as his God, and Allah has sent him astray despite his having knowledge, and set a seal upon his ears and his heart, and a covering upon his eyes; so who will guide him after Allah? So do you not ponder?

# 4497

And they said, “There is nothing except our life of this world – we die and we live – and nothing destroys us except the passage of time”; and they do not have any knowledge of it; they only make guesses.

# 4498

And when Our clear verses are recited to them, their only argument is, “Bring back our forefathers, if you are truthful!”

# 4499

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “It is Allah Who gives you life, then will give you death, then will gather you all on the Day of Resurrection in which there is no doubt, but most people do not know.”

# 4500

And to Allah only belongs the kingship of the heavens and the earth; and when the Last Day is established – on that day the followers of falsehood will suffer loss.

# 4501

And you will see every group down on its knees; every group will be called towards its book of deeds; “This day you will be repaid for what you did.”

# 4502

“This Book of Ours speaks against you with the truth; indeed We had been recording all what you did.”

# 4503

So those who believed and did good deeds – their Lord will admit them into His mercy; this is the clear triumph.

# 4504

And to those who disbelieved, it will be said “Was it not that Our verses were recited to you? In response you were haughty and were a guilty people.”

# 4505

“And when it was said, ‘Indeed Allah’s promise is true and there is no doubt regarding the Last Day”, you used to say, ‘We do not know what the Last Day is – we think it is nothing except an imagination, and we are not convinced.’”

# 4506

And the evils of their deeds appeared to them, and the punishment they used to mock at encompassed them.

# 4507

And it will be said, “This day We shall forsake you, the way you had forgotten the confronting of this day of yours – and your destination is the fire, and you do not have any supporters.”

# 4508

“This is because you mocked at the signs of Allah, and the worldly life deceived you”; so this day they are not to be removed from the fire, nor will anyone seek amends from them.

# 4509

So all praise is for Allah only, the Lord of the heavens and the Lord of the earth, the Lord of the Creation!

# 4510

And for Him only is the Greatness, in the heavens and in the earth; and He only is the Most Honourable, the Wise.

# 4511

Ha-Meem. (Alphabets of the Arabic language – Allah, and to whomever He reveals, know their precise meanings.)

# 4512

The sending down of this Book is from Allah the Most Honourable, the Wise.

# 4513

We did not create the heavens and the earth and all that is between them except with the truth, and for a fixed term; and the disbelievers have turned away from what they are warned!

# 4514

Proclaim, (O dear Prophet Mohammed – peace and blessings be upon him), “What is your opinion – regarding those whom you worship other than Allah – show me which part of the earth they have created, or do they own any portion of the heavens? Bring to me a Book preceding this (Qur’an), or some remnants of knowledge, if you are truthful.”

# 4515

And who is more astray than one who worships those, instead of Allah, who cannot listen to their prayer until\* the Day of Resurrection, and who do not even know of their worship! (Will never listen.)

# 4516

And on the day when people are gathered, they will become their enemies, and will reject their worshippers. (The idols will give testimony against the polytheists.)

# 4517

And when Our clear verses are recited to them, the disbelievers say regarding the Truth that has come to them, “This is an obvious magic!”

# 4518

What! They dare say, “He has fabricated it”? Say (O dear Prophet Mohammed – peace and blessings be upon him), “If I have fabricated it, then (I know that) you have no power to support me against Allah; He well knows the matters you are involved in; He is Sufficient as a Witness between me and you; and He only is the Oft Forgiving, the Most Merciful.”

# 4519

Say, “I am not something new\* among the Noble Messengers, nor do I know (on my own) what will happen to me\*\* or with you; I only follow that which is divinely revealed to me, and I am purely a Herald of clear warning. (\* I am like the earlier ones. \*\* My knowledge comes due to divine revelations.)

# 4520

Say, “What is your opinion – if the Qur’an is from Allah and you have rejected faith in it, and a witness among the Descendants of Israel has already testified upon this and accepted faith, while you became arrogant? Indeed Allah does not guide the unjust.”

# 4521

And the disbelievers said regarding the Muslims, “If there were any good in it, the Muslims would not have surpassed us in achieving it!”; and since they did not receive guidance with it, they will now say, “This is an old slander.”

# 4522

And whereas before this exists the Book of Moosa, a guide and a mercy; and this is a Book giving testimony, in the Arabic language, to warn the unjust; and to give glad tidings to the virtuous.

# 4523

Indeed those who said, “Allah is our Lord”, and then remained steadfast – upon them is neither any fear nor shall they grieve.

# 4524

They are the People of Paradise, abiding in it forever; the reward of their deeds.

# 4525

And We have commanded man to be good towards parents; his mother bore him with hardship, and delivered him with hardship; and carrying him and weaning him is for thirty months; until when he\* reached maturity and became forty years of age, he said, “My Lord! Inspire me to be thankful for the favours you bestowed upon me and my parents, and that I may perform the deeds pleasing to You, and keep merit among my offspring; I have inclined towards you and I am a Muslim.” (\* This verse was revealed concerning S. Abu Bakr – the first caliph, R. A. A)

# 4526

These are the ones whose good deeds We will accept, and overlook their shortfalls – among the People of Paradise; a true promise which is being given to them.

# 4527

And the one who said to his parents, “Uff – I am fed up with both of you! What! You promise me that I will be raised again whereas generations have passed away before me?” And they both seek Allah’s help and say to him, “May you be ruined, accept faith! Indeed Allah’s promise is true”; he therefore answers, “This is nothing except stories of former people.”

# 4528

It is these upon whom the Word has proved true, among the nations that passed away before them, of jinns and men; indeed they were losers.

# 4529

And for all persons are ranks according to their deeds; and so that He may repay them in full for their deeds, and they will not be wronged.

# 4530

And on the day when the disbelievers will be presented upon the fire; it will be said to them, “You have wasted your portion of the good things in the life of this world and enjoyed them; so this day you will be repaid with the disgraceful punishment, the recompense of your wrongfully priding yourself in the land, and because you used to disobey.”

# 4531

And remember the fellowman of the tribe of A’ad; when he warned his nation in the Ahqaf\* – and indeed Heralds of warning passed away before and after him – that, “Do not worship anyone except Allah; indeed I fear the punishment of a Great Day upon you. (\* A country among sand dunes.)

# 4532

They said, “Have you come to us in order to turn us away from our Gods? Therefore bring upon us what you promise us, if you are truthful.”

# 4533

He said, “Its knowledge is only with Allah; and I convey to you the messages of my Lord, but I perceive that you are an ignorant nation.”

# 4534

So when they saw the punishment coming towards their valleys, spread like a cloud on the horizon, they said, “That is a cloud which will shower rain upon us”; said Hud “In fact this is what you were being impatient for; a windstorm carrying a painful punishment.”

# 4535

“That destroys all things by the command of its Lord” – so at morning none could be seen except their empty houses; this is the sort of punishment We mete out to the guilty.

# 4536

And We had indeed given them the means which We have not given you, and made ears and eyes and hearts for them; so their ears and eyes and hearts did not benefit them at all because they used to deny the signs of Allah, and the punishment they used to mock at encompassed them.

# 4537

And We indeed destroyed townships surrounding you, and brought several signs so that they may desist.

# 4538

So why did they – the ones whom they had chosen as Gods as a means of attaining Allah’s proximity – not help them? In fact the disbelievers lost them; and this is just their slander and fabrication.

# 4539

And when We sent a number of jinns towards you (O dear Prophet Mohammed – peace and blessings be upon him), listening attentively to the Qur’an; so when they presented themselves there, they said to each other, “Listen quietly!”; and when the recitation finished, they turned back to their people, giving them warning.

# 4540

They said, “O our people! We have indeed heard a Book, sent down after Moosa, which confirms the Books preceding it, and guides towards the Truth and the Straight Path.”

# 4541

“O our people! Listen to Allah’s caller and accept faith in Him, so that He may forgive you some of your sins and save you from the painful punishment.”

# 4542

“And whoever does not listen to Allah’s caller cannot escape in the earth, and he has no supporters against Allah; they are in open error.”

# 4543

Have they not realised that Allah, Who did not tire in creating the heavens and the earth and in creating them, is Able to revive the dead? Surely yes, why not? Indeed He is Able to do all things.

# 4544

And on the day when the disbelievers are presented upon the fire; it will be said, “Is this not a reality?” They will answer, “By oath of our Lord, surely yes, why not?”; it will be said, “Therefore taste the punishment, the recompense of your disbelief.”

# 4545

Therefore patiently endure (O dear Prophet Mohammed – peace and blessings be upon him) like the courageous Noble Messengers had endured, and do not be impatient for them; on the day when they see what they are promised, it will be as if they had not stayed on earth except part of a day; this is to be conveyed; will anyone be destroyed, except the disobedient?

# 4546

Allah has destroyed the deeds of those who disbelieved and prevented from Allah’s way.

# 4547

And those who accepted faith and did good deeds and believed in what has been sent down upon Mohammed (peace and blessings be upon him) – and that is the truth from their Lord – Allah has relieved them of some of their evils and refined their condition.

# 4548

This is because the disbelievers followed falsehood and the believers followed the Truth which is from their Lord; this is how Allah illustrates the examples of people to them.

# 4549

So when you confront the disbelievers, strike at their necks; until when you have slain them in plenty, tie them up firmly; then after that, you may either release them as a favour or take ransom, until the war lays down its ordeal; this is it; and had Allah willed He Himself could have taken revenge from them, but this is to test some of you with others; and Allah will surely never waste the deeds of those who were killed in His way.

# 4550

He will soon guide them (towards Paradise) and make them succeed.

# 4551

And He will admit them into Paradise – they have been made familiar with it.

# 4552

O People who Believe! If you help the religion of Allah, He will help you and will stabilise you.

# 4553

And for those who disbelieve – may they be ruined, and may Allah destroy all their deeds!

# 4554

This is because they disliked what Allah has sent down – He has therefore squandered all their deeds.

# 4555

So did they not travel in the land to see what sort of fate befell those who preceded them? Allah poured ruin upon them; and for the disbelievers are several like it.

# 4556

This is because Allah is the Supporter of the believers, whereas the disbelievers do not have any supporter.

# 4557

Allah will indeed admit those who believed and did good deeds into Gardens beneath which rivers flow; and the disbelievers enjoy, and they eat like the cattle eat, and their destination is in the fire.

# 4558

And many a township existed which was stronger than your town (O dear Prophet Mohammed – peace and blessings be upon him) – those who removed you from your town – We destroyed them, so they do not have a supporter!

# 4559

So will one who is upon on a clear proof from his Lord, ever be like any of those whose evil deeds are made to appear good to them and they follow their own desires?

# 4560

A description of the Garden which is promised to the pious; in it are rivers of water which shall never pollute; and rivers of milk the taste of which shall never change; and rivers of wine delicious to drink; and rivers of purified honey; and in it for them are fruits of all kinds, and the forgiveness of their Lord; so will such ever be equal to those who are to stay in the fire for ever and who will be given boiling water to drink so that it tears their guts apart?

# 4561

And among them are some who listen to what you say; until when they go away from you, they say to those who have been given knowledge, “What did he say now?”; they are those whose hearts Allah has sealed, and they follow their own desires.

# 4562

And those who attained the right path – Allah increases the guidance for them and bestows their piety to them.

# 4563

So what are they waiting for, except that the Last Day suddenly come upon them? For its signs have already appeared; so when it does come, of what use is their realising it?

# 4564

Therefore know (O dear Prophet Mohammed – peace and blessings be upon him) that there is none worthy of worship except Allah, and seek the forgiveness of sins of your close ones and for the common believing men and women; and Allah knows your movements during the day and your resting during the night.

# 4565

And the Muslims say, “Why was not a chapter sent down?” So when a positive chapter was sent down, and war was commanded in it, you will see those in whose hearts is a disease looking at you with the dazed looks of a dying man; so it would be better for them. –

# 4566

To obey and speak good; so when the manifest command came – it would have been better for them if they had remained faithful to Allah.

# 4567

So do you\* portray that if you get governance, you would spread chaos in the land and sever your relations? (\* The hypocrites)

# 4568

It is these whom Allah has cursed, so He made them deaf to the Truth and blinded their eyes.

# 4569

So do they not ponder the Qur’an deeply, or are there locks on some of their hearts?

# 4570

Indeed those who turn back after the guidance had become clear to them – Satan has deceived them; and made them optimistic of living for ages.

# 4571

This is because they said to those who dislike what Allah has sent down, “We will obey you regarding one matter\*”; and Allah knows their secrets. (\* To fight against the Holy Prophet).

# 4572

So how (dreadful) will it be when the angels remove their souls, striking at their faces and their backs!

# 4573

This is because they followed the matter which displeases Allah, and they disliked what pleases Him – He therefore squandered away all their deeds.

# 4574

What! Do they, in whose hearts is a disease, fancy that Allah will not expose concealed enmities?

# 4575

And if We will, We can show them to you so that you may recognise them by their faces; and you will surely recognise them by the way they talk; and Allah knows your deeds.

# 4576

And We shall indeed test you until We make known the warriors and the steadfast among you – and to test your proclamations.

# 4577

Indeed those who disbelieved and prevented others from Allah’s way, and opposed the Noble Messenger after the guidance had become clear to them – they cannot harm Allah in the least; and soon He will squander away their deeds.

# 4578

O People who Believe! Obey Allah and obey the Noble Messenger, and do not render your deeds void.

# 4579

Indeed those who disbelieved and prevented others from Allah’s way, and then died as disbelievers – so Allah will never forgive them.

# 4580

Therefore do not relax, nor call towards truce by yourself; and it is you who will dominate; and Allah is with you, and He will never cause a loss in your deeds.

# 4581

The worldly life is just a sport and pastime; and if you accept faith and be pious, He will bestow your rewards to you, and not at all ask you for your wealth.

# 4582

Were He to ask it from you, and ask in plenty, you would be miserly, and the miserliness would expose the filth within your hearts.

# 4583

Yes, undoubtedly it is you who are being called, that you may spend in Allah’s way; so some among you act miserly; and whoever is miserly, is being a miser upon himself; and Allah is the Independent (Wealthy – Not requiring anything), whereas you all are needy; and if you renege, He will replace you with other people – and they will not be like you.

# 4584

We have indeed, for your sake (O dear Prophet Mohammed – peace and blessings be upon him), bestowed a clear victory.

# 4585

So that Allah may forgive, for your sake, the sins of those before you and those after you, and complete His favours upon you, and to show you the Straight Path.

# 4586

And so that Allah may provide you a great help.

# 4587

It is He Who instilled peace in the hearts of the believers, so that it may increase their strength of conviction; and to Allah only belong the armies of the heavens and the earth; and Allah is All Knowing, Wise.

# 4588

In order to admit the believing men and believing women into Gardens beneath which rivers flow, in which they will abide, and to relieve them of their misdeeds; and this, in Allah’s sight, is the greatest success.

# 4589

And to punish the hypocrite men and hypocrite women, and the polytheist men and polytheist women, who think evilly about Allah; upon them only is the evil cycle of misfortune; and Allah has wreaked anger upon them, and has cursed them, and has prepared hell for them; and what an evil destination.

# 4590

And to Allah only belong the armies of the heavens and the earth; and Allah is Most Honourable, Wise.

# 4591

We have indeed sent you (O dear Prophet Mohammed – peace and blessings be upon him) as a present witness and a Herald of glad tidings and warnings. (The Holy Prophet is a witness from Allah.)

# 4592

In order that you, O people, may accept faith in Allah and His Noble Messenger, and honour and revere the Noble Messenger; and may say the Purity of Allah, morning and evening. (To honour the Holy Prophet – peace and blessings be upon him – is part of faith. To disrespect him is blasphemy.)

# 4593

Those who swear allegiance to you (O dear Prophet Mohammed – peace and blessings be upon him), do indeed in fact swear allegiance to Allah; Allah's Hand\* of Power is above their hands; so whoever breaches his oath, has breached his own greater promise; and whoever fulfils the covenant he has with Allah – so very soon Allah will bestow upon him a great reward. (Used as a metaphor.)

# 4594

The ignorant ones who had stayed behind will now say to you, “Our wealth and our families prevented us from going by keeping us pre-occupied, therefore seek forgiveness for us”; they utter with their tongues what is not in their hearts; say, “So does anyone have any control over you against Allah, if He wills to harm you or provide you benefit? In fact Allah is Aware of what you do.”

# 4595

“Rather you had assumed that the Noble Messenger and the Muslims will never return to their homes, and you thought this as good within your hearts, whereas you had thought evilly; and you were a people about to be ruined.”

# 4596

And whoever does not accept faith in Allah and His Noble Messenger – We have indeed kept prepared a blazing fire for disbelievers.

# 4597

And for Allah only is the kingship of the heavens and the earth; He may forgive whomever He wills, and punish whomever He wills; and Allah is Oft Forgiving, Most Merciful.

# 4598

Those who had stayed behind will now say, “When you go to receive the war booty, let us also go with you”; they wish to change the Words of Allah; say “You shall never come with us – this is already decreed by Allah”; so they will now say, “But rather you envy us”; in fact they never understood except a little.

# 4599

Say to the ignorant who stayed behind, “You will soon be called against a nation of great military strength – to fight against them or that they become Muslims; so if you obey, Allah will give you an excellent reward; and if you turn away, the way you had turned away before, He will mete out a painful punishment to you.”

# 4600

There is no reproach upon the blind, nor reproach against the lame, nor reproach upon the sick; and whoever obeys Allah and His Noble Messenger – Allah will admit him into Gardens beneath which rivers flow; and whoever turns away – He will mete out a painful punishment to him.

# 4601

Indeed Allah was truly pleased with the believers when they swore allegiance to you beneath the tree – so He knew what was in their hearts – He therefore sent down peace upon them, and rewarded them with an imminent victory.

# 4602

And plenty of war booty, to take; and Allah is Most Honourable, Wise.

# 4603

Allah has promised you plenty of booty which you will take, and has bestowed this to you quickly, and restrained peoples’ hands from you; and in order that it may be a sign for the believers, and to guide you on the Straight Path.

# 4604

And one more, not within your capacity, is within Allah’s hold; and Allah is Able to do all things.

# 4605

And if the disbelievers were to fight you, they will turn away and flee, and then they will not find any supporter nor any aide.

# 4606

The tradition of Allah, ongoing since before; and you will not find the tradition of Allah changing.

# 4607

And it is He Who restrained their hands from you, and your hands from them in the valley of Mecca, after having given you control over them; and Allah sees all what you do.

# 4608

It was these who disbelieved and prevented you from the Sacred Mosque, and stopped the sacrificial animals from reaching their place; and were it not for some Muslim men and Muslim women, whom you do not know – lest you may crush them and unintentionally incur some violation due to them – Allah would have permitted you to slay them; this relief for them, is so that Allah may admit into His mercy whomever He wills; and had they been separated, We would have indeed punished the disbelievers among them with a painful punishment.

# 4609

Whereas the disbelievers had set up in their hearts an obstinacy – the same obstinacy of the days of ignorance – so Allah sent down His solace upon His Noble Messenger and upon the believers, and decreed upon them the words of piety, and they were more deserving and suitable for it; and Allah is the All Knowing.

# 4610

Allah has indeed made the truthful dream of His Noble Messenger, come true; indeed you will all enter the Sacred Mosque, if Allah wills, in safety – with your heads shaven or hair cut short – without fear; so He knows what you do not know, and has therefore ordained another imminent victory before this.

# 4611

It is He Who has sent His Noble Messenger with the guidance and the true religion, in order to make it prevail over all other religions; and Allah is sufficient as a Witness. (The Holy Prophet is a light from Allah.)

# 4612

Mohammed (peace and blessings be upon him) is the Noble Messenger of Allah; and his companions are stern with the disbelievers and merciful among themselves – you will see them bowing and falling in prostration, seeking Allah’s munificence and His pleasure; their signs are on their faces, from the effects of their prostration; this trait of theirs is mentioned in the Taurat; and their trait is mentioned in the Injeel; like a cultivation that sprouted its shoot, then strengthened it, then thickened and then stood firm upon its stem, pleasing the farmer – in order to enrage the disbelievers with them; Allah has promised forgiveness and a great reward to those among them who have faith and do good deeds.

# 4613

O People who Believe! Do not advance ahead of Allah and His Noble Messenger, and fear Allah; indeed Allah is All Hearing, All Knowing.

# 4614

O People who Believe! Do not raise your voices higher than the voice of the Prophet, nor speak to him loudly the way you shout to one another, lest your deeds go to waste whilst you are unaware. (Faith will go waste due to the slightest disrespect towards the Holy Prophet – peace and blessings be upon him. To honour him is part of faith. To disrespect him is blasphemy.)

# 4615

Indeed those who suppress their voices in the presence of Allah’s Noble Messenger, are the ones whose hearts Allah has tested for piety; for them is forgiveness, and a great reward.

# 4616

Indeed most of those who call you from outside the chambers do not have sense.

# 4617

And had they been patient until you yourself came out to them, it would be better for them; and Allah is Oft Forgiving, Most Merciful.

# 4618

O People who Believe! If any miscreant brings you some tidings, verify it, lest you unknowingly cause suffering to some people, and then remain repenting for what you did.

# 4619

And know that Allah’s Noble Messenger is among you; in most of the affairs, were he to listen to you, you would surely fall into hardship, but Allah has made faith dear to you and has instilled it in your hearts, and has made disbelief and rebellion and disobedience abhorred by you; it is people like these who are on guidance.

# 4620

The munificence and favour of Allah; and Allah is All Knowing, Wise.

# 4621

And if two groups of Muslims fight against each other, reconcile them; and if one of them oppresses the other, fight against the oppressor till it returns to the command of Allah; then if it returns, reconcile between them with justice, and be fair; indeed Allah loves the equitable.

# 4622

The Muslims are brothers to each other, therefore make peace between your two brothers and fear Allah, so that you may gain mercy. (The entire Muslim nation is a single brotherhood, without any distinction for caste, creed or colour.)

# 4623

O People who Believe! Men must not ridicule other men for it could be that the ridiculed are better than the mockers, nor must the women ridicule other women for the ridiculed women may be better than the mockers; and do not insult one another, nor assign evil nicknames; how base it is to be called a sinner after being a Muslim! And whoever does not repent – then it is they who are unjust.

# 4624

O People who Believe! Avoid excessive assumptions; indeed assumption sometimes becomes a sin, and do not seek faults, and do not slander one another; would any one among you like to eat the flesh of his dead brother? So you will hate that! And fear Allah; indeed Allah is Most Acceptor of Repentance, Most Merciful.

# 4625

O mankind! We have indeed created you from one man and one woman, and have made you into various nations and tribes so that you may know one another; indeed the more honourable among you, in the sight of Allah, is one who is more pious among you; indeed Allah is All Knowing, All Aware. (Piety is the basis of honour in Allah’s sight.)

# 4626

The ignorant said, “We have accepted faith”; say, (O dear Prophet Mohammed – peace and blessings be upon him), “You have surely not accepted faith, but you should say ‘We have submitted’, for faith has not yet entered your hearts; and if you obey\* Allah and His Noble Messenger, He will not reduce the reward of any of your deeds; indeed Allah is Oft Forgiving, Most Merciful.” (\* By accepting faith and then obeying the commands).

# 4627

The true believers are only those who accepted faith in Allah and His Noble Messenger and then did not have any doubt, and fought with their wealth and their lives in Allah’s way; it is they who are the truthful.

# 4628

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Are you teaching Allah your own religion? Whereas Allah knows all whatever is in the heavens and all whatever is in the earth; and Allah knows all things.”

# 4629

They portray that they are doing a great favour to you (O dear Prophet Mohammed – peace and blessings be upon him) by having become Muslims; say, “Do not think that you have done me a favour by accepting Islam; in fact Allah has bestowed a favour upon you, for He guided you to Islam, if you are truthful.”

# 4630

Indeed Allah knows all the hidden of the heavens and the earth; and Allah is seeing your deeds.

# 4631

Qaf; by oath of the Glorious Qur’an.

# 4632

Rather they were shocked that a Herald of Warning came to them from among themselves, so the disbelievers said, “This is something really strange.”

# 4633

“When we are dead and have turned to dust, will we be raised again? That return is impossible!”

# 4634

We know all what the earth decreases from them; and with Us is a Book that retains.

# 4635

In fact they denied the Truth when it came to them, so they are now in a dilemma.

# 4636

So did they not see the sky above them – how We have made it and beautified it, and there are no cracks in it?

# 4637

And (how) We have spread the earth, and placed mountains as anchors in it, and have grown all kinds of beautiful pairs in it?

# 4638

A perception and an understanding, for every bondman who inclines.

# 4639

And We sent down the auspicious water from the sky, therefore producing gardens with it, and the grain that is harvested.

# 4640

And high date-palms with lush fruit.

# 4641

As sustenance for the bondmen; and with it We revived a dead city; this is how you will be raised.

# 4642

Before these, the people of Nooh had denied, and so did the dwellers of Rass and the Thamud.

# 4643

And the tribe of A’ad, and Firaun, and the fellowmen of Lut.

# 4644

And the Dwellers of the Woods, and the people of Tubb’a; each one of them one denied the Noble Messengers, so My promised punishment proved true.

# 4645

So did We tire by creating the first time? Rather they doubt being created again.

# 4646

And indeed We have created man and We know what his soul instils in him; and We are nearer to him than the hearts artery.

# 4647

When the two receiving angels receive from him, one seated on the right and one on the left.

# 4648

He does not utter a single word, without a ready recorder seated next to him.

# 4649

And the hardship of death came with the truth; “This is what you were escaping from!”

# 4650

And the Trumpet was blown; “This is the Day of the promised punishment.”

# 4651

And every soul came, along with a herder and a witness.

# 4652

“You were indeed neglectful of this, so We have removed the veil for you, and your eyesight is sharp this day.”

# 4653

And his accompanying angel said, “This is the record of your deeds, available with me.”

# 4654

It will be said to the angels, “Both of you fling every excessive ungrateful, stubborn person into hell.”

# 4655

“The one who excessively prevented from virtue, the transgressor, the doubtful.”

# 4656

“The one who appointed another God along with Allah – so both of you fling him into the severe punishment.”

# 4657

His accompanying devil said, “Our Lord! I did not cause him to rebel, but he himself was in extreme error.”

# 4658

He will say, “Do not dispute before Me – I had already warned you of the punishment.”

# 4659

“With Me, the decree does not change, and nor do I oppress the bondmen.”

# 4660

The day when We will ask hell, “Are you filled up?” and it will answer, “Are there some more?”

# 4661

And Paradise will be brought close to the pious, not far away from them.

# 4662

This is what you are promised – for every repenting, careful person.

# 4663

Who fears the Most Gracious without seeing, and came with a heart that inclines.

# 4664

It will be said to him, “Enter it in peace; this is the day of eternity.”

# 4665

In it for them is all that they may desire, and with Us is more than it.

# 4666

And many a generation We did destroy before them, who exceeded them in strength, therefore venturing in the cities! Is there a place to escape?

# 4667

Indeed in this is an advice for anyone who keeps a heart, or listens attentively.

# 4668

And We have indeed created the heavens and the earth, and all what is between them, in six days; and fatigue did not even approach Us.

# 4669

Therefore (O dear prophet Mohammed – peace and blessings be upon him) patiently bear upon what they say, and praising your Lord say His Purity before the sun rises and before the sun sets.

# 4670

And say His Purity during the night, and after the customary prayers.

# 4671

And listen attentively on the day when an announcer will proclaim from a place nearby.

# 4672

The day when all will hear the Scream with the truth; this is the day of coming out of the graves.

# 4673

Indeed it is We Who give life, and give death, and towards Us only is the return.

# 4674

On the day when the earth will split for them, so they will come out in haste; this is the gathering – easy for Us.

# 4675

We well know what they say (O dear Prophet Mohammed – peace and blessings be upon him), and you are not one to use force over them; therefore advise him with the Qur’an, whoever fears My threat.

# 4676

By oath of those which carry away while dispersing.

# 4677

Then by oath of those which carry the burdens.

# 4678

Then by oath of those which move with ease.

# 4679

Then by oath of those which distribute by the command.

# 4680

Undoubtedly, the promise you are given is surely true.

# 4681

And undoubtedly justice will surely be done.

# 4682

And by oath of the decorated heaven.

# 4683

You are indeed in different opinions regarding this Qur’an.

# 4684

Only those who are destined to revert, are reverted from it.

# 4685

Slain be those who mould from their imaginations.

# 4686

Those who have forgotten in a state of intoxication.

# 4687

They ask, “When will be the Day of Judgement?”

# 4688

It will be on the day when they will be roasted in the fire.

# 4689

And it will be said to them, “Taste your own roasting; this is what you were impatient for.”

# 4690

Indeed the pious are among Gardens and water springs.

# 4691

Accepting the rewards given by their Lord; they were indeed virtuous before this.

# 4692

They used to sleep only a little during the night.

# 4693

And used to seek forgiveness before dawn.

# 4694

And the beggar and the destitute had a share in their wealth.

# 4695

And in the earth are signs for those who are certain.

# 4696

And in your own selves; so can you not perceive?

# 4697

And in the heaven lies your sustenance, and the promise you are given.

# 4698

So by oath of the Lord of the heavens and the earth, this Qur’an is the Truth, in the same language that you speak.

# 4699

Did the news of Ibrahim’s honourable guests reach you (O dear Prophet Mohammed – peace and blessings be upon him)?

# 4700

When they came to him and said, “Peace”; he answered, “Peace”; and thought, “These people are not familiar.”

# 4701

Then he went to his home – so he brought a healthy calf.

# 4702

He then presented it before them and said, “Do you not eat?”

# 4703

He therefore inwardly sensed fear of them; they said, “Do not fear!”; and they gave him the glad tidings of a knowledgeable son.

# 4704

So his wife came screaming, and striking her forehead cried, “What! For a barren old woman?”

# 4705

They said, “This is how your Lord has decreed; indeed He only is the Wise, the All Knowing.”

# 4706

Said Ibrahim, “What is your task, O the sent angels?”

# 4707

They said, “We have been sent towards a guilty nation.”

# 4708

“To throw upon them stones of baked clay.”

# 4709

“That are kept marked, with your Lord, for the transgressors.”

# 4710

So We removed the people who had faith, from that town.

# 4711

We therefore found just one house over there that was Muslim.

# 4712

And We kept a sign remaining in it, for those who fear the painful punishment.

# 4713

And in Moosa, when We sent him with a clear proof towards Firaun.

# 4714

In response, he turned away along with his army and said, “He is a magician or a madman.”

# 4715

We therefore seized him and his army and threw them into the sea, while he was blaming himself.

# 4716

And in the tribe of A’ad, when we sent a dry windstorm upon them.

# 4717

It left out nothing in its path, but which it split up into fragments.

# 4718

And in the tribe of Thamud when it was told to them, “Enjoy for a while.”

# 4719

In response they rebelled against their Lord’s command, so the thunderbolt seized them whilst they were watching.

# 4720

So they were neither able to stand up, nor were they able to take revenge.

# 4721

And before them, We destroyed the people of Nooh; they were indeed a sinning nation.

# 4722

And We have built the heaven with hands (the Divine Power), and it is We Who give the expanse.

# 4723

And We made the earth a base, so how well do We lay out!

# 4724

And We created all things in pairs, so that you may ponder.

# 4725

“Therefore rush towards Allah; indeed I am from Him, a clear Herald of Warning towards you.”

# 4726

“And do not appoint other deities along with Allah; indeed I am from Him, a clear Herald of Warning towards you.”

# 4727

Similarly, whenever a Noble Messenger came to those before them they always said, “He is a magician or a madman.”

# 4728

What! Have they willed this utterance to one another? In fact they are a rebellious people.

# 4729

Therefore turn away from them (O dear Prophet Mohammed – peace and blessings be upon him), – so there is no blame upon you.

# 4730

And advise, for advice benefits the Muslims.

# 4731

And I created the jinns and men, only for them to worship Me.

# 4732

I do not ask any sustenance from them, nor wish that they give Me food.

# 4733

Indeed it is Allah, Who is the Greatest Sustainer, the Strong, the Able.

# 4734

And indeed for these unjust is also a turn of punishment, like that of their companions – so they must not ask Me to hasten.

# 4735

So ruin is for disbelievers, from their day – which they are promised.

# 4736

By oath of (mount) Tur.

# 4737

And by oath of a passage, written –

# 4738

On an open record.

# 4739

And by oath of the Inhabited House.

# 4740

And the lofty roof.

# 4741

And the sea set aflame.

# 4742

Indeed your Lord’s punishment will surely take place.

# 4743

No one can avert it.

# 4744

A day on which the heavens will shake with a visible shaking.

# 4745

And the mountains will move with a visible movement.

# 4746

So on that day, ruin is for those who deny.

# 4747

Those who are playing in pursuits.

# 4748

A day when they will be pushed, forcibly shoved towards the fire of hell.

# 4749

“This is the fire, which you used to deny!”

# 4750

“So is this magic, or are you unable to see?”

# 4751

“Enter it – now whether you patiently bear it or are impatient – it is the same for you; for you is a recompense only for what you used to do.”

# 4752

Indeed the pious are in Gardens and peace.

# 4753

Delighted at the bestowal of their Lord; and their Lord has saved them from the fire.

# 4754

“Eat and drink with pleasure, a reward for what you used to do.”

# 4755

Reclining on thrones, in rows; and We have wedded them to maidens with gorgeous eyes.

# 4756

And those who accepted faith, and whose descendants followed them with faith – We have joined their descendants with them, and have not reduced anything for them from their deeds; every soul is trapped in its own deeds.

# 4757

And We aided them with fruit and meat, whatever they desire.

# 4758

In it, they accept cups from each other, in which is neither any lewdness nor any sin.

# 4759

And their boy servants shall go around them, as if they were pearls, safely hidden.

# 4760

And one of them turned towards the other, questioning.

# 4761

Saying, “Indeed before this, we were in our houses, worried.”

# 4762

“So Allah did us a great favour, and saved us from the punishment of the flame.”

# 4763

“Indeed we used to worship Him in our previous life; indeed He only is the Benign, the Most Merciful.”

# 4764

Therefore (O dear Prophet Mohammed – peace and blessings be upon him), enlighten, for by the munificence of your Lord, you are neither a soothsayer nor a madman.

# 4765

Or they allege, “He is a poet – we await a calamity of the times to befall him.”

# 4766

Proclaim, “Go on waiting – I too am waiting along with you.”

# 4767

Is this what their senses tell them, or are they a rebellious people?

# 4768

What! They say, “He has invented the Qur'an”? Rather they do not have faith.

# 4769

So let them bring a single discourse like it, if they are truthful.

# 4770

Have they not been created from some source, or are they themselves the creators?

# 4771

Or did they create the heavens and the earth? Rather they are not certain.

# 4772

Or do they have the treasures of your Lord, or are they the authority?

# 4773

Or do they have any stairs, climbing upon which they eavesdrop? So their eavesdropper should bring some clear proof!

# 4774

What! The daughters for Him, and the sons for you?

# 4775

Or do you (O dear Prophet Mohammed – peace and blessings be upon him) ask any fee from them, so they are burdened with the penalty?

# 4776

Or is the hidden with them, by which they pass judgements?

# 4777

Or are they planning a conspiracy? So the conspiracy will befall only upon the disbelievers.

# 4778

Or do they have a God besides Allah? Purity is to Allah from their ascribing of partners to Him.

# 4779

And were they to see a portion of the sky falling, they will say, “It is a heap of clouds.”

# 4780

Therefore leave them, until they confront their day, in which they will be stunned.

# 4781

A day on which their scheming will not benefit them at all, nor will they be helped.

# 4782

And indeed for the unjust is another punishment before this, but most of them do not know. (Punishment in the grave is proven by this verse.)

# 4783

And be patient upon your Lord’s command, (O dear Prophet Mohammed – peace and blessings be upon him), for you are indeed in Our sight; and proclaim the Purity of your Lord while praising Him, whenever you stand.

# 4784

And proclaim His Purity during the night, and when the stars turn back.

# 4785

By oath of the beloved shining star Mohammed (peace and blessings be upon him), when he returned from the Ascent.

# 4786

Your companion did not err, nor did he go astray.

# 4787

And he does not say anything by his own desire.

# 4788

It is but a divine revelation, which is revealed to him.

# 4789

He has been taught by the Extremely Powerful.

# 4790

The Strong; then the Spectacle inclined towards him.

# 4791

And he was on the horizon of the highest heaven.

# 4792

Then the Spectacle became closer, and came down in full view.

# 4793

So the distance between the Spectacle and the beloved was only two arms’ length, or even less. (The Heavenly Journey of Prophet Mohammed – peace and blessings be upon him – was with body and soul.)

# 4794

So Allah divinely revealed to His bondman, whatever He divinely revealed.

# 4795

The heart did not deny, what it saw. (The Holy Prophet was bestowed with seeing Allah – see also preceding verses 8, 9, 10.)

# 4796

What! So do you dispute with him regarding what he saw?

# 4797

And indeed he did see the Spectacle again.

# 4798

Near the lote-tree of the last boundary.

# 4799

Close to which is the Everlasting Paradise.

# 4800

When the lote-tree was being enveloped, by whatever around it.

# 4801

The sight did not shift, nor did it cross the limits.

# 4802

Indeed he saw the supreme signs of his Lord.

# 4803

So did you observe the idols Lat and Uzza?

# 4804

And subsequently the third, the Manat?

# 4805

What! For you the son, and for Him the daughter?

# 4806

Then that is surely a very unjust distribution!

# 4807

They are nothing but some names that you have coined, you and your forefathers – Allah has not sent any proof for them; they follow only guesses and their own desires; whereas the guidance from their Lord has come to them.

# 4808

What! Will man get whatever he dreams of?

# 4809

So (know that) Allah only is the Owner of all – the Hereafter and this world.

# 4810

And many an angel is in the heavens, whose intercession does not benefit the least unless Allah gives permission for whomever He wills, and whom He likes.

# 4811

Indeed those who do not believe in the Hereafter, coin the names of angels like those of females.

# 4812

And they do not have any knowledge of it; they just follow assumption; and indeed assumption does not serve any purpose in place of the Truth.

# 4813

Therefore turn away from whoever has turned away from Our remembrance and has desired only the life of this world.

# 4814

This is the extent of their knowledge; indeed your Lord well knows one who has strayed from His path, and He well knows one who has attained guidance.

# 4815

And to Allah only belongs all whatever is in the heavens and all whatever is in the earth, in order to repay those who do evil for what they have done, and give an excellent reward to those who do good.

# 4816

Those who avoid the cardinal sins and lewdness, except that they approached it and refrained; indeed your Lord’s mercy is limitless; He knows you very well – since He has created you from clay, and when you were foetuses in your mothers’ wombs; therefore do not, on your own, claim yourselves to be clean; He well knows who are the pious.

# 4817

So did you observe him who turned away?

# 4818

And he gave a little, then refrained?

# 4819

Does he have knowledge of the hidden, so he can foresee?

# 4820

Did not the news reach him, of that which is mentioned in the Books of Moosa?

# 4821

And of Ibrahim, who was most obedient?

# 4822

That no burdened soul bears another soul’s burden?

# 4823

And that man will not obtain anything except what he strove for?

# 4824

And that his effort will soon be scrutinised?

# 4825

Then he will be fully repaid for it?

# 4826

And that the end is only towards your Lord?

# 4827

And that it is He Who made (you) laugh and made (you) cry?

# 4828

And that it is He Who gave death and gave life?

# 4829

And that it is He Who has created the two pairs, male and female?

# 4830

From a drop of liquid, when it is added?

# 4831

And that only upon Him is the next revival?

# 4832

And that it is He Who has given wealth and contentment?

# 4833

And that He only is the Lord of the star Sirius?

# 4834

And that it is He Who earlier destroyed the tribe of Aad?

# 4835

And destroyed the tribe of Thamud, not sparing anyone?

# 4836

And before them, the people of Nooh? Indeed they were more unjust and more rebellious than these!

# 4837

And that it is He Who threw down the upturned townships?

# 4838

So they were covered with whatever covered them?

# 4839

So O listener! Which favour of your Lord will you doubt?

# 4840

He (Prophet Mohammed – peace and blessings be upon him) is a Herald of Warning, like the former Heralds of Warning.

# 4841

The approaching event has come near.

# 4842

None except Allah can avert it.

# 4843

So are you surprised at this fact?

# 4844

And you laugh, and do not weep!

# 4845

And you are lost in play!

# 4846

Therefore prostrate for Allah, and worship Him. (Command of Prostration # 12)

# 4847

The Last Day came near, and the moon split apart.

# 4848

And when they see a sign, they turn away and say, “Just a customary magic!”

# 4849

And they denied and followed their own desires, whereas each matter has been decided!

# 4850

And indeed the news which had a lot of deterrence, came to them.

# 4851

The pinnacle of wisdom – so how will the Heralds of warning provide any benefit?

# 4852

Therefore turn away from them; on the day when the announcer will call towards a severe unknown matter –

# 4853

They will come out from the graves with eyes lowered, as if they were spread locusts.

# 4854

Rushing towards the caller; the disbelievers will say, “This is a tough day.”

# 4855

Before these, the people of Nooh denied and they belied Our bondman and said, “He is a madman” and rebuffed him.

# 4856

He therefore prayed to his Lord, “I am overpowered, therefore avenge me.”

# 4857

We therefore opened the gates of heaven, with water flowing furiously.

# 4858

And caused springs to gush out from the earth, so that the two waters met totalling a quantity that had been destined.

# 4859

And We carried Nooh upon a ship of wooden planks and nails.

# 4860

Sailing in front of Our sight; as a reward for the sake of one who was rejected.

# 4861

And We left it as a sign – so is there one who would ponder?

# 4862

So how did My punishment turn out, and My threats?

# 4863

And We have indeed made the Qur’an easy to memorise, so is there one who would remember?

# 4864

The tribe of A’ad denied – so how did My punishment turn out, and My warnings?

# 4865

We indeed sent towards them a severe windstorm, on a day the ill luck of which lasted upon them forever.

# 4866

Smashing down men as if they were uprooted trunks of date palms.

# 4867

So how did My punishment turn out, and My warnings?

# 4868

And We have indeed made the Qur’an easy to memorise, so is there one who would remember?

# 4869

The tribe of Thamud denied the Noble Messengers.

# 4870

So they said, “What! Shall we follow a man from among us? If we do, we are indeed astray, and insane!”

# 4871

“What! Of all the men among us, the remembrance has come down upon him? In fact, he is a mischievous, great liar.”

# 4872

It was said to Saleh, “They will soon realise tomorrow who is the mischievous great liar.”

# 4873

“We shall send a she-camel to test them, therefore O Saleh, wait and have patience.”

# 4874

“And inform them that the water is to be shared between them; only those may come whose turn it is.”

# 4875

In response they called their companion – he therefore caught and hamstrung the she-camel.

# 4876

So how did My punishment turn out, and My warnings?

# 4877

Indeed We sent upon them a single Scream – thereupon they became like the barrier builder’s residual dry trampled hay.

# 4878

And We have indeed made the Qur’an easy to memorise, so is there one who would remember?

# 4879

The people of Lut denied the Noble Messengers.

# 4880

Indeed We sent a shower of stones upon them, except the family of Lut; We rescued them before dawn.

# 4881

As a reward from Us; this is how We reward one who gives thanks.

# 4882

And indeed he had warned them of Our seizure – in response they doubted the warnings.

# 4883

And they tried to persuade him regarding his guests – We therefore blinded their eyes, “So taste My punishment, and My warnings.”

# 4884

And indeed, the everlasting punishment overcame them early in the morning.

# 4885

“So taste My punishment, and My warnings!”

# 4886

And We have indeed made the Qur’an easy to memorise, so is there one who would remember?

# 4887

And indeed the Noble Messengers came to the people of Firaun.

# 4888

They denied all Our signs, We therefore seized them – the seizure of the Most Honourable, the All Powerful.

# 4889

Are your disbelievers better than they were, or have you been given exemption in the Books?

# 4890

Or they say, “We shall all take revenge as a group.”

# 4891

The group will soon be routed, and will turn their backs to flee.

# 4892

In fact their promise is upon the Last Day – and the Last Day is very severe and very bitter!

# 4893

Indeed the criminals are astray and insane.

# 4894

On the day when they are dragged upon their faces in the fire – “Taste the heat of hell.”

# 4895

We have indeed created all things by a proper measure.

# 4896

And Our command is only a fleeting one – like the batting of an eyelid.

# 4897

And We have indeed destroyed your kind, so is there one who would ponder?

# 4898

And all what they did is in the Books.

# 4899

And every small and great thing is recorded.

# 4900

Indeed the pious are amidst Gardens and springs.

# 4901

Seated in an assembly of the Truth, in the presence of Allah, the Omnipotent King.

# 4902

Allah, the Most Gracious

# 4903

Has taught the Qur’an to His beloved Prophet (Mohammed – peace and blessings be upon him).

# 4904

Has created Prophet Mohammed (peace and blessings be upon him) as the soul of mankind.

# 4905

Has taught him the knowledge of the past and the future.

# 4906

The sun and the moon are scheduled.

# 4907

And the plants and the trees prostrate (for Him).

# 4908

And Allah has raised the sky; and He has set the balance.

# 4909

In order that you may not corrupt the balance.

# 4910

And establish the measures justly, nor decrease the due weight.

# 4911

And He appointed the earth for the creatures.

# 4912

In which are fruits, and covered dates.

# 4913

And grain covered with husk, and fragrant flowers.

# 4914

So O men and jinns! Which favour of your Lord will you deny?

# 4915

He created man from clay like that of earthenware.

# 4916

And created jinn from the flame of fire.

# 4917

So O men and jinns! Which favour of your Lord will you deny?

# 4918

Lord of both the Easts, and Lord of both the Wests!

# 4919

So O men and jinns! Which favour of your Lord will you deny?

# 4920

He has set flowing two seas that appear to meet.

# 4921

Whereas there is a barrier between them so they cannot encroach upon one another.

# 4922

So O men and jinns! Which favour of your Lord will you deny?

# 4923

Pearls and coral-stone come forth from them.

# 4924

So O men and jinns! Which favour of your Lord will you deny?

# 4925

To Him only belong the sailing ships, raised above the sea like hills.

# 4926

So O men and jinns! Which favour of your Lord will you deny?

# 4927

For everything on the earth is extinction.

# 4928

And everlasting is the Entity of your Lord, the Most Majestic and the Most Honourable.

# 4929

So O men and jinns! Which favour of your Lord will you deny?

# 4930

All those who are in the heavens and the earth seek only from Him; every day is an enterprise for Him.

# 4931

So O men and jinns! Which favour of your Lord will you deny?

# 4932

Disposing all works quickly We tend towards your account, O you two large groups!

# 4933

So O men and jinns! Which favour of your Lord will you deny?

# 4934

O the groups of jinns and men, if you can cross the boundaries of the heavens and the earth, then cross them; wherever you may go, His is the kingdom!

# 4935

So O men and jinns! Which favour of your Lord will you deny?

# 4936

Flames of smokeless fire and black smoke without flames, will be let loose on you, so you will not be able to retaliate.

# 4937

So O men and jinns! Which favour of your Lord will you deny?

# 4938

And when the heaven will split, it will appear like a rose painted red.

# 4939

So O men and jinns! Which favour of your Lord will you deny?

# 4940

On that day no sinner will be questioned about his sins, from men or from jinns.

# 4941

So O men and jinns! Which favour of your Lord will you deny?

# 4942

The criminals will be recognised from their faces, so will be caught by their forelocks and feet, and thrown into hell.

# 4943

So O men and jinns! Which favour of your Lord will you deny?

# 4944

This is hell, which the criminals deny.

# 4945

They shall keep going back and forth between it and the extremely hot boiling water.

# 4946

So O men and jinns! Which favour of your Lord will you deny?

# 4947

And for one who fears to stand before his Lord, are two Gardens.

# 4948

So O men and jinns! Which favour of your Lord will you deny?

# 4949

Having numerous branches.

# 4950

So O men and jinns! Which favour of your Lord will you deny?

# 4951

In the two Gardens flow two springs.

# 4952

So O men and jinns! Which favour of your Lord will you deny?

# 4953

In which are fruits of all kinds, each of two varieties.

# 4954

So O men and jinns! Which favour of your Lord will you deny?

# 4955

Reclining upon thrones that are lined with brocade, with the fruit of both Gardens close enough to be picked from under.

# 4956

So O men and jinns! Which favour of your Lord will you deny?

# 4957

Upon thrones are the women who do not gaze at men except their husbands, and before them, are untouched by any man or jinn.

# 4958

So O men and jinns! Which favour of your Lord will you deny?

# 4959

They are like rubies and coral-stone.

# 4960

So O men and jinns! Which favour of your Lord will you deny?

# 4961

What is the reward of virtue except virtue (in return)?

# 4962

So O men and jinns! Which favour of your Lord will you deny?

# 4963

And besides them, there are two more Gardens.

# 4964

So O men and jinns! Which favour of your Lord will you deny?

# 4965

Densely covered with foliage, appearing dark.

# 4966

So O men and jinns! Which favour of your Lord will you deny?

# 4967

In the Gardens are two springs, overflowing with abundance.

# 4968

So O men and jinns! Which favour of your Lord will you deny?

# 4969

In them are fruits (of all kinds), and dates and pomegranate.

# 4970

So O men and jinns! Which favour of your Lord will you deny?

# 4971

In them are women of good behaviour and gorgeous faces.

# 4972

So O men and jinns! Which favour of your Lord will you deny?

# 4973

They are houris (maidens of Paradise), hidden from view, in pavilions.

# 4974

So O men and jinns! Which favour of your Lord will you deny?

# 4975

Untouched by any man or jinn, before them.

# 4976

So O men and jinns! Which favour of your Lord will you deny?

# 4977

Reclining on green cushions and beautiful decorated carpets.

# 4978

So O men and jinns! Which favour of your Lord will you deny?

# 4979

Most Auspicious is the name of your Lord, the Most Majestic and the Most Honourable.

# 4980

When the forthcoming event does occur.

# 4981

Then none will be able to deny its occurrence.

# 4982

The event will be abasing some, and exalting some.

# 4983

When the earth will tremble, shivering.

# 4984

And the mountains will be crushed, blown to bits.

# 4985

So they will become like fine dust, scattered in a shaft of light.

# 4986

And you will become divided into three categories.

# 4987

So those on the right – how (fortunate) are those on the right!

# 4988

And those on the left – how (wretched) are those on the left!

# 4989

And those who surpassed have indeed excelled.

# 4990

It is they who are the close ones.

# 4991

They are in Gardens of peace.

# 4992

A large group from the earlier generations.

# 4993

And a few from the latter.

# 4994

On studded thrones.

# 4995

Reclining on them, facing each other.

# 4996

Surrounded by immortal boys.

# 4997

Carrying bowls and pitchers – and cups filled with wine flowing before them.

# 4998

Their heads shall not ache with it, nor shall they lose their senses.

# 4999

And fruits that they may like.

# 5000

And meat of birds that they may wish.

# 5001

And gorgeous eyed fair maidens.

# 5002

Like pearls safely hidden.

# 5003

The reward for what they did.

# 5004

They will not hear any useless speech in it, or any sin.

# 5005

Except the saying, “Peace, peace.”

# 5006

And those on the right – how (fortunate) are those on the right!

# 5007

Among thorn-less lote-trees.

# 5008

And clusters of banana plants.

# 5009

And in everlasting shade.

# 5010

And in perpetually flowing water.

# 5011

And plenty of fruits.

# 5012

That will neither finish, nor ever be stopped.

# 5013

And raised couches.

# 5014

We have indeed developed these women with an excellent development.

# 5015

So made them as maidens.

# 5016

The beloved of their husbands, of one age.

# 5017

For those on the right.

# 5018

A large group from the earlier generations.

# 5019

And a large group from the latter.

# 5020

And those on the left – how (wretched) are those on the left!

# 5021

In scorching wind and boiling hot water.

# 5022

And in the shadow of a burning smoke.

# 5023

Which is neither cool nor is for respect.

# 5024

Indeed they were among favours before this.

# 5025

And were stubborn upon the great sin (of disbelief).

# 5026

And they used to say, “When we are dead and have turned into dust and bones, will we surely be raised again?”

# 5027

“And also our forefathers?”

# 5028

Proclaim, “Without doubt all – the former and the latter.”

# 5029

“They will all be gathered together – on the appointed time of the known day.”

# 5030

Then indeed you, the astray, the deniers –

# 5031

You will indeed eat from the Zaqqum tree.

# 5032

Then will fill your bellies with it.

# 5033

And upon it, you will drink the hot boiling water.

# 5034

Drinking the way thirsty camels drink.

# 5035

This is their reception on the Day of Justice.

# 5036

It is We Who created you, so why do you not accept the truth?

# 5037

So what is your opinion regarding the semen you discharge?

# 5038

Do you make a human out of it, or is it We Who create?

# 5039

It is We Who have ordained death among you, and We have not been beaten –

# 5040

In the matter of exchanging you for others, and to transform you into what you do not know.

# 5041

And you have indeed learnt about the first creation, so why do you not ponder?

# 5042

So what is your opinion regarding what you sow?

# 5043

Is it you who cultivate it, or is it We Who develop it?

# 5044

If We will We can make it like dry trampled hay, so you would keep crying out.

# 5045

That, “We have indeed been penalised!”

# 5046

“In fact, we were unfortunate!”

# 5047

So what is your opinion regarding the water that you drink?

# 5048

Is it you who caused it to descend from the cloud, or is it We Who cause it to descend?

# 5049

If We will We can make it bitter, so why do you not give thanks?

# 5050

So what is your opinion regarding the fire which you kindle?

# 5051

Is it you who grew its tree, or is it We Who create?

# 5052

We have made it as a reminder of hell and as a utility for travellers in the jungle.

# 5053

Therefore (O dear Prophet Mohammed – peace and blessings be upon him) proclaim the Purity of the name of your Lord, the Greatest.

# 5054

So I swear by the setting places of the stars.

# 5055

And that is indeed a tremendous oath, if you understand.

# 5056

This is indeed the noble Qur’an.

# 5057

Kept in a secure Book.

# 5058

None may touch it, except with ablution.

# 5059

Sent down by the Lord Of The Creation.

# 5060

So is this the matter regarding which you laze?

# 5061

And you make its denial your share?

# 5062

So why was it not, when the soul reaches up to the throat, –

# 5063

Whereas you watch at that moment!

# 5064

And We are nearer to him than you are, but you cannot see.

# 5065

So why is it not, that if you are not to be repaid, –

# 5066

That you bring it back, if you are truthful?

# 5067

Then if the dying one is of those having proximity, –

# 5068

Then is relief, and flowers – and Gardens of peace.

# 5069

And if he is of those on the right, –

# 5070

Then upon you is the greetings of peace (O dear Prophet Mohammed – peace and blessings be upon him), from those on the right.

# 5071

And if he is from the deniers, the astray, –

# 5072

Then his reception is the hot boiling water.

# 5073

And a hurling into the blazing fire.

# 5074

This is indeed an utmost certainty.

# 5075

Therefore (O dear Prophet Mohammed – peace and blessings be upon him) proclaim the Purity of the name of your Lord, the Greatest.

# 5076

All whatever is in the heavens and in the earth proclaims the Purity of Allah; and He only is the Most Honourable, the Wise.

# 5077

For Him only is the kingship of the heavens and the earth; He gives life and causes death; and He is Able to do all things.

# 5078

He only is the First and He only the Last, and He only is the Evident and He only the Concealed; and it is He Who knows all things.

# 5079

It is He Who created the heavens and the earth in six days, then ascended the Throne (of Control), in a manner befitting His Majesty; He knows all what goes into the earth and all what comes out of it, and all what descends from the sky and all that rises in it; and He is with you, wherever you may be; and Allah is seeing your deeds.

# 5080

For Him only is the kingship of the heavens and the earth; and towards Allah only is the return of all matters.

# 5081

He brings the night in a part of the day, and brings the day in a part of the night; and He knows what lies within the hearts.

# 5082

Accept faith in Allah and His Noble Messenger, and spend in His cause from what He has made you the heirs of; so for those among you who accepted faith and spent in His cause, is a great reward.

# 5083

And what is the matter with you, that you should not accept faith in Allah? Whereas this Noble Messenger is calling you to believe in your Lord, and Allah has indeed already taken a covenant from you, if you believe.

# 5084

It is He Who sends down clear verses upon His chosen bondman, in order to take you out from the realms of darkness towards light; and indeed Allah is Most Compassionate, Most Merciful upon you.

# 5085

And what is the matter with you that you should not spend in Allah’s cause, whereas Allah is the Inheritor of all that is in the heavens and in the earth? Those among you who spent and fought before the conquest of Mecca are not equal to others; they are greater in rank than those who spent and fought after the conquest; and Allah has promised Paradise to all of them; and Allah well knows what you do.

# 5086

Who will lend a handsome loan to Allah so that He may double it for him? And for such is an honourable reward.

# 5087

The day when you will see the believing men and believing women, that their light runs before them and on their right – it being said to them, “This day, the best tidings for you are the Gardens beneath which rivers flow – abide in it forever; this is the greatest success.”

# 5088

The day when hypocrite men and hypocrite women will say to the Muslims, “Look mercifully towards us, so that we may gain some of your light!”; it will be said to them, “Turn back, search light over there!”; so they will turn around, whereupon a wall will be erected between them, in which is a gate; inside the gate is mercy, and on the outer side is the punishment.

# 5089

The hypocrites will call out to the Muslims, “Were we not with you?”; they will answer, “Yes you were, why not? But you had put your souls into trial, and you used to await misfortune for the Muslims, and you doubted, and false hopes deceived you until Allah’s command came – and the big cheat had made you conceited towards the command of Allah.”

# 5090

“So this day no ransom is to be taken from you nor from the declared disbelievers; your destination is the fire; that is your companion; and what a wretched outcome!”

# 5091

Has not the time come for the believers to surrender their hearts to Allah’s remembrance and to this truth that has come down? And do not be like those who were earlier given the Book(s) and when a long term passed over them, their hearts became hardened; and many of them are sinners.

# 5092

Know that it is Allah Who revives the earth after its death; We have indeed illustrated the signs for you, for you to understand.

# 5093

Indeed the charity-giving men and women, and those who lend an excellent loan to Allah – for them is double, and for them is an honourable reward.

# 5094

And those who believe in Allah and all His Noble Messengers, are the truly sincere; and are witness upon others, before their Lord; for them is their reward, and their light; and those who disbelieved and denied Our signs, are the people of hell.

# 5095

Know that the life of this world is nothing but play and pastime, and adornment, and boasting amongst yourselves, and the desire to surpass each other in wealth and children; like the rain the produce of which pleased the farmer, then dried so you see it yellow, and then turned into dry trampled hay; and in the Hereafter is a severe punishment, and the forgiveness from Allah and His pleasure; and the life of this world is nothing but counterfeit wealth.

# 5096

Rush towards the forgiveness of your Lord and a Paradise wide as the expanse of the heavens and the earth – made for those who believe in Allah and all His Noble Messengers; this is Allah’s munificence, He may bestow it to whomever He wills; and Allah is Extremely Munificent.

# 5097

There is no misfortune that reaches in the earth or in your selves but is mentioned in a Book, before We initiate it; indeed this is easy for Allah.

# 5098

So that you may not be saddened upon losing something, nor rejoice upon what you are given; and Allah does not like any boastful, conceited person.

# 5099

Those who practice miserliness, and exhort others to miserliness; and whoever turns away, then (know that) Allah is the Independent, the Most Praiseworthy.

# 5100

Indeed We sent Our Noble Messengers with proofs, and sent down the Book and the Balance of Justice along with them, so that people may stay upon justice; and We sent down iron having severe heat and benefits for mankind, and so that Allah may see him, who without seeing aides Him and His Noble Messengers; indeed Allah is Almighty, Dominant.

# 5101

And indeed We sent Nooh and Ibrahim, and placed Prophethood and the Book among their descendants, so some among them took to guidance; and many of them are sinners.

# 5102

We then sent Our other Noble Messengers after them following their footsteps, and after them We sent Eisa, the son of Maryam, and bestowed the Injeel to him; and We instilled compassion and mercy in the hearts of his followers; and they invented monasticism which We had not ordained upon them only to seek Allah’s pleasure, then did not properly abide by it as it should have been rightfully abided; We therefore gave the believers among them their reward; and many of them are sinners.

# 5103

O People who Believe (in the earlier Noble Messengers)! Fear Allah and accept faith in this Noble Messenger of His – He will bestow two portions of His mercy to you and will create a light for you to walk in it, and will forgive you; and Allah is Oft Forgiving, Most Merciful.

# 5104

This is so that the disbelievers among People given the Book(s) may know that they do not have any control over Allah’s munificence, and that the munificence is in Allah’s Hand (control) – He bestows to whomever He wills; and Allah is Extremely Munificent.

# 5105

Allah has indeed heard the speech of the woman who is arguing with you (O dear Prophet Mohammed – peace and blessings be upon him) concerning her husband, and is complaining to Allah; and Allah hears the conversation of you both; indeed Allah is All Hearing, All Knowing.

# 5106

Those among you who have proclaimed their wives as their mothers – so their wives are not their mothers; their mothers are only those that gave them birth; and undoubtedly they utter evil and a blatant lie; and indeed Allah is Most Pardoning, Oft Forgiving.

# 5107

And those among you who have proclaimed their wives as their mothers and then wish to revert to the matter upon which they had uttered such an enormous word, must then free a slave before they touch one another; this is what you are advised; and Allah is Aware of your deeds.

# 5108

So one who cannot find a slave, must then fast for two successive months before they touch one another; and one who cannot even fast, must then feed sixty needy ones; this is in order that you keep faith in Allah and His Noble Messenger; and these are the limits of Allah; and for the disbelievers is a painful punishment.

# 5109

Indeed those who oppose Allah and His Noble Messenger have been humiliated, like those before them who were humiliated, and We have indeed sent down clear verses; and for the disbelievers is a disgraceful punishment.

# 5110

The day when Allah will raise all of them together and inform them of their misdeeds; Allah has kept count of them, whereas they have forgotten them; and all things are present before Allah.

# 5111

O listener! Did you not see that Allah knows all whatever is in the heavens and all whatever is in the earth? Wherever there is any discussion among three He is the fourth present with them, and among five He is the sixth, and there is no discussion among fewer or more except that He is with them wherever they may be; and then on the Day of Resurrection He will inform them of all what they did; indeed Allah knows all things.

# 5112

Did you not see those who were forbidden from conspiracy, yet they do what was forbidden, and consult each other for sinning, and for exceeding limits, and for disobeying the Noble Messenger? And when they come in your presence, they greet you with words not chosen by Allah for respectfully greeting you, and they inwardly say, “Why does not Allah punish us for what we say?”; hell is sufficient for them; they will sink into it; and what a wretched outcome!

# 5113

O People who Believe! When you consult each other, do not consult for sinning, nor for exceeding limits, nor for disobeying the Noble Messenger – and consult for righteousness and piety; and fear Allah, towards Whom you will be raised.

# 5114

The evil consultation is only from the devil in order that he may upset the believers, whereas he cannot harm them in the least without Allah’s command; and only upon Allah must the Muslims rely.

# 5115

O People who Believe! When you are told to give room in the assemblies, then do give room – Allah will give you room (in His mercy); and when it is said, “Stand up in reverence”, then do stand up – Allah will raise the believers among you, and those given knowledge, to high ranks; and Allah is Aware of your deeds.

# 5116

O People who Believe! When you wish to humbly consult with the Noble Messenger, give some charity before you consult; that is much better and much purer for you; so if you do not have the means, then (know that) Allah is Oft Forgiving, Most Merciful.

# 5117

Were you afraid to offer charity before you consult? So when you did not do this, and Allah has inclined towards you with His mercy, keep the prayers established and pay the obligatory charity and obey Allah and His Noble Messenger; and Allah is Aware of your deeds.

# 5118

Did you not see those who befriended those upon whom is Allah’s wrath? They are neither of you nor of these – and they swear a false oath, whereas they know.

# 5119

Allah has kept prepared a severe punishment for them; indeed they commit extremely evil deeds.

# 5120

They use their oaths as a shield therefore preventing from Allah’s way – so for them is a disgraceful punishment.

# 5121

Their wealth and their children will be of no use to them before Allah; they are the people of hell; they are to remain in it forever.

# 5122

The day when Allah will raise them all, they will swear in His presence the way they now swear in front of you, and they will assume that they have achieved something; pay heed! Indeed it is they who are the liars.

# 5123

The devil has overpowered them, so they forgot the remembrance of Allah; they are the devil’s group; pay heed! Indeed it is the devil’s group who are the losers.

# 5124

Indeed those who oppose Allah and His Noble Messenger, are among the most despicable.

# 5125

Allah has already decreed that, “I will indeed be victorious, and My Noble Messengers”; indeed Allah is Almighty, the Most Honourable.

# 5126

You will not find the people who believe in Allah and the Last Day, befriending those who oppose Allah and His Noble Messenger, even if they are their fathers or their sons or their brothers or their tribesmen; it is these upon whose hearts Allah has ingrained faith, and has aided them with a Spirit from Himself; and He will admit them into Gardens beneath which rivers flow, abiding in them forever; Allah is pleased with them, and they are pleased with Him; this is Allah’s group; pay heed! Indeed it is Allah’s group who are the successful.

# 5127

All whatever is in the heavens and all whatever is in the earth proclaims the Purity of Allah; and He only is the Most Honourable, the Wise.

# 5128

It is He Who expelled the disbelievers among the People given the Book(s) from their homes, for their first gathering; you did not expect them to leave, whereas they assumed that their fortresses would save them from Allah, so Allah’s command came to them from a place they had not imagined; and He instilled awe in their hearts, so they ruin their own houses by their own hands and at the hands of the Muslims; therefore learn a lesson, O those who can perceive!

# 5129

And had Allah not decreed exile for them, He would have surely punished them in this world; and for them in the Hereafter is the punishment of the fire.

# 5130

This is because they remained opposed to Allah and His Noble Messenger; and whoever remains opposed to Allah, (and His Noble Messenger) – then indeed Allah’s punishment is severe.

# 5131

The trees you had cut down or left standing on their roots was all by Allah’s permission, and in order to disgrace the sinners.

# 5132

And from them, the booty which Allah gave to His Noble Messenger – so you had not raced your horses or camels against them, but it is Allah Who gives whomever He wills within the control of His Noble Messengers; and Allah is Able to do all things.

# 5133

The booty which Allah gave to His Noble Messenger from the people of the townships, is for Allah and His Noble Messenger, and for the relatives, and the orphans, and the needy and the travellers – so that it does not become the wealth of the rich among you; and accept whatever the Noble Messenger gives you; and refrain from whatever he forbids you; and fear Allah; indeed Allah’s punishment is severe.

# 5134

And (the booty is) also for the poor migrants who were expelled from their homes and their wealth, seeking Allah’s munificence and His pleasure, and aiding Allah and His Noble Messenger; it is they who are the truthful.

# 5135

And those who accepted this city as their home and accepted faith before them, befriend those who migrated towards them, and in their breasts do not find any need for what they have been given, and prefer the migrants above themselves even if they themselves are in dire need; and whoever is saved from the greed of his soul – it is they who are the successful.

# 5136

And those who came after them say, “O our Lord! Forgive us, and our brothers who accepted faith before us, and do not keep any malice in our hearts towards the believers – O our Lord! Indeed You only are the Most Compassionate, Most Merciful.”.

# 5137

Did you not see the hypocrites, that they say to their disbelieving brothers among the People given the Book(s), “If you are expelled, then we will definitely go out with you, and we will not listen to anyone in your matters, and if you are fought against we will surely help you”; and Allah testifies that they are indeed liars.

# 5138

If they are expelled, the hypocrites will not go out with them; and if they are fought against they will not help them; and even if they were to help them, they would turn their backs and flee; and then they will not be helped.

# 5139

Indeed in their hearts is a greater fear of you than that of Allah; this is because they are a people who do not understand.

# 5140

They will not fight you even if they all come together, except in barricaded cities or from behind walls; they are severe fighters among themselves; you will assume them to be one, whereas their hearts are divided; this is because they are a people who do not have any sense.

# 5141

Like the example of those who were before them not long ago – they tasted the evil result of their deeds; and for them is a painful punishment.

# 5142

The example of the devil – when he said to man “Disbelieve”; so when he has rejected faith, he says, “I am unconcerned with you – indeed I fear Allah, the Lord of The Creation.”

# 5143

So the fate of them both is that they are both in the fire, to remain in it forever; and this is the proper punishment for the unjust.

# 5144

O People who Believe! Fear Allah, and every soul must see what it has sent ahead for tomorrow; and fear Allah; indeed Allah is Aware of your deeds.

# 5145

And do not be like those who forgot Allah – He therefore put them into hardship making them forget themselves; it is they who are the sinners.

# 5146

The People of hell and the People of Paradise are not equal; it is only the People of Paradise who have succeeded.

# 5147

Had We sent down this Qur’an upon a mountain, you would have then surely seen it bowed down, blown to bits by the fear of Allah; and We illustrate such examples for people, for them to ponder.

# 5148

It is Allah, except Whom there is no God; the Knowing of all – the hidden and the evident; He only is the Most Gracious, the Most Merciful.

# 5149

It is Allah, except Whom there is no God; the King, the Pure, the Giver of Peace, the Bestower of Safety, the Protector, the Most Honourable, the Compeller, the Proud; Purity is to Allah from all what they ascribe as partners (to Him)!

# 5150

It is Allah only, Who is the Creator, the Initiator, the Designer of all – His only are all the good names; all whatever is in the heavens and in the earth proclaims His Purity; and He only is the Most Honourable, the Wise.

# 5151

O People who Believe! Do not befriend My and your enemy – you reveal secrets to them out of friendship whereas they disbelieve in the truth which has come to you! It is they who remove the Noble Messenger and you from your homes, upon your believing in Allah, your Lord; if you have come out to fight for My cause, and to gain My pleasure, then do not befriend them; you send them secret messages of friendship – and I well know all what you hide and all what you disclose; and whoever among you does it, has indeed strayed away from the right path.

# 5152

If they gain dominance over you they will be your enemies, and will extend their hands and their tongues towards you with evil, and they wish that in some way you turn disbelievers.

# 5153

Neither your relations nor your offspring will in the least benefit you, on the Day of Resurrection; He will separate you from them; and Allah is seeing your deeds.

# 5154

Indeed in Ibrahim, and those along with him, lay a good example for you follow – when they said to their people, “Indeed we are unconcerned with you and all what you worship besides Allah; we reject you, and between us and you has surfaced enmity and hatred for ever until you accept faith in the One Allah” – except the saying of Ibrahim to his father, “I will surely seek forgiveness for you, and I do not possess any power to benefit you against Allah”; “O our Lord! We have relied only upon You, and towards You only we have inclined and only towards You is the return”.

# 5155

“O our Lord! Do not put us into the trial of the disbelievers, and forgive us, O our Lord! Indeed You only are the Most Honourable, the Wise.”

# 5156

Indeed in them lay a good example for you to follow – for one who looks forward to (meeting) Allah and the Last Day; and whoever turns away – then (know that) indeed Allah only is the Independent, the Most Praiseworthy.

# 5157

It is likely that Allah may create friendship between you and those among them who are now your enemies; and Allah is All Able; and Allah is Oft Forgiving, Most Merciful.

# 5158

Allah does not forbid you from those who did not fight against you because of religion and did not drive you out from your homes, that you should be kind towards them and deal with them fairly; indeed the equitable are the beloved of Allah.

# 5159

Allah forbids you only from those who fought against you because of religion or drove you out from your homes or helped others to drive you out, that you should befriend them; and whoever befriends them – it is they who are the unjust.

# 5160

O People who Believe! When Muslim women leave the lands of disbelief and migrate towards you, examine them; Allah knows more about their faith; so if you judge the women to be believers, do not send them back to the disbelievers; neither are they lawful for the disbelievers, nor are the disbelievers lawful for them; and give their disbelieving husbands what they had spent; and there is no sin upon you to marry them if you give them their bridal money; and do not continue the marriage with disbelieving women – and ask for what you had spent, and the disbelievers may ask for what they had spent; this is Allah’s command; He judges between you; and Allah is All Knowing, Wise.

# 5161

And if some women go away from the Muslims to the disbelievers – then when you punish the disbelievers, give from the war booty to the Muslims who lost their wives the amount they had spent; and fear Allah in Whom you believe.

# 5162

O dear Prophet (Mohammed – peace and blessings be upon him)! If Muslim women come humbly to you to take oath of allegiance that they will neither ascribe any partner to Allah, nor steal, nor commit adultery, nor kill their children, nor bring the lie that they carry between their hands and feet, nor disobey you in any rightful matter – then accept their allegiance and seek forgiveness from Allah for them; indeed Allah is Oft Forgiving, Most Merciful.

# 5163

O People who Believe! Do not befriend the people upon whom is Allah’s wrath – they have lost hope in the Hereafter the way the disbelievers have lost hope in the people of the graves.

# 5164

All whatever is in the heavens and all whatever is in the earth proclaims the Purity of Allah; and He only is the Most Honourable, the Wise.

# 5165

O People who Believe! Why do you preach what you do not practice?

# 5166

How despicable it is in the sight of Allah that you may preach what you do not practice.

# 5167

Indeed Allah likes those who fight in His cause, positioned in rows, as if they were an edifice fortified.

# 5168

And remember when Moosa said to his people, “O my people! Why do you trouble me, whereas you know that I am Allah’s Noble Messenger towards you?” So when they deviated, Allah deviated their hearts; and Allah does not guide the sinning people.

# 5169

And remember when Eisa the son of Maryam said, “O Descendants of Israel! Indeed I am Allah’s Noble Messenger towards you, confirming the Book Torah which was before me, and heralding glad tidings of the Noble Messenger who will come after me – his name is Ahmed (the Praised One)”; so when Ahmed came to them with clear proofs, they said, “This is an obvious magic.”

# 5170

And who is more unjust than one who fabricates a lie against Allah whereas he is being called towards Islam? And Allah does not guide the unjust people.

# 5171

They wish to put out Allah’s light with their mouths, whereas Allah will perfect His light even if the disbelievers get annoyed.

# 5172

It is He Who has sent His Noble Messenger with guidance and the religion of truth, in order that He may make it prevail over all other religions, even if the polytheists get annoyed.

# 5173

O People who Believe! Shall I show you a trade that can save you from the painful punishment?

# 5174

Have faith in Allah and His Noble Messenger, and fight in Allah’s cause with your wealth and your lives; this is better for you, if you understand.

# 5175

He will forgive you your sins and admit you into Gardens beneath which rivers flow, and superb dwellings in everlasting Gardens of Eden; this is the greatest success.

# 5176

And He will give you another favour, which is dear to you – the help from Allah and an imminent victory; and O dear Prophet (Mohammed – peace and blessings be upon him), give glad tidings to the Muslims.

# 5177

O People who Believe! Become the aides of Allah’s religion, the way Eisa the son of Maryam had said to the disciples, “Who will help me, inclining towards Allah?” The disciples said, “We are the aides of Allah’s religion” – so a group among the Descendants of Israel accepted faith and another group disbelieved; We therefore aided the believers against their enemies, so they were victorious.

# 5178

All whatever is in the heavens and all whatever is in the earth proclaims the Purity of Allah, the King, the Most Pure, the Most Honourable, the Wise.

# 5179

It is He Who has sent among the unlettered people a Noble Messenger from themselves, who recites His verses to them and purifies them, and bestows them the knowledge of the Book and wisdom; and indeed before this, they were in open error.

# 5180

And he (the Holy Prophet) bestows knowledge to others along with them, who have not yet joined them; and He only is the Most Honourable, the Wise.

# 5181

This is Allah’s munificence, which He may give to whomever He wills; and Allah is Extremely Munificent.

# 5182

The example of those who were entrusted with the Taurat, and did not carry out its commands, is like the donkey carrying books; what a wretched example is of the people who denied the signs of Allah; and Allah does not guide the unjust.

# 5183

Say “O Jews! If you assume that you are Allah’s friends, others are not, then wish for death if you are truthful!”

# 5184

And they will never wish for it because of the misdeeds their hands have sent ahead; and Allah well knows the unjust.

# 5185

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Indeed death which you run away from will surely confront you, then you will be returned to Him Who knows all the hidden and the visible – He will then inform you of what you did.”

# 5186

O People who Believe! When the call for prayer is given on (Friday) the day of congregation, rush towards the remembrance of Allah and stop buying and selling; this is better for you if you understand.

# 5187

And when the prayer ends, spread out in the land and seek Allah’s munificence, and profusely remember Allah, in the hope of attaining success.

# 5188

And when they see some trade or sport, they move towards it and leave you standing delivering the sermon; proclaim, “That which is with Allah, is better than sport and trade; and the sustenance of Allah is the best.”

# 5189

When the hypocrites come in your presence (O dear Prophet Mohammed – peace and blessings be upon him) they say, “We testify that you surely are Allah’s Noble Messenger”; and Allah knows that you indeed are His Noble Messenger, and Allah testifies that the hypocrites are indeed liars.

# 5190

They have taken their oaths as a shield, thereby prevented others from Allah’s way; indeed they commit extremely evil deeds.

# 5191

That is because they accepted faith with their tongues then disbelieved with their hearts, therefore their hearts were sealed – so now they do not understand anything.

# 5192

And when you see them, their appearance would please you; and when they speak, you would listen carefully to their speech; like wooden blocks propped against the wall; they assume every cry to be against them; they are the enemy, so beware of them; may Allah slay them! Where are they reverting!

# 5193

And when it is said to them, “Come! Allah’s Noble Messenger may seek forgiveness for you” – they turn heads away, and you will see them turning away in pride.

# 5194

It is the same for them, whether you seek forgiveness for them or do not seek forgiveness for them; Allah will never forgive them; indeed Allah does not guide the sinning people.

# 5195

It is they who say, “Do not spend upon those who are with Allah’s Noble Messenger until they get distraught”; whereas to Allah only belong the treasures of the heavens and the earth, but the hypocrites do not have sense.

# 5196

They say, “If we return to Medinah, then indeed the honourable group will soon expel the lowly one”; whereas all honour belongs to Allah and to His Noble Messenger and to the Muslims, but the hypocrites do not know.

# 5197

O People who Believe! May not your wealth or your children cause you to neglect the remembrance of Allah; and whoever does this – so it is they who are in a loss.

# 5198

And spend from what We have provided you before death approaches any one of you and he then says, “My Lord! Why did you not give me respite for a little while, so I would have given charity and become of the virtuous?”

# 5199

And Allah will never give respite to any soul when its promise arrives; and Allah is Aware of your deeds.

# 5200

All whatever is in the heavens and all whatever is in the earth proclaims the Purity of Allah; His only is the kingship and His only is all praise; and He is Able to do all things.

# 5201

It is He Who has created you, so among you one is a disbeliever whereas another is a Muslim; and Allah is seeing your deeds.

# 5202

He created the heavens and the earth with the truth, and fashioned you thereby making you in best shapes; and towards Him only is the return.

# 5203

He knows all whatever is in the heavens and in the earth, and He knows all what you hide and all what you disclose; and Allah knows what lies within the hearts.

# 5204

Did not the news of those who disbelieved before you reach you? So they tasted the evil outcome of their deeds, and for them is a painful punishment.

# 5205

This is because their Noble Messengers used to bring clear proofs to them, in response they said, “What! Will humans show us the way?”; they therefore became disbelievers and turned away, and Allah acted independently; and Allah is the Independent, the Most Praiseworthy.

# 5206

The disbelievers alleged that they will surely not be raised again; proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “Surely yes, why not? By oath of Lord, you will surely be raised again and you will then be informed of your misdeeds; and this is easy for Allah.”

# 5207

Therefore accept faith in Allah and His Noble Messenger and the light which We have sent down; and Allah is Well Aware of what you do.

# 5208

The day when He will gather you, on the Day of Collective Assembly – that is the day when the loss of the losers will be laid bare; and whoever believes in Allah and does good deeds, Allah will relieve him of his sins and admit him into Gardens beneath which rivers flow, for them to abide in it forever; this is the greatest success.

# 5209

And those who disbelieved and denied Our signs, are the people of the fire – to remain in it forever; and what a wretched outcome!

# 5210

No misfortune befalls except by Allah’s command; and Allah will guide the heart of whoever accepts faith in Him; and Allah knows all things.

# 5211

And obey Allah and obey His Noble Messenger; then if you turn away, know that the duty upon Our Noble Messenger is only to plainly convey.

# 5212

Allah – there is none worthy of worship except Him; and only upon Allah must the Muslims rely.

# 5213

O People who Believe! Some of your wives and children are your enemies, therefore be wary of them; and if you pardon and overlook and forgive, then indeed Allah is Oft Forgiving, Most Merciful.

# 5214

Your wealth and your children are just a test; and with Allah is a tremendous reward.

# 5215

Therefore fear Allah as much as possible, and heed the commands, and obey, and spend in Allah’s cause, for your own good; and whoever is rescued from the greed of his own soul – is they who will be successful.

# 5216

If you lend an excellent loan to Allah, He will double it for you and forgive you; and Allah is Most Appreciative, Most Forbearing.

# 5217

The All Knowing of all things hidden and visible, the Most Honourable, the Wise.

# 5218

O dear Prophet (Mohammed – peace and blessings be upon him)! When you people divorce women, divorce them at the time of their completing the appointed period, and keep count of the appointed period; and fear Allah, your Lord; do not expel them from their houses during the appointed period nor should they leave on their own, unless they bring about some matter of blatant lewdness; and these are the limits of Allah; and whoever crosses Allah’s limits has indeed wronged himself; do you not know, it is likely that Allah may send some new decree after this?

# 5219

So when they are about to reach their appointed term, hold them back with kindness or separate them with kindness, and make two just men among you as witnesses, and establish the testimony for Allah; with this is advised whoever believes in Allah and the Last Day; and whoever fears Allah – Allah will create for him a way of deliverance.

# 5220

And will provide him sustenance from a place he had never expected; and whoever relies on Allah – then Allah is Sufficient for him; indeed Allah will accomplish His command; indeed Allah has set a proper measure for all things.

# 5221

And for those of your women who have no hope of menstruation, if you doubt, the appointed period is three months – and also for those who have not yet had menstruation; and the appointed period for the pregnant women is up to the time they deliver their burden; and whoever fears Allah – Allah will create ease for him in his affairs.

# 5222

This is Allah’s command that He has sent down towards you; and whoever fears Allah – Allah will relieve his sins and bestow upon him a great reward.

# 5223

Accommodate them where you also reside, according to your means, and do not harass them to make it difficult upon them; and if they are pregnant, give them the provision till they deliver their burden; then if they suckle the child for you, pay them its due; and consult with each other in a reasonable manner; and if you create hardship for one another, the child will get another breast feeding nurse.

# 5224

Whoever has the capacity must give provisions according to his means; and the one whose sustenance is restricted upon him, must give provisions from what Allah has given him; Allah does not burden any soul except according to what He has given it; Allah will soon, after the hardship, create ease.

# 5225

And many a town existed that rebelled against the command of its Lord and His Noble Messengers, so We took a severe account from it – and struck them with a dreadful punishment.

# 5226

They therefore tasted the evil outcome of their deeds, and the outcome of their deeds was a loss.

# 5227

Allah has kept prepared a severe punishment for them – therefore fear Allah, O men of intellect! O People who Believe! Allah has sent down a Remembrance (or an honour) for you. (The Holy Prophet is a Remembrance from Allah.)

# 5228

The Noble Messenger who recites the clear verses of Allah to you, so that he may take those who accept faith and do good deeds, away from the realms of darkness towards light; and whoever accepts faith in Allah and does good deeds, Allah will admit him into Gardens beneath which rivers flow, to abide in them for ever and ever; indeed Allah has kept an excellent sustenance for him.

# 5229

It is Allah Who has created the seven heavens, and seven earthly worlds like them; the command descends within them, so that you may know that Allah is Able to do all things, and that Allah’s knowledge encompasses everything.

# 5230

O dear Prophet (Mohammed – peace and blessings be upon him)! Why do you forbid for yourself the things that Allah has made lawful for you? You wish to please some of your wives; and Allah is Oft Forgiving, Most Merciful.

# 5231

Allah has ordained expiation for your oaths; and Allah is your Master; and Allah is the All Knowing, the Wise.

# 5232

And when the Holy Prophet confided a matter to one of his wives; so when she disclosed it and Allah conveyed this to the Holy Prophet, he told her part of it and held back a part; so when the Holy Prophet informed her about it, she said, “Who informed you?”; he said, “The All Knowing, the All Aware has informed me.”

# 5233

If you both, the wives of the Holy Prophet, incline towards Allah, for indeed your hearts have deviated a little; and if you come together against him (the Holy Prophet – peace and blessings be upon him) then indeed Allah is his Supporter, and Jibreel and the virtuous believers are also his aides; and in addition the angels are also his aides. (Allah has created several supporters for the believers.)

# 5234

It is likely that, if he divorces you, his Lord will give him wives better than you in your place -widows and maidens who are obedient, believing, respectful, penitent, serving and fasting.

# 5235

O People who Believe! Save yourselves and your families from the fire, the fuel of which is men and stones – appointed over it are the extremely strict angels, who do not refuse the command of Allah and carry out whatever they are commanded.

# 5236

“O disbelievers! Do not feign excuses this day; you will only be repaid what you used to do.”

# 5237

O People who Believe! Incline towards Allah in a repentance that becomes a guidance for the future; it is likely that your Lord will relieve you of your sins and admit you into Gardens beneath which rivers flow – on the day when Allah will not humble the Prophet and the believers along with him; their light will be running ahead of them and on their right; they will say, “Our Lord! Perfect our light for us, and forgive us; indeed You are Able to do all things.”

# 5238

O dear Prophet (Mohammed – peace and blessings be upon him), wage holy war against the disbelievers and the hypocrites, and be strict with them; and their destination is hell; and what a wretched outcome!

# 5239

Allah illustrates the example of the disbelievers – the wife of Nooh and the wife of Lut; they were bonded in marriage to two of Our bondmen deserving Our proximity – they then betrayed them so they did not benefit them the least against Allah and it was declared, “Both of you women enter the fire, along with others who enter.”

# 5240

And Allah illustrates an example of the Muslims – the wife of Firaun; when she prayed, “My Lord! Build a house for me near You, in Paradise, and deliver me from Firaun and his works, and rescue me from the unjust people.”

# 5241

And the example of Maryam the daughter of Imran, who guarded her chastity – We therefore breathed into her a Spirit from Ourselves – and she testified for the Words of her Lord and His Books, and was among the obedient.

# 5242

Most Auspicious is He in Whose control is the entire kingship; and He is Able to do all things.

# 5243

The One Who created death and life to test you – who among you has the better deeds; and He only is the Most Honourable, the Oft Forgiving.

# 5244

The One Who created the seven heavens atop each other; do you see any discrepancy in the creation of the Most Gracious? Therefore lift your gaze – do you see any cracks?

# 5245

Then lift your gaze again, your gaze will return towards you, unsuccessful and weak.

# 5246

And indeed We have beautified the lower heaven with lamps, and have made them weapons against the devils, and have kept prepared for them the punishment of the blazing fire.

# 5247

And for those who disbelieved in their Lord, is the punishment of hell; and what a wretched outcome!

# 5248

They will hear it hissing when they will be thrown into it, and it is boiling.

# 5249

As if about to explode with rage; whenever a group is thrown into it, the guardians of hell will ask them, “Did not a Herald of Warning come to you?”

# 5250

They will say, “Yes, why not – indeed a Herald of Warning did come to us – in response we denied and said ‘Allah has not sent down anything – you are not except in a great error’.”

# 5251

And they will say, “Had we listened or understood, we would not have been among the people of hell.”

# 5252

So now they admit their sins! Therefore accursed be the people of hell!

# 5253

Indeed for those who fear their Lord without seeing is forgiveness, and a great reward.

# 5254

And whether you speak softly or proclaim it aloud; He indeed knows what lies within the hearts!

# 5255

What! Will He Who has created not know? Whereas He knows every detail, the All Aware!

# 5256

It is He Who subjected the earth for you, therefore tread its paths and eat from Allah’s sustenance; and towards Him is the resurrection.

# 5257

Have you become unafraid of the One Who controls the heavens, that He will not cause you to sink into the earth when it trembles?

# 5258

Or have you become unafraid of the One Who controls the heavens, that He will not send a torrent of stones upon you? So now you will realise, how My warning turned out!

# 5259

And indeed those before them had denied – therefore how did My rejection turn out!

# 5260

And did they not see the birds above them, spreading and closing their wings? None except the Most Gracious holds them up; indeed He sees all things.

# 5261

Or which army do you have that will help you against the Most Gracious? The disbelievers are in nothing except an illusion.

# 5262

Or who is such that will give you sustenance if Allah stops His sustenance? In fact they persist in rebellion and hatred.

# 5263

So is one who walks inverted upon his face more rightly guided, or one who walks upright on the Straight Path?

# 5264

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “It is He Who created you, and made ears and eyes and hearts for you; very little thanks do you offer!”

# 5265

Say, “It is He Who has spread you out in the earth, and towards Him you will be raised.”

# 5266

And they say, “When will this promise come, if you are truthful?”

# 5267

Proclaim, “Surely Allah has its knowledge; and I am only a Herald of plain warning.”

# 5268

So when they will see it close, the faces of the disbelievers will become ghastly, and it will be declared, “This is what you were demanding.”

# 5269

Say (O dear Prophet Mohammed – peace and blessings be upon him), “What is your opinion –Allah may either destroy me and those with me, or have mercy on us – so who is such that will protect the disbelievers from the painful punishment?”

# 5270

Proclaim, “He only is the Most Gracious – we have accepted faith in Him and have relied only upon Him; so you will now realise who is in open error.”

# 5271

Say, “What is your opinion – if in the morning all your water were to sink into the earth, then who is such who can bring you water flowing before you?”

# 5272

Nuun\* – by oath of the pen and by oath of what is written by it. (Alphabet of the Arabic language; Allah and to whomever He reveals, know their precise meanings.)

# 5273

You are not insane, by the munificence of your Lord.

# 5274

And indeed for you is an unlimited reward.

# 5275

And indeed you possess an exemplary character.

# 5276

So very soon, you will see and they too will realise –

# 5277

\- That who among you was insane.

# 5278

Indeed your Lord well knows those who have strayed from His path, and He well knows those who are upon guidance.

# 5279

Therefore do not listen to the deniers.

# 5280

They wish that in some way you may yield, so they too might soften their stand.

# 5281

Nor ever listen to any excessive oath maker, ignoble person.

# 5282

The excessively insulting one, spreader of spite.

# 5283

One who excessively forbids the good, transgressor, sinner.

# 5284

Foul mouthed, and in addition to all this, of improper lineage.

# 5285

Because he\* has some wealth and sons. (Walid bin Mugaira, who cursed the Holy Prophet.)

# 5286

When Our verses are recited to him, he says, “These are stories of earlier people.”

# 5287

We will soon singe his pig-nose.

# 5288

We have indeed tested them the way We had tested the owners of the garden when they swore that they would reap its harvest the next morning.

# 5289

And they did not say, “If Allah wills”.

# 5290

So an envoy from your Lord completed his round upon the garden, whilst they were sleeping.

# 5291

So in the morning it became as if harvested.

# 5292

They then called out to each other at daybreak.

# 5293

That, “Go to your fields at early morn, if you want to harvest.”

# 5294

So they went off, while whispering to one another.

# 5295

“Make sure that no needy person enters your garden this day.”

# 5296

And they left at early morn, assuming they were in control of their purpose.

# 5297

Then when they saw it, they said, “We have indeed strayed.”

# 5298

“In fact, we are unfortunate.”

# 5299

The best among them said, “Did I not tell you, ‘Why do you not proclaim His purity?’”

# 5300

They said, “Purity is to our Lord – we have indeed been unjust.”

# 5301

So they came towards each other, blaming.

# 5302

They said, “Woe to us – we were indeed rebellious.”

# 5303

“Hopefully, our Lord will give us a better replacement than this – we now incline towards our Lord.”

# 5304

Such is the punishment; and indeed the punishment of the Hereafter is the greatest, if only they knew!

# 5305

Indeed for the pious, with their Lord, are Gardens of Serenity.

# 5306

Shall We equate the Muslims to the guilty?

# 5307

What is the matter with you? What sort of a judgement you impose!

# 5308

Is there a Book for you, from which you read?

# 5309

\- That for you in it is whatever you like?

# 5310

Or is it that you have a covenant from Us, right up to the Day of Judgement, that you will get all what you claim?

# 5311

Ask them, who among them is a guarantor for it?

# 5312

Or is it that they have partners in worship? So they should bring their appointed partners, if they are truthful.

# 5313

On the day when the Shin\* will be exposed and they will be called to prostrate themselves, they will be unable. (Used as a metaphor)

# 5314

With lowered eyes, disgrace overcoming them; and indeed they used to be called to prostrate themselves whilst they were healthy.

# 5315

Therefore leave the one who denies this matter, to Me; We shall soon steadily take them away, from a place they do not know.

# 5316

And I will give them respite; indeed My plan is very solid.

# 5317

Or is it that you (O dear Prophet Mohammed – peace and blessings be upon him) ask any fee from them, so they are burdened with the penalty?

# 5318

Or that they possess the hidden, so they are writing it?

# 5319

Therefore wait for your Lord’s command, and do not be like the one of the fish; who cried out when he was distraught. (Prophet Yunus – peace be upon him.)

# 5320

Were it not for his Lord’s favour that reached him, he would have surely been cast onto the desolate land, reproached.

# 5321

His Lord therefore chose him and made him among those deserving His proximity.

# 5322

And indeed the disbelievers seem as if they would topple you with their evil gaze when they hear the Qur’an, and they say, “He is indeed insane.”

# 5323

Whereas it is not but an advice to the entire creation!

# 5324

The true event!

# 5325

How tremendous is the true event!

# 5326

And what have you understood, how tremendous the true event is!

# 5327

The tribes of Thamud and A’ad denied the event of great dismay. (The Day of Resurrection)

# 5328

So regarding the Thamud, they were destroyed by a terrible scream.

# 5329

And as for A’ad, they were destroyed by a severe thundering windstorm.

# 5330

He forced it upon them with strength, consecutively for seven nights and eight days – so you would see those people overthrown in it, like trunks of date palms fallen down.

# 5331

So do you see any survivor among them?

# 5332

And Firaun, and those before him, and the dwellings that were inverted and thrown, had brought error.

# 5333

They therefore disobeyed the Noble Messengers of their Lord – so He seized them with an intense seizure.

# 5334

Indeed when the water swelled up, We boarded you onto the ship.

# 5335

In order to make it a remembrance for you, and in order that the ears that store may remember.

# 5336

So when the Trumpet will be blown, with a sudden single blow.

# 5337

And the earth and the mountains will be lifted up and crushed with a single crush.

# 5338

So that is the day when the forthcoming event will occur.

# 5339

And the heaven will split asunder – so on that day it will be unstable.

# 5340

And the angels will be on its sides; and on that day, eight angels will carry the Throne of your Lord above them.

# 5341

On that day all of you will be brought forth, so none among you wishing to hide will be able to hide.

# 5342

So whoever is given his book in his right hand – he will say, “Take, read my account!”

# 5343

“I was certain that I will confront my account.”

# 5344

He is therefore in the desired serenity.

# 5345

In a lofty Garden –

# 5346

The fruit clusters of which are hanging down.

# 5347

“Eat and drink with pleasure – the reward of what you sent ahead, in the past days.”

# 5348

And whoever is given his book in his left hand – he will say, “Alas, if only my account were not given to me!”

# 5349

“And had never come to know my account!”

# 5350

“Alas, if only it had been just death.”

# 5351

“My wealth did not in the least benefit me.”

# 5352

“All my power has vanished.”

# 5353

It will be said, “Seize him, and shackle him.”

# 5354

“Then hurl him into the blazing fire.”

# 5355

“Then bind him inside a chain which is seventy arm-lengths.”

# 5356

“Indeed he refused to accept faith in Allah, the Greatest.”

# 5357

“And did not urge to feed the needy.”

# 5358

“So he does not have any friend here this day.”

# 5359

“Nor any food except the pus discharged from the people of hell.”

# 5360

“Which none except the guilty shall eat.”

# 5361

So by oath of the things you see.

# 5362

And by oath of those you do not see.

# 5363

This Qur’an is the speech of Allah with a gracious Noble Messenger.

# 5364

And it is not the speech of a poet; how little do you believe!

# 5365

Nor is it the speech of a soothsayer; how little do you ponder!

# 5366

Sent down by the Lord Of The Creation.

# 5367

And had he fabricated just one matter upon Us –

# 5368

We would have definitely taken revenge from him.

# 5369

Then would have cut off his heart’s artery.

# 5370

Then none among you would be his saviour.

# 5371

And indeed this Qur’an is an advice for the pious.

# 5372

And indeed We know that some among you are deniers.

# 5373

And indeed it is a despair for the disbelievers.

# 5374

And indeed it is a certain Truth.

# 5375

Therefore (O dear Prophet Mohammed – peace and blessings be upon him), proclaim the purity of your Lord, the Greatest.

# 5376

A requester seeks the punishment that will take place –

# 5377

\- Upon the disbelievers – the punishment that none can avert.

# 5378

From Allah, the Lord of all pinnacles.

# 5379

The angels and Jibreel, ascend towards Him – the punishment will befall on a day which spans fifty thousand years.

# 5380

Therefore patiently endure, in the best manner (O dear Prophet Mohammed – peace and blessings be upon him).

# 5381

They deem it to be remote.

# 5382

Whereas We see it impending.

# 5383

The day when the sky will be like molten silver.

# 5384

And the hills will be light as wool.

# 5385

And no friend will ask concerning his friend.

# 5386

They will be seeing them; the guilty will wish if only he could redeem himself from the punishment of that day, by offering his sons.

# 5387

And his wife and his brother.

# 5388

And the family in which he was.

# 5389

And all those who are in the earth – then only if the redemption saves him!

# 5390

Never! That is indeed a blazing fire.

# 5391

A fire that melts the hide.

# 5392

It calls out to him who reverted and turned away.

# 5393

And accumulated wealth and hoarded it.

# 5394

Indeed man is created very impatient, greedy.

# 5395

Very nervous when touched by misfortune.

# 5396

And refraining, when good reaches him.

# 5397

Except those who establish prayer.

# 5398

Those who are regular in their prayers.

# 5399

And those in whose wealth exists a recognised right,

# 5400

For those who beg, and for the needy who cannot even ask.

# 5401

And those who believe the Day of Judgement to be true.

# 5402

And those who fear the punishment of their Lord.

# 5403

Indeed the punishment of their Lord is not a thing to be unafraid of!

# 5404

And those who protect their private organs (from adultery).

# 5405

Except with their wives and the bondwomen in their possession, for there is no reproach on them.

# 5406

So those who desire more than this – it is they who are the transgressors.

# 5407

And those who protect the property entrusted to them, and their agreements.

# 5408

And those who are firm upon their testimonies.

# 5409

And those who protect their prayers.

# 5410

It is these who will be honoured in Gardens.

# 5411

So what is the matter with these disbelievers, that they stare at you (O dear Prophet Mohammed – peace and blessings be upon him)?

# 5412

From the right and the left, in groups?

# 5413

Does every man among them aspire to be admitted into the Garden of serenity?

# 5414

Never! We have indeed created them from a thing they know.

# 5415

So I swear by the Lord of every East and every West, that We are indeed Able.

# 5416

To replace them by those better than them; and none can escape from Us.

# 5417

Therefore leave them, involved in their indecencies and play, till they confront their day which they are promised.

# 5418

A day when they will come out of the graves in haste, as if rushing towards their goals.

# 5419

With lowered eyes, disgrace overcoming them; this is the day, which they had been promised.

# 5420

Indeed We sent Nooh towards his people saying that, “Warn your people before the painful punishment comes upon them.”

# 5421

He said, “O my people! I am indeed a Herald of clear warnings to you.”

# 5422

“That you must worship Allah and fear Him, and obey me.”

# 5423

“He will forgive you some of your sins, and give you respite up to an appointed term; indeed the promise of Allah cannot be averted when it arrives; if only you knew.”

# 5424

He said, “My Lord! I invited my people night and day.”

# 5425

“So for them, my calling them increased their fleeing away.”

# 5426

“And whenever I called them, so that You may forgive them, they always thrust their fingers into their ears, and covered themselves with their clothes, and remained stubborn and were extremely haughty.”

# 5427

“I then called them openly.”

# 5428

“Then I also told them publicly and also spoke to them softly in private.”

# 5429

“I therefore told them, ‘Seek forgiveness from your Lord; He is indeed Most Forgiving.’

# 5430

‘He will send down abundant rain for you from the sky.’

# 5431

‘And will aid you with wealth and sons, and will create gardens for you and cause rivers to flow for you.’

# 5432

‘What is the matter with you, that you do not desire honour from Allah?’

# 5433

‘Whereas it is He Who created you in different stages?’

# 5434

‘Do you not see how Allah has created the seven heavens atop each other?’

# 5435

‘And in them, has illuminated the moon, and made the sun a lamp?’

# 5436

‘And it is Allah Who made you grow like vegetation from the earth.’

# 5437

‘And He will then take you back to it, and again remove you from it.”

# 5438

‘And it is Allah Who made the earth a bed for you.’

# 5439

‘So that you may tread the wide roads in it.’”

# 5440

Prayed Nooh, “O my Lord! They have disobeyed me, and they follow the one whose wealth and children increase nothing for him except ruin.”

# 5441

“And they carried out a very sinister scheme.”

# 5442

“And they said, ‘Do not ever abandon your Gods – and never abandon Wadd, or Suwa – or Yaghuth or Yauq or Nasr.’”

# 5443

“And they have misled a large number; and (I pray that) You increase nothing for the unjust except error.”

# 5444

Because of their sins they were drowned and then put into the fire; so they did not find any supporter for themselves against Allah. (Punishment in the grave is proven by this verse.)

# 5445

And prayed Nooh, “O my Lord! Do not leave any of the disbelievers dwelling in the land.”

# 5446

“Indeed, if You spare them, they will mislead your bondmen – and their descendants, if any, will be none except the wicked, very ungrateful.”

# 5447

“O my Lord! Forgive me, and my parents, and the believers who are in my house, and all other Muslim men and Muslim women; and do not increase anything for the unjust except ruin.”

# 5448

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I have received the divine revelation that some jinns attentively listened to my recitation, so they said, ‘We have heard a unique Qur’an.’

# 5449

‘That guides to the path of goodness, we have therefore accepted faith in it; and we shall never ascribe anyone as a partner to our Lord.’

# 5450

‘And that our Lord’s Majesty is Supreme – He has neither chosen a wife nor a child.’

# 5451

‘And that the fool among us used to utter false exaggerations against Allah.’

# 5452

‘Whereas we thought that men and jinns would never fabricate a lie against Allah!’

# 5453

‘And indeed some men among humans used to take the protection of some men among jinns, so it further increased their haughtiness.’

# 5454

‘And that they assumed, like you humans assume, that Allah would not send any Noble Messenger.’

# 5455

‘And we reached the sky, so we found it strongly guarded and filled with comets.’

# 5456

‘And that we sometimes used to sit in some places in the sky, to listen; so whoever now listens finds a fiery comet waiting for him.’

# 5457

‘And we do not know whether harm is intended for those on the earth, or whether their Lord intends goodness for them.’

# 5458

‘And among us some are virtuous and some are the other type; we are split into several branches.’

# 5459

‘And we are certain that we cannot defeat Allah in the earth, nor can we run out of His grasp.’

# 5460

‘And that when we heard the guidance, we accepted faith in it; so whoever accepts faith in his Lord, has no fear – neither of any loss nor of any injustice.’

# 5461

‘And that some among us are Muslims and some are the unjust; and whoever has accepted Islam – it is they who have thought rightly.’

# 5462

‘And as for the unjust – they are the fuel of hell.’”

# 5463

And proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I have received the divine revelation that ‘Had they remained upright on the straight path, We would have given them abundant water.’

# 5464

‘In order to test them with it; and whoever turns away from the remembrance of his Lord – He will put him in a punishment that keeps on increasing.’

# 5465

‘And that the mosques are for Allah only – therefore do not worship anyone along with Allah.’

# 5466

‘And that when Allah’s bondman stood up to worship Him, the jinns had almost crowded upon him.’”

# 5467

Say (O dear Prophet Mohammed – peace and blessings be upon him), “I worship only Allah, and I do not ascribe any partner to Him.”

# 5468

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I am not the master of any harm or benefit for you.”

# 5469

Say, “No one will ever save me from Allah, and other than Him, I will not find any refuge.”

# 5470

“I only convey the commands from Allah, and His messages; and whoever disobeys the commands of Allah and His Noble Messenger – then indeed for him is the fire of hell, in which they will remain for ever and ever.”

# 5471

Till the time when they will see what they are promised – so they will now come to know whose aide is weak, and who is lesser in number.

# 5472

Say (O dear Prophet Mohammed – peace and blessings be upon him), “I do not know whether what you are promised is close or if my Lord will postpone it for a while.”

# 5473

The All Knowing of all the hidden does not give anyone the control over His secrets.

# 5474

Except to His chosen Noble Messengers – so He appoints guards in front and behind him. (Allah gave the knowledge of the hidden to the Holy Prophet – peace and blessings be upon him.)

# 5475

In order to see that they have conveyed the messages of their Lord – and His knowledge encompasses all whatever they have, and He has kept all things accounted for.

# 5476

O the One Wrapped in piety! (Prophet Mohammed – peace and blessings be upon him)

# 5477

Stand up for worship during the night, except for some part of it.

# 5478

For half the night, or reduce some from it.

# 5479

Or increase a little upon it, and recite the Qur’an slowly in stages.

# 5480

Indeed We shall soon ordain a heavy responsibility upon you.

# 5481

Indeed getting up in the night is tougher, and the words flow with strength.

# 5482

Indeed you have a lot of matters during the day.

# 5483

And remember the name of your Lord and, leaving others, devote yourself solely to Him.

# 5484

Lord of the East and Lord of the West – there is no God except Him, therefore make Him your sole Trustee of affairs.

# 5485

And patiently endure upon what the disbelievers say, and leave them for good.

# 5486

And leave them to Me – these wealthy deniers – and give them some respite.

# 5487

Indeed We have heavy fetters and a blazing fire.

# 5488

And food that chokes, and a painful punishment.

# 5489

On a day when the earth and the mountains will tremble, and the mountains turn into dunes of flowing sand.

# 5490

We have indeed sent a Noble Messenger towards you, a present witness over you – the way We had sent a Noble Messenger towards Firaun.

# 5491

In response Firaun disobeyed the Noble Messenger, so We seized him with a severe seizure.

# 5492

So how will you save yourselves, if you disbelieve, on a day that will turn children old?

# 5493

The heaven will split asunder with its grief; the promise of Allah will surely occur.

# 5494

This is indeed an advice; so whoever wishes may take the path towards his Lord.

# 5495

Indeed your Lord knows that you stand up in prayer, sometimes almost two-thirds of the night, and sometimes half the night or sometimes a third of it – and also a group of those along with you; Allah keeps measure of the night and day; He knows that you, O Muslims, will not be able to measure the night, so He has inclined towards you with mercy – therefore recite from the Qur’an as much as is easy for you; He knows that soon some of you will fall ill, and some will travel in the land seeking the munificence of Allah, and some will be fighting in Allah’s cause; therefore recite from the Qur’an as much as is easy for you, and establish prayer and pay the obligatory charity, and lend an excellent loan to Allah; and whatever good you send ahead for yourselves, you will find it with Allah, better and having a great reward; and seek forgiveness from Allah; indeed Allah is Oft Forgiving, Most Merciful.

# 5496

O the Cloaked One! (Prophet Mohammed – peace and blessings be upon him)

# 5497

Rise up and warn!

# 5498

And proclaim the Purity of your Lord.

# 5499

And keep your clothes clean.

# 5500

And stay away from idols.

# 5501

And do not favour others in order to receive more.

# 5502

And for the sake of your Lord, patiently endure.

# 5503

So when the Trumpet will be blown.

# 5504

So that is a tough day.

# 5505

Not easy upon the disbelievers.

# 5506

Leave him to Me, the one whom I created single.

# 5507

And gave him vast wealth.

# 5508

And gave him sons present before him.

# 5509

And made several preparations for him.

# 5510

Yet he desires that I should give more.

# 5511

Never! For he is an enemy to Our signs!

# 5512

Soon I shall mount him on Saood, the hill of fire.

# 5513

Indeed he thought, and inwardly decided.

# 5514

So accursed be he, how evilly did he decide!

# 5515

Again accursed be he, how evilly did he decide!

# 5516

He then dared to lift his gaze.

# 5517

Then frowned and grimaced.

# 5518

Then he turned away, and was haughty.

# 5519

And said, “This is nothing but magic learnt from earlier men.”

# 5520

“This is nothing but the speech of a man.”

# 5521

I will soon fling him into hell.

# 5522

And what have you understood, what hell is!

# 5523

It neither leaves, nor spares.

# 5524

It strips away the hide of man.

# 5525

Above it are nineteen guards.

# 5526

We have not appointed the guards of hell, except angels; and did not keep this number except to test the disbelievers – in order that the People given the Book(s) may be convinced, and to increase the faith of the believers – and so that the People given the Book(s) and the Muslims may not have any doubt – and so that those in whose hearts is a disease and the disbelievers, may say, “What does Allah mean by this amazing example?” This is how Allah sends astray whomever He wills, and guides whomever He wills; and no one knows the armies of Allah except Him; and this is not but an advice to man.

# 5527

Yes, never!\* By oath of the moon. (Hell will never spare the disbelievers).

# 5528

And by oath of the night when it turns back.

# 5529

And by oath of the morning, when it spreads light.

# 5530

Indeed hell is one of the greatest entities.

# 5531

Warn the men.

# 5532

For the one among you who wishes to come forward or stay back.

# 5533

Every soul is mortgaged for its own deeds.

# 5534

Except those on the right side.

# 5535

In Gardens, they seek answers,

# 5536

\- From the guilty.

# 5537

“What took you into the hell?”

# 5538

They said, “We never used to offer the prayer.”

# 5539

“Nor used to feed the needy.”

# 5540

“And used to dwell on evil matters with those who think evilly.”

# 5541

“And used to deny the Day of Justice.”

# 5542

“Till death overcame us.”

# 5543

So the intercession of the intercessors will not benefit them. (The disbelievers will not have any intercessor.)

# 5544

So what is the matter with them that they turn away from the advice?

# 5545

As if they were startled donkeys –

# 5546

Fleeing away from a lion.

# 5547

Rather each one of them desires that he should be given open Books.

# 5548

Never! In fact they do not fear the Hereafter.

# 5549

Yes indeed, this is an advice.

# 5550

So whoever wills may heed advice from it.

# 5551

And what advice will they heed, except if Allah wills? Only He deserves to be feared, and His only is the greatness of forgiving.

# 5552

I swear by the Day of Resurrection.

# 5553

And by oath of the soul that reproaches itself.

# 5554

Does man assume that We will never assemble his bones?

# 5555

Surely yes, why not? We can properly make all his phalanxes.

# 5556

In fact man wishes to commit evil in front of Him!

# 5557

He asks, “When will be the Day of Resurrection?”

# 5558

So when the eyes will be blinded by light.

# 5559

And the moon will be eclipsed.

# 5560

And the sun and the moon will be united.

# 5561

On that day man will cry out, “Where shall I flee?”

# 5562

Never! There is no refuge!

# 5563

On that day, the station is only towards your Lord.

# 5564

On that day, man will be informed of all what he sent ahead and left behind.

# 5565

In fact, man himself is keeping an eye on his state of affairs!

# 5566

And even if he presents all the excuses he has, none will be listened to.

# 5567

O dear Prophet (Mohammed – peace and blessings be upon him), do not cause your tongue to move along with the Qur’an in order to learn it faster.

# 5568

Indeed assembling the Qur’an and reading it are upon Us.

# 5569

So when We have read it, you should thereupon follow what is read.

# 5570

Then indeed, to explain its details to you is upon Us.

# 5571

None except you, O disbelievers – you love what you have, the fleeting one.

# 5572

And you have forsaken the Hereafter.

# 5573

On that day, some faces will shine with freshness.

# 5574

Looking toward their Lord.

# 5575

And on that day some faces will be ghastly.

# 5576

Knowing that they will be subjected to a torment that breaks the backs.

# 5577

Yes indeed, when the soul will reach up to the throat.

# 5578

And they will say, “Is there any one – any magician?”

# 5579

And he will realise that this is the parting.

# 5580

And one shin will curl up with the other shin.

# 5581

On that day, the herding will be only towards your Lord.

# 5582

Neither did he believe it to be true, nor did he offer the prayer.

# 5583

But he denied and turned away.

# 5584

Then he went back to his home in pride.

# 5585

Your ruin has come close, still closer.

# 5586

Again your ruin has come close, still closer.

# 5587

Does man assume that he will be let loose?

# 5588

Was he not just a drop of the semen that is discharged?

# 5589

He then became a clot – so Allah created him, then made him proper.

# 5590

So created from him a pair, the male and female.

# 5591

So will He, Who has done all this, not be able to revive the dead?

# 5592

Indeed there has been a time for man, when even his name did not exist anywhere.

# 5593

Indeed We have created man from mixed semen; in order to test him – We therefore made him hearing, knowing.

# 5594

We have indeed shown him the way – whether he is grateful or ingrate.

# 5595

We have indeed kept prepared chains, and shackles and a blazing fire for the disbelievers.

# 5596

Indeed the virtuous will drink from a cup, containing a mixture of Kafoor.

# 5597

The Kafoor is a spring, from which the chosen bondmen of Allah will drink, causing it to flow wherever they wish inside their palaces.

# 5598

They fulfil their pledges, and fear a day the evil of which is widespread.

# 5599

And out of His love, they give food to the needy, the orphan and the prisoner.

# 5600

They say to them, “We give you food, only for the sake of Allah – we do not seek any reward or thanks from you.”

# 5601

“Indeed we fear from our Lord a day which is extremely bitter, most severe.”

# 5602

So Allah saved them from the evil of that day, and gave them freshness and joy.

# 5603

And gave them Paradise and silk clothes, as a reward for their patience.

# 5604

Reclining in it, upon thrones; they will not see the hot sunshine in it, nor the bitter cold.

# 5605

And its shade will cover them, and its fruit clusters brought down low for them.

# 5606

Rounds of silver cups and silver beakers, looking like glass, will be presented upon them.

# 5607

Glass made from silver, which the servers have filled up to the measure.

# 5608

And in Paradise they will be given to drink cups, filled with a mixture of ginger.

# 5609

Which is a spring in Paradise called Salsabeel.

# 5610

Immortal youths shall surround them, waiting upon them; when you see them, you would think they are scattered pearls.

# 5611

And when you look towards it, you will see serenity and a great kingdom.

# 5612

In it they adorn clothes of fine green silk and gold embroidery; and they are given silver bracelets to wear; and their Lord gave them pure wine to drink.

# 5613

It will be said to them, “This is your reward – indeed your efforts have been appreciated.”

# 5614

Indeed We have sent down the Qur’an upon you, in stages.

# 5615

Therefore stay patient upon your Lord’s command, and do not listen to any of the sinners or ingrates among them.

# 5616

And remember the name of your Lord morning and evening.

# 5617

And prostrate for Him in a part of the night, and proclaim His purity into the long night.

# 5618

Indeed these people love what they have, the fleeting one, and have forsaken the immensely important day behind them.

# 5619

It is We Who created them, and strengthened their skeleton; and We can replace them with others like them, whenever We will.

# 5620

This is indeed an advice; so whoever wishes may take the path towards his Lord.

# 5621

And what will you wish, except if Allah wills; indeed Allah is All Knowing, Wise.

# 5622

He admits into His mercy, whomever He wills; and for the unjust He has kept prepared a painful punishment.

# 5623

By oath of those that are sent, one after the other. (The verses of the Holy Qur’an or the angels or the winds).

# 5624

Then by oath of those that push with a strong gust.

# 5625

Then by oath of those that lift and carry.

# 5626

Then by those that clearly differentiate the right and wrong.

# 5627

And then by those that instil Remembrance into the hearts.

# 5628

To complete the argument or to warn.

# 5629

Indeed what you are promised, will surely befall.

# 5630

So when the lights of the stars are put out.

# 5631

And when the sky is split apart.

# 5632

And when the mountains are made into dust and blown away.

# 5633

And when the time of the Noble Messengers arrives.

# 5634

For which day were they appointed?

# 5635

For the Day of Decision.

# 5636

And what do you know, what the Day of Decision is!

# 5637

Ruin is for the deniers on that day!

# 5638

Did We not destroy the earlier people?

# 5639

We shall then send the latter after them.

# 5640

This is how We deal with the guilty.

# 5641

Ruin is for the deniers on that day!

# 5642

Did We not create you from an abject fluid?

# 5643

We then kept it in a safe place.

# 5644

For a known calculated term.

# 5645

We then calculated; so how excellently do We control!

# 5646

Ruin is for the deniers on that day!

# 5647

Did We not make the earth a storehouse?

# 5648

For the living and the dead among you?

# 5649

And We placed high mountains as anchors in it and gave you sweet water to drink.

# 5650

Ruin is for the deniers on that day!

# 5651

“Move towards what you used to deny!”

# 5652

“Move towards the shadow of the smoke having three branches.”

# 5653

“Which neither gives shade, nor saves from the flame.”

# 5654

Indeed hell throws up sparks like huge castles.

# 5655

Seeming like yellow camels.

# 5656

Ruin is for the deniers on that day!

# 5657

This is a day in which they will not be able to speak.

# 5658

Nor will they be given permission to present excuses.

# 5659

Ruin is for the deniers on that day!

# 5660

This is the Day of Decision; We have gathered you and all the earlier men.

# 5661

If you now have any conspiracy, carry it out on Me.

# 5662

Ruin is for the deniers on that day!

# 5663

Indeed the pious are in shade and springs.

# 5664

And among fruits whichever they may desire.

# 5665

“Eat and drink with pleasure, the reward of your deeds.”

# 5666

This is how We reward the virtuous.

# 5667

Ruin is for the deniers on that day!

# 5668

“Eat and enjoy for a while – indeed you are guilty.”

# 5669

Ruin is for the deniers on that day!

# 5670

And when it is said to them, “Offer the prayer” – they do not!

# 5671

Ruin is for the deniers on that day!

# 5672

So after this, in what matter will they believe?

# 5673

What are they questioning each other about?

# 5674

About the great tidings!

# 5675

Regarding which they hold different views.

# 5676

Surely yes, they will soon come to know!

# 5677

Again surely yes, they will soon come to know!

# 5678

Did We not make the earth a bed?

# 5679

And the mountains as pegs?

# 5680

And it is We who created you in pairs.

# 5681

And made your sleep a rest.

# 5682

And made the night a cover.

# 5683

And made the day for seeking livelihood.

# 5684

And built seven strong roofs above you.

# 5685

And have kept a very bright lamp in it.

# 5686

And then sent down hard rain from the water bearing clouds.

# 5687

In order to produce grain and plants with it.

# 5688

And dense gardens.

# 5689

Indeed the Day of Decision is a time fixed.

# 5690

The day when the Trumpet will be blown – you will therefore come forth in multitudes.

# 5691

And the heaven will be opened – it therefore becomes like gates.

# 5692

And the mountains will be moved – they will therefore become like mirages.

# 5693

Indeed hell is lying in ambush.

# 5694

The destination of the rebellious.

# 5695

They will remain in it for ages.

# 5696

They will neither taste anything cool in it, nor anything to drink.

# 5697

Except hot boiling water and hot pus discharged from the people of hell.

# 5698

The reward to each is according to what he is.

# 5699

Indeed they had no fear of the account.

# 5700

And they denied Our signs to the extreme.

# 5701

And We have kept recorded everything in a Book, accounted for.

# 5702

Therefore taste it now – We shall not increase anything for you except the punishment.

# 5703

Indeed the place of success is for the pious.

# 5704

Gardens and grapes.

# 5705

And maidens of a single age.

# 5706

And an overflowing cup.

# 5707

In which they shall neither hear lewd talk, nor any lie.

# 5708

A reward from your Lord – a grossly sufficient bestowal.

# 5709

Lord of the heavens and the earth, and all whatever is between them – the Most Gracious – with Whom no one will have the right to talk.

# 5710

The day when Jibreel and all the angels will stand in rows; none will be able to speak except one whom the Most Gracious commands and who spoke rightly. (Prophet Mohammed – peace and blessings be upon him – will be the first to be granted permission to intercede.)

# 5711

That is the True Day; therefore whoever wills may take the path towards his Lord.

# 5712

We warn you of a punishment that has come near; a day on which man will see what his own hands have sent ahead, and the disbeliever will say, “Alas – if only I were dust!”

# 5713

By oath of those who harshly pull out the soul. (Of the disbeliever)

# 5714

And who softly release the soul. (Of the believer)

# 5715

And who glide with ease.

# 5716

And who quickly present themselves.

# 5717

And who plan the implementation.

# 5718

On the day when the trembling one will tremble. (The disbelievers will certainly taste the punishment.)

# 5719

And the following event will come after it.

# 5720

Many a heart will flutter on that day!

# 5721

Unable to lift their gaze.

# 5722

The disbelievers say, “Will we really return to our former state?”

# 5723

“When we have become decayed bones?”

# 5724

They said, “So this return is an obvious loss!”

# 5725

So that is not but a single shout.

# 5726

So they will immediately be in an open plain.

# 5727

Did the news of Moosa reach you?

# 5728

When his Lord called him in the holy valley of Tuwa.

# 5729

That “Go to Firaun – he has rebelled.”

# 5730

“Tell him ‘Do you have the inclination to become pure?’

# 5731

‘And I may guide you to your Lord, so that you may fear.’”

# 5732

So Moosa showed him a magnificent sign.

# 5733

In response, he denied and disobeyed.

# 5734

He then turned away, striving in his effort.

# 5735

So he gathered the people, and proclaimed.

# 5736

And then said, “I am your most supreme lord.”

# 5737

Allah therefore seized him, in the punishment of this world and the Hereafter.

# 5738

Indeed in this is a lesson for one who fears.

# 5739

Do you think that it is harder to create you or the heavens? Allah has created it.

# 5740

He raised its roof and made it proper.

# 5741

And He made its night dark, and started its light.

# 5742

And after it spread out the earth.

# 5743

And from it produced its water and its pasture.

# 5744

And solidified the mountains.

# 5745

In order to benefit you and your cattle.

# 5746

So when the greatest universal disaster arrives,

# 5747

On that day man will recall all what he strove for.

# 5748

And hell will be made visible to all those who can see.

# 5749

So for one who rebelled,

# 5750

And preferred the worldly life,

# 5751

Then indeed hell only is his destination.

# 5752

And for one who feared to stand before his Lord and restrained his soul from desire,

# 5753

Then indeed Paradise only is his destination.

# 5754

They (the disbelievers) ask you regarding the Last Day, as to when is its appointed time.

# 5755

What concern do you have regarding its explanation? (You are not bound to tell them)

# 5756

Towards your Lord only is its conclusion.

# 5757

You are but a Herald of Warning, for one who fears it.

# 5758

The day when they will see it, it will seem as if they had not stayed on earth except for an evening or its morning.

# 5759

He frowned and turned away.

# 5760

Because the blind man had come in his august presence.

# 5761

And what do you know, he may be of the pure!

# 5762

Or that he may accept advice, so the advice may benefit him.

# 5763

For him who does not care,

# 5764

So you are after him!

# 5765

And you have nothing to lose if he does not become pure.

# 5766

And for him who came to you striving,

# 5767

And whereas he fears,

# 5768

So you leave him, and are engrossed elsewhere!

# 5769

Not this way – this is the advice.

# 5770

So whoever wishes may remember it.

# 5771

On honourable pages.

# 5772

Exalted, pure.

# 5773

Written by the hands of emissaries.

# 5774

Who are noble, virtuous.

# 5775

May man be slain – how ungrateful he is!

# 5776

From what did He create him?

# 5777

From a drop of liquid; He created him and then set several measures for him.

# 5778

Then eased the way for him.

# 5779

Then gave him death, so had him put in the grave.

# 5780

Then, when He willed, He brought him out. (As during the night of Holy Prophet’s ascension, when all the Prophets gathered behind him in the Al Aqsa mosque in Jerusalem. Or when Allah will raise everyone on the Day of Resurrection.)

# 5781

Not one – he has not yet completed what he was commanded.

# 5782

So man must look at his food.

# 5783

That We watered it in abundance.

# 5784

Then We split the earth properly.

# 5785

Thereby produced grain in it.

# 5786

And grapes and fodder,

# 5787

And olives and date palms,

# 5788

And dense gardens,

# 5789

And fruits and grass,

# 5790

In order to benefit you and your cattle.

# 5791

So when the deafening Shout arrives,

# 5792

On that day man will run away from his brother.

# 5793

And from his mother and father,

# 5794

And from his wife and sons.

# 5795

On that day, each one has just one issue, which is enough for him.

# 5796

Many a face will be glittering on that day.

# 5797

Laughing, rejoicing.

# 5798

And many a face will be covered with dust on that day.

# 5799

Blackness overcoming them.

# 5800

It is they, the disbelievers, the sinners.

# 5801

When the sunlight is rolled up.

# 5802

And when the stars fall down.

# 5803

And when the mountains are driven.

# 5804

And when milch camels roam abandoned.

# 5805

And when wild animals are herded together.

# 5806

And when the seas are set afire.

# 5807

And when the souls are paired.

# 5808

And when the girl-child who was buried alive is asked.

# 5809

Upon what sin was she killed for.

# 5810

And when the Records of Account are laid bare.

# 5811

And when the heaven is torn away.

# 5812

And when hell is further enflamed.

# 5813

And when Paradise is brought near.

# 5814

Every soul will then come know what it has brought.

# 5815

So by oath of those that revolve. (The planets.)

# 5816

Who move straight and stop.

# 5817

And by oath of the night when it turns back.

# 5818

And by oath of the morning when it takes birth.

# 5819

This is indeed the recitation of an honoured Noble Messenger. (Angel Jibreel – peace and blessings be upon him.)

# 5820

The mighty, the honoured in the presence of the Lord of the Throne.

# 5821

The one who is obeyed, and trustworthy. (Other angels obey angel Jibreel).

# 5822

And your companion is not insane.

# 5823

And indeed he saw him on the clear horizon. (Prophet Mohammed saw Angel Jibreel in his true shape – peace and blessings be upon them).

# 5824

And this Prophet is not miserly upon the hidden. (Allah gave the knowledge of the hidden to the Holy Prophet – peace and blessings be upon him.)

# 5825

And the Qur’an is not the recitation of Satan the outcast.

# 5826

So where are you going?

# 5827

That is but an advice to the entire creation!

# 5828

For the one among you who wishes to become upright.

# 5829

And what will you wish, except if Allah wills – the Lord of the Creation.

# 5830

When the heaven splits open.

# 5831

And when the stars fall down.

# 5832

And when the oceans are swept away.

# 5833

And when the graves are overturned.

# 5834

Every soul will come to know what it has sent ahead and what it left behind.

# 5835

O man! What has deceived you away from your Lord, the Most Beneficent?

# 5836

The One Who created you, then moulded you, then made you proper?

# 5837

He moulded you into whatever shape He willed.

# 5838

Not at all – but rather you deny the establishment of Justice.

# 5839

And indeed there are some guardians over you.

# 5840

The honourable recorders.

# 5841

Knowing all what you may do.

# 5842

Indeed the virtuous are in serenity.

# 5843

And indeed the sinners are in hell.

# 5844

They will enter it on the Day of Justice.

# 5845

And will not be able to hide from it.

# 5846

And what do you know – of what sort is the Day of Justice!

# 5847

Again, what do you know – of what sort is the Day of Justice!

# 5848

The day on which no soul will have the authority over any other soul; and on that day, the entire command belongs to Allah.

# 5849

Ruin is for the defrauders. (Those who measure less.)

# 5850

Those who when they take the measure from others, take it in full!

# 5851

Whereas when they give others after measuring or weighing, they give them less!

# 5852

What! Do they not expect that they will be raised?

# 5853

(To be raised) for a Great Day?

# 5854

The day when everyone will stand before the Lord Of The Creation.

# 5855

Indeed, the record of the disbelievers is in the lowest place, the Sijjeen.

# 5856

And what do you know, how (wretched) the Sijjeen is!

# 5857

The record is a sealed text.

# 5858

Ruin is for the deniers on that day!

# 5859

Those who deny the Day of Justice.

# 5860

And none will deny it, except every transgressor, rebel.

# 5861

When you recite Our verses to him, he says, “Stories of earlier men!”

# 5862

Not at all – but rather their earnings have heaped rust upon their hearts.

# 5863

Yes indeed – they will be deprived of seeing their Lord on that day.

# 5864

Then indeed they have to enter hell.

# 5865

It will then be said, “This is what you used to deny.”

# 5866

Indeed the record of the virtuous is in the highest place, the Illiyin.

# 5867

And what do you know what the Illiyoon are!

# 5868

The record is a sealed text.

# 5869

Which is witnessed by the close ones.

# 5870

Indeed the virtuous are in serenity.

# 5871

On thrones, watching.

# 5872

You will recognise the freshness of serenity on their faces.

# 5873

They will be given pure wine to drink, which is kept preserved, sealed.

# 5874

Its seal is upon musk; and for this should those who crave be eager.

# 5875

And it is mixed with Tasneem.

# 5876

The spring from which drink the ones close to Allah.

# 5877

Indeed the guilty used to laugh at the believers.

# 5878

And when the believers used to pass by, they used to gesture at each other with their eyes.

# 5879

And whilst returning to their homes, they used to return rejoicing.

# 5880

And upon seeing the Muslims, they used to say, “Indeed they have gone astray.”

# 5881

Whereas they have not at all been sent as guardians over them.

# 5882

So this day it is the believers who laugh at the disbelievers.

# 5883

On high thrones, watching.

# 5884

Did not the disbelievers get repaid for what they used to do?

# 5885

When the heaven breaks apart.

# 5886

And it listens to the command of its Lord – and that befits it.

# 5887

And when the earth is spread out.

# 5888

And it unburdens itself of all that is in it, and becomes empty.

# 5889

And it listens to the command of its Lord – and that befits it.

# 5890

O man, indeed you have to surely run towards your Lord, and to meet him.

# 5891

So whoever is given his record of deeds in his right hand –

# 5892

Soon an easy account will be taken from him.

# 5893

And he will return to his family rejoicing.

# 5894

And whoever is given his record of deeds behind his back –

# 5895

Soon he will pray for death.

# 5896

And will go into the blazing fire.

# 5897

Indeed he used to rejoice in his home.

# 5898

He assumed that he does not have to return.

# 5899

Surely yes, why not? Indeed his Lord is seeing him.

# 5900

So by oath of the late evening’s light.

# 5901

And by oath of the night and all that gathers in it.

# 5902

And by oath of the moon when it is full.

# 5903

You will surely go up level by level.

# 5904

What is the matter with them that they do not accept faith?

# 5905

And when the Qur’an is recited to them, they do not fall prostrate? (Command of Prostration # 13)

# 5906

In fact the disbelievers keep denying.

# 5907

And Allah well knows what they conceal in their hearts.

# 5908

Therefore give them the glad tidings of a painful punishment.

# 5909

Except those who believed and did good deeds – for them is a reward that will never end.

# 5910

By oath of the heaven which contains the constellations.

# 5911

And by oath of the Promised Day.

# 5912

And by oath of the day that is a witness and by oath of a day in which the people present themselves.

# 5913

Accursed be the People of the Ditch!

# 5914

The people of the fuelled blazing fire.

# 5915

When they were sitting at its edge.

# 5916

And they themselves are witnesses to what they were doing to the Muslims!

# 5917

And what did they dislike from the Muslims, except that the Muslims accepted faith in Allah the Most Honourable, the Most Praiseworthy?

# 5918

To Him only belongs the kingship of the heavens and the earth; and Allah is a Witness over all things.

# 5919

Indeed those who troubled the Muslim men and Muslim women, and then did not repent – for them is the punishment of hell, and for them is the punishment of fire.

# 5920

Indeed those who believed and did good deeds – for them are Gardens beneath which rivers flow; this is the great success.

# 5921

Indeed the seizure of your Lord is very severe.

# 5922

Indeed it is He Who initiates and redoes.

# 5923

And He only is the Oft Forgiving, the Beloved of His bondmen.

# 5924

Master of the Honourable Throne.

# 5925

Always doing whatever He wills.

# 5926

Did the story of the armies reach you?

# 5927

(The armies of) Firaun and the tribe of Thamud.

# 5928

In fact the disbelievers are in denial.

# 5929

And Allah is after them, has them surrounded.

# 5930

In fact it (what they deny) is the Noble Qur’an.

# 5931

In the Preserved Tablet.

# 5932

By oath of the heaven, and by oath of the nightly arriver.

# 5933

And have you understood what the nightly arriver is?

# 5934

The very brightly shining star!

# 5935

There is not a soul that does not have a guardian over it.

# 5936

So man must consider from what he has been created.

# 5937

Created from a gushing fluid.

# 5938

That is issued from between the backs and the ribs.

# 5939

Indeed Allah is Able to return him.

# 5940

A day when the secrets will be examined.

# 5941

So man will neither have any strength nor any aide.

# 5942

By oath of the sky from which comes down the rain.

# 5943

And by oath of the earth which flourishes with it.

# 5944

Indeed the Qur’an is a decisive Word.

# 5945

And is not a matter of amusement.

# 5946

Indeed the disbelievers carry out their evil schemes.

# 5947

And I secretly plan.

# 5948

Therefore give them some respite – give them some time.

# 5949

Proclaim the Purity of your Lord, the Supreme.

# 5950

The One Who created, and then made proper.

# 5951

And the One Who kept proper measure and then guided.

# 5952

The One Who produced pasture.

# 5953

Then made it dry and dark.

# 5954

We shall now make you read (O dear Prophet Mohammed – peace and blessings be upon him), so you will not forget.

# 5955

Except what Allah wills; indeed He knows all the evident and all the concealed.

# 5956

And We shall create the means of ease for you.

# 5957

Therefore advise, if advising is beneficial.

# 5958

Soon whoever fears will heed advice.

# 5959

And the most wicked will stay away from it.

# 5960

The one who will enter the biggest fire.

# 5961

Then he neither dies in it, nor lives.

# 5962

Indeed successful is the one who became pure.

# 5963

And who mentioned the name of his Lord, then offered prayer.

# 5964

But rather you prefer the life of this world!

# 5965

Whereas the Hereafter is better and everlasting.

# 5966

Indeed this is in the former scriptures.

# 5967

In the Books of Ibrahim and Moosa.

# 5968

Certainly the news of the calamity that will overwhelm has come to you!

# 5969

Many a face will be disgraced on that day.

# 5970

Labouring, striving hard.

# 5971

(Yet) Going into the blazing fire.

# 5972

Made to drink water from the boiling hot spring.

# 5973

There is no food for them except thorns of fire.

# 5974

Which neither give strength nor satisfy the hunger.

# 5975

Many a face will be in serenity on that day.

# 5976

Rejoicing over their efforts.

# 5977

In a high Garden.

# 5978

In which they will not hear any lewd speech.

# 5979

In it is a flowing spring.

# 5980

In which are high thrones.

# 5981

And chosen goblets.

# 5982

And arranged carpets.

# 5983

And linen spread out.

# 5984

So do they not see the camel – how it has been created?

# 5985

And the heaven – how it has been raised?

# 5986

And the mountains – how they have been established?

# 5987

And the earth – how it has been spread out?

# 5988

Therefore advise; indeed you are a proclaimer of advice. (The Holy Prophet is a Remembrance from Allah.)

# 5989

You are not at all a guardian over them.

# 5990

Except whoever turns away and disbelieves –

# 5991

So Allah will mete out to him the greatest punishment.

# 5992

Indeed only towards Us is their return

# 5993

Then indeed only upon Us is their reckoning.

# 5994

By oath of the (particular) dawn.

# 5995

And by oath of ten nights.

# 5996

And by oath of the even and the odd.

# 5997

And by oath of the night when it recedes

# 5998

Why is there an oath in this, for the intelligent?

# 5999

Did you not see how did your Lord deal with (the tribe of) Aad?

# 6000

(And) the tall giants of Iram?

# 6001

Like whom no one else was born in the cities.

# 6002

And the tribe of Thamud, who hewed rocks in the valley.

# 6003

And with Firaun, who used to crucify.

# 6004

Those who rebelled in the cities,

# 6005

And who then spread a lot of turmoil in them.

# 6006

Therefore your Lord struck them hard with the means of punishment.

# 6007

Indeed nothing is hidden from the sight of your Lord.

# 6008

So man, whenever his Lord tests him by giving him honour and favours – thereupon he says, “My Lord has honoured me.”

# 6009

And if He tests him and restricts his livelihood – thereupon he says, “My Lord has degraded me!”

# 6010

Not at all – but rather you do not honour the orphan.

# 6011

And do not urge one another to feed the needy.

# 6012

And you readily devour the inheritance with greed.

# 6013

And you harbour intense love for wealth.

# 6014

Most certainly – when the earth is smashed and blown to bits.

# 6015

And when the command of your Lord comes – and the angels row by row,

# 6016

And when hell is brought that day – on that day will man reflect, but where is the time now to think?

# 6017

He will say, “Alas – if only I had sent some good deeds ahead, during my lifetime!”

# 6018

So on that day, no one punishes like He does!

# 6019

And no one binds like He does!

# 6020

O the contented soul!

# 6021

Return towards your Lord – you being pleased with Him, and He pleased with you!

# 6022

Then enter the ranks of My chosen bondmen!

# 6023

And come into My Paradise!

# 6024

I swear by this city (Mecca) –

# 6025

For you (O dear Prophet Mohammed – peace and blessings be upon him) are in this city.

# 6026

And by oath of your forefather Ibrahim, and by you – his illustrious son!

# 6027

We have indeed created man surrounded by hardships.

# 6028

Does man think that no one will ever have power over him?

# 6029

He says, “I destroyed vast wealth.”

# 6030

Does man think that no one saw him?

# 6031

Did We not make two eyes for him?

# 6032

And a tongue and two lips?

# 6033

And did We not guide him to the two elevated things?

# 6034

So he did not quickly enter the steep valley.

# 6035

And what have you understood, what the valley is!

# 6036

The freeing of a slave!

# 6037

Or the feeding on a day of hunger.

# 6038

Of a related orphan,

# 6039

Or of a homeless needy person!

# 6040

And moreover to be of those who accepted faith, and who urged patience to one another and who urged graciousness to one another.

# 6041

These are the people of the right.

# 6042

And those who denied Our signs, are the people of the left.

# 6043

Upon them is a fire, in which they are imprisoned, closed and shut above them.

# 6044

By oath of the sun and its light

# 6045

And by oath of the moon when it follows the sun

# 6046

And by oath of the day when it reveals it

# 6047

And by oath of the night when it hides it

# 6048

And by oath of the heaven and by oath of Him Who made it.

# 6049

And by oath of the earth and by oath of Him Who spread it.

# 6050

And by oath of the soul and by oath of Him Who made it proper.

# 6051

And inspired in it the knowledge of its sins and its piety.

# 6052

Indeed successful is the one who made it pure.

# 6053

And indeed failed is the one who covered it in sin.

# 6054

The tribe of Thamud denied with rebellion.

# 6055

When the most wicked among them stood up in defiance.

# 6056

So the Noble Messenger of Allah said to them, “Stay away from the she camel of Allah, and from its turn to drink.”

# 6057

In response they belied him, and hamstrung the she camel – so Allah put ruin over them because of their sins and flattened their dwellings.

# 6058

And He does not fear its coming behind (to take vengeance).

# 6059

By oath of the night when it covers

# 6060

And by oath of the day when it shines

# 6061

And by oath of the One Who created the male and the female.

# 6062

Indeed your efforts differ.

# 6063

So for one who gave and practised piety

# 6064

And believed the best matter to be true

# 6065

So We will very soon provide him ease.

# 6066

And for him who hoarded wealth and remained carefree,

# 6067

And denied the best matter,

# 6068

So We will very soon provide him hardship.

# 6069

His wealth will not avail him when he falls into ruin.

# 6070

Indeed guiding is upon Us.

# 6071

And indeed the Hereafter and this world both belong to Us.

# 6072

I therefore warn you of the fire that is ablaze.

# 6073

None except the most wicked will enter it.

# 6074

The one who denied and turned away.

# 6075

He will be far away from the most pious. (The first Caliph S. Abu Bakr Siddiq)

# 6076

Who gives his wealth in order to be pure.

# 6077

And no one has done a favour to him, for which he should be compensated.

# 6078

He desires only to please his Lord, the Supreme.

# 6079

And indeed, soon he will be very pleased.

# 6080

By oath of the late morning,

# 6081

And by oath of the night when it covers,

# 6082

Your Lord has not forsaken you nor does He dislike you!

# 6083

And indeed the latter is better for you than the former.

# 6084

And indeed your Lord will soon give you so much that you will be pleased. (Allah seeks to please the Holy Prophet – peace and blessings be upon him.)

# 6085

Did He not find you an orphan, so provided you shelter?

# 6086

And found you deeply engrossed in His love, so directed you?

# 6087

And found you in need, so made you prosperous?

# 6088

Therefore do not oppress the orphan.

# 6089

And do not rebuke the beggar.

# 6090

And abundantly proclaim the favours of your Lord.

# 6091

Did We not widen your bosom?

# 6092

And relieve you of the burden –

# 6093

Which had broken your back?

# 6094

And We have exalted your remembrance for you.

# 6095

So indeed with hardship is ease.

# 6096

Indeed with hardship is ease.

# 6097

So when you finish the prayer, strive in supplication.

# 6098

And incline towards your Lord.

# 6099

By oath of the fig and of the olive,

# 6100

And by oath of Mount Sinai,

# 6101

And by oath of this secure land,

# 6102

We have indeed created man in the best shape.

# 6103

We then turned him towards all the lowest of the low states.

# 6104

Except those who accepted faith and did good deeds – for them is a never ending reward.

# 6105

So after this, what causes you to deny the judgement?

# 6106

Is not Allah the Greatest Judge upon all judges?

# 6107

Read with the name of your Lord Who created,

# 6108

Created man from a clot.

# 6109

Read, and your Lord only is the Most Beneficent,

# 6110

The One Who taught to write with the pen.

# 6111

The One Who taught man all what he did not know.

# 6112

Yes indeed, man is surely rebellious.

# 6113

As he considers himself independent!

# 6114

Indeed towards your Lord only is the return.

# 6115

What is your opinion – regarding him who forbids –

# 6116

A bondman when he offers the prayer?

# 6117

What is your opinion – if he were upon guidance,

# 6118

He would enjoin piety, so how good it would be!

# 6119

What is your opinion – if he denies and turns away, how wretched will be his state!

# 6120

Did he not realise that Allah is watching?

# 6121

Yes certainly, if he does not desist, We will seize him by the forelock.

# 6122

A forelock that lies, is sinful.

# 6123

So let him now call his gang!

# 6124

We will now call the guards!

# 6125

Yes indeed; do not listen to him – and prostrate, and become close to Us. (Command of Prostration # 14)

# 6126

We have indeed sent down the Qur’an in the Night of Destiny.

# 6127

And what have you understood, what the Night of Destiny is!

# 6128

The Night of Destiny is better than a thousand months.

# 6129

In it descend the angels and Jibreel, by the command of their Lord – for all works.

# 6130

It is peace until the rising of dawn.

# 6131

The disbelieving People of the Book(s) and the polytheists would not have left their religion until the clear proof came to them.

# 6132

(The clear proof is) the Noble Messenger from Allah, who reads the pure pages.

# 6133

In which are written proper affairs.

# 6134

Nor did the People of the Book(s) get divided until after the clear proof came to them.

# 6135

And they were ordered only to worship Allah, believing purely in Him – devoted solely (to Him), and to establish the prayer and to pay the obligatory charity – and this is the straight religion.

# 6136

Indeed all disbelievers, the People of the Book(s) and the polytheists, are in the fire of hell – they will remain in it for ever; it is they who are the worst among the creation.

# 6137

Indeed those who accepted faith and did good deeds – it is they who are the best among the creation.

# 6138

Their reward is – with their Lord – everlasting Gardens of Eden beneath which rivers flow, in which they will abide for ever and ever; Allah is pleased with them and they are pleased with Him; this is for one who fears his Lord.

# 6139

When the earth is shaken with its appointed tremor.

# 6140

And the earth throws out its burdens.

# 6141

And man says, “What has happened to it?”

# 6142

On that day earth will narrate its news,

# 6143

Because your Lord sent a command to it.

# 6144

On that day men will return towards their Lord, in different groups, in order to be shown their deeds.

# 6145

So whoever does a good deed equal to the weight of the minutest particle, will see it.

# 6146

And whoever does an evil deed equal to the weight of the minutest particle, will see it.

# 6147

By oath of those that sprint, breathing heavily. (The horses used in Holy War.)

# 6148

Striking stones with their hooves, sparking fire.

# 6149

And by oath of those who raid at dawn.

# 6150

So thereupon raising dust.

# 6151

Then penetrate to the centre of the enemy army.

# 6152

Indeed man is very ungrateful towards his Lord.

# 6153

And indeed he himself is a witness to it.

# 6154

And indeed he loves wealth to the extreme.

# 6155

So does he not know? When those in the graves are raised,

# 6156

And all what lies in the breasts is opened –

# 6157

On that day their Lord surely knows all about them!

# 6158

The event that terrifies the hearts!

# 6159

What is the event that terrifies the hearts?

# 6160

And what have you understood, what the event that terrifies the hearts is!

# 6161

The day when men will be like scattered moths.

# 6162

And mountains will be like flying wool.

# 6163

So for one whose scales prove heavy,

# 6164

He is therefore in the desired bliss.

# 6165

And for one whose scales prove light,

# 6166

He is in the lap of one that abases.

# 6167

And what have you understood, what the one that abases is!

# 6168

A flaming fire!

# 6169

The craving for excess wealth kept you people neglectful.

# 6170

Until you confronted the graves.

# 6171

Yes certainly, you will soon realise!

# 6172

Again, yes certainly, you will soon realise!

# 6173

Yes certainly, if you had believed with certainty, you would not have craved for wealth.

# 6174

Indeed you will see hell.

# 6175

Again, indeed you will see it with certainty.

# 6176

Then, on that day, you will surely be questioned regarding the favours.

# 6177

By oath of this era of yours (O dear Prophet Mohammed – peace and blessings be upon him).

# 6178

Indeed man is surely in a loss.

# 6179

Except those who accepted faith, and did good deeds and urged one another to the truth – and urged one another to have patience.

# 6180

Ruin is for every open slanderer, backbiter.

# 6181

Who accumulated wealth and hoarded it, counting.

# 6182

Does he think that his wealth will prolong his stay on earth forever?

# 6183

Never! He will certainly be thrown into the Crushing One.

# 6184

And what have you understood what the Crushing One is!

# 6185

The fire of Allah, that is ablaze.

# 6186

Which will climb on to the hearts.

# 6187

Indeed it will be shut over them.

# 6188

In extended columns.

# 6189

O dear Prophet (Mohammed – peace and blessings be upon him), did you not see how did your Lord deal with the People of the Elephant?

# 6190

Did He not put their scheme into ruin?

# 6191

And send flocks of birds upon them,

# 6192

Which hit them with stones of baked clay,

# 6193

So He made them like the leftover devoured leaves of farms?

# 6194

Because of giving alliances to the Quraish.

# 6195

(We) gave them alliances during both their travels of winter and summer.

# 6196

So they must worship the Lord of this House. (The Ka’aba)

# 6197

The One Who gave them food in hunger, and bestowed them safety from a great fear.

# 6198

Just look at him, who belies the religion!

# 6199

So it is he, who pushes away the orphan,

# 6200

And does not urge to feed the needy.

# 6201

So ruin is to those offerers of prayer –

# 6202

Those who are neglectful of their prayer.

# 6203

Those who make a display (of their deeds).

# 6204

And do not let others ask for small utilities.

# 6205

We have indeed bestowed the Kausar\* upon you (O dear prophet Mohammed – peace and blessings be upon him). (\*Infinite excellent qualities / the greatest number of followers / the sweet pond on the Day of Resurrection)

# 6206

So offer the prayers for your Lord, and perform the sacrifice.

# 6207

Indeed it is your enemy who is bereft of all goodness.

# 6208

Proclaim, (O dear prophet Mohammed – peace and blessings be upon him), “O disbelievers!”

# 6209

Neither do I worship what you worship.

# 6210

Nor do you worship Whom I worship.

# 6211

And neither will I ever worship what you worship.

# 6212

Nor will you worship Whom I worship.

# 6213

For you is your religion, and for me is mine.

# 6214

When the help and victory of Allah come,

# 6215

And you see people entering the religion of Allah in multitudes,

# 6216

Then proclaim the Purity of your Lord while praising Him, and seek forgiveness from Him; indeed He is the Most Acceptor of Repentance.

# 6217

May both the hands of Abu Lahab be destroyed – and they are destroyed!

# 6218

His wealth did not benefit him in the least, nor did whatever he earned.

# 6219

He will soon enter the flaming fire.

# 6220

And so will his wife; carrying a bundle of firewood on her head.

# 6221

A rope made from palm fibre around her neck!

# 6222

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “He is Allah, He is One.”

# 6223

“Allah is the Un-wanting.” (Perfect, does not require anything.)

# 6224

“He has no offspring, nor is He born from anything.”

# 6225

“And there is none equal to Him.”

# 6226

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I take refuge of the One Who creates the Daybreak.”

# 6227

“From the evil of His entire creation.”

# 6228

“And from the evil of the matter that darkens when it sets.”

# 6229

“And from the evil of the witches who blow into knots.”

# 6230

“And from the evil of the envier when he is envious of me.”

# 6231

Proclaim (O dear Prophet Mohammed – peace and blessings be upon him), “I take refuge of the One Who is the Lord of all mankind.”

# 6232

“The King of all mankind.”

# 6233

“The God of all mankind.”

# 6234

“From the evil of the one who instils evil thoughts in the hearts – and stays hidden.”

# 6235

“Those who instil evil thoughts into the hearts of men.”

# 6236

“Among the jinns and men.”

