<!--
Quran Translation
Name: Qarai
Translator: Ali Quli Qarai
Language: English
ID: en.qarai
Last Update: April 11, 2022
Source: Tanzil.net
-->

# 1

In the Name of Allah, the All-beneficent, the All-merciful.

# 2

All praise belongs to Allah, Lord of all the worlds,

# 3

the All-beneficent, the All-merciful,

# 4

Master of the Day of Retribution.

# 5

You \[alone\] do we worship, and to You \[alone\] do we turn for help.

# 6

Guide us on the straight path,

# 7

the path of those whom You have blessed — such as have not incurred Your wrath, nor are astray.

# 8

Alif, Lam, Mim.

# 9

This is the Book, there is no doubt in it, a guidance to the Godwary,

# 10

who believe in the Unseen, maintain the prayer, and spend out of what We have provided for them;

# 11

and who believe in what has been sent down to you and what was sent down before you, and are certain of the Hereafter.

# 12

Those follow their Lord’s guidance and it is they who are the felicitous.

# 13

As for the faithless, it is the same to them whether you warn them or do not warn them, they will not have faith.

# 14

Allah has set a seal on their hearts and their hearing, and there is a blindfold on their sight, and there is a great punishment for them.

# 15

Among the people are those who say, ‘We have faith in Allah and the Last Day,’ but they have no faith.

# 16

They seek to deceive Allah and those who have faith, yet they deceive no one but themselves, but they are not aware.

# 17

There is a sickness in their hearts; then Allah increased their sickness, and there is a painful punishment for them because of the lies they used to tell.

# 18

When they are told, ‘Do not cause corruption on the earth,’ they say, ‘We are only reformers!’

# 19

Behold! They are themselves the agents of corruption, but they are not aware.

# 20

And when they are told, ‘Believe like the people who have believed,’ they say, ‘Shall we believe like the fools who have believed?’ Behold! They are themselves the fools, but they do not know.

# 21

When they meet the faithful, they say, ‘We believe,’ but when they are alone with their devils, they say, ‘We are with you; we were only deriding \[them\].’

# 22

It is Allah who derides them, and leaves them bewildered in their rebellion.

# 23

They are the ones who bought error for guidance, so their trade did not profit them, nor were they guided.

# 24

Their parable is that of one who lighted a torch, and when it had lit up all around him, Allah took away their light, and left them sightless in a manifold darkness.

# 25

Deaf, dumb, and blind, they will not come back.

# 26

Or that of a rainstorm from the sky, wherein is darkness, thunder and lightning: they put their fingers in their ears due to the thunderclaps, apprehensive of death; and Allah besieges the faithless.

# 27

The lightning almost snatches away their sight: whenever it shines for them, they walk in it, and when the darkness falls upon them, they stand. Had Allah willed, He would have taken away their hearing and sight. Indeed Allah has power over all things.

# 28

O mankind! Worship your Lord, who created you and those who were before you, so that you may be Godwary

# 29

—He who made the earth a place of repose for you, and the sky a canopy, and He sends down water from the sky and with it brings forth crops for your sustenance. So do not set up equals to Allah, while you know.

# 30

And if you are in doubt concerning what We have sent down to Our servant, then bring a surah like it, and invoke your helpers besides Allah, if you are truthful.

# 31

But if you do not—and you will not—then beware the Fire whose fuel will be humans and stones, prepared for the faithless.

# 32

And give good news to those who have faith and do righteous deeds, that for them shall be gardens with streams running in them: whenever they are provided with their fruit for nourishment, they will say, ‘This is what we were provided before,’ and they were given something resembling it. There will be chaste mates for them, and they will remain therein \[forever\].

# 33

Indeed Allah is not ashamed to draw a parable whether it is that of a gnat or something above it. As for those who have faith, they know it is the truth from their Lord; and as for the faithless, they say, ‘What did Allah mean by this parable?’ Thereby He leads many astray, and thereby He guides many; and He leads no one astray thereby except the transgressors

# 34

—those who break the covenant made with Allah after having pledged it solemnly, and sever what Allah has commanded to be joined, and cause corruption on the earth—it is they who are the losers.

# 35

How can you be unfaithful to Allah, \[seeing that\] you were lifeless and He gave you life, then He will make you die and then bring you to life, and then you will be brought back to Him?

# 36

It is He who created for you all that is in the earth, then He turned to the heaven and fashioned it into seven heavens, and He has knowledge of all things.

# 37

When your Lord said to the angels, ‘Indeed I am going to set a viceroy on the earth,’ they said, ‘Will You set in it someone who will cause corruption in it and shed blood, while we celebrate Your praise and proclaim Your sanctity?’ He said, ‘Indeed I know what you do not know.’

# 38

And He taught Adam the Names, all of them; then presented them to the angels and said, ‘Tell me the names of these, if you are truthful.’

# 39

They said, ‘Immaculate are You! We have no knowledge except what You have taught us. Indeed You are the All-knowing, the All-wise.’

# 40

He said, ‘O Adam, inform them of their names,’ and when he had informed them of their names, He said, ‘Did I not tell you that I know the Unseen of the heavens and the earth, and that I know whatever you disclose and whatever you conceal?’

# 41

And when We said to the angels, ‘Prostrate before Adam,’ they prostrated, but not Iblis: he refused and acted arrogantly, and he was one of the faithless.

# 42

We said, ‘O Adam, dwell with your mate in paradise and eat thereof freely whencesoever you wish, but do not approach this tree, lest you should be among the wrongdoers.’

# 43

Then Satan caused them to stumble from it, and he dislodged them from what \[state\] they were in; and We said, ‘Get down, being enemies of one another! On the earth shall be your abode and sustenance for a time.’

# 44

Then Adam received certain words from his Lord, and He turned to him clemently. Indeed He is the All-clement, the All-merciful.

# 45

We said, ‘Get down from it, all together! Yet, should any guidance come to you from Me, those who follow My guidance shall have no fear, nor shall they grieve.

# 46

But those who are faithless and deny Our signs, they shall be the inmates of the Fire and they shall remain in it \[forever\].

# 47

O Children of Israel, remember My blessing which I bestowed upon you, and fulfill My covenant that I may fulfill your covenant, and be in awe of Me \[alone\].

# 48

And believe in that which I have sent down confirming that which is with you, and do not be the first ones to deny it, and do not sell My signs for a paltry gain, and be wary of Me \[alone\].

# 49

Do not mix the truth with falsehood, nor conceal the truth while you know.

# 50

And maintain the prayer, and give the zakat, and bow along with those who bow \[in prayer\].

# 51

Will you bid others to piety and forget yourselves, while you recite the Book? Do you not exercise your reason?

# 52

And take recourse in patience and prayer, and it is indeed hard except for the humble

# 53

—those who are certain that they will encounter their Lord and that they will return to Him.

# 54

O Children of Israel, remember My blessing which I bestowed upon you, and that I gave you an advantage over all the nations.

# 55

Beware of the day when no soul will compensate for another, neither any intercession shall be accepted from it, nor any ransom shall be received from it, nor will they be helped.

# 56

\[Remember\] when We delivered you from Pharaoh’s clan who inflicted a terrible torment on you, and slaughtered your sons and spared your women, and in that there was a great test from your Lord.

# 57

And when We parted the sea with you, and We delivered you and drowned Pharaoh’s clan as you looked on.

# 58

And when We made an appointment with Moses for forty nights, you took up the Calf \[for worship\] in his absence, and you were wrongdoers.

# 59

Then We excused you after that so that you might give thanks.

# 60

And when We gave Moses the Book and the Criterion so that you might be guided.

# 61

And \[recall\] when Moses said to his people, ‘O my people! You have indeed wronged yourselves by taking up the Calf \[for worship\]. Now turn penitently to your Maker, and slay \[the guilty among\] your folks. That will be better for you with your Maker.’ Then He turned to you clemently. Indeed, He is the All-clement, the All-merciful.

# 62

And when you said, ‘O Moses, we will not believe you until we see Allah visibly.’ Thereupon a thunderbolt seized you as you looked on.

# 63

Then We raised you up after your death so that you might give thanks.

# 64

We shaded you with clouds, and sent down to you manna and quails \[saying\]: ‘Eat of the good things We have provided for you.’ And they did not wrong Us, but they used to wrong \[only\] themselves.

# 65

And when We said, ‘Enter this town, and eat thereof freely whencesoever you wish, and enter while prostrating at the gate, and say, ‘‘Relieve \[us of the burden of our sins\],’’ so that We may forgive your iniquities and We will soon enhance the virtuous.’

# 66

But the wrongdoers changed the saying with other than what they were told. So We sent down on those who were wrongdoers a plague from the sky because of the transgressions they used to commit.

# 67

And when Moses prayed for water for his people, We said, ‘Strike the rock with your staff.’ Thereat twelve fountains gushed forth from it; every tribe came to know its drinking-place. ‘Eat and drink of Allah’s provision, and do not act wickedly on the earth, causing corruption.’

# 68

And when you said, ‘O Moses, ‘We will not put up with one kind of food. So invoke your Lord for us, so that He may bring forth for us of that which the earth grows—its greens and cucumbers, its garlic, lentils, and onions.’ He said, ‘Do you seek to replace what is superior with that which is inferior? Go down to any town and you will indeed get what you ask for!’ So they were struck with abasement and poverty, and they earned Allah’s wrath. That, because they would deny the signs of Allah and kill the prophets unjustly. That, because they would disobey and commit transgressions.

# 69

Indeed the faithful, the Jews, the Christians and the Sabaeans—those of them who have faith in Allah and the Last Day and act righteously—they shall have their reward from their Lord, and they will have no fear, nor will they grieve.

# 70

And when We took a pledge from you, and raised the Mount above you, \[declaring\], ‘Hold on with power to what We have given you and remember that which is in it so that you may be Godwary.’

# 71

Again you turned away after that; and were it not for Allah’s grace on you and His mercy, you would have surely been among the losers.

# 72

And certainly you know those of you who violated the Sabbath, whereupon We said to them, ‘Be you spurned apes.’

# 73

So We made it an exemplary punishment for the present and the succeeding \[generations\], and an advice to the Godwary.

# 74

And when Moses said to his people, ‘Allah commands you to slaughter a cow,’ they said, ‘Are you mocking us?’ He said, ‘I seek Allah’s protection lest I should be one of the ignorant!’

# 75

They said, ‘Invoke your Lord for us that He may clarify for us what she may be.’ He said, ‘He says, she is a cow, neither old nor young, of a middle age. Now do what you are commanded.’

# 76

They said, ‘Invoke your Lord for us that He may clarify for us what her colour may be.’ He said, ‘He says, she is a cow that is yellow, of a bright hue, pleasing to the onlookers.’

# 77

They said, ‘Invoke your Lord for us that He may clarify for us what she may be. Indeed all cows are much alike to us, and if Allah wishes we will surely be guided.’

# 78

He said, ‘He says, She is a cow not broken to till the earth or water the tillage, sound and without blemish.’ They said, ‘Now have you come up with the truth!’ And they slaughtered it, though they were about not to do it.

# 79

And when you killed a soul, and accused one another about it—and Allah was to expose what you were concealing—

# 80

We said, ‘Strike him with a piece of it:’ thus does Allah revive the dead, and He shows you His signs so that you may exercise your reason.

# 81

Then your hearts hardened after that; so they are like stones, or even harder. For there are some stones from which streams gush forth, and there are some of them that split, and water issues from them, and there are some that fall for the fear of Allah. And Allah is not oblivious of what you do.

# 82

Are you then eager that they should believe you, though a part of them would hear the word of Allah and then they would distort it after they had understood it, and they knew \[what they were doing\]?

# 83

When they meet the faithful, they say, ‘We believe,’ and when they are alone with one another, they say, ‘Do you recount to them what Allah has revealed to you, so that they may argue with you therewith before your Lord? Do you not exercise your reason?’

# 84

Do they not know that Allah knows whatever they hide and whatever they disclose?

# 85

And among them are the illiterate who know nothing of the Book except hearsay, and they only make conjectures.

# 86

So woe to them who write the Book with their hands and then say, ‘This is from Allah,’ that they may sell it for a paltry gain. So woe to them for what their hands have written, and woe to them for what they earn!

# 87

And they say, ‘The Fire shall not touch us except for a number of days.’ Say, ‘Have you taken a promise from Allah? If so, Allah will never break His promise. Do you ascribe to Allah what you do not know?’

# 88

Certainly whoever commits misdeeds and is besieged by his iniquity—such shall be the inmates of the Fire, and they will remain in it \[forever\].

# 89

And those who have faith and do righteous deeds—they shall be the inhabitants of paradise; they will remain in it \[forever\].

# 90

When We took a pledge from the Children of Israel, \[saying\]: ‘Worship no one but Allah, do good to your parents, relatives, orphans, and the needy, speak kindly to people, maintain the prayer, and give the zakat,’ you turned away, except a few of you, and you were disregardful.

# 91

And when We took a pledge from you, \[saying\]: ‘You shall not shed your \[own people’s\] blood, and you shall not expel your folks from your homes,’ you pledged, and you testify \[to this pledge of your ancestors\].

# 92

Then there you were, killing your folks and expelling a part of your folks from their homes, backing one another against them in sin and aggression! And if they came to you as captives, you would ransom them, though their expulsion itself was forbidden you. What! Do you believe in part of the Book and deny another part? So what is the requital of those of you who do that except disgrace in the life of this world? And on the Day of Resurrection, they shall be consigned to the severest punishment. And Allah is not oblivious of what you do.

# 93

They are the ones who bought the life of this world for the Hereafter; so their punishment shall not be lightened, nor will they be helped.

# 94

Certainly, We gave Moses the Book and followed him with the apostles, and We gave Jesus, the son of Mary, manifest proofs and confirmed him with the Holy Spirit. Is it not that whenever an apostle brought you that which was not to your liking, you would act arrogantly; so you would impugn a group \[of them\], and slay a\[nother\] group?

# 95

And they say, ‘Our hearts are uncircumcised.’ Rather, Allah has cursed them for their unfaith, so few of them have faith.

# 96

And when there came to them a Book from Allah, confirming that which is with them—and earlier they would pray for victory over the pagans—so when there came to them what they recognized, they denied it. So may the curse of Allah be on the faithless!

# 97

Evil is that for which they have sold their souls, by defying what Allah has sent down, out of envy that Allah should bestow His grace on any of His servants that He wishes. Thus, they earned wrath upon wrath, and there is a humiliating punishment for the faithless.

# 98

And when they are told, ‘Believe in what Allah has sent down,’ they say, ‘We believe in what was sent down to us,’ and they disbelieve what is besides it, though it is the truth confirming what is with them. Say, ‘Then why would you kill the prophets of Allah formerly, should you be faithful?’

# 99

Certainly Moses brought you manifest proofs, but then you took up the Calf in his absence and you were wrongdoers.

# 100

And when We took covenant with you and raised the Mount above you, \[declaring\], ‘Hold on with power to what We have given you, and do listen!’ They said, ‘We hear, and disobey,’ and their hearts had been imbued with \[the love of\] the Calf, due to their unfaith. Say, ‘Evil is that to which your faith prompts you, should you be faithful!’

# 101

Say, ‘If the abode of the Hereafter were exclusively for you with Allah, and not for other people, then long for death, should you be truthful.’

# 102

But they will not long for it ever because of what their hands have sent ahead, and Allah knows best the wrongdoers.

# 103

Surely, you will find them the greediest for life, of all people even the idolaters. Each of them is eager to live a thousand years, though it would not deliver him from the punishment, were he to live \[that long\]. And Allah watches what they do.

# 104

Say, ‘Whoever is an enemy of Gabriel \[should know that\] it is he who has brought it down on your heart with the will of Allah, confirming what has been \[revealed\] before it and as a guidance and good news for the faithful.’

# 105

\[Say,\] ‘Whoever is an enemy of Allah, His angels and His apostles and Gabriel and Michael, \[let him know that\] Allah is the enemy of the faithless.’

# 106

We have certainly sent down manifest signs to you, and no one denies them except transgressors.

# 107

Is it not that whenever they made a covenant, a part of them would cast it away? Rather, the majority of them do not have faith.

# 108

And when there came to them an apostle from Allah, confirming that which is with them, a part of those who were given the Book cast the Book of Allah behind their back, as if they did not know \[that it is Allah’s Book\].

# 109

And they followed what the devils pursued during Solomon’s reign —and Solomon was not faithless but it was the devils who were faithless—teaching the people magic and what was sent down to the two angels at Babylon, Harut and Marut, who would not teach anyone without telling \[him\], ‘We are only a test, so do not be faithless.’ But they would learn from those two that with which they would cause a split between man and his wife—though they could not harm anyone with it except with Allah’s leave. They would learn that which would harm them and bring them no benefit; though they certainly knew that anyone who buys it has no share in the Hereafter. Surely, evil is that for which they sold their souls, had they known!

# 110

Had they been faithful and Godwary, the reward from Allah would have been better, had they known!

# 111

O you who have faith! Do not say Ra‘ina, but say Unzurna, and listen! And there is a painful punishment for the faithless.

# 112

Neither the faithless from among the People of the Book nor the idolaters like that any good be showered on you from your Lord; but Allah singles out for His mercy whomever He wishes, and Allah is dispenser of a mighty grace.

# 113

For any verse that We abrogate or cause to be forgotten, We bring another which is better than it, or similar to it. Do you not know that Allah has power over all things?

# 114

Do you not know that to Allah belongs the kingdom of the heavens and the earth? And besides Allah, you do not have any guardian or helper.

# 115

Would you question your Apostle as Moses was questioned formerly? Whoever changes faith for unfaith certainly strays from the right way.

# 116

Many of the People of the Book are eager to turn you into unbelievers after your faith, out of their inner envy, \[and\] after the truth had become manifest to them. Yet excuse \[them\] and forbear until Allah issues His edict. Indeed Allah has power over all things.

# 117

And maintain the prayer and give the zakat. Any good that you send ahead for your own souls, you shall find it with Allah. Indeed Allah watches what you do.

# 118

And they say, ‘No one will enter paradise except one who is a Jew or Christian.’ Those are their \[false\] hopes! Say, ‘Produce your evidence, should you be truthful.’

# 119

Certainly, whoever submits his will to Allah and is virtuous, he shall have his reward from his Lord, and they will have no fear, nor shall they grieve.

# 120

The Jews say, ‘The Christians stand on nothing,’ and the Christians say, ‘The Jews stand on nothing,’ though they follow the \[same\] Book. So said those who had no knowledge, \[words\] similar to what they say. Allah will judge between them on the Day of Resurrection concerning that about which they used to differ.

# 121

Who is a greater wrongdoer than those who deny access to the mosques of Allah lest His Name be celebrated therein, and try to ruin them? Such ones may not enter them, except in fear. There is disgrace for them in this world and a great punishment in the Hereafter.

# 122

To Allah belong the east and the west: so whichever way you turn, there is the face of Allah! Allah is indeed all-bounteous, all-knowing.

# 123

And they say, ‘Allah has taken a son.’ Immaculate is He! Rather, to Him belongs whatever there is in the heavens and the earth. All are obedient to Him,

# 124

the Originator of the heavens and the earth. When He decides on a matter, He just says to it, ‘Be!’ and it is.

# 125

Those who have no knowledge say, ‘Why does not Allah speak to us, or come to us a sign?’ So said those who were before them, \[words\] similar to what they say. Alike are their hearts. We have certainly made the signs clear for a people who have certainty.

# 126

Indeed We have sent you with the truth, as a bearer of good news and as a warner, and you will not be questioned concerning the inmates of hell.

# 127

Never will the Jews be pleased with you, nor the Christians, unless you followed their creed. Say, ‘Indeed it is the guidance of Allah which is \[true\] guidance.’ And should you follow their desires after the knowledge that has come to you, you will not have against Allah any guardian or helper.

# 128

Those to whom We have given the Book follow it as it ought to be followed: they have faith in it. As for those who deny it—it is they who are the losers.

# 129

O Children of Israel, remember My blessing which I bestowed upon you, and that I gave you an advantage over all the nations.

# 130

Beware of the Day when no soul will compensate for another, neither will any ransom be accepted from it, nor will any intercession benefit it, nor will they be helped.

# 131

When his Lord tested Abraham with certain words and he fulfilled them, He said, ‘I am making you the Imam of mankind.’ Said he, ‘And from among my descendants?’ He said, ‘My pledge does not extend to the unjust.’

# 132

And \[remember\] when We made the House a place of reward for mankind and a sanctuary, \[declaring\], ‘Take the venue of prayer from Abraham’s Station.’ We charged Abraham and Ishmael \[with its upkeep, saying\], ‘Purify My House for those who go around it, \[for\] those who make it a retreat and \[for\] those who bow and prostrate.’

# 133

And when Abraham said, ‘My Lord, make this a secure town, and provide its people with fruits—such of them as have faith in Allah and the Last Day,’ He said, ‘As for him who is faithless, I will provide for him \[too\] for a short time, then I will shove him toward the punishment of the Fire and it is an evil destination.’

# 134

As Abraham raised the foundations of the House with Ishmael, \[they prayed\]: ‘Our Lord, accept it from us! Indeed You are the All-hearing, the All-knowing.

# 135

‘Our Lord, make us submissive to You, and \[raise\] from our progeny a nation submissive to You, and show us our rites \[of worship\], and turn to us clemently. Indeed You are the All-clement, the All-merciful.’

# 136

‘Our Lord, raise amongst them an apostle from among them, who will recite to them Your signs and teach them the Book and wisdom and purify them. Indeed You are the All-mighty, the All-wise.’

# 137

And who will \[ever\] forsake Abraham’s creed except one who debases himself? We certainly chose him in the \[present\] world, and in the Hereafter he will indeed be among the Righteous.

# 138

When his Lord said to him, ‘Submit,’ he said, ‘I submit to the Lord of all the worlds.’

# 139

Abraham enjoined this \[creed\] upon his children, and \[so did\] Jacob, \[saying\], ‘My children! Allah has indeed chosen this religion for you; so do not die except as those who have surrendered themselves \[to Allah\].

# 140

Were you witnesses when death approached Jacob, when he said to his children, ‘What will you worship after me?’ They said, ‘We will worship your God and the God of your fathers, Abraham, Ishmael, and Isaac, the One God, and to Him do we submit.’

# 141

That was a nation that has passed: for it there will be what it has earned, and for you there will be what you have earned, and you will not be questioned about what they used to do.

# 142

They say, ‘Be either Jews or Christians, that you may be \[rightly\] guided.’ Say, ‘No, rather, \[we will follow\] the creed of Abraham, a Hanif, and he was not one of the polytheists.’

# 143

Say, ‘We have faith in Allah and what has been sent down to us, and what was sent down to Abraham, Ishmael, Isaac, Jacob and the Tribes, and that which Moses and Jesus were given, and that which the prophets were given from their Lord; we make no distinction between any of them and to Him do we submit.’

# 144

So if they believe in the like of what you believe in, then they are surely guided; but if they turn away, then \[know that\] they are only \[steeped\] in defiance. Allah will suffice you against them, and He is the All-hearing, the All-knowing.

# 145

‘The baptism of Allah, and who baptizes better than Allah? And Him do we worship.’

# 146

Say, ‘Will you argue with us concerning Allah, while He is our Lord and your Lord, and to us belong our deeds, and to you belong your deeds, and we worship Him dedicatedly?’

# 147

\[Ask them,\] ‘Do you say that Abraham, Ishmael, Isaac, Jacob, and the Tribes were Jews or Christians?’ Say, ‘Is it you who know better, or Allah?’ And who is a greater wrongdoer than someone who conceals a testimony that is with him from Allah? And Allah is not oblivious of what you do.

# 148

That was a nation that has passed: for it there will be what it has earned, and for you there will be what you have earned, and you will not be questioned about what they used to do.

# 149

The foolish among the people will say, ‘What has turned them away from the qiblah they were following?’ Say, ‘To Allah belong the east and the west. He guides whomever He wishes to a straight path.’

# 150

Thus We have made you a middle nation that you may be witnesses to the people, and that the Apostle may be a witness to you. We did not appoint the qiblah you were following, but that We may ascertain those who follow the Apostle from those who turn back on their heels. It was indeed a hard thing except for those whom Allah has guided. And Allah would not let your prayers go to waste. Indeed Allah is most kind and merciful to mankind.

# 151

We certainly see you turning your face about in the sky. We will surely turn you to a qiblah of your liking: so turn your face towards the Holy Mosque, and wherever you may be, turn your faces towards it! Indeed those who were given the Book surely know that it is the truth from their Lord. And Allah is not oblivious of what they do.

# 152

Even if you bring those who were given the Book every \[kind of\] sign, they will not follow your qiblah. Nor shall you follow their qiblah, nor will any of them follow the qiblah of the other. And if you follow their desires, after the knowledge that has come to you, you will be one of the wrongdoers.

# 153

Those whom We have given the Book recognize him just as they recognize their sons, but a part of them indeed conceal the truth while they know.

# 154

This is the truth from your Lord; so do not be among the skeptics.

# 155

Everyone has a cynosure to which he turns; so take the lead in all good works. Wherever you may be, Allah will bring you all together. Indeed Allah has power over all things.

# 156

Whencesoever you may go out, turn your face towards the Holy Mosque. Indeed it is the truth from your Lord, and Allah is not oblivious of what you do.

# 157

And whencesoever you may go out, turn your face towards the Holy Mosque, and wherever you may be, turn your faces towards it, so that the people may have no allegation against you, neither those of them who are wrongdoers. So do not fear them, but fear Me, that I may complete My blessing on you and so that you may be guided.

# 158

Even as We sent to you an apostle from among yourselves, who recites to you Our signs and purifies you, and teaches you the Book and wisdom, and teaches you what you did not know.

# 159

Remember Me and I will remember you, and thank Me, and do not be ungrateful to Me.

# 160

O you who have faith! Take recourse in patience and prayer; indeed Allah is with the patient.

# 161

Do not call those who were slain in Allah’s way ‘dead.’ No, they are living, but you are not aware.

# 162

We will surely test you with a measure of fear and hunger and a loss of wealth, lives, and fruits; and give good news to the patient

# 163

—those who, when an affliction visits them, say, ‘Indeed we belong to Allah and to Him do we indeed return.’

# 164

It is they who receive the blessings of their Lord and \[His\] mercy, and it is they who are the \[rightly\] guided.

# 165

Indeed Safa and Marwah are among Allah’s sacraments. So whoever makes hajj to the House, or performs the ‘umrah, there is no sin upon him to circuit between them. Should anyone do good of his own accord, then Allah is indeed appreciative, all-knowing.

# 166

Indeed those who conceal what We have sent down of manifest proofs and guidance, after We have clarified it in the Book for mankind—they shall be cursed by Allah and cursed by the cursers,

# 167

except such as repent, make amends, and clarify—those I shall pardon, and I am the All-clement, the All-merciful.

# 168

Indeed those who turn faithless and die while they are faithless—it is they on whom shall be the curse of Allah, the angels and all mankind.

# 169

They will remain in it \[forever\] and their punishment shall not be lightened, nor will they be granted any respite.

# 170

Your god is the One God; there is no god except Him, the All-beneficent, the All-merciful.

# 171

Indeed in the creation of the heavens and the earth, and the alternation of night and day, and the ships that sail at sea with profit to men, and the water that Allah sends down from the sky—with which He revives the earth after its death, and scatters therein every kind of animal—and the changing of the winds, and the clouds disposed between the sky and the earth, there are surely signs for a people who exercise their reason.

# 172

Among the people are those who set up compeers besides Allah, loving them as if loving Allah—but the faithful have a more ardent love for Allah—though the wrongdoers will see, when they sight the punishment, that power, altogether, belongs to Allah, and that Allah is severe in punishment.

# 173

When those who were followed will disown the followers, and they will sight the punishment while all their means of recourse will be cut off,

# 174

and when the followers will say, ‘Had there been another turn for us, we would disown them as they disown us \[now\]!’ Thus shall Allah show them their deeds as regrets for themselves, and they shall not leave the Fire.

# 175

O mankind! Eat of what is lawful and pure in the earth, and do not follow in Satan’s steps. Indeed, he is your manifest enemy.

# 176

He only prompts you to \[commit\] evil and indecent acts, and that you attribute to Allah what you do not know.

# 177

When they are told, ‘Follow what Allah has sent down,’ they say, ‘No, We will follow what we have found our fathers following.’ What, even if their fathers neither exercised their reason nor were guided?!

# 178

The parable of the faithless is that of someone who shouts after that which does not hear \[anything\] except a call and cry: deaf, dumb, and blind, they do not exercise their reason.

# 179

O you who have faith! Eat of the good things We have provided you, and thank Allah, if it is Him that you worship.

# 180

He has forbidden you only carrion, blood, the flesh of the swine, and that which has been offered to other than Allah. But should someone be compelled, without being rebellious or transgressive, there shall be no sin upon him. Indeed Allah is all-forgiving, all-merciful.

# 181

Indeed those who conceal what Allah has sent down of the Book and sell it for a paltry gain—they do not take in, into their bellies, \[anything\] except fire, and Allah shall not speak to them on the Day of Resurrection, nor shall He purify them, and there is a painful punishment for them.

# 182

They are the ones who bought error for guidance, and punishment for pardon: how patient of them to face the Fire!

# 183

That is so because Allah has sent down the Book with the truth, and those who differ about the Book are surely in extreme defiance.

# 184

Piety is not to turn your faces to the east or the west; rather, piety is \[personified by\] those who have faith in Allah and the Last Day, the angels, the Book, and the prophets, and who give their wealth, for the love of Him, to relatives, orphans, the needy, the traveller and the beggar, and for \[the freeing of\] the slaves, and maintain the prayer and give the zakat, and those who fulfill their covenants, when they pledge themselves, and those who are patient in stress and distress, and in the heat of battle. They are the ones who are true \[to their covenant\], and it is they who are the Godwary.

# 185

O you who have faith! Retribution is prescribed for you regarding the slain: freeman for freeman, slave for slave, and female for female. But if one is granted any extenuation by his brother, let the follow up \[for the blood-money\] be honourable, and let the payment to him be with kindness. That is a remission from your Lord and a mercy; and should anyone transgress after that, there shall be a painful punishment for him.

# 186

There is life for you in retribution, O you who possess intellects! Maybe you will be Godwary!

# 187

Prescribed for you, when death approaches any of you and he leaves behind any property, is that he make a bequest for his parents and relatives, in an honourable manner—an obligation on the Godwary.

# 188

And should anyone alter it after hearing it, its sin shall indeed lie on those who alter it. Indeed Allah is all-hearing, all-knowing.

# 189

But should someone, fearing deviance or sin on the testator’s behalf, set things right between them, there is no sin upon him. Indeed Allah is all-forgiving, all-merciful.

# 190

O you who have faith! Prescribed for you is fasting as it was prescribed for those who were before you, so that you may be Godwary.

# 191

That for known days. But should any of you be sick or on a journey, let it be a \[similar\] number of other days. Those who find it straining shall be liable to atonement by feeding a needy person. Should anyone do good of his own accord, that is better for him, and to fast is better for you, should you know.

# 192

The month of Ramadan is one in which the Quran was sent down as guidance to mankind, with manifest proofs of guidance and the Criterion. So let those of you who witness it fast \[in\] it, and as for someone who is sick or on a journey, let it be a \[similar\] number of other days. Allah desires ease for you, and He does not desire hardship for you, and so that you may complete the number and magnify Allah for guiding you, and that you may give thanks.

# 193

When My servants ask you about Me, \[tell them that\] I am indeed nearmost. I answer the supplicant’s call when he calls Me. So let them respond to Me, and let them have faith in Me, so that they may fare rightly.

# 194

You are permitted on the night of the fast to go into your wives: they are a garment for you, and you are a garment for them. Allah knew that you would betray yourselves, so He pardoned you and excused you. So now consort with them and seek what Allah has ordained for you, and eat and drink until the white streak becomes manifest to you from the dark streak at the crack of dawn. Then complete the fast until nightfall, and do not consort with them while you dwell in confinement in the mosques. These are Allah’s bounds, so do not approach them. Thus does Allah clarify His signs for mankind so that they may be Godwary.

# 195

Do not eat up your wealth among yourselves wrongfully, nor proffer it to the judges in order to eat up a part of the people’s wealth sinfully, while you know \[that it is immoral to do so\].

# 196

They question you concerning the new moons. Say, ‘They are timekeeping signs for the people and \[for the sake of\] hajj.’ It is not piety that you enter houses from their rear; rather, piety is \[personified by\] one who is Godwary, and enter houses from their doors and be wary of Allah, so that you may be felicitous.

# 197

Fight in the way of Allah those who fight you, but do not transgress. Indeed Allah does not like transgressors.

# 198

And kill them wherever you confront them, and expel them from where they expelled you, for persecution is graver than killing. But do not fight them near the Holy Mosque unless they fight you therein; but if they fight you, kill them; such is the requital of the faithless.

# 199

But if they desist, then Allah is indeed all-forgiving, all-merciful.

# 200

Fight them until persecution is no more, and religion becomes \[exclusively\] for Allah. Then if they desist, there shall be no reprisal except against the wrongdoers.

# 201

A sacred month for a sacred month, and all sanctities require retribution. So should anyone aggress against you, assail him in the manner he assailed you, and be wary of Allah, and know that Allah is with the Godwary.

# 202

Spend in the way of Allah, and do not cast yourselves with your own hands into destruction; and be virtuous. Indeed Allah loves the virtuous.

# 203

Complete the hajj and the ‘umrah for Allah’s sake, and if you are prevented, then \[make\] such \[sacrificial\] offering as is feasible. And do not shave your heads until the offering reaches its \[assigned\] place. But should any of you be sick, or have a hurt in his head, let the atonement be by fasting, or charity, or sacrifice. And when you have security—for those who enjoy \[release from the restrictions\] by virtue of their ‘umrah until the hajj—let the offering be such as is feasible. As for someone who cannot afford \[the offering\], let him fast three days during the hajj and seven when you return; that is \[a period of\] ten complete \[days\]. That is for someone whose family does not dwell by the Holy Mosque. And be wary of Allah, and know that Allah is severe in retribution.

# 204

The hajj \[season\] is in months well-known; so whoever decides on hajj \[pilgrimage\] therein, \[should know that\] there is to be no sexual contact, vicious talk, or disputing during the hajj. And whatever good you do, Allah knows it. And take provision, for indeed the best provision is Godwariness. So be wary of Me, O you who possess intellects!

# 205

There is no sin upon you in seeking your Lord’s bounty \[during the hajj season\]. Then when you stream out of ‘Arafat remember Allah at the Holy Mash‘ar, and remember Him as He has guided you, and earlier you were indeed among the astray.

# 206

Then stream out from where the people stream out, and plead to Allah for forgiveness; indeed Allah is all-forgiving, all-merciful.

# 207

And when you finish your rites, then remember Allah as you would remember your fathers, or with a more ardent remembrance. Among the people there are those who say, ‘Our Lord, give us in this world,’ but for such there is no share in the Hereafter.

# 208

And among them there are those who say, ‘Our Lord, give us good in this world and good in the Hereafter, and save us from the punishment of the Fire.’

# 209

Such shall partake of what they have earned, and Allah is swift at reckoning.

# 210

Remember Allah in the appointed days. Then whoever hastens off in a couple of days, there is no sin upon him, and whoever delays, there is no sin upon him—that for one who has been Godwary—and be wary of Allah and know that toward Him you will be mustered.

# 211

Among the people is he whose talk about worldly life impresses you, and he holds Allah witness to what is in his heart, though he is the staunchest of enemies.

# 212

If he were to wield authority, he would try to cause corruption in the land and to ruin the crop and the stock, and Allah does not like corruption.

# 213

And when he is told, ‘Be wary of Allah,’ conceit seizes him sinfully; so let hell suffice him, and it is surely an evil resting place!

# 214

And among the people is he who sells his soul seeking the pleasure of Allah, and Allah is most kind to \[His\] servants.

# 215

O you who have faith! Enter into submission, all together, and do not follow in Satan’s steps; he is indeed your manifest enemy.

# 216

And should you stumble after the manifest proofs that have come to you, know that Allah is all-mighty, all-wise.

# 217

Do they await anything but that Allah \[’s command\] should come to them in the shades of the clouds, with the angels, and the matter be decided \[once for all\]? To Allah all matters are returned.

# 218

Ask the Children of Israel how many a manifest sign We had given them. Whoever changes Allah’s blessing after it has come to him, indeed Allah is severe in retribution.

# 219

Worldly life has been glamorized for the faithless, and they ridicule the faithful. But those who are Godwary shall be above them on the Day of Resurrection, and Allah provides for whomever He wishes without any reckoning.

# 220

Mankind were a single community; then Allah sent the prophets as bearers of good news and warners, and He sent down with them the Book with the truth, that it may judge between the people concerning that about which they differed, and none differed in it except those who had been given it, after the manifest proofs had come to them, out of envy among themselves. Then Allah guided those who had faith to the truth of what they differed in, by His will, and Allah guides whomever He wishes to a straight path.

# 221

Do you suppose that you will enter paradise though there has not yet come to you the like of \[what befell\] those who went before you? Stress and distress befell them and they were convulsed until the apostle and the faithful who were with him said, ‘When will Allah’s help \[come\]?’ Behold! Allah’s help is indeed near!

# 222

They ask you as to what they should spend. Say, ‘Let whatever wealth you spend be for the parents, relatives, orphans, the needy, and the traveller.’ Allah indeed knows whatever good you do.

# 223

Warfare has been prescribed for you, though it is repulsive to you. Yet it may be that you dislike something, which is good for you, and it may be that you love something, which is bad for you, and Allah knows and you do not know.

# 224

They ask you concerning warfare in the holy month. Say, ‘It is an outrageous thing to fight in it, but to keep \[people\] from Allah’s way, and to be unfaithful to Him, and \[to keep people from\] the Holy Mosque, and to expel its people from it are more outrageous with Allah. And persecution is graver than killing. They will not cease fighting you until they turn you away from your religion, if they can. And whoever of you turns away from his religion and dies faithless—they are the ones whose works have failed in this world and the Hereafter. They shall be the inmates of the Fire, and they shall remain in it \[forever\].

# 225

Indeed those who are faithful and those who have migrated and waged jihad in the way of Allah—it is they who expect Allah’s mercy, and Allah is all-forgiving, all-merciful.

# 226

They ask you concerning wine and gambling. Say, ‘There is a great sin in both of them, and some profits for the people, but their sinfulness outweighs their profit.’ And they ask you as to what they should spend. Say, ‘All that is surplus.’ Thus does Allah clarify His signs for you so that you may reflect

# 227

about the world and the Hereafter. And they ask you concerning the orphans. Say, ‘It is better to set right their affairs, and if you intermingle with them, they are of course your brothers: Allah knows those who cause corruption from those who set things right, and had Allah wished He would have put you to hardship.’ Indeed Allah is all-mighty, all-wise.

# 228

Do not marry idolatresses until they embrace faith. A faithful slave girl is better than an idolatress, though she should impress you. And do not marry \[your daughters\] to idolaters until they embrace faith. A faithful slave is better than an idolater, though he should impress you. Those invite \[others\] to the Fire, but Allah invites to paradise and pardon, by His will, and He clarifies His signs for the people so that they may take admonition.

# 229

They ask you concerning \[intercourse during\] menses. Say, ‘It is hurtful.’ So keep away from wives during the menses, and do not approach them till they are clean. And when they become clean, go into them as Allah has commanded you. Indeed Allah loves the penitent and He loves those who keep clean.

# 230

Your women are a tillage for you, so come to your tillage whenever you like, and send ahead for your souls, and be Godwary, and know that you will encounter Him; and give good news to the faithful.

# 231

Do not make Allah an obstacle, through your oaths, to being pious and Godwary, and to bringing about concord between people. And Allah is all-hearing, all-knowing.

# 232

Allah will not take you to task for what is unconsidered in your oaths, but He will take you to task for what your hearts have incurred, and Allah is all-forgiving, all-forbearing.

# 233

For those who forswear their wives shall be a waiting \[period\]of four months. And if they recant, Allah is indeed all-forgiving, all-merciful.

# 234

But if they resolve on divorce, Allah is indeed all-hearing, all-knowing.

# 235

Divorced women shall wait by themselves for three periods of purity \[after menses\], and it is not lawful for them to conceal what Allah has created in their wombs if they believe in Allah and the Last Day; and their husbands have a greater right to restore them during this \[duration\], if they desire reconcilement. The wives have rights similar to the obligations upon them, in accordance with honourable norms; and men have a degree above them, and Allah is all-mighty and all-wise.

# 236

\[Revocable\] divorce may be only twice; then \[let there be\] either an honourable retention, or a kindly release. It is not lawful for you to take back anything from what you have given them, unless the couple fear that they may not maintain Allah’s bounds; so if you fear they would not maintain Allah’s bounds, there is no sin upon them in what she may give to secure her own release. These are Allah’s bounds, so do not transgress them, and whoever transgresses the bounds of Allah—it is they who are the wrongdoers.

# 237

And if he divorces her, she will not be lawful for him thereafter until she marries a husband other than him, and if he divorces her, there is no sin upon them to remarry if they think that they can maintain Allah’s bounds. These are Allah’s bounds, which He clarifies for a people who have knowledge.

# 238

When you divorce women and they complete their term \[of waiting\], then either retain them honourably or release them honourably, and do not retain them maliciously in order that you may transgress; and whoever does that certainly wrongs himself. Do not take the signs of Allah in derision, and remember Allah’s blessing upon you, and what He has sent down to you of the Book and wisdom, to advise you therewith. Be wary of Allah and know that Allah has knowledge of all things.

# 239

When you divorce women and they complete their term, do not hinder them from \[re\]marrying their husbands, when they honourably reach mutual consent. Herewith are advised those of you who believe in Allah and the Last Day. That will be more decent and purer for you, and Allah knows and you do not know.

# 240

Mothers shall suckle their children for two full years—that for such as desire to complete the suckling—and on the father shall be their maintenance and clothing, in accordance with honourable norms. No soul is to be tasked except according to its capacity: neither the mother shall be made to suffer harm on her child’s account, nor the father on account of his child, and on the \[father’s\] heir devolve \[duties and rights\] similar to that. And if the couple desire to wean with mutual consent and consultation, there will be no sin upon them. And if you want to have your children wet-nursed, there will be no sin upon you so long as you pay what you give in accordance with honourable norms, and be wary of Allah and know that Allah watches what you do.

# 241

As for those of you who die leaving wives, they shall wait by themselves four months and ten days, and when they complete their term, there will be no sin upon you in respect of what they may do with themselves in accordance with honourable norms. And Allah is well aware of what you do.

# 242

There is no sin upon you in what you may hint in proposing to \[recently widowed\] women, or what you may secretly cherish within your hearts. Allah knows that you will be thinking of them, but do not make troth with them secretly, unless you say honourable words, and do not resolve on a marriage tie until the prescribed term is complete. Know that Allah knows what is in your hearts, so beware of Him; and know that Allah is all-forgiving, all-forbearing.

# 243

There is no sin upon you if you divorce women while you have not yet touched them or settled a dowry for them. Yet provide for them—the well-off according to his capacity, and the poorly-off according to his capacity—with a sustenance that is honourable, an obligation on the virtuous.

# 244

And if you divorce them before you touch them, and you have already settled a dowry for them, then \[pay them\] half of what you have settled, unless they forgo it, or someone in whose hand is the marriage tie forgoes it. And to forgo is nearer to Godwariness; so do not forget graciousness among yourselves. Indeed Allah watches what you do.

# 245

Be watchful of your prayers, and \[especially\] the middle prayer, and stand in obedience to Allah;

# 246

and should you fear \[a danger\], then \[pray\] on foot or mounted, and when you are safe remember Allah, as He taught you what you did not know.

# 247

Those of you who die leaving wives shall bequeath for their wives providing for a year, without turning them out; but if they leave, there is no sin upon you in respect of what they may do with themselves in accordance with honourable norms. And Allah is all-mighty, all-wise.

# 248

For the divorced women there shall be a provision, in accordance with honourable norms—an obligation on the Godwary.

# 249

Thus does Allah clarify His signs to you so that you may exercise your reason.

# 250

Have you not regarded those who left their homes in thousands, apprehensive of death, whereupon Allah said to them, ‘Die,’ then He revived them? Indeed Allah is gracious to mankind, but most people do not give thanks.

# 251

Fight in the way of Allah, and know that Allah is all-hearing, all-knowing.

# 252

Who is it that will lend Allah a good loan that He may multiply it for him severalfold? Allah tightens and expands \[the means of life\], and to Him you shall be brought back.

# 253

Have you not regarded the elite of the Israelites after Moses, when they said to their prophet, ‘Appoint for us a king that we may fight in the way of Allah.’ He said, ‘May it not be that you will not fight if fighting were prescribed for you?’ They said, ‘Why should we not fight in the way of Allah, when we have been expelled from our homes and \[separated from\] our children?’ So when fighting was prescribed for them, they turned back except a few of them, and Allah knows well the wrongdoers.

# 254

Their prophet said to them, ‘Allah has appointed Saul as king for you.’ They said, ‘How can he have kingship over us, when we have a greater right to kingship than him, as he has not been given ample wealth?’ He said, ‘Indeed Allah has chosen him over you, and enhanced him vastly in knowledge and physique, and Allah gives His kingdom to whomever He wishes, and Allah is all-bounteous, all-knowing.’

# 255

Their prophet said to them, ‘Indeed the sign of his kingship shall be that the Ark will come to you, bearing tranquillity from your Lord and the relics left behind by the House of Moses and the House of Aaron, borne by the angels. There is indeed a sign in that for you, should you be faithful.’

# 256

As Saul set out with the troops, he said, ‘Allah will test you with a stream: anyone who drinks from it will not belong to me, but those who do not drink from it will belong to me, barring someone who draws a scoop with his hand.’ But they drank from it, \[all\] except a few of them. So when he crossed it along with the faithful who were with him, they said, ‘We have no strength today against Goliath and his troops.’ Those who were certain that they would encounter Allah said, ‘How many a small party has overcome a larger party by Allah’s will! And Allah is with the patient.’

# 257

So when they marched out for \[encounter with\] Goliath and his troops, they said, ‘Our Lord, pour patience upon us, make our feet steady, and assist us against the faithless lot.’

# 258

Thus they routed them with Allah’s will, and David killed Goliath, and Allah gave him kingdom and wisdom and taught him whatever He liked. Were it not for Allah’s repelling the people by means of one another, the earth would surely have been corrupted; but Allah is gracious to the world’s people.

# 259

These are the signs of Allah, which We recite for you in truth, and you are indeed one of the apostles.

# 260

These are the apostles, some of whom We gave an advantage over others: of them are those to whom Allah spoke and some of them He raised in rank, and We gave Jesus, son of Mary, manifest proofs and strengthened him with the Holy Spirit. Had Allah wished, those who succeeded them would not have fought one another after the manifest proofs had come to them. But they differed. So there were among them those who had faith and there were among them those who were faithless, and had Allah wished, they would not have fought one another; but Allah does whatever He desires.

# 261

O you who have faith! Spend out of what We have provided you before there comes a day on which there will be no bargaining, neither friendship, nor intercession. And the faithless—they are the wrongdoers.

# 262

Allah—there is no god except Him—is the Living One, the All-sustainer. Neither drowsiness befalls Him nor sleep. To Him belongs whatever is in the heavens and whatever is on the earth. Who is it that may intercede with Him except with His permission? He knows what is before them and what is behind them, and they do not comprehend anything of His knowledge except what He wishes. His seat embraces the heavens and the earth and He is not wearied by their preservation, and He is the All-exalted, the All-supreme.

# 263

There is no compulsion in religion: rectitude has become distinct from error. So one who disavows fake deities and has faith in Allah has held fast to the firmest handle for which there is no breaking; and Allah is all-hearing, all-knowing.

# 264

Allah is the wali of the faithful: He brings them out of darkness into light. As for the faithless, their awliya are the fake deities, who drive them out of light into darkness. They shall be the inmates of the Fire, and they will remain in it \[forever\].

# 265

Have you not regarded him who argued with Abraham about his Lord, \[only\] because Allah had given him kingdom? When Abraham said, ‘My Lord is He who gives life and brings death,’ he replied, ‘I \[too\] give life and bring death.’ Abraham said, ‘Indeed Allah brings the sun from the east; now you bring it from the west.’ Thereat the faithless one was dumbfounded. And Allah does not guide the wrongdoing lot.

# 266

Or him who came upon a township as it lay fallen on its trellises. He said, ‘How will Allah revive this after its death?!’ So Allah made him die for a hundred years, then He resurrected him. He said, ‘How long did you remain?’ Said he, ‘I have remained a day or part of a day.’ He said, ‘No, you have remained a hundred years. Now look at your food and drink which have not rotted! Then look at your ass! \[This was done\] that We may make you a sign for mankind. And now look at its bones, how We raise them up and clothe them with flesh!’ When it became evident to him, he said, ‘I know that Allah has power over all things.’

# 267

And when Abraham said, ‘My Lord! Show me how You revive the dead,’ He said, ‘Do you not believe?’ He said, ‘Yes indeed, but in order that my heart may be at rest.’ He said, ‘Catch four of the birds. Then cut them into pieces, and place a part of them on every mountain, then call them; they will come to you hastening. And know that Allah is all-mighty and all-wise.’

# 268

The parable of those who spend their wealth in the way of Allah is that of a grain which grows seven ears, in every ear a hundred grains. Allah enhances severalfold whomever He wishes, and Allah is all-bounteous, all-knowing.

# 269

Those who spend their wealth in the way of Allah and then do not follow up what they have spent with reproaches and affronts, they shall have their reward near their Lord, and they will have no fear, nor will they grieve.

# 270

An honourable reply \[in response to the needy\] and forgiving \[their annoyance\] is better than a charity followed by affront. Allah is all-sufficient, most forbearing.

# 271

O you who have faith! Do not render your charities void by reproaches and affronts, like those who spend their wealth to be seen by people and have no faith in Allah and the Last Day. Their parable is that of a rock covered with soil: a downpour strikes it, leaving it bare. They have no power over anything of what they have earned, and Allah does not guide the faithless lot.

# 272

The parable of those who spend their wealth seeking Allah’s pleasure and to confirm themselves \[in their faith\], is that of a garden on a hillside: the downpour strikes it, whereupon it brings forth its fruit twofold; and if it is not a downpour that strikes it, then a shower, and Allah watches what you do.

# 273

Would any of you like to have a garden of palm trees and vines, with streams running in it, with all kinds of fruit for him therein, and old age were to strike him while he has weakly offspring; whereupon a fiery hurricane were to hit it, whereat it lies burnt? Thus does Allah clarify His signs for you so that you may reflect.

# 274

O you who have faith! Spend of the good things you have earned \[through trade and the like\] and of what We bring forth for you from the earth, and do not be of the mind to give the bad part of it, for you yourselves would not take it, unless you ignore. And know that Allah is all-sufficient, all-laudable.

# 275

Satan frightens you of poverty and prompts you to \[commit\] indecent acts. But Allah promises you His forgiveness and bounty, and Allah is all-bounteous, all-knowing.

# 276

He grants wisdom to whomever He wishes, and he, who is given wisdom, is certainly given an abundant good, and none takes admonition except those who possess intellect.

# 277

Allah indeed knows whatever charity you may give, or vows that you may vow, and the wrongdoers have no helpers.

# 278

If you disclose your charities, that is well, but if you hide them and give them to the poor, that is better for you, and it will atone for some of your misdeeds, and Allah is well aware of what you do.

# 279

It is not up to you to guide them; rather, it is Allah who guides whomever He wishes. Whatever wealth you spend, it is for your own benefit, as you do not spend but to seek Allah’s pleasure, and whatever wealth you spend will be repaid to you in full and you will not be wronged.

# 280

\[The charities are\] for the poor who are straitened in the way of Allah, not capable of moving about in the land \[for trade\]. The unaware suppose them to be well-off because of their reserve. You recognize them by their mark; they do not ask the people importunately. And whatever wealth you may spend, Allah indeed knows it.

# 281

Those who give their wealth by night and day, secretly and openly, they shall have their reward near their Lord, and they will have no fear, nor will they grieve.

# 282

Those who exact usury will not stand but like one deranged by the Devil’s touch. That is because they say, ‘Trade is just like usury.’ While Allah has allowed trade and forbidden usury. Whoever relinquishes \[usury\] on receiving advice from his Lord shall keep \[the gains of\] what is past, and his matter will rest with Allah. As for those who resume, they shall be the inmates of the Fire and they shall remain in it \[forever\].

# 283

Allah brings usury to naught, but He makes charities flourish. Allah does not like any sinful ingrate.

# 284

Indeed those who have faith, do righteous deeds, maintain the prayer and give the zakat, they shall have their reward near their Lord, and they will have no fear, nor will they grieve.

# 285

O you who have faith! Be wary of Allah and abandon \[all claims to\] what remains of usury, should you be faithful.

# 286

And if you do not, then be informed of a war from Allah and His apostle. And if you repent, then you will have your principal, neither harming others, nor suffering harm.

# 287

If \[the debtor\] is in straits, let there be a respite until the time of ease; and if you remit \[the debt\] as charity, it will be better for you, should you know.

# 288

And beware of a day in which you will be brought back to Allah. Then every soul shall be recompensed fully for what it has earned, and they will not be wronged.

# 289

O you who have faith! When you contract a loan for a specified term, write it down. Let a writer write with honesty between you, and let not the writer refuse to write as Allah has taught him. So let him write, and let the one who incurs the debt dictate, and let him be wary of Allah, his Lord, and not diminish anything from it. But if the debtor be feeble-minded, or weak, or incapable of dictating himself, then let his guardian dictate with honesty, and take as witness two witnesses from your men, and if there are not two men, then a man and two women—from those whom you approve as witnesses—so that if one of the two defaults the other will remind her. The witnesses must not refuse when they are called, and do not consider it wearisome to write it down, whether it be a big or small sum, \[as a loan lent\] until its term. That is more just with Allah and more upright in respect to testimony, and the likeliest way to avoid doubt, unless it is an on-the-spot deal you transact between yourselves, in which case there is no sin upon you not to write it. Take witnesses when you make a deal, and let no harm be done to the writer or witness, and if you did that, it would be sinful of you. Be wary of Allah and Allah will teach you, and Allah has knowledge of all things.

# 290

If you are on a journey and cannot find a writer, then a retained pledge \[shall suffice\]. And if one of you entrusts \[an asset\] to another, let him who is trusted deliver his trust, and let him be wary of Allah, his Lord. And do not conceal your testimony; anyone who conceals it, his heart will indeed be sinful, and Allah knows well what you do.

# 291

To Allah belongs whatever is in the heavens and the earth. Whether you disclose what is in your hearts or hide it, Allah will bring you to account for it. Then He will forgive whomever He wishes and punish whomever He wishes, and Allah has power over all things.

# 292

The Apostle and the faithful have faith in what has been sent down to him from his Lord. Each \[of them\] has faith in Allah, His angels, His scriptures and His apostles. \[They declare,\] ‘We make no distinction between any of His apostles.’ And they say, ‘We hear and obey. Our Lord, forgive us, and toward You is the return.’

# 293

Allah does not task any soul beyond its capacity. Whatever \[good\] it earns is to its own benefit, and whatever \[evil\] it incurs is to its own harm. ‘Our Lord! Take us not to task if we forget or make mistakes! Our Lord! Do not place upon us a burden as You placed on those who were before us! Our Lord! Do not lay upon us what we have no strength to bear! Excuse us, forgive us, and be merciful to us! You are our Master, so help us against the faithless lot!’

# 294

Alif, Lam, Mim.

# 295

Allah—there is no god except Him—is the Living One, the All-sustainer.

# 296

He has sent down to you the Book with the truth, confirming what was \[revealed\] before it, and He had sent down the Torah and the Evangel

# 297

before as guidance for mankind, and He has sent down the Criterion. Indeed, there is a severe punishment for those who deny the signs of Allah, and Allah is all-mighty, avenger.

# 298

Nothing is indeed hidden from Allah in the earth or in the sky.

# 299

It is He who forms you in the wombs \[of your mothers\] however He wishes. There is no god except Him, the All-mighty, the All-wise.

# 300

It is He who has sent down to you the Book. Parts of it are definitive verses, which are the mother of the Book, while others are metaphorical. As for those in whose hearts is deviance, they pursue what is metaphorical in it, courting temptation, and seeking its interpretation. But no one knows its interpretation except Allah and those firmly grounded in knowledge; they say, ‘We believe in it; all of it is from our Lord.’ And none takes admonition except those who possess intellect.

# 301

\[They say,\] ‘Our Lord! Do not make our hearts swerve after You have guided us, and bestow Your mercy on us. Indeed, You are the All-munificent.

# 302

Our Lord! You will indeed gather mankind on a day in which there is no doubt. Indeed Allah does not break His promise.’

# 303

As for the faithless, neither their wealth nor their children shall avail them anything against Allah; it is they who will be fuel for the Fire;

# 304

as in the case of Pharaoh’s clan and those who were before them, who denied Our signs. So Allah seized them for their sins, and Allah is severe in retribution.

# 305

Say to the faithless, ‘You shall be overcome and mustered toward hell, and it is an evil resting place.’

# 306

There was certainly a sign for you in the two hosts that met: one host fighting in the way of Allah and the other faithless, who saw them as visibly twice as many. Allah strengthens whomever He wishes with His help. There is indeed a moral in that for those who have insight.

# 307

The love of \[worldly\] allures, including women and children, accumulated piles of gold and silver, horses of mark, livestock, and farms has been made to seem decorous to mankind. Those are the wares of the life of this world, but the goodness of one’s ultimate destination lies near Allah.

# 308

Say, ‘Shall I inform you of something better than that? For those who are Godwary there will be gardens near their Lord, with streams running in them, to remain in them \[forever\], and chaste mates, and Allah’s pleasure.’ And Allah watches His servants.

# 309

Those who say, ‘Our Lord! Indeed, we have faith. So forgive us our sins, and save us from the punishment of the Fire.’

# 310

\[They are\] patient and truthful, obedient and charitable, and they plead for \[Allah’s\] forgiveness at dawns.

# 311

Allah, maintainer of justice, the Almighty and the All-wise, besides whom there is no god, bears witness that there is no god except Him, and \[so do\] the angels and those who possess knowledge.

# 312

Indeed, with Allah religion is Islam, and those who were given the Book did not differ except after knowledge had come to them, out of envy among themselves. And whoever denies Allah’s signs \[should know that\] Allah is swift at reckoning.

# 313

If they argue with you, say, ‘I have submitted my will to Allah, and \[so has\] he who follows me.’ And say to those who were given the Book and the uninstructed ones, ‘Do you submit?’ If they submit, they will certainly be guided; but if they turn away, then your duty is only to communicate, and Allah watches His servants.

# 314

Those who deny Allah’s signs and kill the prophets unjustly and kill those who call for justice from among the people, inform them of a painful punishment.

# 315

They are the ones whose works have failed in this world and the Hereafter, and they will have no helpers.

# 316

Have you not regarded those who were given a share of the Book, who are summoned to the Book of Allah in order that it may judge between them, whereat a part of them refuse to comply and they are disregardful?

# 317

That is because they say, ‘The Fire shall not touch us except for a number of days,’ and they have been misled in their religion by what they used to fabricate.

# 318

But how will it be \[with them\] when We gather them on a day in which there is no doubt, and every soul shall be recompensed fully for what it has earned, and they will not be wronged?

# 319

Say, ‘O Allah, Master of all sovereignty! You give sovereignty to whomever You wish, and strip of sovereignty whomever You wish; You make mighty whomever You wish, and You degrade whomever You wish; all choice is in Your hand. Indeed You have power over all things.’

# 320

‘You make the night pass into the day and You make the day pass into the night. You bring forth the living from the dead and You bring forth the dead from the living, and You provide for whomever You wish without any reckoning.’

# 321

The faithful should not take the faithless for allies instead of the faithful, and Allah will have nothing to do with those who do that, except when you are wary of them, out of caution. Allah warns you to beware of \[disobeying\] Him, and toward Allah is the return.

# 322

Say, ‘Whether you hide what is in your hearts or disclose it, Allah knows it, and He knows whatever there is in the heavens and whatever there is in the earth; and Allah has power over all things.’

# 323

The day when every soul will find present whatever good it has done; and as for the evil, it has done, it will wish there were a far distance between it and itself. Allah warns you to beware of \[disobeying\] Him, and Allah is most kind to \[His\] servants.

# 324

Say, ‘If you love Allah, then follow me; Allah will love you and forgive you your sins, and Allah is all-forgiving, all-merciful.’

# 325

Say, ‘Obey Allah and the Apostle.’ But if they turn away, indeed Allah does not like the faithless.

# 326

Indeed Allah chose Adam and Noah, and the progeny of Abraham and the progeny of Imran above all the nations;

# 327

some of them are descendants of the others, and Allah is all-hearing, all-knowing.

# 328

When the wife of Imran said, ‘My Lord, I dedicate to You in consecration what is in my belly. Accept it from me; indeed You are the All-hearing, the All-knowing.’

# 329

When she bore her, she said, ‘My Lord, I have borne a female \[child\]’—and Allah knew better what she had borne, and the male \[child she expected\] was no match for the female \[child she had borne\] —‘and I have named her Mary, and I commend her and her offspring to Your care against \[the evil of\] the outcast Satan.’

# 330

Thereupon her Lord accepted her with a gracious acceptance, and made her grow up in a worthy fashion, and He charged Zechariah with her care. Whenever Zechariah visited her in the sanctuary, he would find provisions with her. He said, ‘O Mary, from where does this come for you?’ She said, ‘It comes from Allah. Allah provides whomever He wishes without any reckoning.’

# 331

Thereat Zechariah supplicated his Lord. He said, ‘My Lord! Grant me a good offspring from You! Indeed You hear all supplications.’

# 332

Then, as he stood praying in the sanctuary the angels called out to him: ‘Allah gives you the good news of John, as a confirmer of a Word of Allah, eminent and chaste, a prophet, and one of the righteous.’

# 333

He said, ‘My Lord, how shall I have a son while old age has overtaken me and my wife is barren?’ Said He, ‘So it is that Allah does whatever He wishes.’

# 334

He said, ‘My Lord, grant me a sign.’ Said He, ‘Your sign is that you will not speak to people for three days except in gestures. Remember Your Lord much, and glorify Him morning and evening.’

# 335

And when the angels said, ‘O Mary, Allah has chosen you and purified you, and He has chosen you above the world’s women.

# 336

O Mary, be obedient to your Lord and prostrate and bow down with those who bow \[in worship\].’

# 337

These accounts are from the Unseen, which We reveal to you, and you were not with them when they were casting lots \[to see\] which of them would take charge of Mary’s care, nor were you with them when they were contending.

# 338

When the angels said, ‘O Mary, Allah gives you the good news of a Word from Him whose name is Messiah, Jesus son of Mary, distinguished in the world and the Hereafter and one of those brought near \[to Allah\].

# 339

He will speak to the people in the cradle and in adulthood, and will be one of the righteous.’

# 340

She said, ‘My Lord, how shall I have a child seeing that no human has ever touched me?’ He said, ‘So it is that Allah creates whatever He wishes. When He decides on a matter He just says to it ‘‘Be!’’ and it is.

# 341

He will teach him the Book and wisdom, the Torah and the Evangel,

# 342

and \[he will be\] an apostle to the Children of Israel, \[and he will declare,\] “I have certainly brought you a sign from your Lord: I will create for you the form of a bird out of clay, then I will breathe into it, and it will become a bird by Allah’s leave. I heal the blind and the leper and I revive the dead by Allah’s leave. I will tell you what you have eaten and what you have stored in your houses. There is indeed a sign in that for you, should you be faithful.

# 343

And \[I come\] to confirm \[the truth of\] that which is before me of the Torah, and to make lawful for you some of the things that were forbidden you. I have brought you a sign from your Lord; so be wary of Allah and obey me.

# 344

Indeed Allah is my Lord and your Lord; so worship Him. This is a straight path.” ’

# 345

When Jesus sensed their faithlessness, he said, ‘Who will be my helpers \[on the path\] toward Allah?’ The Disciples said, ‘We will be helpers of Allah. We have faith in Allah, and you be witness that we have submitted \[to Him\].

# 346

Our Lord, we believe in what You have sent down, and we follow the apostle, so write us among the witnesses.’

# 347

Then they plotted \[against Jesus\], and Allah also devised, and Allah is the best of devisers.

# 348

When Allah said, ‘O Jesus, I shall take you\[r soul\], and I shall raise you up toward Myself, and I shall clear you of \[the calumnies of\] the faithless, and I shall set those who follow you above the faithless until the Day of Resurrection. Then to Me will be your return, whereat I will judge between you concerning that about which you used to differ.

# 349

As for the faithless, I will punish them with a severe punishment in the world and the Hereafter; and they will have no helpers.’

# 350

But as for those who have faith and do righteous deeds, He will pay them in full their rewards, and Allah does not like the wrongdoers.

# 351

These that We recite to you are from the signs and the Wise Reminder.

# 352

Indeed the case of Jesus with Allah is like the case of Adam: He created him from dust, then said to him, ‘Be,’ and he was.

# 353

This is the truth from your Lord, so do not be among the skeptics.

# 354

Should anyone argue with you concerning him, after the knowledge that has come to you, say, ‘Come! Let us call our sons and your sons, our women and your women, our souls and your souls, then let us pray earnestly, and call down Allah’s curse upon the liars.’

# 355

This is indeed the true account, for sure. There is no god but Allah, and indeed Allah is the All-mighty, the All-wise.

# 356

But if they turn away, indeed Allah knows best the agents of corruption.

# 357

Say, ‘O People of the Book! Come to a common word between us and you: that we will worship no one but Allah, that we will not ascribe any partner to Him, and that some of us will not take some others as lords besides Allah.’ But if they turn away, say, ‘Be witnesses that we have submitted \[to Allah\].’

# 358

O People of the Book! Why do you argue concerning Abraham? Neither the Torah nor the Evangel were sent down until \[long\] after him. Do you not exercise your reason?

# 359

Ah! You are the very ones who argue about that of which you have knowledge. But why do you argue about that of which you have no knowledge? And Allah knows and you do not know.

# 360

Abraham was neither a Jew nor a Christian. Rather, he was a Hanif, a Muslim, and he was not one of the polytheists.

# 361

Indeed the nearest of all people to Abraham are those who follow him and this prophet and those who have faith, and Allah is the guardian of the faithful.

# 362

A group of the People of the Book were eager to lead you astray; yet they lead no one astray except themselves, but they are not aware.

# 363

O People of the Book! Why do you deny Allah’s signs while you testify \[to their truth\]?

# 364

O People of the Book! Why do you mix the truth with falsehood, and conceal the truth while you know \[it\]?

# 365

A group of the People of the Book say, ‘Believe in what has been sent down to the faithful at the beginning of the day, and disbelieve at its end, so that they may turn back \[from their religion\].’

# 366

And \[they say,\] ‘Do not believe anyone except him who follows your religion.’ Say, ‘Indeed \[true\] guidance is the guidance of Allah.’ \[They also say.\] ‘\[Do not believe\] that anyone may be given the like of what you were given, or that he may argue with you before your Lord.’ Say, ‘Indeed all grace is in Allah’s hand; He grants it to whomever He wishes, and Allah is all-bounteous, all-knowing.

# 367

He singles out for His mercy whomever He wishes, and Allah is dispenser of a great grace.’

# 368

Among the People of the Book is he who if you entrust him with a quintal will repay it to you, and among them is he who, if you entrust him with a dinar will not repay it to you unless you stand persistently over him. That is because they say, ‘We have no obligation to the non-Jews.’ But they attribute lies to Allah, and they know \[it\].

# 369

Yes, whoever fulfills his commitments and is wary of Allah—Allah indeed loves the Godwary.

# 370

There shall be no share in the Hereafter for those who sell Allah’s covenant and their oaths for a paltry gain, and on the Day of Resurrection Allah will not speak to them nor will He \[so much as\] look at them, nor will He purify them, and there is a painful punishment for them.

# 371

There is a group of them who alter their voice while reading out a text \[that they have themselves authored\], so that you may suppose it to be from the Book, though it is not from the Book, and they say, ‘It is from Allah,’ though it is not from Allah, and they attribute lies to Allah, and they know \[it\].

# 372

It does not behoove any human that Allah should give him the Book, judgement and prophethood, and then he should say to the people, ‘Be my servants instead of Allah.’ Rather \[he would say\], ‘Be a godly people, because of your teaching the Book and because of your studying it.’

# 373

And he would not command you to take the angels and the prophets for lords. Would he call you to unfaith after you have submitted \[to Allah\]?

# 374

When Allah took a compact concerning the prophets, \[He said,\] ‘Inasmuch as I have given you \[the knowledge\] of the Book and wisdom, should an apostle come to you thereafter confirming what is with you, you shall believe in him and help him.’ He said, ‘Do you pledge and accept My covenant on this condition?’ They said, ‘We pledge.’ He said, ‘Then be witnesses, and I, too, am among the witnesses along with you.’

# 375

Then whoever turns away after that—it is they who are the transgressors.

# 376

Do they seek a religion other than that of Allah, while to Him submits whoever there is in the heavens and the earth, willingly or unwillingly, and to Him they will be brought back?

# 377

Say, ‘We have faith in Allah and in what has been sent down to us, and what was sent down to Abraham, Ishmael, Isaac, Jacob and the Tribes, and that which Moses, Jesus and the prophets were given by their Lord. We make no distinction between any of them, and to Him do we submit.’

# 378

Should anyone follow a religion other than Islam, it shall never be accepted from him, and he will be among the losers in the Hereafter.

# 379

How shall Allah guide a people who have disbelieved after their faith and \[after\] bearing witness that the Apostle is true, and \[after\] manifest proofs had come to them? Allah does not guide the wrongdoing lot.

# 380

Their requital is that there shall be upon them the curse of Allah, the angels, and all mankind.

# 381

They will remain in it \[forever\], and their punishment will not be lightened, nor will they be granted any respite,

# 382

except such as repent after that and make amends, for Allah is all-forgiving, all-merciful.

# 383

Indeed those who turn faithless after their faith, and then advance in faithlessness, their repentance will never be accepted, and it is they who are the astray.

# 384

Indeed those who turn faithless and die while they are faithless, a world of gold will not be accepted from any of them should he offer it for ransom. For such there will be a painful punishment, and they will have no helpers.

# 385

You will never attain piety until you spend out of what you hold dear, and whatever you may spend of anything, Allah indeed knows it.

# 386

All food was lawful to the Children of Israel except what Israel had forbidden himself before the Torah was sent down. Say, ‘Bring the Torah, and read it, if you are truthful.’

# 387

So whoever fabricates a lie against Allah after that—it is they who are the wrongdoers.

# 388

Say, ‘Allah has spoken the truth; so follow the creed of Abraham, a Hanif, and he was not one of the polytheists.

# 389

Indeed the first house to be set up for mankind is the one at Bakkah, blessed and a guidance for all nations.

# 390

In it are manifest signs \[and\] Abraham’s Station, and whoever enters it shall be secure. And it is the duty of mankind toward Allah to make pilgrimage to the House—for those who can afford the journey to it—and should anyone renege \[on his obligation\], Allah is indeed without need of the creatures.

# 391

Say, ‘O People of the Book! Why do you deny the signs of Allah, while Allah is witness to what you do?’

# 392

Say, ‘O People of the Book! why do you bar the faithful from the way of Allah, seeking to make it crooked, while you are witnesses \[to its truthfulness\]? And Allah is not oblivious of what you do.’

# 393

O you who have faith, if you obey a part of those who were given the Book, they will turn you back, after your faith, into faithless ones.

# 394

And how would you be faithless while the signs of Allah are recited to you and His Apostle is in your midst? Whoever takes recourse in Allah is certainly guided to a straight path.

# 395

O you who have faith! Be wary of Allah with the wariness due to Him and do not die except as Muslims.

# 396

Hold fast, all together, to Allah’s cord, and do not be divided \[into sects\]. Remember Allah’s blessing upon you when you were enemies, then He brought your hearts together, so you became brothers with His blessing. And you were on the brink of a pit of Fire, whereat He saved you from it. Thus does Allah clarify His signs for you so that you may be guided.

# 397

There has to be a nation among you summoning to the good, bidding what is right, and forbidding what is wrong. It is they who are the felicitous.

# 398

Do not be like those who became divided \[into sects\] and differed after manifest signs had come to them. For such there will be a great punishment

# 399

on the day when \[some\] faces will turn white and \[some\] faces will turn black. As for those whose faces turn black \[it will be said to them\], ‘Did you disbelieve after your faith? So taste the punishment because of what you used to disbelieve.’

# 400

But as for those whose faces become white, they shall dwell in Allah’s mercy, and they will remain in it \[forever\].

# 401

These are the signs of Allah, which We recite to you in truth, and Allah does not desire any wrong for the creatures.

# 402

To Allah belongs whatever there is in the heavens and the earth, and to Allah all matters are returned.

# 403

You are the best nation \[ever\] brought forth for mankind: you bid what is right and forbid what is wrong, and have faith in Allah. And if the People of the Book had believed, it would have been better for them. Among them \[some\] are faithful, but most of them are transgressors.

# 404

They will never do you any harm, except for some hurt; and if they fight you, they will turn their backs \[to flee\], then they will not be helped.

# 405

Wherever they are found, abasement is stamped upon them, except for an asylum from Allah and an asylum from the people. They have earned the wrath of Allah, and poverty has been stamped upon them. That, because they would deny the signs of Allah and kill the prophets unjustly. That, because they would disobey and commit transgression.

# 406

Yet they are not all alike. Among the People of the Book is an upright nation; they recite Allah’s signs in the watches of the night and prostrate.

# 407

They have faith in Allah and the Last Day, and bid what is right and forbid what is wrong, and they are active in \[performing\] good deeds. Those are among the righteous.

# 408

Whatever good they do, they will not go unappreciated for it, and Allah knows well the Godwary.

# 409

As for the faithless, neither their wealth nor their children will avail them anything against Allah. They shall be the inmates of the Fire and remain in it \[forever\].

# 410

The parable of what they spend in the life of this world is that of a cold wind that strikes the tillage of a people who wronged themselves, destroying it. Allah does not wrong them, but they wrong themselves.

# 411

O you who have faith! Do not take your confidants from others than yourselves; they will spare nothing to ruin you. They are eager to see you in distress. Hatred has already shown itself from their mouths, and what their breasts hide \[within\] is yet worse. We have certainly made the signs clear for you, should you exercise your reason.

# 412

Ah! You are the ones who bear love towards them, while they do not love you, though you believe in all the Books. When they meet you, they say, ‘We believe,’ but when they are alone, they bite their fingertips at you out of rage. Say, ‘Die of your rage!’ Indeed Allah knows well what is in the breasts.

# 413

If some good should befall you, it upsets them, but if some ill befalls you, they rejoice at it. Yet if you are patient and Godwary, their guile will not harm you in any way. Indeed Allah encompasses what they do.

# 414

When you left your family at dawn to settle the faithful in their positions for battle —and Allah is all-hearing, all-knowing.

# 415

When two groups among you were about to lose courage—though Allah is their guardian, and in Allah let all the faithful put their trust.

# 416

Certainly Allah helped you at Badr, when you were weak \[in the enemy’s eyes\]. So be wary of Allah so that you may give thanks.

# 417

When you were saying to the faithful, ‘Is it not enough for you that your Lord should aid you with three thousand angels sent down?’

# 418

Yes, if you are steadfast and Godwary, and should they come at you suddenly, your Lord will aid you with five thousand angels sent in \[to the scene of battle\].

# 419

Allah did not appoint it but as a good news for you and to reassure with it your hearts; and victory comes only from Allah, the All-mighty, the All-wise,

# 420

that He may cut down a section of the faithless, or subdue them, so that they retreat disappointed.

# 421

You have no hand in the matter, whether He accepts their repentance or punishes them, for they are indeed wrongdoers.

# 422

To Allah belongs whatever there is in the heavens and the earth: He forgives whomever He wishes and punishes whomever He wishes, and Allah is all-forgiving, all-merciful.

# 423

O you who have faith! Do not exact usury, twofold and severalfold, and be wary of Allah so that you may be felicitous.

# 424

Beware of the Fire, which has been prepared for the faithless,

# 425

and obey Allah and the Apostle so that you may be granted \[His\] mercy.

# 426

Hasten towards your Lord’s forgiveness and a paradise as vast as the heavens and the earth, prepared for the Godwary

# 427

—those who spend in ease and adversity, and suppress their anger, and excuse \[the faults of\] the people, and Allah loves the virtuous;

# 428

and those who, when they commit an indecent act or wrong themselves, remember Allah, and plead \[to Allah seeking His\] forgiveness for their sins—and who forgives sins except Allah?—and who knowingly do not persist in what \[sins\] they have committed.

# 429

Their reward is forgiveness from their Lord, and gardens with streams running in them, to remain in them \[forever\]. How excellent is the reward of the workers!

# 430

Certain \[Divine\] precedents have passed before you. So travel through the land and observe how was the fate of the deniers.

# 431

This is an explanation for mankind, and a guidance and advice for the Godwary.

# 432

Do not weaken or grieve: you shall have the upper hand, should you be faithful.

# 433

If wounds afflict you, like wounds have already afflicted those people; and We make such vicissitudes rotate among mankind, so that Allah may ascertain those who have faith, and that He may take martyrs from among you, and Allah does not like the wrongdoers.

# 434

And so that Allah may purge \[the hearts of\] those who have faith and that He may wipe out the faithless.

# 435

Do you suppose that you would enter paradise, while Allah has not yet ascertained those of you who have waged jihad and He has not ascertained the steadfast?

# 436

Certainly you were longing for death before you had encountered it. Then certainly, you saw it, as you were looking on.

# 437

Muhammad is but an apostle; \[other\] apostles have passed before him. If he dies or is slain, will you turn back on your heels? Anyone who turns back on his heels, will not harm Allah in the least, and soon Allah will reward the grateful.

# 438

No soul may die except by Allah’s leave, at an appointed time. Whoever desires the reward of this world, We will give him of it; and whoever desires the reward of the Hereafter, We will give him of it; and soon We will reward the grateful.

# 439

How many a prophet there has been with whom a multitude of godly men fought. They did not falter for what befell them in the way of Allah, neither did they weaken, nor did they abase themselves; and Allah loves the steadfast.

# 440

All that they said was, ‘Our Lord, forgive us our sins and our excesses in our affairs, make our feet steady, and help us against the faithless lot.’

# 441

So Allah gave them the reward of this world and the fair reward of the Hereafter; and Allah loves the virtuous.

# 442

O you who have faith! If you obey the faithless, they will turn you back on your heels, and you will become losers.

# 443

Indeed, Allah is your Master, and He is the best of helpers.

# 444

We shall cast terror into the hearts of the faithless because of their ascribing partners to Allah, for which He has not sent down any authority, and their refuge shall be the Fire, and evil is the \[final\] abode of the wrongdoers.

# 445

Allah certainly fulfilled His promise to you when you were slaying them with His leave, until you lost courage, disputed about the matter, and disobeyed after He showed you what you loved. Some among you desire this world, and some among you desire the Hereafter. Then He turned you away from them so that He might test you. Certainly He has excused you, for Allah is gracious to the faithful.

# 446

When you were fleeing without paying any attention to anyone, while the Apostle was calling you from your rear, He requited you with grief upon grief, so that you may not grieve for what you lose nor for what befalls you, and Allah is well aware of what you do.

# 447

Then He sent down to you safety after grief—a drowsiness that came over a group of you—while another group, anxious only about themselves, entertained false notions about Allah, notions of \[pagan\] ignorance. They say, ‘Do we have any role in the matter?’ Say, ‘Indeed the matter belongs totally to Allah.’ They hide in their hearts what they do not disclose to you. They say, ‘Had we any role in the matter, we would not have been slain here.’ Say, ‘Even if you had remained in your houses, those destined to be slain would have set out toward the places where they were laid to rest, so that Allah may test what is in your breasts, and that He may purge what is in your hearts, and Allah knows well what is in the breasts.’

# 448

Those of you who fled on the day when the two hosts met, only Satan had made them stumble because of some of their deeds. Certainly, Allah has excused them, for Allah is all-forgiving, all-forbearing.

# 449

O you who have faith! Do not be like the faithless who say of their brethren, when they travel in the land or go into battle, ‘Had they stayed with us they would not have died or been killed,’ so that Allah may make it a regret in their hearts. But Allah gives life and brings death, and Allah watches what you do.

# 450

If you are slain in the way of Allah, or die, forgiveness and mercy from Allah are surely better than what they amass.

# 451

If you die or are slain, you will surely be mustered toward Allah.

# 452

It is by Allah’s mercy that you are gentle to them; had you been harsh and hardhearted, they would have surely scattered from around you. So excuse them and plead for forgiveness for them, and consult them in the affairs, and once you are resolved, put your trust in Allah. Indeed Allah loves those who trust in Him.

# 453

If Allah helps you, no one can overcome you, but if He forsakes you, who will help you after Him? So in Allah let all the faithful put their trust.

# 454

A prophet may not breach his trust, and whoever breaches his trust will bring his breaches on the Day of Resurrection; then every soul shall be recompensed fully for what it has earned, and they will not be wronged.

# 455

Is he who follows \[the course of\] Allah’s pleasure like him who earns Allah’s displeasure and whose refuge is hell, an evil destination?

# 456

They have ranks with Allah, and Allah watches what they do.

# 457

Allah certainly favoured the faithful when He raised up among them an apostle from among themselves to recite to them His signs and to purify them and teach them the Book and wisdom, and earlier they had indeed been in manifest error.

# 458

What, when an affliction visits you—while you have inflicted twice as much—do you say, ‘How is this?’! Say, ‘This is from your own souls.’ Indeed Allah has power over all things.

# 459

What befell you on the day when the two hosts met, was by Allah’s permission, so that He may ascertain the faithful,

# 460

and ascertain the hypocrites. \[When\] they were told: ‘Come, fight in the way of Allah, or defend \[yourselves\], they said, ‘If we knew any fighting, we would have surely followed you.’ That day they were nearer to unfaith than to faith. They say with their mouths what is not in their hearts, and Allah knows well whatever they conceal.

# 461

Those who said of their brethren, while they themselves sat back: ‘Had they obeyed us, they would not have been killed.’ Say, ‘Then keep death off from yourselves, if you are truthful.’

# 462

Do not suppose those who were slain in the way of Allah to be dead; no, they are living and provided for near their Lord,

# 463

exulting in what Allah has given them out of His grace, and rejoicing for those who have not yet joined them from \[those left\] behind them, that they will have no fear, nor will they grieve.

# 464

They rejoice in Allah’s blessing and grace, and that Allah does not waste the reward of the faithful.

# 465

Those who responded to Allah and the Apostle \[even\] after they had been wounded—for those of them who have been virtuous and Godwary there shall be a great reward.

# 466

—Those to whom the people said, ‘All the people have gathered against you, so fear them.’ That only increased them in faith, and they said, ‘Allah is sufficient for us, and He is an excellent trustee.’

# 467

So they returned with Allah’s blessing and grace, untouched by any harm. They pursued the pleasure of Allah, and Allah is dispenser of a great grace.

# 468

That is only Satan frightening \[you\] of his followers! So fear them not, and fear Me, should you be faithful.

# 469

Do not grieve for those who are active in unfaith; they will not hurt Allah in the least: Allah desires to give them no share in the Hereafter, and there is a great punishment for them.

# 470

Those who have bought unfaith for faith will not hurt Allah in the least, and there is a painful punishment for them.

# 471

Let the faithless not suppose that the respite that We grant them is good for their souls: We give them respite only that they may increase in sin, and there is a humiliating punishment for them.

# 472

Allah will not leave the faithful in your present state, until He has separated the bad ones from the good. Allah will not acquaint you with the Unseen, but Allah chooses whomever He wishes from His apostles. So have faith in Allah and His apostles; and if you are faithful and Godwary, there shall be a great reward for you.

# 473

Let the stingy not suppose that \[their grudging\] what Allah has given them out of His bounty is good for them; no, it is bad for them. They will be collared with what they grudge on the Day of Resurrection. To Allah belongs the heritage of the heavens and the earth, and Allah is well aware of what you do.

# 474

Allah has certainly heard the remark of those who said, ‘Allah is poor and we are rich.’ We will record what they have said, and their killing of the prophets unjustly, and We shall say, ‘Taste the punishment of the burning.

# 475

That is because of what your hands have sent ahead, and because Allah is not tyrannical to His servants.’

# 476

Tell those who say, ‘Allah has pledged us not to believe in any apostle unless he brings us an offering consumed by fire,’ ‘Apostles before me certainly did bring you manifest signs and what you speak of. Then why did you kill them, if you are truthful?’

# 477

But if they deny you, \[other\] apostles have been denied before you, who came with manifest signs, holy writs, and an illuminating scripture.

# 478

Every soul shall taste death, and you will indeed be paid your full rewards on the Day of Resurrection. Whoever is delivered from the Fire and admitted to paradise has certainly succeeded. The life of this world is nothing but the wares of delusion.

# 479

You will surely be tested in your possessions and your souls, and you will surely hear much affront from those who were given the Book before you and from the polytheists; but if you are patient and Godwary, that is indeed the steadiest of courses.

# 480

When Allah made a covenant with those who were given the Book: ‘You shall explain it for the people, and you shall not conceal it,’ they cast it behind their backs and sold it for a paltry gain. How evil is what they buy!

# 481

Do not suppose those who brag about what they have done, and love to be praised for what they have not done—do not suppose them saved from punishment and there is a painful punishment for them.

# 482

To Allah belongs the kingdom of the heavens and the earth, and Allah has power over all things.

# 483

Indeed in the creation of the heavens and the earth and the alternation of night and day, there are signs for those who possess intellect.

# 484

Those who remember Allah standing, sitting, and lying on their sides, and reflect on the creation of the heavens and the earth \[and say\], ‘Our Lord, You have not created this in vain! Immaculate are You! Save us from the punishment of the Fire.

# 485

Our Lord, whoever that You make enter the Fire will surely have been disgraced by You, and the wrongdoers will have no helpers.

# 486

Our Lord, we have indeed heard a summoner calling to faith, declaring, ‘‘Have faith in your Lord!’’ So we believed. Our Lord, forgive us our sins and absolve us of our misdeeds, and make us die with the pious.

# 487

Our Lord, give us what You have promised us through Your apostles, and do not disgrace us on the Day of Resurrection. Indeed You do not break Your promise.’

# 488

Then their Lord answered them, ‘I do not waste the work of any worker among you, whether male or female; you are all on the same footing. So those who migrated and were expelled from their homes, and were tormented in My way, and those who fought and were killed—I will surely absolve them of their misdeeds and I will admit them into gardens with streams running in them, as a reward from Allah, and Allah—with Him is the best of rewards.’

# 489

Never be misled by the bustle of the faithless in the towns.

# 490

It is a trivial enjoyment; then their refuge is hell, and it is an evil resting place.

# 491

But those who are wary of their Lord—for them shall be gardens with streams running in them, to remain in them \[forever\], a hospitality from Allah; and what is with Allah is better for the pious.

# 492

Indeed among the People of the Book there are some who have faith in Allah and in what has been sent down to you, and in what has been sent down to them. Humble toward Allah, they do not sell the signs of Allah for a paltry gain. They shall have their reward near their Lord; indeed Allah is swift at reckoning.

# 493

O you who have faith! Be patient, stand firm, and close \[your\] ranks, and be wary of Allah so that you may be felicitous.

# 494

O mankind! Be wary of your Lord who created you from a single soul, and created its mate from it, and from the two of them scattered numerous men and women. Be wary of Allah, in whose Name you adjure one another and \[of severing ties with\] blood relations. Indeed Allah is watchful over you.

# 495

Give the orphans their property, and do not replace the good with the bad, and do not eat up their property \[by mingling it\] with your own property, for that is indeed a great sin.

# 496

If you fear that you may not deal justly with the orphans, then marry \[other\] women that you like, two, three, or four. But if you fear that you may not treat them fairly, then \[marry only\] one, or \[marry from among\] your slave-women. That makes it likelier that you will not be unfair.

# 497

Give women their dowries, handing it over to them; but if they remit anything of it of their own accord, then consume it as \[something\] lawful and wholesome.

# 498

Do not give the feeble-minded your property, which Allah has assigned you to manage: provide for them out of it and clothe them, and speak to them honourable words.

# 499

Test the orphans when they reach the age of marriage. Then if you discern in them maturity, deliver to them their property. And do not consume it lavishly and hastily lest they should grow up. As for him who is well-off, let him be abstemious, and as for him who is poor, let him eat in an honourable manner. And when you deliver to them their property, take witnesses over them, and Allah suffices as reckoner.

# 500

Men have a share in the heritage left by parents and near relatives, and women have a share in the heritage left by parents and near relatives, whether it be little or much, a share ordained \[by Allah\].

# 501

And when the division is attended by relatives, the orphans and the needy, provide for them out of it, and speak to them honourable words.

# 502

Let those fear \[the result of mistreating orphans\] who, were they to leave behind weak offspring, would be concerned on their account. So let them be wary of Allah, and let them speak upright words.

# 503

Indeed those who consume the property of orphans wrongfully, only ingest fire into their bellies, and soon they will enter the Blaze.

# 504

Allah enjoins you concerning your children: for the male shall be the like of the share of two females, and if there be \[two or\] more than two females, then for them shall be two-thirds of what he leaves; but if she be alone, then for her shall be a half; and for each of his parents a sixth of what he leaves, if he has children; but if he has no children, and his parents are his \[sole\] heirs, then it shall be a third for his mother; but if he has brothers, then a sixth for his mother, after \[paying off\] any bequest he may have made or any debt \[he may have incurred\]. Your parents and your children—you do not know which of them is likelier to be beneficial for you. This is an ordinance from Allah. Indeed Allah is all-knowing, all-wise.

# 505

For you shall be a half of what your wives leave, if they have no children; but if they have children, then for you shall be a fourth of what they leave, after \[paying off\] any bequest they may have made or any debt \[they may have incurred\]. And for them \[it shall be\] a fourth of what you leave, if you have no children; but if you have children, then for them shall be an eighth of what you leave, after \[paying off\] any bequest you may have made or any debt \[you may have incurred\]. If a man or woman is inherited by siblings and has a brother or a sister, then each of them shall receive a sixth; but if they are more than that, then they shall share in one third, after \[paying off\] any bequest he may have made or any debt \[he may have incurred\] without prejudice. \[This is\] an enjoinment from Allah, and Allah is all-knowing, all-forbearing.

# 506

These are Allah’s bounds, and whoever obeys Allah and His Apostle, He shall admit him to gardens with streams running in them, to remain in them \[forever\]. That is the great success.

# 507

But whoever disobeys Allah and His Apostle and transgresses the bounds set by Allah, He shall make him enter a Fire, to remain in it \[forever\], and there will be a humiliating punishment for him.

# 508

Should any of your women commit an indecent act, produce against them four witnesses from yourselves, and if they testify, detain them in \[their\] houses until death finishes them, or Allah decrees a course for them.

# 509

Should two among you commit it, chastise them both; but if they repent and reform, let them alone. Indeed Allah is all-clement, all-merciful.

# 510

\[Acceptance of\] repentance by Allah is only for those who commit evil out of ignorance and then repent promptly. It is such whose repentance Allah will accept, and Allah is all-knowing, all-wise.

# 511

But \[acceptance of\] repentance is not for those who go on committing misdeeds: when death approaches any of them, he says, ‘I repent now.’ Nor is it for those who die while they are faithless. For such We have prepared a painful punishment.

# 512

O you who have faith! It is not lawful for you to inherit women forcibly, and do not press them to take away part of what you have given them, unless they commit a gross indecency. Consort with them in an honourable manner; and should you dislike them, maybe you dislike something while Allah invests it with an abundant good.

# 513

If you desire to take a wife in place of another, and you have given one of them a quintal \[of gold\], do not take anything away from it. Would you take it by way of calumny and flagrant sin?!

# 514

How could you take it back, when you have known each other, and they have taken from you a solemn covenant?

# 515

Do not marry any of the women whom your fathers had married, excluding what is already past. That is indeed an indecency, an outrage and an evil course.

# 516

Forbidden to you are your mothers, your daughters and your sisters, your paternal aunts and your maternal aunts, your brother’s daughters and your sister’s daughters, your \[foster-\]mothers who have suckled you and your sisters through fosterage, your wives’ mothers, and your stepdaughters who are under your care \[born\] of the wives whom you have gone into—but if you have not gone into them there is no sin upon you—and the wives of your sons who are from your own loins, and that you should marry two sisters at one time—excluding what is already past; indeed Allah is all-forgiving, all-merciful—

# 517

and married women, excepting your slave-women. This is Allah’s ordinance for you. As to others than these, it is lawful for you to seek \[temporary union with them\] with your wealth, in wedlock, not in license. For the enjoyment you have had from them thereby, give them their dowries, by way of settlement, and there is no sin upon you in what you may agree upon after the settlement. Indeed Allah is all-knowing, all-wise.

# 518

As for those of you who cannot afford to marry faithful free women, then \[let them marry\] from what you own, from among your faithful slave-women. Your faith is best known \[only\] to Allah; you are all \[on a\] similar \[footing\]. So marry them with their masters’ permission, and give them their dowries in an honourable manner—\[such of them\] as are chaste women, not licentious ones or those who take paramours. But should they commit an indecent act on marrying, there shall be for them \[only\] half the punishment for free women. This is for those of you who fear falling into fornication; but it is better that you be continent, and Allah is all-forgiving, all-merciful.

# 519

Allah desires to explain \[the laws\] to you, and to guide you to the customs of those who were before you, and to turn toward you clemently, and Allah is all-knowing, all-wise.

# 520

Allah desires to turn toward you clemently, but those who pursue their \[base\] appetites desire that you fall into gross waywardness.

# 521

Allah desires to lighten your burden, for man was created weak.

# 522

O you who have faith! Do not eat up your wealth among yourselves unrightfully, but it should be trade by mutual consent. And do not kill yourselves. Indeed Allah is most merciful to you.

# 523

And whoever does that in aggression and injustice, We will soon make him enter the Fire, and that is easy for Allah.

# 524

If you avoid the major sins that you are forbidden, We will absolve you of your misdeeds and admit you to a noble abode.

# 525

Do not covet the advantage, which Allah has given some of you over others. To men belongs a share of what they have earned, and to women a share of what they have earned. And ask Allah for His bounty. Indeed Allah has knowledge of all things.

# 526

For everyone We have appointed heirs to what the parents and near relatives leave, as well as those with whom you have made a compact; so give them their share \[of the heritage\]. Indeed Allah is witness to all things.

# 527

Men are the managers of women, because of the advantage Allah has granted some of them over others, and by virtue of their spending out of their wealth. Righteous women are obedient and watchful in the absence \[of their husbands\] in guarding what Allah has enjoined \[them\] to guard. As for those \[wives\] whose misconduct you fear, \[first\] advise them, and \[if ineffective\] keep away from them in the bed, and \[as the last resort\] beat them. Then if they obey you, do not seek any course \[of action\] against them. Indeed Allah is all-exalted, all-great.

# 528

If you fear a split between the two of them, then appoint an arbiter from his relatives and an arbiter from her relatives. If they desire reconcilement, Allah shall reconcile them. Indeed Allah is all-knowing, all-aware.

# 529

Worship Allah and do not ascribe any partners to Him, and be good to parents, the relatives, the orphans, the needy, the near neighbour and the distant neighbour, the companion at your side, the traveller, and your slaves. Indeed Allah does not like those who are arrogant and boastful.

# 530

—Those who are \[themselves\] stingy and bid \[other\] people to be stingy, and conceal whatever Allah has given them out of His bounty; and We have prepared for the faithless a humiliating punishment.

# 531

And those who spend their wealth to be seen by people, and believe neither in Allah nor in the Last Day. As for him who has Satan for his companion—an evil companion is he!

# 532

What harm would it have done them had they believed in Allah and the Last Day, and spent out of what Allah has provided them? Allah knows them well.

# 533

Indeed Allah does not wrong \[anyone\] \[even to the extent of\] an atom’s weight, and if it be a good deed He doubles it\[s reward\], and gives from Himself a great reward.

# 534

So how shall it be, when We bring a witness from every nation and We bring you as a witness to them?

# 535

On that day those who were faithless and \[who\] disobeyed the Apostle will wish the earth were levelled with them, and they will not conceal any matter from Allah.

# 536

O you who have faith! Do not approach prayer when you are intoxicated, \[not\] until you know what you are saying, nor \[enter mosques\] in the state of ritual impurity until you have washed yourselves, except while passing through. But if you are sick or on a journey, or any of you has come from the toilet, or you have touched women, and you cannot find water, then make your ablution on clean ground and wipe a part of your faces and your hands. Indeed Allah is all-excusing, all-forgiving.

# 537

Have you not regarded those who were given a share of the Book, who purchase error and desire that you \[too\] should lose the way?

# 538

But Allah knows your enemies better, and Allah suffices as guardian, and Allah suffices as helper.

# 539

Among the Jews are those who pervert words from their meanings and say, ‘We hear and disobey’ and ‘Hear without listening!’ and ‘Ra’ina,’ twisting their tongues and reviling the faith. But had they said, ‘We hear and obey’ and ‘Listen’ and ‘Unzurna,’ it would have been better for them and more upright. But Allah has cursed them for their faithlessness, so they will not believe except a few.

# 540

O you who were given the Book! Believe in what We have sent down confirming what is with you, before We blot out the faces and turn them backwards, or curse them as We cursed the People of the Sabbath, and Allah’s command is bound to be fulfilled.

# 541

Indeed Allah does not forgive that partners should be ascribed to Him, but He forgives anything besides that to whomever He wishes. Whoever ascribes partners to Allah has indeed fabricated \[a lie\] in great sinfulness.

# 542

Have you not regarded those who style themselves as pure? Indeed, it is Allah who purifies whomever He wishes, and they will not be wronged \[so much as\] a single date-thread.

# 543

Look, how they fabricate lies against Allah! That suffices for a flagrant sin.

# 544

Have you not regarded those who were given a share of the Book, believing in idols and fake deities and saying of the pagans: ‘These are better guided on the way than the faithful’?

# 545

They are the ones whom Allah has cursed, and whomever Allah curses, you will never find any helper for him.

# 546

Do they have a share in sovereignty? If so, they will not give those people \[so much as\] a speck on a date-stone!

# 547

Do they envy those people for what Allah has given them out of His bounty? We have certainly given the progeny of Abraham the Book and wisdom, and We have given them a great sovereignty.

# 548

Of them are some who believe in him, and of them are some who deter \[others\] from him; and hell suffices for a blaze!

# 549

Indeed We shall soon make those who deny Our signs enter a Fire: as often as their skins become scorched, We shall replace them with other skins, so that they may taste the punishment. Indeed Allah is all-mighty, all-wise.

# 550

As for those who have faith and do righteous deeds, We shall admit them into gardens with streams running in them, to remain in them forever. In it, there will be chaste mates for them, and We shall admit them into a deep shade.

# 551

Indeed Allah commands you to deliver the trusts to their \[rightful\] owners, and to judge with fairness when you judge between people. Excellent indeed is what Allah advises you. Indeed Allah is all-hearing, all-seeing.

# 552

O you who have faith! Obey Allah and obey the Apostle and those vested with authority among you. And if you dispute concerning anything, refer it to Allah and the Apostle, if you have faith in Allah and the Last Day. That is better and more favourable in outcome.

# 553

Have you not regarded those who claim that they believe in what has been sent down to you and what was sent down before you? They desire to seek the judgment of fake deities, though they were commanded to reject them, and Satan desires to lead them astray into far error.

# 554

When they are told, ‘Come to what Allah has sent down and \[come\] to the Apostle,’ you see the hypocrites keep away from you aversely.

# 555

But how will it be when an affliction visits them because of what their hands have sent ahead? Then they will come to you, swearing by Allah, ‘We desired nothing but to do good and to bring about comity.’

# 556

They are the ones whom Allah knows as to what is in their hearts. So let them alone, and advise them, and speak to them concerning themselves far-reaching words.

# 557

We did not send any apostle but to be obeyed by Allah’s leave. Had they, when they wronged themselves, come to you and pleaded to Allah for forgiveness, and the Apostle had pleaded for them \[to Allah\]for forgiveness, they would have surely found Allah all-clement, all-merciful.

# 558

But no, by your Lord! They will not believe until they make you a judge in their disputes, then do not find within their hearts any dissent to your verdict and submit in full submission.

# 559

Had We prescribed for them, \[commanding\]: ‘Slay \[the guilty among\] your folks or leave your habitations,’ they would not have done it except a few of them. And if they had done as they were advised, it would have been better for them and stronger in confirming \[their faith\].

# 560

Then We would surely have given them from Us a great reward,

# 561

and We would have guided them to a straight path.

# 562

Whoever obeys Allah and the Apostle—they are with those whom Allah has blessed, including the prophets and the truthful, the martyrs and the righteous, and excellent companions are they!

# 563

That is the grace of Allah, and Allah suffices as knower \[of His creatures\].

# 564

O you who have faith! Take your precautions, then go forth in companies, or go forth en masse.

# 565

Among you is indeed he who drags his feet, and should an affliction visit you, he says, ‘It was certainly Allah’s blessing that I did not accompany them!’

# 566

But should a bounty from Allah come to you, he will say—as if there were no \[tie of friendship and\] affection between you and him—‘I wish I were with them so that I had achieved a great success!’

# 567

Let those who sell the life of this world for the Hereafter fight in the way of Allah; and whoever fights in the way of Allah, and then is slain, or he subdues \[the enemy\], We shall soon give him a great reward.

# 568

Why should you not fight in the way of Allah and the oppressed men, women, and children, who say, ‘Our Lord, bring us out of this town whose people are oppressors, and appoint for us a guardian from Yourself, and appoint for us a helper from Yourself’?

# 569

Those who have faith fight in the way of Allah, and those who are faithless fight in the way of fake gods. So fight the friends of Satan; indeed the stratagems of Satan are always flimsy.

# 570

Have you not regarded those who were told, ‘Keep your hands off \[from warfare\], and maintain the prayer and give the zakat’? But when fighting was prescribed for them, behold, a part of them feared the people as if fearing Allah, or were even more afraid, and they said, ‘Our Lord! Why did You prescribe fighting for us? Why did You not respite us for a short time?!’ Say, ‘The enjoyments of this world are trifle and the Hereafter is better for the Godwary, and you will not be wronged so much as a single date-thread.

# 571

Wherever you may be death will overtake you, even if you were in fortified towers.’ If any good befalls them, they say, ‘This is from Allah;’ and when an ill befalls them, they say, ‘This is from you.’ Say, ‘All is from Allah.’ What is the matter with these people that they would not understand any matter?

# 572

Whatever good befalls you is from Allah; and whatever ill befalls you is from yourself. We sent you as an apostle to mankind, and Allah suffices as witness.

# 573

Whoever obeys the Apostle certainly obeys Allah; and as for those who turn their backs \[on you\]; We have not sent you to keep watch over them.

# 574

They profess obedience \[to you\], but when they go out from your presence, a group of them conspire overnight \[to do\] something other than what you say. But Allah records what they conspire overnight. So disregard them and put your trust in Allah, for Allah suffices as trustee.

# 575

Do they not contemplate the Quran? Had it been from \[someone\] other than Allah, they would have surely found much discrepancy in it.

# 576

When a report of safety or alarm comes to them, they immediately broadcast it; but had they referred it to the Apostle or to those vested with authority among them, those of them who investigate would have ascertained it. And were it not for Allah’s grace upon you and His mercy, you would have surely followed Satan, \[all\] except a few.

# 577

So fight in the way of Allah: you are responsible only for yourself, but urge on the faithful \[to fight\]. Maybe Allah will curb the might of the faithless, for Allah is greatest in might and severest in punishment.

# 578

Whoever intercedes for a good cause shall receive a share of it, and whoever intercedes for an evil cause shall share its burden, and Allah is prepotent over all things.

# 579

When you are greeted with a salute, greet with a better one than it, or return it; indeed Allah takes account of all things.

# 580

Allah—there is no god except Him—will surely gather you on the Day of Resurrection, in which there is no doubt; and who is more truthful in speech than Allah?

# 581

Why should you be two groups concerning the hypocrites, while Allah has made them relapse \[into unfaith\] because of their deeds? Do you desire to guide someone Allah has led astray? Whomever Allah leads astray, you will never find any way for him.

# 582

They are eager that you should disbelieve like they have disbelieved, so that you all become alike. So do not make friends \[with anyone\] from among them, until they migrate in the way of Allah. But if they turn their backs, seize them and kill them wherever you find them, and do not take from among them friends or helpers,

# 583

excepting those who join a people between whom and you there is a treaty, or such as come to you with hearts reluctant to fight you, or to fight their own people. Had Allah wished, He would have imposed them upon you, and then they would have surely fought you. So if they keep out of your way and do not fight you, and offer you peace, then Allah does not allow you any course \[of action\] against them.

# 584

You will find others desiring to be secure from you, and secure from their own people; yet whenever they are called back to polytheism, they relapse into it. So if they do not keep out of your way, nor offer you peace, nor keep their hands off \[from fighting\], then seize them and kill them wherever you confront them, and it is such against whom We have given you a clear sanction.

# 585

A believer may not kill another believer, unless it is by mistake. Anyone who kills a believer by mistake should set free a believing slave, and pay blood-money to his family, unless they remit it in charity. If he belongs to a people that are hostile to you but is a believer, then a believing slave is to be set free. And if he belongs to a people with whom you have a treaty, the blood-money is to be paid to his family and a believing slave is to be set free. He who cannot afford \[to pay the blood-money\], must fast two successive months as a penance from Allah, and Allah is all-knowing, all-wise.

# 586

Should anyone kill a believer intentionally, his requital shall be hell, to remain in it \[forever\]; Allah shall be wrathful at him and curse him and He shall prepare for him a great punishment.

# 587

O you who have faith! When you issue forth in the way of Allah, try to ascertain: do not say to someone who offers you peace, ‘You are not a believer,’ seeking the transitory wares of the life of this world. Yet with Allah are plenteous gains. You too were such earlier, but Allah did you a favour. Therefore, do ascertain. Allah is indeed well aware of what you do.

# 588

Not equal are those of the faithful who sit back—excepting those who suffer from some disability—and those who wage jihad in the way of Allah with their possession and their persons. Allah has graced those who wage jihad with their possessions and their persons by a degree over those who sit back; yet to each Allah has promised the best reward, and Allah has graced those who wage jihad over those who sit back with a great reward:

# 589

ranks from Him, forgiveness, and mercy, and Allah is all-forgiving, all-merciful.

# 590

Indeed, those whom the angels take away while they are wronging themselves, they ask, ‘What state were you in?’ They reply, ‘We were oppressed in the land.’ They say, ‘Was not Allah’s earth vast enough so that you might migrate in it?’ The refuge of such shall be hell, and it is an evil destination.

# 591

Except the oppressed among men, women and children, who have neither access to any means nor are guided to any way.

# 592

Maybe Allah will excuse them, for Allah is all-excusing, all-forgiving.

# 593

Whoever migrates in the way of Allah will find many havens and plenitude in the earth. And whoever leaves his home migrating toward Allah and His Apostle, and is then overtaken by death, his reward shall certainly fall on Allah, and Allah is all-forgiving, all-merciful.

# 594

When you journey in the land, there is no sin upon you in shortening the prayers, if you fear that the faithless may trouble you; indeed the faithless are your manifest enemies.

# 595

When you are among them, leading them in prayers, let a group of them stand with you, carrying their weapons. And when they have done the prostrations, let them withdraw to the rear, then let the other group which has not prayed come and pray with you, taking their precautions and \[bearing\] their weapons. The faithless are eager that you should be oblivious of your weapons and your baggage, so that they could assault you all at once. But there is no sin upon you, if you are troubled by rain or are sick, to set aside your weapons; but take your precautions. Indeed Allah has prepared for the faithless a humiliating punishment.

# 596

When you have finished the prayers, remember Allah, standing, sitting, and lying down, and when you feel secure, perform the \[complete\] prayers, for the prayer is indeed a timed prescription for the faithful.

# 597

Do not slacken in the pursuit of these people. If you are suffering, they are also suffering like you, but you expect from Allah what they do not expect, and Allah is all-knowing, all-wise.

# 598

Indeed We have sent down to you the Book with the truth, so that you may judge between the people by what Allah has shown you; do not be an advocate for the traitors,

# 599

and plead to Allah for forgiveness; indeed Allah is all-forgiving, all-merciful.

# 600

And do not plead for those who betray themselves; indeed Allah does not like someone who is treacherous and sinful.

# 601

They try to hide \[their real character\] from people, but they do not try to hide from Allah, though He is with them when they conspire overnight with a discourse that He does not approve of. And Allah comprehends whatever they do.

# 602

Aha! There you are, pleading for them in the life of this world! But who will plead for them with Allah on the Day of Resurrection, or will be their defender?

# 603

Whoever commits evil or wrongs himself and then pleads to Allah for forgiveness, will find Allah all-forgiving, all-merciful.

# 604

Whoever commits a sin, commits it only against himself; and Allah is all-knowing, all-wise.

# 605

But someone who commits an iniquity or sin and then accuses an innocent person of it, is indeed guilty of calumny and a flagrant sin.

# 606

Were it not for Allah’s grace and His mercy on you, a group of them were bent on leading you astray; but they do not mislead anyone except themselves, and they cannot do you any harm. Allah has sent down to you the Book and wisdom, and He has taught you what you did not know, and great is Allah’s grace upon you.

# 607

There is no good in much of their secret talks, excepting him who enjoins charity or what is right or reconciliation between people, and whoever does that, seeking Allah’s pleasure, soon We shall give him a great reward.

# 608

Whoever defies the Apostle, after the guidance has become manifest to him, and follows a way other than that of the faithful, We shall abandon him to his devices and We shall make him enter hell, and it is an evil destination.

# 609

Indeed Allah does not forgive that any partner should be ascribed to Him, but He forgives anything besides that to whomever He wishes. And whoever ascribes partners to Allah has certainly strayed into far error.

# 610

They invoke none but females besides Him, and invoke none but a froward Satan,

# 611

whom Allah has cursed, and who said, ‘I will surely take of Your servants a settled share,

# 612

and I will lead them astray and give them \[false\] hopes, and prompt them to slit the ears of cattle, and I will prompt them to alter Allah’s creation.’ Whoever takes Satan as a guardian instead of Allah has certainly incurred a manifest loss.

# 613

He makes them promises and gives them \[false\] hopes, yet Satan does not promise them anything but delusion.

# 614

The refuge of such shall be hell, and they will not find any escape from it.

# 615

But those who have faith and do righteous deeds, We will admit them into gardens with streams running in them, to remain in them forever—a true promise of Allah, and who is truer in speech than Allah?

# 616

It will be neither after your hopes nor the hopes of the People of the Book: whoever commits evil shall be requited for it, and he will not find for himself any guardian or helper besides Allah.

# 617

And whoever does righteous deeds, whether male or female, should he be faithful—such shall enter paradise and they will not be wronged \[so much as\] the speck on a date-stone.

# 618

Who has a better religion than him who submits his will to Allah, being virtuous, and follows the creed of Abraham, a Hanif? And Allah took Abraham for a dedicated friend.

# 619

To Allah belongs whatever is in the heavens and whatever is on the earth, and Allah comprehends all things.

# 620

They seek your ruling concerning women. Say, ‘Allah gives you a ruling concerning them and what is announced to you in the Book concerning girl orphans—whom you do not give what has been prescribed for them, and yet you desire to marry them—and about the weak among children: that you should maintain the orphans with justice, and whatever good you do, indeed Allah knows it well.

# 621

If a woman fears from her husband misconduct or desertion, there is no sin upon the couple if they reach a reconciliation between themselves; and reconcilement is better. The souls are prone to greed; but if you are virtuous and Godwary, Allah is indeed well aware of what you do.

# 622

You will not be able to be fair between wives, even if you are eager to do so. Yet do not turn away from one altogether, leaving her as if in a suspense. But if you are conciliatory and Godwary, Allah is indeed all-forgiving, all-merciful.

# 623

But if they separate, Allah will suffice each of them out of His bounty, and Allah is all-bounteous, all-wise.

# 624

To Allah belongs whatever is in the heavens and whatever is on the earth. We have certainly enjoined those who were given the Book before you, and you, that you should be wary of Allah. But if you are faithless, \[you should know that\] to Allah indeed belongs whatever is in the heavens and whatever is on the earth, and Allah is all-sufficient, all-laudable.

# 625

To Allah belongs whatever is in the heavens and whatever is on the earth, and Allah suffices as trustee.

# 626

If He wishes, He will take you away, O mankind, and bring others \[in your place\]; Allah has the power to do that.

# 627

Whoever desires the reward of this world, \[should know that\] with Allah is the reward of this world and the Hereafter, and Allah is all-hearing, all-seeing.

# 628

O you who have faith! Be maintainers of justice and witnesses for the sake of Allah, even if it should be against yourselves or \[your\] parents and near relatives, and whether it be \[someone\] rich or poor, for Allah has a greater right over them. So do not follow \[your\] desires, lest you should be unfair, and if you distort \[the testimony\] or disregard \[it\], Allah is indeed well aware of what you do.

# 629

O you who have faith! Have faith in Allah and His Apostle and the Book that He has sent down to His Apostle and the Book He had sent down earlier. Whoever disbelieves in Allah and His angels, His Books and His apostles and the Last Day, has certainly strayed into far error.

# 630

As for those who believe and then disbelieve, then believe \[again\] and then disbelieve and then increase in disbelief, Allah shall never forgive them, nor shall He guide them to any way.

# 631

Inform the hypocrites that there is a painful punishment for them

# 632

—those who take the faithless for allies instead of the faithful. Do they seek honour with them? \[If so,\] indeed all honour belongs to Allah.

# 633

Certainly He has sent down to you in the Book that when you hear Allah’s signs being disbelieved and derided, do not sit with them until they engage in some other discourse, or else you \[too\] will be like them. Indeed Allah will gather the hypocrites and the faithless in hell all together

# 634

—those who lie in wait for you: if there is a victory for you from Allah, they say, ‘Were we not with you?’ But if the faithless get a share \[of victory\], they say, ‘Did we not prevail upon you and defend you against the faithful?’ Allah will judge between you on the Day of Resurrection, and Allah will never provide the faithless any way \[to prevail\] over the faithful.

# 635

The hypocrites indeed seek to deceive Allah, but it is He who outwits them. When they stand up for prayer, they stand up lazily, showing off to the people and not remembering Allah except a little,

# 636

wavering in between: neither with these, nor with those. And whomever Allah leads astray, you will never find any way for him.

# 637

O you who have faith! Do not take the faithless for friends instead of the faithful. Do you wish to give Allah a clear sanction against yourselves?

# 638

Indeed the hypocrites will be in the lowest reach of the Fire, and you will never find any helper for them,

# 639

except for those who repent and reform, and hold fast to Allah and dedicate their religion \[exclusively\] to Allah. Those are with the faithful, and soon Allah will give the faithful a great reward.

# 640

Why should Allah punish you if you give thanks and be faithful? And Allah is appreciative, all-knowing.

# 641

Allah does not like the disclosure of \[anyone’s\] evil \[conduct\] in speech except by someone who has been wronged, and Allah is all-hearing, all-knowing.

# 642

Whether you disclose a good \[deed that you do\] or hide it, or excuse an evil \[deed\], Allah is indeed all-excusing, all-powerful.

# 643

Those who disbelieve in Allah and His apostles and seek to separate Allah from His apostles, and say, ‘We believe in some and disbelieve in some’ and seek to take a way in between

# 644

—it is they who are truly faithless, and We have prepared for the faithless a humiliating punishment.

# 645

But those who have faith in Allah and His apostles and make no distinction between any of them—them He will soon give their rewards, and Allah is all-forgiving, all-merciful.

# 646

The People of the Book ask you to bring down for them a Book from the sky. Certainly they asked Moses for \[something\] greater than that, for they said, ‘Show us Allah visibly,’ whereat a thunderbolt seized them for their wrongdoing. Then they took up the Calf \[for worship\], after all the manifest proofs that had come to them. Yet We excused that, and We gave Moses a manifest authority.

# 647

And We raised the Mount above them for the sake of their covenant, and We said to them, ‘Enter the gate prostrating’ and We said to them, ‘Do not violate the Sabbath,’ and We took from them a solemn covenant.

# 648

Then because of their breaking their covenant, their defiance of Allah’s signs, their killing of the prophets unjustly and for their saying, ‘Our hearts are uncircumcised’... Indeed, Allah has set a seal on them for their unfaith, so they do not have faith except a few.

# 649

And for their faithlessness, and their uttering a monstrous calumny against Mary,

# 650

and for their saying, ‘We killed the Messiah, Jesus son of Mary, the apostle of Allah’—though they did not kill him nor did they crucify him, but so it was made to appear to them. Indeed those who differ concerning him are surely in doubt about him: they do not have any knowledge of that beyond following conjectures, and certainly, they did not kill him.

# 651

Indeed, Allah raised him up toward Himself, and Allah is all-mighty, all-wise.

# 652

There is none among the People of the Book but will surely believe in him before his death; and on the Day of Resurrection, he will be a witness against them.

# 653

Due to the wrongdoing of the Jews, We prohibited them certain good things that were permitted to them \[earlier\], and for their barring many \[people\] from the way of Allah,

# 654

and for their taking usury—though they had been forbidden from it—and for eating up the wealth of the people wrongfully. And We have prepared for the faithless among them a painful punishment.

# 655

But as for those who are firmly grounded in knowledge from among them, and the faithful, they believe in what has been sent down to you, and what was sent down before you—those who maintain the prayer, give the zakat, and believe in Allah and the Last Day—them We shall give a great reward.

# 656

We have indeed revealed to you as We revealed to Noah and the prophets after him, and \[as\] We revealed to Abraham and Ishmael, Isaac, Jacob, and the Tribes, Jesus and Job, Jonah, Aaron, and Solomon—and We gave David the Psalms—

# 657

and apostles We have recounted to you earlier and apostles We have not recounted to you—and to Moses Allah spoke directly—

# 658

apostles, as bearers of good news and warners, so that mankind may not have any argument against Allah, after the \[sending of the\] apostles; and Allah is all-mighty, all-wise.

# 659

But Allah bears witness to what He has sent down to you—He sent it down with His knowledge—and the angels bear witness \[too\], and Allah quite suffices as witness.

# 660

Indeed those who are faithless and bar \[others\] from the way of Allah, have certainly strayed into far error.

# 661

Indeed those who are faithless and do wrong, Allah shall never forgive them, nor shall He guide them to any way,

# 662

except the way to hell, to remain in it forever, and that is easy for Allah.

# 663

O mankind! The Apostle has certainly brought you the truth from your Lord. So have faith! That is better for you. And if you are faithless, \[you should know that\] to Allah indeed belongs whatever is in the heavens and the earth, and Allah is all-knowing, all-wise.

# 664

O People of the Book! Do not exceed the bounds in your religion, and do not attribute anything to Allah except the truth. The Messiah, Jesus son of Mary, was only an apostle of Allah, and His Word that He cast toward Mary and a spirit from Him. So have faith in Allah and His apostles, and do not say, ‘\[God is\] a trinity.’ Relinquish \[such a creed\]! That is better for you. Allah is but the One God. He is far too immaculate to have any son. To Him belongs whatever is in the heavens and whatever is on the earth, and Allah suffices as trustee.

# 665

The Messiah would never disdain being a servant of Allah, nor would the angels brought near \[to Him\]. And whoever disdains His worship and is arrogant, He will gather them all toward Him.

# 666

As for those who have faith and do righteous deeds, He will pay them in full their rewards, and He will enhance them out of His grace. But those who are disdainful and arrogant, He will punish them with a painful punishment, and they will not find besides Allah any guardian or helper.

# 667

O mankind! Certainly, a proof has come to you from your Lord, and We have sent down to you a manifest light.

# 668

As for those who have faith in Allah, and hold fast to Him, He will admit them to His mercy and grace, and He will guide them on a straight path to Him.

# 669

They ask you for a ruling. Say, ‘Allah gives you a ruling concerning the kalalah: If a man dies and has no children \[or parents\], but has a sister, for her shall be a half of what he leaves, and he shall inherit from her if she has no children. If there be two sisters, then they shall receive two-thirds of what he leaves. But if there be \[several\] brothers and sisters, then for the male shall be the like of the share of two females. Allah explains \[the laws\] for you lest you should go astray, and Allah has knowledge of all things.’

# 670

O you who have faith! Keep your agreements. You are permitted animals of grazing livestock, except what is \[now\] announced to you, disallowing game while you are in pilgrim sanctity. Indeed Allah decrees whatever He desires.

# 671

O you who have faith! Do not violate Allah’s sacraments, neither the sacred month, nor the offering, nor the necklaces, nor those bound for the Sacred House, who seek their Lord’s grace and \[His\] pleasure. But when you emerge from pilgrim sanctity, you may hunt for game. Ill feeling for a people should not lead you, because they barred you from \[access to\] the Sacred Mosque, to transgress. Cooperate in piety and Godwariness, but do not cooperate in sin and aggression, and be wary of Allah. Indeed Allah is severe in retribution.

# 672

You are prohibited carrion, blood, the flesh of swine, and what has been offered to other than Allah, and the animal strangled or beaten to death, and that which dies by falling or is gored to death, and that which is mangled by a beast of prey—barring that which you may purify —and what is sacrificed on stone altars \[to idols\], and that you should divide by raffling with arrows. All that is transgression. Today the faithless have despaired of your religion. So do not fear them, but fear Me. Today I have perfected your religion for you, and I have completed My blessing upon you, and I have approved Islam as your religion. But should anyone be compelled by hunger, without inclining to sin, then Allah is indeed all-forgiving, all-merciful.

# 673

They ask you as to what is lawful to them. Say, ‘All the good things are lawful to you.’ As for what you have taught hunting dogs \[to catch\], teaching them out of what Allah has taught you, eat of what they catch for you and mention Allah’s Name over it, and be wary of Allah. Indeed Allah is swift at reckoning.

# 674

Today all the good things have been made lawful to you—the food of those who were given the Book is lawful to you, and your food is lawful to them—and the chaste ones from among faithful women, and chaste women of those who were given the Book before you, when you have given them their dowries, in wedlock, not in license, nor taking paramours. Should anyone renounce his faith, his work shall fail and he will be among the losers in the Hereafter.

# 675

O you who have faith! When you stand up for prayer, wash your faces and your hands up to the elbows, and wipe a part of your heads and your feet, up to the ankles. If you are junub, purify yourselves. But if you are sick, or on a journey, or any of you has come from the toilet, or you have touched women, and you cannot find water, then make tayammum with clean ground and wipe a part of your faces and your hands with it. Allah does not desire to put you to hardship, but He desires to purify you, and to complete His blessing upon you so that you may give thanks.

# 676

Remember Allah’s blessing upon you and His covenant with which He has bound you when you said, ‘We hear and obey.’ And be wary of Allah. Indeed Allah knows best what is in the breasts.

# 677

O you who have faith! Be maintainers, as witnesses for the sake of Allah, of justice, and ill feeling for a people should never lead you to be unfair. Be fair; that is nearer to Godwariness, and be wary of Allah. Allah is indeed well aware of what you do.

# 678

Allah has promised those who have faith and do righteous deeds forgiveness and a great reward.

# 679

As for those who are faithless and deny Our signs, they shall be the inmates of hell.

# 680

O you who have faith! Remember Allah’s blessing upon you when a people set out to extend their hands against you, but He withheld their hands from you, and be wary of Allah, and in Allah let all the faithful put their trust.

# 681

Certainly Allah took a pledge from the Children of Israel, and We raised among them twelve chiefs. And Allah said, ‘I am with you! Surely, if you maintain the prayer and give the zakat and have faith in My apostles and support them and lend Allah a good loan, I will surely absolve you of your misdeeds, and I will surely admit you into gardens with streams running in them. But whoever of you disbelieves after that has certainly strayed from the right way.’

# 682

Then, because of their breaking their covenant We cursed them and made their hearts hard: they pervert words from their meanings, and have forgotten a part of what they were reminded. You will not cease to learn of some of their treachery, excepting a few of them. Yet excuse them and forbear. Indeed Allah loves the virtuous.

# 683

Also from those who say, ‘We are Christians,’ We took their pledge; but they forgot a part of what they were reminded. So We stirred up enmity and hatred among them until the Day of Resurrection, and soon Allah will inform them concerning what they had been doing.

# 684

O People of the Book! Certainly Our Apostle has come to you, clarifying for you much of what you used to hide of the Book, and excusing many \[an offense of yours\]. Certainly, there has come to you a light from Allah, and a manifest Book.

# 685

With it Allah guides those who follow \[the course of\] His pleasure to the ways of peace, and brings them out from darkness into light by His will, and guides them to a straight path.

# 686

They are certainly faithless who say, ‘Allah is the Messiah, son of Mary.’ Say, ‘Who can avail anything against Allah should He wish to destroy the Messiah, son of Mary, and his mother, and everyone upon the earth?’ To Allah belongs the kingdom of the heavens and the earth, and whatever is between them. He creates whatever He wishes, and Allah has power over all things.

# 687

The Jews and the Christians say, ‘We are Allah’s children and His beloved ones.’ Say, ‘Then why does He punish you for your sins?’ No, you are humans from among His creatures. He forgives whomever He wishes, and punishes whomever He wishes, and to Allah belongs the kingdom of the heavens and the earth, and whatever is between them, and toward Him is the return.

# 688

O People of the Book! Certainly Our Apostle has come to you, clarifying \[the Divine teachings\] for you after a gap in \[the appearance of\] the apostles, lest you should say, ‘There did not come to us any bearer of good news nor any warner.’ Certainly, there has come to you a bearer of good news and a warner. And Allah has power over all things.

# 689

When Moses said to his people, ‘O my people, remember Allah’s blessing upon you when He appointed prophets among you, and made you kings, and gave you what none of the nations were given.

# 690

O my people, enter the Holy Land which Allah has ordained for you, and do not turn your backs, or you will become losers.’

# 691

They said, ‘O Moses, there are a tyrannical people in it. We will not enter it until they leave it. But once they leave it, we will go in.’

# 692

Said two men from among those who were Godfearing and whom Allah had blessed: ‘Go at them by the gate! For once, you have entered it, you will be victors. Put your trust in Allah, should you be faithful.’

# 693

They said, ‘O Moses, we will never enter it so long as they remain in it. Go ahead, you and your Lord, and fight! We will be sitting right here.’

# 694

He said, ‘My Lord! I have no power over \[anyone\] except myself and my brother, so part us from the transgressing lot.’

# 695

He said, ‘It shall be forbidden them for forty years: they shall wander about in the earth. So do not grieve for the transgressing lot.’

# 696

Relate to them truly the account of Adam’s two sons. When the two of them offered an offering, it was accepted from one of them and not accepted from the other. \[One of them\] said, ‘Surely I will kill you.’ \[The other one\] said, ‘Allah accepts only from the Godwary.

# 697

Even if you extend your hand toward me to kill me, I will not extend my hand toward you to kill you. Indeed, I fear Allah, the Lord of all the worlds.

# 698

I desire that you earn \[the burden of\] my sin and your sin, to become one of the inmates of the Fire, and such is the requital of the wrongdoers.’

# 699

So his soul prompted him to kill his brother, and he killed him, and thus became one of the losers.

# 700

Then Allah sent a crow, exploring in the ground, to show him how to bury the corpse of his brother. He said, ‘Woe to me! Am I unable to be \[even\] like this crow and bury my brother’s corpse?’ Thus he became regretful.

# 701

That is why We decreed for the Children of Israel that whoever kills a soul, without \[its being guilty of\] manslaughter or corruption on the earth, is as though he had killed all mankind, and whoever saves a life is as though he had saved all mankind. Our apostles certainly brought them manifest signs, yet even after that, many of them commit excesses on the earth.

# 702

Indeed the requital of those who wage war against Allah and His Apostle, and try to cause corruption on the earth, is that they shall be slain or crucified, or shall have their hands and feet cut off from opposite sides, or be banished from the land. That is a disgrace for them in this world, and in the Hereafter, there is a great punishment for them,

# 703

excepting those who repent before you capture them, and know that Allah is all-forgiving, all-merciful.

# 704

O you who have faith! Be wary of Allah, and seek the means of recourse to Him, and wage jihad in His way, so that you may be felicitous.

# 705

Indeed if the faithless possessed all that is on the earth, and as much of it besides, to redeem themselves with it from the punishment of the Day of Resurrection, it shall not be accepted from them, and there is a painful punishment for them.

# 706

They would long to leave the Fire, but they shall never leave it, and there is a lasting punishment for them.

# 707

As for the thief, man or woman, cut off their hands as a requital for what they have earned. \[That is\] an exemplary punishment from Allah, and Allah is all-mighty, all-wise.

# 708

But whoever repents after his wrongdoing, and reforms, then Allah shall accept his repentance. Indeed Allah is all-forgiving, all-merciful.

# 709

Do you not know that to Allah belongs the kingdom of the heavens and the earth? He punishes whomever He wishes, and forgives whomever He wishes, and Allah has power over all things.

# 710

O Apostle! Do not grieve for those who are active in \[promoting\] unfaith, such as those who say, ‘We believe’ with their mouths, but whose hearts have no faith, and the Jews who eavesdrop with the aim of \[telling\] lies \[against you\] and eavesdrop for other people who do not come to you. They pervert words from their meanings, \[and\] say, ‘If you are given this, take it, but if you are not given this, beware!’ Yet whomever Allah wishes to mislead, you cannot avail him anything against Allah. They are the ones whose hearts Allah did not desire to purify. For them is disgrace in this world, and there is a great punishment for them in the Hereafter.

# 711

Eavesdroppers with the aim of \[telling\] lies, eaters of the unlawful—if they come to you, judge between them, or disregard them. If you disregard them, they will not harm you in any way. But if you judge, judge between them with justice. Indeed Allah loves the just.

# 712

And how should they make you a judge, while with them is the Torah, in which is Allah’s judgement? Yet in spite of that, they turn their backs \[on Him\] and they are not believers.

# 713

We sent down the Torah containing guidance and light. The prophets, who had submitted, judged by it for the Jews, and so did the rabbis and the scribes, as they were charged to preserve the Book of Allah and were witnesses to it. So do not fear the people, but fear Me, and do not sell My signs for a paltry gain. Those who do not judge by what Allah has sent down—it is they who are the faithless.

# 714

In it We prescribed for them: a life for a life, an eye for an eye, a nose for a nose, and an ear for an ear, a tooth for a tooth, and retaliation for wounds. Yet whoever remits it out of charity, that shall be an atonement for him. Those who do not judge by what Allah has sent down—it is they who are the wrongdoers.

# 715

We followed them with Jesus son of Mary, to confirm that which was before him of the Torah, and We gave him the Evangel containing guidance and light, confirming what was before it of the Torah, and as guidance and advice for the Godwary.

# 716

Let the people of the Evangel judge by what Allah has sent down in it. Those who do not judge by what Allah has sent down—it is they who are the transgressors.

# 717

We have sent down to you the Book with the truth, confirming what was before it of the Book and as a guardian over it. So judge between them by what Allah has sent down, and do not follow their desires against the truth that has come to you. For each \[community\] among you We had appointed a code \[of law\] and a path, and had Allah wished He would have made you one community, but \[His purposes required\] that He should test you in respect to what He has given you. So take the lead in all good works. To Allah shall be the return of you all, whereat He will inform you concerning that about which you used to differ.

# 718

Judge between them by what Allah has sent down, and do not follow their desires. Beware of them lest they should beguile you from part of what Allah has sent down to you. But if they turn their backs \[on you\], then know that Allah desires to punish them for some of their sins, and indeed many of the people are transgressors.

# 719

Do they seek the judgement of \[pagan\] ignorance? But who is better than Allah in judgement for a people who have certainty?

# 720

O you who have faith! Do not take the Jews and the Christians for allies: they are allies of each other. Any of you who allies with them is indeed one of them. Indeed Allah does not guide the wrongdoing lot.

# 721

Yet you see those in whose hearts is a sickness rushing to them, saying, ‘We fear lest a turn of fortune should visit us.’ Maybe Allah will bring about a victory, or a command from Him, and then they will be regretful for what they kept secret in their hearts,

# 722

and the faithful will say, ‘Are these the ones who swore by Allah with solemn oaths that they were with you?!’ Their works have failed, and they have become losers.

# 723

O you who have faith! Should any of you desert his religion, Allah will soon bring a people whom He loves and who love Him, \[who will be\] humble towards the faithful, stern towards the faithless, waging jihad in the way of Allah, not fearing the blame of any blamer. That is Allah’s grace, which He grants to whomever He wishes, and Allah is all-bounteous, all-knowing.

# 724

Your guardian is only Allah, His Apostle, and the faithful who maintain the prayer and give the zakat while bowing down.

# 725

Whoever takes for his guardians Allah, His Apostle and the faithful \[should know that\] the confederates of Allah are indeed the victorious.

# 726

O you who have faith! Do not take those who take your religion in derision and play, from among those who were given the Book before you, and the infidels, as friends, and be wary of Allah, should you be faithful.

# 727

When you call to prayer, they take it in derision and play. That is because they are a people who do not exercise their reason.

# 728

Say, ‘O People of the Book! Are you vindictive toward us for any reason except that we have faith in Allah and in what has been sent down to us, and in what was sent down before, and that most of you are transgressors?’

# 729

Say, ‘Shall I inform you concerning something worse than that as a requital from Allah? Those whom Allah has cursed and with whom He is wrathful, and turned some of whom into apes and swine, and worshippers of fake deities! Such are in a worse situation and more astray from the right way.’

# 730

When they come to you, they say, ‘We believe.’ Certainly, they enter with disbelief and leave with it, and Allah knows best as to what they have been concealing.

# 731

You see many of them actively engaged in sin and aggression, and consuming illicit gains. Surely, evil is what they have been doing.

# 732

Why do not the rabbis and the scribes forbid them from sinful speech and consuming illicit gains? Surely, evil is what they have been working.

# 733

The Jews say, ‘Allah’s hand is tied up.’ Tied up be their hands, and cursed be they for what they say! No, His hands are wide open: He bestows as He wishes. Surely many of them will be increased in rebellion and unfaith by what has been sent to you from your Lord, and We have cast enmity and hatred amongst them until the Day of Resurrection. Every time they ignite the flames of war, Allah puts them out. They seek to cause corruption on the earth, and Allah does not like the agents of corruption.

# 734

Had the People of the Book believed and been Godwary, We would surely have absolved them of their misdeeds and admitted them into gardens of bliss.

# 735

Had they observed the Torah and the Evangel, and what was sent down to them from their Lord, they would surely have drawn nourishment from above them and from beneath their feet. There is an upright group among them, but evil is what many of them do.

# 736

O Apostle! Communicate that which has been sent down to you from your Lord, and if you do not, you will not have communicated His message, and Allah shall protect you from the people. Indeed Allah does not guide the faithless lot.

# 737

Say, ‘O People of the Book! You do not stand on anything until you observe the Torah and the Evangel and what was sent down to you from your Lord.’ Surely many of them will be increased in rebellion and unfaith by what has been sent down to you from your Lord. So do not grieve for the faithless lot.

# 738

Indeed the faithful, the Jews, the Sabaeans, and the Christians—those who have faith in Allah and the Last Day and act righteously—they will have no fear, nor will they grieve.

# 739

Certainly We took a pledge from the Children of Israel, and We sent apostles to them. Whenever an apostle brought them that which was not to their liking, they would impugn a part of them, and a part they would slay.

# 740

They supposed there would be no testing, so they became blind and deaf. Thereafter Allah accepted their repentance, yet \[again\] many of them became blind and deaf, and Allah watches what they do.

# 741

They are certainly faithless who say, ‘Allah is the Messiah, son of Mary.’ But the Messiah had said, ‘O Children of Israel! Worship Allah, my Lord, and your Lord. Indeed whoever ascribes partners to Allah, Allah shall forbid him \[entry into\] paradise, and his refuge shall be the Fire, and the wrongdoers will not have any helpers.’

# 742

They are certainly faithless who say, ‘Allah is the third \[person\] of a trinity,’ while there is no god except the One God. If they do not relinquish what they say, there shall befall the faithless among them a painful punishment.

# 743

Will they not repent to Allah and plead to Him for forgiveness? Yet Allah is all-forgiving, all-merciful.

# 744

The Messiah, son of Mary, is but an apostle. Certainly, \[other\] apostles have passed before him, and his mother was a truthful one. Both of them would eat food. Look how We clarify the signs for them, and yet, look, how they go astray!

# 745

Say, ‘Do you worship, besides Allah, what has no power to bring you any benefit or harm, while Allah—He is the All-hearing, the All-knowing?!’

# 746

Say, ‘O People of the Book! Do not unduly exceed the bounds in your religion and do not follow the fancies of a people who went astray in the past, and led many astray, and \[themselves\] strayed from the right path.’

# 747

The faithless among the Children of Israel were cursed on the tongue of David and Jesus son of Mary. That, because they would disobey and they used to commit transgression.

# 748

They would not forbid one another from the wrongs that they committed. Surely, evil is what they had been doing.

# 749

You see many of them fraternizing with the faithless. Surely evil is what they have sent ahead for their souls, as Allah is displeased with them and they shall remain in punishment \[forever\].

# 750

Had they believed in Allah and the Prophet and what has been sent down to him, they would not have taken them for allies. But most of them are transgressors.

# 751

Surely You will find the most hostile of all people towards the faithful to be the Jews and the polytheists, and surely you will find the nearest of them in affection to the faithful to be those who say ‘We are Christians.’ That is because there are priests and monks among them, and because they are not arrogant.

# 752

When they hear what has been revealed to the Apostle, you see their eyes fill with tears because of the truth that they recognize. They say, ‘Our Lord, we believe; so write us down among the witnesses.

# 753

Why should we not believe in Allah and the truth that has come to us, eager as we are that our Lord should admit us among the righteous people?’

# 754

So, for what they said, Allah requited them with gardens with streams running in them, to remain in them \[forever\], and that is the reward of the virtuous.

# 755

But those who are faithless and deny Our signs—they shall be the inmates of hell.

# 756

O you who have faith! Do not prohibit the good things that Allah has made lawful to you, and do not transgress. Indeed Allah does not like the transgressors.

# 757

Eat the lawful and good things Allah has provided you, and be wary of Allah in whom you have faith.

# 758

Allah shall not take you to task for what is frivolous in your oaths; but He shall take you to task for what you pledge in earnest. The atonement for it is to feed ten needy persons with the average food you give to your families, or their clothing, or the freeing of a slave. He who cannot afford \[any of these\] shall fast for three days. That is the atonement for your oaths when you vow. But keep your oaths. Thus does Allah clarify His signs for you so that you may give thanks.

# 759

O you who have faith! Indeed wine, gambling, idols, and the divining arrows are abominations of Satan’s doing, so avoid them, so that you may be felicitous.

# 760

Indeed Satan seeks to cast enmity and hatred among you through wine and gambling, and to hinder you from the remembrance of Allah and from prayer. Will you, then, relinquish?

# 761

And obey Allah and obey the Apostle, and beware; but if you turn your backs, then know that Our Apostle’s duty is only to communicate in clear terms.

# 762

There will be no sin upon those who have faith and do righteous deeds in regard to what they have eaten \[in the past\] so long as they are Godwary and faithful and do righteous deeds, and are further Godwary and faithful, and are further Godwary and virtuous. And Allah loves the virtuous.

# 763

O you who have faith! Allah will surely test you with some of the game within the reach of your hands and spears, so that Allah may know those who fear Him in secret. So whoever transgresses after that, there is a painful punishment for him.

# 764

O you who have faith! Do not kill any game when you are in pilgrim sanctity. Should any of you kill it intentionally, its atonement, the counterpart from cattle of what he has killed, as judged by two fair men among you, will be an offering brought to the Ka‘bah, or an atonement by feeding needy persons, or its equivalent in fasting, that he may taste the untoward consequences of his conduct. Allah has excused what is already past; but should anyone resume, Allah shall take vengeance on him, for Allah is all-mighty, avenger.

# 765

You are permitted the game of the sea and its food, a provision for you and for the caravans, but you are forbidden the game of the land so long as you remain in pilgrim sanctity, and be wary of Allah toward whom you will be gathered.

# 766

Allah has made the Ka‘bah, the Sacred House, a \[means of\] sustentation for mankind, and \[also\] the sacred month, the offering and the garlands, so that you may know that Allah knows whatever there is in the heavens and whatever there is in the earth, and that Allah has knowledge of all things.

# 767

Know that Allah is severe in retribution, and that Allah is all-forgiving, all-merciful.

# 768

The Apostle’s duty is only to communicate and Allah knows whatever you disclose and whatever you conceal.

# 769

Say, ‘The good and the bad are not equal, though the abundance of the bad should amaze you.’ So be wary of Allah, O you who possess intellect, so that you may be felicitous!

# 770

O you who have faith! Do not ask about things, which, if they are disclosed to you, will upset you. Yet if you ask about them while the Quran is being sent down, they shall be disclosed to you. Allah has excused it, and Allah is all-forgiving, all-forbearing.

# 771

Certainly some people asked about them before you and then came to disbelieve in them.

# 772

Allah has not prescribed any such thing as Bahirah, Sa’ibah, Waseelah, or Haam; but those who are faithless fabricate lies against Allah, and most of them do not exercise their reason.

# 773

When they are told, ‘Come to what Allah has sent down and \[come\] to the Apostle,’ they say, ‘Sufficient for us is what we have found our fathers following.’ What, even if their fathers did not know anything and were not guided?!

# 774

O you who have faith! Take care of your own souls. He who strays cannot hurt you if you are guided. To Allah will be the return of you all, whereat He will inform you concerning what you used to do.

# 775

O you who have faith! The witness between you, when death approaches any of you, while making a bequest, shall be two fair men from among yourselves—or two from among others, if you are journeying in the land and the affliction of death visits you. You shall detain the two of them after the prayer, and, if you have any doubt, they shall vow by Allah, ‘We will not sell it for any gain, even if it were a relative, nor will we conceal the testimony of Allah, for then we would indeed be among the sinners.’

# 776

But if it is found that both of them were guilty of a sin, then two others shall stand up in their place from among those nearest in kinship to the claimants and swear by Allah: ‘Our testimony is surely truer than their testimony, and we have not transgressed, for then we would indeed be among the wrongdoers.’

# 777

That makes it likelier that they give the testimony in its genuine form, or fear that other oaths will be taken after their oaths. Be wary of Allah and listen, and Allah does not guide the transgressing lot.

# 778

The day Allah will gather the apostles and say, ‘What was the response to you?’ They will say, ‘We have no knowledge. Indeed You are knower of all that is Unseen.’

# 779

When Allah will say, O Jesus son of Mary, remember My blessing upon you and upon your mother, when I strengthened you with the Holy Spirit, so you would speak to the people in the cradle and in adulthood, and when I taught you the Book and wisdom, the Torah and the Evangel, and when you would create from clay the form of a bird, with My leave, and you would breathe into it and it would become a bird, with My leave; and you would heal the blind and the leper, with My leave, and you would raise the dead, with My leave; and when I held off \[the evil of\] the Children of Israel from you when you brought them manifest proofs, whereat the faithless among them said, ‘This is nothing but plain magic.’

# 780

And when I inspired the Disciples, \[saying\], ‘Have faith in Me and My apostle,’ they said, ‘We have faith. Bear witness that we are Muslims.’

# 781

When the Disciples said, ‘O Jesus son of Mary! Can your Lord send down to us a table from the sky?’ Said he, ‘Be wary of Allah, should you be faithful.’

# 782

They said, ‘We desire to eat from it, and our hearts will be at rest: we shall know that you have told us the truth, and we shall be among the witnesses to it.’

# 783

Said Jesus son of Mary, ‘O Allah! Our Lord! Send down to us a table from the sky, to be a festival for us, for the first ones and the last ones among us and as a sign from You, and provide for us; for You are the best of providers.’

# 784

Allah said, ‘I will indeed send it down to you. But should any of you disbelieve after this, I will indeed punish him with a punishment such as I do not punish anyone in all creation.’

# 785

And when Allah will say, ‘O Jesus son of Mary! Was it you who said to the people, ‘‘Take me and my mother for gods besides Allah’’?’ He will say, ‘Immaculate are You! It does not behoove me to say what I have no right to \[say\]. Had I said it, You would certainly have known it: You know whatever is in my self, and I do not know what is in Your Self. Indeed, You are knower of all that is Unseen.

# 786

I did not say to them \[anything\] except what You had commanded me \[to say\]: ‘‘Worship Allah, my Lord and your Lord.’’ And I was a witness to them so long as I was among them. But when You had taken me away, You Yourself were watchful over them, and You are witness to all things.

# 787

If You punish them, they are indeed Your creatures; but if You forgive them, You are indeed the All-mighty, the All-wise.’

# 788

Allah will say, ‘This day truthfulness shall benefit the truthful. For them there will be gardens with streams running in them, to remain in them forever. Allah is pleased with them and they are pleased with Him. That is the great success.’

# 789

To Allah belongs the kingdom of the heavens and the earth and whatever there is in them, and He has power over all things.

# 790

All praise belongs to Allah who created the heavens and the earth and made the darkness and the light. Yet the faithless equate \[others\] with their Lord.

# 791

It is He who created you from clay, then ordained the term \[of your life\]—the specified term is with Him—and yet you are in doubt.

# 792

He is Allah in the heavens and on the earth: He knows your secret and your overt \[matters\], and He knows what you earn.

# 793

There did not come to them any sign from among the signs of their Lord, but that they used to disregard it.

# 794

They have certainly denied the truth when it came to them, but soon there will come to them the news of what they have been deriding.

# 795

Have they not regarded how many a generation We have destroyed before them whom We had granted power in the land in respects that We did not grant you, and We sent abundant rains for them from the sky and made streams run for them? Then We destroyed them for their sins, and brought forth another generation after them.

# 796

Had We sent down to you a Book on paper so they could touch it with their \[own\] hands, \[still\] the faithless would have said, ‘This is nothing but plain magic.’

# 797

They say, ‘Why has not an angel been sent down to him?’ Were We to send down an angel, the matter would surely be decided, and then they would not be granted any respite.

# 798

Had We made him an angel, We would have surely made him a man, and We would have surely confounded them just as they confound \[the truth now\].

# 799

Apostles were certainly derided before you. Then those who ridiculed them were besieged by what they used to deride.

# 800

Say, ‘Travel over the land, and then observe how was the fate of the deniers.’

# 801

Say, ‘To whom belongs whatever is in the heavens and the earth?’ Say, ‘To Allah. He has made mercy incumbent upon Himself. He will surely gather you on the Day of Resurrection, in which there is no doubt. Those who have ruined their souls will not have faith.’

# 802

To Him belongs whatever abides in the night and the day, and He is the All-hearing, the All-knowing.

# 803

Say, ‘Shall I take for guardian \[anyone\] other than Allah, the originator of the heavens and the earth, who feeds and is not fed?’ Say, ‘I have been commanded to be the first of those who submit \[to Allah\], and \[told,\] “Never be one of the polytheists.” ’

# 804

Say, ‘Indeed, should I disobey my Lord, I fear the punishment of a tremendous day.’

# 805

Whoever is spared of it on that day, He has certainly been merciful to him, and that is manifest success.

# 806

Should Allah visit you with some distress there is no one to remove it except Him; and should He bring you some good, then He has power over all things.

# 807

And He is the All-dominant over His servants, and He is the All-wise, the All-aware.

# 808

Say, ‘What thing is greatest as witness?’ Say, ‘Allah! \[He is\] witness between me and you, and this Quran has been revealed to me that I may warn thereby you and whomever it may reach.’ ‘Do you indeed bear witness that there are other gods besides Allah?’ Say, ‘I do not bear witness \[to any such thing\].’ Say, ‘Indeed He is the One God, and I indeed disown what you associate \[with Him\].’

# 809

Those whom We have given the Book recognize him just as they recognize their sons. Those who have ruined their souls will not have faith.

# 810

Who is a greater wrongdoer than him who fabricates a lie against Allah, or denies His signs? Indeed the wrongdoers will not be felicitous.

# 811

On the day when We gather them all together, We shall say to those who ascribed partners \[to Allah\] ‘Where are your partners that you used to claim?’

# 812

Then their only excuse will be to say, ‘By Allah, our Lord, we were not polytheists.’

# 813

Look, how they forswear themselves, and what they used to fabricate has forsaken them!

# 814

There are some of them who prick up their ears at you, but We have cast veils on their hearts lest they should understand it, and a deafness into their ears; and though they should see every sign, they will not believe in it. When they come to you, to dispute with you, the faithless say, ‘These are nothing but myths of the ancients.’

# 815

They dissuade \[others\] from \[following\] him, and \[themselves\] avoid him; yet they destroy no one except themselves, but they are not aware.

# 816

Were you to see when they are brought to a halt by the Fire, whereupon they will say, ‘If only we were sent back \[into the world\]! Then we will not deny the signs of our Lord, and we will be among the faithful!’

# 817

Indeed, what they used to hide before has now become evident to them. But were they to be sent back they would revert to what they were forbidden, and they are indeed liars.

# 818

They say, ‘There is nothing but our life of this world, and we shall not be resurrected.’

# 819

Were you to see when they are brought to a halt before their Lord. He will say, ‘Is this not a fact?’ They will say, ‘Yes, by our Lord!’ He will say, ‘So taste the punishment because of what you used to deny.’

# 820

They are certainly losers who deny the encounter with Allah. When the Hour overtakes them suddenly, they will say, ‘Alas for us, for what we neglected in it!’ And they will bear their burdens on their backs. Look! Evil is what they bear!

# 821

The life of the world is nothing but play and diversion, and the abode of the Hereafter is surely better for those who are Godwary. Do you not exercise your reason?

# 822

We certainly know that what they say grieves you. Yet it is not you that they deny, but it is Allah’s signs that the wrongdoers impugn.

# 823

Apostles were certainly denied before you, yet they patiently bore being denied and tormented until Our help came to them. Nothing can change the words of Allah, and there have certainly come to you some of the accounts of the apostles.

# 824

And should their aversion be hard on you, find, if you can, a tunnel into the ground, or a ladder into sky, that you may bring them a sign. Had Allah wished, He would have brought them together on guidance. So do not be one of the ignorant.

# 825

Only those who listen will respond \[to you\]. As for the dead, Allah will resurrect them, then they will be brought back to Him.

# 826

They say, ‘Why has not a sign been sent down to him from his Lord?’ Say, ‘Allah is indeed able to send down a sign,’ but most of them do not know.

# 827

There is no animal on land, nor a bird that flies with its wings, but they are communities like yourselves. We have not omitted anything from the Book. Then they will be mustered toward their Lord.

# 828

Those who deny Our signs are deaf and dumb, in a manifold darkness. Allah leads astray whomever He wishes, and whomever He wishes He puts him on a straight path.

# 829

Say, ‘Tell me, should Allah’s punishment overtake you, or should the Hour overtake you, will you supplicate anyone other than Allah, should you be truthful?

# 830

No, Him you will supplicate, and He will remove that for which you supplicated Him, if He wishes, and you will forget what you ascribe \[to Him\] as \[His\] partners.’

# 831

We have certainly sent \[apostles\] to nations before you, then We seized them with stress and distress so that they might entreat \[Us\].

# 832

Why did they not entreat when Our punishment overtook them! But their hearts had hardened, and Satan had made what they had been doing seem decorous to them.

# 833

So when they forgot what they had been admonished of, We opened for them the gates of all \[good\] things. When they became proud of what they were given, We seized them suddenly, whereat, behold, they were despondent.

# 834

Thus the wrongdoing lot were rooted out, and all praise belongs to Allah, the Lord of all the worlds.

# 835

Say, ‘Tell me, should Allah take away your hearing and your sight and set a seal on your hearts, which god other than Allah can bring it \[back\] to you?’ Look, how We paraphrase the signs variously; nevertheless they turn away.

# 836

Say, ‘Tell me, should Allah’s punishment overtake you suddenly or visibly, will anyone be destroyed except the wrongdoing lot?’

# 837

We do not send the apostles except as bearers of good news and warners. As for those who are faithful and righteous, they will have no fear, nor will they grieve.

# 838

But as for those who deny Our signs, the punishment shall befall them because of the transgressions they used to commit.

# 839

Say, ‘I do not say to you that I possess the treasuries of Allah, nor do I know the Unseen, nor do I say to you that I am an angel. I follow only what is revealed to me.’ Say, ‘Are the blind one and the seer equal? So do you not reflect?’

# 840

And warn by its means those who fear being mustered toward their Lord, besides whom they shall have neither any guardian nor any intercessor, so that they may be Godwary.

# 841

Do not drive away those who supplicate their Lord morning and evening desiring His face. Neither are you accountable for them in any way, nor are they accountable for you in any way, so that you may drive them away and thus become one of the wrongdoers.

# 842

Thus do We test them by means of one another so that they should say, ‘Are these the ones whom Allah has favoured from among us?!’ Does not Allah know best the grateful?!

# 843

When those who have faith in Our signs come to you, say, ‘Peace to you! Your Lord has made mercy incumbent upon Himself: whoever of you commits an evil \[deed\] out of ignorance and then repents after that and reforms, then He is indeed all-forgiving, all-merciful.’

# 844

Thus do We elaborate the signs, so that the way of the guilty may be exposed.

# 845

Say, ‘I have been forbidden to worship those whom you invoke besides Allah.’ Say, ‘I do not follow your desires, for then I will have gone astray, and I will not be among the \[rightly\] guided.’

# 846

Say, ‘Indeed I stand on a manifest proof from my Lord and you have denied it. What you seek to hasten is not up to me. Judgement belongs only to Allah; He expounds the truth and He is the best of judges.’

# 847

Say, ‘If what you seek to hasten were with me, the matter would surely have been decided between you and me, and Allah knows best the wrongdoers.’

# 848

With Him are the treasures of the Unseen; no one knows them except Him. He knows whatever there is in land and sea. No leaf falls without His knowing it, nor is there a grain in the darkness of the earth, nor anything fresh or withered but it is in a manifest Book.

# 849

It is He who takes your souls by night, and He knows what you do by day, then He reanimates you therein so that a specified term may be completed. Then to Him will be your return, whereat He will inform you concerning what you used to do.

# 850

He is the All-dominant over His servants, and He sends guards to \[protect\] you. When death approaches anyone of you, Our messengers take him away and they do not neglect \[their duty\].

# 851

Then they are returned to Allah, their real master. Look! All judgement belongs to Him, and He is the swiftest of reckoners.

# 852

Say, ‘Who delivers you from the darkness of land and sea, \[when\] You invoke Him suppliantly and secretly: ‘‘If He delivers us from this, we will surely be among the grateful’’?’

# 853

Say, ‘It is Allah who delivers you from them and from every agony, \[but\] then you ascribe partners \[to Him\].’

# 854

Say, ‘He is able to send upon you a punishment from above you or from under your feet, or confound you as \[hostile\] factions, and make you taste one another’s violence.’ Look, how We paraphrase the signs variously so that they may understand!

# 855

Your people have denied it, though it is the truth. Say, ‘It is not my business to watch over you.’

# 856

For every prophecy there is a \[preordained\] setting, and soon you will know.

# 857

When you see those who gossip impiously about Our signs, avoid them until they engage in some other discourse; but if Satan makes you forget, then, after remembering, do not sit with the wrongdoing lot.

# 858

Those who are Godwary are in no way accountable for them, but this is merely for admonition’s sake, so that they may beware.

# 859

Leave alone those who take their religion for play and diversion and whom the life of this world has deceived, and admonish with it, lest any soul should perish because of what it has earned: It shall not have any guardian besides Allah, nor any intercessor; and though it should offer every kind of ransom, it shall not be accepted from it. They are the ones who perish because of what they have earned; they shall have boiling water for drink and a painful punishment because of what they used to defy.

# 860

Say, ‘Shall we invoke besides Allah that which can neither benefit us nor harm us, and turn back on our heels after Allah has guided us, like someone seduced by the devils and bewildered on the earth, who has companions that invite him to guidance, \[saying,\] ‘‘Come to us!’’?’ Say, ‘Indeed it is the guidance of Allah which is \[true\] guidance. And we have been commanded to submit to the Lord of all the worlds,

# 861

and that ‘‘Maintain the prayer and be wary of Him, and it is He toward whom you will be gathered.’’ ’

# 862

It is He who created the heavens and the earth with reason, and the day He says \[to something\], ‘Be!’ it is. His word is the truth, and to Him belongs all sovereignty on the day when the Trumpet will be blown. Knower of the sensible and the Unseen, He is the All-wise, the All-aware.

# 863

When Abraham said to Azar, his father, ‘Do you take idols for gods? Indeed I see you and your people in manifest error.’

# 864

Thus did We show Abraham the dominions of the heavens and the earth, that he might be of those who possess certitude.

# 865

When night darkened over him, he saw a star and said, ‘This is my Lord!’ But when it set, he said, ‘I do not like those who set.’

# 866

Then, when he saw the moon rising, he said, ‘This is my Lord!’ But when it set, he said, ‘Had my Lord not guided me, I would surely have been among the astray lot.’

# 867

Then, when he saw the sun rising, he said, ‘This is my Lord! This is bigger!’ But when it set, he said, ‘O my people, indeed I disown what you take as \[His\] partners.’

# 868

‘Indeed I have turned my face toward Him who originated the heavens and the earth, as a Hanif, and I am not one of the polytheists.’

# 869

His people argued with him. He said, ‘Do you argue with me concerning Allah, while He has guided me for certain? I do not fear what you ascribe to Him as \[His\] partners, excepting anything that my Lord may wish. My Lord embraces all things in \[His\] knowledge. Will you not then take admonition?

# 870

How could I fear what you ascribe \[to Him\] as \[His\] partners, when you do not fear ascribing to Allah partners for which He has not sent down any authority to you? So \[tell me,\] which of the two sides has a greater right to safety, if you know?

# 871

Those who have faith and do not taint their faith with wrongdoing—for such there shall be safety, and they are the \[rightly\] guided.’

# 872

This was Our argument that We gave to Abraham against his people. We raise in rank whomever We wish. Indeed your Lord is all-wise, all-knowing.

# 873

And We gave him Isaac and Jacob and guided each of them. And Noah We had guided before, and from his offspring, David and Solomon, Job, Joseph, Moses and Aaron—thus do We reward the virtuous—

# 874

and Zechariah, John, Jesus and Ilyas—each of them among the righteous—

# 875

and Ishmael, Elisha, Jonah and Lot—each We graced over all the nations—

# 876

and from among their fathers, their descendants and brethren—We chose them and guided them to a straight path.

# 877

That is Allah’s guidance: with it, He guides whomever He wishes of His servants. But were they to ascribe any partners \[to Allah\], what they used to do would not avail them.

# 878

They are the ones whom We gave the Book, judgement and prophethood. So if these disbelieve in them, We have certainly entrusted them to a people who will never disbelieve in them.

# 879

They are the ones whom Allah has guided. So follow their guidance. Say, ‘I do not ask you any recompense for it. It is just an admonition for all the nations.’

# 880

They did not regard Allah with the regard due to Him when they said, ‘Allah has not sent down anything to any human.’ Say, ‘Who had sent down the Book that was brought by Moses as a light and guidance for the people, which you make into parchments that you display, while you conceal much of it, and \[by means of which\] you were taught what you did not know, \[neither\] you nor your fathers?’ Say, ‘Allah!’ Then leave them to play around in their impious gossip.

# 881

Blessed is this Book, which We have sent down, confirming what was \[revealed\] before it, so that you may warn the Mother of Cities and those around it. Those who believe in the Hereafter believe in it, and they are watchful of their prayers.

# 882

Who is a greater wrongdoer than him who fabricates a lie against Allah, or says, ‘It has been revealed to me,’ while nothing was revealed to him, and he who says, ‘I will bring the like of what Allah has sent down?’ Were you to see when the wrongdoers are in the throes of death, and the angels extend their hands \[saying\]: ‘Give up your souls! Today you shall be requited with a humiliating punishment because of what you used to attribute to Allah untruly, and for your being disdainful towards His signs.’

# 883

‘Certainly you have come to Us alone, just as We created you the first time, and left behind whatever We had bestowed on you. We do not see your intercessors with you—those whom you claimed to be \[Our\] partners in \[deciding\] you\[r\] \[fate\]. Certainly all links between you have been cut, and what you used to claim has forsaken you!’

# 884

Indeed Allah is the splitter of the grain and the pit. He brings forth the living from the dead and He brings forth the dead from the living. That is Allah! Then where do you stray?

# 885

Splitter of the dawn, He has made the night for rest, and the sun and the moon for calculation. That is the ordaining of the All-mighty, the All-knowing.

# 886

It is He who made the stars for you, so that you may be guided by them in the darkness of land and sea. We have certainly elaborated the signs for a people who have knowledge.

# 887

It is He who created you from a single soul, then there is the \[enduring\] abode and the place of temporary lodging. We have certainly elaborated the signs for a people who understand.

# 888

It is He who sends down water from the sky, and brings forth with it every kind of growing thing. Then from it We bring forth vegetation from which We produce the grain, in clusters, and from the palm-tree, from the spathes of it, low-hanging clusters \[of dates\], and gardens of grapes, olives and pomegranates, similar and dissimilar. Look at its fruit as it fructifies and ripens. Indeed, there are signs in that for a people who have faith.

# 889

They make the jinn partners of Allah, though He has created them, and carve out sons and daughters for Him, without any knowledge. Immaculate is He and exalted above what they allege \[concerning Him\]!

# 890

The originator of the heavens and the earth—how could He have a child when He has had no spouse? He created all things and He has knowledge of all things.

# 891

That is Allah, your Lord, there is no god except Him, the creator of all things; so worship Him. He watches over all things.

# 892

The sights do not apprehend Him, yet He apprehends the sights, and He is the All-attentive, the All-aware.

# 893

\[Say,\] ‘Certainly insights have come to you from your Lord. So whoever sees, it is to the benefit of his own soul, and whoever remains blind, it is to its detriment, and I am not a keeper over you.’

# 894

Thus do We paraphrase the signs variously, lest they should say, ‘You have received instruction,’ and so that We may make it clear for a people who have knowledge.

# 895

Follow that which has been revealed to you from your Lord, there is no god except Him, and turn away from the polytheists.

# 896

Had Allah wished they would not have ascribed partners \[to Him\]. We have not made you a caretaker for them, nor is it your duty to watch over them.

# 897

Do not abuse those whom they invoke besides Allah, lest they should abuse Allah out of hostility, without any knowledge. That is how to every people We have made their conduct seem decorous. Then their return will be to their Lord and He will inform them concerning what they used to do.

# 898

They swear by Allah with solemn oaths that were a sign to come to them they would surely believe in it. Say, ‘These signs are only from Allah,’ and what will bring home to you that they will not believe even if they came?

# 899

We transform their hearts and their visions as they did not believe in it the first time, and We leave them bewildered in their rebellion.

# 900

Even if We had sent down angels to them, and the dead had spoken to them, and We had gathered before them all things manifestly, they would \[still\] not believe unless Allah wished. But most of them are ignorant.

# 901

That is how for every prophet We appointed as enemy the devils from among humans and jinn, who inspire each other with flashy words, deceptively. Had your Lord wished, they would not have done it. So leave them with what they fabricate,

# 902

so that toward it may incline the hearts of those who do not believe in the Hereafter, and so that they may be pleased with it and commit what they commit.

# 903

\[Say,\] ‘Shall I seek a judge other than Allah, while it is He who has sent down to you the Book, well-elaborated?’ Those whom We have given the Book know that it has been sent down from your Lord with the truth; so do not be one of the skeptics.

# 904

The word of your Lord has been fulfilled in truth and justice. Nothing can change His words, and He is the All-hearing, the All-knowing.

# 905

If you obey most of those on the earth, they will lead you astray from the way of Allah. They follow nothing but conjectures and they do nothing but surmise.

# 906

Indeed your Lord knows best those who stray from His way; and He knows best those who are guided.

# 907

Eat from that over which Allah’s Name has been mentioned, if you are believers in His signs.

# 908

Why should you not eat that over which Allah’s Name has been mentioned, while He has already elaborated for you whatever He has forbidden you, excepting what you may be compelled to \[eat in an emergency\]? Indeed many mislead \[others\] by their fancies, without any knowledge. Indeed your Lord knows best the transgressors.

# 909

Renounce outward sins and the inward ones. Indeed those who commit sins shall be requited for what they used to commit.

# 910

Do not eat \[anything\] of that over which Allah’s Name has not been mentioned, and that is indeed transgression. Indeed the satans inspire their friends to dispute with you; and if you obey them, you will indeed be polytheists.

# 911

Is he who was lifeless, then We gave him life and provided him with a light by which he walks among the people, like one who dwells in a manifold darkness which he cannot leave? To the faithless is thus presented as decorous what they have been doing.

# 912

Thus have We installed in every town its major criminals that they may plot therein. Yet they do not plot except against their own souls, but they are not aware.

# 913

When a sign comes to them, they say, ‘We will not believe until we are given the like of what was given to Allah’s apostles.’ Allah knows best where to place His apostleship! Soon the guilty will be visited by a degradation and severe punishment from Allah because of the plots they used to devise.

# 914

Whomever Allah desires to guide, He opens his breast to Islam, and whomever He desires to lead astray, He makes his breast narrow and straitened as if he were climbing to a height. Thus does Allah lay \[spiritual\] defilement on those who do not have faith.

# 915

This is the straight path of your Lord. We have already elaborated the signs for a people who take admonition.

# 916

For them shall be the abode of peace near their Lord and He will be their guardian because of what they used to do.

# 917

On the day He will gather them all together, \[He will say\], ‘O company of jinn! You claimed many of the humans.’ Their friends from among the humans will say, ‘Our Lord, we used each other, and we completed our term which You had appointed for us.’ He will say, ‘The Fire is your abode, to remain in it \[forever\], except what Allah may wish.’ Indeed your Lord is all-wise, all-knowing.

# 918

That is how We make the wrongdoers one another’s friends because of what they used to earn.

# 919

‘O company of jinn and humans! Did there not come to you apostles from yourselves, recounting to you My signs and warning you of the encounter of this Day?’ They will say, ‘We testify against ourselves.’ The life of this world had deceived them, and they will testify against themselves that they had been faithless.

# 920

This is because your Lord would never destroy the towns unjustly while their people were unaware.

# 921

For everyone there are ranks in accordance with what they have done; and your Lord is not oblivious of what they do.

# 922

Your Lord is the All-sufficient dispenser of mercy. If He wishes, He will take you away, and make whomever He wishes succeed you, just as He produced you from the descendants of another people.

# 923

Indeed what you are promised will surely come, and you will not be able to thwart it.

# 924

Say, ‘O my people, act according to your ability; I too am acting. Soon you will know in whose favour the outcome of that abode will be. Indeed the wrongdoers will not be felicitous.’

# 925

They dedicate a portion to Allah out of what He has created of the crops and cattle, and say, ‘This is for Allah,’ so do they maintain, ‘and this is for our partners.’ But what is for their partners does not reach Allah, and what is for Allah reaches their partners. Evil is the judgement that they make.

# 926

That is how to most of the polytheists the slaying of their children is presented as decorous by those whom they ascribe as partners \[to Allah\], that they may ruin them and confound their religion for them. Had Allah wished, they would not have done it. So leave them with what they fabricate.

# 927

And they say, ‘These cattle and tillage are a taboo: none may eat them except whom we please,’ so they maintain, and there are cattle whose backs are forbidden and cattle over which they do not mention Allah’s Name, fabricating a lie against Him. Soon He will requite them for what they used to fabricate.

# 928

And they say, ‘That which is in the bellies of these cattle is exclusively for our males and forbidden to our wives. But if it be still-born, they will all share it.’ Soon He will requite them for their allegations. Indeed, He is all-wise, all-knowing.

# 929

They are certainly losers who slay their children foolishly without knowledge, and forbid what Allah has provided them, fabricating a lie against Allah. Certainly, they have gone astray and are not guided.

# 930

It is He who produces gardens trellised and without trellises, and palm-trees and crops of diverse produce, olives and pomegranates, similar and dissimilar. Eat of its fruits when it fructifies, and give its due on the day of harvest, and do not be wasteful; indeed, He does not like the wasteful.

# 931

Of the cattle \[some\] are for burden and \[some\] for slaughter. Eat of what Allah has provided you and do not follow in Satan’s footsteps; he is indeed your manifest enemy.

# 932

Eight mates: two of sheep, and two of goats. Say, ‘Is it the two males that He has forbidden or the two females, or what is contained in the wombs of the two females? Inform me with knowledge, should you be truthful.’

# 933

And two of camels and two of oxen. Say, ‘Is it the two males that He has forbidden or the two females, or what is contained in the wombs of the two females? Were you witnesses when Allah enjoined this upon you?’ So who is a greater wrongdoer than him who fabricates a lie against Allah to mislead the people without any knowledge? Indeed Allah does not guide the wrongdoing lot.

# 934

Say, ‘I do not find in what has been revealed to me that anyone be forbidden to eat anything except carrion or spilt blood, or the flesh of swine—for that is indeed unclean—or an impiety offered to other than Allah.’ But should someone be compelled, without being rebellious or aggressive, indeed your Lord is all-forgiving, all-merciful.

# 935

To the Jews We forbade every animal having an undivided hoof, and of oxen and sheep We forbade them their fat, except what is borne by their backs or the entrails, or what is attached to the bones. We requited them with that for their rebelliousness, and We indeed speak the truth.

# 936

But if they deny you, say, ‘Your Lord is dispenser of an all-embracing mercy, but His punishment will not be averted from the guilty lot.’

# 937

The polytheists will say, ‘Had Allah wished we would not have ascribed any partner \[to Him\], nor our fathers, nor would we have forbidden anything.’ Those who were before them had denied likewise until they tasted Our punishment. Say, ‘Do you have any \[revealed\] knowledge that you can produce before us? You follow nothing but conjectures, and you do nothing but surmise.’

# 938

Say, ‘To Allah belongs the conclusive argument. Had He wished, He would have surely guided you all.’

# 939

Say, ‘Bring your witnesses who may testify that Allah has forbidden this.’ So if they testify, do not testify with them, and do not follow the desires of those who deny Our signs, and those who do not believe in the Hereafter and equate \[others\] with their Lord.

# 940

Say, ‘Come, I will recount what your Lord has forbidden you. That you shall not ascribe any partners to Him, and you shall be good to the parents, you shall not kill your children due to penury—We will provide for you and for them—you shall not approach indecencies, the outward among them and the inward ones, and you shall not kill a soul \[whose life\] Allah has made inviolable, except with due cause. This is what He has enjoined upon you so that you may exercise your reason.

# 941

Do not approach the orphan’s property, except in the best \[possible\] manner, until he comes of age. And observe fully the measure and the balance with justice.’ We task no soul except according to its capacity. ‘And when you speak, be fair, even if it were a relative; and fulfill Allah’s covenant. This is what He enjoins upon you so that you may take admonition.’

# 942

‘This indeed is my straight path, so follow it, and do not follow \[other\] ways, for they will separate you from His way. This is what He enjoins upon you so that you may be Godwary.’

# 943

Then We gave Moses the Book, completing \[Our blessing\] on him who is virtuous, and as an elaboration of all things, and as a guidance and mercy, so that they may believe in the encounter with their Lord.

# 944

And this Book that We have sent down is a blessed one; so follow it, and be Godwary so that you may receive \[His\] mercy.

# 945

Lest you should say, ‘The Book was sent down only to two communities before us, and we were indeed unaware of their studies,’

# 946

or \[lest\] you should say, ‘If the Book had been sent down to us, surely we would have been better-guided than them.’ There has already come to you a manifest proof from your Lord and a guidance and mercy. So who is a greater wrongdoer than him who denies the signs of Allah, and turns away from them? Soon We shall requite those who turn away from Our signs with a terrible punishment because of what they used to evade.

# 947

Do they not consider that the angels may come to them, or your Lord may come, or some of your Lord’s signs may come? The day when some of your Lord’s signs do come, faith shall not benefit any soul that had not believed beforehand and had not earned some goodness in its faith. Say, ‘Wait! We too are waiting!’

# 948

Indeed those who split up their religion and became sects, you will not have anything to do with them. Their matter rests only with Allah; then He will inform them concerning what they used to do.

# 949

Whoever brings virtue shall receive \[a reward\] ten times its like; but whoever brings vice shall not be requited except with its like, and they will not be wronged.

# 950

Say, ‘Indeed my Lord has guided me to a straight path, the upright religion, the creed of Abraham, a Hanif, and he was not one of the polytheists.’

# 951

Say, ‘Indeed my prayer and my worship, my life and my death are for the sake of Allah, the Lord of all the worlds.

# 952

He has no partner, and I have been commanded \[to follow\] this \[creed\], and I am the first of those who submit \[to Allah\].’

# 953

Say, ‘Shall I seek a Lord other than Allah, while He is the Lord of all things?’ No soul does evil except against itself, and no bearer shall bear another’s burden; then to your Lord will be your return, whereat He will inform you concerning that about which you used to differ.

# 954

It is He who has made you successors on the earth, and raised some of you in rank above others so that He may test you in respect to what He has given you. Indeed your Lord is swift in retribution, and indeed, He is all-forgiving, all-merciful.

# 955

Alif, Lam, Mim, Suad.

# 956

\[This is\] a Book that has been sent down to you—so let there be no disquiet in your heart on its account that you may warn thereby—and as an admonition for the faithful.

# 957

Follow what has been sent down to you from your Lord, and do not follow any masters besides Him. Little is the admonition that you take!

# 958

How many a town We have destroyed! Our punishment came to it at night, or while they were taking a midday nap.

# 959

Then their cry, when Our punishment overtook them, was only that they said, ‘We have indeed been wrongdoers!’

# 960

We will surely question those to whom the apostles were sent, and We will surely question the apostles.

# 961

Then We will surely recount to them with knowledge, for We had not been absent.

# 962

The weighing \[of deeds\] on that Day is a truth. As for those whose deeds weigh heavy in the scales—it is they who are the felicitous.

# 963

As for those whose deeds weigh light in the scales—it is they who have ruined their souls, because they used to wrong Our signs.

# 964

Certainly We have established you on the earth, and made in it \[various\] means of livelihood for you. Little do you thank.

# 965

Certainly We created you, then We formed you, then We said to the angels, ‘Prostrate before Adam.’ So they \[all\] prostrated, but not Iblis: he was not among those who prostrated.

# 966

Said He, ‘What prevented you from prostrating, when I commanded you? ’‘I am better than him,’ he said. ‘You created me from fire and You created him from clay.’

# 967

‘Get down from it!’ He said. ‘It is not for you to be arrogant therein. Begone! You are indeed among the degraded ones.’

# 968

He said, ‘Respite me till the day they will be resurrected.’

# 969

Said He, ‘You are indeed among the reprieved.’

# 970

‘As You have consigned me to perversity,’ he said, ‘I will surely lie in wait for them on Your straight path.

# 971

Then I will come at them from their front and from their rear, and from their right and their left, and You will not find most of them to be grateful.’

# 972

Said He, ‘Begone hence, blameful and banished! Whoever of them follows you, I will surely fill hell with you all.’

# 973

\[Then He said to Adam,\] ‘O Adam, dwell with your mate in paradise, and eat thereof whence you wish; but do not approach this tree, lest you should be among the wrongdoers.’

# 974

Then Satan tempted them, to expose to them what was hidden from them of their nakedness, and he said, ‘Your Lord has only forbidden you from this tree lest you should become angels, or lest you become immortal.’

# 975

And he swore to them, ‘I am indeed your well-wisher.’

# 976

Thus he brought about their fall by deception. So when they tasted of the tree, their nakedness became exposed to them, and they began to stitch over themselves with the leaves of paradise. Their Lord called out to them, ‘Did I not forbid you from that tree, and tell you, ‘‘Satan is indeed your manifest enemy?’’ ’

# 977

They said, ‘Our Lord, we have wronged ourselves! If You do not forgive us and have mercy upon us, we will surely be among the losers.’

# 978

He said, ‘Get down, being enemies of one another! On the earth shall be your abode and sustenance for a time.’

# 979

He said, ‘In it you will live, and in it you will die; and from it you will be raised \[from the dead\].’

# 980

‘O Children of Adam! We have certainly sent down to you garments to cover your nakedness, and for adornment. Yet the garment of Godwariness—that is the best.’ That is \[one\] of Allah’s signs, so that they may take admonition.

# 981

‘O Children of Adam! Do not let Satan tempt you, like he expelled your parents from paradise, stripping them of their garments to expose to them their nakedness. Indeed he sees you—he and his hosts—whence you do not see them. We have indeed made the devils friends of those who have no faith.’

# 982

When they commit an indecency, they say, ‘We found our fathers practising it, and Allah has enjoined it upon us.’ Say, ‘Indeed Allah does not enjoin indecencies. Do you attribute to Allah what you do not know?’

# 983

Say, ‘My Lord has enjoined justice,’ and \[He has enjoined,\] ‘Set your heart \[on Him\] at every occasion of prayer, and invoke Him, putting your exclusive faith in Him. Even as He brought you forth in the beginning, so will you return.’

# 984

A part \[of mankind\] He has guided and a part has deserved \[to be consigned to\] error, for they took devils for guardians instead of Allah, and supposed they were guided.

# 985

O Children of Adam! Put on your adornment on every occasion of prayer, and eat and drink, but do not waste; indeed, He does not like the wasteful.

# 986

Say, ‘Who has forbidden the adornment of Allah which He has brought forth for His servants, and the good things of \[His\] provision?’ Say, ‘These are for the faithful in the life of this world, and exclusively for them on the Day of Resurrection.’ Thus do We elaborate the signs for a people who have knowledge.

# 987

Say, ‘My Lord has only forbidden indecencies, the outward among them and the inward ones, and sin and undue aggression, and that you should ascribe to Allah partners for which He has not sent down any authority, and that you should attribute to Allah what you do not know.’

# 988

There is a \[preordained\] time for every nation: when their time comes, they shall not defer it by a single hour nor shall they advance it.

# 989

O Children of Adam! If there come to you apostles from among yourselves, recounting to you My signs, then those who are Godwary and righteous will have no fear, nor will they grieve.

# 990

But those who deny Our signs and are disdainful of them, they shall be the inmates of the Fire and they shall remain in it \[forever\].

# 991

So who is a greater wrongdoer than him who fabricates a lie against Allah, or denies His signs? Their share, as decreed in the Book, shall reach them. When Our messengers come to take them away, they will say, ‘Where is that which you used to invoke besides Allah?’ They will say, ‘They have forsaken us,’ and they will testify against themselves that they were faithless.

# 992

He will say, ‘Enter the Fire, along with the nations of jinn and humans who passed before you!’ Every time that a nation enters \[hell\], it will curse its sister \[nation\]. When they all rejoin in it, the last of them will say about the first of them, ‘Our Lord, it was they who led us astray; so give them a double punishment of the Fire.’ He will say, ‘It is double for each \[of you\], but you do not know.’

# 993

And the first of them will say to the last of them, ‘You have no merit over us! So taste the punishment because of what you used to earn.’

# 994

Indeed, those who deny Our signs and are disdainful of them—the gates of the heaven will not be opened for them, nor shall they enter paradise until the camel passes through the needle’s eye, and thus do We requite the guilty.

# 995

They shall have hell for their resting place, and over them shall be sheets \[of fire\], and thus do We requite the wrongdoers.

# 996

As for those who have faith and do righteous deeds—We task no soul except according to its capacity—they shall be the inhabitants of paradise, and they shall remain in it \[forever\].

# 997

We will remove whatever rancour there is in their breasts, and streams will run for them. They will say, ‘All praise belongs to Allah, who guided us to this. We would have never been guided had not Allah guided us. Our Lord’s apostles had certainly brought the truth.’ And the call would be made to them: ‘This is paradise, which you have been given to inherit because of what you used to do!’

# 998

The inhabitants of paradise will call out to the inmates of the Fire, ‘We found what our Lord promised us to be true; did you find what your Lord promised you to be true?’ ‘Yes,’ they will say. Then a caller will announce in their midst, ‘May Allah’s curse be on the wrongdoers!’

# 999

—Those who bar \[others\] from the way of Allah, and seek to make it crooked, and disbelieve in the Hereafter.

# 1000

There will be a veil between them. And on the Elevations will be certain men who recognize each of them by their mark. They will call out to the inhabitants of paradise, ‘Peace be to you!’ (They will not have entered it, though they would be eager to do so.

# 1001

And when their look is turned toward the inmates of the Fire, they will say, ‘Our Lord, do not put us among the wrongdoing lot!’)

# 1002

The occupants of the Elevations will call out to certain men whom they recognize by their marks, ‘Your rallying did not avail you, nor what you used to disdain.

# 1003

Are these the ones concerning whom you swore that Allah will not extend them any mercy?’ ‘Enter paradise! You shall have no fear, nor shall you grieve.’

# 1004

The inmates of the Fire will call out to the inhabitants of paradise, ‘Pour on us some water, or something of what Allah has provided you.’ They will say, ‘Allah has indeed forbidden these two to the faithless!’

# 1005

Those who took their religion for diversion and play and whom the life of the world had deceived. So today, We will forget them as they forgot the encounter of this day of theirs, and as they used to impugn Our signs.

# 1006

Certainly We have brought them a Book, which We have elaborated with knowledge, as a guidance and mercy for a people who have faith.

# 1007

Do they not consider \[the consequences of\] its fulfillment? The day when its fulfillment comes, those who had forgotten it before will say, ‘Our Lord’s apostles had certainly brought the truth. If only we had some intercessors to intercede for us, or we would be returned, so that we may do differently from what we did!’ They have certainly ruined their souls, and what they used to fabricate has forsaken them.

# 1008

Indeed your Lord is Allah, who created the heavens and the earth in six days, and then settled on the Throne. He draws the night’s cover over the day, which pursues it swiftly, and \[He created\] the sun, the moon, and the stars, \[all of them\] disposed by His command. Look! All creation and command belong to Him. Blessed is Allah, the Lord of all the worlds.

# 1009

Supplicate your Lord, beseechingly and secretly. Indeed, He does not like the transgressors.

# 1010

And do not cause corruption on the earth after its restoration, and supplicate Him with fear and hope: indeed Allah’s mercy is close to the virtuous.

# 1011

It is He who sends forth the winds as harbingers of His mercy. When they bear \[rain-\] laden clouds, We drive them toward a dead land and send down water on it, and with it We bring forth all kinds of crops. Thus shall We raise the dead; maybe you will take admonition.

# 1012

The good land—its vegetation comes out by the permission of its Lord, and as for that which is bad, it does not come out except sparsely. Thus do We paraphrase the signs variously for a people who give thanks.

# 1013

Certainly We sent Noah to his people. He said, ‘O my people, worship Allah! You have no other god besides Him. Indeed I fear for you the punishment of a tremendous day.’

# 1014

The elite of his people said, ‘Indeed we see you in manifest error.’

# 1015

He said, ‘O my people, I am not in error. Rather, I am an apostle from the Lord of all the worlds.

# 1016

I communicate to you the messages of my Lord, and I am your well-wisher, and I know from Allah what you do not know.

# 1017

Do you consider it odd that a reminder from your Lord should come to you through a man from among yourselves, to warn you so that you may be Godwary and so that you may receive His mercy?’

# 1018

But they denied him. So We delivered him and those who were with him in the ark, and We drowned those who denied Our signs. Indeed, they were a blind lot.

# 1019

And to \[the people of\] ‘Ad \[We sent\] Hud, their brother. He said, ‘O my people, worship Allah! You have no other god besides Him. Will you not then be wary \[of Him\]?’

# 1020

The elite of his people who were faithless said, ‘Indeed we see you to be in folly, and indeed we consider you to be a liar.’

# 1021

He said, ‘O my people, I am not in folly. Rather, I am an apostle from the Lord of all the worlds.

# 1022

I communicate to you the messages of my Lord and I am a trustworthy well-wisher for you.

# 1023

Do you consider it odd that there should come to you a reminder from your Lord through a man from among yourselves, so that he may warn you? Remember when He made you successors after the people of Noah, and increased you vastly in creation. So remember Allah’s bounties so that you may be felicitous.’

# 1024

They said, ‘Have you come to \[tell\] us that we should worship Allah alone and abandon what our fathers have been worshiping? Then bring us what you threaten us with, should you be truthful.’

# 1025

He said, ‘Punishment and wrath from your Lord has become due against you. Do you dispute with me regarding names, which you have named—you and your fathers—for which Allah has not sent down any authority? So wait! I too am waiting along with you.’

# 1026

Then We delivered him and those who were with him by a mercy from Us, and We rooted out those who denied Our signs and were not faithful.

# 1027

And to \[the people of\] Thamud \[We sent\] Salih, their brother. He said, ‘O my people, worship Allah! You have no other god besides Him. There has certainly come to you a manifest proof from your Lord. This she-camel of Allah is a sign for you. Let her alone to graze \[freely\] in Allah’s land, and do not cause her any harm, for then you shall be seized by a painful punishment.

# 1028

Remember when He made you successors after \[the people of\] ‘Ad, and settled you in the land: you build palaces in its plains, and hew houses out of the mountains. So remember Allah’s bounties, and do not act wickedly on the earth, causing corruption.’

# 1029

The elite of his people who were arrogant said to those who were oppressed—to those among them who had faith—‘Do you know that Salih has been sent by his Lord?’ They said, ‘We indeed believe in what he has been sent with.’

# 1030

Those who were arrogant said, ‘We indeed disbelieve in what you have believed.’

# 1031

So they hamstrung the She-camel and defied the command of their Lord, and they said, ‘O Salih, bring us what you threaten us with, if you are one of the apostles.’

# 1032

Thereupon the earthquake seized them, and they lay lifeless prostrate in their homes.

# 1033

So he abandoned them \[to their fate\], and said, ‘O my people! Certainly I communicated to you the message of my Lord, and I was your well-wisher, but you did not like well-wishers.’

# 1034

And Lot, when he said to his people, ‘What! Do you commit an outrage none in the world ever committed before you?!

# 1035

Indeed you come to men with desire instead of women! Indeed, you are a profligate lot.’

# 1036

But the only answer of his people was that they said, ‘Expel them from your town! They are indeed a puritanical lot.’

# 1037

Thereupon We delivered him and his family, except his wife; she was one of those who remained behind.

# 1038

Then We poured down upon them a rain \[of stones\]. So observe how was the fate of the guilty!

# 1039

And to \[the people of\] Midian \[We sent\] Shu‘ayb, their brother. He said, ‘O my people, worship Allah! You have no other god besides Him. There has certainly come to you a manifest proof from your Lord. Observe fully the measure and the balance, and do not cheat the people of their goods, and do not cause corruption on the earth after its restoration. That is better for you, if you are faithful.

# 1040

And do not lie in wait on every road to threaten and bar those who have faith in Him from the way of Allah, seeking to make it crooked. Remember when you were few, and He multiplied you, and observe how was the fate of the agents of corruption.

# 1041

If a group of you have believed in what I have been sent with, and a group have not believed, be patient until Allah judges between us, and He is the best of judges.’

# 1042

The elite of his people who were arrogant said, ‘O Shu'ayb, we will surely expel you and the faithful who are with you from our town, or else you shall revert to our creed.’ He said, ‘What! Even if we should be unwilling?!

# 1043

We would be fabricating a lie against Allah should we revert to your creed after Allah had delivered us from it. It does not behoove us to return to it, unless Allah, our Lord, should wish so. Our Lord embraces all things in \[His\] knowledge. In Allah we have put our trust.’ ‘Our Lord! Judge justly between us and our people, and You are the best of judges!’

# 1044

The elite of his people who were faithless said, ‘If you follow Shu'ayb, you will indeed be losers.’

# 1045

So the earthquake seized them, and they lay lifeless prostrate in their homes.

# 1046

Those who impugned Shu'ayb became as if they had never lived there. Those who impugned Shu‘ayb were themselves the losers.

# 1047

So he abandoned them \[to their fate\] and said, ‘O my people! Certainly, I communicated to you the messages of my Lord, and I was your well-wisher. So how should I grieve for a faithless lot?’

# 1048

We did not send a prophet to any town without visiting its people with stress and distress so that they might entreat \[for Allah’s forgiveness\].

# 1049

Then We changed the ill \[conditions\] to good until they multiplied \[in numbers\] and said, ‘Adversity and ease befell our fathers \[too\].’ Then We seized them suddenly while they were unaware.

# 1050

If the people of the towns had been faithful and Godwary, We would have opened to them blessings from the heaven and the earth. But they denied; so We seized them because of what they used to earn.

# 1051

Do the people of the towns feel secure from Our punishment overtaking them at night while they are asleep?

# 1052

Do the people of the towns feel secure from Our punishment overtaking them at midday while they are playing around?

# 1053

Do they feel secure from Allah’s devising? No one feels secure from Allah’s devising except the people who are losers.

# 1054

Does it not dawn upon those who inherited the earth after its \[former\] inhabitants that if We wish We will punish them for their sins, and set a seal on their hearts so they would not hear?

# 1055

These are the towns some of whose accounts We recount to you. Their apostles certainly brought them manifest proofs, but they were not the ones to believe in what they had denied earlier. Thus does Allah put a seal on the hearts of the faithless.

# 1056

We did not find in most of them any \[loyalty to\] covenants. Indeed, We found most of them to be transgressors.

# 1057

Then after them We sent Moses with Our signs to Pharaoh and his elite, but they wronged them. So observe how was the fate of the agents of corruption!

# 1058

And Moses said, ‘O Pharaoh, I am indeed an apostle from the Lord of all the worlds.

# 1059

It behooves me to say nothing about Allah except the truth. I certainly bring you a manifest proof from your Lord. So let the Children of Israel go with me.’

# 1060

He said, ‘If you have brought a sign, produce it, should you be truthful.’

# 1061

Thereat he threw down his staff, and behold, it became a manifest python.

# 1062

Then he drew out his hand, and behold, it was white to the onlookers.

# 1063

The elite of Pharaoh’s people said, ‘This is indeed an expert magician;

# 1064

he seeks to expel you from your land.’ ‘So what do you advise?’

# 1065

They said, ‘Put him and his brother off for a while, and send heralds to the cities,

# 1066

to bring you every expert magician.’

# 1067

And the magicians came to Pharaoh. They said, ‘We shall indeed have a reward if we were to be the victors?’

# 1068

He said, ‘Of course! And indeed you shall be among those near \[to me\].’

# 1069

They said, ‘O Moses, will you throw \[first\], or shall we throw?’

# 1070

He said, ‘Throw \[yours\].’ So when they threw, they bewitched the people’s eyes and overawed them, producing a tremendous magic.

# 1071

And We signalled to Moses: ‘Throw down your staff.’ And behold, it was swallowing what they had faked.

# 1072

So the truth came out, and what they had wrought was reduced to naught.

# 1073

Thereat they were vanquished, and they retreated, humiliated.

# 1074

And the magicians fell down in prostration.

# 1075

They said, ‘We have believed in the Lord of all the worlds,

# 1076

the Lord of Moses and Aaron.’

# 1077

Pharaoh said, ‘Do you profess faith in Him before I may permit you? It is indeed a plot you have devised in the city to expel its people from it. Soon you will know \[the consequences\]!

# 1078

Surely I will cut off your hands and feet on opposite sides, and then I will surely crucify all of you.’

# 1079

They said, ‘Indeed we shall return to our Lord.

# 1080

You are vindictive toward us only because we have believed in the signs of our Lord, when they came to us.’ ‘Our Lord! Pour patience upon us, and grant us to die as Muslims.’

# 1081

The elite of Pharaoh’s people said, ‘Will you leave Moses and his people to cause corruption in the land, and to abandon you and your gods?’ He said, ‘We will kill their sons and spare their women, and indeed we are dominant over them.’

# 1082

Moses said to his people, ‘Turn to Allah for help and be patient. The earth indeed belongs to Allah, and He gives its inheritance to whomever He wishes of His servants, and the outcome will be in favour of the Godwary.’

# 1083

They said, ‘We were tormented before you came to us and \[also\] after you came to us.’ He said, ‘Maybe your Lord will destroy your enemy and make you successors in the land, and then He will see how you act.’

# 1084

Certainly We afflicted Pharaoh’s clan with droughts and loss of produce, so that they may take admonition.

# 1085

But whenever any good came to them, they would say, ‘This is our due.’ And if any ill visited them, they took it for ill omens attending Moses and those who were with him. (Look! Indeed the cause of their ill omens is from Allah, but most of them do not know.)

# 1086

And they said, ‘Whatever sign you may bring us to bewitch us, we are not going to believe you.’

# 1087

So We sent against them a flood and locusts, lice, frogs and blood, as distinct signs. But they acted arrogantly, and they were a guilty lot.

# 1088

Whenever a plague fell upon them, they would say, ‘O Moses, invoke your Lord for us by the covenant He has made with you. If you remove the plague from us, we will certainly believe in you and let the Children of Israel go along with you.’

# 1089

But when We had removed the plague from them until a term that they should have completed, behold, they broke their promise.

# 1090

So We took vengeance on them and drowned them in the sea, for they denied Our signs and were oblivious to them.

# 1091

We made the people who were abased the heirs to the east and west of the land which We had blessed, and your Lord’s best word \[of promise\] was fulfilled for the Children of Israel because of their patience, and We destroyed what Pharaoh and his people had built and what they used to erect.

# 1092

We carried the Children of Israel across the sea, whereat they came upon a people cleaving to certain idols that they had. They said, ‘O Moses, make for us a god like the gods that they have.’ He said, ‘You are indeed an ignorant lot.

# 1093

What they are engaged in is indeed bound to perish, and what they have been doing shall come to naught.’

# 1094

He said, ‘Shall I find you a god other than Allah, while He has graced you over all the nations?’

# 1095

And when We delivered you from Pharaoh’s clan who inflicted on you a terrible torment, slaughtering your sons and sparing your women, and there was a great test in that from your Lord.

# 1096

We made an appointment with Moses for thirty nights, and completed them with ten \[more\]; thus the tryst of his Lord was completed in forty nights. And Moses said to Aaron, his brother, ‘Be my successor among my people, and set things right and do not follow the way of the agents of corruption.’

# 1097

When Moses arrived at Our tryst and his Lord spoke to him, he said, ‘My Lord, show \[Yourself\] to me, that I may look at You!’ He said, ‘You shall not see Me. But look at the mountain: if it abides in its place, then you will see Me.’ So when his Lord disclosed Himself to the mountain, He levelled it, and Moses fell down swooning. When he recovered, he said, ‘Immaculate are You! I turn to You in penitence, and I am the first of the faithful.’

# 1098

He said, ‘O Moses, I have chosen you over the people with My messages and My speech. So take what I give you, and be among the grateful.’

# 1099

We wrote for him in the tablets advice concerning all things and an elaboration of all things, \[and We said\], ‘Hold on to them with power, and bid your people to hold on to the best of \[what is in\] them. Soon I shall show you the abode of the transgressors.

# 1100

Soon I shall turn away from My signs those who are unduly arrogant in the earth: \[even\] though they should see every sign, they will not believe in it, and if they see the way of rectitude they will not take it as \[their\] way, and if they see the way of error they will take it as \[their\] way. That is because they deny Our signs and are oblivious to them.’

# 1101

Those who deny Our signs and the encounter of the Hereafter, their works have failed. Shall they not be requited for what they used to do?

# 1102

The people of Moses took up in his absence a calf \[cast\] from their ornaments—a body that gave out a lowing sound. Did they not regard that it did not speak to them, nor did it guide them to any way? They took it up \[for worship\] and they were wrongdoers.

# 1103

But when they became remorseful and realised they had gone astray, they said, ‘Should our Lord have no mercy on us, and forgive us, we will be surely among the losers.’

# 1104

When Moses returned to his people, angry and indignant, he said, ‘Evil has been your conduct in my absence! Would you hasten on the edict of your Lord?’ He threw down the tablets and seized his brother by the head, pulling him towards himself. He said, ‘Son of my mother, indeed this people thought me to be weak, and they were about to kill me. So do not let the enemies gloat over me, and do not take me with the wrongdoing lot.’

# 1105

He said, ‘My Lord, forgive me and my brother, and admit us into Your mercy, for You are the most merciful of the merciful.

# 1106

Indeed those who took up the calf \[for worship\] shall be overtaken by their Lord’s wrath and abasement in the life of the world.’ Thus do We requite the fabricators \[of lies\].

# 1107

Yet \[to\] those who commit misdeeds but repent after that, and believe—indeed, after that, your Lord shall surely be all-forgiving, all-merciful.

# 1108

When Moses’ indignation abated, he picked up the tablets whose inscriptions contained guidance and mercy for those who are in awe of their Lord.

# 1109

Moses chose seventy men from his people for Our tryst, and when the earthquake seized them, he said, ‘My Lord, had You wished, You would have destroyed them and me before. Will You destroy us because of what the fools amongst us have done? It is only Your test, by which You lead astray whomever You wish and guide whomever You wish. You are our master, so forgive us and have mercy on us, for You are the best of those who forgive.

# 1110

And appoint goodness for us in this world and the Hereafter, for indeed we have come back to You.’ Said He, ‘I visit My punishment on whomever I wish, but My mercy embraces all things. Soon I shall appoint it for those who are Godwary and give the zakat and those who believe in Our signs

# 1111

—those who follow the Apostle, the untaught prophet, whose mention they find written with them in the Torah and the Evangel, who bids them to do what is right and forbids them from what is wrong, makes lawful to them all the good things and forbids them from all vicious things, and relieves them of their burdens and the shackles that were upon them—those who believe in him, honour him, and help him and follow the light that has been sent down with him, they are the felicitous.’

# 1112

Say, ‘O mankind! I am the Apostle of Allah to you all, \[of Him\] to whom belongs the kingdom of the heavens and the earth. There is no god except Him. He gives life and brings death.’ So have faith in Allah and His Apostle, the untaught prophet, who has faith in Allah and His words, and follow him so that you may be guided.

# 1113

Among the people of Moses is a nation who guide \[the people\] by the truth and do justice thereby.

# 1114

We split them up into twelve tribal communities, and We revealed to Moses, when his people asked him for water, \[saying\], ‘Strike the rock with your staff,’ whereat twelve fountains gushed forth from it. Every tribe came to know its drinking-place. And We shaded them with clouds, and We sent down to them manna and quails: ‘Eat of the good things We have provided you.’ And they did not wrong Us, but they used to wrong \[only\] themselves.

# 1115

And when they were told, ‘Settle in this town and eat thereof whence you wish; and say, ‘‘Relieve \[us of the burden of our sins\],’’ and enter prostrating at the gate, that We may forgive your iniquities, and soon We shall enhance the virtuous.’

# 1116

But the wrongdoers changed the saying with other than what they had been told. So We sent against them a plague from the sky because of the wrongs they used to commit.

# 1117

Ask them about the town that was situated on the seaside, when they violated the Sabbath, when their fish would come to them on the Sabbath day, visibly on the shore, but on days when they were not keeping Sabbath they would not come to them. Thus did We test them because of the transgressions they used to commit.

# 1118

When a group of them said, ‘Why do you advise a people whom Allah will destroy, or punish with a severe punishment?’ They said, ‘As an excuse before your Lord, and \[with the hope\] that they may be Godwary.’

# 1119

So when they forgot what they had been reminded of, We delivered those who forbade evil \[conduct\] and seized the wrongdoers with a terrible punishment because of the transgressions they used to commit.

# 1120

When they defied \[the command pertaining to\] what they were forbidden from, We said to them, ‘Be you spurned apes.’

# 1121

And when your Lord proclaimed that He would surely send against them, until the Day of Resurrection, those who would inflict on them a terrible punishment. Indeed your Lord is swift in retribution, and indeed, He is all-forgiving, all-merciful.

# 1122

We dispersed them into communities around the earth: some of them were righteous, and some of them otherwise, and We tested them with good and bad \[times\] so that they may come back.

# 1123

Then they were succeeded by an evil posterity, which inherited the Book: they grab the transitory gains of this lower world, and say, ‘It will be forgiven us.’ And if similar transitory gains were to come their way, they would grab them too. Was not the covenant of the Book taken with them that they shall not attribute anything to Allah except the truth? They have studied what is in it, and \[know that\] the abode of the Hereafter is better for those who are Godwary. Do you not exercise your reason?

# 1124

As for those who hold fast to the Book and maintain the prayer—indeed, We do not waste the reward of those who bring about reform.

# 1125

When We plucked the mountain \[and held it\] above them as if it were a canopy (and they thought it was about to fall on them): ‘Hold on with power to what We have given you and remember that which is in it, so that you may be Godwary.’

# 1126

When your Lord took from the Children of Adam, from their loins, their descendants and made them bear witness over themselves, \[He said to them,\] ‘Am I not your Lord?’ They said, ‘Yes indeed! We bear witness.’ \[This,\] lest you should say on the Day of Resurrection, ‘Indeed we were unaware of this,’

# 1127

or lest you should say, ‘Our fathers ascribed partners \[to Allah\] before \[us\] and we were descendants after them. Will You then destroy us because of what the falsifiers have done?’

# 1128

Thus do We elaborate the signs, so that they may come back.

# 1129

Relate to them an account of him to whom We gave Our signs, but he cast them off. Thereupon Satan pursued him, and he became one of the perverse.

# 1130

Had We wished, We would have surely raised him by their means, but he clung to the earth and followed his \[base\] desires. So his parable is that of a dog: if you make for it, it lolls out its tongue, and if you let it alone, it lolls out its tongue. Such is the parable of the people who deny Our signs. So recount these narratives, so that they may reflect.

# 1131

Evil is the parable of the people who deny Our signs and wrong themselves.

# 1132

Whomever Allah guides is rightly guided, and whomever He leads astray—it is they who are the losers.

# 1133

Certainly We have winnowed out for hell many of the jinn and humans: they have hearts with which they do not understand, they have eyes with which they do not see, they have ears with which they do not hear. They are like cattle; indeed, they are more astray. It is they who are the heedless.

# 1134

To Allah belong the Best Names, so supplicate Him by them, and abandon those who commit sacrilege in His names. Soon they shall be requited for what they used to do.

# 1135

Among those We have created are a nation who guide by the truth and do justice thereby.

# 1136

As for those who deny Our signs, We will draw them imperceptibly \[into ruin\], whence they do not know.

# 1137

And I will grant them respite, for My devising is indeed sure.

# 1138

Have they not reflected that there is no madness in their companion, \[and that\] he is just a manifest warner?

# 1139

Have they not contemplated the dominions of the heavens and the earth, and whatever things Allah has created, and that maybe their time has already drawn near? So what discourse will they believe after this?!

# 1140

Whomever Allah leads astray has no guide, and He leaves them bewildered in their rebellion.

# 1141

They question you concerning the Hour, when will it set in? Say, ‘Its knowledge is only with my Lord: none except Him shall manifest it at its time. It will weigh heavy on the heavens and the earth. It will not overtake you but suddenly.’ They ask you as if you were in the know of it. Say, ‘Its knowledge is only with Allah, but most people do not know.’

# 1142

Say, ‘I have no control over any benefit for myself, nor \[over\] any harm except what Allah may wish. Had I known the Unseen, I would have acquired much good, and no ill would have befallen me. I am only a warner and bearer of good news to a people who have faith.’

# 1143

It is He who created you from a single soul, and made from it its mate, that he might find comfort with her. So when he had covered her, she bore a light burden and passed \[some time\] with it. When she had grown heavy, they both invoked Allah, their Lord: ‘If You give us a healthy \[child\], we will be surely grateful.’

# 1144

Then when He gave them a healthy \[child\], they ascribed partners to Him in what He had given them. Exalted is Allah above \[having\] any partners that they ascribe \[to Him\]!

# 1145

Do they ascribe \[to Him\] partners that create nothing and have been created themselves,

# 1146

and can neither help them, nor help themselves?

# 1147

If you call them to guidance, they will not follow you: it is the same to you whether you call them or whether you are silent.

# 1148

Indeed those whom you invoke besides Allah are creatures like you. So invoke them: they should answer you, if you are truthful.

# 1149

Do they have any feet to walk with? Do they have any hands to grasp with? Do they have any eyes to see with? Do they have any ears to hear with? Say, ‘Invoke your partners \[that you ascribe to Allah\] and try out your stratagems against me without granting me any respite.

# 1150

My guardian is indeed Allah who sent down the Book, and He takes care of the righteous.

# 1151

Those whom you invoke besides Him can neither help you, nor help themselves.

# 1152

If you call them to guidance, they will not hear. You see them facing you, but they do not see.’

# 1153

Adopt \[a policy of\] excusing \[the faults of people\], bid what is right, and turn away from the ignorant.

# 1154

Should a temptation from Satan disturb you, invoke the protection of Allah; indeed He is all-hearing, all-knowing.

# 1155

When those who are Godwary are touched by a visitation of Satan, they remember \[Allah\] and, behold, they perceive.

# 1156

But their brethren, they draw them into error, and then they do not spare \[any harm\].

# 1157

When you do not bring them a sign, they say, ‘Why do you not improvise one?’ Say, ‘I only follow what is revealed to me from my Lord; these are insights from your Lord, and a guidance and mercy for a people who have faith.’

# 1158

When the Quran is recited, listen to it and be silent, maybe you will receive \[Allah’s\] mercy.

# 1159

And remember your Lord within your heart beseechingly and reverentially, without being loud, morning, and evening, and do not be among the heedless.

# 1160

Indeed those who are \[stationed\] near your Lord do not disdain to worship Him. They glorify Him and prostrate to Him.

# 1161

They ask you concerning the anfaal. Say, ‘The anfaal belong to Allah and the Apostle.’ So be wary of Allah and settle your differences, and obey Allah and His Apostle, should you be faithful.

# 1162

The faithful are only those whose hearts tremble \[with awe\] when Allah is mentioned, and when His signs are recited to them, they increase their faith, and who put their trust in their Lord,

# 1163

maintain the prayer and spend out of what We have provided them.

# 1164

It is they who are truly the faithful. They shall have ranks near their Lord, forgiveness and a noble provision.

# 1165

As your Lord brought you out from your home with a just cause, a part of the faithful were indeed reluctant.

# 1166

They disputed with you concerning the truth after it had become clear, as if they were being driven towards death as they looked on.

# 1167

When Allah promised you \[victory over\] one of the two companies, \[saying\], ‘It is for you,’ you were eager that it should be the one that was unarmed. But Allah desires to confirm the truth with His words, and to root out the faithless,

# 1168

so that He may confirm the truth and bring falsehood to naught, though the guilty should be averse.

# 1169

When you appealed to your Lord for help, He answered you: ‘I will aid you with a thousand angels in a file.’

# 1170

Allah did not appoint it but as a good news, and to reassure your hearts. Victory comes only from Allah. Indeed Allah is all-mighty, all-wise.

# 1171

When He covered you with a trance as a \[sense of\] security from Him, and He sent down water from the sky to purify you with it, and to repel from you the defilement of Satan, and to fortify your hearts, and to make \[your\] feet steady with it.

# 1172

Then your Lord signaled to the angels: ‘I am indeed with you; so steady the faithful. I will cast terror into the hearts of the faithless. So strike their necks, and strike their every limb joint!’

# 1173

That, because they defied Allah and His Apostle. And whoever defies Allah and His Apostle, Allah is indeed severe in retribution.

# 1174

‘Taste this, and \[know\] that for the faithless is the punishment of the Fire.’

# 1175

O you who have faith! When you encounter the faithless advancing \[for battle\], do not turn your backs \[to flee\] from them.

# 1176

Whoever turns his back \[to flee\] from them that day—unless \[he is\] diverting to fight or retiring towards another troop—shall certainly earn Allah’s wrath, and his refuge shall be hell, an evil destination.

# 1177

You did not kill them; rather, it was Allah who killed them; and you did not throw when you threw, rather, it was Allah who threw, that He might test the faithful with a good test from Himself. Indeed Allah is all-hearing, all-knowing.

# 1178

Such is the case, and \[know\] that Allah undermines the stratagems of the faithless.

# 1179

If you sought a verdict, the verdict has certainly come to you; and if you cease \[your belligerence against the Prophet and his followers\], it is better for you, but if you resume, We \[too\] shall return and your troops will never avail you though they should be ever so many, and \[know\] that Allah is with the faithful.

# 1180

O you who have faith! Obey Allah and His Apostle, and do not turn away from him while you hear \[him\].

# 1181

Do not be like those who say, ‘We hear,’ though they do not hear.

# 1182

Indeed the worst of beasts in Allah’s sight are the deaf and dumb who do not exercise their reason.

# 1183

Had Allah known any good in them, He would have surely made them hear, and were He to make them hear, surely they would turn away, being disregardful.

# 1184

O you who have faith! Answer Allah and the Apostle when he summons you to that which will give you life. Know that Allah intervenes between a man and his heart and that toward Him you will be mustered.

# 1185

And beware of a punishment, which shall not visit the wrongdoers among you exclusively, and know that Allah is severe in retribution.

# 1186

Remember when you were few, abased in the land, and feared lest the people should despoil you, and He gave you refuge, and strengthened you with His help, and provided you with all the good things so that you may give thanks.

# 1187

O you who have faith! Do not betray Allah and the Apostle, and do not betray your trusts knowingly.

# 1188

Know that your possessions and children are only a test, and that Allah—with Him is a great reward.

# 1189

O you who have faith! If you are wary of Allah, He shall appoint a criterion for you, and absolve you of your misdeeds, and forgive you, for Allah is dispenser of a great grace.

# 1190

When the faithless plotted against you to take you captive, or to kill or expel you—they plotted and Allah devised, and Allah is the best of devisers.

# 1191

When Our signs are recited to them, they say, ‘We have heard already. If we want, we \[too\] can say like this. These are nothing but myths of the ancients.’

# 1192

And when they said, ‘O Allah, if this be the truth from You, rain down upon us stones from the sky, or bring us a painful punishment.’

# 1193

But Allah will not punish them while you are in their midst, nor will Allah punish them while they plead for forgiveness.

# 1194

What \[excuse\] have they that Allah should not punish them, when they bar \[the faithful\] from the Holy Mosque, and they are not its custodians? Its custodians are only the Godwary, but most of them do not know.

# 1195

Their prayer at the House is nothing but whistling and clapping. So taste the punishment because of what you used to defy.

# 1196

Indeed the faithless spend their wealth to bar from the way of Allah. Soon they will have spent it, then it will be a cause of regret to them, then they will be overcome, and the faithless will be gathered toward Hell,

# 1197

so that Allah may separate the bad ones from the good, and place the bad on one another, and pile them up together, and cast them into hell. It is they who are the losers.

# 1198

Say to the faithless, if they cease \[their belligerence against the Muslims\], what is already past shall be forgiven them. But if they resume \[their hostilities\], then the precedent of the predecessors has already come to pass.

# 1199

Fight them until persecution is no more, and religion becomes exclusively for Allah. So if they desist, Allah indeed watches what they do.

# 1200

But if they turn away, then know that Allah is your master: an excellent master and an excellent helper!

# 1201

Know that whatever thing you may come by, a fifth of it is for Allah and the Apostle, for the relatives and the orphans, for the needy and the traveller, if you have faith in Allah and what We sent down to Our servant on the Day of Separation, the day when the two hosts met; and Allah has power over all things.

# 1202

When you were on the nearer side, and they on the farther side, while the caravan was below you, and had you agreed together on an encounter, you would have certainly failed to keep the tryst, but in order that Allah may carry through a matter that was bound to be fulfilled, so that he who perishes might perish by a manifest proof, and he who lives may live on by a manifest proof, and Allah is indeed all-hearing, all-knowing.

# 1203

When Allah showed them to you as few in your dream, and had He shown them as many, you would have lost heart, and disputed about the matter. But Allah spared you. Indeed He knows well what is in the breasts.

# 1204

And when He showed them to you as few in your eyes, when you met them \[on the battlefield\], and He made you \[appear\] few in their eyes, \[it was\] in order that Allah may carry through a matter that was bound to be fulfilled, and to Allah all matters are returned.

# 1205

O you who have faith! When you meet a host \[in battle\], then stand firm, and remember Allah greatly so that you may be felicitous.

# 1206

And obey Allah and His Apostle, and do not dispute, or you will lose heart and your power will be gone. And be patient; indeed Allah is with the patient.

# 1207

Do not be like those who left their homes vainly and to show off to the people, and to bar \[other people\] from the way of Allah, and Allah comprehends what they do.

# 1208

When Satan made their deeds seem decorous to them, and said \[to the faithless\], ‘No one shall overcome you today from among all mankind, and I will stand by you.’ But when the two hosts sighted each other, he took to his heels, saying, ‘Indeed I am quit of you. I see what you do not see. Indeed I fear Allah, and Allah is severe in retribution.’

# 1209

When the hypocrites said, and \[also\] those in whose hearts is a sickness, ‘Their religion has deceived them.’ But whoever puts his trust in Allah, then Allah is indeed all-mighty, all-wise.

# 1210

Were you to see when the angels take away the faithless, striking their faces and their backs, \[saying\], ‘Taste the punishment of the burning.

# 1211

That is because of what your hands have sent ahead, and because Allah is not tyrannical to the servants.’

# 1212

Like the precedent of Pharaoh’s clan and those who were before them, who defied Allah’s signs, so Allah seized them for their sins. Indeed Allah is all-strong, severe in retribution.

# 1213

That is because Allah never changes a blessing that He has bestowed on a people unless they change what is in their own souls, and Allah is all-hearing, all-knowing:

# 1214

Like the precedent of Pharaoh’s clan and those who were before them, who denied the signs of their Lord; so We destroyed them for their sins, and We drowned Pharaoh’s clan; and they were all wrongdoers.

# 1215

Indeed the worst of beasts in Allah’s sight are those who are faithless; so they will not have faith.

# 1216

—Those with whom you made a treaty, and who violated their treaty every time, and who are not Godwary.

# 1217

So if you confront them in battle, treat them \[in such a wise\] as to disperse those who are behind them, so that they may take admonition.

# 1218

And if you fear treachery from a people, break off \[the treaty\] with them in a like manner. Indeed Allah does not like the treacherous.

# 1219

Let the faithless not suppose that they have outmanoeuvred \[Allah\]. Indeed, they cannot frustrate \[His power\].

# 1220

Prepare against them whatever you can of \[military\] power and war-horses, awing thereby the enemy of Allah, and your enemy, and others besides them, whom you do not know, but Allah knows them. And whatever you spend in the way of Allah will be repaid to you in full, and you will not be wronged.

# 1221

If they incline toward peace, then you \[too\] incline toward it, and put your trust in Allah. Indeed He is the All-hearing, the All-knowing.

# 1222

But if they desire to deceive you, Allah is indeed sufficient for you. It is He who strengthened you with His help and with the means of the faithful,

# 1223

and united their hearts. Had you spent all that is in the earth, you could not have united their hearts, but Allah united them together. Indeed He is all-mighty, all-wise.

# 1224

O Prophet! Sufficient for you is Allah and those of the faithful who follow you.

# 1225

O Prophet! Urge on the faithful to fight: If there be twenty patient men among you, they shall overcome two hundred; and if there be a hundred of you, they shall overcome a thousand of the faithless, for they are a lot who do not understand.

# 1226

Now Allah has lightened your burden, knowing that there is weakness in you. So if there be a hundred patient men among you, they shall overcome two hundred; and if there be a thousand, they shall overcome two thousand, by Allah’s leave; and Allah is with the patient.

# 1227

A prophet may not take captives until he has thoroughly decimated \[the enemy\] in the land. You desire the transitory gains of this world, while Allah desires \[for you\] \[the reward of\] the Hereafter, and Allah is all-mighty, all-wise.

# 1228

Had it not been for a prior decree of Allah, surely there would have befallen you a great punishment for what you took.

# 1229

Avail yourselves of the spoils you have taken as lawful and good, and be wary of Allah. Indeed Allah is all-forgiving, all-merciful.

# 1230

O Prophet! Say to the captives who are in your hands, ‘If Allah finds any good in your hearts, He will give you \[something which is\] better than what has been taken away from you, and He will forgive you, and Allah is all-forgiving, all-merciful.’

# 1231

But if they seek to betray you, then they have already betrayed Allah earlier, and He gave \[you\] power over them; and Allah is all-knowing, all-wise.

# 1232

Indeed those who have believed and migrated and waged jihad with their possessions and persons in the way of Allah, and those who gave \[them\] shelter and help—they are heirs of one another. As for those who have believed but did not migrate, you have no heirdom in relation to them whatsoever until they migrate. Yet if they ask your help for the sake of religion, it is incumbent on you to help them, excepting against a people with whom you have a treaty; and Allah watches what you do.

# 1233

As for the faithless, they are heirs of one another. Unless you do the same, there will be strife in the land and great corruption.

# 1234

Those who have believed, migrated, and waged jihad in the way of Allah, and those who gave them shelter and help, it is they who are truly the faithful. For them shall be forgiveness and a noble provision.

# 1235

Those who believed afterwards and migrated, and waged jihad along with you, they belong to you; but the blood relatives are more entitled to inherit from one another in the Book of Allah. Indeed Allah has knowledge of all things.

# 1236

\[This is\] a \[declaration of\] repudiation by Allah and His Apostle \[addressed\] to the polytheists with whom you had made a treaty:

# 1237

Travel \[unmolested\] in the land for four months, but know that you cannot frustrate Allah, and that Allah shall disgrace the faithless.

# 1238

\[This is\] an announcement from Allah and His Apostle to all the people on the day of the greater Hajj: that Allah and His Apostle repudiate the polytheists: If you repent that is better for you; but if you turn your backs \[on Allah\], know that you cannot frustrate Allah, and inform the faithless of a painful punishment

# 1239

(barring the polytheists with whom you have made a treaty, and who did not violate any \[of its terms\] with you, nor backed anyone against you. So fulfill the treaty with them until \[the end of\] its term. Indeed Allah loves the Godwary).

# 1240

Then, when the sacred months have passed, kill the polytheists wherever you find them, capture them and besiege them, and lie in wait for them at every ambush. But if they repent, and maintain the prayer and give the zakat, then let them alone. Indeed Allah is all-forgiving, all-merciful.

# 1241

If any of the polytheists seeks asylum from you, grant him asylum until he hears the Word of Allah. Then convey him to his place of safety. That is because they are a people who do not know.

# 1242

How shall the polytheists have any \[valid\] treaty with Allah and His Apostle?! (Barring those with whom you made a treaty at the Holy Mosque; so long as they are steadfast with you, be steadfast with them. Indeed Allah loves the Godwary.)

# 1243

How? For if, they get the better of you, they will observe toward you neither kinship nor covenant. They please you with their mouths while their hearts spurn you; and most of them are transgressors.

# 1244

They have sold the signs of Allah for a paltry gain, and have barred \[the people\] from His way. Evil indeed is what they have been doing.

# 1245

They observe toward a believer neither kinship nor covenant, and it is they who are the transgressors.

# 1246

Yet if they repent and maintain the prayer and give the zakat, then they are your brethren in faith. We elaborate the signs for a people who have knowledge.

# 1247

But if they break their pledges after their having made a treaty and revile your religion, then fight the leaders of unfaith—indeed, they have no \[commitment to\] pledges,—maybe they will desist.

# 1248

Will you not make war on a people who broke their pledges and resolved to expel the Apostle, and opened \[hostilities\] against you initially? Do you fear them? But Allah is worthier of being feared by you, should you be faithful.

# 1249

Make war on them so that Allah may punish them by your hands and humiliate them, and help you against them, and heal the hearts of a faithful folk,

# 1250

and remove rage from their hearts, and Allah turns clemently to whomever He wishes, and Allah is all-knowing, all-wise

# 1251

Do you suppose that you will be let off while Allah has not yet ascertained those of you who wage jihad and those who do not take anyone as \[their\] confidant besides Allah and His Apostle and the faithful? Allah is well aware of what you do.

# 1252

The polytheists may not maintain Allah’s mosques while they are witness to their own unfaith. Their works have failed, and they shall remain in the Fire \[forever\].

# 1253

Only those shall maintain Allah’s mosques who believe in Allah and the Last Day, and maintain the prayer, and give the zakat, and fear no one except Allah. They, hopefully, will be among the guided.

# 1254

Do you regard the providing of water to Hajj pilgrims and the maintenance of the Holy Mosque as similar \[in worth\] to someone who has faith in Allah and \[believes in\] the Last Day and wages jihad in the way of Allah? They are not equal with Allah, and Allah does not guide the wrongdoing lot.

# 1255

Those who have believed and migrated, and waged jihad in the way of Allah with their possessions and persons have a greater rank near Allah, and it is they who are the triumphant.

# 1256

Their Lord gives them the good news of His mercy and \[His\] pleasure, and for them there will be gardens with lasting bliss,

# 1257

to remain in them forever. With Allah indeed is a great reward.

# 1258

O you who have faith! Do not befriend your fathers and brothers if they prefer faithlessness to faith. Those of you who befriend them—it is they who are the wrongdoers.

# 1259

Say, ‘If your fathers and your sons, your brethren, your spouses, and your kinsfolk, the possessions that you have acquired, the business you fear may suffer, and the dwellings you are fond of, are dearer to you than Allah and His Apostle and to waging jihad in His way, then wait until Allah issues His edict, and Allah does not guide the transgressing lot.

# 1260

Allah has certainly helped you in many situations, and on the day of Hunayn, when your great number impressed you, but it did not avail you in any way, and the earth became narrow for you in spite of its expanse, whereupon you turned your backs \[to flee\].

# 1261

Then Allah sent down His composure upon His Apostle and upon the faithful, and He sent down hosts you did not see, and He punished the faithless, and that is the requital of the faithless.

# 1262

Then Allah shall turn clemently after that to whomever He wishes. Indeed Allah is all-forgiving, all-merciful.

# 1263

O you who have faith! The polytheists are indeed unclean: so let them not approach the Holy Mosque after this year. Should you fear poverty, Allah will enrich you out of His grace, if He wishes. Indeed Allah is all-knowing, all-wise.

# 1264

Fight those who do not have faith in Allah nor \[believe\] in the Last Day, nor forbid what Allah and His Apostle have forbidden, nor practise the true religion, from among those who were given the Book, until they pay the tribute out of hand, degraded.

# 1265

The Jews say, ‘Ezra is the son of Allah,’ and the Christians say, ‘Christ is the son of Allah.’ That is an opinion that they mouth, imitating the opinions of the faithless of former times. May Allah assail them, where do they stray?!

# 1266

They have taken their scribes and their monks as lords besides Allah, and also Christ, Mary’s son; though they were commanded to worship only the One God, there is no god except Him; He is far too immaculate to have any partners that they ascribe \[to Him\]!

# 1267

They desire to put out the light of Allah with their mouths, but Allah is intent on perfecting His light though the faithless should be averse.

# 1268

It is He who has sent His Apostle with the guidance and the religion of truth that He may make it prevail over all religions, though the polytheists should be averse.

# 1269

O you who have faith! Indeed many of the scribes and monks wrongfully eat up the people’s wealth, and bar \[them\] from the way of Allah. Those who treasure up gold and silver, and do not spend it in the way of Allah, inform them of a painful punishment

# 1270

on the day when these shall be heated in hellfire and therewith branded on their foreheads, their sides, and their backs \[and told\]: ‘This is what you treasured up for yourselves! So taste what you have treasured!’

# 1271

Indeed the number of months with Allah is twelve months in Allah’s Book, the day when He created the heavens and the earth. Of these, four are sacred. That is the upright religion. So do not wrong yourselves during them. Fight all the polytheists, just as they fight you all, and know that Allah is with the Godwary.

# 1272

Indeed nasee is an increase in unfaith, whereby the faithless are led \[further\] astray. They allow it in one year and forbid it another year, so as to fit in with the number, which Allah has made inviolable, thus permitting what Allah has forbidden. Their evil deeds appear to them as decorous, and Allah does not guide the faithless lot.

# 1273

O you who have faith! What is the matter with you that when you are told: ‘Go forth in the way of Allah,’ you sink heavily to the ground? Are you pleased with the life of this world instead of the Hereafter? But the wares of the life of this world compared with the Hereafter are but insignificant.

# 1274

If you do not go forth, He will punish you with a painful punishment, and replace you with another people, and you will not hurt Him in the least, and Allah has power over all things.

# 1275

If you do not help him, then Allah certainly helped him when the faithless expelled him, as one of two \[refugees\], when the two of them were in the cave, he said to his companion, ‘Do not grieve; Allah is indeed with us.’ Then Allah sent down His composure upon him, and strengthened him with hosts you did not see, and He made the word of the faithless the lowest; and the word of Allah is the highest; and Allah is all-mighty, all-wise.

# 1276

Go forth, whether \[armed\] lightly or heavily, and wage jihad with your possessions and persons in the way of Allah. That is better for you, should you know.

# 1277

Were it an accessible gain or a short journey, they would have surely followed you; but the distance seemed too far to them. Yet they will swear by Allah: ‘If we could, we would have surely gone forth with you.’ They \[merely\] destroy themselves. Allah knows that they are indeed liars.

# 1278

May Allah excuse you! Why did you grant them leave \[to stay behind\] before those who told the truth were evident to you and you had ascertained the liars?

# 1279

Those who believe in Allah and the Last Day do not ask you for leave \[exempting them\] from waging jihad with their possessions and their persons, and Allah knows best the Godwary.

# 1280

Only those seek a leave \[of exemption\] from you who do not believe in Allah and the Last Day, and whose hearts are in doubt, so they waver in their doubt.

# 1281

Had they desired to go forth, they would have surely made some preparations for it; but Allah was averse to arouse them, so He held them back, and it was said \[to them\], ‘Be seated with those who sit back.’

# 1282

Had they gone forth with you, they would have only added to your troubles, and they would have surely spread rumours in your midst, seeking to cause sedition among you. They have some spies among you, and Allah knows best the wrongdoers.

# 1283

They certainly sought to cause sedition earlier, and upset the matters for you, until the truth came and Allah’s command prevailed, much as they were averse.

# 1284

Among them there are some who say, ‘Give me leave, and do not put me to temptation.’ Look! They have already fallen into temptation and indeed hell besieges the faithless.

# 1285

If some good should befall you, it upsets them; but if an adversity befalls you, they say, ‘We had already taken our precautions in advance,’ and they go away boasting.

# 1286

Say, ‘Nothing will befall us except what Allah has ordained for us. He is our master, and in Allah let all the faithful put their trust.’

# 1287

Say, ‘Do you not await one of the two excellent things to happen to us? But we await that Allah shall visit on you a punishment, from Him, or by our hands. So wait! We too are waiting along with you.’

# 1288

Say, ‘Spend willingly or unwillingly, it shall never be accepted from you; for you are indeed a transgressing lot.’

# 1289

Nothing stops their charities from being accepted except that they have no faith in Allah and His Apostle and do not perform the prayer but lazily, and do not spend but reluctantly.

# 1290

So let not their wealth and children impress you: Allah only desires to punish them with these in the life of this world, and that their souls may depart while they are faithless.

# 1291

They swear by Allah that they belong to you, but they do not belong to you. Rather, they are a frightened lot.

# 1292

If they could find a refuge, or a hideout, or a hole \[to creep into\], they would turn to it in frantic haste.

# 1293

There are some of them who blame you regarding \[the distribution of\] the charities: if they are given from them, they are pleased, but if they are not given from them, behold, they are displeased.

# 1294

\[It would have been better\] if they had been pleased with what Allah and His Apostle gave them, and had said, ‘Allah is sufficient for us; Allah and His Apostle will give to us out of His grace. Indeed to Allah do we eagerly turn.’

# 1295

The charities are only for the poor and the needy, and those employed to collect them, and those whose hearts are to be reconciled, and for \[the freedom of\] the slaves and the debtors, and in the way of Allah, and for the traveller. \[This is\] an ordinance from Allah, and Allah is all-knowing, all-wise.

# 1296

Among them are those who torment the Prophet, and say, ‘He is an ear.’ Say, ‘An ear that is good for you. He has faith in Allah and trusts the faithful, and is a mercy for those of you who have faith.’ As for those who torment the Apostle of Allah, there is a painful punishment for them.

# 1297

They swear to you by Allah, to please you; but Allah and His Apostle are worthier that they should please Him, should they be faithful.

# 1298

Do they not know that whoever opposes Allah and His Apostle, there awaits him the Fire of hell, to remain in it \[forever\]? That is the great disgrace.

# 1299

The hypocrites are apprehensive lest a surah should be sent down against them, informing them about what is in their hearts. Say, ‘Go on deriding. Allah will indeed bring out what you are apprehensive of.’

# 1300

If you question them \[regarding their conduct\], they will surely say, ‘We were just gossiping and amusing ourselves.’ Say, ‘Were you deriding Allah, His signs, and His apostles?

# 1301

Do not make excuses. You have disbelieved after your faith.’ If We forgive a group among you, We will punish another group, for they have been guilty.

# 1302

The hypocrites, men and women, are all alike: they bid what is wrong and forbid what is right; and are tight-fisted. They have forgotten Allah, so He has forgotten them. The hypocrites are indeed the transgressors.

# 1303

Allah has promised the hypocrites, men and women, and the faithless, the Fire of hell, to remain in it \[forever\]. That suffices them. Allah has cursed them, and there is a lasting punishment for them.

# 1304

\[Hypocrites! Your case is\] similar to those who were before you, who were more powerful than you and more abounding in wealth and children: they enjoyed their share \[of worldly existence\]; you too enjoy your share, just like those who were before you enjoyed their share, and you have gossiped \[impiously\] as they gossiped. They are the ones whose works have failed in this world and the Hereafter; and it is they who are the losers.

# 1305

Has there not come to them the account of those who were before them—the people of Noah, ‘Ad, and Tham£d, and the people of Abraham, the inhabitants of Midian, and the towns that were overturned? Their apostles brought them manifest proofs. So it was not Allah who wronged them, but it was they who used to wrong themselves.

# 1306

But the faithful, men and women, are comrades of one another: they bid what is right and forbid what is wrong and maintain the prayer, give the zakat, and obey Allah and His Apostle. It is they to whom Allah will soon grant His mercy. Indeed Allah is all-mighty, all-wise.

# 1307

Allah has promised the faithful, men and women, gardens with streams running in them, to remain in them \[forever\], and good dwellings in the Gardens of Eden. Yet Allah’s pleasure is greater \[than all these\]; that is the great success.

# 1308

O Prophet! Wage jihad against the faithless and the hypocrites, and be severe with them. Their refuge shall be hell, and it is an evil destination.

# 1309

They swear by Allah that they did not say it. But they certainly did utter the word of unfaith and renounced faith after their Islam. They contemplated what they could not achieve, and they were vindictive only because Allah and His Apostle had enriched them out of His grace. Yet if they repent, it will be better for them; but if they turn away, Allah shall punish them with a painful punishment in this world and the Hereafter, and they shall not find on the earth any guardian or helper.

# 1310

Among them are those who made a pledge with Allah: ‘If He gives us out of His grace, we will surely give the zakat and we will surely be among the righteous.’

# 1311

But when He gave them out of His grace, they begrudged it and turned away, being disregardful.

# 1312

So He caused hypocrisy to ensue in their hearts until the day they will encounter Him, because of their going back on what they had promised Allah and because of the lies they used to tell.

# 1313

Do they not know that Allah knows their secret \[thoughts\] and \[hears\] their secret talks, and that Allah is knower of all that is Unseen?

# 1314

Those who blame the voluntary donors from among the faithful concerning the charities—and as for those who do not find \[anything\] except \[what\] their means \[permit\], they ridicule them—Allah shall put them to ridicule, and there is a painful punishment for them.

# 1315

Whether you plead forgiveness for them or do not plead forgiveness for them, even if you plead forgiveness for them seventy times, Allah shall never forgive them because they defied Allah and His Apostle; and Allah does not guide the transgressing lot.

# 1316

Those who were left behind boasted for sitting back against \[the command of\] the Apostle of Allah, and were reluctant to wage jihad with their possessions and persons in the way of Allah, and they said, ‘Do not go forth in this heat.’ Say, The fire of hell is severer in heat, should they understand.

# 1317

So let them laugh a little; much will they weep as a requital for what they used to earn.

# 1318

If Allah brings you back \[from the battlefront\] to a group of them and they seek your permission to go forth, say, ‘You shall never go forth with me, and you shall not fight with me against any enemy. You were indeed pleased to sit back the first time, so sit back with those who stay behind.’

# 1319

And never pray over any of them when he dies, nor stand at his graveside. They indeed defied Allah and His Apostle and died as transgressors.

# 1320

Let not their possessions or their children impress you. Allah only desires to punish them with these in this world, and that their souls may depart while they are faithless.

# 1321

When a surah is sent down \[declaring\]: ‘Have faith in Allah, and wage jihad along with His Apostle, the affluent among them ask you for leave, and say, ‘Let us remain with those who sit back.’

# 1322

They are pleased to be with those who stay back, and their hearts have been sealed. So they do not understand.

# 1323

But the Apostle and the faithful who are with him wage jihad with their possessions and persons, and to such belong all the blessings, and it is they who are the felicitous.

# 1324

Allah has prepared for them gardens with streams running in them, to remain in them \[forever\]. That is the great success.

# 1325

Some of the Bedouins who sought to be excused came, so that they may be granted leave \[to stay back\]; while those who lied to Allah and His Apostle sat back. Soon there shall visit the faithless among them a painful punishment.

# 1326

There is no blame on the weak, nor on the sick, nor on those who do not find anything to spend, so long as they are sincere to Allah and His Apostle. There is no \[cause for\] blaming the virtuous, and Allah is all-forgiving, all-merciful.

# 1327

Nor \[is there any blame\] on those to whom, when they came to you to provide them with a mount, you said, ‘I do not find any mount for you,’ and they turned back, their eyes flowing with tears, grieved because they did not find any means to spend.

# 1328

The blame lies only on those who ask leave of you \[to stay behind\] though they are well-off. They are pleased to be with those who stay back; Allah has set a seal on their hearts, so they do not know \[the outcome of their conduct\].

# 1329

They will offer you excuses when you return to them. Say, ‘Do not make excuses; we will never believe you. Allah has informed us of your state of affairs. Allah and His Apostle will observe your conduct, then you will be returned to the Knower of the sensible and the Unseen, and He will inform you concerning what you used to do.’

# 1330

They will swear to you by Allah when you return to them, that you may leave them alone. So leave them alone. They are indeed filth, and their refuge shall be hell, a requital for what they used to earn.

# 1331

They swear to you that you may be reconciled to them. But even if you are reconciled to them, Allah shall not be reconciled to the transgressing lot.

# 1332

The Bedouins are more obdurate in unfaith and hypocrisy, and more apt to be ignorant of the precepts that Allah has sent down to His Apostle, and Allah is all-knowing, all-wise.

# 1333

Among the Bedouins are those who regard what they spend as a loss, and they watch for a reversal of your fortunes. Theirs shall be an adverse turn of fortune, and Allah is all-hearing, all-knowing.

# 1334

Yet among the Bedouins are \[also\] those who believe in Allah and the Last Day, and regard what they spend as \[a means of attaining\] nearness to Allah and the blessings of the Apostle. Now, it shall indeed bring them nearness, and Allah will admit them into His mercy. Indeed Allah is all-forgiving, all-merciful.

# 1335

The early vanguard of the Emigrants and the Helpers and those who followed them in virtue—Allah is pleased with them and they are pleased with Him, and He has prepared for them gardens with streams running in them, to remain in them forever. That is the great success.

# 1336

There are hypocrites among the Bedouins around you and among the townspeople of Madinah, steeped in hypocrisy. You do not know them; We know them, and We will punish them twice, then they shall be consigned to a great punishment.

# 1337

\[There are\] others who have confessed to their sins, having mixed up righteous conduct with other that was evil. Maybe Allah will accept their repentance. Indeed Allah is all-forgiving, all-merciful.

# 1338

Take charity from their possessions to cleanse them and purify them thereby, and bless them. Indeed your blessing is a comfort to them, and Allah is all-hearing, all-knowing.

# 1339

Do they not know that it is Allah who accepts the repentance of His servants and receives the charities, and that it is Allah who is the All-clement, the All-merciful?

# 1340

And say, ‘Go on working: Allah will see your conduct, and His Apostle and the faithful \[as well\], and you will be returned to the Knower of the sensible and the Unseen, and He will inform you concerning what you used to do.

# 1341

\[There are\] others waiting Allah’s edict: either He shall punish them, or turn to them clemently, and Allah is all-knowing, all-wise.

# 1342

As for those who took to a mosque for sabotage and for defiance, and to cause division among the faithful, and for the purpose of ambush \[used\] by those who have fought Allah and His Apostle before—they will surely swear, ‘We desired nothing but good,’ and Allah bears witness that they are indeed liars.

# 1343

Do not stand in it ever! A mosque founded on Godwariness from the \[very\] first day is worthier that you stand in it \[for prayer\]. Therein are men who love to keep pure, and Allah loves those who keep pure.

# 1344

Is he who founds his building on Godwariness and \[the pursuit of Allah’s\] pleasure better-off or he who founds his building on the brink of a collapsing bank which collapses with him into the fire of hell? Allah does not guide the wrongdoing lot.

# 1345

The building they have built will never cease to be \[a source of\] disquiet in their hearts until their hearts are cut into pieces, and Allah is all-knowing, all-wise.

# 1346

Indeed Allah has bought from the faithful their souls and their possessions for paradise to be theirs: they fight in the way of Allah, kill, and are killed. A promise binding upon Him in the Torah and the Evangel and the Quran. And who is truer to his promise than Allah? So rejoice in the bargain you have made with Him, and that is the great success.

# 1347

\[The faithful are\] penitent, devout, celebrators of Allah’s praise, wayfarers, who bow \[and\] prostrate \[in prayer\], bid what is right and forbid what is wrong, and keep Allah’s bounds—and give good news to the faithful.

# 1348

The Prophet and the faithful may not plead for the forgiveness of the polytheists, even if they should be \[their\] relatives, after it has become clear to them that they will be the inmates of hell.

# 1349

Abraham’s pleading forgiveness for his father was only to fulfill a promise he had made him. So when it became manifest to him that he was an enemy of God, he repudiated him. Indeed Abraham was most plaintive and forbearing.

# 1350

Allah does not lead any people astray after He has guided them until He has made clear to them what they should beware of. Indeed Allah has knowledge of all things.

# 1351

Indeed to Allah belongs the kingdom of the heavens and the earth. He gives life and brings death. And besides Allah you do not have any guardian or helper.

# 1352

Certainly Allah turned clemently to the Prophet and the Emigrants and the Helpers, who followed him in the hour of difficulty, after the hearts of a part of them were about to swerve. Then He turned clemently to them—indeed, He is most kind and merciful to them

# 1353

—and to the three who were left behind. When the earth became narrow for them with \[all\] its expanse, and their own souls weighed heavily on them, and they knew that there was no refuge from Allah except in Him, then He turned clemently toward them so that they might be penitent. Indeed Allah is the All-clement, the All-merciful.

# 1354

O you who have faith! Be wary of Allah, and be with the Truthful.

# 1355

It is not fitting for the people of Madinah and the Bedouins around them to hang back behind the Apostle of Allah and prefer their own lives to his life. That is because they neither experience any thirst, nor fatigue, nor hunger, in the way of Allah, nor do they tread any ground enraging the faithless, nor do they gain any ground against an enemy but a righteous deed is written for them on its account. Indeed Allah does not waste the reward of the virtuous.

# 1356

And neither do they incur any expense, big or small, nor do they cross any valley, but it is written to their account, so that Allah may reward them by the best of what they used to do.

# 1357

Yet it is not for the faithful to go forth en masse. But why should not there a group from each of their sections go forth to become learned in religion, and to warn their people when they return to them, so that they may beware?

# 1358

O you who have faith! Fight the faithless who are in your vicinity, and let them find severity in you, and know that Allah is with the Godwary.

# 1359

Whenever a surah is sent down, there are some of them who say, ‘Which of you did it increase in faith?’ As for those who have faith, it increases them in faith, and they rejoice.

# 1360

But as for those in whose heart is a sickness, it only adds defilement to their defilement, and they die while they are faithless.

# 1361

Do they not see that they are tried once or twice every year? Yet they neither repent, nor do they take admonition.

# 1362

Whenever a surah is sent down they look at one another: ‘Is anybody observing you?’ Then they slip away. Allah has turned aside their hearts, for they are a people who do not understand.

# 1363

There has certainly come to you an apostle from among yourselves. Grievous to him is your distress; he has deep concern for you, and is most kind and merciful to the faithful.

# 1364

But if they turn their backs \[on you\], say, ‘Allah is sufficient for me. There is no god except Him. In Him I have put my trust and He is the Lord of the Great Throne.’

# 1365

Alif, Lam, Ra. These are the signs of the Wise Book.

# 1366

Does it seem odd to these people that We have revealed to a man from among themselves, \[declaring\], ‘Warn mankind, and give good news to the faithful that they are in good standing with their Lord’? The faithless say, ‘This is indeed a plain magician.’

# 1367

Indeed your Lord is Allah, who created the heavens and the earth in six days, and then settled on the Throne, directing the command. There is no intercessor, except by His leave. That is Allah, your Lord! So worship Him. Will you not then take admonition?

# 1368

To Him will be the return of you all; \[that is\] Allah’s true promise. Indeed, He originates the creation, then He will bring it back that He may reward with justice those who have faith and do righteous deeds. As for the faithless, they shall have boiling water for drink, and a painful punishment because of what they used to defy.

# 1369

It is He who made the sun a radiance and the moon a light, and ordained its phases that you might know the number of years and the calculation \[of time\]. Allah did not create all that except with justice. He elaborates the signs for a people who have knowledge.

# 1370

Indeed in the alternation of night and day, and whatever Allah has created in the heavens and the earth, there are surely signs for a people who are Godwary.

# 1371

Indeed those who do not expect to encounter Us and who are pleased with the life of this world and satisfied with it, and those who are oblivious of Our signs

# 1372

—it is they whose refuge shall be the Fire because of what they used to earn.

# 1373

Indeed those who have faith and do righteous deeds, their Lord guides them by the means of their faith. Streams will run for them in gardens of bliss.

# 1374

Their call therein will be, ‘O Allah! Immaculate are You!’ and their greeting therein will be, ‘Peace!’ and their concluding call, ‘All praise belongs to Allah, the Lord of all the worlds.’

# 1375

Were Allah to hasten ill for mankind with their haste for good, their term would have been over. But We leave those who do not expect to encounter Us bewildered in their rebellion.

# 1376

When distress befalls man, he supplicates Us, \[lying\] on his side, sitting, or standing; but when We remove his distress, he passes on as if he had never supplicated Us concerning the distress that had befallen him. What they have been doing is thus presented as decorous to the transgressors.

# 1377

Certainly We destroyed generations before you when they perpetrated wrongs: their apostles brought them manifest proofs, but they would not have faith. Thus do We requite the guilty lot.

# 1378

Then We made you successors on the earth after them that We may observe how you will act.

# 1379

When Our manifest signs are recited to them, those who do not expect to encounter Us say, ‘Bring a Quran other than this, or alter it.’ Say, ‘I may not alter it of my own accord. I follow only what is revealed to me. Indeed should I disobey my Lord, I fear the punishment of a tremendous day.’

# 1380

Say, ‘Had Allah \[so\] wished, I would not have recited it to you, nor would He have made it known to you, for I have dwelled among you for a lifetime before it. Do you not exercise your reason?’

# 1381

So who is a greater wrongdoer than him who fabricates a lie against Allah, or denies His signs? Indeed the guilty will not be felicitous.

# 1382

They worship besides Allah that which neither causes them any harm, nor brings them any benefit, and they say, ‘These are our intercessors with Allah.’ Say, ‘Will you inform Allah about something He does not know in the heavens or on the earth?’ Immaculate is He and exalted above \[having\] any partners that they ascribe \[to Him\]!

# 1383

Mankind were but a single \[religious\] community; then they differed. And were it not for a prior decree of your Lord, decision would have been made between them concerning that about which they differ.

# 1384

They say, ‘Why has not some sign been sent down to him from his Lord?’ Say, ‘\[The knowledge of\] the Unseen belongs only to Allah. So wait. I too am waiting along with you.’

# 1385

When We let people taste \[Our\] mercy after a distress that has befallen them, behold, they scheme against Our signs! Say, ‘Allah is more swift at devising.’ Indeed Our messengers write down what you scheme.

# 1386

It is He who carries you across land and sea. When you are in the ships, and they sail along with them with a favourable wind, exulting in it, there comes upon them a tempestuous wind and waves assail them from every side, and they think that they are besieged, they invoke Allah putting exclusive faith in Him, ‘If You deliver us from this, we will surely be among the grateful.’

# 1387

But when He delivers them, behold, they commit violations on the earth unduly! O mankind! Your violations are only to your own detriment. \[These are\] the wares of the life of this world; then to Us will be your return, whereat We will inform you concerning what you used to do.

# 1388

The parable of the life of this world is that of water which We send down from the sky. It mingles with the earth’s vegetation from which humans and cattle eat. When the earth puts on its luster and is adorned, and its inhabitants think they have power over it, Our edict comes to it, by night or day, whereat We turn it into a mown field, as if it did not flourish the day before. Thus do We elaborate the signs for a people who reflect.

# 1389

Allah invites to the abode of peace, and He guides whomever He wishes to a straight path.

# 1390

Those who are virtuous shall receive the best reward and an enhancement. Neither dust nor abasement shall overcast their faces. They shall be the inhabitants of paradise, and they shall remain in it \[forever\].

# 1391

For those who have committed misdeeds, the requital of a misdeed shall be its like, and they shall be overcast by abasement. They shall have no one to protect \[them\] from Allah. \[They will be\] as if their faces were covered with dark patches of the night. They shall be the inmates of the Fire, and they shall remain in it \[forever\].

# 1392

On the day when We gather them all together, We shall say to those who ascribe partners \[to Allah\], ‘Stay where you are—you and your partners!’ Then We shall set them apart from one another, and their partners will say, ‘It was not us that you worshipped.

# 1393

Allah suffices as a witness between you and us. We were indeed unaware of your worship.’

# 1394

There every soul will examine what it has sent in advance, and they will be returned to Allah, their real master, and what they used to fabricate will forsake them.

# 1395

Say, ‘Who provides for you out of the sky and the earth? Who controls \[your\] hearing and sight, and who brings forth the living from the dead and brings forth the dead from the living, and who directs the command?’ They will say, ‘Allah.’ Say, ‘Will you not then be wary \[of Him\]?’

# 1396

That, then, is Allah, your true Lord. So what is there after the truth except error? Then where are you being led away?

# 1397

Thus the word of your Lord became due against those who transgress, that they shall not have faith.

# 1398

Say, ‘Is there anyone among your partners who originates the creation and then brings it back?’ Say, ‘Allah originates the creation, then He will bring it back.’ Then where do you stray?

# 1399

Say, ‘Is there anyone among your partners who may guide to the truth?’ Say, ‘Allah guides to the truth. Is He who guides to the truth worthier to be followed, or he who is not guided unless shown the way? What is the matter with you? How do you judge?’

# 1400

Most of them just follow conjecture; indeed conjecture is no substitute for the truth. Indeed Allah knows best what they do.

# 1401

This Quran could not have been fabricated by anyone besides Allah; rather, it is a confirmation of what was \[revealed\] before it, and an elaboration of the Book, there is no doubt in it, from the Lord of all the worlds.

# 1402

Do they say, ‘He has fabricated it?’ Say, ‘Then bring a surah like it, and invoke whomever you can, besides Allah, should you be truthful.’

# 1403

Indeed, they deny something whose knowledge they do not comprehend, and whose explanation has not yet come to them. Those who were before them denied likewise. So observe how was the fate of the wrongdoers!

# 1404

Some of them believe in it, and some of them do not believe in it, and your Lord best knows the agents of corruption.

# 1405

If they deny you, say, ‘My deeds belong to me and your deeds belong to you: you are absolved of what I do and I am absolved of what you do.’

# 1406

There are some of them who prick up their ears at you. But can you make the deaf hear even if they do not exercise their reason?

# 1407

There are some of them who observe you. But can you guide the blind even if they do not perceive?

# 1408

Indeed Allah does not wrong people in the least; rather, it is people who wrong themselves.

# 1409

On the day He will gather them \[it will be\] as if they had not remained \[in the world\] except for an hour of the day getting acquainted with one another. They are certainly losers who deny the encounter with Allah, and they are not guided.

# 1410

Whether We show you a part of what We promise them, or take you away \[before that\], \[in any case\] their return will be to Us and Allah will be witness to what they do.

# 1411

There is an apostle for every nation; so when their apostle comes, judgement is made between them with justice, and they are not wronged.

# 1412

They say, ‘When will this promise be fulfilled, should you be truthful?’

# 1413

Say, ‘I have no control over any benefit for myself nor \[over\] any harm except what Allah may wish. There is a time for every nation: when their time comes, they shall not defer it by a single hour nor shall they advance it.’

# 1414

Say, ‘Tell me, should His punishment overtake you by night or day, \[you will not be able to avert it\]; so what part of it do the guilty seek to hasten?’

# 1415

‘What! Do you believe it when it has befallen? Now? While you would seek to hasten it \[earlier\]?!’

# 1416

Then it will be said to those who were wrongdoers, ‘Taste the everlasting punishment. Shall you not be requited for what you used to earn?’

# 1417

They inquire of you, ‘Is it true?’ Say, ‘Yes! By my Lord, it is true, and you cannot frustrate \[Him\].’

# 1418

Were any soul that has done wrong to possess whatever there is on the earth, it would surely offer it for ransom. They will hide their remorse when they sight the punishment; and judgement will be made between them with justice and they will not be wronged.

# 1419

Look! To Allah indeed belongs whatever is in the heavens and the earth. Look! Allah’s promise is indeed true; but most of them do not know.

# 1420

It is He who gives life and brings death, and to Him you shall be brought back.

# 1421

O mankind! There has certainly come to you an advice from your Lord, and a cure for what is in the breasts, and a guidance and mercy for the faithful.

# 1422

Say, ‘In Allah’s grace and His mercy—let them rejoice in that! It is better than what they amass.’

# 1423

Say, ‘Have you regarded what Allah has sent down for you of \[His\] provision, whereupon you have made some of it unlawful and \[some\] lawful?’ Say, ‘Did Allah give you the sanction \[to do so\], or do you fabricate a lie against Allah?’

# 1424

What is the idea of those who fabricate lies against Allah \[concerning their situation\] on the Day of Resurrection? Indeed Allah is gracious to mankind, but most of them do not give thanks.

# 1425

You do not engage in any work, neither do you recite any part of the Quran, nor do you perform any deed without Our being witness over you when you are engaged therein. Not an atom’s weight escapes your Lord in the earth or in the sky, nor \[is there\] anything smaller than that nor bigger, but it is in a manifest Book.

# 1426

Look! The friends of Allah will indeed have no fear nor will they grieve

# 1427

—those who have faith and are Godwary.

# 1428

For them is good news in the life of this world and in the Hereafter. (There is no altering the words of Allah.) That is the great success.

# 1429

Do not grieve at their remarks; indeed all might belongs to Allah; He is the All-hearing, the All-knowing.

# 1430

Look! To Allah indeed belongs whoever is in the heavens and whoever is on the earth. What do they pursue who invoke partners besides Allah? They merely follow conjectures and they just make surmises.

# 1431

It is He who made the night for you, that you may rest in it, and the day to provide visibility. There are indeed signs in that for people who listen.

# 1432

They say, ‘Allah has taken a son!’ Immaculate is He! He is the All-sufficient. To Him belongs whatever is in the heavens and whatever is in the earth. You have no authority for this \[statement\]. Do you attribute to Allah what you do not know?

# 1433

Say, ‘Indeed those who fabricate lies against Allah will not be felicitous.’

# 1434

An enjoyment in this world; then to Us shall be their return, then We shall make them taste the severe punishment because of what they used to defy.

# 1435

Relate to them the account of Noah when he said to his people, ‘O my people! If my stay \[among you\] be hard on you and \[also\] my reminding you of Allah’s signs, \[for my part\] I have put my trust in Allah. So conspire together, along with your partners, leaving nothing vague in your plan, then carry it out against me without giving me any respite.

# 1436

If you turn your back \[on me\], I do not ask any reward from you; my reward lies only with Allah and I have been commanded to be of those who submit \[to Allah\].’

# 1437

But they impugned him. So We delivered him and those who were with him in the ark and We made them the successors, and We drowned those who denied Our signs. So observe how was the fate of those who were warned!

# 1438

Then after him We sent \[other\] apostles to their people. They brought them manifest proofs, but they would not believe something they had denied before. Thus do We seal the hearts of the transgressors.

# 1439

Then, after them, We sent Moses and Aaron to Pharaoh and his elite with Our signs, but they acted arrogantly and they were a guilty lot.

# 1440

When the truth from Us came to them, they said, ‘This is indeed plain magic!’

# 1441

Moses said, ‘Do you say of the truth when it comes to you \[that it is magic\]? Is this magic? Magicians do not find salvation.’

# 1442

They said, ‘Have you come to us to turn us away from what we found our fathers following, so that supremacy may be yours in the land? We will not believe in the two of you.’

# 1443

Pharaoh said, ‘Bring me every expert magician.’

# 1444

So when the magicians came, Moses said to them, ‘Throw down what you have to throw.’

# 1445

So when they threw down \[their sticks and ropes\], Moses said, ‘What you have produced is magic. Indeed Allah will bring it to naught presently. Indeed Allah does not foster the efforts of those who cause corruption.

# 1446

Allah will confirm the truth with His words, though the guilty should be averse.’

# 1447

But none believed in Moses except some youths from among his people, for the fear of Pharaoh and his elite that he would persecute them. For Pharaoh was indeed a tyrant in the land, and indeed he was an unrestrained \[despot\].

# 1448

And Moses said, ‘O my people! If you have faith in Allah, put your trust in Him, if you have submitted \[to Him\].’

# 1449

Whereat they said, ‘In Allah we have put our trust.’ ‘Our Lord! Do not make us a \[means of\] test for the wrongdoing lot,

# 1450

and deliver us by Your mercy from the faithless lot.’

# 1451

We revealed to Moses and his brother \[saying\], ‘Settle your people in the city, and let your houses face each other, and maintain the prayer, and give good news to the faithful.’

# 1452

Moses said, ‘Our Lord! You have given Pharaoh and his elite glamour and wealth in the life of this world, our Lord, that they may lead \[people\] astray from Your way! Our Lord! Blot out their wealth and harden their hearts so that they do not believe until they sight the painful punishment.’

# 1453

Said He, ‘Your supplication has already been granted. So be steadfast, and do not follow the way of those who do not know.’

# 1454

We carried the Children of Israel across the sea, whereat Pharaoh and his troops pursued them, out of defiance and aggression. When overtaken by drowning, he called out, ‘I believe that there is no god except Him in whom the Children of Israel believe, and I am one of those who submit \[to Him\]!’

# 1455

\[He was told,\] ‘What! Now? When you have been disobedient heretofore and were among the agents of corruption?!

# 1456

So today We shall deliver your body so that you may be a sign for those who come after you.’ Indeed many of the people are oblivious to Our signs.

# 1457

Certainly We settled the Children of Israel in a worthy settlement and We provided them with all the good things, and they did not differ until \[after\] the knowledge had come to them. Your Lord will indeed judge between them on the Day of Resurrection concerning that about which they used to differ.

# 1458

So if you are in doubt about what We have sent down to you, ask those who read the Book \[revealed\] before you. The truth has certainly come to you from your Lord; so do not be among the skeptics.

# 1459

And do not be of those who deny the signs of Allah, \[for\] then you shall be among the losers.

# 1460

Indeed those against whom your Lord’s judgement has become due will not have faith,

# 1461

even though every sign were to come to them, until they sight the painful punishment.

# 1462

Why has there not been any town that might believe, so that its belief might benefit it, except the people of Jonah? When they believed, We removed from them the punishment of disgrace in the life of this world, and We provided for them for a while.

# 1463

Had your Lord wished, all those who are on earth would have believed. Would you then force people until they become faithful?

# 1464

No soul may have faith except by Allah’s leave, and He lays defilement on those who do not exercise their reason.

# 1465

Say, ‘Observe what is in the heavens and the earth.’ But neither signs nor warnings avail a people who have no faith.

# 1466

Do they await anything except the like of the days of those who passed away before them? Say, ‘Then wait! I too am waiting along with you.’

# 1467

Then We shall deliver Our apostles and those who have faith. Thus, it is a must for Us to deliver the faithful.

# 1468

Say, ‘O people! if you are in doubt about my religion, then \[know that\] I do not worship those whom you worship besides Allah. Rather, I worship only Allah, who causes you to die, and I have been commanded to be among the faithful,

# 1469

and that: ‘‘Dedicate yourself to the religion, as a Hanif, and never be one of the polytheists.

# 1470

Nor invoke besides Allah that which neither benefits you nor can do you any harm. For if you do so, then you will indeed be among the wrongdoers.’’ ’

# 1471

Should Allah visit you with some distress, there is no one to remove it except Him; and should He desire any good for you, none can stand in the way of His grace: He grants it to whomever He wishes of His servants, and He is the All-forgiving, the All-merciful.

# 1472

Say, ‘O mankind! The truth has already come to you from your Lord. Whoever is guided, is guided only for \[the good of\] his own soul, and whoever goes astray, goes astray only to its detriment, and it is not my business to watch over you.’

# 1473

And follow that which is revealed to you, and be patient until Allah issues \[His\] judgement, and He is the best of judges.

# 1474

Alif, Lam Ra. \[This is\] a Book, whose signs have been made definitive and then elaborated, from One \[who is\] all-wise, all-aware,

# 1475

declaring: ‘Worship no one but Allah. I am indeed a warner to you from Him and a bearer of good news.

# 1476

Plead with your Lord for forgiveness, then turn to Him penitently. He will provide you with a good provision for a specified term and grant His grace to every meritorious person. But if you turn your backs \[on Him\], indeed I fear for you the punishment of a terrible day.

# 1477

To Allah will be your return, and He has power over all things.’

# 1478

Look! They fold up their breasts to hide \[their secret feelings\] from Him. Look! When they draw their cloaks over their heads, He knows whatever they keep secret and whatever they disclose. Indeed, He knows best whatever is in the breasts.

# 1479

There is no animal on the earth, but that its sustenance lies with Allah, and He knows its \[enduring\] abode and its temporary place of lodging. Everything is in a manifest Book.

# 1480

It is He who created the heavens and the earth in six days—and His Throne was \[then\] upon the waters—that He may test you \[to see\] which of you is best in conduct. Yet if you say, ‘You will indeed be raised up after death,’ the faithless will surely say, ‘This is nothing but plain magic.’

# 1481

And if We defer their punishment until a certain time, they will surely say, ‘What holds it back?’ Look! On the day it overtakes them it shall not be turned away from them, and they will be besieged by what they used to deride.

# 1482

If We let man taste a mercy from Us, and then withdraw it from him, he becomes despondent, ungrateful.

# 1483

And if We let him have a taste of Our blessings after adversities have befallen him, he will surely say, ‘All ills have left me.’ Indeed, he becomes a vain braggart,

# 1484

excepting those who are patient and do righteous deeds. For such there will be forgiveness and a great reward.

# 1485

\[Look out\] lest you should disregard aught of what has been revealed to you, and be upset because they say, ‘Why has not a treasure been sent down to him, or \[why does\] not an angel accompany him?’ You are only a warner, and Allah watches over all things.

# 1486

Do they say, ‘He has fabricated it?’ Say, ‘Then bring ten surahs like it, fabricated, and invoke whomever you can, besides Allah, should you be truthful.’

# 1487

But if they do not respond to you, know that it has been sent down by Allah’s knowledge, and that there is no god except Him. Will you, then, submit \[to Allah\]?

# 1488

As for those who desire the life of this world and its glitter, We will recompense them fully for their works therein, and they shall not be underpaid in it.

# 1489

They are the ones for whom there shall be nothing in the Hereafter but Fire: what they had accomplished in the world has failed, and their works have come to naught.

# 1490

Is he who stands on a manifest proof from his Lord, and whom a witness of his own \[family\] follows? And before him there was the Book of Moses, a guide and mercy. It is they who have faith in it, and whoever defies him from among the factions, the Fire is their tryst. So do not be in doubt about it; it is the truth from your Lord, but most people do not have faith.

# 1491

Who is a greater wrongdoer than him who fabricates a lie against Allah? Such shall be presented before their Lord, and the witnesses will say, ‘It is these who lied against their Lord.’ Behold! The curse of Allah is upon the wrongdoers

# 1492

—those who bar \[others\] from the way of Allah, and seek to make it crooked, and disbelieve in the Hereafter.

# 1493

They cannot frustrate \[Allah\] on the earth, nor do they have besides Allah any guardian. For them the punishment shall be doubled, for they could neither listen, nor did they use to see.

# 1494

They are the ones who have ruined their souls, and what they used to fabricate has forsaken them.

# 1495

Undoubtedly, they are the ones who will be the biggest losers in the Hereafter.

# 1496

Indeed those who have faith and do righteous deeds and are humble before their Lord—they shall be the inhabitants of paradise, and they shall remain in it \[forever\].

# 1497

The parable of the two parties is that of one who is blind and deaf and one who sees and hears. Are they equal in comparison? Will you not then take admonition?

# 1498

Certainly We sent Noah to his people \[to declare\]: ‘Indeed I am a manifest warner to you.

# 1499

Worship none but Allah. Indeed I fear for you the punishment of a painful day.’

# 1500

But the elite of the faithless from among his people said, ‘We do not see you to be anything but a human being like ourselves, and we do not see anyone following you except those who are simpleminded riffraff from our midst. Nor do we see that you have any merit over us. Indeed, we consider you to be liars.’

# 1501

He said, ‘O my people! Tell me, should I stand on a manifest proof from my Lord, and He has granted me His own mercy—though it should be invisible to you—shall we force it upon you while you are averse to it?

# 1502

O my people! I do not ask you any material reward for it. My reward lies only with Allah. But I will not drive away those who have faith: they will indeed encounter their Lord. But I see that you are an ignorant lot.

# 1503

O my people! Who would come to my help against Allah were I to drive them away? Will you not then take admonition?

# 1504

I do not say to you that I possess the treasuries of Allah, neither do I know the Unseen. I do not claim to be an angel, neither do I say of those who are despicable in your eyes that Allah will not grant them any good—Allah knows best what is in their hearts—for then I would indeed be a wrongdoer.’

# 1505

They said, ‘O Noah, you have disputed with us already, and you have disputed with us exceedingly. Now bring us what you threaten us with, should you be truthful.

# 1506

He said, ‘Allah will indeed bring it on you if He wishes, and you cannot frustrate \[Him\].

# 1507

My exhorting will not benefit you, much as I may seek to exhort you, if Allah desires to consign you to perversity. He is your Lord, and to Him you shall be brought back.’

# 1508

Do they say, ‘He has fabricated it?’ Say, ‘Should I have fabricated it, then my guilt will be upon me, and I am absolved of your guilty conduct.’

# 1509

It was revealed to Noah: ‘None of your people will believe except those who already have faith; so do not sorrow for what they used to do.

# 1510

Build the ark before Our eyes and by Our revelation, and do not plead with Me for those who are wrongdoers: they shall indeed be drowned.’

# 1511

As he was building the ark, whenever the elders of his people passed by him, they would ridicule him. He said, ‘If you ridicule us \[today\], we shall ridicule you \[tomorrow\] just as you ridicule us \[now\].

# 1512

Soon you will know whom a disgraceful punishment will overtake and on whom a lasting punishment will descend.’

# 1513

When Our edict came and the oven gushed \[a stream of water\], We said, ‘Carry in it a pair of every kind \[of animal\], along with your family—except those \[of them\] against whom the edict has already been given—and those who have faith.’ And none believed with him except a few.

# 1514

He said, ‘Board it: In the Name of Allah it shall set sail and cast anchor. Indeed my Lord is all-forgiving, all-merciful.’

# 1515

And it sailed along with them amid waves \[rising\] like mountains. Noah called out to his son, who stood aloof, ‘O my son! ‘Board with us, and do not be with the faithless!’

# 1516

He said, ‘I shall take refuge on a mountain; it will protect me from the flood.’ He said, ‘There is none today who can protect from Allah’s edict, except someone upon whom He has mercy.’ Then the waves came between them, and he was among those who were drowned.

# 1517

Then it was said, ‘O earth, swallow your water! O sky, leave off!’ The waters receded; the edict was carried out, and it settled on \[Mount\] Judi. Then it was said, ‘Away with the wrongdoing lot!’

# 1518

Noah called out to his Lord, and said, ‘My Lord! My son is indeed from my family. Your promise is indeed true, and You are the fairest of all judges.’

# 1519

Said He, ‘O Noah! Indeed, He is not of your family. Indeed, he is \[personification of\] unrighteous conduct. So do not ask Me \[something\] of which you have no knowledge. I advise you lest you should be among the ignorant.’

# 1520

He said, ‘My Lord! I seek Your protection lest I should ask You something of which I have no knowledge. If You do not forgive me and have mercy upon me I shall be among the losers.’

# 1521

It was said, ‘O Noah! Disembark in peace from Us and with \[Our\] blessings upon you and upon nations \[to descend\] from those who are with you, and nations whom We shall provide for, then a painful punishment from Us shall befall them.’

# 1522

These are accounts of the Unseen, which We reveal to you. Neither you nor your people used to know them before this. So be patient. Indeed the outcome will be in favour of the Godwary.

# 1523

And to ‘Ad \[We sent\] Hud, their brother. He said, ‘O my people! Worship Allah. You have no other god besides Him: you merely fabricate \[the deities that you worship\].

# 1524

‘O my people! I do not ask you any reward for it. My reward lies only with Him who originated me. Do you not exercise your reason?

# 1525

‘O my people! Plead with your Lord for forgiveness, then turn to Him penitently: He will send copious rains for you from the sky, and add power to your \[present\] power. So do not turn your backs \[on Him\] as guilty ones.’

# 1526

They said, ‘O Hud, you have not brought us any manifest proof. We are not going to abandon our gods for what you say, and we are not going to believe you.

# 1527

All we say is that some of our gods have visited you with some evil.’ He said, ‘I call Allah to witness—and you too be \[my\] witnesses—that I repudiate what you take as \[His\] partners

# 1528

besides Him. Now try out your stratagems against me, together, without granting me any respite.

# 1529

Indeed I have put my trust in Allah, my Lord and your Lord. There is no living being but He holds it by its forelock. Indeed my Lord is on a straight path.

# 1530

But if you turn your backs \[on me\], then \[know that\] I have communicated to you whatever I was sent to you with. My Lord will make another people succeed you, and you will not hurt Allah in the least. Indeed my Lord is watchful over all things.’

# 1531

When Our edict came, We delivered Hud and the faithful who were with him, by a mercy from Us, and We delivered them from a harsh punishment.

# 1532

Such were \[the people of\] Ad: they impugned the signs of their Lord and disobeyed His apostles, and followed the dictates of every obstinate tyrant.

# 1533

So they were pursued by a curse in this world and on the Day of Resurrection. Behold! ‘Ad indeed defied their Lord. Now, away with ‘Ad, the people of Hud!

# 1534

And to Thamud \[We sent\] Salih, their brother. He said, ‘O my people! Worship Allah. You have no other god besides Him. He brought you forth from the earth and made it your habitation. So plead with Him for forgiveness, then turn to Him penitently. My Lord is indeed nearmost \[and\] responsive.’

# 1535

They said, ‘O Salih! You were a source of hope to us before this. Do you forbid us to worship what our fathers have been worshiping? Indeed we have grave doubts concerning that to which you invite us.’

# 1536

He said, ‘O my people! Tell me, should I stand on a manifest proof from my Lord, and He has granted me His own mercy, who will protect me from Allah should I disobey Him? For then you will increase me in nothing but loss.

# 1537

O my people! This she-camel of Allah is a sign for you. Let her graze \[freely\] in Allah’s land, and do not cause her any harm, for then you shall be seized by a prompt punishment.’

# 1538

But they hamstrung her, whereupon he said, ‘Enjoy yourselves in your homes for three days: that is a promise not to be belied!’

# 1539

So when Our edict came, We delivered Salih and the faithful who were with him by a mercy from Us and from the \[punishment and\] disgrace of that day. Your Lord is indeed the All-strong, the All-mighty.

# 1540

The Cry seized those who were wrongdoers, and they lay lifeless prostrate in their homes,

# 1541

as if they had never lived there. Behold! Thamud indeed defied their Lord. Now, away with Thamud!

# 1542

Certainly Our messengers came to Abraham with the good news, and said, ‘Peace!’ ‘Peace!’ He replied. Presently he brought \[for them\] a roasted calf.

# 1543

But when he saw their hands not reaching for it, he took them amiss and felt a fear of them. They said, ‘Do not be afraid. We have been sent to the people of Lot.’

# 1544

His wife, standing by, laughed as We gave her the good news of \[the birth of\] Isaac, and of Jacob, after Isaac.

# 1545

She said, ‘Oh, my! Shall I, an old woman, bear \[children\], and \[while\] this husband of mine is an old man?! That is indeed an odd thing!’

# 1546

They said, ‘Are you amazed at Allah’s dispensation? \[That is\] Allah’s mercy and His blessings upon you, members of the household. Indeed He is all-laudable, all-glorious.’

# 1547

So when the awe had left Abraham and the good news had reached him, he pleaded with Us concerning the people of Lot.

# 1548

Abraham was indeed most forbearing, plaintive, \[and\] penitent.

# 1549

‘O Abraham, let this matter alone! Your Lord’s edict has certainly come, and an irrevocable punishment shall overtake them.’

# 1550

When Our messengers came to Lot, he was distressed on their account and in a predicament for their sake, and he said, ‘This is a terrible day!’

# 1551

Then his people came running toward him, and they had been committing vices aforetime. He said, ‘O my people, these are my daughters: they are purer for you. Be wary of Allah and do not humiliate me with regard to my guests. Is there not a right-minded man among you?’

# 1552

They said, ‘You certainly know that we have no interest in your daughters, and indeed you know what we want.’

# 1553

He said, ‘If only I had the power to deter you, or could take refuge in a mighty support!’

# 1554

They said, ‘O Lot, we are messengers of your Lord. They will never get at you. Set out with your family in a watch of the night; and none of you shall turn round, except your wife; indeed she will be struck by what strikes them. Indeed their tryst is the dawn. Is not the dawn \[already\] near?’

# 1555

So when Our edict came, We made its topmost part its nethermost, and We rained on it stones of laminar shale,

# 1556

sent in from your Lord \[for the profligate\], never far from the wrongdoers.

# 1557

And to Midian \[We sent\] Shu‘ayb, their brother. He said, ‘O my people! Worship Allah. You have no other god besides Him. Do not diminish the measure or the balance. Indeed I see that you are faring well, but I fear for you the punishment of an all-embracing day.’

# 1558

‘O my people! Observe fully the measure and the balance, with justice, and do not cheat the people of their goods, and do not act wickedly on the earth, causing corruption.’

# 1559

‘What remains of Allah’s provision is better for you, should you be faithful, and I am not a keeper over you.’

# 1560

They said, ‘O Shu‘ayb, does your worship require that we abandon what our fathers have been worshiping, or that we should not do with our wealth whatever we wish? You are indeed \[a\] gentle and sensible \[person\].’

# 1561

He said, ‘O my people! Have you considered, should I stand on a manifest proof from my Lord, who has provided me a good provision from Himself? I do not wish to oppose you by what I forbid you. I only desire to put things in order, as far as I can, and my success lies only with Allah: in Him I have put my trust, and to Him I turn penitently.

# 1562

O my people, do not let your defiance toward me lead you to be visited by the like of what was visited on the people of Noah, or the people of Hud, or the people of Salih, and the people of Lot are not distant from you.

# 1563

Plead with your Lord for forgiveness, then turn to Him penitently. My Lord is indeed all-merciful, all-affectionate.’

# 1564

They said, ‘O Shu‘ayb, we do not understand much of what you say. Indeed we see that you are weak amongst us, and were it not for your tribe, we would have stoned you, and you are not a formidable \[challenge\] for us.’

# 1565

He said, ‘O my people! Is my tribe more formidable in your sight than Allah, to whom you pay no regard? Indeed my Lord comprehends whatever you do.

# 1566

O my people! Act according to your ability; I too am acting. Soon you will know who will be overtaken by a punishment that will disgrace him, and who is a liar. So be on the watch; I too will be watching along with you.’

# 1567

When Our edict came, We delivered Shu‘ayb and the faithful who were with him by a mercy from Us. And the Cry seized those who were wrongdoers, whereat they lay lifeless prostrate in their homes,

# 1568

as if they had never lived there. Behold, away with Midian!—just as Thamud was done away with!

# 1569

Certainly We sent Moses with Our signs and a manifest authority

# 1570

to Pharaoh and his elite, but they followed Pharaoh’s dictates, and Pharaoh’s dictates were not right-minded.

# 1571

On the Day of Resurrection he will lead his people and conduct them into the Fire: an evil goal for the incoming!

# 1572

They are pursued by a curse in this \[world\], as well as on the Day of Resurrection; evil is the award conferred \[upon them\]!

# 1573

These are from the accounts of the townships, which We recount to you. Of them, there are some that still stand, and some that have been mown down.

# 1574

We did not wrong them, but they wronged themselves. When your Lord’s edict came, their gods whom they would invoke besides Allah were of no avail to them in any wise, and they did not increase them in anything but ruin.

# 1575

Such is the seizing of your Lord when He seizes the townships that are wrongdoing. Indeed His seizing is painful and severe.

# 1576

There is indeed a sign in that for those who fear the punishment of the Hereafter. That is a day on which all mankind will be gathered, and it is a day witnessed \[by all creatures\].

# 1577

And We do not defer it but for a determinate term.

# 1578

The day it comes, no one shall speak except by His leave. \[On that day,\] some of them will be wretched and \[some\] felicitous.

# 1579

As for the wretched, they shall be in the Fire: their lot therein will be groaning and wailing.

# 1580

They shall remain in it for as long as the heavens and the earth endure—except what your Lord may wish; indeed your Lord does whatever He desires.

# 1581

As for the felicitous, they will be in paradise. They will remain in it for as long as the heavens and the earth endure—except what your Lord may wish—an endless bounty.

# 1582

So do not be in doubt about what these worship: they worship just as their fathers worshiped before, and We shall surely pay them their full share, undiminished.

# 1583

Certainly We gave Moses the Book, but differences arose about it, and were it not for a prior decree of your Lord, a decision would have been made between them; indeed they are in grave doubt concerning it.

# 1584

Your Lord will indeed recompense everyone fully for their works. Indeed, He is well aware of what they do.

# 1585

So be steadfast, just as you have been commanded—\[you\] and whoever has turned \[to Allah\] with you—and do not overstep the bounds. Indeed, He watches what you do.

# 1586

Do not incline toward the wrongdoers, lest the Fire should touch you, and you will not have any friend besides Allah; then you will not be helped.

# 1587

Maintain the prayer at the two ends of the day, and during the early hours of the night. Indeed good deeds efface misdeeds. That is an admonition for the mindful.

# 1588

And be patient; indeed Allah does not waste the reward of the virtuous.

# 1589

Why were there not among the generations before you a remnant \[of the wise\] who might forbid corruption in the earth, except a few of those whom We delivered from among them? Those who were wrongdoers pursued that in which they had been granted affluence, and they were a guilty lot.

# 1590

Your Lord would never destroy the townships unjustly while their inhabitants were bringing about reform.

# 1591

Had your Lord wished, He would have made mankind one community; but they continue to differ,

# 1592

except those on whom your Lord has mercy—and that is why He created them—and the word of your Lord has been fulfilled: ‘I will surely fill hell with jinn and humans, all together!’

# 1593

Whatever We relate to you of the accounts of the apostles are those by which We strengthen your heart, and there has come to you in this \[surah\] the truth and an advice and admonition for the faithful.

# 1594

Say to those who do not have faith, ‘Act according to your ability; we too are acting.

# 1595

And wait! We too are waiting.’

# 1596

To Allah belongs the Unseen of the heavens and the earth, and to Him all matters are returned. So worship Him and trust in Him. Your Lord is not oblivious of what you do.

# 1597

Aif, Lam, Ra. These are the signs of the Manifest Book.

# 1598

Indeed We have sent it down as an Arabic Quran so that you may exercise your reason.

# 1599

We will recount to you the best of narratives in what We have revealed to you of this Quran, and indeed prior to it you were among those who are unaware \[of it\].

# 1600

When Joseph said to his father, ‘Father! I saw eleven planets, and the sun and the moon: I saw them prostrating themselves before me,’

# 1601

he said, ‘My son, do not recount your dream to your brothers, lest they should devise schemes against you. Satan is indeed man’s manifest enemy.

# 1602

That is how your Lord will choose you, and teach you the interpretation of dreams, and complete His blessing upon you and upon the house of Jacob, just as He completed it earlier for your fathers, Abraham and Isaac. Your Lord is indeed all-knowing and all-wise.’

# 1603

In Joseph and his brothers there are certainly signs for the seekers.

# 1604

When they said, ‘Surely Joseph and his brother are dearer to our father than \[the rest of\] us, though we are a hardy band. Our father is indeed in manifest error.’

# 1605

‘Kill Joseph or cast him away into some \[distant\] land, so that your father’s attention may be exclusively towards you, and thereafter you may become a righteous lot.’

# 1606

One of them said, ‘Do not kill Joseph, but cast him into the recess of a well so that some caravan may pick him up, if you are to do \[anything\].’

# 1607

They said, ‘Father! Why is it that you do not trust us with Joseph? We are indeed his well-wishers.

# 1608

Let him go with us tomorrow so that he may eat lots of fruits and play, and we will indeed take \[good\] care of him.’

# 1609

He said, ‘It really upsets me that you should take him away, and I fear the wolf may eat him while you are oblivious of him.’

# 1610

They said, ‘Should the wolf eat him while we are a hardy band, then we will indeed be losers!’

# 1611

So when they took him away and conspired to put him into the recess of a well, We revealed to him, ‘\[A day will come when\] you will surely inform them about this affair of theirs while they are not aware \[of your identity\].’

# 1612

In the evening, they came weeping to their father.

# 1613

They said, ‘Father! We had gone racing and left Joseph with our things, whereat the wolf ate him. But you will not believe us even if we spoke truly.’

# 1614

And they produced sham blood on his shirt. He said, ‘No, your souls have made a matter seem decorous to you. Yet patience is graceful, and Allah is my resort against what you allege.’

# 1615

There came a caravan, and they sent their water-drawer, who let down his bucket. ‘Good news!’ he said. ‘This is a young boy!’ So they hid him as \[a piece of\] merchandise, and Allah knew best what they were doing.

# 1616

And they sold him for a cheap price, a few dirhams, for they set small store by him.

# 1617

The man from Egypt who had bought him said to his wife, ‘Give him an honourable place \[in the household\]. Maybe he will be useful to us, or we may adopt him as a son.’ Thus We established Joseph in the land and that We might teach him the interpretation of dreams. Allah has \[full\] command of His affairs, but most people do not know.

# 1618

When he came of age, We gave him judgement and \[sacred\] knowledge, and thus do We reward the virtuous.

# 1619

The woman in whose house he was, solicited him. She closed the doors and said, ‘Come!!’ He said, ‘God forbid! Indeed He is my Lord; He has given me a good abode. Indeed the wrongdoers are not felicitous.’

# 1620

She certainly made for him; and he would have made for her \[too\] had he not beheld the proof of his Lord. So it was, that We might turn away from him all evil and indecency. He was indeed one of Our dedicated servants.

# 1621

They raced to the door, and she tore his shirt from behind, and they ran into her husband at the door. She said, ‘What is to be the requital of him who has evil intentions for your wife except imprisonment or a painful punishment?’

# 1622

He said, ‘It was she who solicited me.’ A witness of her own household testified \[thus\]: ‘If his shirt is torn from the front, she tells the truth and he lies.

# 1623

But if his shirt is torn from behind, then she lies and he tells the truth.’

# 1624

So when he saw that his shirt was torn from behind, he said, ‘This is \[a case\] of you women’s guile! Your guile is indeed great!

# 1625

Joseph, let this matter alone, and you, woman, plead for forgiveness for your sin, for you have indeed been erring.’

# 1626

Some of the townswomen said, ‘The chieftain’s wife has solicited her slave boy! He has captivated her love. Indeed we see her to be in manifest error.’

# 1627

When she heard of their machinations, she sent for them and arranged a repast, and gave each of them a knife, and said \[to Joseph\], ‘Come out before them.’ So when they saw him, they marvelled at him and cut their hands \[absent-mindedly\], and they said, ‘Good heavens! This is not a human being! This is but a noble angel!’

# 1628

She said, ‘He is the one on whose account you blamed me. Certainly, I did solicit him, but he was continent, and if he does not do what I bid him, surely he shall be imprisoned and humbled.’

# 1629

He said, ‘My Lord! The prison is dearer to me than to what they invite me. If You do not turn away their schemes from me, I will incline towards them and become one of the senseless.’

# 1630

So his Lord answered him and turned away their stratagems from him. Indeed, He is the All-hearing, the All-knowing.

# 1631

Then it appeared to them, after they had seen all the signs \[of his innocence\], that they should confine him for some time.

# 1632

There entered the prison two youths along with him. One of them said, ‘I dreamt that I am pressing grapes.’ The other said, ‘I dreamt that I am carrying bread on my head from which the birds are eating.’ ‘Inform us of its interpretation,’ \[they said\], ‘for indeed we see you to be a virtuous man.’

# 1633

He said, ‘Before the meals you are served come to you I will inform you of its interpretation. That is among things my Lord has taught me. Indeed, I renounce the creed of the people who have no faith in Allah and who \[also\] disbelieve in the Hereafter.

# 1634

I follow the creed of my fathers, Abraham, Isaac and Jacob. It is not for us to ascribe any partner to Allah. That is by virtue of Allah’s grace upon us and upon all mankind, but most people do not give thanks.

# 1635

O my prison mates! Are different masters better, or Allah, the One, the All-paramount?

# 1636

You do not worship besides Him but \[mere\] names that you and your fathers have coined, for which Allah has not sent down any authority. Sovereignty belongs only to Allah. He has commanded you to worship none except Him. That is the upright religion, but most people do not know.

# 1637

O my prison mates! As for one of you, he will serve wine to his master, and as for the other, he will be crucified and vultures will eat from his head. The matter about which you inquire has been decided.’

# 1638

Then he said to the one whom he knew would be delivered from among the two: ‘Mention me to your master.’ But Satan caused him to forget mentioning \[it\] to his master. So he remained in the prison for several years.

# 1639

\[One day\] the king said, ‘I saw \[in a dream\] seven fat cows being devoured by seven lean ones, and seven green ears and \[seven\] others \[that were\] dry. O courtiers, give me your opinion about my dream, if you can interpret dreams.’

# 1640

They said, ‘\[These are\] confused nightmares, and we do not know the interpretation of nightmares.’

# 1641

Said the one of the two who had been delivered, remembering \[Joseph\] after a long time: ‘I will inform you of its interpretation; so let me go \[to meet Joseph in the prison\].’

# 1642

‘Joseph,’ \[he said\], ‘O truthful one, give us your opinion concerning seven fat cows who are eaten by seven lean ones, and seven green ears and \[seven\] others dry, that I may return to the people so that they may know \[the truth of the matter\].’

# 1643

He said, ‘You will sow for seven consecutive years. Then leave in the ear whatever \[grain\] you harvest, except a little that you eat.

# 1644

Then after that there will come seven hard years which will eat up whatever you have set aside for them—all except a little which you preserve \[for seed\].

# 1645

Then after that there will come a year wherein the people will be granted relief and provided with rains therein.

# 1646

The king said, ‘Bring him to me!’ When the messenger came to him, he said, ‘Go back to your master, and ask him about the affair of women who cut their hands. My Lord is indeed well aware of their stratagems.’

# 1647

The king said, ‘What was your business, women, when you solicited Joseph?’ They said, ‘Heaven be praised! We know of no evil in him.’ The prince’s wife said, ‘Now the truth has come to light! It was I who solicited him, and he is indeed telling the truth.’

# 1648

\[Joseph said\], \[‘I initiated\] this \[inquiry\], that he may know that I did not betray him in his absence, and that Allah does not further the schemes of the treacherous.’

# 1649

‘Yet I do not absolve my \[own carnal\] soul, for the \[carnal\] soul indeed prompts \[men\] to evil, except inasmuch as my Lord has mercy. Indeed my Lord is all-forgiving, all-merciful.’

# 1650

The king said, ‘Bring him to me, I will make him my favourite.’ Then, when he had spoken with him, he said, ‘Indeed today \[onwards\] you will be honoured and trustworthy with us.’

# 1651

He said, ‘Put me in charge of the country’s granaries. I am indeed fastidious \[and\]well-informed.’

# 1652

That is how We established Joseph in the land that he may settle in it wherever he wished. We confer Our mercy on whomever We wish, and We do not waste the reward of the virtuous.

# 1653

And the reward of the Hereafter is surely better for those who have faith and are Godwary.

# 1654

\[After some years\] the brothers of Joseph came and entered his presence. He recognized them, but they did not recognize him.

# 1655

When he had furnished them with their provision, he said, ‘Bring me a brother that you have through your father. Do you not see that I give the full measure and that I am the best of hosts?

# 1656

But if you do not bring him to me, then there will be no rations for you with me, and don’t \[ever\] come near me.’

# 1657

They said, ‘We will solicit him from his father. \[That\] we will surely do.’

# 1658

He said to his servants, ‘Put their money \[back\] into their saddlebags. Maybe they will recognize it when they return to their folks, and maybe they will come back \[again\].’

# 1659

So when they returned to their father, they said, ‘Father, the measure has been withheld from us, so let our brother go with us so that we may obtain the measure, and we will indeed take \[good\] care of him.’

# 1660

He said, ‘Should I not trust you with him just as I trusted you with his brother before? Yet Allah is the best of protectors, and He is the most merciful of merciful ones.’

# 1661

And when they opened their baggage, they found their money restored to them. They said, ‘Father, what \[more\] do we want?! This is our money, restored to us! We will get provisions for our family and take care of our brother, and add another camel-load of rations. These are meagre rations.’

# 1662

He said, ‘I will not let him go with you until you give me a \[solemn\] pledge by Allah that you will surely bring him back to me, unless you are made to perish.’ When they had given him their \[solemn\] pledge, he said, ‘Allah is witness over what we say.’

# 1663

And he said, ‘My sons, do not enter by one gate, but enter by separate gates, though I cannot avail you anything against Allah. Sovereignty belongs only to Allah. In Him I have put my trust; and in Him let all the trusting put their trust.’

# 1664

When they entered whence their father had bidden them, it did not avail them anything against Allah, but only fulfilled a wish in Jacob’s heart. Indeed, he had the knowledge of what We had taught him, but most people do not know.

# 1665

When they entered into the presence of Joseph, he set his brother close to himself, and said, ‘Indeed I am your brother, so do not sorrow for what they used to do.’

# 1666

When he had furnished them with their provision, he put the drinking-cup into his brother’s saddlebag. Then a herald shouted: ‘O \[men of the\] caravan! You are indeed thieves!’

# 1667

They said, as they turned towards them, ‘What are you missing?’

# 1668

They said, ‘We miss the king’s goblet.’ ‘Whoever brings it shall have a camel-load \[of grain\],’ \[said the steward\], ‘I will guarantee that.’

# 1669

They said, ‘By Allah! You certainly know that we did not come to make trouble in this country, and we are not thieves.’

# 1670

They said, ‘What shall be its requital if you \[prove to\] be lying?’

# 1671

They said, ‘The requital for it shall be that he in whose saddlebag it is found shall give himself over as its requital. Thus do we requite the wrongdoers.’

# 1672

Then he began with their sacks, before \[opening\] his brother’s sack. Then he took it out from his brother’s sack. Thus did We devise for Joseph’s sake. He could not have held his brother under the king’s law unless Allah willed \[otherwise\]. We raise in rank whomever We please, and above every man of knowledge is One who knows best.

# 1673

They said, ‘If he has stolen \[there is no wonder\]; a brother of his had stolen before.’ Thereupon Joseph kept the matter to himself and he did not disclose it to them. He said, ‘You are in a worse state! And Allah knows best what you allege.’

# 1674

They said, ‘O emir! Indeed, he has a father, a very old man; so take one of us in his place. Indeed we see that you are a virtuous man.’

# 1675

He said, ‘God forbid that we should detain anyone except him with whom we found our wares, for then we would indeed be wrongdoers.’

# 1676

When they had despaired of \[moving\] him, they withdrew to confer privately. The eldest of them said, ‘Don’t you know that your father has taken a \[solemn\] pledge from you by Allah, and earlier you have neglected your duty in regard to Joseph? So I will never leave this land until my father permits me, or Allah passes a judgement for me, and He is the best of judges.

# 1677

Go back to your father, and say, ‘‘Father! Your son has indeed committed theft, and we testified only to what we knew, and we could not have forestalled the unseen.

# 1678

Ask \[the people of\] the town we were in, and the caravan with which we came. We indeed speak the truth.’’ ’

# 1679

He said, ‘No, your souls have made a matter seem decorous to you. Yet patience is graceful. Maybe Allah will bring them all \[back\] to me. Indeed He is the All-knowing, the All-wise.’

# 1680

He turned away from them and said, ‘Alas for Joseph!’ His eyes had turned white with grief, and he choked with suppressed agony.

# 1681

They said, ‘By Allah! You will go on remembering Joseph until you wreck your health or perish.’

# 1682

He said, ‘I complain of my anguish and grief only to Allah. I know from Allah what you do not know.’

# 1683

‘Go, my sons, and look for Joseph and his brother, and do not despair of Allah’s mercy. Indeed no one despairs of Allah’s mercy except the faithless lot.’

# 1684

Then, when they entered into his presence, they said, ‘O emir! Distress has befallen us and our family, and we have brought \[just\] a meagre sum. Yet grant us the full measure, and be charitable to us! Indeed Allah rewards the charitable.’

# 1685

He said, ‘Have you realized what you did to Joseph and his brother, when you were senseless?’

# 1686

They said, ‘Are you really Joseph?!’ He said, ‘I am Joseph, and this is my brother. Certainly Allah has shown us favour. Indeed if one is Godwary and patient Allah does not waste the reward of the virtuous.’

# 1687

They said, ‘By Allah, Allah has certainly preferred you over us, and we have indeed been erring.’

# 1688

He said, ‘There shall be no reproach on you today. Allah will forgive you, and He is the most merciful of the merciful.

# 1689

Take this shirt of mine, and cast it upon my father’s face; he will regain his sight, and bring me all your folks.’

# 1690

As the caravan set off, their father said, ‘I sense the scent of Joseph, if you will not consider me a dotard.’

# 1691

They said, ‘By God, you persist in your inveterate error.’

# 1692

When the bearer of good news arrived, he cast it on his face, and he regained his sight. He said, ‘Did I not tell you, ‘‘I know from Allah what you do not know?’’ ’

# 1693

They said, ‘Father! Plead \[with Allah\] for forgiveness of our sins! We have indeed been erring.’

# 1694

He said, ‘I shall plead with my Lord to forgive you; indeed He is the All-forgiving, the All-merciful.’

# 1695

When they entered into the presence of Joseph, he set his parents close to himself, and said, ‘Welcome to Egypt, in safety, God willing!’

# 1696

And he seated his parents high upon the throne, and they fell down prostrate before him. He said, ‘Father! This is the fulfillment of my dream of long ago, which my Lord has made come true. He was certainly gracious to me when He brought me out of the prison and brought you over from the desert after that Satan had incited ill feeling between me and my brothers. Indeed my Lord is all-attentive in bringing about what He wishes. Indeed He is the All-knowing, the All-wise.’

# 1697

‘My Lord! You have granted me a share in the kingdom, and taught me the interpretation of dreams. Originator of the heavens and earth! You are my guardian in this world and the Hereafter! Let my death be in submission \[to You\], and unite me with the Righteous.’

# 1698

These are accounts from the Unseen, which We reveal to you, and you were not with them when they conspired together and schemed.

# 1699

Yet most people will not have faith, however eager you should be.

# 1700

You do not ask them any reward for it: it is just a reminder for all the nations.

# 1701

How many a sign there is in the heavens and the earth that they pass by while they are disregardful of it!

# 1702

And most of them do not believe in Allah without ascribing partners to Him.

# 1703

Do they feel secure from being overtaken by a blanket punishment from Allah, or being overtaken by the Hour, suddenly, while they are unaware?

# 1704

Say, ‘This is my way. I summon to Allah with insight—I and he who follows me. Immaculate is Allah, and I am not one of the polytheists.’

# 1705

We did not send \[any apostles\] before you except as men from among the people of the towns, to whom We revealed. Have they not travelled over the land so that they may observe how was the fate of those who were before them? And the abode of the Hereafter is surely better for those who are Godwary. Do you not exercise your reason?

# 1706

When the apostles lost hope and they thought that they had been told lies, Our help came to them, and We delivered whomever We wished, and Our punishment will not be averted from the guilty lot.

# 1707

There is certainly a moral in their accounts for those who possess intellect. This \[Quran\] is not a fabricated discourse; rather, it is a confirmation of what was \[revealed\] before it, and an elaboration of all things, and a guidance and mercy for a people who have faith.

# 1708

Alif, Lam, Mim, Ra. These are the signs of the Book. That which has been sent down to you from your Lord is the truth, but most people do not believe \[in it\].

# 1709

It is Allah who raised the heavens without any pillars that you see, and then presided over the Throne. He disposed the sun and the moon, each moving for a specified term. He directs the command, \[and\] elaborates the signs that you may be certain of encountering your Lord.

# 1710

It is He who has spread out the earth and set in it firm mountains and streams, and of every fruit in it He has made two kinds. He draws the night’s cover over the day. There are indeed signs in that for a people who reflect.

# 1711

In the earth are neighbouring terrains \[of diverse kinds\] and vineyards, farms, and date palms growing from the same root and from diverse roots, \[all\] irrigated by the same water, and We give some of them an advantage over others in flavour. There are indeed signs in that for people who exercise their reason.

# 1712

If you are to wonder \[at anything\], then wonderful is their remark, ‘When we have become dust, shall we be \[ushered\] into a new creation?’ They are the ones who defy their Lord; they shall have iron collars around their necks, they shall be the inhabitants of the Fire, and they shall remain in it \[forever\].

# 1713

They would press you for evil sooner than for good, though there have already gone by before them exemplary punishments. Indeed your Lord is forgiving to mankind despite their wrongdoing, and indeed your Lord is severe in retribution.

# 1714

The faithless say, ‘Why has not some sign been sent down to him from his Lord?’ You are only a warner, and there is a guide for every people.

# 1715

Allah knows what every female carries \[in her womb\], and what the wombs reduce and what they increase, and everything is by \[precise\] measure with Him,

# 1716

the Knower of the sensible and the Unseen, the All-great, the All-sublime.

# 1717

It is the same \[to Him\] whether any of you speaks secretly, or does so loudly, or whether he lurks in the night, or is open to view in daytime.

# 1718

He has guardian angels, to his front and his rear, who guard him by Allah’s command. Indeed Allah does not change a people’s lot, unless they change what is in their souls. And when Allah wishes to visit ill on a people, there is nothing that can avert it, and they have no protector besides Him.

# 1719

It is He who shows you the lightning, inspiring fear and hope, and He produces the clouds heavy \[with rain\].

# 1720

The Thunder celebrates His praise, and the angels \[too\], in awe of Him, and He releases the thunderbolts and strikes with them whomever He wishes. Yet they dispute concerning Allah, though He is great in might.

# 1721

\[Only\] to Him belongs the true invocation; and those whom they invoke besides Him do not answer them in any wise—like someone who stretches his hands towards water \[desiring\] that it should reach his mouth, but it does not reach it—and the invocations of the faithless only go awry.

# 1722

To Allah prostrates whoever there is in the heavens and the earth, willingly or unwillingly, and their shadows at sunrise and sunset.

# 1723

Say, ‘Who is the Lord of the heavens and the earth?’ Say, ‘Allah!’ Say, ‘Have you then taken others besides Him for guardians, who have no control over their own benefit or harm?’ Say, ‘Are the blind one and the seer equal? Are darkness and light equal?’ Have they set up for Allah partners who have created like His creation, so that the creations seemed confusable to them? Say, ‘Allah is the creator of all things, and He is the One and the All-paramount.’

# 1724

He sends down water from the sky whereat the valleys are flooded to \[the extent of\] their capacity, and the flood carries along a swelling scum. And from what they smelt in the fire for the purpose of \[making\] ornaments or wares, \[there arises\] a similar scum. That is how Allah compares truth and falsehood. As for the scum, it leaves as dross, and that which profits the people stays in the earth. That is how Allah draws comparisons.

# 1725

For those who answer \[the summons of\] their Lord there shall be the best \[of rewards\]. But those who do not answer Him, even if they possessed all that is on the earth and as much of it besides, they would surely offer it to redeem themselves with it. For such there shall be an adverse reckoning, and their refuge shall be hell, and it is an evil resting place.

# 1726

Is someone who knows that what has been sent down to you from your Lord is the truth, like someone who is blind? Only those who possess intellect take admonition

# 1727

—those who fulfill Allah’s covenant and do not break the pledge solemnly made,

# 1728

and those who join what Allah has commanded to be joined, and fear their Lord, and are afraid of an adverse reckoning

# 1729

—those who are patient for the sake of their Lord’s pleasure, maintain the prayer, and spend secretly and openly out of what We have provided them, and repel evil \[conduct\] with good. For such will be the reward of the \[ultimate\] abode:

# 1730

the Gardens of Eden, which they will enter along with whoever is righteous from among their forebears, their spouses, and their descendants, and the angels will call on them from every door:

# 1731

‘Peace be to you, for your patience.’ How excellent is the reward of the \[ultimate\] abode!

# 1732

But as for those who break Allah’s compact after having pledged it solemnly, and sever what Allah has commanded to be joined, and cause corruption in the earth—it is such on whom the curse will lie, and for them will be the ills of the \[ultimate\] abode.

# 1733

Allah expands the provision for whomever He wishes, and tightens it. They boast of the life of this world, but compared with the Hereafter the life of this world is but a \[trifling\] enjoyment.

# 1734

The faithless say, ‘Why has not some sign been sent down to him from his Lord?’ Say, ‘Indeed Allah leads astray whomever He wishes, and guides to Himself those who turn penitently \[to Him\]

# 1735

—those who have faith and whose hearts find rest in the remembrance of Allah.’ Behold! The hearts find rest in Allah’s remembrance!

# 1736

Those who have faith and do righteous deeds—happy are they and good is their \[ultimate\] destination.

# 1737

Thus have We sent you to a nation before which many nations have passed away, that you may recite to them what We have revealed to you. Yet they defy the All-beneficent. Say, ‘He is my Lord; there is no god except Him; in Him I have put my trust, and to Him will be my return.’

# 1738

If only it were a Quran whereby the mountains could be moved, or the earth could be toured, or the dead could be spoken to.... Indeed, all dispensation belongs to Allah. Have not the faithful yet realised that had Allah wished He would have guided mankind all together? The faithless will continue to be visited by catastrophes because of their doings—or they will land near their habitations—until Allah’s promise comes to pass. Indeed Allah does not break His promise.

# 1739

Apostles were certainly derided before you. But then I gave respite to those who were faithless, then I seized them; so how was My retribution?

# 1740

Is He who sustains every soul in spite of what it earns \[comparable to the idols\]? Yet they ascribe partners to Allah! Say, ‘Name them!’ Will you inform Him concerning something He does not know about on the earth, or concerning \[what are\] mere words? Indeed, to the faithless, their scheming is presented as decorous, and they have been barred from the \[right\] way; and whomever Allah leads astray, has no guide.

# 1741

There is a punishment for them in the life of this world, and the punishment of the Hereafter will surely be harder, and they have no defender against Allah.

# 1742

A description of the paradise promised to the Godwary: streams run in it, its fruits and shade are everlasting. Such is the requital of those who are Godwary; and the requital of the faithless is the Fire.

# 1743

Those whom We have given the Book rejoice in what has been sent down to you. Some of the factions deny a part of it. Say, ‘Indeed I have been commanded to worship Allah and not to ascribe any partner to Him. To Him do I summon \[all mankind\] and to Him will be my return.’

# 1744

Thus We have sent it down as a dispensation in Arabic; and should you follow their desires after the knowledge that has come to you, you shall have against Allah neither any guardian nor defender.

# 1745

Certainly We have sent apostles before you, and We appointed for them wives and descendants; and an apostle may not bring a sign except by Allah’s leave. There is a written \[ordinance\] for every term:

# 1746

Allah effaces and confirms whatever He wishes and with Him is the Mother Book.

# 1747

Whether We show you a part of what We promise them, or take you away \[before that\], your duty is only to communicate, and it is for Us to do the reckoning.

# 1748

Have they not seen how We visit the land diminishing it at its edges? Allah judges, and there is none who may repeal His judgement, and He is swift at reckoning.

# 1749

Those who were before them \[also\] schemed; yet all devising belongs to Allah. He knows what every soul earns. Soon the faithless will know in whose favour the outcome of that abode will be.

# 1750

The faithless say, ‘You have not been sent \[by Allah\].’ Say, ‘Allah suffices as a witness between me and you, and he who possesses the knowledge of the Book.’

# 1751

Alif, Lam, Ra. \[This is\] a Book We have sent down to you that you may bring mankind out from darkness into light, by the command of their Lord, to the path of the All-mighty, the All-laudable

# 1752

—Allah, to whom belongs whatever is in the heavens and whatever is on the earth. Woe to the faithless for a severe punishment

# 1753

—those who prefer the life of this world to the Hereafter, and bar \[others\] from the way of Allah, and seek to make it crooked. They are in extreme error.

# 1754

We did not send any apostle except with the language of his people, so that he might make \[Our messages\] clear to them. Then Allah leads astray whomever He wishes, and He guides whomsoever He wishes, and He is the All-mighty, the All-wise.

# 1755

Certainly We sent Moses with Our signs: ‘Bring your people out from darkness into light and remind them of Allah’s \[holy\] days. There are indeed signs in that for every patient and grateful \[servant\].’

# 1756

When Moses said to his people, ‘Remember Allah’s blessing upon you when He delivered you from Pharaoh’s clan who inflicted a terrible torment on you, and slaughtered your sons and spared your women, and in that there was a great test from your Lord.

# 1757

And when your Lord proclaimed, “If you are grateful, I will surely enhance you \[in blessing\], but if you are ungrateful, My punishment is indeed severe.” ’

# 1758

And Moses said, ‘Should you be faithless,—you and everyone on the earth, all together—indeed Allah is all-sufficient, all-laudable.’

# 1759

Has there not come to you the account of those who were before you—the people of Noah, ‘Ad and Thamud, and those who were after them, whom no one knows \[well\] except Allah? Their apostles brought them manifest proofs, but they did not respond to them, and said, ‘We disbelieve in what you have been sent with. Indeed we have grave doubts concerning that to which you invite us.’

# 1760

Their apostles said, ‘Is there any doubt about Allah, the originator of the heavens and the earth?! He calls you to forgive you a part of your sins, and grants you respite until a specified time.’ They said, ‘You are nothing but humans like us who desire to bar us from what our fathers used to worship. So bring us a manifest authority.’

# 1761

Their apostles said to them, ‘Indeed we are just human beings like yourselves; but Allah favours whomever of His servants that He wishes. We may not bring you an authority except by Allah’s leave, and in Allah let all the faithful put their trust.

# 1762

And why should we not put our trust in Allah, seeing that He has guided us in our ways? Surely, we will put up patiently with whatever torment you may inflict upon us, and in Allah let all the trusting put their trust.’

# 1763

But the faithless said to their apostles, ‘Surely we will expel you from our land, or you shall revert to our creed.’ Thereat their Lord revealed to them: ‘We will surely destroy the wrongdoers,

# 1764

and surely We will settle you in the land after them. This \[promise\] is for someone who is awed to stand before Me and fears My threat.’

# 1765

They prayed for victory \[against the infidels\], and every obstinate tyrant was defeated,

# 1766

with hell lying ahead of him, \[where\] he shall be given to drink of a purulent fluid,

# 1767

gulping it down, but hardly swallowing it: death will assail him from every side, but he will not die, and there is \[yet\] a harsh punishment ahead of him.

# 1768

A parable of those who defy their Lord: their deeds are like ashes over which the wind blows hard on a tempestuous day: they have no power over anything they have earned. That is extreme error.

# 1769

Have you not regarded that Allah created the heavens and the earth with justice? If He wishes, He will take you away, and bring about a new creation,

# 1770

and that is not a formidable thing for Allah.

# 1771

Together they will be presented before Allah. Then those who were weak will say to the arrogant \[leaders\], ‘Indeed we were your followers. So will you avail us against Allah’s punishment in any wise?’ They will say, ‘Had Allah guided us, surely we would have guided you. It is the same to us whether we are restless or patient: there is no escape for us.’

# 1772

When the matter is all over, Satan will say, ‘Indeed Allah made you a promise that was true and I \[too\] made you a promise, but I failed you. I had no authority over you, except that I called you and you responded to me. So do not blame me, but blame yourselves. I cannot respond to your distress calls, neither can you respond to my distress calls. Indeed I disavow your taking me for \[Allah’s\] partner aforetime. There is indeed a painful punishment for the wrongdoers.’

# 1773

Those who have faith and do righteous deeds will be admitted into gardens with streams running in them, to remain in them \[forever\], by the leave of their Lord. Their greeting therein will be ‘Peace!’

# 1774

Have you not regarded how Allah has drawn a parable? A good word is like a good tree: its roots are steady and its branches are in the sky.

# 1775

It gives its fruit every season by the leave of its Lord. Allah draws these parables for mankind so that they may take admonition.

# 1776

And the parable of a bad word is that of a bad tree: uprooted from the ground, it has no stability.

# 1777

Allah fortifies those who have faith with a constant creed in the life of this world and in the Hereafter, and Allah leads astray the wrongdoers, and Allah does whatever He wishes.

# 1778

Have you not regarded those who have changed Allah’s blessing with ingratitude, and landed their people in the house of ruin?

# 1779

—hell, which they shall enter, and it is an evil abode!

# 1780

They have set up equals to Allah, to lead \[people\] astray from His way. Say, ‘Enjoy \[for a while\], for indeed your destination is hellfire!’

# 1781

Tell My servants who have faith to maintain the prayer and to spend out of what We have provided them with, secretly and openly, before there comes a day on which there will be neither any bargaining nor friendship.

# 1782

It is Allah who created the heavens and the earth, and He sends down water from the sky and with it He brings forth crops for your sustenance. And He disposed the ships for you\[r benefit\] so that they may sail at sea by His command, and He disposed the rivers for you.

# 1783

He disposed the sun and the moon for you, constant \[in their courses\], and He disposed the night and the day,

# 1784

and He gave you all that you had asked Him. If you enumerate Allah’s blessings, you will not be able to count them. Indeed man is most unfair and ungrateful!

# 1785

When Abraham said, ‘My Lord! Make this city a sanctuary, and save me and my children from worshiping idols.

# 1786

My Lord! Indeed they have misled many people. So whoever follows me indeed belongs to me, and as for those who disobey me, well, You are indeed all-forgiving, all-merciful.

# 1787

Our Lord! I have settled part of my descendants in a barren valley, by Your sacred House, our Lord, that they may maintain the prayer. So make the hearts of a part of the people fond of them, and provide them with fruits, so that they may give thanks.

# 1788

Our Lord! Indeed You know whatever we hide and whatever we disclose, and nothing is hidden from Allah on the earth or in the sky.

# 1789

All praise belongs to Allah, who gave me Ishmael and Isaac despite \[my\] old age. Indeed my Lord hears all supplications.

# 1790

My Lord! Make me a maintainer of prayer, and my descendants \[as well\]. Our Lord, accept my supplication.

# 1791

Our Lord! Forgive me and my parents, and all the faithful, on the day when the reckoning is held.’

# 1792

Do not suppose that Allah is oblivious of what the wrongdoers are doing. He is only granting them respite until the day when the eyes will be glazed.

# 1793

Scrambling with their heads upturned, there will be a fixed gaze in their eyes, and their hearts will be vacant.

# 1794

Warn the people of the day when the punishment will overtake them, whereat the wrongdoers will say, ‘Our Lord! Respite us for a short time so that we may respond to Your call and follow the apostles.’ \[They will be told,\] ‘Did you not use to swear earlier that there would be no reverse for you,

# 1795

while you dwelt in the dwellings of those who had wronged themselves \[before\], and it had been made clear to you how We had dealt with them \[before you\], and We had \[also\] cited examples for you?’

# 1796

They certainly devised their plots, but their plots are known to Allah, and their plots are not such as to dislodge the mountains.

# 1797

So do not suppose that Allah will break His promise to His apostles. Indeed Allah is all-mighty, avenger.

# 1798

The day when the earth is turned into another earth and the heavens \[as well\], and they are presented before Allah, the One, the All-paramount

# 1799

—on that day you will see the guilty bound together in chains,

# 1800

their garments made of pitch, and the Fire covering their faces,

# 1801

so that Allah may reward every soul for what it has earned. Indeed Allah is swift at reckoning.

# 1802

This is a proclamation for mankind, so that they may be warned thereby and know that He is indeed the One God, and those who possess intellect may take admonition.

# 1803

Alif, Lam, Ra. These are the signs of the Book and a manifest Quran.

# 1804

Much will the faithless wish that they had been Muslims.

# 1805

Leave them to eat and enjoy and to be diverted by longings. Soon they will know.

# 1806

We did not destroy any town but that it had a known term.

# 1807

No nation can advance its time nor can it defer it.

# 1808

They said, ‘O you, to whom the Reminder has been sent down, you are indeed crazy.

# 1809

Why do you not bring us the angels should you be truthful?!’

# 1810

We do not send down the angels except with due reason, and then they will not be granted any respite.

# 1811

Indeed We have sent down the Reminder, and indeed We will preserve it.

# 1812

Certainly We sent \[apostles\] before you to former communities,

# 1813

and there did not come to them any apostle but that they used to deride him.

# 1814

That is how We let it pass through the hearts of the guilty:

# 1815

they do not believe in it, and the precedent of the ancients has already passed.

# 1816

Were We to open for them a gate of the sky, so that they could go on ascending through it,

# 1817

they would surely say, ‘Indeed a spell has been cast on our eyes; indeed, we are a bewitched lot.’

# 1818

Certainly We have appointed houses in the sky and adorned them for the onlookers,

# 1819

and We have guarded them from every outcast Satan,

# 1820

except someone who may eavesdrop, whereat there pursues him a manifest flame.

# 1821

And We spread out the earth, and cast in it firm mountains, and We grew in it every kind of balanced thing,

# 1822

and made in it \[various\] means of livelihood for you and for those whom you do not provide for.

# 1823

There is not a thing but that its sources are with Us, and We do not send it down except in a known measure.

# 1824

And We send the fertilizing winds and send down water from the sky providing it for you to drink and you are not maintainers of its resources.

# 1825

Indeed it is We who give life and bring death and We are the inheritors.

# 1826

Certainly We know the predecessors among you and certainly We know the successors,

# 1827

and indeed it is your Lord who will resurrect them. Indeed, He is all-wise, all-knowing.

# 1828

Certainly We created man out of a dry clay \[drawn\] from an aging mud,

# 1829

and We created the jinn earlier, out of a piercing fire.

# 1830

When your Lord said to the angels, ‘Indeed I am going to create a human out of a dry clay \[drawn\] from an aging mud.

# 1831

So when I have proportioned him and breathed into him of My spirit, then fall down in prostration before him.’

# 1832

Thereat the angels prostrated, all of them together,

# 1833

but not Iblis: he refused to be among those who prostrated.

# 1834

He said, ‘O Iblis! What kept you from being among those who have prostrated?’

# 1835

Said he, ‘I will not prostrate before a human whom You have created out of a dry clay \[drawn\] from an aging mud.’

# 1836

He said, ‘Begone hence, for you are indeed an outcast,

# 1837

and indeed the curse shall lie on you until the Day of Retribution.’

# 1838

He said, ‘My Lord! Respite me till the day they will be resurrected.’

# 1839

Said He, ‘You are indeed among the reprieved

# 1840

until the day of the known time.’

# 1841

He said, ‘My Lord! As You have consigned me to perversity, I will surely glamorize \[evil\] for them on the earth, and I will surely pervert them, all

# 1842

except Your dedicated servants among them.’

# 1843

He said, ‘This is the path \[leading\] straight to Me.

# 1844

Indeed, as for My servants you do not have any authority over them, except the perverse who follow you,

# 1845

and indeed hell is the tryst of them all.

# 1846

It has seven gates, and to each gate belongs a separate portion of them.’

# 1847

Indeed the Godwary will be amid gardens and springs.

# 1848

‘‘Enter it in peace and safety!’’

# 1849

We will remove whatever rancour there is in their breasts; \[intimate like\] brothers, \[they will be reclining\] on couches, facing one another.

# 1850

Therein neither weariness shall touch them, nor will they \[ever\] be expelled from it.

# 1851

Inform my servants that I am indeed the All-forgiving, the All-merciful,

# 1852

and that My punishment is a painful punishment.

# 1853

And inform them about the guests of Abraham,

# 1854

when they entered into his presence and said, ‘Peace!’ He said, ‘We are indeed afraid of you.’

# 1855

They said, ‘Do not be afraid. Indeed we give you the good news of a wise son.’

# 1856

He said, ‘Do you give me good news though old age has befallen me? What is the good news that you bring me?’

# 1857

They said, ‘We bring you good news in truth; so do not be despondent.’

# 1858

He said, ‘Who despairs of his Lord’s mercy except the astray?!’

# 1859

He said, ‘O messengers, what is now your errand?’

# 1860

They said, ‘We have been sent toward a guilty people,

# 1861

\[who shall perish\] except the family of Lot. We will indeed deliver all of them,

# 1862

except his wife, \[who\], We have ordained, will indeed be among those who remain behind.’

# 1863

So when the messengers came to Lot’s family,

# 1864

he said, ‘You are indeed strangers \[to me\].’

# 1865

They said, ‘Indeed, we bring you what they used to doubt.

# 1866

We bring you the truth, and indeed, we speak truly.

# 1867

Take your family in a watch of the night; and follow in their rear, and none of you should turn round, and proceed as you are bidden.’

# 1868

We apprised him of the matter that these will be rooted out by dawn.

# 1869

The people of the city came, rejoicing.

# 1870

He said, ‘These are indeed my guests. Do not bring dishonour on me.

# 1871

Be wary of Allah and do not humiliate me.’

# 1872

They said, ‘Did we not forbid you from \[defending \] strangers?’

# 1873

He said, ‘These are my daughters, \[marry them\] if you should do anything.’

# 1874

By your life, they were bewildered in their drunkenness.

# 1875

So the Cry seized them at sunrise,

# 1876

and We made its topmost part its nethermost, and rained on them stones of shale.

# 1877

There are indeed signs in that for the percipient.

# 1878

Indeed it is on a standing road,

# 1879

and there is indeed a sign in that for the faithful.

# 1880

Indeed the inhabitants of Aykah were \[also\] wrongdoers.

# 1881

So We took vengeance on them, and indeed the two of them are on an open highway.

# 1882

Certainly the inhabitants of Hijr denied the apostles.

# 1883

We had given them Our signs but they disregarded them.

# 1884

They used to hew out dwellings from mountains feeling secure.

# 1885

So the Cry seized them at dawn,

# 1886

and what they used to earn did not avail them.

# 1887

We did not create the heavens and the earth and whatever is between them except with consummate wisdom, and indeed the Hour is bound to come. So forbear with a graceful forbearance.

# 1888

Indeed your Lord is the All-creator, the All-knowing.

# 1889

Certainly We have given you \[the surah of\] the seven oft-repeated verses and the great Quran.

# 1890

Do not extend your glance toward what We have provided to certain groups of them, and do not grieve for them, and lower your wing to the faithful,

# 1891

and say, ‘I am indeed a manifest warner \[of punishment from God\],’

# 1892

like that We sent down upon those who split into bands,

# 1893

who represented the Quran as magic.

# 1894

By your Lord, We will question them all

# 1895

concerning what they used to do.

# 1896

So proclaim what you have been commanded, and turn away from the polytheists.

# 1897

Indeed We will suffice you against the deriders

# 1898

—those who set up another deity besides Allah. Soon they will know!

# 1899

Certainly We know that you become upset because of what they say.

# 1900

So celebrate the praise of your Lord and be among those who prostrate,

# 1901

and worship your Lord until certainty comes to you.

# 1902

Allah’s edict is coming! So do not seek to hasten it. Immaculate is He and exalted above \[having\] any partners that they ascribe \[to Him\].

# 1903

He sends down the angels with the spirit of His command to whomever He wishes of His servants: ‘Warn \[the people\] that there is no god except Me; so be wary of Me.’

# 1904

He created the heavens and the earth with consummate wisdom. He is above having any partners that they ascribe \[to Him\].

# 1905

He created man from a drop of \[seminal\] fluid, and, behold, he is an open contender!

# 1906

He created the cattle, in which there is warmth for you and \[other\] uses, and some of them you eat.

# 1907

There is in them a beauty for you when you bring them home for rest and when you drive them forth to pasture.

# 1908

And they bear your burdens to towns, which you could not reach except by straining yourselves. Indeed your Lord is most kind and merciful.

# 1909

And horses, mules and asses, for you to ride them, and for pomp, and He creates what you do not know.

# 1910

With Allah rests guidance to the straight path, and some of the paths are devious, and had He wished He would have guided you all.

# 1911

It is He who sends down water from the sky: from it you get your drink and with it are \[sustained\] the plants wherein you pasture your herds.

# 1912

For you He makes the crops grow with it and olives, date palms, vines, and fruits of all kinds. There is indeed a sign in that for a people who reflect.

# 1913

He disposed the night and the day for you, and the sun, the moon and the stars are disposed by His command. There are indeed signs in that for people who exercise their reason.

# 1914

And \[He disposed for your benefit\] whatever He has created for you in the earth of diverse hues—there is indeed a sign in that for a people who take admonition.

# 1915

It is He who disposed the sea \[for your benefit\] that you may eat from it fresh meat, and obtain from it ornaments which you wear, and you see the ships plowing through it, that you may seek His bounty and that you may give thanks.

# 1916

He cast firm mountains in the earth lest it should shake with you, and \[made\] streams and ways, so that you may be guided

# 1917

—and the landmarks \[as well\]—and by the stars they are guided.

# 1918

Is He who creates like one who does not create? Will you not then take admonition?

# 1919

If you enumerate Allah’s blessings, you will not be able to count them. Indeed Allah is all-forgiving, all-merciful,

# 1920

and Allah knows whatever you hide and whatever you disclose.

# 1921

Those whom they invoke besides Allah do not create anything and are themselves created.

# 1922

They are dead and lifeless, and are not aware when they will be resurrected.

# 1923

Your God is the One God. Those who do not believe in the Hereafter, their hearts are in denial \[of the truth\], and they are arrogant.

# 1924

Undoubtedly, Allah knows whatever they hide and whatever they disclose. Indeed, He does not like the arrogant.

# 1925

When they are asked, ‘What is it that your Lord has sent down?’ They say, ‘Myths of the ancients,’

# 1926

\[with the result\] that they will bear the full weight of their own burden on the Day of Resurrection, along with part of the burden of those whom they mislead without any knowledge. Behold! Evil is what they bear!

# 1927

Those who were before them \[had also\] schemed. Then Allah came at their edifice from the foundations and the roof fell down upon them from above and the punishment overtook them whence they were not aware.

# 1928

Then, on the Day of Resurrection, He will disgrace them, and say, ‘Where are My “partners” for whose sake you used to defy \[Allah\]?’ Those who were given knowledge will say, ‘Indeed today disgrace and distress pursue the faithless.’

# 1929

—Those whom the angels take away while they were wronging themselves. Thereat they submit: ‘We were not doing any evil!’ ‘Yes, \[the angels say to them,\] indeed Allah knows best what you used to do!

# 1930

Enter the gates of hell to remain in it \[forever\]. Evil is the \[final\] abode of the arrogant.’

# 1931

But those who were Godwary will be asked, ‘What is it that your Lord has sent down?’ They will say, ‘Good.’ For those who do good in this world there will be a good \[reward\], and the abode of the Hereafter is better, and the abode of the Godwary is surely excellent:

# 1932

the Gardens of Eden, which they will enter, with streams running in them. There they will have whatever they wish, and thus does Allah reward the Godwary

# 1933

—those whom the angels take away while they are pure. They say \[to them\], ‘Peace be to you! Enter paradise because of what you used to do.’

# 1934

Do they not consider that the angels may come to them, or your Lord’s edict may come? Those who were before them had acted likewise; Allah did not wrong them, but they used to wrong themselves.

# 1935

So the evils of what they had earned visited them, and they were besieged by what they used to deride.

# 1936

The polytheists say, ‘Had Allah wished, we would not have worshiped anything besides Him—neither we, nor our fathers—nor we would have forbidden anything without His sanction.’ Those who were before them had acted likewise. Is the apostles’ duty anything but to communicate in clear terms?

# 1937

Certainly We raised an apostle in every nation \[to preach:\] ‘Worship Allah, and shun fake deities.’ Among them were some whom Allah guided, and among them were some who deserved to be in error. So travel over the land and observe how was the fate of the deniers.

# 1938

Even if you are eager for them to be guided, indeed Allah does not guide those who mislead \[others\], and they will have no helpers.

# 1939

They swear by Allah with solemn oaths that Allah will not resurrect those who die. Yes indeed \[He will\], it is a promise binding upon Him, but most people do not know,

# 1940

so that He may clarify for them what they differ about, and that the faithless may know that they were liars.

# 1941

All that We say to a thing, when We will it, is to say to it ‘Be!’ and it is.

# 1942

Those who migrate for the sake of Allah after they have been wronged, We will surely settle them in a good place in the world, and the reward of the Hereafter is surely greater, had they known

# 1943

—those who are patient and who put their trust in their Lord.

# 1944

We did not send \[any apostles\] before you except as men to whom We revealed. Ask the People of the Reminder if you do not know.

# 1945

\[We sent them\] with manifest proofs and scriptures. We have sent down the reminder to you so that you may clarify for the people that which has been sent down to them, so that they may reflect.

# 1946

Do those who devise evil schemes feel secure that Allah will not make the earth swallow them, or the punishment will not overtake them whence they are not aware?

# 1947

Or that He will not seize them in the midst of their bustle, whereupon they will not be able to frustrate \[Him\]?

# 1948

Or that He will not visit them with attrition? Indeed your Lord is most kind and merciful.

# 1949

Have they not regarded that whatever thing Allah has created casts its shadow to the right and to the left, prostrating to Allah in utter humility?

# 1950

To Allah prostrates whatever is in the heavens and whatever is on the earth, including animals and angels, and they are not arrogant.

# 1951

They fear their Lord above them, and do what they are commanded.

# 1952

Allah has said, ‘Do not worship two gods. Indeed He is the One God, so be in awe of Me \[alone\].’

# 1953

To Him belongs whatever is in the heavens and the earth, and to Him belongs the enduring religion. Will you, then, be wary of other than Allah?

# 1954

Whatever blessing you have is from Allah, and when a distress befalls you, you make entreaties to Him.

# 1955

Then, when He removes the distress from you—behold, a part of them ascribe partners to their Lord,

# 1956

being unthankful for what We have given them. So let them enjoy. Soon they shall know!

# 1957

They assign a share in what We have provided them to what they do not know. By Allah, you will surely be questioned concerning what you used to fabricate.

# 1958

And they attribute daughters to Allah—immaculate is He—while they will have what they desire!

# 1959

When one of them is brought the news of a female \[newborn\], his face becomes darkened, and he chokes with suppressed agony.

# 1960

He hides from the people out of distress at the news he has been brought: shall he retain it in humiliation, or bury it in the ground! Behold! Evil is the judgement that they make.

# 1961

There is an evil description for those who do not believe in the Hereafter, and the loftiest description belongs to Allah, and He is the All-mighty, the All-wise.

# 1962

Were Allah to take mankind to task for their wrongdoing, He would not leave any living being upon it. But He respites them until a specified time; so when their time comes they shall not defer it by a single hour nor shall they advance it.

# 1963

They attribute to Allah what they dislike \[for themselves\], and their tongues assert the lie that the best of rewards \[in the Hereafter\] will be theirs. Undoubtedly, the Fire shall be their lot and they will be foremost \[in entering it\].

# 1964

By Allah, We have certainly sent \[apostles\] to nations before you. But Satan made their deeds seem decorous to them. So he is their master today and there is a painful punishment for them.

# 1965

We did not send down the Book to you except \[for the purpose\] that you may clarify for them what they differ about, and as a guidance and mercy for a people who have faith.

# 1966

Allah sends down water from the sky with which He revives the earth after its death. There is indeed a sign in that for a people who listen.

# 1967

There is indeed a lesson for you in the cattle: We give you a drink pleasant to those who drink, pure milk, which is in their bellies, between \[intestinal\] waste and blood.

# 1968

From the fruits of date palms and vines you draw wine and goodly provision. There are indeed signs in that for people who exercise their reason.

# 1969

And your Lord inspired the bee \[saying\]: ‘Make your home in the mountains, and on the trees and the trellises that they erect.

# 1970

Then eat from every \[kind of\] fruit and follow meekly the ways of your Lord.’ There issues from its belly a juice of diverse hues, in which there is a cure for the people. There is indeed a sign in that for a people who reflect.

# 1971

Allah has created you, then He takes you away, and there are some among you who are relegated to the nethermost age so that he knows nothing after \[having possessed\] some knowledge. Indeed Allah is all-knowing, all-powerful.

# 1972

Allah has granted some of you an advantage over others in \[respect of\] provision. Those who have been granted an advantage do not give over their provision to their slaves so that they become equal in its respect. What, do they deny the blessing of Allah?

# 1973

Allah made for you mates from your own selves and appointed for you children and grandchildren from your mates, and We provided you with all the good things. What, do they believe in falsehood while they deny the blessing of Allah?

# 1974

They worship besides Allah what has no power to provide them with anything from the heavens and the earth, nor are they capable \[of anything\].

# 1975

So do not draw comparisons for Allah: indeed Allah knows and you do not know.

# 1976

Allah draws a parable: a slave owned \[by his master\] who has no power over anything, and another one \[a free man\] whom We have provided a goodly provision and who spends out of it secretly and openly. Are they equal? All praise belongs to Allah. But most of them do not know.

# 1977

Allah draws \[another\] parable: Two men, one of whom is dumb, having no power over anything and who is a liability to his master: wherever he directs him he does not bring any good. Is he equal to someone who enjoins justice and is \[steady\] on a straight path?

# 1978

To Allah belongs the Unseen of the heavens and the earth. The matter of the Hour is just like the twinkling of an eye, or \[even\] swifter. Indeed Allah has power over all things.

# 1979

Allah has brought you forth from the bellies of your mothers while you did not know anything. He made for you hearing, eyesight, and hearts so that you may give thanks.

# 1980

Have they not regarded the birds disposed in the air of the sky: no one sustains them except Allah. There are indeed signs in that for a people who have faith.

# 1981

It is Allah who has made your homes as a place of rest for you and He made for you homes out of the skins of the cattle which you find portable on the day of your shifting and on the day of your halt, and out of their wool, fur and hair \[He has appointed\] furniture and wares \[enduring\] for a while.

# 1982

It is Allah who made for you the shade from what He has created, and made for you retreats in the mountains, and made for you garments that protect you from heat, and garments that protect you from your \[mutual\] violence. That is how He completes His blessing upon you so that you may submit \[to Him\].

# 1983

But if they turn their backs \[on you\], your duty is only to communicate in clear terms.

# 1984

They recognize the blessing of Allah and then deny it, and most of them are faithless.

# 1985

The day We shall raise a witness from every nation, the faithless will not be permitted \[to speak\], nor will they be asked to propitiate \[Allah\].

# 1986

And when the wrongdoers sight the punishment, it shall not be lightened for them, nor will they be granted any respite.

# 1987

When the polytheists sight their partners, they will say, ‘Our Lord! These are our partners whom we used to invoke besides You.’ But they will retort to them, ‘You are indeed liars!’

# 1988

They will submit to Allah on that day, and what they used to fabricate will forsake them.

# 1989

Those who are faithless and bar from the way of Allah—We shall add punishment to their punishment because of the corruption they used to cause.

# 1990

The day We raise in every nation a witness against them from among themselves, We shall bring you as a witness against these. We have sent down the Book to you as a clarification of all things and as guidance, mercy and good news for the Muslims.

# 1991

Indeed Allah enjoins justice and kindness, and generosity towards relatives, and He forbids indecency, wrongdoing, and aggression. He advises you, so that you may take admonition.

# 1992

Fulfill Allah’s covenant when you pledge, and do not break \[your\] oaths, after pledging them solemnly and having made Allah a witness over yourselves. Indeed Allah knows what you do.

# 1993

Do not be like her who would undo her yarn, breaking it up after \[spinning it to\] strength, by making your oaths a means of \[mutual\] deceit among yourselves, so that one community may become more affluent than another community. Indeed Allah tests you thereby, and He will surely clarify for you on the Day of Resurrection what you used to differ about.

# 1994

Had Allah wished, He would have made you one community, but He leads astray whomever He wishes and guides whomever He wishes, and you will surely be questioned concerning what you used to do.

# 1995

Do not make your oaths a means of \[mutual\] deceit among yourselves, lest feet should stumble after being steady and \[lest\] you suffer ill for barring from the way of Allah and face a great punishment.

# 1996

Do not sell Allah’s covenants for a paltry gain. Indeed, what is with Allah is better for you, should you know.

# 1997

That which is with you will be spent \[and gone\], but what is with Allah shall last, and We will surely pay the patient their reward by the best of what they used to do.

# 1998

Whoever acts righteously, \[whether\] male or female, should he be faithful, We shall revive him with a good life and pay them their reward by the best of what they used to do.

# 1999

When you recite the Quran, seek the protection of Allah against the outcast Satan.

# 2000

Indeed he does not have any authority over those who have faith and put their trust in their Lord.

# 2001

His authority is only over those who befriend him and those who make him a partner \[of Allah\].

# 2002

When We change a sign for another in its stead—and Allah knows best what He sends down—they say, ‘You are indeed a fabricator.’ Indeed, most of them do not know.

# 2003

Say, the Holy Spirit has brought it down duly from your Lord to fortify those who have faith and as guidance and good news for the Muslims.

# 2004

We certainly know that they say, ‘It is only a human that instructs him.’ The language of him to whom they refer is non-Arabic, while this is a clear Arabic language.

# 2005

Indeed those who do not believe in the signs of Allah—Allah shall not guide them and there is a painful punishment for them.

# 2006

Only those fabricate lies who do not believe in the signs of Allah, and it is they who are the liars.

# 2007

Excepting someone who is compelled \[to recant his faith\] while his heart is at rest in it, those who disbelieve in Allah after \[affirming\] their faith and open up their breasts to unfaith, Allah’s wrath shall be upon them and there is a great punishment for them.

# 2008

That, because they preferred the life of the world to the Hereafter and that Allah does not guide the faithless lot.

# 2009

They are the ones Allah has set a seal on their hearts, their hearing and their sight, and it is they who are the heedless.

# 2010

Undoubtedly, they are the ones who will be the losers in the Hereafter.

# 2011

Thereafter your Lord will indeed be forgiving and merciful to those who migrated after they were persecuted, waged jihad and remained steadfast.

# 2012

The day \[will come\] when every soul will come pleading for itself and every soul will be recompensed fully for what it has done, and they will not be wronged.

# 2013

Allah draws a parable: There was a town secure and peaceful, its provision coming abundantly from every place. But it was ungrateful toward Allah’s blessings. So Allah made it taste hunger and fear because of what they used to do.

# 2014

Certainly there had come to them an apostle from among themselves, but they impugned him. So the punishment seized them while they were doing wrong.

# 2015

So eat out of what Allah has provided you as lawful and good, and give thanks for Allah’s blessing, if it is Him that you worship.

# 2016

He has forbidden you only carrion, blood, the flesh of swine, and that which has been offered to other than Allah. But if someone is compelled \[to eat any of that\], without being rebellious or aggressive, indeed Allah is all-forgiving, all-merciful.

# 2017

Do not say, asserting falsely with your tongues, ‘This is lawful, and that is unlawful,’ attributing lies to Allah. Indeed those who attribute lies to Allah will not be felicitous.

# 2018

\[Their share of the present life is\] a trifling enjoyment, and there will be a painful punishment for them.

# 2019

We forbade to the Jews what We have recounted to you earlier, and We did not wrong them, but they used to wrong themselves.

# 2020

Moreover, your Lord will indeed be forgiving and merciful to those who repent after they having committed evil out of ignorance and reform themselves.

# 2021

Indeed Abraham was a nation \[all by himself\], obedient to Allah, a Hanif, and he was not a polytheist.

# 2022

Grateful \[as he was\] for His blessings, He chose him and guided him to a straight path.

# 2023

We gave him good in this world, and in the Hereafter he will indeed be among the Righteous.

# 2024

Thereafter We revealed to you \[saying\], ‘Follow the creed of Abraham, a Hanif, who was not a polytheist.’

# 2025

The Sabbath was only prescribed for those who differed about it. Your Lord will indeed judge between them on the Day of Resurrection concerning that about which they differ.

# 2026

Invite to the way of your Lord with wisdom and good advice and dispute with them in a manner that is best. Indeed your Lord knows best those who stray from His way, and He knows best those who are guided.

# 2027

Should you retaliate, retaliate with the like of what you have been made to suffer, but if you are patient that is surely better for the steadfast.

# 2028

So be steadfast, and you cannot be steadfast except with Allah \[’s help\]. And do not grieve for them, nor be upset by their guile.

# 2029

Indeed Allah is with those who are Godwary and those who are virtuous.

# 2030

Immaculate is He who carried His servant on a journey by night from the Sacred Mosque to the Farthest Mosque whose environs We have blessed, that We might show him some of Our signs. Indeed, He is the All-hearing, the All-seeing.

# 2031

We gave Moses the Book, and made it a guide for the Children of Israel—\[saying,\] ‘Do not take any trustee besides Me’—

# 2032

descendants of those whom We carried \[in the ark\] with Noah. Indeed, he was a grateful servant.

# 2033

We revealed to the Children of Israel in the Book: ‘Twice you will cause corruption on the earth, and you will perpetrate great tyranny.’

# 2034

So when the first occasion of the two \[prophecies\] came, We aroused against you Our servants possessing great might, and they ransacked \[your\] habitations, and the promise was bound to be fulfilled.

# 2035

Then We gave you back the turn \[to prevail\] over them, and We aided you with children and wealth, and made you greater in number,

# 2036

\[saying,\] ‘If you do good, you will do good to your \[own\] souls, and if you do evil, it will be \[evil\] for them.’ So when the occasion for the other \[prophecy\] comes, they will make your faces wretched, and enter the Temple just as they entered it the first time, and destroy utterly whatever they come upon.

# 2037

Maybe your Lord will have mercy on you, but if you revert, We \[too\] will revert, and We have made hell a prison for the faithless.

# 2038

Indeed this Quran guides to what is most upright, and gives the good news to the faithful who do righteous deeds that there is a great reward for them.

# 2039

As for those who do not believe in the Hereafter, We have prepared a painful punishment for them.

# 2040

Man prays for ill as \[avidly as\] he prays for good, and man is overhasty.

# 2041

We made the night and the day two signs. Then We faded out the sign of the night, and made the sign of the day lightsome, so that you may seek from your Lord’s bounty and that you may know the number of years and calculation \[of time\], and We have elaborated everything in detail.

# 2042

We have attached every person’s omen to his neck, and We shall bring it out for him on the Day of Resurrection as a book that he will find wide open.

# 2043

‘Read your book! Today your soul suffices as your own reckoner.’

# 2044

Whoever is guided is guided only for \[the good of\] his own soul, and whoever goes astray, goes astray only to its detriment. No bearer shall bear another’s burden. We do not punish \[any community\] until We have sent \[it\] an apostle.

# 2045

And when We desire to destroy a town We command its affluent ones \[to obey Allah\]. But they commit transgression in it, and so the word becomes due against it, and We destroy it utterly.

# 2046

How many generations We have destroyed since Noah! Your Lord is sufficient as \[a witness who is\] well aware and percipient of His servants’ sins.

# 2047

Whoever desires this transitory life, We expedite for him therein whatever We wish, for whomever We desire. Then We appoint hell for him, to enter it, blameful and spurned.

# 2048

Whoever desires the Hereafter and strives for it with an endeavour worthy of it, should he be faithful,—the endeavour of such will be well-appreciated.

# 2049

To these and to those—to all We extend the bounty of your Lord, and the bounty of your Lord is not confined.

# 2050

Observe how We have given some of them an advantage over some others; yet the Hereafter is surely greater in respect of ranks and greater in respect of relative merit.

# 2051

Do not set up another god besides Allah, or you will sit blameworthy, forsaken.

# 2052

Your Lord has decreed that you shall not worship anyone except Him, and \[He has enjoined\] kindness to parents. Should any of them or both reach old age at your side, do not say to them, ‘Fie!’ And do not chide them, but speak to them noble words.

# 2053

Lower the wing of humility to them, mercifully, and say, ‘My Lord! Have mercy on them, just as they reared me when I was \[a\] small \[child\]!’

# 2054

Your Lord knows best what is in your hearts. Should you be righteous, He is indeed most forgiving toward penitents.

# 2055

Give the relatives their \[due\] right, and the needy and the traveller \[as well\], but do not squander wastefully.

# 2056

Indeed the wasteful are brothers of satans, and Satan is ungrateful to his Lord.

# 2057

And if you have to hold off from \[assisting\] them \[for now\], seeking your Lord’s mercy which you expect \[in the future\], speak to them gentle words.

# 2058

Do not keep your hand chained to your neck, nor open it altogether, or you will sit blameworthy and regretful.

# 2059

Indeed your Lord expands the provision for whomever He wishes, and tightens it. Indeed, He is well aware of His servants and a keen observer.

# 2060

Do not kill your children for the fear of penury: We will provide for them and for you. Killing them is indeed a great iniquity.

# 2061

Do not approach fornication. It is indeed an indecency and an evil way.

# 2062

Do not kill a soul \[whose life\] Allah has made inviolable, except with due cause, and whoever is killed wrongfully, We have certainly given his heir an authority. But let him not commit any excess in killing \[the murderer\], for he has been assisted \[by law\].

# 2063

Do not approach the orphan’s property except in the best manner, until he comes of age. Fulfill the covenants; indeed all covenants are accountable.

# 2064

When you measure, observe fully the measure, \[and\] weigh with an even balance. That is better and more favourable with respect to the outcome \[in the Hereafter\].

# 2065

Do not pursue that of which you have no knowledge. Indeed hearing, eyesight, and the heart—all of these are accountable.

# 2066

Do not walk exultantly on the earth. Indeed, you will neither pierce the earth, nor reach the mountains in height.

# 2067

The evil of all these is detestable to your Lord.

# 2068

These are among \[precepts\] that your Lord has revealed to you of wisdom. Do not set up another god besides Allah, or you will be cast into hell, being blameworthy and banished \[from His mercy\].

# 2069

Did your Lord prefer you for sons, and \[Himself\] adopt females from among the angels? Indeed, you say a monstrous word!

# 2070

Certainly We have variously paraphrased \[the principles of guidance\] in this Quran so that they may take admonition, but it increases them only in aversion.

# 2071

Say, ‘Were there \[other\] gods besides Him, as they say, they would surely have encroached on the Lord of the Throne.

# 2072

Immaculate is He, and greatly exalted above what they say!’

# 2073

The seven heavens glorify Him, and the earth \[too\], and whoever is in them. There is not a thing but celebrates His praise, but you do not understand their glorification. Indeed, He is all-forbearing, all-forgiving.

# 2074

When you recite the Quran, We draw a hidden curtain between you and those who do not believe in the Hereafter,

# 2075

and We cast veils on their hearts, lest they should understand it, and a deafness into their ears. When you mention your Lord alone in the Quran, they turn their backs in aversion.

# 2076

We know best what they listen for, when they listen to you, and when they hold their secret talks, when the wrongdoers say, ‘\[If you follow him\] You will be following just a bewitched man.’

# 2077

Look, how they coin epithets for you; so they go astray, and cannot find a way.

# 2078

They say, ‘What, when we have become bones and dust, shall we really be raised in a new creation?’

# 2079

Say, ‘\[That is bound to happen\] even if you should become stones, or iron,

# 2080

or a creature more fantastic to your minds!’ They will say, ‘Who will bring us back?’ Say, ‘He who originated you the first time.’ They will nod their heads at you, and say, ‘When will that be?’ Say, ‘Maybe it is near!

# 2081

The day He calls you, you will respond to Him, praising Him, and you will think you remained \[in the world\] only for a little while.’

# 2082

Tell My servants to speak in a manner which is the best. Indeed Satan incites ill feeling between them, and Satan is indeed man’s manifest enemy.

# 2083

Your Lord knows you best. He will have mercy on you if He wishes, or punish you, if He wishes, and We did not send you to watch over them.

# 2084

Your Lord knows best whoever is in the heavens and the earth. Certainly, We gave some prophets an advantage over the others, and We gave David the Psalms.

# 2085

Say, ‘Invoke those whom you claim \[to be gods\] besides Him. They have no power to remove your distress, nor to bring about any change \[in your state\].

# 2086

They \[themselves\] are the ones who supplicate, seeking a recourse to their Lord, whoever is nearer \[to Him\], expecting His mercy and fearing His punishment.’ Indeed your Lord’s punishment is a thing to beware of.

# 2087

There is not a town but We will destroy it before the Day of Resurrection, or punish it with a severe punishment. That has been written in the Book.

# 2088

Nothing keeps Us from sending signs except that the former peoples denied them. We gave Thamud the she-camel as an eye-opener, but they wronged her. We do not send the signs except as warning.

# 2089

When We said to you, ‘Indeed your Lord encircles those people,’ We did not appoint the vision that We showed you except as a tribulation for the people and the tree cursed in the Quran. We warn them, but it only increases them in their outrageous rebellion.

# 2090

When We said to the angels, ‘Prostrate before Adam,’ they \[all\] prostrated, but not Iblis: he said, ‘Shall I prostrate before someone whom You have created from clay?’

# 2091

Said he, ‘Do You see this one whom You have honoured above me? If You respite me until the Day of Resurrection, I will surely lay my yoke on his progeny, \[all\] except a few.’

# 2092

Said He, ‘Begone! Whoever of them follows you, indeed the hell shall be your requital, an ample reward.

# 2093

Instigate whomever of them you can with your voice; and rally against them your cavalry and your infantry, and share with them in wealth and children, and make promises to them!’ But Satan promises them nothing but delusion.

# 2094

‘As for My servants, you shall have no authority over them.’ And your Lord suffices as trustee.

# 2095

Your Lord is He who drives for you the ships in the sea that you may seek of His bounty. Indeed, He is most merciful to you.

# 2096

When distress befalls you at sea, those whom you invoke besides Him are forsaken. But when He delivers you to land, you are disregardful \[of Him\]. Man is very ungrateful.

# 2097

Do you feel secure that He will not make the coastland swallow you, or He will not unleash upon you a rain of stones? Then you will not find any defender for yourselves.

# 2098

Do you feel secure that He will not send you back into it another time and unleash against you a shattering gale and drown you because of your unfaith? Then you will not find for yourselves any redresser against Us.

# 2099

Certainly We have honoured the Children of Adam, and carried them over land and sea, and provided them with all the good things, and preferred them with a complete preference over many of those We have created.

# 2100

The day We shall summon every group of people along with their imam, then whoever is given his book in his right hand—they will read it, and they will not be wronged so much as a single date-thread.

# 2101

But whoever has been blind in this \[world\], will be blind in the Hereafter, and \[even\] more astray from the \[right\] way.

# 2102

They were about to beguile you from what Allah has revealed to you so that you may fabricate something other than that against Us, whereat they would have befriended you.

# 2103

And had We not fortified you, certainly you might have inclined toward them a bit.

# 2104

Then We would have surely made you taste a double \[punishment\] in this life and a double \[punishment\] after death, and then you would have not found for yourself any helper against Us.

# 2105

They were about to hound you out of the land, to expel you from it, but then they would not have stayed after you but a little.

# 2106

A precedent concerning those We have sent before you from among Our apostles, and you will not find any change in Our precedent.

# 2107

Maintain the prayer \[during the period\] from the sun’s decline till the darkness of the night, and \[observe particularly\] the dawn recital. Indeed the dawn recital is attended \[by angels\].

# 2108

And keep vigil for a part of the night, as a supererogatory \[devotion\] for you. It may be that your Lord will raise you to a praiseworthy station.

# 2109

And say, ‘My Lord! ‘Admit me with a worthy entrance, and bring me out with a worthy departure, and render me a favourable authority from Yourself.’

# 2110

And say, ‘The truth has come, and falsehood has vanished. Indeed falsehood is bound to vanish.’

# 2111

We send down in the Quran that which is a cure and mercy for the faithful; and it increases the wrongdoers only in loss.

# 2112

When We bless man, he is disregardful and turns aside; but when an ill befalls him, he is despondent.

# 2113

Say, ‘Everyone acts according to his character. Your Lord knows best who is better guided with regard to the way.’

# 2114

They question you concerning the Spirit. Say, ‘The Spirit is of the command of my Lord, and you have not been given of the knowledge except a few \[of you\].’

# 2115

If We wish, We would take away what We have revealed to you. Then you would not find for yourself any defender against Us,

# 2116

except a mercy from your Lord. Indeed His grace has been great upon you.

# 2117

Say, ‘Should all humans and jinn rally to bring the like of this Quran, they will not bring its like, even if they assisted one another.’

# 2118

We have certainly interspersed this Quran with every \[kind of\] parable for the people, but most people are only intent on ingratitude.

# 2119

They say, ‘We will not believe you until you make a spring gush forth for us from the ground.

# 2120

Or until you have a garden of date palms and vines and you make streams gush through it.

# 2121

Or until you cause the sky to fall in fragments upon us, just as you have averred. Or until you bring Allah and the angels \[right\] in front of us.

# 2122

Or until you have a house of gold, or you ascend into the sky. And we will not believe your ascension until you bring down for us a book that we may read.’ Say, ‘Immaculate is my Lord! Am I anything but a human apostle?!’

# 2123

Nothing has kept these people from believing when guidance came to them, but their saying, ‘Has Allah sent a human as an apostle?!’

# 2124

Say, ‘Had there been angels in the earth, walking around and residing \[in it like humans do\], We would have sent down to them an angel from the heaven as apostle.’

# 2125

Say, ‘Allah suffices as witness between me and you. Indeed He is well aware His servants and a keen observer.’

# 2126

Whomever Allah guides is rightly guided, and whomever He leads astray—you will never for find them any guardians besides Him. On the Day of Resurrection, We shall muster them \[scrambling\] on their faces, blind, dumb, and deaf. Their refuge shall be hell. Whenever it subsides, We shall intensify the blaze for them.

# 2127

That is their requital because they defied Our signs and said, ‘What, when we have become bones and dust, shall we really be raised in a new creation?’

# 2128

Do they not see that Allah, who created the heavens and the earth, is able to create the like of them? He has appointed for them a term, in which there is no doubt; yet the wrongdoers are only intent on ingratitude.

# 2129

Say, ‘Even if you possessed the treasuries of my Lord’s mercy, you would withhold them for the fear of being spent, and man is very niggardly.’

# 2130

Certainly We gave Moses nine manifest signs. So ask the Children of Israel. When he came to them, Pharaoh said to him, ‘O Moses, indeed I think you are bewitched.’

# 2131

He said, ‘You certainly know that no one has sent these \[signs\] except the Lord of the heavens and the earth, as eye-openers, and I, O Pharaoh, indeed think you are doomed.’

# 2132

He desired to exterminate them from the land, so We drowned him and all those who were with him.

# 2133

After him We said to the Children of Israel, ‘Take up residence in the land, and when the occasion of the other \[promise\] comes, We shall gather you in mixed company.’

# 2134

With the truth did We send it down, and with the truth did it descend, and We did not send you except as a bearer of good news and as a warner.

# 2135

We have sent the Quran in \[discrete\] parts so that you may recite it for the people a little at a time, and We have sent it down piecemeal.

# 2136

Say, ‘Whether you believe in it, or do not believe in it, indeed when it is recited to those who were given knowledge before it, they fall down in prostration on their faces,

# 2137

and say, ‘‘Immaculate is our Lord! Indeed Our Lord’s promise is bound to be fulfilled.’’

# 2138

Weeping, they fall down on their faces, and it increases them in humility.’

# 2139

Say, ‘Invoke ‘‘Allah’’ or invoke ‘‘the All-beneficent.’’ Whichever \[of His Names\] you may invoke, to Him belong the Best Names.’ Be neither loud in your prayer, nor murmur it, but follow a middle course between these,

# 2140

and say, ‘All praise belongs to Allah, who has neither taken any son, nor has He any partner in sovereignty, nor has He any wali out of weakness,’ and magnify Him with a magnification \[worthy of Him\].

# 2141

All praise belongs to Allah, who has sent down the Book to His servant and did not let any crookedness be in it,

# 2142

\[a Book\] upright, to warn of a severe punishment from Him, and to give good news to the faithful who do righteous deeds, that there shall be for them a good reward,

# 2143

to abide in it forever,

# 2144

and to warn those who say, ‘Allah has taken a son.’

# 2145

They do not have any knowledge of that, nor did their fathers. Monstrous is the utterance that comes out of their mouths, and they say nothing but a lie.

# 2146

You are liable to imperil your life out of grief for their sake, if they should not believe this discourse.

# 2147

Indeed We have made whatever is on the earth an adornment for it that We may test them \[to see\] which of them is best in conduct.

# 2148

And indeed We will turn whatever is on it into a barren plain.

# 2149

Do you suppose that the Companions of the Cave and the Inscription were among Our wonderful signs?

# 2150

When the youths took refuge in the Cave, they said, ‘Our Lord! Grant us a mercy from Yourself, and help us on to rectitude in our affair.’

# 2151

So We put them to sleep in the Cave for several years.

# 2152

Then We aroused them that We might know which of the two groups better reckoned the period they had stayed.

# 2153

We relate to you their account in truth. They were indeed youths who had faith in their Lord, and We had enhanced them in guidance,

# 2154

and fortified their hearts, when they stood up and said, ‘Our Lord is the Lord of the heavens and the earth. We will never invoke any god besides Him, for then we shall certainly have said an atrocious lie.

# 2155

These—our people—have taken gods besides Him. Why do they not bring any clear authority touching them? So who is a greater wrongdoer than he who fabricates a lie against Allah?

# 2156

When you have dissociated yourselves from them and from what they worship except Allah, then take refuge in the Cave. Your Lord will unfold His mercy for you, and He will help you on to ease in your affair.’

# 2157

You may see the sun, when it rises, slanting toward the right of their cave, and, when it sets, cut across them towards the left, and they are in a cavern within it. That is one of Allah’s signs. Whomever Allah guides is rightly guided, and whomever He leads astray, you will never find for him any guardian or guide.

# 2158

You will suppose them to be awake, although they are asleep. We turn them to the right and to the left, and their dog \[lies\] stretching its forelegs at the threshold. If you come upon them, you will surely turn to flee from them, and you will surely be filled with a terror of them.

# 2159

So it was that We aroused them \[from sleep\] so that they might question one another. One of them said, ‘How long have you stayed \[here\]?’ They said, ‘We have stayed a day, or part of a day.’ They said, ‘Your Lord knows best how long you have stayed. Send one of you to the city with this money. Let him observe which of them has the purest food, and bring you provisions from there. Let him be attentive, and let him not make anyone aware of you.

# 2160

Indeed should they prevail over you, they will \[either\] stone you \[to death\], or force you back into their creed, and then you will never be saved. ’

# 2161

So it was that We let them come upon them, that they might know that Allah’s promise is true, and that there is no doubt in the Hour. As they disputed among themselves about their matter, they said, ‘Build a building over them. Their Lord knows them best.’ Those who had the say in their matter said, ‘We will set up a place of worship over them.’

# 2162

They will say, ‘\[They are\] three; their dog is the fourth of them,’ and say, ‘\[They are\] five, their dog is the sixth of them,’ taking a shot at the invisible. They will say, ‘\[They are\] seven, their dog is the eighth of them.’ Say, ‘My Lord knows best their number, and none knows them except a few.’ So do not dispute concerning them, except for a seeming dispute, and do not question about them any of them.

# 2163

Do not say about anything, ‘I will indeed do it tomorrow,’

# 2164

without \[adding\], ‘God willing.’ And when you forget, remember your Lord, and say, ‘Maybe my Lord will guide me to \[something\] more akin to rectitude than this.’

# 2165

They remained in the Cave for three hundred years, and added nine more \[to that number\].

# 2166

Say, ‘Allah knows best how long they remained. To Him belongs the Unseen of the heavens and the earth. How well does He see! How well does He hear! They have no guardian besides Him, and none shares with Him in His judgement.’

# 2167

Recite what has been revealed to you from the Book of your Lord. Nothing can change His words, and you will never find any refuge besides Him.

# 2168

Content yourself with the company of those who supplicate their Lord morning and evening, desiring His Face, and do not lose sight of them, desiring the glitter of the life of this world. And do not obey him whose heart We have made oblivious to Our remembrance, and who follows his own desires, and whose conduct is \[mere\] profligacy.

# 2169

And say, ‘\[This is\] the truth from your Lord: let anyone who wishes believe it, and let anyone who wishes disbelieve it.’ Indeed, We have prepared for the wrongdoers a Fire whose curtains will surround them \[on all sides\]. If they cry out for help, they will be helped with a water like molten copper, which will scald their faces. What an evil drink, and how ill a resting place!

# 2170

As for those who have faith and do righteous deeds—indeed We do not waste the reward of those who are good in deeds.

# 2171

For such there will be the gardens of Eden with streams running in them. They will be adorned therein with bracelets of gold and wear green garments of silk and brocade, reclining therein on couches. How excellent a reward, and how good a resting place!

# 2172

Draw for them the parable of two men for each of whom We had made two gardens of vines, and We had surrounded them with date palms, and placed crops between them.

# 2173

Both gardens yielded their produce without stinting anything of it. And We had set a stream gushing through them.

# 2174

He had abundant fruits, so he said to his companion, as he conversed with him: ‘I have more wealth than you, and am stronger with respect to numbers.’

# 2175

He entered his garden while he wronged himself. He said, ‘I do not think that this will ever perish,

# 2176

and I do not think that the Hour will ever set in. And even if I am returned to my Lord I will surely find a resort better than this.’

# 2177

His companion said to him, as he conversed with him: ‘Do you disbelieve in Him who created you from dust, then from a drop of \[seminal\] fluid, then fashioned you as a man?

# 2178

But I \[say\], ‘‘He is Allah, my Lord,’’ and I do not ascribe any partner to my Lord.

# 2179

Why did you not say, when you entered your garden, ‘‘\[This is\] as Allah has willed! There is no power except by Allah!’’ If you see that I have lesser wealth than you and children,

# 2180

maybe my Lord will give me \[something\] better than your garden, and He will unleash upon it bolts from the sky, so that it becomes a bare plain.

# 2181

Or its water will sink down, so that you will never be able to obtain it.’

# 2182

And ruin closed in on his produce, and he began to wring his hands for what he had spent on it, as it lay fallen on its trellises. He was saying, ‘I wish I had not ascribed any partner to my Lord.’

# 2183

He had no party to help him, besides Allah, nor could he help himself.

# 2184

There, all authority belongs to Allah, the Real. He is best in rewarding, and best in requiting.

# 2185

Draw for them the parable of the life of this world: \[It is\] like the water We send down from the sky. Then the earth’s vegetation mingles with it. Then it becomes chaff, scattered by the wind. And Allah has power over all things.

# 2186

Wealth and children are an adornment of the life of the world, but lasting righteous deeds are better with your Lord in reward and better in hope.

# 2187

The day We shall set the mountains moving and you will see the earth in full view, We shall muster them, and We will not leave out anyone of them.

# 2188

They will be presented before your Lord in ranks: ‘Certainly you have come to Us just as We created you the first time. But you maintained that We shall not appoint a tryst for you.’

# 2189

The Book will be set up. Then you will see the guilty apprehensive of what is in it. They will say, ‘Woe to us! What a book is this! It omits nothing, big or small, without enumerating it.’ They will find present whatever they had done, and your Lord does not wrong anyone.

# 2190

When We said to the angels, ‘Prostrate before Adam,’ they prostrated, but not Iblis. He was one of the jinn, so he transgressed against his Lord’s command. Will you then take him and his offspring for guardians in My stead, though they are your enemies? How evil a substitute for the wrongdoers!

# 2191

I did not make them witness to the creation of the heavens and the earth, nor to their own creation, nor do I take those who mislead others as assistants.

# 2192

The day He will say \[to the polytheists\], ‘Call those whom you maintained to be My partners,’ they will call them, but they will not respond to them, for We shall set an abyss between them.

# 2193

The guilty will sight the Fire and know that they are about to fall in it, for they will find no way to escape it.

# 2194

We have certainly interspersed this Quran with every kind of parable for the people. But man is the most disputatious of creatures.

# 2195

Nothing has kept these people from believing and pleading to their Lord for forgiveness when guidance came to them, except \[their demand\] that the precedent of the ancients come to pass for them, or that the punishment come to them, face to face.

# 2196

We do not send the apostles except as bearers of good news and as warners, but those who are faithless dispute fallaciously to refute thereby the truth, having taken My signs and what they are warned of in derision.

# 2197

Who is a greater wrongdoer than he who is reminded of the signs of his Lord, whereat he disregards them and forgets what his hands have sent ahead? Indeed We have cast veils on their hearts lest they should understand it, and a deafness into their ears; and if you invite them to guidance they will never \[let themselves\] be guided.

# 2198

Your Lord is the All-forgiving dispenser of mercy. Were He to take them to task because of what they have committed, He would have surely hastened their punishment. But they have a tryst, \[when\] they will not find a refuge besides Him.

# 2199

Those are the towns that We destroyed when they were wrongdoers, and We appointed a tryst for their destruction.

# 2200

When Moses said to his lad, ‘I will go on \[journeying\] until I have reached the confluence of the two seas, or have spent a long time \[travelling\].’

# 2201

So when they reached the confluence between them, they forgot their fish, which found its way into the sea, sneaking away.

# 2202

So when they had passed on, he said to his lad, ‘Bring us our meal. We have certainly encountered much fatigue on this journey of ours.’

# 2203

He said, ‘Did you see?! When we took shelter at the rock, indeed I forgot about the fish—and none but Satan made me forget to mention it!—and it made its way into the sea in an amazing manner!’

# 2204

He said, ‘That is what we were after!’ So they returned, retracing their footsteps.

# 2205

\[There\] they found one of Our servants whom We had granted a mercy from Ourselves, and taught him a knowledge from Our own.

# 2206

Moses said to him, ‘May I follow you for the purpose that you teach me some of the probity you have been taught?’

# 2207

He said, ‘Indeed you cannot have patience with me!

# 2208

And how can you have patience about something you do not comprehend?’

# 2209

He said, ‘You will find me, God willing, to be patient, and I will not disobey you in any matter.’

# 2210

He said, ‘If you follow me, do not question me concerning anything until I myself first mention it for you.’

# 2211

So they went on and when they boarded the boat, he made a hole in it. He said, ‘Did you make a hole in it to drown its people? You have certainly done a monstrous thing!’

# 2212

He said, ‘Did I not say that you cannot have patience with me?’

# 2213

He said, ‘Do not take me to task for my forgetting, and do not be hard upon me.’

# 2214

So they went on until they came upon a boy, whereat he slew him. He said, ‘Did you slay an innocent soul, without \[his having slain\] anyone? You have certainly done a dire thing!’

# 2215

He said, ‘Did I not tell you that you cannot have patience with me?’

# 2216

He said, ‘If I question you about anything after this, do not keep me in your company. You already have enough excuse on my part.’

# 2217

So they went on until they came to the people of a town. They asked its people for food, but they refused to extend them any hospitality. There they found a wall which was about to collapse, so he erected it. He said, ‘Had you wished, you could have taken a wage for it.’

# 2218

He said, ‘This is where you and I shall part. I will inform you about the interpretation of that over which you could not maintain patience.

# 2219

As for the boat, it belonged to some poor people who work on the sea. I wanted to make it defective, for behind them was a king seizing every ship usurpingly.

# 2220

As for the boy, his parents were faithful \[persons\], and We feared he would overwhelm them with rebellion and unfaith.

# 2221

So We desired that their Lord should give them in exchange one better than him in respect of purity and closer in mercy.

# 2222

As for the wall, it belonged to two boy orphans in the city. Under it there was a treasure belonging to them. Their father had been a righteous man. So your Lord desired that they should come of age and take out their treasure—as a mercy from your Lord. I did not do that out of my own accord. This is the interpretation of that over which you could not maintain patience.’

# 2223

They question you concerning Dhul Qarnayn. Say, ‘I will relate to you an account of him.’

# 2224

Indeed We had granted him power in the land and given him the means to all things.

# 2225

So he directed a means.

# 2226

When he reached the place where the sun sets, he found it setting over a warm sea, and by it he found a people. We said, ‘O Dhul Qarnayn! You will either punish them, or treat them with kindness.’

# 2227

He said, ‘As for him who is a wrongdoer, we will punish him. Then he shall be returned to his Lord and He will punish him with a dire punishment.

# 2228

But as for him who has faith and acts righteously, he shall have the best reward, and we will assign him easy tasks under our command.’

# 2229

Thereafter he directed another means.

# 2230

When he reached the place where the sun rises, he found it rising on a people for whom We had not provided any shield against it.

# 2231

So it was, and We were fully aware of whatever \[means\] he possessed.

# 2232

Thereafter he directed another means.

# 2233

When he reached \[the place\] between the two barriers, he found between them a people who could hardly understand a word \[of his language\].

# 2234

They said, ‘O Dhul Qarnayn! Indeed Gog and Magog are causing disaster in this land. Shall we pay you a tribute on condition that you build a barrier between them and us?’

# 2235

He said, ‘What my Lord has furnished me is better. Yet help me with some strength, and I will make a bulwark between you and them.

# 2236

Bring me pieces of iron!’ When he had levelled up between the flanks, he said, ‘Blow!’ When he had turned it into fire, he said, ‘Bring me molten copper to pour over it.’

# 2237

So they could neither scale it, nor could they make a hole in it.

# 2238

He said, ‘This is a mercy from my Lord. But when the promise of my Lord is fulfilled, He will level it; and my Lord’s promise is true.’

# 2239

That day We shall let them surge over one another, the Trumpet will be blown, and We shall gather them all,

# 2240

and on that day We shall bring hell into view visibly for the faithless.

# 2241

—Those whose eyes were blind to My remembrance and who could not hear.

# 2242

Do the faithless suppose that they have taken My servants for guardians in My stead? Indeed, We have prepared hell for the hospitality of the faithless.

# 2243

Say, ‘Shall we inform you who are the biggest losers in their works?

# 2244

Those whose efforts are misguided in the life of the world, while they suppose they are doing good.’

# 2245

They are the ones who deny the signs of their Lord and encounter with Him. So their works have failed. On the Day of Resurrection We will not give them any weight.

# 2246

That is their requital—hell—because of their unfaith and for deriding My signs and apostles.

# 2247

As for those who have faith and do righteous deeds, they shall have the gardens of Firdaws for abode,

# 2248

to remain in them \[forever\]; they will not seek to leave it for another place.

# 2249

Say, ‘If the sea were ink for the words of my Lord, the sea would be spent before the words of my Lord are finished, though We replenish it with another like it.’

# 2250

Say, ‘I am just a human being like you. It has been revealed to me that your God is the One God. So whoever expects to encounter his Lord—let him act righteously, and not associate anyone with the worship of his Lord.’

# 2251

Kaf, Ha, Ya, ‘Ayn, Suad.

# 2252

\[This is\] an account of your Lord’s mercy on His servant, Zechariah,

# 2253

when he called out to his Lord with a secret cry.

# 2254

He said, ‘My Lord! Indeed my bones have become feeble, and my head has turned white with age, yet never have I, my Lord, been disappointed in supplicating You!

# 2255

Indeed I fear my kinsmen, after me, and my wife is barren. So grant me from Yourself an heir

# 2256

who may inherit from me and inherit from the House of Jacob, and make him, my Lord, pleasing \[to You\]!’

# 2257

‘O Zechariah! Indeed We give you the good news of a son, whose name is ‘‘John.’’ Never before have We made anyone his namesake.’

# 2258

He said, ‘My Lord! How shall I have a son, when my wife is barren, and I am already advanced in age?’

# 2259

He said, ‘So shall it be. Your Lord has said, ‘‘It is simple for Me.’’ Certainly I created you before when you were nothing.’

# 2260

He said, ‘My Lord! Appoint a sign for me.’ He said, ‘Your sign is that you will not speak to the people for three complete nights.’

# 2261

So he emerged before his people from the Temple, and signalled to them that they should glorify \[Allah\] morning and evening.

# 2262

‘O John!’ \[We said,\] ‘Hold on with power to the Book!’ And We gave him judgement while still a child,

# 2263

and a compassion and purity from Us. He was Godwary

# 2264

and good to his parents, and was not self-willed or disobedient.

# 2265

Peace be to him, the day he was born, and the day he dies, and the day he is raised alive!

# 2266

And mention in the Book Mary, when she withdrew from her family to an easterly place.

# 2267

Thus did she seclude herself from them, whereupon We sent to her Our Spirit and he became incarnate for her as a well-proportioned human.

# 2268

She said, ‘I seek the protection of the All-beneficent from you, should you be Godwary!’

# 2269

He said, ‘I am only a messenger of your Lord that I may give you a pure son.’

# 2270

She said, ‘How shall I have a child seeing that no human being has ever touched me, nor have I been unchaste?’

# 2271

He said, ‘So shall it be. Your Lord says, ‘‘It is simple for Me.’’ And so that We may make him a sign for mankind and a mercy from Us, and it is a matter \[already\] decided.’

# 2272

Thus she conceived him, then withdrew with him to a distant place.

# 2273

The birth pangs brought her to the trunk of a date palm. She said, ‘I wish I had died before this and become a forgotten thing, beyond recall.’

# 2274

Thereupon he called her from below her \[saying,\] ‘Do not grieve! Your Lord has made a spring to flow at your feet.

# 2275

Shake the trunk of the palm tree, freshly picked dates will drop upon you.

# 2276

Eat, drink, and be comforted. Then if you see any human, say, ‘‘Indeed I have vowed a fast to the All-beneficent, so I will not speak to any human today.’’ ’

# 2277

Then carrying him she brought him to her people. They said, ‘O Mary, you have certainly come up with an odd thing!

# 2278

O sister of Aaron\[’s lineage\]! Your father was not an evil man, nor was your mother unchaste.’

# 2279

Thereat she pointed to him. They said, ‘How can we speak to one who is yet a baby in the cradle?’

# 2280

He said, ‘Indeed I am a servant of Allah! He has given me the Book and made me a prophet.

# 2281

He has made me blessed, wherever I may be, and He has enjoined me to \[maintain\] the prayer and to \[pay\] the zakat as long as I live,

# 2282

and to be good to my mother, and He has not made me self-willed and wretched.

# 2283

Peace to me the day I was born, and the day I die, and the day I am raised alive.’

# 2284

That is Jesus, son of Mary, a Word of the Real concerning whom they are in doubt.

# 2285

It is not for Allah to take a son. Immaculate is He! When He decides on a matter, He just says to it, ‘Be!’ and it is.

# 2286

\[And Jesus said,\] ‘Indeed Allah is my Lord and your Lord. So worship Him. This is a straight path.’

# 2287

But the factions differed among themselves. So woe to the faithless at the scene of a tremendous day.

# 2288

How well they will hear and how well they will see on the day when they come to Us! But today the wrongdoers are in manifest error.

# 2289

Warn them of the Day of Regret, when the matter will be decided, while they are \[yet\] heedless and do not have faith.

# 2290

Indeed We shall inherit the earth and whoever there is on it, and to Us they shall be brought back.

# 2291

And mention in the Book Abraham. Indeed, he was a truthful man and a prophet.

# 2292

When he said to his father, ‘Father! Why do you worship that which neither hears nor sees, and is of no avail to you in any way?

# 2293

Father! Indeed a knowledge has already come to me, which has not come to you. So follow me that I may guide you to a right path.

# 2294

Father! Do not worship Satan. Indeed Satan is disobedient to the All-beneficent.

# 2295

Father! I am indeed afraid that a punishment from the All-beneficent will befall you, and you will become Satan’s accomplice.’

# 2296

He said, ‘Abraham! Are you renouncing my gods? If you do not desist, I will stone you. Get away from me for a long while.’

# 2297

He said, ‘Peace be to you! I shall plead with my Lord to forgive you. Indeed, He is gracious to me.

# 2298

I dissociate myself from you and whatever you invoke besides Allah. I will supplicate my Lord. Hopefully, I will not be disappointed in supplicating my Lord.’

# 2299

So when he had left them and what they worshipped besides Allah, We gave him Isaac and Jacob, and each We made a prophet.

# 2300

And We gave them out of Our mercy, and conferred on them a worthy and lofty repute.

# 2301

And mention in the Book Moses. Indeed he was exclusively dedicated \[to Allah\], and an apostle and prophet.

# 2302

We called him from the right side of the Mount and We drew him near \[to Ourselves\] for confidential discourse.

# 2303

And We gave him out of Our mercy his brother Aaron, a prophet.

# 2304

And mention in the Book Ishmael. Indeed, he was true to his promise, and an apostle and prophet.

# 2305

He used to bid his family to \[maintain\] the prayer and to \[pay\] the zakat, and was pleasing to his Lord.

# 2306

And mention in the Book Idrees. Indeed, he was a truthful one and a prophet,

# 2307

and We raised him to an exalted station.

# 2308

They are the ones whom Allah has blessed from among the prophets of Adam’s progeny, and from \[the progeny of\] those We carried with Noah, and from among the progeny of Abraham and Israel, and from among those that We guided and chose. When the signs of the All-beneficent were recited to them, they would fall down weeping in prostration.

# 2309

But they were succeeded by an evil posterity who neglected the prayer, and followed \[their base\] appetites. So they will soon encounter \[the reward of\] perversity,

# 2310

barring those who repent, believe, and act righteously. Such will enter paradise, and they will not be wronged in the least.

# 2311

Gardens of Eden promised by the All-beneficent to His servants, \[while they were still\] unseen. Indeed His promise is bound to come to pass.

# 2312

Therein they will not hear vain talk, but only ‘Peace!’ Therein they will have their provision morning and evening.

# 2313

This is the paradise We will give as inheritance to those of Our servants who are Godwary.

# 2314

\[O Gabriel, tell the Prophet,\] ‘We do not descend except by the command of your Lord. To Him belongs whatever is before us and whatever is behind us and whatever is in between that, and your Lord does not forget

# 2315

—the Lord of the heavens and the earth and whatever is between them. So worship Him and be steadfast in His worship. Do you know anyone who could be His namesake?’

# 2316

Man says, ‘What? Shall I be brought forth alive \[from the grave\], when I have been dead?’

# 2317

Does not man remember that We created him before when he was nothing?

# 2318

By your Lord, We will surely gather them with the devils; then We will surely bring them up around hell \[scrambling\] on their knees.

# 2319

Then from every group We shall draw whichever of them was more defiant towards the All-beneficent.

# 2320

Then surely We will know best those who deserve most to enter it.

# 2321

There is none of you but will come to it: a \[matter that is a\] decided certainty with your Lord.

# 2322

Then We will deliver those who are Godwary, and leave the wrongdoers in it, fallen on their knees.

# 2323

When Our manifest signs are recited to them, the faithless say to the faithful, ‘Which of the two groups is superior in station and better with respect to company?’

# 2324

How many a generation We have destroyed before them, who were superior in furnishings and appearance!

# 2325

Say, ‘Whoever abides in error, the All-beneficent shall prolong his respite until they sight what they have been promised: either punishment, or the Hour.’ Then they will know whose position is worse, and whose host is weaker.

# 2326

Allah enhances in guidance those who are \[rightly\] guided, and lasting righteous deeds are better with your Lord in reward, and better at the return \[to Allah\].

# 2327

Have you not regarded him who defies Our signs, and says, ‘I will surely be given wealth and children’?

# 2328

Has he come to know the Unseen, or taken a promise from the All-beneficent?

# 2329

No indeed! We will write down what he says, and We will prolong his punishment endlessly.

# 2330

We shall take over from him what he talks about, and he will come to Us alone.

# 2331

They have taken gods besides Allah that they may be a \[source of\] might to them.

# 2332

No Indeed! Soon they will disown their worship, and they will be their opponents.

# 2333

Have you not regarded that We unleash the devils upon the faithless to urge them vigorously?

# 2334

So do not make haste against them; indeed We are counting for them, a counting \[down\].

# 2335

The day We shall gather the Godwary toward the All-beneficent, on mounts,

# 2336

and drive the guilty as a thirsty herd towards hell,

# 2337

no one will have the power to intercede \[with Allah\], except for him who has taken a covenant with the All-beneficent.

# 2338

They say, ‘The All-beneficent has taken a son!’

# 2339

You have certainly advanced something hideous!

# 2340

The heavens are about to be rent apart at it, the earth to split open, and the mountains to collapse into bits,

# 2341

that they should ascribe a son to the All-beneficent!

# 2342

It does not behoove the All-beneficent to take a son.

# 2343

There is none in the heavens and the earth but he comes to the All-beneficent as a servant.

# 2344

Certainly He has counted them \[all\] and numbered them precisely,

# 2345

and each of them will come to Him alone on the Day of Resurrection.

# 2346

Indeed those who have faith and do righteous deeds—the All-beneficent will endear them \[to His creation\].

# 2347

Indeed We have made it simple in your language so that you may give good news thereby to the Godwary and warn with it a disputatious lot.

# 2348

How many a generation We have destroyed before them! Can you descry any one of them, or hear from them so much as a murmur?

# 2349

Ta Ha!

# 2350

We did not send down to you the Quran that you should be miserable,

# 2351

but only as an admonition to him who fears \[his Lord\].

# 2352

A sending down \[of the Revelation\] from Him who created the earth and the lofty heavens

# 2353

—the All-beneficent, settled on the Throne.

# 2354

To Him belongs whatever is in the heavens and whatever is on the earth, and whatever is between them, and whatever is under the ground.

# 2355

Whether you speak loudly \[or in secret tones,\] He indeed knows the secret and what is still more hidden.

# 2356

Allah—there is no god except Him—to Him belong the Best Names.

# 2357

Did the story of Moses come to you,

# 2358

when he sighted a fire, and said to his family, ‘Wait! Indeed, I descry a fire! Maybe I will bring you a brand from it, or find some guidance at the fire.’

# 2359

So when he came to it, he was called, ‘O Moses!

# 2360

Indeed I am your Lord! So take off your sandals. You are indeed in the sacred valley of Tuwa.

# 2361

I have chosen you; so listen to what is revealed.

# 2362

Indeed I am Allah—there is no god except Me. So worship Me, and maintain the prayer for My remembrance.

# 2363

Indeed the Hour is bound to come: I will have it hidden, so that every soul may be rewarded for its endeavour.

# 2364

So do not let yourself be distracted from it by those who do not believe in it and who follow their desires, or you will perish.’

# 2365

‘Moses, what is that in your right hand?’

# 2366

He said, ‘It is my staff. I lean on it, and with it I beat down leaves for my sheep; and I have other uses for it.’

# 2367

He said, ‘Moses, throw it down.’

# 2368

So he threw it down, and behold, it was a snake, moving swiftly.

# 2369

He said, ‘Take hold of it, and do not fear. We will restore it to its former state.

# 2370

Now clasp your hand to your armpit: it will emerge white, without any harm—\[this is yet\] another sign,

# 2371

that We may show you some of Our great signs.

# 2372

Go to Pharaoh. He has indeed rebelled.’

# 2373

He said, ‘My Lord! Open my breast for me.

# 2374

Make my task easy for me.

# 2375

Remove the hitch from my tongue,

# 2376

\[so that\] they may understand my speech.

# 2377

Appoint for me a minister from my family,

# 2378

Aaron, my brother.

# 2379

Strengthen my back through him,

# 2380

and make him my associate in my task,

# 2381

so that we may glorify You greatly,

# 2382

and remember You greatly.

# 2383

Indeed You see us best.’

# 2384

He said, ‘Moses, your request has been granted!

# 2385

Certainly, We have done you a favour another time,

# 2386

when We revealed to your mother whatever was to be revealed:

# 2387

“Put him in the casket, and cast it into the river. Then the river will cast it on the bank, and he shall be picked up by an enemy of Mine and an enemy of his.” And I made you endearing, and that you might be reared under My \[watchful\] eyes.

# 2388

When your sister walked up \[to Pharaoh’s palace\] saying, “Shall I show you someone who will take care of him?” Then We restored you to your mother, that she might not grieve and be comforted. Then you slew a soul, whereupon We delivered you from anguish, and We tried you with various ordeals. Then you stayed for several years among the people of Midian. Then you turned up as ordained, O Moses!

# 2389

And I chose you for Myself.’

# 2390

‘Go ahead, you and your brother, with My signs and do not flag in My remembrance.

# 2391

Both of you go to Pharaoh, for he has indeed rebelled.

# 2392

Speak to him in a soft manner; maybe he will take admonition or fear.’

# 2393

They said, ‘Our Lord! We are indeed afraid that he will forestall us or will exceed all bounds.’

# 2394

He said, ‘Do not be afraid, for I will be with the two of you, hearing and seeing \[whatever happens\].

# 2395

So approach him and say, ‘‘We are the apostles of your Lord. Let the Children of Israel go with us, and do not torture them! We certainly bring you a sign from your Lord, and may peace be upon him who follows guidance!

# 2396

Indeed it has been revealed to us that punishment shall befall those who impugn us and turn their backs \[on us\].’’ ’

# 2397

He said, ‘Who is your Lord, Moses?’

# 2398

He said, ‘Our Lord is He who gave everything its creation and then guided it.’

# 2399

He said, ‘What about the former generations?’

# 2400

He said, ‘Their knowledge is with my Lord, in a Book. My Lord neither makes any error nor forgets.’

# 2401

He, who made the earth for you a cradle, and in it threaded for you ways, and sent down water from the sky, and with it We brought forth various kinds of vegetation.

# 2402

‘Eat and pasture your cattle.’ There are indeed signs in that for those who have sense.

# 2403

From it did We create you, into it shall We return you, and from it shall We bring you forth another time.

# 2404

Certainly We showed him all Our signs. But he denied \[them\] and refused \[to believe them\].

# 2405

He said, ‘Moses, have you come to us to expel us from our land with your magic?

# 2406

Yet we \[too\] will bring you a magic like it! So fix a tryst between us and you, which neither we shall fail nor you, at a middle place.’

# 2407

He said, ‘Your tryst shall be the Day of Adornment, and let the people be assembled in early forenoon.’

# 2408

Then Pharaoh withdrew \[to consult privately\], summoned up his guile, and then arrived \[at the scene of the contest\].

# 2409

Moses said to them, ‘Woe to you! Do not fabricate lies against Allah, or He will obliterate you with a punishment. Whoever fabricates lies certainly fails.’

# 2410

So they disputed their matter among themselves, and kept their confidential talks secret.

# 2411

They said, ‘These two are indeed magicians who intend to expel you from your land with their magic, and to abolish your excellent tradition!

# 2412

So summon up your ingenuity, then come in ranks. Today he who has the upper hand will be felicitous!’

# 2413

They said, ‘O Moses! Will you throw first, or shall we?’

# 2414

He said, ‘No, you throw first.’ Thereupon, behold, their ropes and staffs appeared to him by their magic to wriggle swiftly.

# 2415

Then Moses felt a fear within his heart.

# 2416

We said, ‘Do not be afraid. Indeed, you will have the upper hand.

# 2417

Throw down what is in your right hand, and it will swallow what they have conjured. What they have conjured is only a magician’s trick, and the magician does not fare well wherever he may show up.’

# 2418

Thereat the magicians fell down prostrating. They said, ‘We have believed in the Lord of Aaron and Moses!’

# 2419

He said, ‘Did you believe in him before I should permit you? He is indeed your chief who has taught you magic! Surely, I will cut off your hands and feet from opposite sides, and I will crucify you on the trunks of palm trees, and you will know which of us can inflict a severer and more lasting punishment.’

# 2420

They said, ‘We will never prefer you to the clear proofs which have come to us, and to Him who originated us. Decide whatever you want to decide. You can only decide about the life of this world.

# 2421

We have indeed believed in our Lord that He may forgive us our offences and the magic you compelled us to perform. Allah is better and more lasting.’

# 2422

Whoever comes to his Lord laden with guilt, for him shall be hell, where he will neither live nor die.

# 2423

But whoever comes to Him with faith and he has done righteous deeds, for such shall be the highest ranks

# 2424

—the Gardens of Eden, with streams running in them, to abide in them \[forever\], and that is the reward of him who keeps pure.

# 2425

We revealed to Moses, \[saying\], ‘Set out with My servants at night, and strike out for them a dry path through the sea. Do not be afraid of being overtaken, and have no fear \[of getting drowned\].

# 2426

Then Pharaoh pursued them with his troops, whereat they were engulfed by what engulfed them of the sea.

# 2427

Pharaoh led his people astray and did not guide them.

# 2428

O Children of Israel! We delivered you from your enemy, and We appointed with you a tryst on the right side of the Mount and We sent down to you manna and quails:

# 2429

‘Eat of the good things We have provided you, but do not overstep the bounds therein, lest My wrath should descend on you, and he on whom My wrath descends certainly perishes.

# 2430

Indeed I forgive those who repent, become faithful, act righteously, and follow guidance.’

# 2431

\[God said,\] ‘O Moses, what has prompted you to hasten ahead of your people?’

# 2432

He said, ‘They are close upon my heels, and I hurried on to You, my Lord, that You may be pleased.’

# 2433

He said, ‘Indeed We tried your people in your absence, and the Samiri has led them astray.’

# 2434

Thereupon Moses returned to his people, indignant and grieved. He said, ‘O my people! Did your Lord not give you a true promise? Did the period \[of my absence\] seem too long to you? Or did you desire that your Lord’s wrath should descend on you and so you failed your tryst with me?’

# 2435

They said, ‘We did not fail our tryst with you of our own accord, but we were laden with the weight of those people’s ornaments, and we cast them \[into the fire\] and so did the Samiri.’

# 2436

Then he produced for them a calf—a \[lifeless\] body with a low—and they said, This is your god and the god of Moses, so he forgot!

# 2437

Did they not see that it did not answer them, nor could it bring them any benefit or harm?

# 2438

Aaron had certainly told them earlier, ‘O my people! You are only being tested by it. Indeed your Lord is the All-beneficent. So follow me and obey my command!’

# 2439

They had said, ‘We will keep on clinging to it until Moses returns to us.’

# 2440

He said, ‘O Aaron! What kept you, when you saw them going astray,

# 2441

from following me? Did you disobey my command?’

# 2442

He said, ‘O son of my mother! Do not grab my beard or my head! I feared lest you should say, ‘‘You have caused a rift among the Children of Israel and did not heed my word \[of advice\].’’’

# 2443

He said, ‘What is your business, O Samiri?’

# 2444

He said, ‘I saw what they did not see. I took a handful \[of dust\] from the messenger’s trail and threw it. That is how my soul prompted me.’

# 2445

He said, ‘Begone! It shall be your \[lot\] throughout life to say, ‘‘Do not touch me!’’ Indeed, there is a tryst for you which you will not fail to keep! Now look at your god to whom you went on clinging. We will burn it down and then scatter it\[s ashes\] into the sea.

# 2446

Indeed your God is Allah. There is no god except Him. He embraces all things in \[His\] knowledge.’

# 2447

Thus do We relate to you some accounts of what is past. Certainly, We have given you a Reminder from Ourselves.

# 2448

Whoever disregards it shall bear a burden \[of punishment\] on the Day of Resurrection,

# 2449

remaining in it \[forever\]. Evil is their burden on the Day of Resurrection

# 2450

—the day the Trumpet will be blown; on that day We shall muster the guilty with blind eyes.

# 2451

They will whisper to one another: ‘You have stayed only for ten \[days\].’

# 2452

We know best what they will say, when the smartest of them in approach will say, ‘You stayed only a day!’

# 2453

They question you concerning the mountains. Say, ‘My Lord will scatter them \[like dust\].’

# 2454

Then He will leave it a level plain.

# 2455

You will not see any crookedness or unevenness in it.

# 2456

On that day they will follow the summoner without zigzagging. Their voices will be muted before the All-beneficent, and you will hear nothing but a murmur.

# 2457

Intercession will not avail that day except from him whom the All-beneficent allows and approves of his word.

# 2458

He knows what is before them and behind them, though they do not comprehend Him in their knowledge.

# 2459

All faces shall be humbled before the Living One, the All-sustainer, and those who bear \[the burden of\] wrongdoing will fail.

# 2460

But whoever does righteous deeds, being faithful, will neither fear any injustice or disparagement.

# 2461

Thus We have sent it down as an Arabic Quran and We have paraphrased the warnings in it variously so that they may be Godwary, or it may prompt them to remembrance.

# 2462

So exalted is Allah, the True Sovereign. Do not hasten with the Quran before its revelation is completed for you, and say, ‘My Lord! Increase me in knowledge.’

# 2463

Certainly We had enjoined Adam earlier; but he forgot, and We did not find any resoluteness in him.

# 2464

When We said to the angels, ‘Prostrate before Adam,’ they prostrated, but not Iblis: he refused.

# 2465

We said, ‘O Adam! This is indeed an enemy of yours and your mate’s. So do not let him expel you from paradise, or you will be miserable.

# 2466

You will neither be hungry in it nor naked.

# 2467

You will neither be thirsty in it, nor suffer from \[the heat of\] the sun.’

# 2468

Then Satan tempted him. He said, ‘O Adam! Shall I show you the tree of immortality, and an imperishable kingdom?’

# 2469

So they both ate of it, and their nakedness became evident to them, and they began to stitch over themselves with the leaves of paradise. Adam disobeyed his Lord, and went amiss.

# 2470

Then his Lord chose him, and turned to him clemently, and guided him.

# 2471

He said, ‘Get down both of you from it, all together, being enemies of one another! Yet, should any guidance come to you from Me, those who follow My guidance will not go astray, nor will they be miserable.

# 2472

But whoever disregards My remembrance, his shall be a wretched life, and We shall raise him blind on the Day of Resurrection.’

# 2473

He will say, ‘My Lord! Why have You raised me blind, though I used to see?’

# 2474

He will say: ‘So it is. Our signs came to you, but you forgot them, and so you will be forgotten today.’

# 2475

Thus do We requite those who transgress and do not believe in the signs of their Lord, and the punishment of the Hereafter is severer and more lasting.

# 2476

Does it not dawn upon them how many generations We have destroyed before them, amid \[the ruins of\] whose dwellings they walk? There are indeed signs in this for those who have reason.

# 2477

Were it not for a prior decree of your Lord and a specified time, \[their doom\] would have attended \[their guilt\].

# 2478

So be patient with what they say, and celebrate the praise of your Lord before the rising of the sun and before the sunset, and glorify Him in watches of the night and at the day’s ends, that you may be pleased.

# 2479

Do not extend your glance toward what We have provided certain groups of them as a glitter of the life of this world, so that We may test them thereby. The provision of your Lord is better and more lasting.

# 2480

And bid your family to prayer and be steadfast in maintaining it. We do not ask any provision of you: it is We who provide for you, and to Godwariness belongs the ultimate outcome \[in the Hereafter\].

# 2481

They say, ‘Why does he not bring us a sign from his Lord?’ Has there not come to them a clear proof in that which is in the former scriptures?

# 2482

Had We destroyed them with a punishment before it, they would have surely said, ‘Our Lord! Why did You not send us an apostle so that we might have followed Your signs before we were abased and disgraced?’

# 2483

Say, ‘Everyone \[of us\] is waiting. So wait! Soon you will know who are the people of the right path, and who is \[rightly\] guided.’

# 2484

Mankind’s reckoning has drawn near to them, yet they are disregardful in \[their\] obliviousness.

# 2485

There does not come to them any new reminder from their Lord but they listen to it as they play around,

# 2486

their hearts set on diversions. The wrongdoers secretly whisper together, \[saying\], ‘Is this \[man\] not a human being like yourselves? Will you give in to magic with open eyes?’

# 2487

He said, ‘My Lord knows every word \[spoken\] in the sky and on the earth, and He is the All-hearing, the All-knowing.’

# 2488

But they said, ‘\[They are\] muddled dreams!’ ‘Indeed, he has fabricated it!’ ‘Indeed, he is a poet!’ ‘Let him bring us a sign, like those sent to the former generations.’

# 2489

No town that We destroyed before them believed. Will these then have faith \[if they are sent signs\]?

# 2490

We did not send \[any apostles\] before you except as men to whom We revealed. Ask the People of the Reminder if you do not know.

# 2491

We did not make them bodies that did not eat food, nor were they immortal.

# 2492

Then We fulfilled Our promise to them, and We delivered them and whomever We wished, and We destroyed the transgressors.

# 2493

Certainly We have sent down to you a Book in which there is an admonition for you. Do you not exercise your reason?

# 2494

How many a town We have smashed that had been wrongdoing, and We brought forth another people after it.

# 2495

So when they sighted Our punishment, behold, they ran away from it.

# 2496

‘Do not run away! Return to the opulence you were given to enjoy and to your dwellings so that you may be questioned!’

# 2497

They said, ‘Woe to us! We have indeed been wrongdoers!’

# 2498

That remained their cry until We turned them into a mown field, stilled \[like burnt ashes\].

# 2499

We did not create the sky and the earth and whatever is between them for play.

# 2500

Had We desired to take up some diversion We would have taken it up with Ourselves, were We to do \[so\].

# 2501

Indeed, We hurl the truth against falsehood, and it crushes its head, and behold, falsehood vanishes! And woe to you for what you allege \[about Allah\].

# 2502

To Him belongs whatever is in the heavens and the earth, and those who are near Him do not disdain to worship Him, nor do they become weary.

# 2503

They glorify \[Him\] night and day, and they do not flag.

# 2504

Have they taken gods from the earth who raise \[the dead\]?

# 2505

Had there been any gods in them other than Allah, they would surely have fallen apart. Clear is Allah, the Lord of the Throne, of what they allege \[concerning Him\].

# 2506

He is not questioned concerning what He does, but they are questioned.

# 2507

Have they taken gods besides Him? Say, ‘Produce your evidence! This is a precept of those who are with me, and a precept of those \[who went\] before me.’ But most of them do not know the truth, and so they are disregardful.

# 2508

We did not send any apostle before you but that We revealed to him that ‘There is no god except Me; so worship Me.’

# 2509

They say, ‘The All-beneficent has taken offsprings.’ Immaculate is He! Indeed, they are \[His\] honoured servants.

# 2510

They do not venture to speak ahead of Him, and they act by His command.

# 2511

He knows that which is before them and that which is behind them, and they do not intercede except for someone He approves of, and they are apprehensive for the fear of Him.

# 2512

Should any of them say, ‘I am a god besides Him,’ We will requite him with hell. Thus do We requite the wrongdoers.

# 2513

Have the faithless not regarded that the heavens and the earth were interwoven and We unravelled them, and We made every living thing out of water? Will they not then have faith?

# 2514

We set firm mountains in the earth lest it should shake with them, and We made broad ways in them so that they may be guided \[to their destinations\].

# 2515

We made the sky a preserved roof and yet they are disregardful of its signs.

# 2516

It is He who created the night and the day, the sun and the moon, each swimming in an orbit.

# 2517

We did not give immortality to any human before you. If you are fated to die, will they live on forever?

# 2518

Every soul shall taste death, and We will test you with good and ill by way of test, and to Us you will be brought back.

# 2519

Whenever the faithless see you they only take you in derision: ‘Is this the one who remembers your gods?’ while they remain defiant towards the remembrance of the All-beneficent.

# 2520

Man is a creature of haste. Soon I will show you My signs. So do not ask Me to hasten.

# 2521

And they say, ‘When will this promise be fulfilled, if you are truthful?’

# 2522

If only the faithless knew about the time when they will not be able to keep the Fire off their faces and their backs, nor will they be helped!

# 2523

Indeed, it will overtake them suddenly, dumbfounding them. So they will neither be able to avert it, nor will they be granted any respite.

# 2524

Apostles were certainly derided before you; but those who ridiculed them were besieged by what they had been deriding.

# 2525

Say, ‘Who can guard you, day and night, against \[the punishment of\] the All-beneficent \[should He want to punish you\]?’ Indeed, they are disregardful of their Lord’s remembrance.

# 2526

Do they have gods besides Us to defend them? Neither can they help themselves, nor can they shield \[the idolaters\] from Us.

# 2527

Indeed, We have provided for them and their fathers until they lived on for long years. Do they not see how We visit the land diminishing it at its edges? Are they the ones who will prevail?

# 2528

Say, ‘I indeed warn you by the means of revelation.’ But the deaf do not hear the call when they are warned.

# 2529

Should a whiff of your Lord’s punishment touch them, they will surely say, ‘Woe to us! We have indeed been wrongdoers!’

# 2530

We shall set up just scales on the Day of Resurrection, and no soul will be wronged in the least. Even if it be the weight of a mustard seed We shall produce it and We suffice as reckoners.

# 2531

Certainly We gave Moses and Aaron the Criterion, a light and reminder for the Godwary

# 2532

—those who fear their Lord in secret, and who are apprehensive of the Hour.

# 2533

This \[too\] is a blessed reminder, which We have sent down. Will you then deny it?

# 2534

Certainly We had given Abraham his probity before, and We knew him

# 2535

when he said to his father and his people, ‘What are these images to which you keep on clinging?’

# 2536

They said, ‘We found our fathers worshipping them.’

# 2537

He said, ‘Certainly you and your fathers have been in manifest error.’

# 2538

They said, ‘Are you telling the truth, or are you \[just\] kidding?’

# 2539

He said, ‘Indeed, your Lord is the Lord of the heavens and the earth, who originated them, and I affirm that.

# 2540

By Allah, I will devise a stratagem against your idols after you have gone away.’

# 2541

So he broke them into pieces—all except the biggest of them—so that they might come back to it.

# 2542

They said, ‘Whoever has done this to Our gods?! He is indeed a wrongdoer!’

# 2543

They said, ‘We heard a young man mentioning them. He is called ‘‘Abraham.’’ ’

# 2544

They said, ‘Bring him before the people’s eyes so that they may bear witness \[against him\].’

# 2545

They said, ‘Was it you who did this to our gods, O Abraham?’

# 2546

He said, ‘No, it was this biggest one of them who did it! Ask them, if they can speak.’

# 2547

Thereat they came to themselves and said \[to one another\], ‘Indeed it is you who are the wrongdoers!’

# 2548

Then they hung their heads. \[However, they said,\] ‘You certainly know that they cannot speak.’

# 2549

He said, ‘Then, do you worship besides Allah that which cannot cause you any benefit or harm?

# 2550

Fie on you and what you worship besides Allah! Do you not exercise your reason?’

# 2551

They said, ‘Burn him, and help your gods, if you are to do anything!’

# 2552

We said, ‘O fire! Be cool and safe for Abraham!’

# 2553

They plotted to harm him, but We made them the biggest losers.

# 2554

We delivered him and Lot toward the land, which We have blessed for all nations.

# 2555

And We gave him Isaac, and Jacob as well for a grandson, and each of them We made righteous.

# 2556

We made them imams, guiding by Our command, and We revealed to them \[concerning\] the performance of good deeds, the maintenance of prayers, and the giving of zakat, and they used to worship Us.

# 2557

We gave judgement and knowledge to Lot, and We delivered him from the town which used to commit vicious acts. Indeed, they were an evil and depraved lot.

# 2558

And We admitted him into Our mercy. Indeed, he was one of the righteous.

# 2559

And before that Noah, when he called out, We responded to him and delivered him and his family from the great agony.

# 2560

And We helped him against the people who denied Our signs. They were indeed an evil lot; so We drowned them all.

# 2561

And \[remember\] David and Solomon when they gave judgement concerning the tillage when the sheep of some people strayed into it by night, and We were witness to their judgement.

# 2562

We gave its understanding to Solomon, and to each We gave judgement and knowledge. We disposed the mountains and the birds to glorify \[Us\] with David, and We have been the doer \[of these things\].

# 2563

We taught him the making of coats of mail for you, to protect you from your \[own\] violence. Will you then be grateful?

# 2564

And \[We disposed\] for Solomon the tempestuous wind which blew by his command toward the land which We have blessed, and We have knowledge of all things.

# 2565

Among the devils were some who dived for him and performed tasks other than that, and We were watchful over them.

# 2566

And \[remember\] Job, when he called out to his Lord, ‘Indeed distress has befallen me, and You are the most merciful of the merciful.’

# 2567

So We answered his prayer and removed his distress, and We gave him \[back\] his family along with others like them, as a mercy from Us and an admonition for the devout.

# 2568

And \[remember\] Ishmael, Idris, and Dhul-Kifl—each of them was among the patient.

# 2569

We admitted them into Our mercy. Indeed, they were among the righteous.

# 2570

And \[remember\] the Man of the Fish, when he left in a rage, thinking that We would not put him to hardship. Then he cried out in the darkness, ‘There is no god except You! You are immaculate! I have indeed been among the wrongdoers!’

# 2571

So We answered his prayer and delivered him from the agony; and thus do We deliver the faithful.

# 2572

And \[remember\] Zechariah, when he cried out to his Lord, ‘My Lord! Do not leave me without an heir, and You are the best of inheritors.’

# 2573

So We answered his prayer, and gave him John, and cured for him his wife \[of infertility\]. Indeed, they were active in \[performing\] good works, and they would supplicate Us with eagerness and awe and were humble before Us.

# 2574

And \[remember\] her who guarded her chastity, so We breathed into her Our spirit, and made her and her son a sign for all the nations.

# 2575

Indeed this community of yours is one community, and I am your Lord. So worship Me.

# 2576

They have fragmented their religion among themselves, but everyone of them will return to Us.

# 2577

Whoever is faithful and does righteous deeds, his endeavour shall not go unappreciated, and We will indeed record it for him.

# 2578

It is forbidden for \[the people of\] any town that We have destroyed \[to return to the world\]: they shall not return,

# 2579

until when Gog and Magog are let loose, and they race down from every slope,

# 2580

and the true promise draws near \[to its fulfillment\], behold, the faithless will look on with a fixed gaze: ‘Woe to us! We have certainly been oblivious of this! Indeed, we have been wrongdoers!’

# 2581

Indeed you and what \[idols\] you worship besides Allah shall be fuel for hell, and you will enter it.

# 2582

Had they been gods, they would not have entered it, and they will all remain in it \[forever\].

# 2583

Their lot therein will be groaning, and they will not hear anything in it.

# 2584

Indeed those to whom there has gone beforehand \[the promise of\] the best reward from Us will be kept away from it.

# 2585

They will not hear even its faint sound and they will remain \[forever\] in what their souls desire.

# 2586

The Great Terror will not upset them, and the angels will receive them \[saying\]: ‘This is your day which you were promised.’

# 2587

The day We shall roll up the heaven, like rolling of the scrolls \[meant\] for writings. We will bring it back just as We began the first creation—a promise \[binding\] on Us. \[That\] indeed We will do.

# 2588

Certainly We wrote in the Psalms, after the Torah: ‘Indeed My righteous servants shall inherit the earth.’

# 2589

There is indeed in this a proclamation for a devout people.

# 2590

We did not send you but as a mercy to all the nations.

# 2591

Say, ‘It has been revealed to me that your God is the One God. So will you submit?’

# 2592

But if they turn away, say, ‘I have proclaimed to you all alike, and I do not know whether what you have been promised is far or near.

# 2593

Indeed He knows whatever is spoken aloud, and He knows whatever you conceal.

# 2594

I do not know—maybe it is a trial for you and an enjoyment for a while.’

# 2595

He said, ‘My Lord! Judge \[between us and the polytheists\] with justice.’ ‘Our Lord is the All-beneficent; \[He is our\] resort against what you allege.’

# 2596

O mankind! Be wary of your Lord! Indeed the quake of the Hour is a terrible thing.

# 2597

The day that you will see it, every suckling female will be unmindful what she suckled, and every pregnant female will deliver her burden, and you will see the people drunk, yet they will not be drunken, but Allah’s punishment is severe.

# 2598

Among the people are those who dispute about Allah without any knowledge, and follow every froward devil,

# 2599

about whom it has been decreed that he will mislead those who take him for an ally, and conduct them toward the punishment of the Blaze.

# 2600

O people! If you are in doubt about the resurrection, \[consider that\] We created you from dust, then from a drop of \[seminal\] fluid, then from a clinging mass, then from a fleshy tissue, partly formed and partly unformed, so that We may manifest \[Our power\] to you. We lodge in the wombs whatever \[fetus\] We wish for a specified term, then We bring you forth as infants, then \[We rear you\] so that you may come of age. \[Then\] there are some of you who are taken away, and there are some of you who are relegated to the nethermost age, such that he knows nothing after \[having possessed\] some knowledge. And you see the earth torpid, yet when We send down water upon it, it stirs and swells, and grows every delightful kind \[of plant\].

# 2601

All that is because Allah is the Reality and it is He who revives the dead, and He has power over all things,

# 2602

and because the Hour is bound to come, there is no doubt in it, and Allah will resurrect those who are in the graves.

# 2603

Among the people are those who dispute concerning Allah without any knowledge or guidance, or an enlightening Book,

# 2604

turning aside disdainfully to lead \[others\] astray from the way of Allah. For such there is disgrace in this world, and on the Day of Resurrection We will make him taste the punishment of the burning:

# 2605

‘That is because of what your hands have sent ahead, and because Allah is not tyrannical to the servants.’

# 2606

And among the people are those who worship Allah on the \[very\] fringe: if good fortune befalls him, he is content with it; but if an ordeal visits him he makes a turnabout, to become a loser in the world and the Hereafter. That is manifest loss.

# 2607

He invokes besides Allah that which can bring him neither benefit nor harm. That is extreme error.

# 2608

He invokes someone whose harm is surely likelier than his benefit. An evil ally indeed, and an evil companion!

# 2609

Allah will indeed admit those who have faith and do righteous deeds into gardens with streams running in them. Indeed Allah does whatever He desires.

# 2610

Whoever thinks that Allah will not help him in this world and the Hereafter, let him stretch a rope to the ceiling and hang himself, and see if his artifice would remove his rage.

# 2611

Thus have We sent it down as manifest signs, and indeed Allah guides whomever He desires.

# 2612

Indeed Allah will indeed judge between the faithful, the Jews, the Sabaeans, the Christians, the Magians and the polytheists on the Day of Resurrection. Indeed Allah is witness to all things.

# 2613

Have you not regarded that whoever is in the heavens and whoever is on the earth prostrates to Allah, as well as the sun, the moon, and the stars, the mountains, the trees, and the animals and many humans? And many have come to deserve the punishment. Whomever Allah humiliates will find no one who may bring him honour. Indeed Allah does whatever He wishes.

# 2614

These two contending groups contend concerning their Lord. As for those who are faithless, cloaks of fire will be cut out for them, and boiling water will be poured over their heads,

# 2615

with which their skins and entrails will fuse,

# 2616

and there will be clubs of iron for them.

# 2617

Whenever they desire to leave it out of anguish, they will be turned back into it \[and told\]: ‘Taste the punishment of the burning!’

# 2618

Indeed Allah will admit those who have faith and do righteous deeds into gardens with streams running in them, adorned therein with bracelets of gold and pearl, and their dress therein will be silk.

# 2619

They were guided to chaste belief, and guided to the path of the All-laudable.

# 2620

Indeed those who are faithless and bar from the way of Allah and the Sacred Mosque, which We have made for all people, the native and the visitor being equal therein—whoever wrongfully tries to commit violation in it, We shall make him taste a painful punishment.

# 2621

When We settled for Abraham the site of the House \[saying\], Do not ascribe any partners to Me, and purify My House for those who circle around it, and those who stand \[in it for prayer\], and those who bow and prostrate themselves.

# 2622

And proclaim the Hajj to all the people: they will come to you on foot and on lean camels, coming from distant places,

# 2623

that they may witness the benefits for them, and mention Allah’s Name during the known days over the livestock He has provided them. So eat thereof and feed the destitute and the needy.

# 2624

Then let them do away with their untidiness, fulfill their vows, and circle around the Ancient House.

# 2625

That, and whoever venerates the sacraments of Allah, that is better for him with his Lord. You are permitted \[animals of\] grazing livestock except for what will be recited to you. So avoid the abomination of idols, and avoid false speech,

# 2626

as persons having pure faith in Allah, not ascribing partners to Him. Whoever ascribes partners to Allah is as though he had fallen from a height, then \[his corpse\] is devoured by vultures, or \[his remains are\] blown away by the wind far and wide.

# 2627

That. And whoever venerates the sacraments of Allah—indeed that arises from the Godwariness of hearts.

# 2628

You may benefit from them until a specified time. Then their place of sacrifice is by the Ancient House.

# 2629

For every nation We have appointed a rite so that they might mention Allah’s Name over the livestock He has provided them. Your God is the One God, so submit to Him. And give good news to the humble

# 2630

—those whose hearts tremble with awe when Allah is mentioned, and who are patient through whatever visits them, and who maintain the prayer and spend out of what We have provided them.

# 2631

We have appointed for you the \[sacrificial\] camels as part of Allah’s sacraments. There is good for you in them. So mention the Name of Allah over them as they stand. And when they have fallen on their flanks, eat from them, and feed the self-contained needy and the mendicant. Thus have We disposed them for your benefit so that you may give thanks.

# 2632

It is not their flesh or blood that reaches Allah; rather, it is your piety that reaches Him. Thus has He disposed them for your benefit so that you may magnify Allah for His guiding you. And give good news to the virtuous.

# 2633

Allah will indeed defend those who have faith. Indeed Allah does not like any ingrate traitor.

# 2634

Those who are fought against are permitted \[to fight\] because they have been wronged, and Allah is indeed able to help them

# 2635

—those who were expelled from their homes unjustly, only because they said, ‘Allah is our Lord.’ Had not Allah repulsed the people from one another, ruin would have befallen the monasteries, churches, synagogues and mosques in which Allah’s Name is much invoked. Allah will surely help those who help Him. Indeed Allah is all-strong, all-mighty.

# 2636

Those who, if We granted them power in the land, will maintain the prayer, give the zakat, bid what is right and forbid what is wrong. And with Allah rests the outcome of all matters.

# 2637

If they impugn you, the people of Noah had impugned before them and ‘Ad and Thamud,

# 2638

\[as well as\] the people of Abraham and the people of Lot,

# 2639

and the inhabitants of Midian, and Moses was also impugned. But I gave the faithless a respite, then I seized them and how was My rebuttal!

# 2640

How many towns We have destroyed when they had been wrongdoers! So they lie fallen on their trellises, their wells neglected and their ruined palaces!

# 2641

Have they not travelled through the land so that they may have hearts by which they may exercise their reason, or ears by which they may hear? Indeed, it is not the eyes that turn blind, but it is the hearts in the breasts that turn blind!

# 2642

They ask you to hasten the punishment, though Allah will never break His promise. Indeed a day with your Lord is like a thousand years by your reckoning.

# 2643

To how many a town did I give respite while it was doing wrong! Then I seized it, and toward Me is the destination.

# 2644

Say, ‘O mankind! I am only a manifest warner to you!’

# 2645

As for those who have faith and do righteous deeds, for them will be forgiveness and a noble provision.

# 2646

But as for those who contend with Our signs, seeking to frustrate \[their purpose\], they shall be the inmates of hell.

# 2647

We did not send any apostle or prophet before you but that when he recited \[the scripture\] Satan interjected \[something\] in his recitation. Thereat Allah nullifies whatever Satan has interjected, and then Allah confirms His signs, and Allah is All-knowing, All-wise.

# 2648

That He may make what Satan has thrown in a test for those in whose hearts is a sickness and those whose hearts have hardened. Indeed the wrongdoers are steeped in extreme defiance.

# 2649

\[And also for the reason\] that those who have been given knowledge may know that it is the truth from your Lord, and so they may have faith in it, and their hearts may be humbled before Him. Indeed Allah guides those who have faith to a straight path.

# 2650

Those who are faithless persist in their doubt about it, until either the Hour overtakes them suddenly, or they are overtaken by the punishment of an inauspicious day.

# 2651

On that day all sovereignty will belong to Allah: He will judge between them; then those who have faith and do righteous deeds will be in gardens of bliss,

# 2652

and those who are faithless and deny Our signs—for such there will be a humiliating punishment.

# 2653

Those who migrate in the way of Allah and then are slain, or die, Allah will surely provide them with a good provision. Allah is indeed the best of providers.

# 2654

He will admit them into an abode they are pleased with. Indeed Allah is all-knowing, all-forbearing.

# 2655

So will it be; and whoever retaliates with the like of what he has been made to suffer, and is aggressed against \[again\] thereafter, Allah will surely help him. Indeed Allah is all-excusing, all-forgiving.

# 2656

So will it be, because Allah makes the night pass into the day and makes the day pass into the night, and because Allah is all-hearing, all-seeing.

# 2657

So will it be, because Allah is the Reality, and what they invoke besides Him is nullity, and because Allah is the All-exalted, the All-great.

# 2658

Have you not regarded that Allah sends down water from the sky, whereupon the earth turns green? Indeed Allah is all-attentive, all-aware.

# 2659

To Him belongs whatever is in the heavens and whatever is in the earth, Indeed Allah is the All-sufficient, the All-laudable.

# 2660

Have you not regarded that Allah has disposed for you \[r benefit\] whatever there is in the earth, and \[that\] the ships sail at sea by His command, and He sustains the sky lest it should fall on the earth, excepting \[when it does so\] by His leave? Indeed Allah is most kind and merciful to mankind.

# 2661

It is He who gave you life then He makes you die, then He brings you to life. Indeed man is very ungrateful.

# 2662

For every nation We have appointed rites \[of worship\] which they observe; so let them not dispute with you concerning your religion, and invite to your Lord. Indeed, you are on a straight guidance.

# 2663

But if they dispute with you, say, ‘Allah knows best what you are doing.

# 2664

Allah will judge between you on the Day of Resurrection concerning that about which you used to differ.

# 2665

Do you not know that Allah knows whatever there is in the heaven and the earth? All that is in a Book. That is indeed easy for Allah.’

# 2666

They worship besides Allah that for which He has not sent down any authority, and of which they have no knowledge. The wrongdoers will have no helper.

# 2667

When Our manifest signs are recited to them, you perceive denial on the faces of the faithless: they would almost pounce upon those who recite Our signs to them. Say, ‘Shall I inform you about something worse than that? The Fire which Allah has promised the faithless, and it is an evil destination.’

# 2668

O people! Listen to a parable that is being drawn: Indeed those whom you invoke besides Allah will never create \[even\] a fly even if they all rallied to do so! And if a fly should take away something from them, they can not recover that from it. Feeble is the seeker and the sought!

# 2669

They do not regard Allah with the regard due to Him. Indeed Allah is all-strong, all-mighty.

# 2670

Allah chooses messengers from angels and from mankind. Indeed Allah is all-hearing, all-seeing.

# 2671

He knows that which is before them and that which is behind them, and to Allah all matters are returned.

# 2672

O you who have faith! Bow down and prostrate yourselves, and worship your Lord, and do good, so that you may be felicitous.

# 2673

And wage jihad for the sake of Allah, a jihad which is worthy of Him. He has chosen you and has not placed for you any obstacle in the religion, the faith of your father, Abraham. He named you ‘Muslims’ before, and in this, so that the Apostle may be a witness to you, and that you may be witnesses to mankind. So maintain the prayer, give the zakat, and hold fast to Allah. He is your master—an excellent master and an excellent helper.

# 2674

Certainly, the faithful have attained salvation

# 2675

—those who are humble in their prayers,

# 2676

avoid vain talk,

# 2677

carry out their \[duty of\] zakat,

# 2678

guard their private parts,

# 2679

(except from their spouses or their slave women, for then they are not blameworthy;

# 2680

but whoever seeks \[anything\] beyond that—it is they who are transgressors),

# 2681

and those who keep their trusts and covenants

# 2682

and are watchful of their prayers.

# 2683

It is they who will be the inheritors,

# 2684

who shall inherit paradise and will remain in it \[forever\].

# 2685

Certainly We created man from an extract of clay.

# 2686

Then We made him a drop of \[seminal\] fluid \[lodged\] in a secure abode.

# 2687

Then We created the drop of fluid as a clinging mass. Then We created the clinging mass as a fleshy tissue. Then We created the fleshy tissue as bones. Then We clothed the bones with flesh. Then We produced him as \[yet\] another creature. So blessed is Allah, the best of creators!

# 2688

Then indeed you die after that.

# 2689

Then you will indeed be raised up on the Day of Resurrection.

# 2690

Certainly We created above you seven levels and We have not been oblivious of the creation.

# 2691

We sent down water from the sky in a measured manner, and We lodged it within the ground, and We are indeed able to take it away.

# 2692

Then with it We produced for you gardens of date palms and vines. There are abundant fruits in them for you, and you eat from them,

# 2693

and a tree that grows on Mount Sinai, which produces oil and a seasoning for those who eat.

# 2694

There is indeed a moral for you in the cattle: We give you to drink of that which is in their bellies, and you have many uses in them, and you eat some of them,

# 2695

and you are carried on them and on ships.

# 2696

Certainly We sent Noah to his people, and he said, ‘O my people! Worship Allah! You have no other god besides Him. Will you not then be wary \[of Him\]?’

# 2697

But the elite of the faithless from among his people said, ‘This is just a human being like you, who seeks to dominate you. Had Allah wished, He would have sent down angels. We never heard of such a thing among our forefathers.

# 2698

He is just a man possessed by madness. So bear with him for a while.’

# 2699

He said, ‘My Lord! Help me, for they impugn me.’

# 2700

So We revealed to him: ‘Build the ark before Our eyes and by Our revelation. When Our edict comes and the oven gushes \[a stream of water\], bring into it a pair of every kind \[of animal\], and your family, except those of them against whom the decree has gone beforehand, and do not plead with Me for those who are wrongdoers: they shall indeed be drowned.’

# 2701

‘When you, and those who are with you, are settled in the ark, say, ‘‘All praise belongs to Allah, who has delivered us from the wrongdoing lot.’’

# 2702

And say, ‘‘My Lord! Land me with a blessed landing, for You are the best of those who bring ashore.’’ ’

# 2703

There are indeed signs in this; and indeed, We have been testing.

# 2704

Then after them We brought forth another generation,

# 2705

and We sent them an apostle from among themselves, saying, ‘Worship Allah! You have no other god besides Him. Will you not then be wary \[of Him\]?’

# 2706

Said the elite of his people, who were faithless and who denied the encounter of the Hereafter and whom We had given affluence in the life of the world: ‘This is just a human being like yourselves: he eats what you eat, and drinks what you drink.

# 2707

If you obey a human being like yourselves, you will indeed be losers.

# 2708

Does he promise you that when you have died and become bones and dust you will indeed be raised \[from the dead\]?

# 2709

Far-fetched, far-fetched is what you are promised!

# 2710

There is nothing but the life of this world: we live and die, and we will not be resurrected.

# 2711

He is just a man who has fabricated a lie against Allah, and we will not believe in him.’

# 2712

He said, ‘My Lord! Help me, for they impugn me.’

# 2713

Said He, ‘In a little while they will become regretful.’

# 2714

So the Cry seized them justly and We turned them into a scum. So away with the wrongdoing lot!

# 2715

Then after them We brought forth other generations.

# 2716

No nation can advance its time nor can it defer it.

# 2717

Then We sent Our apostles successively. Whenever there came to a nation its apostle, they impugned him, so We made them follow one another \[to extinction\] and We turned them into folktales. So away with the faithless lot!

# 2718

Then We sent Moses and Aaron, his brother, with Our signs and a manifest authority

# 2719

to Pharaoh and his elites; but they acted arrogantly and they were a tyrannical lot.

# 2720

They said, ‘Shall we believe two humans like ourselves, while their people are our slaves?’

# 2721

So they impugned the two of them, whereat they were among those who were destroyed.

# 2722

Certainly We gave Moses the Book so that they might be guided,

# 2723

and We made the son of Mary and his mother a sign, and sheltered them in a level highland with flowing water.

# 2724

O apostles! Eat of the good things and act righteously. Indeed I know best what you do.

# 2725

Indeed this community of yours is one community, and I am your Lord, so be wary of Me.

# 2726

But they fragmented their religion among themselves, each party boasting about what it had.

# 2727

So leave them in their stupor for a while.

# 2728

Do they suppose that whatever aid We provide them in regard to wealth and children \[is because\]

# 2729

We are eager to bring them good? No, they are not aware!

# 2730

Indeed those who are apprehensive for the fear of their Lord,

# 2731

and believe in the signs of their Lord,

# 2732

and do not ascribe partners to their Lord;

# 2733

who give whatever they give while their hearts tremble with awe that they are going to return to their Lord

# 2734

—it is they who are zealous in \[performing\] good works and take the lead in them.

# 2735

We task no soul except according to its capacity, and with Us is a book that speaks the truth, and they will not be wronged.

# 2736

Indeed, their hearts are in a stupor in regard to this, and there are other deeds besides which they perpetrate.

# 2737

When We seize their affluent ones with punishment, behold, they make entreaties \[to Us\].

# 2738

‘Do not make entreaties today! Indeed, you will not receive any help from Us.

# 2739

Certainly My signs used to be recited to you, but you used to take to your heels,

# 2740

being disdainful of it, talking nonsense in your nightly sessions.’

# 2741

Have they not contemplated the Discourse, or has anything come to them \[in it\] that did not come to their forefathers?

# 2742

Is it that they do not recognize their apostle, and so they deny him?

# 2743

Do they say, ‘There is madness in him’? No, he has brought them the truth, and most of them are averse to the truth.

# 2744

Had the truth followed their desires, the heavens and the earth would have surely fallen apart \[along\] with those who are in them. Indeed, We have brought them their Reminder, but they are disregardful of their Reminder.

# 2745

Do you ask a recompense from them? Your Lord’s recompense is better, and He is the best of providers.

# 2746

Indeed you invite them to a straight path,

# 2747

and those who do not believe in the Hereafter surely deviate from the path.

# 2748

Should We have mercy upon them and remove their distress, they would surely persist, bewildered in their rebellion.

# 2749

We have already seized them with punishment, yet they did not humble themselves before their Lord, nor will they entreat \[Him for mercy\]

# 2750

until We open on them the gate of a severe punishment, whereupon they will be despondent in it.

# 2751

It is He who made for you hearing, eyesight, and hearts. Little do you thank.

# 2752

It is He who created you on the earth, and you will be mustered toward Him.

# 2753

And it is He who gives life and brings death, and due to Him is the alternation of day and night. Do you not exercise your reason?

# 2754

Indeed, they say, just like what the former peoples said.

# 2755

They said, ‘What, when we are dead and become dust and bones, shall we be resurrected?

# 2756

Certainly, we and our fathers were promised this before. \[But\] these are nothing but myths of the ancients.’

# 2757

Say, ‘To whom does the earth belong and whoever it contains, if you know?’

# 2758

They will say, ‘To Allah.’ Say, ‘Will you not then take admonition?’

# 2759

Say, ‘Who is the Lord of the seven heavens and the Lord of the Great Throne?’

# 2760

They will say, ‘\[They belong\] to Allah.’ Say, ‘Will you not then be wary \[of Him\]?’

# 2761

Say, ‘In whose hand is the dominion of all things, and who gives shelter and no shelter can be provided from Him, if you know?’

# 2762

They will say, ‘\[They all belong\] to Allah.’ Say, ‘Then how are you so deluded?’

# 2763

Indeed, We have brought them the truth, and they are indeed liars.

# 2764

Allah has not taken any offspring, neither is there any god besides Him, for then each god would take away what he created, and some of them would surely rise up against others. Clear is Allah of what they allege!

# 2765

The Knower of the sensible and the Unseen, He is above having any partners that they ascribe \[to Him\].

# 2766

Say, ‘My Lord! If You should show me what they are promised,

# 2767

then do not put me, my Lord, among the wrongdoing lot.’

# 2768

We are indeed able to show you what We promise them.

# 2769

Repel ill \[conduct\] with that which is the best. We know best whatever they allege.

# 2770

Say, ‘My Lord! I seek Your protection from the promptings of devils,

# 2771

and I seek Your protection, my Lord, from their presence near me.’

# 2772

When death comes to one of them, he says, ‘My Lord! Take me back,

# 2773

that I may act righteously in what I have left behind.’ ‘By no means! These are mere words that he says.’ And before them is a barrier until the day they will be resurrected.

# 2774

When the Trumpet is blown, there will be no ties between them on that day, nor will they ask \[about\] each other.

# 2775

Then those whose deeds weigh heavy in the scales—it is they who are the felicitous.

# 2776

As for those whose deeds weigh light in the scales—they will be the ones who have ruined their souls, and they will remain in hell \[forever\].

# 2777

The Fire will scorch their faces, while they snarl baring their teeth.

# 2778

‘Was it not that My signs were recited to you but you would deny them?’

# 2779

They will say, ‘Our Lord! Our wretchedness overcame us, and we were an astray lot.

# 2780

Our Lord! Bring us out of this! Then, if we revert \[to our previous conduct\], we will indeed be wrongdoers.’

# 2781

He will say, ‘Begone in it, and do not speak to Me!

# 2782

Indeed there was a part of My servants who would say, ‘‘Our Lord! We have believed. So forgive us, and have mercy on us, and You are the best of the merciful.’’

# 2783

But you took them by ridicule until they made you forget My remembrance, and you used to laugh at them.

# 2784

Indeed I have rewarded them today for their patience. They are indeed the triumphant.’

# 2785

He will say, ‘How many years did you remain on earth?’

# 2786

They will say, ‘We remained for a day, or part of a day; yet ask those who keep the count.’

# 2787

He will say, ‘You only remained a little; if only you had known.

# 2788

Did you suppose that We created you aimlessly, and that you will not be brought back to Us?’

# 2789

So exalted is Allah, the True Sovereign, there is no god except Him, the Lord of the Noble Throne.

# 2790

Whoever invokes besides Allah another god of which he has no proof, his reckoning will indeed rest with his Lord. Indeed the faithless will not be felicitous.

# 2791

Say, ‘My Lord, forgive and have mercy, and You are the best of the merciful.’

# 2792

\[This is\] a surah which We have sent down and prescribed, and We have sent down in it manifest signs so that you may take admonition.

# 2793

As for the fornicatress and the fornicator, strike each of them a hundred lashes, and let not pity for them overcome you in Allah’s law, if you believe in Allah and the Last Day, and let their punishment be witnessed by a group of the faithful.

# 2794

The fornicator will not marry anyone but a fornicatress or an idolatress, and the fornicatress will be married by none except a fornicator or an idolater, and that is forbidden to the faithful.

# 2795

As for those who accuse chaste women and do not bring four witnesses, strike them eighty lashes, and never accept any testimony from them after that, and they are transgressors,

# 2796

excepting those who repent after that and reform, for Allah is indeed all-forgiving, all-merciful.

# 2797

As for those who accuse their wives \[of adultery\], but have no witnesses except themselves, the testimony of such a man shall be a fourfold testimony \[sworn\] by Allah that he is indeed stating the truth,

# 2798

and a fifth \[oath\] that Allah’s wrath shall be upon him if he were lying.

# 2799

The punishment shall be averted from her by her testifying with four oaths \[sworn\] by Allah that he is indeed lying,

# 2800

and a fifth \[oath\] that Allah’s wrath shall be upon her if he were stating the truth.

# 2801

Were it not for Allah’s grace and His mercy upon you, and that Allah is all-clement, all-wise....

# 2802

Indeed those who initiated the calumny are a group from among yourselves. Do not suppose it is bad thing for you. No, it is for your good. Each man among them bears \[the onus for\] his share in the sin, and as for him who assumed its major burden from among them, there is a great punishment for him.

# 2803

When you \[first\] heard about it, why did not the faithful, men and women, think well of their folks, and say, ‘This is an obvious calumny’?

# 2804

Why did they not bring four witnesses to it? So when they could not bring the witnesses, they are liars in Allah’s sight.

# 2805

Were it not for Allah’s grace and His mercy upon you in this world and the Hereafter, there would have befallen you a great punishment for what you ventured into,

# 2806

when you were receiving it on your tongues, and were mouthing something of which you had no knowledge, supposing it to be a light matter, while it was a grave \[matter\] with Allah.

# 2807

And why did you not, when you heard it, say, ‘It is not for us to say such a thing. \[O Allah!\] You are immaculate! This is a monstrous calumny!’

# 2808

Allah advises you lest you should ever repeat the like of it, should you be faithful.

# 2809

Allah clarifies the signs for you, and Allah is all-knowing, all-wise.

# 2810

Indeed those who want indecency to spread among the faithful—there is a painful punishment for them in the world and the Hereafter, and Allah knows and you do not know.

# 2811

Were it not for Allah’s grace and His mercy upon you, and that Allah is all-kind, all-merciful...

# 2812

O you who have faith! Do not follow in Satan’s steps. Whoever follows in Satan’s steps \[should know that\] he indeed prompts \[you to commit\] indecent and wrongful acts. Were it not for Allah’s grace and His mercy upon you, not one of you would ever become pure. But Allah purifies whomever He wishes, and Allah is all-hearing, all-knowing.

# 2813

The well-off and the opulent among you should not vow that they will not give \[any longer\] to the relatives and the needy, and to those who have migrated in the way of Allah, and let them excuse and forbear. Do you not love that Allah should forgive you? Allah is all-forgiving, all-merciful.

# 2814

Indeed those who accuse chaste and unwary faithful women shall be cursed in this world and the Hereafter, and there shall be a great punishment for them

# 2815

on the day when witness shall be given against them by their tongues, their hands, and their feet concerning what they used to do.

# 2816

On that day, Allah will pay them in full their due recompense, and they shall know that Allah is the Manifest Reality.

# 2817

Vicious women are for vicious men, and vicious men for vicious women. Good women are for good men, and good men for good women. These are absolved of what they say \[about them\]. For them is forgiveness and a noble provision.

# 2818

O you who have faith! Do not enter houses other than your own until you have announced \[your arrival\] and greeted their occupants. That is better for you. Maybe you will take admonition.

# 2819

But if you do not find anyone in them, do not enter them until you are given permission. And if you are told: ‘Turn back,’ then do turn back. That is more decent for you. Allah knows best what you do.

# 2820

There will be no sin upon you in entering \[without announcing\] uninhabited houses wherein you have goods belonging to you. Allah knows whatever you disclose and whatever you conceal.

# 2821

Tell the faithful men to cast down their looks and to guard their private parts. That is more decent for them. Allah is indeed well aware of what they do.

# 2822

And tell the faithful women to cast down their looks and to guard their private parts, and not to display their charms, beyond what is \[acceptably\] visible, and let them draw their scarfs over their bosoms, and not display their charms except to their husbands, or their fathers, or their husband’s fathers, or their sons, or their husband’s sons, or their brothers, or their brothers’ sons, or their sisters’ sons, or their women, or their slave girls, or male dependants lacking \[sexual\] desire, or children who are not yet conscious of female sexuality. And let them not thump their feet to make known their hidden ornaments. Rally to Allah in repentance, O faithful, so that you may be felicitous.

# 2823

Marry off those who are single among you, and the upright among your male and female slaves. If they are poor, Allah will enrich them out of His grace, and Allah is all-bounteous, all-knowing.

# 2824

Those who cannot afford marriage should be continent until Allah enriches them out of His grace. As for those who seek an emancipation deal from among your slaves, make such a deal with them if you know any good in them, and give them out of the wealth of Allah which He has given you. Do not compel your female slaves to prostitution when they desire to be chaste, seeking the transitory wares of the life of this world. Should anyone compel them, Allah will be forgiving and merciful to them following their compulsion.

# 2825

Certainly We have sent down to you manifest signs and a description of those who passed before you, and an advice for the Godwary.

# 2826

Allah is the Light of the heavens and the earth. The parable of His Light is a niche wherein is a lamp—the lamp is in a glass, the glass as it were a glittering star—lit from a blessed olive tree, neither eastern nor western, whose oil almost lights up, though fire should not touch it. Light upon light. Allah guides to His Light whomever He wishes. Allah draws parables for mankind, and Allah has knowledge of all things.

# 2827

In houses Allah has allowed to be raised and wherein His Name is celebrated; He is glorified therein, morning and evening,

# 2828

by men whom neither trade nor bargaining distracts from the remembrance of Allah and the maintenance of prayer and the giving of zakat. They are fearful of a day wherein the hearts and the sights will be transformed,

# 2829

so that Allah may reward them by the best of what they have done, and enhance them out of His grace, and Allah provides for whomever He wishes without any reckoning.

# 2830

As for the faithless, their works are like a mirage in a plain, which the thirsty man supposes to be water. When he comes to it, he finds it to be nothing; but there he finds Allah, who will pay him his full account, and Allah is swift at reckoning.

# 2831

Or like the manifold darkness in a deep sea, covered by billow upon billow, overcast by clouds; manifold \[layers of\] darkness, one on top of another: when he brings out his hand, he can hardly see it. One whom Allah has not granted any light has no light.

# 2832

Have you not regarded that Allah is glorified by everyone in the heavens and the earth, and the birds spreading their wings. Each knows his prayer and glorification, and Allah knows best what they do.

# 2833

To Allah belongs the kingdom of the heavens and the earth, and toward Allah is the destination.

# 2834

Have you not regarded that Allah drives the clouds, then He composes them, then He piles them up, whereat you see the rain issuing from its midst? And He sends down hail from the sky, out of the mountains that are in it, and He strikes with it whomever He wishes, and turns it away from whomever He wishes. The brilliance of its lightening almost takes away the sight.

# 2835

Allah alternates the night and the day. There is indeed a lesson in that for those who have insight.

# 2836

Allah created every animal from water. Among them are some that creep upon their bellies, and among them are some that walk on two feet, and among them are some that walk on four. Allah creates whatever He wishes. Indeed Allah has power over all things.

# 2837

Certainly We have sent down illuminating signs, and Allah guides whomever He wishes to a straight path.

# 2838

They say, ‘We have faith in Allah and His Apostle, and we obey.’ Then, after that, a part of them refuse to comply, and they do not have faith.

# 2839

When they are summoned to Allah and His Apostle that He may judge between them, behold, a part of them turn aside.

# 2840

But if justice be on their side, they come compliantly to him.

# 2841

Is there a sickness in their hearts? Do they have doubts, or fear that Allah and His Apostle will be unjust to them? Indeed, it is they who are the wrongdoers.

# 2842

All the response of the faithful, when they are summoned to Allah and His Apostle that He may judge between them, is to say, ‘We hear and obey.’ It is they who are the felicitous.

# 2843

Whoever obeys Allah and His Apostle, and fears Allah and is wary of Him—it is they who will be the triumphant.

# 2844

They swear by Allah with solemn oaths that if you order them they will surely march out. Say, ‘Do not swear! Honourable obedience \[is all that is expected of you\]. Allah is indeed well aware of what you do.’

# 2845

Say, ‘Obey Allah, and obey the Apostle.’ But if you turn your backs, \[you should know that\] he is only responsible for his burden and you are responsible for your own burden, and if you obey him, you will be guided, and the Apostle’s duty is only to communicate in clear terms.

# 2846

Allah has promised those of you who have faith and do righteous deeds that He will surely make them successors in the earth, just as He made those who were before them successors, and He will surely establish for them their religion which He has approved for them, and that He will surely change their state to security after their fear, while they worship Me, not ascribing any partners to Me. Whoever is ungrateful after that—it is they who are the transgressors.

# 2847

Maintain the prayer and give the zakat, and obey the Apostle so that you may receive \[Allah’s\] mercy.

# 2848

Do not suppose that those who are faithless can frustrate \[Allah\] on the earth. Their refuge shall be the Fire, and it is surely an evil destination.

# 2849

O you who have faith! Your slaves and any of you who have not yet reached puberty should seek your permission three times: before the dawn prayer, and when you put off your garments at noon, and after the night prayer. These are three times of privacy for you. Apart from these, it is not sinful of you or them to frequent one another \[freely\]. Thus does Allah clarify the signs for you, and Allah is all-knowing, all-wise.

# 2850

When your children reach puberty, let them ask permission \[at all times\] just as those \[who grew up\] before them asked permission. Thus does Allah clarify His signs for you, and Allah is all-knowing, all-wise.

# 2851

As for women advanced in years who do not expect to marry, there will be no sin upon them if they put off their cloaks, without displaying their adornment. But it is better for them to be modest, and Allah is all-hearing, all-knowing.

# 2852

There is no blame upon the blind, nor any blame upon the lame, nor any blame upon the sick, nor upon yourselves if you eat from your own houses, or your fathers’ houses, or your mothers’ houses, or your brothers’ houses, or your sisters’ houses, or the houses of your paternal uncles, or the houses of your paternal aunts, or the houses of your maternal uncles, or the houses of your maternal aunts, or those whose keys are in your possession, or those of your friends. There will be no blame on you whether you eat together or separately. So when you enter houses, greet yourselves with a salutation from Allah, blessed and good. Thus does Allah clarify His signs for you so that you may exercise your reason.

# 2853

Indeed the faithful are those who have faith in Allah and His Apostle, and when they are with him in a collective affair, they do not leave until they have sought his permission. Indeed those who seek your permission are those who have faith in Allah and His Apostle. So when they seek your permission for some of theirs \[private\] work, give permission to whomever of them you wish and plead with Allah to forgive them. Indeed Allah is all-forgiving, all-merciful.

# 2854

Do not consider the Apostle’s summons amongst you to be like your summoning one another. Allah certainly knows those of you who slip away shielding one another. Those who disobey his orders should beware lest an affliction should visit them or a painful punishment should befall them.

# 2855

Behold! To Allah indeed belongs whatever is in the heavens and the earth. He certainly knows your present state. The day they are brought back to Him He will inform them about what they have done, and Allah has knowledge of all things.

# 2856

Blessed is He who sent down the Criterion to His servant that he may be a warner to all the nations.

# 2857

He, to whom belongs the sovereignty of the heavens and the earth, and who did not take any offspring, nor has He any partner in sovereignty, and He created everything and determined it in a precise measure.

# 2858

Yet they have taken gods besides Him who create nothing and have themselves been created, and who have no control over their own harm or benefit and have no control over \[their own\] death, life, or resurrection.

# 2859

The faithless say, ‘This is nothing but a lie that he has fabricated, and other people have abetted him in it.’ Thus they have certainly come out with wrongdoing and falsehood.

# 2860

They say, ‘He has taken down myths of the ancients, and they are dictated to him morning and evening.’

# 2861

Say, ‘It has been sent down by Him who knows the hidden in the heavens and the earth. Indeed He is all-forgiving, all-merciful.’

# 2862

And they say, ‘What sort of apostle is this who eats food and walks in the marketplaces? Why has not an angel been sent down to him so as to be a warner along with him?’

# 2863

Or, ‘\[Why is not\] a treasure thrown to him, or \[why does\] he \[not\] have a garden from which he may eat?’ And the wrongdoers say, ‘You are just following a bewitched man.’

# 2864

Look, how they coin epithets for you; so they go astray, and cannot find the way.

# 2865

Blessed is He who will grant you better than that if He wishes—gardens with streams running in them, and He will make for you palaces.

# 2866

Indeed, they deny the Hour, and We have prepared a Blaze for those who deny the Hour.

# 2867

When it sights them from a distant place, they will hear it raging and roaring.

# 2868

And when they are cast into a narrow place in it, bound together \[in chains\], they will pray for \[their own\] annihilation.

# 2869

\[They will be told:\] ‘Do not pray for a single annihilation today, but pray for many annihilations!’

# 2870

Say, ‘Is that better, or the everlasting paradise promised to the Godwary, which will be their reward and destination?’

# 2871

There they will have whatever they wish, abiding \[forever\]—a promise \[much\] besought, \[binding\] on your Lord.

# 2872

On the day that He will muster them and those whom they worship besides Allah, He will say, ‘Was it you who led astray these servants of Mine, or did they themselves stray from the way?’

# 2873

They will say, ‘Immaculate are You! It does not behoove us to take any wali in Your stead! But You provided for them and their fathers until they forgot the Reminder, and they were a ruined lot.’

# 2874

So they will certainly impugn you in what you say, and you will neither be able to circumvent \[punishment\] nor find help, and whoever of you does wrong, We shall make him taste a terrible punishment.

# 2875

We did not send any apostles before you but that they indeed ate food and walked in marketplaces. We have made you a \[means of\] test for one another, \[to see\] if you will be patient and steadfast, and your Lord is all-seeing.

# 2876

Those who do not expect to encounter Us say, ‘Why have angels not been sent down to us, or why do we not see our Lord?’ Certainly, they are full of arrogance within their souls and have become terribly defiant.

# 2877

The day they will see the angels, there will be no good news for the guilty on that day, and they will say, ‘Keep off \[from paradise\]!’

# 2878

Then We shall attend to the works they have done and then turn them into scattered dust.

# 2879

On that day the inhabitants of paradise will be in the best abode and an excellent resting place.

# 2880

The day when the sky with its clouds will be split open, and the angels will be sent down \[in a majestic\] descent,

# 2881

on that day true sovereignty will belong to the All-beneficent, and it will be a hard day for the faithless.

# 2882

It will be a day when the wrongdoer will bite his hands, saying, ‘I wish I had followed the Apostle’s way!

# 2883

Woe to me! I wish I had not taken so and so as a friend!

# 2884

Certainly he led me astray from the Reminder after it had come to me, and Satan is a deserter of man.’

# 2885

And the Apostle will say, ‘O my Lord! Indeed my people consigned this Quran to oblivion.’

# 2886

That is how for every prophet We assigned an enemy from among the guilty, and your Lord suffices as helper and guide.

# 2887

The faithless say, ‘Why has not the Quran been sent down to him all at once?’ So it was, that We may strengthen your heart with it, and We have recited it \[to you\] in a measured tone.

# 2888

They do not bring you any representation but that We bring you the truth \[in reply to them\] and the best exposition.

# 2889

Those who will be mustered \[fallen\] on their faces toward hell, they are the worse situated and further astray from the \[right\] way.

# 2890

Certainly We gave Moses the Book and We made Aaron, his brother, accompany him as a minister.

# 2891

Then We said, ‘Let the two of you go to the people who have denied Our signs.’ Then We destroyed them utterly.

# 2892

And Noah’s people, We drowned them when they impugned the apostles, and We made them a sign for mankind, and We have prepared for the wrongdoers a painful punishment.

# 2893

And ‘Ad and Thamud, and the people of Rass, and many generations between them.

# 2894

For each of them We drew examples, and each We destroyed utterly.

# 2895

Certainly they must have passed the town on which an evil shower was rained. Have they not seen it? Rather, they did not expect resurrection \[to happen\].

# 2896

When they see you they just take you in derision: ‘Is this the one whom Allah has sent as an apostle!?

# 2897

Indeed he was about to lead us astray from our gods, had we not stood firm by them.’ Soon they will know, when they sight the punishment, who is further astray from the \[right\] way.

# 2898

Have you seen him who has taken his desire to be his god? Is it your duty to watch over him?

# 2899

Do you suppose that most of them listen or exercise their reason? They are just like cattle; indeed, they are further astray from the way.

# 2900

Have you not regarded how your Lord spreads the twilight? (Had He wished He would have made it stand still.) Then We made the sun a beacon for it.

# 2901

Then We retract it toward Ourselves, with a gentle retracting.

# 2902

It is He who made for you the night as a covering and sleep for rest and He made the day a recall to life.

# 2903

And it is He who sends the winds as harbingers of His mercy, and We send down from the sky purifying water,

# 2904

with which We revive a dead country and provide water to many of the cattle and humans We have created.

# 2905

Certainly We distribute it among them so that they may take admonition. But most people are only intent on ingratitude.

# 2906

Had We wished, We would have sent a warner to every town.

# 2907

So do not obey the faithless, but wage a great jihad against them with it.

# 2908

It is He who merged the two seas: this one sweet and agreeable, and that one briny and bitter, and between the two He set a barrier and a forbidding hindrance.

# 2909

It is He who created the human being from water, then invested him with ties of blood and marriage, and your Lord is all-powerful.

# 2910

They worship besides Allah that which neither brings them any benefit nor causes them any harm, and the faithless one is ever an abettor against his Lord.

# 2911

We did not send you except as a bearer of good news and as a warner.

# 2912

Say, ‘I do not ask you any reward for it, except that anyone who wishes should take the way to his Lord.’

# 2913

Put your trust in the Living One who does not die, and celebrate His praise. He suffices as one all-aware of the sins of His servants.

# 2914

He, who created the heavens and the earth and whatever is between them in six days, and then settled on the Throne, the All-beneficent; so ask someone who is well aware about Him.

# 2915

When they are told: ‘Prostrate yourselves before the All-beneficent,’ they say, ‘What is ‘‘the All-beneficent’’? Shall we prostrate ourselves before whatever you bid us?’ And it increases their aversion.

# 2916

Blessed is He who appointed houses in the sky and set in it a lamp and a shining moon.

# 2917

It is He who made the night and the day alternate for someone who desires to take admonition, or desires to give thanks.

# 2918

The servants of the All-beneficent are those who walk humbly on the earth, and when the ignorant address them, say, ‘Peace!’

# 2919

Those who spend the night for their Lord, prostrating and standing \[in worship\].

# 2920

Those who say, ‘Our Lord! Turn away from us the punishment of hell. Indeed its punishment is enduring.

# 2921

Indeed it is an evil station and abode.’

# 2922

Those who are neither wasteful nor tightfisted when spending, but balanced between these \[two extremes\].

# 2923

Those who do not invoke another deity besides Allah, and do not kill a soul \[whose life\] Allah has made inviolable, except with due cause, and do not commit fornication. (Whoever does that shall encounter its retribution,

# 2924

the punishment being doubled for him on the Day of Resurrection. In it he will abide in humiliation forever,

# 2925

except those who repent, attain faith, and act righteously. For such, Allah will replace their misdeeds with good deeds, and Allah is all-forgiving, all-merciful.

# 2926

And whoever repents and acts righteously indeed turns to Allah with due penitence).

# 2927

Those who do not give false testimony, and when they come upon frivolity, pass by with dignity.

# 2928

Those who, when reminded of the signs of their Lord, do not turn a deaf ear and a blind eye to them.

# 2929

And those who say, ‘Our Lord! Give us joy and comfort in our spouses and offspring, and make us imams of the Godwary.’

# 2930

Those shall be rewarded with sublime abodes for their patience and steadfastness, and they shall be met there with greetings and ‘Peace,’

# 2931

to abide in them \[forever\], an excellent station and abode.

# 2932

Say, ‘Were it not for the sake of summoning you \[to faith\], what store my Lord would have set by you? But you impugned \[me and my summons\], so it will soon follow as a result.’

# 2933

Ta, Seen, Meem.

# 2934

These are the signs of the Manifest Book.

# 2935

You are liable to imperil your life \[out of distress\] that they will not have faith.

# 2936

If We wish We will send down to them a sign from the sky before which their heads will remain bowed in humility.

# 2937

There does not come to them any new reminder from the All-beneficent but that they disregard it.

# 2938

They have already denied \[the truth\], but soon there will come to them the news of what they have been deriding.

# 2939

Have they not regarded the earth, how many of every splendid kind \[of vegetation\] We have caused to grow in it?

# 2940

There is indeed a sign in that; but most of them do not have faith.

# 2941

Indeed your Lord is the All-mighty, the All-merciful.

# 2942

When your Lord called out to Moses: \[saying,\] ‘Go to those wrongdoing people,

# 2943

the people of Pharaoh. Will they not be wary \[of Allah\]?’

# 2944

He said, ‘My Lord! I fear they will impugn me,

# 2945

and I will become upset and my tongue will fail me. So send for Aaron \[to join me\].

# 2946

Besides, they have a charge against me, and I fear they will kill me.’

# 2947

He said, ‘Certainly not! Let both of you go with Our signs: We will indeed be with you, hearing \[everything\].

# 2948

So approach Pharaoh and say, ‘‘We are indeed envoys of the Lord of the worlds

# 2949

that you let the Children of Israel leave with us.’’ ’

# 2950

He \[i.e. Pharaoh\] said, ‘Did we not rear you as a child among us, and did you not stay with us for years of your life?

# 2951

Then you committed that deed of yours, and you are an ingrate.’

# 2952

He said, ‘I did that when I was astray.

# 2953

So I fled from you, as I was afraid of you. Then my Lord gave me sound judgement and made me one of the apostles.

# 2954

That you have enslaved the Children of Israel—is that the favour with which you reproach me?’

# 2955

He said, ‘And what is ‘‘the Lord of all the worlds?’’ ’

# 2956

He said, ‘The Lord of the heavens and the earth and whatever is between them,—should you have conviction.’

# 2957

He said to those who were around him, ‘Don’t you hear?!’

# 2958

He said, ‘Your Lord, and the Lord of your forefathers!’

# 2959

He said, ‘Indeed your messenger, who has been sent to you, is surely crazy!’

# 2960

He said, ‘The Lord of the east and the west and whatever is between them—should you exercise your reason.’

# 2961

He said, ‘If you take up any god other than me, I will surely make you a prisoner!’

# 2962

He said, ‘What if I bring you something \[as an\] unmistakable \[proof\]?’

# 2963

He said, ‘Then bring it, should you be truthful.’

# 2964

Thereat he threw down his staff, and behold, it was a manifest python.

# 2965

Then he drew out his hand, and behold, it was white and bright to the onlookers.

# 2966

He said to the elite \[who stood\] around him, ‘This is indeed an expert magician

# 2967

who seeks to expel you from your land with his magic. So what do you advise?’

# 2968

They said, ‘Put him and his brother off for a while, and send heralds to the cities

# 2969

to bring you every expert magician.’

# 2970

So the magicians were gathered for the tryst of a known day,

# 2971

and the people were told: ‘Will you all gather?!’

# 2972

‘Maybe we will follow the magicians, if they are victors!’

# 2973

So when the magicians came, they said to Pharaoh, ‘Shall we have a reward if we were to be the victors?’

# 2974

He said, ‘Of course; and you will be among members of my inner circle.’

# 2975

Moses said to them, ‘Throw down whatever you have to throw!’

# 2976

So they threw down their sticks and ropes, and said, ‘By the might of Pharaoh, we shall surely be victorious!’

# 2977

Thereat Moses threw down his staff, and behold, it was swallowing what they had faked.

# 2978

Thereat the magicians fell down prostrating.

# 2979

They said, ‘We believe in the Lord of all the worlds,

# 2980

the Lord of Moses and Aaron.’

# 2981

He \[i.e. Pharaoh\] said, ‘Do you profess faith in Him before I should permit you? He is indeed your chief who has taught you magic! Soon you will know! I will cut off your hands and feet from opposite sides, and I will crucify you all.’

# 2982

They said, ‘\[There is\] no harm \[in that\]! Indeed, we shall return to our Lord.

# 2983

Indeed we hope our Lord will forgive us our offences for being the first to believe.’

# 2984

Then We revealed to Moses, \[saying\],‘Set out with My servants at night, for you will be pursued.’

# 2985

Then Pharaoh sent heralds to the cities,

# 2986

\[proclaiming:\] ‘These are indeed a small band.

# 2987

They have aroused our wrath,

# 2988

and we are alert and fully prepared.’

# 2989

So We took them out of gardens and springs,

# 2990

and \[made them leave behind\] treasures and stately homes.

# 2991

So it was; and We bequeathed them to the Children of Israel.

# 2992

Then they pursued them at sunrise.

# 2993

When the two hosts sighted each other, the companions of Moses said, ‘Indeed we have been caught up.’

# 2994

He said, ‘Certainly not! Indeed my Lord is with me. He will guide me.’

# 2995

Thereupon We revealed to Moses: ‘Strike the sea with your staff!’ Whereupon it parted, and each part was as if it were a great mountain.

# 2996

There, We brought the others near,

# 2997

and We delivered Moses and all those who were with him.

# 2998

Then We drowned the rest.

# 2999

There is indeed a sign in that, but most of them do not have faith.

# 3000

Indeed your Lord is the All-mighty, the All-merciful.

# 3001

Relate to them the account of Abraham

# 3002

when he said to his father and his people, ‘What is it that you are worshiping?!’

# 3003

They said, ‘We worship idols, and are constant in our devotion to them.’

# 3004

He said, ‘Do they hear you when you call them?

# 3005

Or do they bring you any benefit, or cause you any harm?’

# 3006

They said, ‘Indeed, we found our fathers doing likewise.’

# 3007

He said, ‘Have you regarded what you have been worshipping,

# 3008

you and your ancestors?

# 3009

They are indeed enemies to me, but the Lord of all the worlds,

# 3010

who created me, it is He who guides me,

# 3011

and provides me with food and drink,

# 3012

and when I get sick, it is He who cures me;

# 3013

who will make me die, then He will bring me to life,

# 3014

and who, I hope, will forgive me my faults on the Day of Retribution.’

# 3015

‘My Lord! Grant me \[unerring\] judgement, and unite me with the Righteous.

# 3016

Confer on me a worthy repute among the posterity,

# 3017

and make me one of the heirs to the paradise of bliss.

# 3018

Forgive my father, for he is one of those who are astray.

# 3019

Do not disgrace me on the day that they will be resurrected,

# 3020

the day when neither wealth nor children will avail,

# 3021

except him who comes to Allah with a sound heart,’

# 3022

and paradise will be brought near for the Godwary,

# 3023

and hell will be brought into view for the perverse,

# 3024

and they shall be told: ‘Where is that which you used to worship

# 3025

besides Allah? Do they help you, or do they help each other?’

# 3026

Then they will be cast into it on their faces—they and the perverse,

# 3027

and the hosts of Iblis all together.

# 3028

They will say, as they wrangle in it \[together\],

# 3029

‘By Allah, we had indeed been in manifest error

# 3030

when we equated you with the Lord of all the worlds!

# 3031

No one led us astray except the guilty.

# 3032

Now we have no intercessors,

# 3033

nor do we have any sympathetic friend.

# 3034

Had there been another turn for us, we would be among the faithful.’

# 3035

There is indeed a sign in that; but most of them do not have faith.

# 3036

Indeed your Lord is the All-mighty, the All-merciful.

# 3037

The people of Noah impugned the apostles

# 3038

when Noah, their brother, said to them, ‘Will you not be wary \[of Allah\]?

# 3039

Indeed I am a trusted apostle \[sent\] to you.

# 3040

So be wary of Allah and obey me.

# 3041

I do not ask you any reward for it; my reward lies only with the Lord of all the worlds.

# 3042

So be wary of Allah and obey me.’

# 3043

They said, ‘Shall we believe in you, when it is the riffraff who follow you?’

# 3044

He said, ‘What do I know as to what they used to do?

# 3045

Their reckoning is only with my Lord, should you be aware.

# 3046

I will not drive away the faithful.

# 3047

I am just a manifest warner.’

# 3048

They said, ‘Noah, if you do not desist, you will certainly be stoned \[to death\].’

# 3049

He said, ‘My Lord! Indeed my people have impugned me.

# 3050

So judge conclusively between me and them, and deliver me and the faithful who are with me.’

# 3051

Thereupon We delivered him and those who were with him in the laden ark.

# 3052

Then We drowned the rest.

# 3053

There is indeed a sign in that; but most of them do not have faith.

# 3054

Indeed your Lord is the All-mighty, the All-merciful.

# 3055

\[The people of\] ‘Ad impugned the apostles,

# 3056

when Hud, their brother, said to them, ‘Will you not be wary \[of Allah\]?

# 3057

Indeed I am a trusted apostle \[sent\] to you.

# 3058

So be wary of Allah and obey me.

# 3059

I do not ask you any reward for it; my reward lies only with the Lord of all the worlds.

# 3060

Do you build futile a sign on every prominence?

# 3061

You set up structures as if you will be immortal,

# 3062

and when you seize \[someone for punishment\], you seize \[him\] like tyrants.

# 3063

So be wary of Allah and obey me.

# 3064

Be wary of Him who has provided you with whatever you know,

# 3065

and aided you with sons and with cattle,

# 3066

gardens and springs.

# 3067

Indeed I fear for you the punishment of a tremendous day.’

# 3068

They said, ‘It is the same to us whether you exhort us or not.

# 3069

These are nothing but the traditions of the ancients,

# 3070

and we will not be punished.’

# 3071

So they impugned him, whereupon We destroyed them. There is indeed a sign in that; but most of them do not have faith.

# 3072

Indeed your Lord is the All-mighty, the All-merciful.

# 3073

\[The people of\] Thamud impugned the apostles

# 3074

when Salih, their brother, said to them, ‘Will you not be wary \[of Allah\]?

# 3075

Indeed I am a trusted apostle \[sent\] to you.

# 3076

So be wary of Allah and obey me.

# 3077

I do not ask you any reward for it; my reward lies only with the Lord of all the worlds.

# 3078

Will you be left secure in that which is here

# 3079

—amid gardens and springs,

# 3080

farms and date palms with dainty spathes

# 3081

—while you skillfully hew out houses from the mountains?

# 3082

So be wary of Allah and obey me,

# 3083

and do not obey the dictates of the transgressors,

# 3084

who cause corruption in the land and do not bring about reform.’

# 3085

They said, ‘Indeed you are one of the bewitched.

# 3086

You are just a human being like us. So bring us a sign, should you be truthful.’

# 3087

He said, ‘This is a she-camel; she shall drink and you shall drink on known days.

# 3088

Do not cause her any harm, for then you shall be seized by the punishment of a terrible day.’

# 3089

But they hamstrung her, whereupon they became regretful.

# 3090

So the punishment seized them. There is indeed a sign in that; but most of them do not have faith.

# 3091

Indeed your Lord is the All-mighty, the All-merciful.

# 3092

The people of Lot impugned the apostles

# 3093

when Lot, their brother, said to them, ‘Will you not be wary \[of Allah\]?

# 3094

Indeed I am a trusted apostle \[sent\] to you.

# 3095

So be wary of Allah and obey me.

# 3096

I do not ask you any reward for it; my reward lies only with the Lord of all the worlds.

# 3097

What! Of all people do you come to males,

# 3098

abandoning your wives your Lord has created for you? Indeed, you are a transgressing lot.’

# 3099

They said, ‘Lot, if you do not desist, you will surely be banished.’

# 3100

He said, ‘Indeed I detest your conduct.’

# 3101

‘My Lord! Deliver me and my family from what they do.’

# 3102

So We delivered him and all his family,

# 3103

except an old woman who remained behind.

# 3104

Then We destroyed \[all\] the rest,

# 3105

and rained down upon them a rain \[of stones\]. Evil was the rain of those who were warned!

# 3106

There is indeed a sign in that; but most of them do not have faith.

# 3107

Indeed your Lord is the All-mighty, the All-merciful.

# 3108

The inhabitants of Aykah impugned the apostles,

# 3109

when Shu‘ayb said to them, ‘Will you not be wary \[of Allah\]?

# 3110

Indeed I am a trusted apostle \[sent\] to you.

# 3111

So be wary of Allah and obey me.

# 3112

I do not ask you any reward for it; my reward lies only with the Lord of all the worlds.

# 3113

Observe the full measure, and do not be of those who give short measure.

# 3114

Weigh with an even balance,

# 3115

and do not cheat the people of their goods. Do not act wickedly on the earth, causing corruption.

# 3116

Be wary of Him who created you and the earlier generations.’

# 3117

They said, ‘Indeed you are one of the bewitched.

# 3118

You are just a human being like us, and we indeed consider you to be a liar.

# 3119

Make a fragment of the sky falls upon us, should you be truthful.’

# 3120

He said, ‘My Lord knows best what you are doing.’

# 3121

So they impugned him, and then they were overtaken by the punishment of the day of the overshadowing cloud. It was indeed the punishment of a terrible day.

# 3122

There is indeed a sign in that; but most of them do not have faith.

# 3123

Indeed your Lord is the All-mighty, the All-merciful.

# 3124

This is indeed \[a Book\] sent down by the Lord of all the worlds,

# 3125

brought down by the Trustworthy Spirit

# 3126

upon your heart (so that you may be one of the warners),

# 3127

in a clear Arabic language.

# 3128

It is indeed \[foretold\] in the scriptures of the ancients.

# 3129

Is it not a sign for them that the learned of the Children of Israel recognize it?

# 3130

Had We sent it down upon some non-Arab

# 3131

and had he recited it to them, they would not have believed in it.

# 3132

This is how We let it pass through the hearts of the guilty:

# 3133

they do not believe in it until they sight the painful punishment.

# 3134

It will overtake them suddenly while they are unaware.

# 3135

Thereupon they will say, ‘Shall we be granted any respite?’

# 3136

So do they seek to hasten on Our punishment?

# 3137

Tell me, should We let them enjoy for some years,

# 3138

then there comes to them what they have been promised,

# 3139

of what avail to them will be that which they were given to enjoy?

# 3140

We have not destroyed any town without its having warners,

# 3141

for the sake of admonition, and We were not unjust.

# 3142

It has not been brought down by the devils.

# 3143

Neither does it behoove them, nor are they capable \[of doing that\].

# 3144

Indeed, they are kept at bay \[even\] from hearing it.

# 3145

So do not invoke any god besides Allah, lest you should be among the punished.

# 3146

Warn the nearest of your kinsfolk,

# 3147

and lower your wing to the faithful who follow you.

# 3148

But if they disobey you, say, ‘I am absolved of what you do.’

# 3149

And put your trust in the All-mighty, the All-merciful,

# 3150

who sees you when you stand \[for prayer\],

# 3151

and your going about among those who prostrate.

# 3152

Indeed He is the All-hearing, the All-knowing.

# 3153

Should I inform you on whom the devils descend?

# 3154

They descend on every sinful liar.

# 3155

They eavesdrop, and most of them are liars.

# 3156

As for the poets, \[only\] the perverse follow them.

# 3157

Have you not regarded that they rove in every valley,

# 3158

and that they say what they do not do?

# 3159

Barring those who have faith, do righteous deeds, and remember Allah much often, and vindicate themselves after they have been wronged. And the wrongdoers will soon know at what goal they will end up.

# 3160

Ta, Seen. These are the signs of the Quran and a manifest Book,

# 3161

a guidance and good news for the faithful

# 3162

—those who maintain the prayer and pay the zakat, and who are certain of the Hereafter.

# 3163

As for those who do not believe in the Hereafter, We have made their deeds seem decorous to them, and so they are bewildered.

# 3164

They are the ones for whom there is a terrible punishment, and they are the ones who will be the biggest losers in the Hereafter.

# 3165

Indeed you receive the Quran from One who is all-wise, all-knowing.

# 3166

When Moses said to his family, ‘Indeed I descry a fire! I will bring you some news from it, or bring you a firebrand so that you may warm yourselves.’

# 3167

When he came to it, he was called: ‘Blessed is He who is in the fire and who is \[as well\] around it, and immaculate is Allah, the Lord of all the worlds!’

# 3168

‘O Moses! Indeed I am Allah, the All-mighty, the All-wise.’

# 3169

‘Throw down your staff!’ When he saw it wriggling, as if it were a snake, he turned his back \[to flee\], without looking back. ‘O Moses! ‘Do not be afraid. Indeed the apostles are not afraid before Me,

# 3170

nor those who do wrong and then make up for \[their\] fault with goodness, for indeed I am all-forgiving, all-merciful.’

# 3171

‘Insert your hand into your shirt. It will emerge white and bright, without any fault—among nine signs meant for Pharaoh and his people. Indeed they are a transgressing lot.’

# 3172

But when Our signs came to them, as eye-openers, they said, ‘This is plain magic.’

# 3173

They impugned them, wrongfully and out of arrogance, though they were convinced in their hearts \[of their veracity\]. So observe how the fate of the agents of corruption was!

# 3174

Certainly, We gave knowledge to David and Solomon, and they said, ‘All praise belongs to Allah, who granted us an advantage over many of His faithful servants.’

# 3175

Solomon inherited from David, and he said, ‘O people! We have been taught the speech of the birds, and we have been given out of everything. Indeed this is a manifest advantage.’

# 3176

\[Once\] Solomon’s hosts were marched out for him, comprising jinn, humans and birds, and they were held in check.

# 3177

When they came to the Valley of Ants, an ant said, ‘O ants! Enter your dwellings, lest Solomon and his hosts should trample on you while they are unaware.’

# 3178

Whereat he smiled, amused at its words, and he said, ‘My Lord! Inspire me to give thanks for Your blessing with which You have blessed me and my parents, and that I may do righteous deeds which please You, and admit me, by Your mercy, among Your righteous servants.’

# 3179

\[One day\] he reviewed the birds, and said, ‘Why do I not see the hoopoe? Or is he absent?’

# 3180

‘I will punish him with a severe punishment, or I will behead him, unless he brings me a credible excuse.’

# 3181

He did not stay for long \[before he turned up\] and said, ‘I have alighted on something which you have not alighted on, and I have brought you from Sheba a definite report.

# 3182

I found a woman ruling over them, and she has been given everything, and she has a great throne.

# 3183

I found her and her people prostrating to the sun instead of Allah, and Satan has made their deeds seem decorous to them—thus he has barred them from the way \[of Allah\], so they are not guided—

# 3184

so that they do not prostrate themselves to Allah, who brings forth the hidden in the heavens and the earth, and He knows whatever you hide and whatever you disclose.

# 3185

Allah—there is no god except Him—is the Lord of the Great Throne.’

# 3186

He said, ‘We shall see whether you are truthful, or if you are one of the liars.

# 3187

Take this letter of mine and deliver it to them. Then draw away from them and observe what \[response\] they return.’

# 3188

She said, ‘O \[members of the\] elite! Indeed a noble letter has been delivered to me.

# 3189

It is from Solomon, and it begins in the name of Allah, the All-beneficent, the All-merciful.

# 3190

\[It states,\] ‘‘Do not defy me, and come to me in submission.’’ ’

# 3191

She said, ‘O \[members of the\] elite! Give me your opinion concerning my matter. I do not decide any matter until you are present.’

# 3192

They said, ‘We are powerful and possess a great might. But it is up to you to command. So consider what orders you will give.’

# 3193

She said, ‘Indeed when kings enter a town, they devastate it, and make the mightiest of its people the weakest. That is how they act.

# 3194

I will send them a gift, and see what the envoys bring back.’

# 3195

So when he came to Solomon, he said, ‘Are you aiding me with wealth? What Allah has given me is better than what He has given you. Indeed, you are proud of your gift!

# 3196

Go back to them, for we will come at them with hosts which they cannot face, and we will expel them from it, abased and degraded.’

# 3197

He said, ‘O \[members of the\] elite! Which of you will bring me her throne before they come to me in submission?’

# 3198

An afreet from among the jinn said, ‘I will bring it to you before you rise from your place. I have the power to do it and am trustworthy.’

# 3199

The one who had knowledge of the Book said, ‘I will bring it to you in the twinkling of an eye.’ So when he saw it set near him, he said, ‘This is by the grace of my Lord, to test me if I will give thanks or be ungrateful. Whoever gives thanks, gives thanks only for his own sake. And whoever is ungrateful \[should know that\] my Lord is indeed all-sufficient, all-generous.’

# 3200

He said, ‘Disguise her throne for her, so that we may see whether she is discerning or if she is one of the undiscerning ones.’

# 3201

So when she came, it was said \[to her\], ‘Is your throne like this one?’ She said, ‘It seems to be the same, and we were informed before it, and we had submitted.’

# 3202

She had been barred \[from the way of Allah\] by what she used to worship besides Allah, for she belonged to a faithless people.

# 3203

It was said to her, ‘Enter the palace.’ So when she saw it, she supposed it to be a pool of water, and she bared her shanks. He said, ‘It is a palace paved with crystal.’ She said, ‘My Lord! Indeed I have wronged myself, and I submit with Solomon to Allah, the Lord of all the worlds.’

# 3204

Certainly We sent to Thamud Salih, their brother, \[with the summons:\] ‘Worship Allah!’ But thereat they became two groups contending with each other.

# 3205

He said, ‘O My people! Why do you press for evil sooner than for good? Why do you not plead to Allah for forgiveness so that you may receive His mercy?’

# 3206

They said, ‘We take you and those who are with you for a bad omen.’ He said, ‘Your bad omens are from Allah. Indeed, you are a people being tested.’

# 3207

There were nine persons in the city who caused corruption in the land and did not set things right.

# 3208

They said, ‘Swear by Allah that we will attack him and his family by night. Then we will tell his heir that we were not present at the murder of his family and that we speak the truth.’

# 3209

They devised a plot, and We \[too\] devised a plan, but they were not aware.

# 3210

So observe how was the outcome of their plotting, as We destroyed them and all their people.

# 3211

So there lay their houses, fallen in ruin because of their wrongdoing. There is indeed a sign in that for a people who have knowledge.

# 3212

And We delivered those who had faith and were Godwary.

# 3213

\[We also sent\] Lot, when he said to his people, ‘What! Do you commit this indecency while you look on?

# 3214

Do you approach men with \[sexual\] desire instead of women?! Indeed, you are a senseless lot!’

# 3215

But the only answer of his people was that they said, ‘Expel Lot’s family from your town! They are indeed a puritanical lot.’

# 3216

So We delivered him and his family, except his wife. We ordained her to be among those who remained behind.

# 3217

Then We poured down upon them a rain \[of stones\]. Evil was that rain for those who had been warned!

# 3218

Say, ‘All praise belongs to Allah, and Peace be to the servants whom He has chosen.’ Is Allah better, or the partners they ascribe \[to Him\]?

# 3219

Is He who created the heavens and the earth, and sends down for you water from the sky, whereby We grow delightful gardens, whose trees you could never cause to grow...? What! Is there a god besides Allah? Indeed, they are a lot who equate \[others with Allah\].

# 3220

Is He who made the earth an abode \[for you\], and made rivers \[flowing\] through it, and set firm mountains for it \[’s stability\], and set a barrier between the two seas...? What! Is there a god besides Allah? Indeed, most of them do not know.

# 3221

Is He who answers the call of the distressed \[person\] when he invokes Him and removes his distress, and makes you successors on the earth...? What! Is there a god besides Allah? Little is the admonition that you take.

# 3222

Is He who guides you in the darkness of land and sea and who sends the winds as harbingers of His mercy...? What! Is there a god besides Allah? Exalted is Allah above \[having\] any partners that they ascribe \[to Him\].

# 3223

Is He who originates the creation, then He will bring it back, and who provides for you from the sky and the earth...? What! Is there a god besides Allah? Say, ‘Produce your evidence, if you are truthful.’

# 3224

Say, ‘No one in the heavens or the earth knows the Unseen except Allah, and they are not aware when they will be resurrected.’

# 3225

Do they comprehend the knowledge of the Hereafter? No, they are in doubt about it. Indeed, they are blind to it.

# 3226

The faithless say, ‘What! When we and our fathers have become dust shall we be raised \[from the dead\]?

# 3227

We and our fathers were promised this before. \[But\] these are just myths of the ancients.’

# 3228

Say, ‘Travel over the land and observe how was the fate of the guilty.’

# 3229

Do not grieve for them, and do not be upset by their guile.

# 3230

They say, ‘When will this promise be fulfilled, if you are truthful?’

# 3231

Say, ‘Perhaps there is right behind you some of what you seek to hasten.’

# 3232

Indeed your Lord is gracious to mankind, but most of them do not give thanks.

# 3233

Your Lord knows whatever their breasts conceal, and whatever they disclose.

# 3234

There is no invisible thing in the heaven and the earth but it is in a manifest Book.

# 3235

This Quran recounts for the Children of Israel most of what they differ about,

# 3236

and it is indeed a guidance and mercy for the faithful.

# 3237

Your Lord will decide between them by His judgement, and He is the All-mighty, the All-knowing.

# 3238

So put your trust in Allah, for you indeed stand on the manifest truth.

# 3239

You cannot make the dead hear, nor can you make the deaf listen to your call when they turn their backs,

# 3240

nor can you lead the blind out of their error. You can make only those hear you who believe in Our signs and have submitted.

# 3241

When the word \[of judgement\] falls upon them, We shall bring out for them an Animal from the earth who shall tell them that the people had no faith in Our signs.

# 3242

On that day We shall resurrect from every nation a group of those who denied Our signs, and they will be held in check.

# 3243

When they come, He will say, ‘Did you deny My signs without comprehending them in knowledge? What was it that you used to do?’

# 3244

And the word \[of judgement\] shall fall upon them for their wrongdoing, and they will not speak.

# 3245

Do they not see that We made the night that they may rest in it, and the day to provide visibility. There are indeed signs in that for a people who have faith.

# 3246

The day when the trumpet is blown, whoever is in the heavens and whoever is on the earth will be terrified, except such as Allah wishes, and all will come to Him in utter humility.

# 3247

You see the mountains, which you suppose, to be stationary, while they drift like passing clouds—the handiwork of Allah who has made everything faultless. He is indeed well aware of what you do.

# 3248

Whoever brings virtue shall receive \[a reward\] better than it; and on that day they will be secure from terror.

# 3249

But whoever brings vice—they shall be cast on their faces into the Fire \[and told:\] ‘Shall you not be requited for what you used to do?’

# 3250

\[Say\], ‘I have been commanded to worship the Lord of this city who has made it inviolable and to whom all things belong, and I have been commanded to be among those who submit \[to Allah\],

# 3251

and to recite the Quran.’ Whoever is guided is guided only for his own good, and as for him who goes astray, say, ‘I am just one of the warners.’

# 3252

And say, ‘All praise belongs to Allah. Soon He will show you His signs, and you will recognize them.’ Your Lord is not oblivious of what you do.

# 3253

Ta, Seen, Meem.

# 3254

These are the signs of the Manifest Book.

# 3255

We relate to you truly some of the account of Moses and Pharaoh for a people who have faith.

# 3256

Indeed Pharaoh tyrannized over the land, reducing its people to factions, abasing one group of them, slaughtering their sons, and sparing their women. Indeed, He was one of the agents of corruption.

# 3257

And We desired to show favour to those who were abased in the land, and to make them imams, and to make them the heirs,

# 3258

and to establish them in the land, and to show Pharaoh and Haman and their hosts from them that of which they were apprehensive.

# 3259

We revealed to Moses’ mother, \[saying\], ‘Nurse him; then, when you fear for him, cast him into the river, and do not fear or grieve, for We will restore him to you and make him one of the apostles.’

# 3260

Then Pharaoh’s kinsmen picked him up that he might be an enemy and a cause of grief to them. Indeed Pharaoh and Haman and their hosts were iniquitous.

# 3261

Pharaoh’s wife said \[to him\], ‘\[This infant will be\] a \[source of\] comfort to me and to you. Do not kill him. Maybe he will benefit us, or we will adopt him as a son.’ But they were not aware.

# 3262

The heart of Moses’ mother became desolate, and indeed she was about to divulge it had We not fortified her heart so that she might have faith \[in Allah’s promise\].

# 3263

She said to his sister, ‘Follow him.’ So she watched him from a distance, while they were not aware.

# 3264

Since before We had forbidden him to be suckled by any nurse. So she said, ‘Shall I show you a household that will take care of him for you and they will be his well-wishers?’

# 3265

That is how We restored him to his mother so that she might be comforted and not grieve, and that she might know that Allah’s promise is true, but most of them do not know.

# 3266

When he came of age and became fully matured, We gave him judgement and knowledge, and thus do We reward the virtuous.

# 3267

\[One day\] he entered the city at a time when its people were not likely to take notice. He found there two men fighting, this one from among his followers, and that one from his enemies. The one who was from his followers sought his help against him who was from his enemies. So Moses hit him with his fist, whereupon he expired. He said, ‘This is of Satan’s doing. Indeed he is clearly a misguiding enemy.’

# 3268

He said, ‘My Lord! I have wronged myself. Forgive me!’ So He forgave him. Indeed, He is the All-forgiving, the All-merciful.

# 3269

He said, ‘My Lord! As You have blessed me, I will never be a supporter of the guilty.’

# 3270

He rose at dawn in the city, fearful and vigilant, when behold, the one who had sought his help the day before, shouted for his help \[once again\]. Moses said to him, ‘You are indeed clearly perverse!’

# 3271

But when he wanted to strike him who was an enemy of both of them, he said, ‘Moses, do you want to kill me, just like the one you killed yesterday? You only want to be a tyrant in the land, and you do not desire to be one who brings about reform.’

# 3272

There came a man from the city outskirts, hurrying. He said, ‘Moses! The elite are indeed conspiring to kill you. So leave. I am indeed your well-wisher.’

# 3273

So he left the city, fearful and vigilant. He said, ‘My Lord! Deliver me from the wrongdoing lot.’

# 3274

And when he turned his face toward Midian, he said, ‘Maybe my Lord will show me the right way.’

# 3275

When he arrived at the well of Midian, he found there a throng of people watering \[their flocks\], and he found, besides them, two women holding back \[their flock\]. He said, ‘What is your business?’ They said, ‘We do not water \[our flock\] until the shepherds have driven out \[their flocks\], and our father is an aged man.’

# 3276

So he watered \[their flock\] for them. Then he withdrew toward the shade and said, ‘My Lord! I am indeed in need of any good You may send down to me!’

# 3277

Then one of the two women approached him, walking bashfully. She said, ‘Indeed my father invites you to pay you the wages for watering \[our flock\] for us.’ So when he came to him and recounted the story to him, he said, ‘Do not be afraid. You have been delivered from the wrongdoing lot.’

# 3278

One of the two women said, ‘Father, hire him. Indeed the best you can hire is a powerful and trustworthy man.’

# 3279

He said, ‘Indeed I desire to marry you to one of these two daughters of mine, on condition that you hire yourself to me for eight years. And if you complete ten, that will be up to you, and I do not want to be hard on you. God willing, you will find me to a righteous person.’

# 3280

He said, ‘This will be \[by consent\] between you and me. Whichever of the two terms I complete, there shall be no imposition upon me, and Allah is witness over what we say.’

# 3281

So when Moses completed the term and set out with his family, he descried a fire on the side of the mountain. He said to his family, ‘Wait! Indeed, I descry a fire! Maybe I will bring you some news from it, or a brand of fire so that you may warm yourselves.’

# 3282

When he approached it, he was called from the right bank of the valley in that blessed site from the tree: ‘Moses! Indeed I am Allah, the Lord of all the worlds!’

# 3283

And: ‘Throw down your staff!’ And when he saw it wriggling as if it were a snake, he turned his back \[to flee\], without looking back. ‘Moses! Come forward, and do not be afraid. Indeed you are safe.’

# 3284

‘Insert your hand into your shirt. It will emerge white, without any fault, and keep your arms drawn in awe to your sides. These shall be two proofs from your Lord to Pharaoh and his elite. They are indeed a transgressing lot.’

# 3285

He said, ‘My Lord! Indeed, I have killed one of their men, so I fear they will kill me.

# 3286

Aaron, my brother—he is more eloquent than me in speech. So send him with me as a helper to confirm me, for I fear that they will impugn me.’

# 3287

He said, ‘We will strengthen your arm by means of your brother, and invest both of you with such authority that they will not touch you. With the help of Our signs, you two, and those who follow the two of you, shall be the victors.’

# 3288

When Moses brought them Our manifest signs, they said, ‘This is nothing but concocted magic. We never heard of such a thing among our forefathers.’

# 3289

Moses said, ‘My Lord knows best who brings guidance from Him, and in whose favour the outcome of that abode will be. The wrongdoers will not be felicitous.’

# 3290

Pharaoh said, ‘O \[members of the\] elite! I do not know of any god that you may have besides me. Haman, light for me a fire over clay, and build me a tower so that I may take a look at Moses’ god, and indeed I consider him to be a liar!’

# 3291

He and his hosts unduly acted arrogantly in the land, and thought they would not be brought back to Us.

# 3292

So We seized him and his hosts, and threw them into the sea. So observe how was the fate of the wrongdoers!

# 3293

We made them leaders who invite to the Fire, and on the Day of Resurrection they will not receive any help.

# 3294

We made a curse pursue them in this world, and on the Day of Resurrection they will be among the disfigured.

# 3295

Certainly We gave Moses the Book, after We had destroyed the former generations, as \[a set of\] eye-openers, guidance and mercy for mankind, so that they may take admonition.

# 3296

You were not on the western side when We revealed the commandments to Moses, nor were you among the witnesses.

# 3297

But We brought forth other generations and time took its toll on them. You did not dwell among the people of Midian reciting to them Our signs, but it is We who are the senders \[of the apostles\].

# 3298

And you were not on the side of the Mount when We called out \[to Moses\], but \[We have sent you as\] a mercy from your Lord that you may warn a people to whom there did not come any warner before you, so that they may take admonition.

# 3299

And lest—if an affliction were to befall them because of what their hands have sent ahead —they should say, ‘Our Lord! Why did You not send us an apostle so that we might have followed Your signs and been among the faithful?’

# 3300

But when there came to them the truth from Us, they said, ‘Why has he not been given the like of what Moses was given?’ Did they not disbelieve what Moses was given before, and said, ‘Two magicians abetting each other,’ and said, ‘Indeed we disbelieve both of them’?

# 3301

Say, ‘If you are truthful, bring some Book from Allah better in guidance than the two on them so that I may follow it.’

# 3302

Then if they do not respond to you\[r\] \[summons\], know that they only follow their desires, and who is more astray than him who follows his desires without any guidance from Allah? Indeed Allah does not guide the wrongdoing lot.

# 3303

Certainly We have carried on this discourse for them so that they may take admonition.

# 3304

Those to whom We gave the Book before it are the ones who believe in it,

# 3305

and when it is recited to them, they say, ‘We believe in it. It is indeed the truth from our Lord. Indeed we were Muslims \[even\] before it \[came\].’

# 3306

Those will be given their reward two times for their patience. They repel evil \[conduct\] with good, and spend out of what We have provided them,

# 3307

and when they hear vain talk, they avoid it and say, ‘Our deeds belong to us, and your deeds belong to you. Peace be to you. We do not court the ignorant.’

# 3308

You cannot guide whomever you wish, but \[it is\] Allah \[who\] guides whomever He wishes, and He knows best those who are guided.

# 3309

They say, ‘If we follow the guidance with you, we will be forced out of our territory.’ Did We not establish a secure sanctuary for them where fruits of all kinds are brought as a provision from Us? But most of them do not know.

# 3310

How many a town We have destroyed that exulted in its lifestyle! There lie their dwellings, uninhabited after them except by a few, and We were the \[sole\] inheritors.

# 3311

Your Lord would not destroy the towns until He had raised an apostle in their mother city to recite to them Our signs. We would never destroy the towns except when their people were wrongdoers.

# 3312

Whatever things you have been given are only the wares of the life of this world and its glitter, and what is with Allah is better and more lasting. Will you not exercise your reason?

# 3313

Is he to whom We have given a good promise, which he will receive, like him whom We have provided the wares of the life of this world, but who will be arraigned on the Day of Resurrection?

# 3314

The day He will call out to them and ask, ‘Where are My ‘partners’ that you used to claim?’

# 3315

Those against whom the word had become due will say, ‘Our Lord! These are the ones whom we have perverted. We perverted them as we were perverse ourselves. We repudiate them before You: it was not us that they worshipped.’

# 3316

It will be said, ‘Invoke your partners!’ So they will invoke them, but they will not respond to them, and they will sight the punishment, wishing they had followed guidance.

# 3317

The day He will call out to them and say, ‘What response did you give to the apostles?’

# 3318

That day all information will be withheld from them, so they will not question one another.

# 3319

As for him who repents, has faith and acts righteously, maybe he will be among the felicitous.

# 3320

Your Lord creates whatever He wishes and chooses: they have no choice. Immaculate is Allah and exalted above \[having\] any partners that they ascribe \[to Him\].

# 3321

Your Lord knows whatever their breasts conceal, and whatever they disclose.

# 3322

He is Allah, there is no god except Him. All praise belongs to Him in this world and the Hereafter. All judgement belongs to Him, and to Him you will be brought back.

# 3323

Say, ‘Tell me, if Allah were to make the night perpetual for you until the Day of Resurrection, what god other than Allah can bring you light? Will you not listen?’

# 3324

Say, ‘Tell me, if Allah were to make the day perpetual for you until the Day of Resurrection, what god other than Allah can bring you night wherein you can rest? Will you not perceive?’

# 3325

He has made for you the night and the day out of His mercy, so that you may rest therein and that you may seek His bounty and so that you may give thanks.

# 3326

The day He will call out to them and say, ‘Where are My ‘partners’ that you used to claim?’

# 3327

We shall draw from every nation a witness and say, ‘Produce your evidence.’ Then they will know that all reality belongs to Allah and what they used to fabricate will forsake them.

# 3328

Korah indeed belonged to the people of Moses, but he bullied them. We had given him so much treasures that their chests indeed proved heavy for a band of stalwarts. When his people said to him, ‘Do not boast! Indeed Allah does not like the boasters.

# 3329

Seek the abode of the Hereafter by means of what Allah has given you, while not forgetting your share of this world. Be good \[to others\] just as Allah has been good to you, and do not try to cause corruption in the land. Indeed Allah does not like the agents of corruption.’

# 3330

He said, ‘I have indeed been given \[all\] this because of the knowledge that I have.’ Did he not know that Allah had already destroyed before him some of the generations who were more powerful than him and greater in amassing \[wealth\]? The guilty will not be questioned about their sins.

# 3331

So he emerged before his people in his finery. Those who desired the life of the world said, ‘We wish we had like what Korah has been given! Indeed he is greatly fortunate.’

# 3332

Those who were given knowledge said \[to them\], ‘Woe to you! Allah’s reward is better for someone who has faith and acts righteously, and no one will receive it except the patient.’

# 3333

So We caused the earth to swallow him and his house, and he had no party that might protect him from Allah, nor could he rescue himself.

# 3334

By dawn those who longed to be in his place the day before were saying, ‘Don’t you see that Allah expands the provision for whomever He wishes of His servants, and tightens it? Had Allah not shown us favour, He might have made the earth swallow us too. Don’t you see that the faithless do not prosper?’

# 3335

This is the abode of the Hereafter, which We shall grant to those who do not desire to domineer in the earth nor to cause corruption, and the outcome will be in favour of the Godwary.

# 3336

Whoever brings virtue shall receive \[a reward\] better than it, but whoever brings vice—those who commit misdeeds shall not be requited except for what they used to do.

# 3337

Indeed He who has revealed to you the Quran will surely restore you to the place of return. Say, ‘My Lord knows best him who brings guidance and him who is in manifest error.’

# 3338

You did not expect that the Book would be delivered to you; but it was a mercy from your Lord. So do not be ever an advocate of the faithless.

# 3339

Do not ever let them bar you from Allah’s signs after they have been sent down to you. Invite to your Lord, and never be one of the polytheists.

# 3340

And do not invoke another god besides Allah; there is no god except Him. Everything is to perish except His Face. All judgement belongs to Him, and to Him you will be brought back.

# 3341

Alif, Lam, Meem.

# 3342

Do the people suppose that they will be let off because they say, ‘We have faith,’ and they will not be tested?

# 3343

Certainly We tested those who were before them. So Allah shall surely ascertain those who are truthful, and He shall surely ascertain the liars.

# 3344

Do those who commit misdeeds suppose that they can outmaneuver Us? Evil is the judgement that they make.

# 3345

Whoever expects to encounter Allah \[should know that\] Allah’s \[appointed\] time will indeed come, and He is the All-hearing, the All-knowing.

# 3346

Whoever strives, strives only for his own sake. Indeed Allah has no need of the creatures.

# 3347

As for those who have faith and do righteous deeds, We will absolve them of their misdeeds and We will surely reward them by the best of what they used to do.

# 3348

We have enjoined man to be good to his parents. But if they urge you to ascribe to Me as partner that of which you have no knowledge, then do not obey them. To Me will be your return, whereat I will inform you concerning what you used to do.

# 3349

Those who have faith and do righteous deeds, We will surely admit them among the righteous.

# 3350

Among the people there are those who say, ‘We have faith in Allah,’ but if such a one is tormented in Allah’s cause, he takes persecution by the people for Allah’s punishment. Yet if there comes any help from your Lord, they will say, ‘We were indeed with you.’ Does not Allah know best what is in the breasts of the creatures?

# 3351

Allah shall surely ascertain those who have faith, and He shall surely ascertain the hypocrites.

# 3352

The faithless say to the faithful, ‘Follow our way and we will bear \[responsibility for\] your iniquities.’ They will not bear anything of their iniquities. They are indeed liars.

# 3353

But they will carry their own burdens and other burdens along with their own burdens, and they will surely be questioned on the Day of Resurrection concerning that which they used to fabricate.

# 3354

Certainly We sent Noah to his people, and he remained with them for a thousand-less-fifty years. Then the flood overtook them while they were wrongdoers.

# 3355

Then We delivered him and those who were in the Ark, and made it a sign for all the nations.

# 3356

And Abraham, when he said to his people, ‘Worship Allah and be wary of Him. That is better for you, should you know.

# 3357

What you worship instead of Allah are mere idols, and you invent a lie. Indeed those whom you worship besides Allah have no control over your provision. So seek all \[your\] provision from Allah, and worship Him and thank Him, and to Him you shall be brought back.’

# 3358

If you impugn \[the Apostle’s teaching\], then \[other\] nations have impugned \[likewise\] before you, and the Apostle’s duty is only to communicate in clear terms.

# 3359

Have they not regarded how Allah originates the creation? Then He will bring it back. That is indeed easy for Allah.

# 3360

Say, ‘Travel over the land and observe how He has originated the creation.’ Then Allah will bring about the genesis of the Hereafter. Indeed Allah has power over all things.

# 3361

He will punish whomever He wishes and have mercy on whomever He wishes, and to Him you will be returned.

# 3362

You cannot frustrate Him on the earth or in the sky, nor do you have besides Allah any guardian or helper.

# 3363

Those who deny the signs of Allah and the encounter with Him—they have despaired of My mercy, and for such there is a painful punishment.

# 3364

But the only answer of his people was that they said, ‘Kill him, or burn him.’ Then Allah delivered him from the fire. There are indeed signs in that for a people who have faith.

# 3365

He said, ‘You have taken idols \[for worship\] besides Allah for the sake of \[mutual\] affection amongst yourselves in the life of the world. Then on the Day of Resurrection you will disown one another and curse one another, and the Fire will be your abode, and you will not have any helpers.’

# 3366

Thereupon Lot believed in him, and he said, ‘Indeed I am migrating toward my Lord. Indeed He is the All-mighty, the All-wise.’

# 3367

And We gave him Isaac and Jacob, and We ordained among his descendants prophethood and the Book, and We gave him his reward in this world, and in the Hereafter he will indeed be among the Righteous.

# 3368

And Lot, when he said to his people, ‘You indeed commit an indecency none in the world has ever committed before you!

# 3369

What! Do you come to men, and cut off the way, and commit outrages in your gatherings?’ But the only answer of his people was that they said, ‘Bring down us Allah’s punishment, if you are truthful.’

# 3370

He said, ‘My Lord! Help me against this corruptive lot.’

# 3371

And when Our messengers came to Abraham with the good news, they said, ‘We are indeed going to destroy the people of this town. Its people are indeed wrongdoers.’

# 3372

He said, ‘Lot is in it.’ They said, ‘We know better those who are in it. We will surely deliver him and his family, except his wife: she shall be one of those who remain behind.’

# 3373

And when Our messengers came to Lot, he was distressed on their account and in a predicament for their sake. But they said, ‘Do not be afraid, nor grieve! We shall deliver you and your family, except your wife: she will be one of those who remain behind.

# 3374

We are indeed going to bring down upon the people of this town a punishment from the sky because of the transgressions they used to commit.’

# 3375

Certainly We have left of it a manifest sign for people who exercise their reason.

# 3376

And to Midian We sent Shu‘ayb, their brother. He said, ‘O my people! Worship Allah, and expect \[to encounter\] the Last Day, and do not act wickedly on the earth causing corruption.’

# 3377

But they impugned him, whereupon the earthquake seized them, and they lay lifeless prostrate in their homes.

# 3378

And ‘Ad and Thamud, \[whose fate\] is evident to you from their habitations. Satan made their deeds seem decorous to them, thus he barred them from the way \[of Allah\], though they used to be perceptive.

# 3379

And Korah, Pharaoh, and Haman. Certainly, Moses brought them manifest proofs, but they acted arrogantly in the land; though they could not outmaneuver \[Allah\].

# 3380

So We seized each \[of them\] for his sin: among them were those upon whom We unleashed a rain of stones, and among them were those who were seized by the Cry, and among them were those whom We caused the earth to swallow, and among them were those whom We drowned. It was not Allah who wronged them, but it was they who used to wrong themselves.

# 3381

The parable of those who take guardians instead of Allah is that of the spider that takes a home, and indeed the frailest of homes is the home of a spider, had they known!

# 3382

Allah indeed knows whatever thing they invoke besides Him, and He is the All-mighty, the All-wise.

# 3383

We draw these parables for mankind; but no one grasps them except those who have knowledge.

# 3384

Allah created the heavens and the earth with consummate wisdom. There is indeed a sign in that for the faithful.

# 3385

Recite what has been revealed to you of the Book, and maintain the prayer. Indeed the prayer restrains from indecent and wrongful conduct, and the remembrance of Allah is surely greater. And Allah knows whatever \[deeds\] you do.

# 3386

Do not argue with the People of the Book except in a manner which is best, except such of them as are wrongdoers, and say, ‘We believe in what has been sent down to us and in what has been sent down to you; our God and your God is one \[and the same\], and to Him do we submit.’

# 3387

Thus We have sent down the Book to you; those to whom We have given the Book believe in it, and of these there are some who believe in it, and none contests Our signs except the faithless.

# 3388

You did not use to recite any scripture before it, nor did you write it with your right hand, for then the impugners would have been skeptical.

# 3389

Indeed, it is \[present as\] manifest signs in the breasts of those who have been given knowledge, and none contests Our signs except wrongdoers.

# 3390

They say, ‘Why has not some sign been sent down to him from his Lord?’ Say, ‘These signs are only from Allah, and I am only a manifest warner.’

# 3391

Does it not suffice them that We have sent down to you the Book which is recited to them? There is indeed in that a mercy and admonition for a people who have faith.

# 3392

Say, ‘Allah suffices as a witness between me and you: He knows whatever there is in the heavens and the earth. Those who put faith in falsehood and defy Allah—it is they who are the losers.’

# 3393

They ask you to hasten the punishment. Yet were it not for a specified time, the punishment would have surely overtaken them. Surely, it will overtake them suddenly while they are unaware.

# 3394

They ask you to hasten the punishment, and indeed hell will besiege the faithless

# 3395

on the day when the punishment envelopes them, from above them and from under their feet, and He will say, ‘Taste what you used to do!’

# 3396

O My servants who have faith! My earth is indeed vast. So worship \[only\] Me.

# 3397

Every soul shall taste death. Then you shall be brought back to Us.

# 3398

Those who have faith and do righteous deeds, We will surely settle them in the lofty abodes of paradise, with streams running in them, to remain in them \[forever\]. How excellent is the reward of the workers!

# 3399

—Those who are patient and who put their trust in their Lord.

# 3400

How many an animal there is that does not carry its own provision. Allah provides them and you, and He is the All-hearing, the All-knowing.

# 3401

If you ask them, ‘Who created the heavens and the earth, and who has disposed the sun and the moon?’ They will surely say, ‘Allah.’ Then where do they stray?

# 3402

Allah expands the provision for whomever He wishes of His servants, and tightens it for him. Indeed Allah has knowledge of all things.

# 3403

And if you ask them, ‘Who sends down water from the sky, with which He revives the earth after its death?’ They will surely say, ‘Allah.’ Say, ‘All praise belongs to Allah!’ But most of them do not exercise their reason.

# 3404

The life of this world is nothing but diversion and play, but the abode of the Hereafter is indeed Life (itself), had they known!

# 3405

When they board the ship, they invoke Allah putting exclusive faith in Him, but when He delivers them to land, behold, they ascribe partners \[to Him\],

# 3406

being ungrateful for what We have given them! Let them enjoy. Soon they will know!

# 3407

Have they not seen that We have appointed a safe sanctuary, while the people are despoiled all around them? Would they then believe in falsehood and be ungrateful toward the blessing of Allah?

# 3408

Who is a greater wrongdoer than him who fabricates a lie against Allah, or denies the truth when it comes to him? Is not the \[final\] abode of the faithless in hell?

# 3409

As for those who strive in Us, We shall surely guide them in Our ways, and Allah is indeed with the virtuous.

# 3410

Alif, Lam, Meem.

# 3411

The Byzantines has been vanquished

# 3412

in a nearby land, but they, after their defeat, will be victorious

# 3413

in a few years. All command belongs to Allah, before this and hereafter, and on that day the faithful will rejoice

# 3414

at Allah’s help. He helps whomever He wishes, and He is the All-mighty, the All-merciful.

# 3415

\[This is\] a promise of Allah: Allah does not break His promise, but most people do not know.

# 3416

They know just an outward aspect of the life of the world, but they are oblivious of the Hereafter.

# 3417

Have they not reflected in their own souls? Allah did not create the heavens and the earth and whatever is between them except with consummate wisdom and for a specified term. Indeed many people disbelieve in the encounter with their Lord.

# 3418

Have they not travelled in the land and seen how was the fate of those who were before them? They were more powerful than them, and they plowed the earth and developed it more than they have developed it. Their apostles brought them manifest proofs. So it was not Allah who wronged them, but it was they who used to wrong themselves.

# 3419

Then the fate of those who committed misdeeds was that they denied the signs of Allah and they used to deride them.

# 3420

Allah originates the creation, then He will bring it back, then you will be brought back to Him.

# 3421

And when the Hour sets in, the guilty will despair.

# 3422

None of those whom they ascribed as partners \[to Allah\] will intercede for them, and they will disavow their partners.

# 3423

The day the Hour sets in, they will be divided on that day \[in separate groups\]:

# 3424

As for those who have faith and do righteous deeds, they shall be in a garden, rejoicing.

# 3425

But as for those who were faithless and denied Our signs and the encounter of the Hereafter, they will be brought to the punishment.

# 3426

So glorify Allah when you enter evening and when you rise at dawn.

# 3427

To Him belongs all praise in the heavens and the earth, at nightfall and when you enter noontime.

# 3428

He brings forth the living from the dead, and brings forth the dead from the living, and revives the earth after its death. Likewise, you \[too\] shall be raised \[from the dead\].

# 3429

Of His signs is that He created you from dust, then, behold, you are humans scattering \[all over\]!

# 3430

And of His signs is that He created for you mates from your own selves that you may take comfort in them, and He ordained affection and mercy between you. There are indeed signs in that for a people who reflect.

# 3431

Among His signs is the creation of the heavens and the earth, and the difference of your languages and colours. There are indeed signs in that for those who know.

# 3432

And of His signs is your sleep by night and day, and your pursuit of His bounty. There are indeed signs in that for a people who listen.

# 3433

And of His signs is that He shows you the lightning, arousing fear and hope, and He sends down water from the sky, and with it revives the earth after its death. There are indeed signs in that for people who exercise their reason.

# 3434

And of His signs is that the sky and the earth stand by His command, and then, when He calls you forth from the earth, behold, you will come forth.

# 3435

To Him belongs whoever is in the heavens and the earth. All are obedient to Him.

# 3436

It is He who originates the creation, and then He will bring it back—and that is more simple for Him. His is the loftiest description in the heavens and the earth, and He is the All-mighty, the All-wise.

# 3437

He draws for you an example from yourselves: Do you have among your slaves any partners \[who may share\] in what We have provided you, so that you are equal in its respect, and you revere them as you revere one another? Thus do We elaborate the signs for people who exercise their reason.

# 3438

Indeed, the wrongdoers follow their own desires without any knowledge. So who will guide those whom Allah has led astray? They will have no helpers.

# 3439

So set your heart as a person of pure faith on this religion, the original nature endowed by Allah according to which He originated mankind (There is no altering Allah’s creation; that is the upright religion, but most people do not know.)

# 3440

—turning to Him in penitence, and be wary of Him, and maintain the prayer, and do not be one of the polytheists

# 3441

—those who split up their religion and became sects: each faction boasting about what it possessed.

# 3442

When distress befalls people, they supplicate their Lord, turning to Him in penitence. Then, when He lets them taste His mercy, behold, a part of them ascribe partners to their Lord,

# 3443

being ungrateful toward what We have given them. So let them enjoy. Soon they will know!

# 3444

Have We sent down to them any authority which might assert what they associate with Him?

# 3445

When We let people taste \[Our\] mercy, they boast about it; but should an ill visit them because of what their hands have sent ahead, behold, they become despondent!

# 3446

Do they not see that Allah expands the provision for whomever He wishes, and tightens it? There are indeed signs in that for a people who have faith.

# 3447

Give the relative his due, and the needy and the traveller \[as well\]. That is better for those who seek Allah’s pleasure, and it is they who are the felicitous.

# 3448

What you give in usury in order that it may increase people’s wealth does not increase with Allah. But what you pay as zakat seeking Allah’s pleasure—it is they who will be given a manifold increase.

# 3449

It is Allah who created you and then He provided for you, then He makes you die, then He will bring you to life. Is there anyone among your ‘partners’ who does anything of that kind? Immaculate is He and exalted above \[having\] any partners that they ascribe \[to Him\]!

# 3450

Corruption has appeared in land and sea because of the doings of the people’s hands, that He may make them taste something of what they have done, so that they may come back.

# 3451

Say, ‘Travel over the land, and see how was the fate of those who were before \[you\], most of whom were polytheists.’

# 3452

So set your heart on the upright religion, before there comes a day irrevocable from Allah. On that day they shall be split \[into various groups\].

# 3453

Whoever is faithless shall face the consequences of his faithlessness, and those who act righteously only prepare for their own souls,

# 3454

so that He may reward those who have faith and do righteous deeds out of His grace. Indeed, He does not like the faithless.

# 3455

And of His signs is that He sends the winds as bearers of good news and to let you taste of His mercy, and that the ships may sail by His command, and that you may seek of His bounty, and so that you may give \[Him\] thanks.

# 3456

Certainly We sent apostles to their people before you, and they brought them manifest proofs. Then We took vengeance upon those who were guilty, and it was a must for Us to help the faithful.

# 3457

It is Allah who sends the winds. Then they generate a cloud, then He spreads it as He wishes in the sky, and forms it into fragments, whereat you see the rain issuing from its midst. Then, when He strikes with it whomever of His servants that He wishes, behold, they rejoice;

# 3458

and indeed they had been despondent earlier, before it was sent down upon them.

# 3459

So observe the effects of Allah’s mercy: how He revives the earth after its death! Indeed He is the reviver of the dead, and He has power over all things.

# 3460

And if We send a wind and they see it turn yellow, they will surely become ungrateful after that.

# 3461

Indeed you cannot make the dead hear, nor can you make the deaf hear the call when they turn their backs \[upon you\],

# 3462

nor can you lead the blind out of their error. You can make only those hear who have faith in Our signs and have submitted.

# 3463

It is Allah who created you from \[a state of\] weakness, then He gave you power after weakness. Then, after power, He ordained weakness and old age: He creates whatever He wishes, and He is the All-knowing, the All-powerful.

# 3464

On the day when the Hour sets in, the guilty will swear that they had remained only for an hour. That is how they were used to lying \[in the world\].

# 3465

But those who were given knowledge and faith will say, ‘Certainly you remained in Allah’s Book until the Day of Resurrection. This is the Day of Resurrection, but you did not know.’

# 3466

On that day, the excuses of the wrongdoers will not benefit them, nor will they be asked to propitiate \[Allah\].

# 3467

Certainly we have drawn for mankind in this Quran every \[kind of\] parable. Indeed if you bring them a sign, the faithless will surely say, ‘You are nothing but fabricators!’

# 3468

Thus does Allah seal the hearts of those who do not know.

# 3469

So be patient! Allah’s promise is indeed true. And do not let yourself be upset by those who have no conviction.

# 3470

Alif, Lam, Meem.

# 3471

These are the signs of the wise Book,

# 3472

a guidance and mercy for the virtuous,

# 3473

who maintain the prayer, pay the zakat, and are certain of the Hereafter.

# 3474

Those follow their Lord’s guidance, and it is they who are the felicitous.

# 3475

Among the people is he who buys diversionary talk that he may lead \[people\] astray from Allah’s way without any knowledge, and he takes it in derision. For such there is a humiliating punishment.

# 3476

When Our signs are recited to him he turns away disdainfully, as if he had not heard them \[at all\], as if there were a deafness in his ears. So inform him of a painful punishment.

# 3477

As for those who have faith and do righteous deeds, for them will be gardens of bliss,

# 3478

to remain in them \[forever\]—a true promise of Allah, and He is the All-mighty, the All-wise.

# 3479

He created the heavens without any pillars that you may see, and cast firm mountains in the earth lest it should shake with you, and He has scattered in it every kind of animal. And We sent down water from the sky and caused every splendid kind \[of plant\] to grow in it.

# 3480

This is the creation of Allah. Now show Me what others besides Him have created. Indeed, the wrongdoers are in manifest error!

# 3481

Certainly We gave Luqman wisdom, saying, ‘Give thanks to Allah; and whoever gives thanks, gives thanks only for his own sake. And whoever is ungrateful, \[let him know that\] Allah is indeed all-sufficient, all-laudable.’

# 3482

When Luqman said to his son, as he advised him: ‘O my son! Do not ascribe any partners to Allah. Polytheism is indeed a great injustice.’

# 3483

We have enjoined man concerning his parents: His mother carried him through weakness upon weakness, and his weaning takes two years. Give thanks to Me and to your parents. To Me is the return.

# 3484

But if they urge you to ascribe to Me as partner that of which you have no knowledge, then do not obey them. Keep their company honourably in this world and follow the way of those who turn to Me penitently. Then to Me will be your return, whereat I will inform you concerning what you used to do.

# 3485

‘O my son! Even if it should be the weight of a mustard seed, and \[even though\] it should be in a rock, or in the heavens, or in the earth, Allah will produce it. Indeed Allah is all-attentive, all-aware.

# 3486

O my son! Maintain the prayer and bid what is right and forbid what is wrong, and be patient through whatever may befall you. That is indeed the steadiest of courses.

# 3487

Do not turn your cheek away disdainfully from the people, and do not walk exultantly on the earth. Indeed Allah does not like any swaggering braggart.

# 3488

Be modest in your bearing, and lower your voice. Indeed the ungainliest of voices is the donkey’s voice.’

# 3489

Do you not see that Allah has disposed for you whatever there is in the heavens and whatever there is in the earth and He has showered upon you His blessings, the outward, and the inward? Yet among the people are those who dispute concerning Allah without any knowledge or guidance or an illuminating scripture.

# 3490

When they are told, ‘Follow what Allah has sent down,’ they say, ‘No, we will follow what we found our fathers following.’ What! Even if Satan be calling them to the punishment of the Blaze?

# 3491

Whoever surrenders his heart to Allah and is virtuous, has certainly held fast to the firmest handle, and with Allah lies the outcome of all matters.

# 3492

As for those who are faithless, let their faithlessness not grieve you. To Us will be their return, and We will inform them about what they have done. Indeed Allah knows best what is in the breasts.

# 3493

We will provide for them for a short time, then We will shove them toward a harsh punishment.

# 3494

If you ask them, ‘Who created the heavens and the earth?’ they will surely say, ‘Allah.’ Say, ‘All praise belongs to Allah!’ But most of them do not know.

# 3495

To Allah belongs whatever is in the heavens and the earth. Indeed Allah is the All-sufficient, the All-laudable.

# 3496

If all the trees on the earth were pens, and the sea replenished with seven more seas \[were ink\], the words of Allah would not be spent. Indeed Allah is all-mighty, all-wise.

# 3497

Your creation and your resurrection are not but as of a single soul. Indeed Allah is all-hearing, all-seeing.

# 3498

Have you not regarded that Allah makes the night pass into the day and makes the day pass into the night; and He has disposed the sun and the moon, each moving for a specified term, and that Allah is well aware of what you do?

# 3499

That is because Allah is the Reality, and whatever they invoke besides Him is nullity, and because Allah is the All-exalted, the All-great.

# 3500

Have you not regarded that the ships sail at sea with Allah’s blessing, that He may show you some of His signs? There are indeed signs in that for every patient and grateful \[servant\].

# 3501

When waves cover them like awnings; they invoke Allah, putting exclusive faith in Him. But when He delivers them towards land, \[only\] some of them remain unswerving. No one will impugn Our signs except an ungrateful traitor.

# 3502

O mankind! Be wary of your Lord and fear the day when a father will not atone for his child, nor the child will atone for its father in any wise. Indeed Allah’s promise is true. So do not let the life of the world deceive you, nor let the Deceiver deceive you concerning Allah.

# 3503

Indeed the knowledge of the Hour is with Allah. He sends down the rain, and He knows what is in the wombs. No soul knows what it will earn tomorrow, and no soul knows in what land it will die. Indeed Allah is all-knowing, all-aware.

# 3504

Alif, Lam, Meem.

# 3505

The \[gradual\] sending down of the Book, there is no doubt in it, is from the Lord of all the worlds.

# 3506

But they say, ‘He has fabricated it.’ No, it is the truth from your Lord, that you may warn a people to whom there did not come any warner before you, so that they may be guided \[to the right path\].

# 3507

It is Allah who created the heavens and the earth and whatever is between them in six days, then He settled on the Throne. You do not have besides Him any guardian or intercessor. Will you not then take admonition?

# 3508

He directs the command from the heaven to the earth; then it ascends toward Him in a day whose span is a thousand years by your reckoning.

# 3509

That is the Knower of the sensible and the Unseen, the All-mighty, the All-merciful,

# 3510

who perfected everything that He created and commenced man’s creation from clay.

# 3511

Then He made his progeny from an extract of a base fluid.

# 3512

Then He proportioned him and breathed into him of His Spirit, and made for you hearing, sight, and hearts. Little do you thank.

# 3513

They say, ‘When we have been lost in the dust, shall we be indeed created anew?’ Indeed, they disbelieve in the encounter with their Lord.

# 3514

Say, ‘You will be taken away by the angel of death, who has been charged with you. Then you will be brought back to your Lord.’

# 3515

Were you to see when the guilty hang their heads before their Lord \[confessing\], ‘Our Lord! We have seen and heard. Send us back so that we may act righteously. Indeed we are \[now\] convinced.’

# 3516

Had We wished We would have given every soul its guidance, but My word became due \[against the faithless\]: ‘Surely I will fill hell with all the \[guilty\] jinn and humans.’

# 3517

So taste \[the punishment\] for your having forgotten the encounter of this day of yours. We \[too\] have forgotten you. Taste the everlasting punishment because of what you used to do.

# 3518

Only those believe in Our signs who, when they are reminded of them, fall down in prostration and celebrate the praise of their Lord, and they are not arrogant.

# 3519

Their sides vacate their beds to supplicate their Lord in fear and hope, and they spend out of what We have provided them.

# 3520

No one knows what delights have been kept hidden for them \[in the Hereafter\] as a reward for what they used to do.

# 3521

Is someone who is faithful like someone who is a transgressor? They are not equal.

# 3522

As for those who have faith and do righteous deeds, for them will be the gardens of the Abode—a hospitality for what they used to do.

# 3523

As for those who have transgressed, their refuge will be the Fire. Whenever they seek to leave it, they will be turned back into it and told: ‘Taste the punishment of the Fire which you used to deny.’

# 3524

We shall surely make them taste the nearer punishment prior to the greater punishment, so that they may come back.

# 3525

Who is a greater wrongdoer than him who is reminded of his Lord’s signs, whereat he disregards them? Indeed, We shall take vengeance upon the guilty.

# 3526

Certainly We gave Moses the Book, \[declaring\], ‘Do not be in doubt about the encounter with Him,’ and We made it a \[source of\] guidance for the Children of Israel.

# 3527

When they had been patient and had conviction in Our signs, We appointed amongst them imams to guide \[the people\] by Our command.

# 3528

Indeed your Lord will judge between them on the Day of Resurrection concerning that about which they used to differ.

# 3529

Does it not dawn upon them how many generations We have destroyed before them, amid \[the ruins of\] whose dwellings they walk? There are indeed signs in that. Will they not then listen?

# 3530

Do they not see that We carry water to the parched earth and with it We bring forth crops, from which they eat, themselves and their cattle? Will they not then see?

# 3531

They say, ‘When will this judgement be, if you are truthful?’

# 3532

Say, ‘On the day of judgement their \[newly found\] faith will not avail the faithless, nor will they be granted any respite.’

# 3533

So turn away from them, and wait. They too are waiting.

# 3534

O Prophet! Be wary of Allah and do not obey the faithless and the hypocrites. Indeed Allah is all-knowing, all-wise.

# 3535

Follow that which is revealed to you from your Lord. Indeed Allah is well aware of what you do.

# 3536

And put your trust in Allah; Allah suffices as trustee.

# 3537

Allah has not put two hearts within any man, nor has He made your wives whom you repudiate by zihar your mothers, nor has he made your adopted sons your \[actual\] sons. These are mere utterances of your mouths. But Allah speaks the truth and He guides to the \[right\] way.

# 3538

Call them after their fathers. That is more just with Allah. If you do not know their fathers, then they are your brethren in the faith and your kinsmen. Excepting what your hearts may intend deliberately, there will be no sin upon you for any mistake that you may make therein. And Allah is all-forgiving, all-merciful.

# 3539

The Prophet is closer to the faithful than their own souls, and his wives are their mothers. The blood relatives are more entitled to inherit from one another in the Book of Allah than the \[other\] faithful and Emigrants, barring any favour you may do your comrades. This has been written in the Book.

# 3540

\[Recall\] when We took a pledge from the prophets, and from you and from Noah and Abraham and Moses and Jesus son of Mary, and We took from them a solemn pledge,

# 3541

so that He may question the truthful concerning their truthfulness. And He has prepared for the faithless a painful punishment.

# 3542

O you who have faith! Remember Allah’s blessing upon you when the hosts came at you, and We sent against them a gale and hosts whom you did not see, and Allah sees best what you do.

# 3543

When they came at you from above and below you, and when the eyes rolled \[with fear\] and the hearts leapt to the throats, and you entertained misgivings about Allah,

# 3544

it was there that the faithful were tested and jolted with a severe agitation.

# 3545

When the hypocrites, as well as those in whose hearts is a sickness, were saying, ‘Allah and His Apostle did not promise us \[anything\] except delusion.’

# 3546

And when a group of them said, ‘O people of Yathrib! \[This is\] not a place for you, so go back!’ A group of them sought the Prophet’s permission \[to leave the scene of battle\], saying, ‘Our homes lie exposed \[to the enemy\],’ although they were not exposed. They only sought to flee.

# 3547

Had they been invaded from its flanks and had they been asked to apostatize, they would have done so with only a mild hesitation,

# 3548

though they had already pledged to Allah before that they would not turn their backs \[to flee\], and pledges given to Allah are accountable.

# 3549

Say, ‘Flight will not avail you, if you flee from death, or from being killed, and then you will be let to enjoy only for a little while.’

# 3550

Say, ‘Who is it that can protect you from Allah if He desires to cause you harm or desires to grant you His mercy?’ Besides Allah they will not find for themselves any protector or helper.

# 3551

Allah knows those of you who discourage others, and those who say to their brethren, ‘Come to us!’ and take little part in the battle,

# 3552

grudging you \[their help\]. So when there is panic, you see them looking at you, with their eyes rolling like someone fainting at death. Then, when the panic is over, they scald you with \[their\] sharp tongues in their greed for the spoils. They never have had faith. So Allah has made their works fail, and that is easy for Allah.

# 3553

They suppose the confederates have not left yet, and were the confederates to come \[again\], they would wish they were in the desert with the Bedouins asking about your news, and if they were with you they would fight but a little.

# 3554

There is certainly a good exemplar for you in the Apostle of Allah—for those who look forward to Allah and the Last Day, and remember Allah much.

# 3555

But when the faithful saw the confederates, they said, ‘This is what Allah and His Apostle had promised us, and Allah and His Apostle were true.’ And it only increased them in faith and submission.

# 3556

Among the faithful are men who fulfill what they have pledged to Allah: there are some among them who have fulfilled their pledge, and some of them who still wait, and they have not changed in the least,

# 3557

that Allah may reward the true for their truthfulness, and punish the hypocrites, if He wishes, or accept their repentance. Indeed Allah is all-forgiving, all-merciful.

# 3558

Allah sent back the faithless in their rage, without their attaining any advantage, and Allah spared the faithful of fighting, and Allah is all-strong, all-mighty.

# 3559

And He dragged down from their strongholds those who had backed them from among the People of the Book, and He cast terror into their hearts, \[so that\] you killed a part of them, and took captive \[another\] part.

# 3560

He bequeathed you their land, their houses and their possessions, and a territory you had not trodden, and Allah has power over all things.

# 3561

O Prophet! Say to your wives, ‘If you desire the life of the world and its glitter, come, I will provide for you and release you in a graceful manner.

# 3562

But if you desire Allah and His Apostle and the abode of the Hereafter, then Allah has indeed prepared a great reward for the virtuous among you.’

# 3563

O wives of the Prophet! Whoever of you commits a gross indecency, her punishment shall be doubled, and that is easy for Allah.

# 3564

But whoever of you is obedient to Allah and His Apostle and acts righteously, We shall give her a twofold reward, and We will have in store for her a noble provision.

# 3565

O wives of the Prophet! You are not like other women: if you are wary \[of Allah\], do not be complaisant in your speech, lest he in whose heart is a sickness should aspire; speak honourable words.

# 3566

Stay in your houses and do not flaunt your finery like the former \[days of pagan\] ignorance. Maintain the prayer and pay the zakat, and obey Allah and His Apostle. Indeed Allah desires to repel all impurity from you, O People of the Household, and purify you with a thorough purification.

# 3567

And remember what is recited in your homes of the signs of Allah and wisdom. Indeed Allah is all-attentive, all-aware.

# 3568

Indeed the muslim men and the muslim women, the faithful men and the faithful women, the obedient men and the obedient women, the truthful men and the truthful women, the patient men and the patient women, the humble men and the humble women, the charitable men and the charitable women, the men who fast and the women who fast, the men who guard their private parts and the women who guard, the men who remember Allah greatly and the women who remember \[Allah greatly\]—Allah holds in store for them forgiveness and a great reward.

# 3569

A faithful man or woman may not have any option in their matter, when Allah and His Apostle have decided on a matter, and whoever disobeys Allah and His Apostle has certainly strayed into manifest error.

# 3570

When you said to him whom Allah had blessed, and whom you \[too\] had blessed, ‘Retain your wife for yourself, and be wary of Allah,’ and you had hidden in your heart what Allah was to divulge, and you feared the people though Allah is worthier that you should fear Him, so when Zayd had got through with her, We wedded her to you, so that there may be no blame on the faithful in respect of the wives of their adopted sons, when the latter have got through with them, and Allah’s command is bound to be fulfilled.

# 3571

There is no blame on the Prophet in respect of that which Allah has made lawful for him: Allah’s precedent with those who passed away earlier (and Allah’s commands are ordained by a precise ordaining),

# 3572

such as deliver the messages of Allah and fear Him, and fear no one except Allah, and Allah suffices as reckoner.

# 3573

Muhammad is not the father of any man among you, but he is the Apostle of Allah and the Seal of the Prophets, and Allah has knowledge of all things.

# 3574

O you who have faith! Remember Allah with frequent remembrance,

# 3575

and glorify Him morning and evening.

# 3576

It is He who blesses you—and so do His angels—that He may bring you out from darkness into light, and He is most merciful to the faithful.

# 3577

The day they encounter Him, their greeting will be, ‘Peace,’ and He holds in store for them a noble reward.

# 3578

O Prophet! Indeed We have sent you as a witness, as a bearer of good news and as a warner

# 3579

and as a summoner to Allah by His permission, and as a radiant lamp.

# 3580

Announce to the faithful the good news that there will be for them a great grace from Allah.

# 3581

Do not obey the faithless and the hypocrites, and disregard their torments, and put your trust in Allah, and Allah suffices as trustee.

# 3582

O you who have faith! When you marry faithful women and then divorce them before you touch them, there shall be no period for you to reckon. But provide for them and release them in a graceful manner.

# 3583

O Prophet! Indeed We have made lawful to you your wives whom you have given their dowries, and those whom your right hand owns, of those whom Allah gave you as spoils of war, and the daughters of your paternal uncle, and the daughters of your paternal aunts, and the daughters of your maternal uncle, and the daughters of your maternal aunts who migrated with you, and a faithful woman if she offers herself to the Prophet and the Prophet desires to take her in marriage (a privilege exclusively for you, not for \[the rest of\] the faithful; We know what We have made lawful for them with respect to their wives and those whom their right hands own, so that there may be no blame on you ), and Allah is all-forgiving, all-merciful.

# 3584

You may put off whichever of them you wish and consort with whichever of them you wish, and there is no sin upon you \[in receiving again\] any \[of them\] whom you may seek \[to consort with\] from among those you have set aside \[earlier\]. That makes it likelier that they will be comforted and not feel unhappy, and all of them will be pleased with what you give them. Allah knows what is in your hearts, and Allah is all-knowing, all-forbearing.

# 3585

Beyond that, women are not lawful for you, nor that you should change them for other wives even though their beauty should impress you, except those whom your right hand owns. Allah is watchful over all things.

# 3586

O you who have faith! Do not enter the Prophet’s houses for a meal until you are granted permission, without hanging around for it to be readied. But enter when you are invited, and disperse when you have taken your meal, without cozying up for chats. Such conduct on your part offends the Prophet, and he is ashamed of \[asking\] you \[to leave\]; but Allah is not ashamed of \[expressing\] the truth. When you ask \[his\] womenfolk for something, do so from behind a curtain. That is more chaste for your hearts and theirs. You should not offend the Apostle of Allah, nor may you ever marry his wives after him. Indeed that would be a grave \[sin\] with Allah.

# 3587

Whether you disclose anything or hide it, Allah indeed knows all things.

# 3588

There is no sin on them \[in socializing freely\] with their fathers, or their sons, or their brothers, or their brothers’ sons, or the sons of their sisters, or their own womenfolk, or what their right hands own. Be wary of Allah. Indeed Allah is witness to all things.

# 3589

Indeed Allah and His angels bless the Prophet; O you who have faith! Invoke blessings on him and invoke Peace upon him in a worthy manner.

# 3590

Indeed those who offend Allah and His Apostle are cursed by Allah in the world and the Hereafter, and He has prepared a humiliating punishment for them.

# 3591

Those who offend faithful men and women undeservedly, certainly bear the guilt of slander and flagrant sin.

# 3592

O Prophet! Tell your wives and your daughters and the women of the faithful to draw closely over themselves their chadors \[when going out\]. That makes it likely for them to be recognized and not be troubled, and Allah is all-forgiving, all-merciful.

# 3593

If the hypocrites and those in whose hearts is a sickness, and the rumourmongers in the city do not desist, We will prompt you \[to take action\] against them; then they will not be your neighbours in it except briefly.

# 3594

Accursed, they will be seized wherever they are confronted and slain violently:

# 3595

Allah’s precedent with those who passed away before, and you will never find any change in Allah’s precedent.

# 3596

The people question you concerning the Hour. Say, ‘Its knowledge is only with Allah.’ What do you know, maybe the Hour is near.

# 3597

Indeed Allah has cursed the faithless and prepared for them a blaze,

# 3598

in which they will remain forever, and will not find any guardian or helper.

# 3599

The day when their faces are turned about in the Fire, they will say, ‘We wish we had obeyed Allah and obeyed the Apostle!’

# 3600

They will say, ‘Our Lord! We obeyed our leaders and elders, and they led us astray from the way.’

# 3601

Our Lord! Give them a double punishment and curse them with a mighty curse.’

# 3602

O you who have faith! Do not be like those who offended Moses, whereat Allah cleared him of what they alleged, and he was distinguished in Allah’s sight.

# 3603

O you who have faith! Be wary of Allah, and speak upright words.

# 3604

He will rectify your conduct for you and forgive you your sins. Whoever obeys Allah and His Apostle will certainly achieve a great success.

# 3605

Indeed We presented the Trust to the heavens and the earth and the mountains, but they refused to undertake it and were apprehensive of it; but man undertook it. Indeed he is most unjust and ignorant.

# 3606

Allah will surely punish the hypocrites, men and women, and the polytheists, men and women, and Allah will turn clemently to the faithful, men and women, and Allah is all-forgiving, all-merciful.

# 3607

All praise belongs to Allah to whom belongs whatever is in the heavens and whatever is in the earth. To Him belongs all praise in the Hereafter, and He is the All-wise, the All-aware.

# 3608

He knows whatever enters into the earth and whatever emerges from it, and whatever descends from the sky and whatever ascends into it, and He is the All-merciful, the All-forgiving.

# 3609

The faithless say, ‘The Hour will not overtake us.’ Say, ‘Yes, indeed it will surely overtake you, by my Lord,’ the Knower of the Unseen; not \[even\] an atom’s weight escapes Him in the heavens or in the earth, nor \[is there\] anything smaller than that nor bigger, but it is in a manifest Book,

# 3610

that He may reward those who have faith and do righteous deeds.’ For such there will be forgiveness and a noble provision.

# 3611

But those who contend with Our signs seeking to frustrate \[their purpose\], for such is a painful punishment due to defilement.

# 3612

Those who have been given knowledge see that what has been sent down to you from your Lord is the truth and \[that\] it guides to the path of the All-mighty, the All-laudable.

# 3613

The faithless say, ‘Shall we show you a man who will inform you \[that\] when you have been totally rent to pieces you will indeed have a new creation?

# 3614

Has he fabricated a lie against Allah, or is there a madness in him?’ Indeed, those who do not believe in the Hereafter languish in punishment and extreme error.

# 3615

Have they not regarded that which is before them and that which is behind them of the sky and the earth? If We like, We can make the earth swallow them, or let a fragment from the sky fall on them. There is indeed a sign in that for every penitent servant.

# 3616

Certainly We gave David our grace: ‘O mountains and birds, chime in with him!’ And We made iron soft for him,

# 3617

saying, ‘Make easy coats of mail, and keep the measure in arranging \[the links\], and act righteously. Indeed I watch what you do.’

# 3618

And for Solomon \[We subjected\] the wind: its morning course was a month’s journey and its evening course was a month’s journey. We made a fount of \[molten\] copper flow for him, and \[We placed at his service\] some of the jinn who would work for him by the permission of his Lord, and if any of them swerved from Our command, We would make him taste the punishment of the Blaze.

# 3619

They built for him as many temples as he wished, and figures, basins like cisterns, and caldrons fixed \[in the ground\]. ‘O House of David, act thankfully, and few of My servants are grateful.’

# 3620

When We decreed death for him, nothing apprised them of his death except a worm which gnawed away at his staff. And when he fell down, \[the humans\] realized that had the jinn known the Unseen, they would not have remained in a humiliating torment.

# 3621

There was certainly a sign for Sheba in their habitation: two gardens, to the right and to the left. ‘Eat of the provision of your Lord and give Him thanks: a good land and an all-forgiving Lord!’

# 3622

But they disregarded \[the path of Allah\], so We unleashed upon them a violent flood and replaced their two gardens with two gardens bearing bitter fruit, tamarisk, and sparse lote trees.

# 3623

We requited them with that for their ingratitude. Do We not requite ingrates?

# 3624

We had placed between them and the towns which We had blessed hamlets prominent \[from the main route\], and We had ordained the course through them: ‘Travel through them in safety, night and day.’

# 3625

But they said, ‘Our Lord! Make the stages between our journeys far apart,’ and they wronged themselves. So We turned them into folktales and caused them to disintegrate totally. There are indeed signs in that for every patient and grateful \[servant\].

# 3626

Certainly Iblis had his conjecture come true about them. So they followed him—all except a part of the faithful.

# 3627

He had no authority over them, but that We may ascertain those who believe in the Hereafter from those who are in doubt about it, and your Lord is watchful over all things.

# 3628

Say, ‘Invoke those whom you claim \[to be gods\] besides Allah! They do not control \[even\] an atom’s weight in the heavens or the earth, nor do they have any share in \[either of\] them, nor is any of them His helper.’

# 3629

Intercession is of no avail with Him, except for those whom He permits. When fear is lifted from their hearts, they say, ‘What did your Lord say?’ They say, ‘The truth, and He is the All-exalted, the All-great.’

# 3630

Say, ‘Who provides for you from the heavens and the earth?’ Say, ‘Allah! Indeed either we or you are rightly guided or in manifest error.’

# 3631

Say, ‘You will not be questioned about our guilt, nor shall we be questioned about what you do.’

# 3632

Say, ‘Our Lord will bring us together, then He will judge between us with justice, and He is the All-knowing Judge.’

# 3633

Say, ‘Show me those whom you associate with Him as partners.’ No! \[They can never show any such partner\]. Indeed, He is Allah, the All-mighty, the All-wise.

# 3634

We did not send you except as a bearer of good news and warner to all mankind, but most people do not know.

# 3635

They say, ‘When will this promise be fulfilled, if you are truthful?’

# 3636

Say, ‘Your promised hour is a day that you shall neither defer nor advance by an hour.’

# 3637

The faithless say, ‘We will never believe in this Quran, nor in what was \[revealed\] before it.’ But if you were to see when the wrongdoers will be made to stop before their Lord casting the blame on one another. Those who were abased will say to those who were arrogant, ‘Had it not been for you, we would surely have been faithful.’

# 3638

Those who were arrogant will say to those who were abased, ‘Did we keep you from guidance after it had come to you? No, you were guilty \[yourselves\].’

# 3639

Those who were abased will say to those who were arrogant, ‘No, \[it was your\] night and day plotting, when you prompted us to forswear Allah and to set up equals to Him.’ They will hide their remorse when they sight the punishment, and We will put iron collars around the necks of the faithless. Shall they not be requited for what they used to do?

# 3640

We did not send a warner to any town without its affluent ones saying, ‘We indeed disbelieve in what you have been sent with.’

# 3641

They say, ‘We have greater wealth and more children, and we will not be punished!’

# 3642

Say, ‘Indeed my Lord expands the provision for whomever He wishes and He tightens it, but most people do not know.’

# 3643

It is not your wealth, nor your children, that will bring you close to Us in nearness, excepting those who have faith and act righteously. It is they for whom there will be a twofold reward for what they did, and they will be secure in lofty abodes.

# 3644

As for those who contend with Our signs seeking to frustrate \[their purpose\], they will be brought to the punishment.

# 3645

Say, ‘Indeed my Lord expands the provision for whomever of His servants that He wishes and tightens it, and He will repay whatever you may spend, and He is the best of providers.’

# 3646

On the day He will muster them all together, He will say to the angels, ‘Was it you that these used to worship?’

# 3647

They will say, ‘Immaculate are You! You are our wali, not they! No, they used to worship the jinn; most of them had faith in them.’

# 3648

‘Today you have no power to benefit or harm one another,’ and We shall say to those who did wrong, ‘Taste the punishment of the Fire which you used to deny.’

# 3649

When Our manifest signs are recited to them, they say, ‘This is just a man who desires to keep you from what your fathers used to worship.’ And they say, ‘This is nothing but a fabricated lie.’ The faithless say of the truth when it comes to them: ‘This is nothing but plain magic,’

# 3650

though We did not give them any scriptures that they might have studied, nor did We send them any warner before you.

# 3651

Those who were before them had also denied—and these have not attained one-tenth of what We had given them—they impugned My apostles, so how was My rebuttal!

# 3652

Say, ‘I give you just a single advice: that you rise up for Allah’s sake, in pairs or singly, and then reflect: there is no madness in your companion; he is just a warner to you before \[the befalling of\] a severe punishment.’

# 3653

Say, ‘Whatever reward I may have asked you is for your own good. My \[true\] reward lies only with Allah, and He is witness to all things.’

# 3654

Say, ‘Indeed my Lord hurls the truth. \[He is\] the knower of all that is Unseen.’

# 3655

Say, ‘The truth has come, and falsehood neither originates nor restores \[anything\].’

# 3656

Say, ‘If I go astray, my going astray is only to my own harm, and if I am rightly guided that is because of what my Lord has revealed to me. Indeed He is all-hearing and nearmost.’

# 3657

Were you to see them when they will be stricken with terror, without any escape, and are seized from a close quarter.

# 3658

They will say, ‘We believe in it \[now\]!’ But how can they attain it from a far-off place,

# 3659

when they denied it in the past—shooting at something invisible from a far-off place—

# 3660

and a barrier is set between them and what they desire, as was done aforetime with their likes, who had remained in grave doubt?

# 3661

All praise belongs to Allah, originator of the heavens and the earth, maker of the angels \[His\] messengers, possessing wings, two, three or four \[of them\]. He adds to the creation whatever He wishes. Indeed Allah has power over all things.

# 3662

Whatever mercy Allah unfolds for the people, no one can withhold it; and whatever He withholds no one can release it except Him, and He is the All-mighty, the All-wise.

# 3663

O mankind! Remember Allah’s blessing upon you! Is there any creator other than Allah who provides for you from the sky and the earth? There is no god except Him. So where do you stray?

# 3664

If they impugn you, certainly \[other\] apostles were impugned before you, and all matters are returned to Allah.

# 3665

O mankind! Allah’s promise is indeed true. So do not let the life of the world deceive you, nor let the Deceiver deceive you concerning Allah.

# 3666

Satan is indeed your enemy, so treat him as an enemy. He only invites his confederates so that they may be among the inmates of the Blaze.

# 3667

There is a severe punishment for the faithless; but for those who have faith and do righteous deeds, there will be forgiveness and a great reward.

# 3668

Is someone the evil of whose conduct is presented as decorous to him, so he regards it as good.... Indeed Allah leads astray whomever He wishes, and guides whomever He wishes. So do not fret yourself to death regretting for them. Indeed Allah knows best what they do.

# 3669

It is Allah who sends the winds and they raise a cloud; then We drive it toward a dead land and with it revive the earth after its death. Likewise will be the resurrection \[of the dead\].

# 3670

Whoever seeks honour \[should know that\] honour entirely belongs to Allah. To Him ascends the good word, and He elevates righteous conduct; as for those who devise evil schemes, there is a severe punishment for them, and their plotting shall come to naught.

# 3671

Allah created you from dust, then from a drop of \[seminal\] fluid, then He made you mates. No female conceives or delivers except with His knowledge, and no elderly person advances in years, nor is anything diminished of his life, but it is \[recorded\] in a Book. That is indeed easy for Allah.

# 3672

Not alike are the two seas: this one sweet and agreeable, pleasant to drink, and that one briny and bitter, and from each you eat fresh meat and obtain ornaments, which you wear. And you see the ships plowing through them, that you may seek of His bounty, and so that you may give thanks.

# 3673

He makes the night pass into the day and makes the day pass into the night, and He has disposed the sun and the moon, each moving for a specified term. That is Allah, your Lord; to Him belongs all sovereignty. As for those whom you invoke besides Him, they do not control so much as the husk of a date stone.

# 3674

If you invoke them they will not hear your invocation, and even if they heard they cannot respond to you, and on the Day of Resurrection they will forswear your polytheism, and none can inform you like the One who is all-aware.

# 3675

O mankind! You are the ones who stand in need of Allah, and Allah—He is the All-sufficient, the All-laudable.

# 3676

If He wishes, He will take you away, and bring about a new creation;

# 3677

and that is not a hard thing for Allah.

# 3678

No bearer shall bear another’s burden, and should someone heavily burdened call \[another\] to carry it, nothing of it will be carried \[by anyone\] even if he should be a near relative. You can only warn those who fear their Lord in secret and maintain the prayer. Whoever purifies himself, purifies only for his own sake, and to Allah is the return.

# 3679

The blind one and the seer are not equal,

# 3680

nor darkness and light;

# 3681

nor shade and torrid heat;

# 3682

nor are the living equal to the dead. Indeed Allah makes whomever He wishes to hear, and you cannot make those who are in the graves hear you.

# 3683

You are but a warner.

# 3684

Indeed We have sent you with the truth as a bearer of good news and as a warner; and there is not a nation but a warner has passed in it.

# 3685

If they impugn you, those before them have impugned \[likewise\]: their apostles brought them manifest proofs, \[holy\] writs, and illuminating scriptures.

# 3686

Then I seized the faithless. So how was My rebuttal!

# 3687

Have you not regarded that Allah sends down water from the sky, with which We produce fruits of diverse hues. And in the mountains are stripes, white and red, of diverse hues, and \[others\] pitch black?

# 3688

And of humans and beasts and cattle there are likewise diverse hues. Only those of Allah’s servants having knowledge fear Him. Indeed Allah is all-mighty, all-forgiving.

# 3689

Indeed those who recite the Book of Allah and maintain the prayer, and spend secretly and openly out of what We have provided them, expect a commerce that will never go bankrupt,

# 3690

so that He may pay them their full reward and enhance them out of His bounty. Indeed He is all-forgiving, all-appreciative.

# 3691

That which We have revealed to you of the Book is the truth, confirming what was \[revealed\] before it. Indeed Allah is all-aware, all-seeing about His servants.

# 3692

Then We made those whom We chose from Our servants heirs to the Book. Yet some of them are those who wrong themselves, and some of them are average, and some of them are those who take the lead in all the good works by Allah’s will. That is the greatest grace \[of Allah\]!

# 3693

Gardens of Eden, which they will enter, adorned therein with bracelets of gold and pearl, and their garments therein will be of silk.

# 3694

They will say, ‘All praise belongs to Allah, who has removed all grief from us. Indeed Our Lord is all-forgiving, all-appreciative,

# 3695

who has settled us in the everlasting abode by His grace. In it we are untouched by toil, and untouched by fatigue.’

# 3696

As for the faithless, there is for them the fire of hell: they will neither be done away with so that they may die, nor shall its punishment be lightened for them. Thus do We requite every ingrate.

# 3697

They shall cry therein for help: ‘Our Lord! Bring us out, so that we may act righteously—differently from what we used to do!’ ‘Did We not give you a lifelong enough that one who is heedful might take admonition? And \[moreover\] the warner had \[also\] come to you. Now taste \[the consequence of your deeds\], for the wrongdoers have no helper.’

# 3698

Indeed Allah is the knower of the Unseen of the heavens and the earth. Indeed, He knows well what is in the breasts.

# 3699

It is He who made you successors on the earth. So whoever is faithless, his unfaith is to his own detriment. The unfaith of the faithless does not increase them with their Lord \[in anything\] except disfavour, and their unfaith increases the faithless in nothing except loss.

# 3700

Say, ‘Tell me about your ‘partners’ whom you invoke besides Allah? Show me what \[part\] of the earth have they created. Have they any share in the heavens?’ Have We given them a scripture so that they stand on a manifest proof from it? No, the wrongdoers do not promise one another \[anything\] except delusion.

# 3701

Indeed Allah sustains the heavens and the earth lest they should fall apart, and if they were to fall apart, there is none who can sustain them except Him. Indeed He is all-forbearing, all-forgiving.

# 3702

They had sworn by Allah with solemn oaths that if a warner were to come to them, they would be better guided than any of the nations. But when a warner came to them, it only increased their distance \[from the truth\],

# 3703

due to their domineering \[conduct\] in the land and their devising of evil schemes; and evil schemes beset only their authors. So do they await anything except the precedent of the ancients? Yet you will never find any change in Allah’s precedent, and you will never find any revision in Allah’s precedent.

# 3704

Have they not travelled over the land so that they may observe how was the fate of those who were before them? They were more powerful than them, and Allah is not to be frustrated by anything in the heavens or on the earth. Indeed, He is all-knowing, all-powerful.

# 3705

Were Allah to take humans to task because of what they have earned, He would not leave any living being on its back. But He respites them until a specified time, and when their time comes, \[He retributes them in accordance with their works\], for Allah has been watching His servants.

# 3706

Ya Seen!

# 3707

By the Wise Quran,

# 3708

you are indeed one of the apostles,

# 3709

on a straight path.

# 3710

\[It is a scripture\] sent down gradually from the All-mighty, the All-merciful

# 3711

that you may warn a people whose fathers were not warned, so they are oblivious.

# 3712

The word has certainly become due against most of them, so they will not have faith.

# 3713

Indeed We have put iron collars around their necks, which are up to the chins, so their heads are upturned.

# 3714

And We have put a barrier before them and a barrier behind them, then We have blind-folded them, so they do not see.

# 3715

It is the same to them whether you warn them or do not warn them, they will not have faith.

# 3716

You can only warn someone who follows the Reminder and fears the All-beneficent in secret; so give him the good news of forgiveness and a noble reward.

# 3717

Indeed it is We who revive the dead and write what they have sent ahead and their effects \[which they left behind\], and We have figured everything in a manifest Imam.

# 3718

Cite for them the example of the inhabitants of the town when the apostles came to it.

# 3719

When We sent to them two \[apostles\], they impugned both of them. Then We reinforced them with a third, and they said, ‘We have indeed been sent to you.’

# 3720

They said, ‘You are no other than human beings like us, and the All-beneficent has not sent down anything, and you are only lying.’

# 3721

They said, ‘Our Lord knows that we have indeed been sent to you,

# 3722

and our duty is only to communicate in clear terms.’

# 3723

They said, ‘Indeed we take you for a bad omen. If you do not desist we will stone you, and surely a painful punishment will visit you from us.’

# 3724

They said, ‘Your bad omens attend you. What! If you are admonished.... Indeed, you are an unrestrained lot.’

# 3725

There came a man hurrying from the city outskirts. He said, ‘O my people! Follow the apostles!

# 3726

Follow them who do not ask you any reward and they are rightly guided.

# 3727

Why should I not worship Him who has originated me, and to whom you shall be brought back?

# 3728

Shall I take gods besides Him? If the All-beneficent desired to cause me any distress, their intercession will not avail me in any way, nor will they rescue me.

# 3729

Indeed, then I would be in manifest error.

# 3730

Indeed I have faith in your Lord, so listen to me.’

# 3731

He was told, ‘Enter paradise!’ He said, ‘Alas! Had my people only known

# 3732

for what my Lord forgave me and made me one of the honoured ones!’

# 3733

After him We did not send down on his people a host from the sky, nor We would have sent down.

# 3734

It was but a single Cry, and, behold, they were stilled \[like burnt ashes\]!

# 3735

How regrettable of the servants! There did not come to them any apostle but that they used to deride him.

# 3736

Have they not regarded how many generations We have destroyed before them who will not come back to them?

# 3737

And all of them will indeed be presented before Us.

# 3738

A sign for them is the dead earth, which We revive and bring forth grain out of it, so they eat of it.

# 3739

We make in it orchards of date palms and vines, and We cause springs to gush forth in it,

# 3740

so that they may eat of its fruit and what their hands have cultivated. Will they not then give thanks?

# 3741

Immaculate is He who has created all the kinds of what the earth grows, and of themselves, and of what they do not know.

# 3742

A sign for them is the night, which We strip of daylight, and, behold, they find themselves in the dark!

# 3743

The sun runs on to its place of rest: That is the ordaining of the All-mighty, the All-knowing.

# 3744

As for the moon, We have ordained its phases, until it becomes like an old palm leaf.

# 3745

Neither it behooves the sun to overtake the moon, nor may the night outrun the day, and each swims in an orbit.

# 3746

A sign for them is that We carried their progeny in the laden ship,

# 3747

and We have created for them what is similar to it, which they ride.

# 3748

And if We like We drown them, whereat they have no one to call for help, nor are they rescued

# 3749

except by a mercy from Us and for an enjoyment until some time.

# 3750

And when they are told, ‘Beware of that which is before you and that which is behind you, so that you may receive \[His\] mercy...’

# 3751

There does not come to them any sign from among the signs of their Lord but that they have been disregarding it.

# 3752

When they are told, ‘Spend out of what Allah has provided you,’ the faithless say to the faithful, ‘Shall we feed \[someone\] whom Allah would feed, if He wished? You are only in manifest error.’

# 3753

And they say, ‘When will this promise be fulfilled, should you be truthful?’

# 3754

They do not await but a single Cry that will seize them as they wrangle.

# 3755

Then they will not be able to make any will, nor will they return to their folks.

# 3756

And when the Trumpet is blown, behold, there they will be, scrambling towards their Lord from their graves!

# 3757

They will say, ‘Woe to us! Who raised us from our place of sleep?’ ‘This is what the All-beneficent had promised, and the apostles had spoken the truth!’

# 3758

It will be but a single Cry, and, behold, they will all be presented before Us!

# 3759

‘Today no soul will be wronged in the least, nor will you be requited except for what you used to do.’

# 3760

Indeed today the inhabitants of paradise rejoice in their engagements

# 3761

—they and their mates, reclining on couches in the shades.

# 3762

There they have fruits, and they have whatever they want.

# 3763

‘Peace!’—a watchword from the all-merciful Lord.

# 3764

And ‘Get apart today, you guilty ones!’

# 3765

‘Did I not exhort you, O children of Adam, saying, “Do not worship Satan. He is indeed your manifest enemy.

# 3766

Worship Me. That is a straight path”?

# 3767

Certainly, he has led astray many of your generations. Have you not exercised your reason?

# 3768

This is the hell you had been promised!

# 3769

Enter it today, because of what you used to deny.

# 3770

Today We shall seal their mouths, and their hands shall speak to Us, and their feet shall bear witness concerning what they used to earn.’

# 3771

Had We wished We would have blotted out their eyes: then, were they to advance towards the path, how would have they seen?

# 3772

And had We wished We would have deformed them in their place; then they would neither have been able to move ahead nor to return.

# 3773

And whomever We give a long life, We cause him to regress in creation. Then, will they not exercise their reason?

# 3774

We did not teach him poetry, nor does it behoove him. This is just a reminder and a manifest Quran,

# 3775

so that anyone who is alive may be warned, and that the word may come due against the faithless.

# 3776

Have they not seen that We have created for them—of what Our hands have worked—cattle, so they have become their masters?

# 3777

And We made them tractable for them; so some of them make their mounts and some of them they eat.

# 3778

There are other benefits for them therein, and drinks. Will they not then give thanks?

# 3779

They have taken gods besides Allah, \[hoping\] that they might be helped \[by the fake deities\].

# 3780

\[But\] they cannot help them, while they \[themselves\] are an army mobilized for their defence.

# 3781

So do not let their remarks grieve you. We indeed know whatever they hide and whatever they disclose.

# 3782

Does not man see that We created him from a drop of \[seminal\] fluid, and, behold, he is an open contender!?

# 3783

He draws comparisons for Us, and forgets his own creation. He says, ‘Who shall revive the bones when they have decayed?’

# 3784

Say, ‘He will revive them who produced them the first time, and He has knowledge of all creation.

# 3785

He, who made for you fire out of the green tree, and, behold, you light fire from it!

# 3786

Is not He who created the heavens and the earth able to create the like of them? Yes indeed! He is the All-creator, the All-knowing.

# 3787

All His command, when He wills something, is to say to it ‘Be,’ and it is.

# 3788

So immaculate is He in whose hand is the dominion of all things, and to whom you shall be brought back.

# 3789

By the \[angels\] ranged in ranks,

# 3790

by the ones who drive \[the clouds\] vigorously,

# 3791

by the ones who recite the reminder:

# 3792

indeed your God is certainly One,

# 3793

the Lord of the heavens and the earth and whatever is between them, and the Lord of the easts.

# 3794

Indeed We have adorned the lowest heaven with the finery of the stars,

# 3795

and to guard from any froward devil.

# 3796

They do not eavesdrop on the Supernal Elite—they are shot at from every side,

# 3797

to drive them away, and there is a perpetual punishment for them—

# 3798

except any who snatches a snatch, whereat a piercing flame pursues him.

# 3799

Ask them, is their creation more prodigious or \[that of other creatures\] that We have created? Indeed, We created them from a viscous clay.

# 3800

Indeed you wonder, while they engage in ridicule,

# 3801

and \[even\] when admonished do not take admonition,

# 3802

and when they see a sign they make it an object of ridicule,

# 3803

and say, ‘This is nothing but plain magic!’

# 3804

‘What! When we are dead and have become dust and bones, shall we be resurrected?

# 3805

And our forefathers too?!’

# 3806

Say, ‘Yes! And you will be utterly humble.’

# 3807

It will be only a single shout and, behold, they will look on,

# 3808

and say, ‘Woe to us! This is the Day of Retribution!’

# 3809

‘This is the Day of Judgement that you used to deny!’

# 3810

‘Muster the wrongdoers and their mates and what they used to worship

# 3811

besides Allah, and show them the way to hell!

# 3812

\[But first\] stop them! For they must be questioned.’

# 3813

‘Why is it that you do not support one another \[today\]?’

# 3814

‘Indeed, they are \[meek and\] submissive today!’

# 3815

Some of them will turn to others, questioning each other.

# 3816

They will say, ‘Indeed you used to accost us peremptorily.’

# 3817

They will answer, ‘No, you \[yourselves\] had no faith.

# 3818

We had no authority over you. No, you \[yourselves\] were a rebellious lot.

# 3819

So our Lord’s word became due against us that we shall indeed taste \[the punishment\].

# 3820

So we perverted you, for we were perverse \[ourselves\].’

# 3821

So, that day they will share the punishment.

# 3822

Indeed, that is how We deal with the guilty.

# 3823

Indeed, it was they who, when they were told, ‘There is no god except Allah,’ used to be disdainful,

# 3824

and \[they would\] say, ‘Shall we abandon our gods for a crazy poet?’

# 3825

Indeed, he has brought \[them\] the truth, and confirmed the \[earlier\] apostles.

# 3826

Indeed you will taste the painful punishment,

# 3827

and you will be requited only for what you used to do

# 3828

—\[all\] except Allah’s exclusive servants.

# 3829

For such there is a known provision

# 3830

—fruits—and they will be held in honour,

# 3831

in the gardens of bliss,

# 3832

\[reclining\] on couches, facing one another,

# 3833

served around with a cup, from a clear fountain,

# 3834

snow-white, delicious to the drinkers,

# 3835

wherein there will be neither headache nor will it cause them stupefaction,

# 3836

and with them will be maidens, of restrained glances with big \[beautiful\] eyes,

# 3837

as if they were hidden ostrich eggs.

# 3838

Some of them will turn to others, questioning each other.

# 3839

One of them will say, ‘Indeed I had a companion

# 3840

who used to say, ‘‘Are you really among those who affirm

# 3841

that when we have died and become dust and bones, we shall be brought to retribution?’’ ’

# 3842

He will say, ‘Will you have a look?’

# 3843

Then he will take a look and sight him in the middle of hell.

# 3844

He will say, ‘By Allah, you had almost ruined me!

# 3845

Had it not been for my Lord’s blessing, I too would have been among those mustered \[in hell\]!’

# 3846

‘Is it \[true\] that we shall not die \[anymore\],

# 3847

aside from our earlier death, and that we shall not be punished?

# 3848

This is indeed the supreme triumph!’

# 3849

Let all workers work for the like of this!

# 3850

Is this a better reception, or the Zaqqum tree?

# 3851

Indeed We have made it a punishment for the wrongdoers.

# 3852

It is a tree that rises from the depths of hell.

# 3853

Its spathes are as if they were devils’ heads.

# 3854

They will eat from it and gorge with it their bellies.

# 3855

On top of that they will take a solution of scalding water.

# 3856

Then their retreat will be toward hell.

# 3857

They had found their fathers astray,

# 3858

yet they press onwards in their footsteps.

# 3859

Most of the former peoples went astray before them,

# 3860

and We had certainly sent warners among them.

# 3861

So observe how was the fate of those who were warned

# 3862

—\[all\] except Allah’s exclusive servants!

# 3863

Certainly Noah called out to Us, and how well did We respond!

# 3864

We delivered him and his family from their great distress,

# 3865

and made his descendants the survivors,

# 3866

and left for him a good name among posterity:

# 3867

‘Peace to Noah, throughout the nations!’

# 3868

Thus do We reward the virtuous.

# 3869

He is indeed one of Our faithful servants.

# 3870

Then We drowned the rest.

# 3871

Indeed Abraham was among his followers,

# 3872

when he came to his Lord with a sound heart \[untainted by sin\].

# 3873

When he said to his father and his people, ‘What is it that you are worshiping?

# 3874

Is it a lie, gods other than Allah, that you desire?

# 3875

Then what is your idea about the Lord of all the worlds?’

# 3876

Then he made an observation of the stars

# 3877

and said, ‘Indeed I am sick!’

# 3878

So they went away leaving him behind.

# 3879

Then he stole away to their gods and said, ‘Will you not eat?

# 3880

Why do you not speak?’

# 3881

Then he attacked them, striking forcefully.

# 3882

They came running towards him.

# 3883

He said, ‘Do you worship what you have yourselves carved,

# 3884

when Allah has created you and whatever you make?’

# 3885

They said, ‘Build a structure for him and cast him into a huge fire.’

# 3886

So they sought to outwit him, but We made them the lowermost.

# 3887

He said, ‘Indeed I am going toward my Lord, who will guide me.’

# 3888

‘My Lord! Give me \[an heir\], one of the righteous.’

# 3889

So We gave him the good news of a forbearing son.

# 3890

When he was old enough to assist in his endeavour, he said, ‘My son! I see in dreams that I am sacrificing you. See what you think.’ He said, ‘Father! Do whatever you have been commanded. If Allah wishes, you will find me to be patient.’

# 3891

So when they had both surrendered \[to Allah’s will\], and he had laid him down on his forehead,

# 3892

We called out to him, ‘O Abraham!

# 3893

You have indeed fulfilled your vision! Thus indeed do We reward the virtuous!

# 3894

This was indeed a manifest test.’

# 3895

Then We ransomed him with a great sacrifice,

# 3896

and left for him a good name in posterity:

# 3897

‘Peace be to Abraham!’

# 3898

Thus do We reward the virtuous.

# 3899

He is indeed one of Our faithful servants.

# 3900

And We gave him the good news of \[the birth of\] Isaac, a prophet, one of the righteous.

# 3901

And We blessed him and Isaac. Among their descendants \[some\] are virtuous, and \[some\] who manifestly wrong themselves.

# 3902

Certainly We favoured Moses and Aaron,

# 3903

and delivered them and their people from their great distress,

# 3904

and We helped them so that they became the victors.

# 3905

We gave them the illuminating scripture

# 3906

and guided them to the straight path,

# 3907

and left for them a good name in posterity.

# 3908

‘Peace be to Moses and Aaron!’

# 3909

Thus indeed do We reward the virtuous.

# 3910

They are indeed among Our faithful servants.

# 3911

Indeed Ilyas was one of the apostles.

# 3912

When he said to his people, ‘Will you not be Godwary?

# 3913

Do you invoke Baal and abandon the best of creators,

# 3914

Allah, your Lord and Lord of your forefathers?,’

# 3915

they impugned him. So they will indeed be mustered \[in hell\]

# 3916

—\[all\] except Allah’s exclusive servants.

# 3917

We left for him a good name in posterity.

# 3918

‘Peace be to Ilyas!’

# 3919

Thus indeed do We reward the virtuous.

# 3920

He is indeed one of Our faithful servants.

# 3921

Indeed Lot was one of the apostles.

# 3922

When We delivered him and all his family,

# 3923

excepting an old woman among those who remained behind,

# 3924

We destroyed the rest.

# 3925

Indeed you pass by them at dawn

# 3926

and at night. Do you not exercise your reason?

# 3927

Indeed Jonah was one of the apostles.

# 3928

When he absconded toward the laden ship,

# 3929

he drew lots with them and was the one to be condemned \[as one to be thrown overboard\].

# 3930

Then the fish swallowed him while he was blameworthy.

# 3931

Had he not been one of those who celebrate Allah’s glory,

# 3932

he would have surely remained in its belly till the day they will be resurrected.

# 3933

Then We cast him on a bare shore, and he was sick.

# 3934

So We made a gourd plant grow above him.

# 3935

We sent him to a \[community of\] hundred thousand or more,

# 3936

and they believed \[in him\]. So We provided for them for a while.

# 3937

Ask them, are daughters to be for your Lord while sons are to be for them?

# 3938

Did We create the angels females while they were present?

# 3939

Be aware that it is out of their mendacity that they say,

# 3940

‘Allah has begotten \[offsprings\],’ and they indeed speak a falsehood.

# 3941

Has He preferred daughters to sons?

# 3942

What is the matter with you? How do you judge?

# 3943

Will you not then take admonition?

# 3944

Do you have a manifest authority?

# 3945

Then produce your scripture, should you be truthful.

# 3946

And they have set up a kinship between Him and the jinn, while the jinn certainly know that they will be presented \[before Him\].

# 3947

Clear is Allah of whatever they allege \[about Him\]

# 3948

—\[all\] except Allah’s exclusive servants.

# 3949

Indeed you and what you worship

# 3950

cannot mislead \[anyone\] about Him,

# 3951

except someone who is bound for hell.

# 3952

‘There is none among us but has a known place.

# 3953

It is we who are the ranged ones.

# 3954

It is we who celebrate Allah’s glory.’

# 3955

They indeed, used to say,

# 3956

‘Had we possessed a Reminder from our predecessors,

# 3957

we would have surely been Allah’s exclusive servants.’

# 3958

But they disbelieved it \[when it came to them\]. Soon they will know!

# 3959

Certainly Our decree has gone beforehand in favour of Our servants, the apostles,

# 3960

that they will indeed receive \[Allah’s\] help,

# 3961

and indeed Our hosts will be the victors.

# 3962

So leave them alone for a while,

# 3963

and watch them; soon they will see \[the truth of the matter\]!

# 3964

Do they seek to hasten Our punishment?

# 3965

But when it descends in their courtyard it will be a dismal dawn for those who had been warned.

# 3966

So leave them alone for a while,

# 3967

and watch; soon they will see!

# 3968

Clear is your Lord, the Lord of Might, of whatever they allege \[concerning Him\].

# 3969

Peace be to the apostles!

# 3970

All praise belongs to Allah, Lord of all the worlds.

# 3971

Suad. By the Quran bearing the Reminder,

# 3972

the faithless indeed dwell in conceit and defiance.

# 3973

How many a generation We have destroyed before them! They cried out \[for help\], but gone was the time for escape.

# 3974

They consider it odd that there should come to them a warner from among themselves, and the faithless say, ‘This is a magician, a mendacious liar.’

# 3975

‘Has he reduced the gods to one god? This is indeed an odd thing!’

# 3976

Their elite go about \[urging others\]: ‘Go and stand by your gods! This is indeed the desirable thing \[to do\].

# 3977

We did not hear of this in the latter-day creed. This is nothing but a fabrication.

# 3978

Has the Reminder been sent down to him out of \[all of\] us?’ Indeed, they are in doubt concerning My Reminder. Indeed, they have not yet tasted My punishment.

# 3979

Do they possess the treasuries of the mercy of your Lord, the All-mighty, the All-munificent?

# 3980

Do they own the kingdom of the heavens and the earth and whatever is between them? \[If so,\] let them ascend \[to the higher spheres\] by the means \[of ascension\].

# 3981

\[They are but\] a host routed out there of the factions.

# 3982

Before them Noah’s people impugned \[their apostle\] and \[so did the people of\] ‘Ad, and Pharaoh, the Impaler \[of his victims\],

# 3983

and Thamud, and the people of Lot, and the inhabitants of Aykah: those were the factions.

# 3984

There was not any one but such as impugned the apostles; so My retribution became due \[against them\].

# 3985

These \[too\] do not await but a single Cry, which will not grant \[them\] any respite.

# 3986

They say, ‘Our Lord! Hasten on for us our share before the Day of Reckoning.’

# 3987

Be patient over what they say, and remember Our servant, David, \[the man\] of strength. Indeed he was a penitent \[soul\].

# 3988

We disposed the mountains to glorify \[Allah\] with him at evening and dawn,

# 3989

and the birds \[as well\], mustered \[in flocks\]; all echoing him \[in a chorus\].

# 3990

We consolidated his kingdom and gave him wisdom and conclusive speech.

# 3991

Has there not come to you the account of the contenders, when they scaled the wall into the sanctuary?

# 3992

When they entered into the presence of David, he was alarmed by them. They said, ‘Do not be afraid. \[We are only\] two contenders: one of us has bullied the other. So judge justly between us, and do not exceed \[the bounds of justice\], and show us the right path.’

# 3993

‘This brother of mine has ninety-nine ewes, while I have only a single ewe, and \[yet\] he says, ‘Commit it to my care,’ and he browbeats me in speech.’

# 3994

He said, ‘He has certainly wronged you by asking your ewe in addition to his own ewes, and indeed many partners bully one another, except such as have faith and do righteous deeds, and few are they.’ Then David knew that We had tested him, whereat he pleaded with his Lord for forgiveness, and fell down in prostration and repented.

# 3995

So We forgave him that, and indeed he has \[a station of\] nearness with Us and a good destination.

# 3996

‘O David! Indeed, We have made you a vicegerent on the earth. So judge between people with justice, and do not follow your desires, or they will lead you astray from the way of Allah. Indeed there is a severe punishment for those who stray from the way of Allah, because of their forgetting the Day of Reckoning.’

# 3997

We did not create the sky and the earth and whatever is between them in vain. That is a conjecture of the faithless. So woe to the faithless for the Fire!

# 3998

Shall We treat those who have faith and do righteous deeds like those who cause corruption on the earth? Shall We treat the Godwary like the vicious?

# 3999

\[This is\] a blessed Book that We have sent down to you, so that they may contemplate its signs, and that those who possess intellect may take admonition.

# 4000

And to David We gave Solomon—what an excellent servant he was! Indeed, he was a penitent \[soul\].

# 4001

One evening when there were displayed before him prancing steeds,

# 4002

he said, ‘Indeed I have preferred the love of \[worldly\] niceties to the remembrance of my Lord until \[the sun\] disappeared behind the \[night’s\] veil.’

# 4003

‘Bring it back for me!’ Then he \[and others\] began to wipe \[their\] legs and necks.

# 4004

Certainly We tried Solomon, and cast a \[lifeless\] body on his throne. Thereupon he was penitent.

# 4005

He said, ‘My Lord! Forgive me, and grant me a kingdom that will not befit anyone except me. Indeed You are the All-munificent.’

# 4006

So We disposed the wind for him, blowing softly wherever he intended by his command,

# 4007

and every builder and diver from the demons,

# 4008

and others \[too\] bound together in chains.

# 4009

‘This is Our bounty: so withhold or bestow without any reckoning.’

# 4010

Indeed he has \[a station of\] nearness with Us and a good destination.

# 4011

And remember Our servant Job \[in the Quran\]. When he called out to his Lord, ‘The devil has visited on me hardship and torment,’

# 4012

\[We told him:\] ‘Stamp your foot on the ground; this \[ensuing spring\] will be a cooling bath and drink.’

# 4013

We gave \[back\] his family to him along with others like them, as a mercy from Us and an admonition for those who possess intellect.

# 4014

\[We told him:\] ‘Take a faggot in your hand and then strike \[your wife\] with it, but do not break \[your\] oath.’ Indeed, We found him to be patient. What an excellent servant! Indeed he was a penitent \[soul\].

# 4015

And remember Our servants, Abraham, Isaac and Jacob, men of strength and insight.

# 4016

Indeed We purified them with exclusive remembrance of the abode \[of the Hereafter\].

# 4017

Indeed they are surely with Us among the elect of the best.

# 4018

And remember Ishmael, Elisha and Dhu’l-Kifl—each \[of whom was\] among the elect.

# 4019

This is a Reminder, and indeed the Godwary have a good destination:

# 4020

the Gardens of Eden, whose gates will be flung open for them.

# 4021

Reclining therein \[on couches\], they will call for abundant fruits and drinks,

# 4022

and there will be with them maidens of restrained glances, of a like age.

# 4023

This is what you are promised on the Day of Reckoning.

# 4024

This is Our provision, which will never be exhausted.

# 4025

This \[will be for the righteous\], and as for the rebellious there will surely be a bad destination:

# 4026

hell, which they shall enter, an evil resting place.

# 4027

\[They will be told, ‘This is scalding water and pus; let them taste it,

# 4028

and other kinds \[of torments\] resembling it.’

# 4029

\[The leaders of the faithless will be told,\] ‘This is a group \[of your followers\] plunging \[into hell\] along with you.’ \[They will repond,\] ‘May wretchedness be their lot! For they will enter the Fire.’

# 4030

They will say, ‘No, may wretchedness be your lot! You prepared this \[hell\] for us. What an evil abode!’

# 4031

They will say, ‘Our Lord! Whoever has prepared this for us, double his punishment in the Fire!’

# 4032

And they will say, ‘Why is it that we do not see \[here\] men whom we used to count among the bad ones,

# 4033

ridiculing them, or do \[our\] eyes miss them \[here\]?’

# 4034

That is indeed a true account of the contentions of the inmates of the Fire.

# 4035

Say, ‘I am just a warner, and there is no god except Allah, the One, the All-paramount,

# 4036

the Lord of the heavens and the earth and whatever is between them, the All-mighty, the All-forgiver.’

# 4037

Say, ‘It is a great prophesy,

# 4038

of which you are disregardful.

# 4039

I have no knowledge of the Supernal Elite when they contend.

# 4040

All that is revealed to me is that I am just a manifest warner.’

# 4041

When your Lord said to the angels, ‘Indeed I am about to create a human being out of clay.

# 4042

So when I have proportioned him and breathed into him of My spirit, then fall down in prostration before him.’

# 4043

Thereat the angels prostrated, all of them together,

# 4044

but not Iblis; he acted arrogantly and he was one of the faithless.

# 4045

He said, ‘O Iblis! What keeps you from prostrating before that which I have created with My \[own\] two hands? Are you arrogant, or are you one of the exalted ones?’

# 4046

‘I am better than him,’ he said. ‘You created me from fire and You created him from clay.’

# 4047

He said, ‘Begone hence, for you are indeed an outcast,

# 4048

and indeed My curse will be on you till the Day of Retribution.’

# 4049

He said, ‘My Lord! Respite me till the day they will be resurrected.’

# 4050

Said He, ‘You are indeed among the reprieved

# 4051

until the day of the known time.’

# 4052

He said, ‘By Your might, I will surely pervert them,

# 4053

except Your exclusive servants among them.’

# 4054

Said He, ‘The truth is that—and I speak the truth—

# 4055

I will surely fill hell with you and all those who follow you.’

# 4056

Say, ‘I do not ask you any reward for it, and I am no impostor.

# 4057

It is just a reminder for all the nations,

# 4058

and you will surely learn its tidings in due time.’

# 4059

The \[gradual\] sending down of the Book is from Allah, the All-mighty, the All-wise.

# 4060

Indeed We have sent down the Book to you with the truth; so worship Allah, putting exclusive faith in Him.

# 4061

Indeed, only exclusive faith is worthy of Allah, and those who take other as awliya besides Him \[claiming,\] ‘We only worship them so that they may bring us near to Allah,’ Allah will judge between them concerning that about which they differ. Indeed Allah does not guide someone who is a liar and an ingrate.

# 4062

Had Allah intended to take a son, He could have chosen from those He has created whatever He wished. Immaculate is He! He is Allah, the One, the All-paramount.

# 4063

He created the heavens and the earth with consummate wisdom. He winds the night over the day, and winds the day over the night, and He has disposed the sun and the moon, each moving for a specified term. Indeed, He is the All-mighty, the All-forgiver!

# 4064

He created you from a single soul, then made from it its mate, and He has sent down for you eight mates of the cattle. He creates you in the wombs of your mothers, creation after creation, in a threefold darkness. That is Allah, your Lord! To Him belongs all sovereignty. There is no god except Him. Then where are you being led away?

# 4065

If you are ungrateful, Allah has indeed no need of you, though He does not approve ingratitude for His servants; and if you give thanks, He approves that for you. No bearer shall bear another’s burden; then your return will be to your Lord, whereat He will inform you concerning what you used to do. Indeed, He knows best what is in the breasts.

# 4066

When distress befalls man, he supplicates his Lord, turning to Him penitently. Then, when He grants him a blessing from Himself, he forgets that for which he had supplicated Him earlier and sets up equals to Allah, that he may lead \[people\] astray from His way. Say, ‘Revel in your ingratitude for a while. Indeed you are among the inmates of the Fire.’

# 4067

Is he who supplicates in the watches of the night, prostrating and standing, apprehensive of the Hereafter and expecting the mercy of his Lord...? Say, ‘Are those who know equal to those who do not know?’ Only those who possess intellect take admonition.

# 4068

Say, ‘\[Allah declares:\] “O My servants who have faith! Be wary of your Lord. For those who do good in this world there will be a good \[reward\], and Allah’s earth is vast. Indeed the patient will be paid in full their reward without any reckoning.” ’

# 4069

Say, ‘I have been commanded to worship Allah with exclusive faith in Him,

# 4070

and I have been commanded to be the foremost of those who submit \[to Him\].’

# 4071

Say, ‘Indeed, should I disobey my Lord, I fear the punishment of a tremendous day.’

# 4072

Say, ‘I worship \[only\] Allah, putting my exclusive faith in Him.

# 4073

You worship whatever you wish besides Him.’ Say, ‘The losers are those who ruin themselves and their families on the Day of Resurrection.’ Indeed, that is a manifest loss!

# 4074

There will be canopies of fire above them, and \[similar\] canopies beneath them. With that Allah deters His servants. So, My servants, be wary of Me!

# 4075

As for those who stay clear of the worship of fake deities and turn penitently to Allah, there is good news for them. So give good news to My servants

# 4076

who listen to the word \[of Allah\] and follow the best \[interpretation\] of it. They are the ones whom Allah has guided, and it is they who possess intellect.

# 4077

Can he against whom the word of punishment has become due...? Can you rescue someone who is in the Fire?

# 4078

But as for those who are wary of their Lord, for them there will be lofty abodes with \[other\] lofty abodes built above them, with streams running beneath them—a promise of Allah. Allah does not break His promise.

# 4079

Have you not seen that Allah sends down water from the sky, then He conducts it through the ground as springs. Then He brings forth with it crops of diverse hues. Then they wither and you see them turn yellow. Then He turns them into chaff. There is indeed a lesson in that for those who possess intellect.

# 4080

Is someone whose breast Allah has opened to Islam so that he follows a light from His Lord...? So woe to those whose hearts have been hardened to the remembrance of Allah. They are in manifest error.

# 4081

Allah has sent down the best of discourses, a scripture \[composed\] of similar motifs, whereat shiver the skins of those who fear their Lord, then their skins and hearts relax at Allah’s remembrance. That is Allah’s guidance, by which He guides whomever He wishes; and whomever Allah leads astray, has no guide.

# 4082

What! Is someone who fends off with his face the terrible punishment \[meted out to him\] on the Day of Resurrection...? And the wrongdoers will be told, ‘Taste what you used to earn.’

# 4083

Those who were before them impugned \[the apostles\], whereat the punishment overtook them whence they were not aware.

# 4084

So Allah made them taste disgrace in the life of the world, and the punishment of the Hereafter will surely be greater, if they knew.

# 4085

We have drawn for mankind in this Quran every \[kind of\] example, so that they may take admonition:

# 4086

an Arabic Quran, without any deviousness, so that they may be Godwary.

# 4087

Allah draws an example: a man jointly owned by several contending masters, and a man belonging entirely to one man: are the two equal in comparison? All praise belongs to Allah! But most of them do not know.

# 4088

You will die, and they \[too\] will die.

# 4089

Then on the Day of Resurrection you will contend before your Lord.

# 4090

So who is a greater wrongdoer than him who attributes a falsehood to Allah, and denies the truth when it reaches him? Is not the \[final\] abode of the faithless in hell?

# 4091

He who brings the truth and he who confirms it—it is they who are the Godwary.

# 4092

They will have what they wish with their Lord—that is the reward of the virtuous—

# 4093

that Allah may absolve them of the worst of what they did, and pay them their reward by the best of what they used to do.

# 4094

Does not Allah suffice \[to defend\] His servant? They would frighten you of others than Him. Yet whomever Allah leads astray, has no guide,

# 4095

and whomever Allah guides, there is no one who can lead him astray. Is not Allah an all-mighty avenger?

# 4096

If you ask them, ‘Who created the heavens and the earth?’ they will surely say, ‘Allah.’ Say, ‘Have you considered what you invoke besides Allah? Should Allah desire some distress for me, can they remove the distress visited by Him? Or should He desire some mercy for me, can they withhold His mercy?’ Say, ‘Allah is sufficient for me. In Him let all the trusting put their trust.’

# 4097

Say, ‘O my people! Act according to your ability. I too am acting. Soon you will know

# 4098

who will be overtaken by a punishment that will disgrace him, and on whom a lasting punishment will descend.’

# 4099

Indeed We have sent down the Book to you with the truth for \[the deliverance of\] mankind. So whoever is guided is guided for his own sake, and whoever goes astray, goes astray to his own detriment, and it is not your duty to watch over them.

# 4100

Allah takes the souls at the time of their death, and those who have not died, in their sleep. Then He retains those for whom He has ordained death and releases the others until a specified time. There are indeed signs in that for a people who reflect.

# 4101

Have they taken intercessors besides Allah? Say, ‘What! Even though they do not control anything, and cannot reason?!’

# 4102

Say, ‘All intercession rests with Allah. To Him belongs the kingdom of the heavens and the earth; then you will be brought back to Him.’

# 4103

When Allah is mentioned alone, \[thereat\] shrink away the hearts of those who do not believe in the Hereafter, but when others are mentioned besides Him, behold, they rejoice!

# 4104

Say, ‘O Allah! Originator of the heavens and the earth, Knower of the sensible and the Unseen, You will judge between Your servants concerning that about which they used to differ.’

# 4105

Even if the wrongdoers possessed all that is on the earth, and as much of it besides, they would offer it on the Day of Resurrection to redeem themselves with it from a terrible punishment, and there will appear to them from Allah what they had never reckoned.

# 4106

The evils of what they had earned will appear to them, and they will be besieged by what they used to deride.

# 4107

When distress befalls man, he supplicates Us. Then, when We grant him a blessing from Us, he says, ‘I was given it by virtue of \[my\] knowledge.’ Indeed, it is a test, but most of them do not know.

# 4108

Those who were before them \[also\] said that, but what they used to earn did not avail them.

# 4109

So the evils of what they had earned visited them, and as for the wrongdoers among these, the evils of what they earn shall be visited on them and they will not frustrate \[Allah\].

# 4110

Do they not know that Allah expands the provision for whomever He wishes and tightens it \[for whomever He wishes\]? There are indeed signs in that for a people who have faith.

# 4111

Say \[that Allah declares,\] ‘O My servants who have committed excesses against their own souls, do not despair of the mercy of Allah. Indeed Allah will forgive all sins. Indeed, He is the All-forgiving, the All-merciful.

# 4112

Turn penitently to Him and submit to Him before the punishment overtakes you, whereupon you will not be helped.

# 4113

Follow the best of what has been sent down to you from your Lord, before the punishment overtakes you suddenly while you are unaware.’

# 4114

Lest anyone should say, ‘Alas for my negligence in the vicinage of Allah! Indeed I was among those who ridiculed.’

# 4115

Or say, ‘Had Allah guided me I would have surely been among the Godwary!’

# 4116

Or say, when he sights the punishment, ‘If only there were a second chance for me, I would be among the virtuous!’

# 4117

\[They will be told,\] ‘Yes, My signs certainly came to you, but you denied them and acted arrogantly and you were among the faithless.’

# 4118

On the Day of Resurrection you will see those who attributed lies to Allah with their faces blackened. Is not the \[final\] abode of the arrogant in hell?

# 4119

Allah will deliver those who were Godwary with their salvation. No ill shall touch them, nor will they grieve.

# 4120

Allah is creator of all things, and He watches over all things.

# 4121

To Him belong the keys of the heavens and the earth, and those who disbelieve in the signs of Allah—it is they who are the losers.

# 4122

Say, ‘Will you, then, bid me to worship other than Allah, O you ignorant ones?!’

# 4123

Certainly it has been revealed to you and to those \[who have been\] before you: ‘If you ascribe a partner to Allah your works shall fail and you shall surely be among the losers.

# 4124

No, worship Allah, and be among the grateful!’

# 4125

They do not regard Allah with the regard due to Him, yet the entire earth will be in His fist on the Day of Resurrection, and the heavens, scrolled, in His right hand. Immaculate is He and exalted above \[having\] any partners that they ascribe \[to Him\].

# 4126

And the Trumpet will be blown, and whoever is in the heavens will swoon and whoever is on the earth, except whomever Allah wishes. Then it will be blown a second time, behold, they will rise up, looking on!

# 4127

The earth will glow with the light of her Lord, and the Book will be set up, and the prophets and the martyrs will be brought, and judgment will be made between them with justice, and they will not be wronged.

# 4128

Every soul will be recompensed fully for what it has done, and He is best aware of what they do.

# 4129

The faithless will be driven to hell in throngs. When they reach it and its gates are opened, its keepers will say to them, ‘Did there not come to you \[any\] apostles from among yourselves, reciting to you the signs of your Lord and warning you of the encounter of this day of yours?’ They will say, ‘Yes, but the word of punishment became due against the faithless.’

# 4130

It will be said, ‘Enter the gates of hell to remain in it \[forever\]. Evil is the \[ultimate\] abode of the arrogant.’

# 4131

Those who are wary of their Lord will be led to paradise in throngs. When they reach it and its gates are opened, its keepers will say to them, ‘Peace be to you! You are welcome! Enter it to remain \[forever\].’

# 4132

They will say, ‘All praise belongs to Allah, who has fulfilled His promise to us and made us inheritors of the earth, that we may settle in paradise wherever we may wish!’ How excellent is the reward of the workers \[of righteousness\]!

# 4133

And you will see the angels surrounding the Throne, celebrating the praise of their Lord, and judgment will be made between them with justice, and it will be said, ‘All praise belongs to Allah, the Lord of all the worlds!’

# 4134

Ha, Meem.

# 4135

The \[gradual\] sending down of the Book is from Allah, the All-mighty, the All-knowing,

# 4136

forgiver of sins and acceptor of repentance, severe in retribution, \[yet\] all-bountiful; there is no god except Him, \[and\] toward Him is the destination.

# 4137

No one disputes the signs of Allah except the faithless. So do not be misled by their bustle in the towns.

# 4138

The people of Noah denied before them and the \[heathen\] factions \[who came\] after them. Every nation attempted to lay hands on their apostle, and disputed erroneously to refute the truth. Then I seized them; so how was My retribution?!

# 4139

That is how the word of your Lord became due concerning the faithless, that they shall be inmates of the Fire.

# 4140

Those who bear the Throne, and those who are around it, celebrate the praise of their Lord and have faith in Him, and they plead for forgiveness for the faithful: ‘Our Lord! You embrace all things in mercy and knowledge. So forgive those who repent and follow Your way and save them from the punishment of hell.

# 4141

Our Lord! Admit them into the Gardens of Eden, which You have promised them, along with whoever is righteous among their forebears, their spouses and their descendants. Indeed You are the All-mighty, the All-wise.

# 4142

Save them from the ills \[of the Day of Retribution\]; and whomever You save from the ills that day, You will have had mercy upon him, and that is the great triumph.’

# 4143

It will be proclaimed to the faithless: ‘Surely, Allah’s outrage \[towards you\] is greater than your outrage towards yourselves, as you were invited to faith, but you disbelieved.’

# 4144

They will say, ‘Our Lord! Twice did You make us die, and twice did You give us life. We admit our sins. Is there any way out \[from this plight\]?’

# 4145

\[They will be told,\] ‘This \[plight of yours\] is because, when Allah was invoked alone, you would disbelieve, but if partners were ascribed to Him you would believe. So the judgment belongs to Allah, the All-exalted, the All-great.’

# 4146

It is He who shows you His signs and sends down provision for you from the sky. Yet no one takes admonition except those who return penitently \[to Allah\].

# 4147

So supplicate Allah, putting exclusive faith in Him, though the faithless should be averse.

# 4148

Raiser of ranks, Lord of the Throne, He casts the Spirit of His command upon whomever of His servants that He wishes, that he may warn \[people\] of the Day of Encounter.

# 4149

The day when they will emerge \[from their graves\], nothing about them will be hidden from Allah. ‘To whom does the sovereignty belong today?’ ‘To Allah, the One, the All-paramount!’

# 4150

‘Today every soul shall be requited for what it has earned. There will be no injustice today. Indeed Allah is swift at reckoning.’

# 4151

Warn them of the Approaching Day, when the hearts will be at the throats, choking with suppressed agony, \[and\] the wrongdoers will have no sympathizer, nor any intercessor who might be heard.

# 4152

He knows the treachery of the eyes, and what the breasts hide.

# 4153

Allah judges with justice, while those whom they invoke besides Him do not judge by anything. Indeed it is Allah who is the All-hearing, the All-seeing.

# 4154

Have they not travelled through the land so that they may observe how was the fate of those who were before them? They were greater than them in might and with respect to the effects \[they left\] in the land. But then Allah seized them for their sins, and they had no defender against Allah \[’s punishment\].

# 4155

That was because their apostles used to bring them manifest proofs, but they defied \[them\]. So Allah seized them. Indeed He is all-strong, severe in retribution.

# 4156

Certainly We sent Moses with Our signs and a manifest authority

# 4157

to Pharaoh, Haman and Korah, but they said, ‘A magician and a mendacious liar.’

# 4158

So when he brought them the truth from Us, they said, ‘Kill the sons of the faithful who are with him, and spare their women.’ But the stratagems of the faithless only go awry.

# 4159

And Pharaoh said, ‘Let me slay Moses, and let him invoke his Lord. Indeed I fear that he will change your religion, or bring forth corruption in our land.’

# 4160

Moses said, ‘I seek the protection of my Lord and your Lord from every arrogant one who does not believe in the Day of Reckoning.’

# 4161

Said a man of faith from Pharaoh’s clan, who concealed his faith, ‘Will you kill a man for saying, ‘‘My Lord is Allah,’’ while he has already brought you manifest proofs from your Lord? Should he be lying, his falsehood will be to his own detriment; but if he is truthful, there shall visit you some of what he promises you. Indeed Allah does not guide someone who is a transgressor and liar.

# 4162

O my people! Today sovereignty belongs to you, and you are dominant in the land. But who will save us from Allah’s punishment should it overtake us?’ Pharaoh said, ‘I just point out to you what I see \[to be advisable for you\], and I guide you only to the way of rectitude.’

# 4163

He who had faith said, ‘O my people! Indeed I fear for you \[a day\] like the day of the \[heathen\] factions;

# 4164

like the case of the people of Noah, of Ad and Thamud, and those who came after them, and Allah does not desire any wrong for \[His\] servants.

# 4165

O my people! I fear for you a day of mutual distress calls,

# 4166

a day when you will turn back \[to flee\], not having anyone to protect you from Allah, and whomever Allah leads astray has no guide.

# 4167

Certainly Joseph brought you manifest proofs earlier, but you continued to remain in doubt concerning what he had brought you. When he died, you said, ‘‘Allah will never send any apostle after him.’’ That is how Allah leads astray those who are unrestrained and skeptical.

# 4168

Those who dispute the signs of Allah without any authority that may have come to them—\[that is\] greatly outrageous to Allah and to those who have faith. That is how Allah seals the heart of every arrogant tyrant.’

# 4169

Pharaoh said, ‘O Haman! Build me a tower so that I may reach the routes

# 4170

—the routes of the heavens—and take a look at the God of Moses, and indeed I consider him a liar.’ The evil of his conduct was thus presented as decorous to Pharaoh, and he was kept from the way \[of Allah\]. Pharaoh’s stratagems only led him into ruin.

# 4171

And he who had faith said, ‘O my people! Follow me; I will guide you to the way of rectitude.

# 4172

O my people! This life of the world is only a \[passing\] enjoyment, and indeed the Hereafter is the abiding home.

# 4173

Whoever commits a misdeed shall not be requited except with its like, but whoever acts righteously, whether male or female, should he be faithful—such shall enter paradise, and they will be provided therein without any reckoning.

# 4174

O my people! \[Think,\] what makes me invite you to deliverance, while you invite me toward the Fire?

# 4175

You invite me to defy Allah and to ascribe to Him partners of which I have no knowledge, while I call you to the All-mighty, the All-forgiver.

# 4176

Undoubtedly, that to which you invite me has no invitation in the world nor in the Hereafter, and indeed our return will be to Allah, and indeed it is the transgressors who will be inmates of the Fire.

# 4177

Soon you will remember what I tell you, and I entrust my affair to Allah. Indeed Allah watches His servants.’

# 4178

Then Allah saved him from their evil schemes, while a terrible punishment besieged Pharaoh’s clan:

# 4179

the Fire, to which they are exposed morning and evening. On the day when the Hour sets in, Pharaoh’s clan will enter the severest punishment.

# 4180

When they argue in the Fire, the oppressed will say to the oppressors, ‘We used to follow you; will you avail us against any portion of the Fire?’

# 4181

The oppressors will say, ‘We are all in it \[together\]; Allah has judged between \[His\] servants.’

# 4182

Those who are in the Fire will say to the keepers of hell, ‘Invoke your Lord to lighten for us \[at least\] a day’s punishment.’

# 4183

They will say, ‘Had not your apostles brought you manifest proofs?’ They will say, ‘Yes.’ They will say, ‘Then invoke \[Him\] yourselves.’ But the invocations of the faithless only go awry.

# 4184

Indeed We shall help Our apostles and those who have faith in the life of the world and on the day when the witnesses rise up,

# 4185

the day when the excuses of the wrongdoers will not benefit them, the curse will lie on them, and for them will be the ills of the \[ultimate\] abode.

# 4186

Certainly We gave guidance to Moses and We gave the Children of Israel the Book as a legacy,

# 4187

as guidance and admonition for those who possess intellect.

# 4188

So be patient! Allah’s promise is indeed true. Plead \[Allah\] for forgiveness of your sin, and celebrate the praise of your Lord morning and evening.

# 4189

Indeed those who dispute the signs of Allah without any authority that may have come to them—there is \[an ambition for\] greatness in their breasts, which they will never attain. So seek the protection of Allah; indeed, He is the All-hearing, the All-seeing.

# 4190

The creation of the heavens and the earth is surely more prodigious than the creation of mankind, but most people do not know.

# 4191

The blind one and the seer are not equal, neither are the evildoers and those who have faith and do righteous deeds. Little is the admonition that you take!

# 4192

Indeed the Hour is bound to come; there is no doubt in it. But most people do not believe.

# 4193

Your Lord has said, ‘Call Me, and I will hear you!’ Indeed those who are disdainful of My worship will enter hell in utter humiliation.

# 4194

It is Allah who made the night for you, that you may rest in it, and the day to provide visibility. Indeed Allah is gracious to mankind, but most people do not give thanks.

# 4195

That is Allah, your Lord, the creator of all things, there is no god except Him. Then where do you stray?

# 4196

Those who were used to impugning the signs of Allah are thus made to go astray.

# 4197

It is Allah who made for you the earth an abode and the sky a canopy. He formed you and perfected your forms, and provided you with all the good things. That is Allah, your Lord! Blessed is Allah, Lord of all the worlds!

# 4198

He is the Living One, there is no god except Him. So supplicate Him, putting exclusive faith in Him. All praise belongs to Allah, Lord of all the worlds.

# 4199

Say, ‘I have been forbidden to worship those whom you invoke besides Allah, as manifest proofs have come to me from my Lord, and I have been commanded to submit to the Lord of all the worlds.’

# 4200

It is He who created you from dust, then from a drop of \[seminal\] fluid, then from a clinging mass, then He brings you forth as infants, then \[He nurtures you\] so that you may come of age, and then that you may become aged—though there are some of you who die earlier—and complete a specified term, and so that you may exercise your reason.

# 4201

It is He who gives life and brings death. When He decides on a matter, He just says to it, ‘Be!’ and it is.

# 4202

Have you not regarded those who dispute the signs of Allah, where they are being led away \[from Allah’s way\]?

# 4203

—Those who deny the Book and what we have sent with Our apostles. Soon they will know

# 4204

when they are dragged \[with\] iron collars and chains around their necks

# 4205

into scalding waters and then set aflame in the Fire.

# 4206

Then they will be told, ‘Where are they whom you used to worship as deities

# 4207

besides Allah?’ They will say, ‘They have forsaken us. No, we did not invoke anything before.’ That is how Allah leads the faithless astray.

# 4208

‘That \[punishment\] is because you used to boast unduly on the earth and because you used to strut.

# 4209

Enter the gates of hell, to remain in it \[forever\].’ Evil is the \[final\] abode of the arrogant.

# 4210

So be patient! Allah’s promise is indeed true. Whether We show you a part of what We promise them, or take you away \[before that\], \[in any case\] they will be brought back to Us.

# 4211

Certainly We have sent apostles before you. Of them are those We have recounted to you, and of them are those We have not recounted to you. An apostle may not bring any sign except by Allah’s permission. Hence, when Allah’s edict comes, judgment is made with justice, and it is thence that the falsifiers become losers.

# 4212

It is Allah who created the cattle for you that you may ride some of them, and some of them you eat;

# 4213

and there are \[numerous\] uses in them for you, and that over them you may satisfy any need that is in your breasts, and you are carried on them and on ships.

# 4214

He shows you His signs. So which of the signs of Allah do you deny?

# 4215

Have they not travelled over the land so that they may observe how was the fate of those who were before them? They were more numerous than them and were greater \[than them\] in power and with respect to the effects \[they left\] in the land. But what they used to earn did not avail them.

# 4216

When their apostles brought them manifest proofs, they boasted about the knowledge they possessed, but they were besieged by what they used to deride.

# 4217

Then, when they sighted Our punishment, they said, ‘We believe in Allah alone, and disavow what we used to take as His partners.’

# 4218

But their faith was of no benefit to them when they sighted Our punishment—Allah’s precedent, which has passed among His servants, and it is thence that the faithless will be losers.

# 4219

Ha, Meem.

# 4220

A \[gradually\] sent down \[revelation\] from the All-beneficent, the All-merciful,

# 4221

\[this is\] a Book whose signs have been elaborated for a people who have knowledge, an Arabic Quran,

# 4222

a bearer of good news and a warner. But most of them turn away \[from it\], \[and\] so they do not listen.

# 4223

They say, ‘Our hearts are in veils \[which shut them off\] from what you invite us to, and there is a deafness in our ears, and there is a curtain between us and you. So act \[as your faith requires\]; we too are acting \[according to our own\].’

# 4224

Say, ‘I am just a human like you. It has been revealed to me that your God is the One God. So worship Him single-mindedly and plead to Him for forgiveness.’ And woe to the polytheists

# 4225

—those who do not pay the zakat and disbelieve in the Hereafter.

# 4226

As for those who have faith and do righteous deeds, there will be an everlasting reward for them.

# 4227

Say, ‘Do you really disbelieve in Him who created the earth in two days, and ascribe partners to Him? That is the Lord of all the worlds!’

# 4228

He set in it firm mountains, \[rising\] above it, blessed it, and ordained in it, in four days, \[various\] means of sustenance, equally for all seekers.

# 4229

Then He turned to the heaven, and it was smoke, and He said to it and to the earth, ‘Come, willingly or unwillingly!’ They said, ‘We come obediently.’

# 4230

Then He set them up as seven heavens in two days, and revealed \[to the angels\] in each heaven its ordinance. We have adorned the lowest heaven with lamps, and guarded them. That is the ordaining of the All-mighty, the All-knowing.

# 4231

But if they turn away, say, ‘I warn you of a thunderbolt, like the thunderbolt of ‘Ad and Thamud.’

# 4232

When the apostles came to them, before them and in their own time, saying, ‘Worship no one except Allah!’ They said, ‘Had our Lord wished, He would have sent down angels \[to us\]. We indeed disbelieve in what you have been sent with.’

# 4233

As for \[the people of\] ‘Ad, they acted arrogantly in the earth unduly, and they said, ‘Who is more powerful than us?’ Did they not see that Allah, who created them, is more powerful than them? They used to impugn Our signs;

# 4234

so We unleashed upon them an icy gale during ill-fated days, in order that We might make them taste a humiliating punishment in the life of the world. Yet the punishment of the Hereafter will be surely more disgraceful, and they will not be helped.

# 4235

As for \[the people of\] Thamud, We guided them, but they preferred blindness to guidance. So the bolt of a humiliating punishment seized them because of what they used to earn.

# 4236

And We delivered those who had faith and were Godwary.

# 4237

The day the enemies of Allah are marched out toward the Fire, while they are in check,

# 4238

when they come to it, their hearing, their eyes and their skins will bear witness against them concerning what they used to do.

# 4239

They will say to their skins, ‘Why did you bear witness against us?’ They will say, ‘We were given speech by Allah, who gave speech to all things. He created you the first time, and you are being brought back to Him.

# 4240

You did not use to conceal yourselves \[while perpetrating sinful acts\] lest your hearing, your eyes, or your skins should bear witness against you, but you thought that Allah did not know most of what you did.

# 4241

That misjudgement, which you entertained about your Lord ruined you. So you became losers.’

# 4242

Should they be patient, the Fire is their abode; and should they seek to propitiate \[Allah\], they will not be redeemed.

# 4243

We have assigned them companions who make their present \[conduct\] and future \[state\] seem decorous to them, and the word became due against them along with the nations of jinn and humans that passed away before them. They were indeed losers.

# 4244

The faithless say, ‘Do not listen to this Quran and hoot it down so that you may prevail \[over the Apostle\].’

# 4245

We will surely make the faithless taste a severe punishment, and We will surely requite them by the worst of what they used to do.

# 4246

That is the requital of the enemies of Allah—the Fire! In it, they will have an everlasting abode, as a requital for their impugning Our signs.

# 4247

The faithless will say, ‘Our Lord! Show us those who led us astray from among jinn and humans so that we may trample them under our feet, so that they may be among the lowermost!’

# 4248

Indeed those who say, ‘Our Lord is Allah!’ and then remain steadfast, the angels descend upon them, \[saying,\] ‘Do not fear, nor be grieved! Receive the good news of the paradise, which you have been promised.

# 4249

We are your friends in the life of this world and in the Hereafter, and you will have in it whatever your souls desire, and you will have in it whatever you ask for,

# 4250

as a hospitality from One all-forgiving, all-merciful.’

# 4251

Who has a better call than him who summons to Allah and acts righteously and says, ‘Indeed I am one of the Muslims’?

# 4252

Good and evil \[conduct\] are not equal. Repel \[evil\] with what is best. \[If you do so,\] he between whom and you was enmity, will then be as though he were a sympathetic friend.

# 4253

But none is granted it except those who are patient, and none is granted it except the greatly endowed.

# 4254

Should an incitement from Satan prompt you \[to ill feeling\], seek the protection of Allah. Indeed, He is the All-hearing, the All-knowing.

# 4255

Among His signs are night and day, and the sun and the moon. Do not prostrate to the sun, nor to the moon, but prostrate to Allah who created them, if it is Him that you worship.

# 4256

But if they disdain \[the worship of Allah\], those who are near your Lord glorify Him night and day, and they are not wearied.

# 4257

Among His signs, is that you see the earth desolate; but when We send down water upon it, it stirs and swells. Indeed, He who revives it will also revive the dead. Indeed, He has power over all things.

# 4258

Those who abuse Our signs are not hidden from Us. Is someone who is cast in the Fire better off, or someone who arrives safely on the Day of Resurrection? Act as you wish; indeed He watches what you do.

# 4259

Those who reject the Reminder when it comes to them... Indeed, it is an august Book:

# 4260

falsehood cannot approach it, at present or in future, a \[revelation gradually\] sent down from One all-wise, all-laudable.

# 4261

Nothing is said to you except what has already been said to the apostles before you. Indeed your Lord is One who forgives and also metes out a painful retribution.

# 4262

Had We made it a non-Arabic Quran, they would have said, ‘Why have not its signs been articulated?’ ‘What! A non-Arabian \[scripture\] and an Arabian \[prophet\]!?’ Say, ‘It is guidance and healing for those who have faith. As for those who are faithless, there is a deafness in their ears and it is lost to their sight: \[to them it is as if\] they were called from a distant place.’

# 4263

Certainly We gave Moses the Book, but differences arose about it; and were it not for a prior decree of your Lord, judgement would have been made between them, for they are in grave doubt concerning it.

# 4264

Whoever acts righteously, it is for \[the benefit of\] his own soul, and whoever does evil, it is to its detriment, and your Lord is not tyrannical to His servants.

# 4265

On Him devolves the knowledge of the Hour, and no fruit emerges from its covering and no female conceives or delivers except with His knowledge. On the day when He will call out to them, ‘Where are My ‘partners’?’ They will say, ‘We informed You that there is no witness amongst us.’

# 4266

What they used to invoke before has forsaken them, and they know there is no escape for them.

# 4267

Man is never wearied of supplicating for good, and should any ill befall him, he becomes hopeless and despondent.

# 4268

If, after distress has befallen him, We let him have a taste of Our mercy, he says, ‘This is my due! I do not think the Hour will ever come, and in case I am returned to my Lord, I will indeed have the best \[reward\] with Him.’ So We will surely inform the faithless about what they have done, and will surely make them taste a harsh punishment.

# 4269

When We bless man, he is disregardful and turns aside; but when an ill befalls him, he makes protracted supplications.

# 4270

Say, ‘Tell me, if it is from Allah and you disbelieve in it, who will be more astray than those who are in extreme defiance.’

# 4271

Soon We shall show them Our signs in the horizons and in their own souls until it becomes clear to them that He is the Real. Is it not sufficient that your Lord is witness to all things?

# 4272

Indeed, they are in doubt about the encounter with their Lord! Indeed, He embraces all things!

# 4273

Ha, Meem,

# 4274

‘Ayn, Seen, Qaf.

# 4275

Allah, the All-mighty and the All-wise, thus reveals to you and to those who were before you:

# 4276

whatever is in the heavens and whatever is in the earth belongs to Him, and He is the All-exalted, the All-supreme.

# 4277

The heavens are about to be rent apart from above them, while the angels celebrate the praise of their Lord and plead for forgiveness for those \[faithful\] who are on the earth. Indeed, Allah is the All-forgiving, the All-merciful!

# 4278

As for those who have taken awliya besides Him, Allah is watchful over them, and you are not their keeper.

# 4279

Thus have We revealed to you an Arabic Quran that you may warn \[the people of\] the Mother of the Towns and those around it, and warn \[them\] of the Day of Gathering, in which there is no doubt, \[whereupon\] a part \[of mankind\] will be in paradise and a part will be in the Blaze.

# 4280

Had Allah wished, He would have surely made them one community; but He admits whomever He wishes into His mercy, and the wrongdoers do not have any guardian or helper.

# 4281

Have they taken awliya besides Him? \[Say,\] ‘It is Allah, who is the \[true\] Wali, and He revives the dead, and He has power over all things.

# 4282

Whatever thing you may differ about, its judgement is with Allah. That is Allah, my Lord. In Him, I have put my trust, and to Him do I turn penitently.

# 4283

The originator of the heavens and the earth, He made for you mates from your own selves, and mates of the cattle, by which means He multiplies you. Nothing is like Him, and He is the All-hearing, the All-seeing.

# 4284

To Him belong the keys of the heavens and the earth: He expands the provision for whomever He wishes, and tightens it \[for whomever He wishes\]. Indeed He has knowledge of all things.’

# 4285

He has prescribed for you the religion which He had enjoined upon Noah and which We have \[also\] revealed to you, and which We had enjoined upon Abraham, Moses and Jesus, declaring, ‘Maintain the religion, and do not be divided in it.’ Hard on the polytheists is that to which you summon them. Allah chooses for it whomever He wishes, and He guides to it whomever returns penitently \[to Him\].

# 4286

They did not divide \[into sects\] except after the knowledge had come to them, out of envy among themselves; and were it not for a prior decree of your Lord \[granting them reprieve\] until a specified time, decision would have been made between them. Indeed those who were made heirs to the Book after them are in grave doubt concerning it.

# 4287

So summon to this \[unity of religion\], and be steadfast, just as you have been commanded, and do not follow their desires, and say, ‘I believe in whatever Book Allah has sent down. I have been commanded to do justice among you. Allah is our Lord and your Lord. Our deeds belong to us and your deeds belong to you. There is no quarrel between us and you. Allah will bring us together and toward Him is the destination.’

# 4288

Those who argue concerning Allah, after His call has been answered, their argument stands refuted with their Lord, and upon them shall be \[His\] wrath, and there is a severe punishment for them.

# 4289

It is Allah who has sent down the Book with the truth and \[He has sent down\] the Balance. What do you know—maybe the Hour is near!

# 4290

Those who do not believe in it ask \[you\] to hasten it, but those who have faith are apprehensive of it, and know that it is true. Indeed those who are in doubt about the Hour are in extreme error!

# 4291

Allah is all-attentive to His servants. He provides for whomever He wishes, and He is the All-strong, the All-mighty.

# 4292

Whoever desires the tillage of the Hereafter, We will enhance for him his tillage, and whoever desires the tillage of the world, We will give it to him, but he will have no share in the Hereafter.

# 4293

Do they have deities \[besides Allah\] who have ordained for them a religion not permitted by Allah? Were it not for a \[prior\] conclusive word, judgement would have been made between them, and indeed a painful punishment awaits the wrongdoers.

# 4294

When it is about to befall them, You will see the wrongdoers fearful because of what they have earned; but those who have faith and do righteous deeds will be in the gardens of paradise: they will have whatever they wish near their Lord. That is the mighty grace.

# 4295

Such is the good news that Allah gives to His servants who have faith and do righteous deeds! Say, ‘I do not ask you any reward for it except the love of \[my\] relatives.’ Whoever performs a good deed, We shall enhance its goodness for him. Indeed Allah is all-forgiving, all-appreciative.

# 4296

Do they say, ‘He has fabricated a lie against Allah’? If so, should Allah wish He would set a seal on your heart, and Allah will efface the falsehood and confirm the truth with His words. Indeed He knows well what is in the breasts.

# 4297

It is He who accepts the repentance of His servants, and excuses their misdeeds and knows what you do.

# 4298

He answers \[the supplications of\] those who have faith and do righteous deeds and enhances them out of His grace. But as for the faithless, there is a severe punishment for them.

# 4299

Were Allah to expand the provision for \[all\] His servants, they would surely create havoc on the earth. But He sends down in a \[precise\] measure whatever He wishes. Indeed, He is all-aware, all-seeing about His servants.

# 4300

It is He who sends down the rain after they have been despondent, and unfolds His mercy, and He is the Guardian, the All-laudable.

# 4301

Among His signs is the creation of the heavens and the earth and whatever creatures He has scattered in them, and He is able to gather them whenever He wishes.

# 4302

Whatever affliction that may visit you is because of what your hands have earned, and He excuses many \[an offense of yours\].

# 4303

You cannot frustrate \[Allah\] on the earth, and you do not have besides Allah any guardian or helper.

# 4304

Among His signs are the ships \[that run\] on the sea \[appearing\] like landmarks.

# 4305

If He wishes He stills the wind, whereat they remain standstill on its surface. There are indeed signs in that for every patient and grateful \[servant\].

# 4306

Or He wrecks them because of what they have earned, and He excuses many \[an offense\].

# 4307

Let those who dispute Our signs know that there is no escape for them.

# 4308

Whatever you have been given are the wares of the life of this world, but what is with Allah is better and more lasting for those who have faith and who put their trust in their Lord

# 4309

—those who avoid major sins and indecencies, and forgive when angered;

# 4310

those who answer their Lord, maintain the prayer, and \[conduct\] their affairs by counsel among themselves, and they spend out of what We have provided them;

# 4311

those who, when afflicted by oppression, defend themselves.

# 4312

The requital of evil is an evil like it, so whoever excuses and conciliates, his reward lies with Allah. Indeed, He does not like the wrongdoers.

# 4313

As for those who retaliate after being wronged, there is no ground for action against them.

# 4314

The ground for action is only against those who oppress the people and commit tyranny in the land in violation of justice. For such there will be a painful punishment.

# 4315

As for someone who endures patiently and forgives—that is indeed the steadiest of courses.

# 4316

Those whom Allah leads astray have no guardian apart from Him. You will see the wrongdoers, when they sight the punishment, saying, ‘Is there any way for a retreat?’

# 4317

You will see them being exposed to it, humbled by abasement, furtively looking askance. The faithful will say, ‘Indeed the losers are those who have ruined themselves and their families on the Day of Resurrection. Indeed, the wrongdoers will abide in lasting punishment.

# 4318

They have no awliya to help them besides Allah. There is no way out for those whom Allah leads astray.’

# 4319

Respond to your Lord before there comes a day for which there will be no revoking from Allah. On that day you will have no refuge, nor will you have \[any chance for\] denial \[of your sins\].

# 4320

But if they disregard \[your warnings\], \[keep in mind that\] We have not sent you as their keeper. Your duty is only to communicate. Indeed when We let man taste Our mercy, he boasts about it; but should an ill visit him because of what his hands have sent ahead, then man is very ungrateful.

# 4321

To Allah belongs the kingdom of the heavens and the earth. He creates whatever He wishes; He gives females to whomever He wishes, and males to whomever He wishes,

# 4322

or He combines them males and females, and makes sterile whomever He wishes. Indeed, He is all-knowing, all-powerful.

# 4323

It is not \[possible\] for any human that Allah should speak to him except through revelation or from behind a veil, or send a messenger who reveals by His permission whatever He wishes. Indeed He is all-exalted, all-wise.

# 4324

Thus have We imbued you with a Spirit of Our command. You did not know what the Book is, nor what is faith; but We made it a light that We may guide by its means whomever We wish of Our servants. Indeed, you guide to a straight path,

# 4325

the path of Allah, to whom belongs whatever is in the heavens and whatever is in the earth. Indeed all matters return to Allah!

# 4326

Ha, Meem.

# 4327

By the Manifest Book:

# 4328

We have made it an Arabic Quran so that you may exercise your reason,

# 4329

and it is sublime and wise with Us in the Mother Book.

# 4330

Shall We keep back the Reminder from you and disregard you because you are an unrestrained lot?

# 4331

How many a prophet We have sent to the former peoples!

# 4332

There did not come to them any prophet but that they used to deride him.

# 4333

So We destroyed those who were stronger than these, and the example of the former peoples has already come to pass.

# 4334

If you ask them, ‘Who created the heavens and the earth?’ they will surely say, ‘The All-mighty, the All-knowing created them.’

# 4335

He, who made the earth a cradle for you, and made for you in it ways so that you may be guided \[to your destinations\],

# 4336

and who sent down water from the sky in a measured manner, and We revived with it a dead country. Likewise, you shall be raised \[from the dead\].

# 4337

He created all the kinds and made for you the ships and the cattle such which you ride,

# 4338

that you may sit on their backs, then remember the blessing of your Lord when you are settled on them, and say, ‘Immaculate is He who has disposed this for us, and we \[by ourselves\] were no match for it.

# 4339

Indeed we shall return to our Lord.’

# 4340

They ascribe to Him offspring from among His servants! Man is indeed a manifest ingrate.

# 4341

Did He adopt daughters from what He creates while He preferred you with sons?

# 4342

When one of them is brought the news of what he ascribes to the All-beneficent, his face becomes darkened and he chokes with suppressed rage, \[and says\]

# 4343

‘What! One who is brought up amid ornaments and is inconspicuous in contests?’

# 4344

They have made the angels—who are servants of the All-beneficent—females. Were they witness to their creation? Their testimony will be written down and they shall be questioned.

# 4345

They say, ‘Had the All-beneficent wished, we would not have worshipped them.’ They do not have any knowledge of that, and they do nothing but surmise.

# 4346

Did We give them a Book before this, so that they are holding fast to it?

# 4347

No, they said, ‘We found our fathers following a creed, and we are indeed guided in their footsteps.’

# 4348

So it has been that We did not send any warner to a town before you, without its affluent ones saying, ‘We found our fathers following a creed and we are indeed following in their footsteps.’

# 4349

He would say, ‘What! Even if I bring you a better guidance than what you found your fathers following?!’ They would say, ‘We indeed disbelieve in what you are sent with.’

# 4350

Thereupon We took vengeance on them; so observe how was the fate of the deniers.

# 4351

When Abraham said to his father and his people, ‘I repudiate what you worship,

# 4352

excepting Him who originated me; indeed He will guide me.’

# 4353

He made it a lasting word among his posterity so that they may come back \[to the right path\].

# 4354

Indeed, I provided for these and their fathers until the truth and a manifest apostle came to them.

# 4355

But when the truth came to them, they said, ‘This is magic, and we indeed disbelieve in it.’

# 4356

And they said, ‘Why was not this Quran sent down to some great man from the two cities?’

# 4357

Is it they who dispense the mercy of your Lord? It is We who have dispensed among them their livelihood in the present life, and raised some of them above others in rank, so that some may take others into service, and your Lord’s mercy is better than what they amass.

# 4358

Were it not \[for the danger\] that mankind would be one community, We would have made for those who defy the All-beneficent, silver roofs for their houses and \[silver\] stairways by which they ascend,

# 4359

and \[silver\] doors for their houses and \[silver\] couches on which they recline,

# 4360

and ornaments of gold; yet all that would be nothing but the wares of the life of this world, and the Hereafter is for the Godwary near your Lord.

# 4361

We assign a devil to be the companion of him who turns a blind eye to the remembrance of the All-beneficent.

# 4362

Indeed they bar them from the way \[of Allah\], while they suppose that they are \[rightly\] guided.

# 4363

When he comes to Us, he will say, ‘I wish there had been between me and you the distance between the east and the west! What an evil companion \[you are\]!’

# 4364

‘Today that will be of no avail to you. As you did wrong, so will you share in the punishment.’

# 4365

Can you, then, make the deaf hear or guide the blind and those who are in manifest error?

# 4366

We will indeed take vengeance on them, whether We take you away

# 4367

or show you what We have promised them, for indeed We hold them in Our power.

# 4368

So hold fast to what has been revealed to you. Indeed, you are on a straight path.

# 4369

Indeed it is a reminder for you and your people, and soon you will be questioned.

# 4370

Ask those of Our apostles We have sent before you: Did We set up any gods to be worshipped besides the All-beneficent?

# 4371

Certainly We sent Moses with Our signs to Pharaoh and his elite. He said, ‘I am indeed an apostle of the Lord of all the worlds.’

# 4372

But when he brought them Our signs, they indeed laughed at them.

# 4373

We did not show them a sign but it was greater than the other, and We visited on them punishment so that they might come back.

# 4374

They would say, ‘O magician! Invoke your Lord for us by the covenant He has made with you \[to remove this scourge\]. We will indeed be guided \[when it is removed\].’

# 4375

But when We lifted the punishment from them, behold, they would break their pledge.

# 4376

And Pharaoh proclaimed to his people, saying, ‘O my people! Do not the kingdom of Egypt and these rivers that run at my feet belong to me? Do you not perceive?

# 4377

Am I not better than this wretch who cannot even speak clearly?

# 4378

Why no bracelets of gold have been thrown to him, nor any angels accompany him as escorts?’

# 4379

Thus did he mislead his people and they obeyed him. Indeed, they were a transgressing lot.

# 4380

So when they roused Our wrath, We took vengeance on them and drowned them all.

# 4381

Thus We made them the vanguard and an example for posterity.

# 4382

When the Son of Mary was cited as an example, behold, your people raise an outcry.

# 4383

They say, ‘Are our gods better or he?’ They cite him to you only for the sake of contention. Indeed, they are a contentious lot.

# 4384

He was just a servant whom We had blessed and made an exemplar for the Children of Israel.

# 4385

Had We wished We would have set angels in your stead to be \[your\] successors on the earth.

# 4386

\[Say,\] ‘Indeed he is a portent of the Hour; so do not doubt it and follow me. This is a straight path.

# 4387

Do not let Satan bar you \[from the way of Allah\]. Indeed he is your manifest enemy.’

# 4388

When Jesus brought those manifest proofs, he said, ‘I have certainly brought you wisdom, and \[I have come\] to make clear to you some of the things that you differ about. So be wary of Allah and obey me.

# 4389

Indeed Allah is my Lord and your Lord; so worship Him. This is a straight path.’

# 4390

But the factions differed among themselves. So woe to the wrongdoers for the punishment of a painful day.

# 4391

Do they not consider that the Hour may overtake them suddenly while they are unaware?

# 4392

On that day, friends will be one another’s enemies, except for the Godwary.

# 4393

\[They will be told,\] ‘O My servants! Today you will have no fear, nor will you grieve

# 4394

—those who believed in Our signs and had been Muslims.

# 4395

Enter paradise, you and your spouses, rejoicing.’

# 4396

They will be served around with golden dishes and goblets, and therein will be whatever the souls desire and eyes delight in. ‘You will remain in it \[forever\].

# 4397

That is the paradise you have been given to inherit for what you used to do.

# 4398

There are abundant fruits for you in it, from which you will eat.’

# 4399

Indeed the guilty will remain \[forever\] in the punishment of hell.

# 4400

It will not be lightened for them, and they will be despondent in it.

# 4401

We did not wrong them, but they themselves were wrongdoers.

# 4402

They will call out, ‘O Malik! Let your Lord finish us off!’ He will say, ‘Indeed you will stay on.’

# 4403

‘We certainly brought you the truth, but most of you were averse to the truth.’

# 4404

Have they settled on some \[devious\] plan? Indeed, We too are settling \[on Our plans\].

# 4405

Do they suppose that We do not hear their secret thoughts and their secret talks? Yes indeed \[We do\]! And with them are Our messengers, writing down \[everything\].

# 4406

Say, ‘If the All-beneficent had offspring, I would have been the first to worship \[him\].’

# 4407

Clear is the Lord of the heavens and the earth, the Lord of the Throne, of whatever they allege \[concerning Him\]!

# 4408

So leave them to gossip and play until they encounter the day they are promised.

# 4409

It is He who is God in the sky, and God on the earth, and He is the All-Wise, the All-Knowing.

# 4410

Blessed is He to whom belongs the kingdom of the heavens and the earth and whatever is between them, and with Him is the knowledge of the Hour, and to Him you will be brought back.

# 4411

Those whom they invoke besides Him have no power of intercession, except those who are witness to the truth and who know \[for whom to intercede\].

# 4412

If you ask them, ‘Who created them?’ they will surely say, ‘Allah.’ Then where do they stray?

# 4413

And his plaint: ‘My Lord! Indeed these are a people who will not have faith!’

# 4414

So disregard them, and say, ‘Peace!’ Soon they will know.

# 4415

Ha, Meem.

# 4416

By the Manifest Book!

# 4417

We sent it down on a blessed night, and We have been warning \[mankind\].

# 4418

Every definitive matter is resolved on it,

# 4419

as an ordinance from Us. We have been sending \[apostles\]

# 4420

as a mercy from your Lord—indeed He is the All-hearing, the All-knowing—

# 4421

the Lord of the heavens and the earth, and whatever is between them, should you have conviction.

# 4422

There is no god except Him: He gives life and brings death, your Lord and the Lord of your forefathers.

# 4423

But they play around in doubt.

# 4424

So watch out for the day when the sky brings on a manifest smoke,

# 4425

enveloping the people. \[They will cry out:\] ‘This is a painful punishment.

# 4426

Our Lord! Remove this punishment from us. Indeed we have believed!’

# 4427

What will the admonition avail them, when a manifest apostle had already come to them,

# 4428

but they turned away from him, and said, ‘A tutored madman?’

# 4429

Indeed We will withdraw the punishment a little; but you will revert \[to your earlier ways\].

# 4430

The day We shall strike with the most terrible striking, We will indeed take vengeance \[on them\].

# 4431

Certainly We tried the people of Pharaoh before them, when a noble apostle came to them,

# 4432

\[saying,\] ‘Give over the servants of Allah to me; indeed I am a trusted apostle \[sent\] to you.

# 4433

Do not defy Allah. Indeed I bring you a manifest authority.

# 4434

I seek the protection of my Lord and your Lord, lest you should stone me.

# 4435

And if you do not believe me, keep out of my way.’

# 4436

Then he invoked his Lord, \[saying,\] ‘These are indeed a guilty lot.’

# 4437

\[Allah told him,\] ‘Set out by night with My servants; for you will be pursued.

# 4438

Leave behind the sea unmoving; for they will be a drowned host.’

# 4439

How many gardens and springs did they leave behind!

# 4440

Fields and splendid places,

# 4441

and the affluence wherein they rejoiced!

# 4442

So it was; and We bequeathed them to another people.

# 4443

So neither the sky wept for them, nor the earth; nor were they granted any respite.

# 4444

Certainly We delivered the Children of Israel from the humiliating torment

# 4445

of Pharaoh. Indeed, he was a tyrant among the transgressors.

# 4446

Certainly We chose them knowingly above all the nations,

# 4447

and We gave them some signs in which there was a manifest test.

# 4448

These ones say,

# 4449

‘It will be only our first death, and we shall not be resurrected.

# 4450

Bring our fathers back \[to life\], if you are truthful.’

# 4451

Are they better, or the people of Tubba‘, and those who were before them? We destroyed them; indeed, they were guilty.

# 4452

We did not create the heavens and the earth and whatever is between them for play.

# 4453

We did not create them except with consummate wisdom; but most of them do not know.

# 4454

Indeed the Day of Judgement is the tryst for them all,

# 4455

the day when a friend will not avail a friend in any way, nor will they be helped,

# 4456

except for him on whom Allah has mercy. Indeed He is the All-mighty, the All-merciful.

# 4457

Indeed the tree of Zaqqum

# 4458

will be the food of the sinful.

# 4459

Like molten copper it will boil in their bellies,

# 4460

seething like boiling water.

# 4461

\[The keepers of hell will be told,\] ‘Seize him and drag him to the middle of hell,

# 4462

then pour over his head boiling water as punishment,

# 4463

\[and tell them,\] “Taste this! Indeed you are the \[self-styled\] mighty and noble!

# 4464

This is what you used to doubt!’

# 4465

Indeed the Godwary will be in a safe place,

# 4466

amid gardens and springs,

# 4467

dressed in fine silk and brocade, sitting face to face.

# 4468

So shall it be, and We shall wed them to black-eyed houris.

# 4469

Secure \[from any kind of harm,\] there they will call for every kind of fruit \[they wish\].

# 4470

Other than the first death, they will not taste death therein, and He will save them from the punishment of hell

# 4471

—a grace from your Lord. That is the great success.

# 4472

Indeed We have made it simple in your language, so that they may take admonition.

# 4473

So wait! They \[too\] are waiting.

# 4474

Ha, Meem.

# 4475

The \[gradual\] sending down of the Book is from Allah, the All-mighty, All-wise.

# 4476

In the heavens and the earth there are indeed signs for the faithful,

# 4477

There are signs for people who have certainty in your own creation and in animals, He scatters abroad.

# 4478

There are signs for people who exercise their reason in the alternation of night and day, in the provision that Allah sends down from the sky, with which He revives the earth after its death, and in the changing of the winds.

# 4479

These are the signs of Allah that We recite for you in truth. So what discourse will they believe after Allah and His signs?

# 4480

Woe to every sinful liar,

# 4481

who hears the signs of Allah being recited to him, yet persists arrogantly as if he had not heard them. So inform him of a painful punishment.

# 4482

Should he learn anything about Our signs, he takes them in derision. For such there is a humiliating punishment.

# 4483

Ahead of them is hell, and neither what they have earned, nor what they had taken as guardians besides Allah will avail them in any way, and there is a great punishment for them.

# 4484

This is \[true\] guidance, and there is a painful punishment due to defilement for those who defy the signs of their Lord.

# 4485

It is Allah who disposed the sea for you\[r benefit\] so that the ships may sail in it by His command, that you may seek of His bounty and that you may give thanks.

# 4486

He has disposed for you\[r benefit\] whatever is in the heavens and whatever is on the earth; all is from Him. There are indeed signs in that for a people who reflect.

# 4487

Say to the faithful to forgive those who do not expect Allah’s days, that He may \[Himself\] requite every people for what they used to earn.

# 4488

Whoever acts righteously, it is for his own soul, and whoever does evil, it is to its own detriment, then you will be brought back to your Lord.

# 4489

Certainly We gave the Children of Israel the Book, judgement and prophethood and We provided them with all the good things. We gave them an advantage over all the nations,

# 4490

and We gave them manifest precepts. But they did not differ except after knowledge had come to them, out of envy among themselves. Indeed your Lord will judge between them on the Day of Resurrection concerning that about which they used to differ.

# 4491

Then We set you upon a clear course of the Law; so follow it, and do not follow the desires of those who do not know.

# 4492

Indeed they will not avail you in any way against Allah. Indeed the wrongdoers are allies of one another, but Allah is the ally of the Godwary.

# 4493

These are eye-openers for mankind, and guidance and mercy for a people who have certainty.

# 4494

Do those who have perpetrated misdeeds suppose that We shall treat them like those who have faith and do righteous deeds, their life and death being equal? Evil is the judgement that they make!

# 4495

Allah created the heavens and the earth with consummate wisdom, so that every soul may be requited for what it has earned, and they will not be wronged.

# 4496

Have you seen him who has taken his desire to be his god and whom Allah has led astray knowingly, set a seal upon his hearing and heart, and put a blindfold on his sight? So who will guide him after Allah \[has consigned him to error\]? Will you not then take admonition?

# 4497

They say, ‘There is nothing but the life of this world: we live and we die, and nothing but time destroys us.’ But they do not have any knowledge of that, and they only make conjectures.

# 4498

When Our manifest signs are recited to them, their only argument is to say, ‘Bring our fathers back \[to life\], if you are truthful.’

# 4499

Say, ‘It is Allah who gives you life, then He makes you die. Then He will gather you on the Day of Resurrection, in which there is no doubt. But most people do not know.’

# 4500

To Allah belongs the kingdom of the heavens and the earth, and when the Hour sets in, the falsifiers will be losers on that day.

# 4501

And you will see every nation fallen on its knees. Every nation will be summoned to its book: ‘Today you will be requited for what you used to do.

# 4502

This is Our book, which speaks truly against you. Indeed We used to record what you used to do.’

# 4503

As for those who have faith and do righteous deeds, their Lord will admit them into His mercy. That is the manifest success!

# 4504

But as for the faithless, \[they will be asked,\] ‘Were not My signs recited to you? But you were disdainful, and you were a guilty lot.

# 4505

When it was said, ‘‘Allah’s promise is indeed true, and there is no doubt about the Hour,’’ you said, ‘‘We do not know what the Hour is. We know nothing beyond conjectures, and we do not possess any certainty.’’ ’

# 4506

The evils of what they had done will appear to them, and they will be besieged by what they used to deride.

# 4507

And it will be said, ‘Today We will forget you, just as you forgot the encounter of this day of yours. The Fire will be your abode, and you will not have any helpers.

# 4508

That is because you took the signs of Allah in derision, and the life of the world had deceived you.’ So today, they will not be brought out of it, nor will they be asked to propitiate \[Allah\].

# 4509

So all praise belongs to Allah, the Lord of the heavens and the Lord of the earth, the Lord of all the worlds.

# 4510

To Him belongs all supremacy in the heavens and the earth, and He is the All-mighty, the All-wise.

# 4511

Ha, Meem.

# 4512

The \[gradual\] sending down of the Book is from Allah, the All-mighty, the All-wise.

# 4513

We did not create the heavens and the earth and whatever is between them except with consummate wisdom and for a specified term. Yet the faithless are disregardful of what they are warned.

# 4514

Say, ‘Tell me about those you invoke besides Allah. Show me what \[part\] of the earth have they created. Do they have any share in the heavens? Bring me a scripture \[revealed\] before this, or some vestige of \[divine\] knowledge, if you are truthful.’

# 4515

Who is more astray than him who invokes besides Allah such \[entities\] as would not respond to him until the Day of Resurrection, and who are oblivious of their invocation?

# 4516

When mankind are mustered \[on Judgement’s Day\] they will be their enemies, and they will disavow their worship.

# 4517

When Our manifest signs are recited to them, the faithless say of the truth when it comes to them: ‘This is plain magic.’

# 4518

Or they say, ‘He has fabricated it.’ Say, ‘Should I have fabricated it, you would not avail me anything against Allah. He best knows what you gossip concerning it. He suffices as a witness between me and you, and He is the All-forgiving, the All-merciful.’

# 4519

Say, ‘I am not a novelty among the apostles, nor do I know what will be done with me, or with you. I just follow whatever is revealed to me, and I am just a manifest warner.’

# 4520

Say, ‘Tell me, if it is from Allah and you disbelieve in it, and a witness from the Children of Israel has testified to its like and believed \[in it\], while you are disdainful \[of it\]?’ Indeed Allah does not guide the wrongdoing lot.

# 4521

The faithless say about the faithful, ‘Had it been \[anything\] good, they would not have taken the lead over us toward \[accepting\] it.’ And since they could not find the way to it, they will say, ‘It is an ancient lie.’

# 4522

Yet before it the Book of Moses was a guide and mercy, and this is a Book in the Arabic language, which confirms it, \[sent\] to warn the wrongdoers, and is a \[bearer of\] good news for the virtuous.

# 4523

Those who say, ‘Our Lord is Allah,’ and then remain steadfast, they will have no fear, nor will they grieve.

# 4524

They shall be the inhabitants of paradise, remaining in it \[forever\]—a reward for what they used to do.

# 4525

We have enjoined man to be kind to his parents. His mother has carried him in travail, and bore him in travail, and his gestation and weaning take thirty months. When he comes of age and reaches forty years, he says, ‘My Lord! Inspire me to give thanks for Your blessing with which You have blessed me and my parents, and that I may do righteous deeds which please You, and invest my descendants with righteousness. Indeed I have turned to you in penitence, and I am one of the Muslims.’

# 4526

Such are the ones from whom We accept the best of what they do, and overlook their misdeeds, \[who will be\] among the inhabitants of paradise—a true promise which they had been given.

# 4527

As for him who says to his parents, ‘Fie on you! Do you promise me that I shall be raised \[from the dead\] when generations have passed away before me?’ And they invoke Allah’s help \[and say\]: ‘Woe to you! Believe! Indeed Allah’s promise is true.’ But he says, ‘These are nothing but myths of the ancients.’

# 4528

Such are the ones against whom the word has become due, along with the nations of jinn and humans that have passed away before them. They were the losers.

# 4529

For everyone there are degrees \[of merit\] pertaining to what he has done: He will recompense them fully for their works, and they will not be wronged.

# 4530

The day when the faithless are exposed to the Fire, \[they will be told,\] ‘You have exhausted your good things in the life of the world and enjoyed them. So today you will be requited with a humiliating punishment for your acting arrogantly in the earth unduly, and because you used to transgress.’

# 4531

And mention \[Hud\] the brother of ‘Ad, when he warned his people at Ahqaf—and warners have passed away before and after him—saying, ‘Do not worship anyone but Allah. Indeed I fear for you the punishment of a tremendous day.’

# 4532

They said, ‘Have you come to turn us away from our gods? Then bring us what you threaten us with, if you are truthful.

# 4533

He said, ‘The knowledge \[of when that threat will be carried out\] is with Allah alone. I communicate to you what I have been sent with. But I see that you are a senseless lot.’

# 4534

When they saw it as a cloud advancing toward their valleys, they said, ‘This cloud brings us rain.’ ‘No, it is what you sought to hasten: a hurricane carrying a painful punishment,

# 4535

destroying everything by its Lord’s command.’ So they became such that nothing could be seen except their dwellings. Thus do We requite the guilty lot.

# 4536

Certainly We had granted them power in respects that We have not granted you, and We had vested them with hearing and sight and hearts. But neither their hearing availed them in any way nor did their sight, nor their hearts when they used to impugn the signs of Allah. So they were besieged by what they used to deride.

# 4537

Certainly We have destroyed the towns that were around you, and We have variously paraphrased the signs so that they may come back.

# 4538

So why did not those \[fake deities\] help them whom they had taken as gods besides Allah, as a means of nearness \[to Him\]? Indeed, they forsook them; that was their lie and what they used to fabricate.

# 4539

When We dispatched toward you a team of jinn listening to the Quran, when they were in its presence, they said, ‘Be silent!’ When it was finished, they went back to their people as warners.

# 4540

They said, ‘O our people! Indeed, we have heard a Book, which has been sent down after Moses, confirming what was before it. It guides to the truth and to a straight path.

# 4541

O our people! Respond to Allah’s summoner and have faith in Him. He will forgive you some of your sins and shelter you from a painful punishment.’

# 4542

Those who do not respond to Allah’s summoner cannot frustrate \[Allah\] on the earth, and they will not find any protectors besides Him. They are in manifest error.

# 4543

Do they not see that Allah, who created the heavens and the earth and \[who\] was not exhausted by their creation, is able to revive the dead? Yes, indeed He has power over all things.

# 4544

The day when the faithless are exposed to the Fire, \[He will say,\] ‘Is this not a fact?’ They will say, ‘Yes, by our Lord!’ He will say, ‘So taste the punishment because of what you used to disbelieve.’

# 4545

So be patient just as the resolute among the apostles were patient, and do not seek to hasten \[the punishment\] for them. The day when they see what they are promised, \[it will be\] as though they had remained \[in the world\] only an hour of a day. This is a proclamation. So shall anyone be destroyed except the transgressing lot?

# 4546

Those who are \[themselves\] faithless and bar \[others\] from the way of Allah—He has rendered their works fruitless.

# 4547

But those who have faith and do righteous deeds and believe in what has been sent down to Muhammad—and it is the truth from their Lord—He shall absolve them of their misdeeds and set right their affairs.

# 4548

That is because the faithless follow falsehood, and the faithful follow the truth from their Lord. That is how Allah draws comparisons for mankind.

# 4549

When you meet the faithless in battle, strike their necks. When you have thoroughly decimated them, bind the captives firmly. Thereafter either oblige them \[by setting them free\] or take ransom, until the war lays down its burdens. That \[is Allah’s ordinance\]. Had Allah wished He could have taken vengeance on them, but that He may test some of you by means of others. As for those who were slain in the way of Allah, He will not let their works go fruitless.

# 4550

He will guide them and set right their affairs,

# 4551

and admit them into paradise, with which He has acquainted them.

# 4552

O you who have faith! If you help Allah, He will help you and make your feet steady.

# 4553

As for the faithless, their lot will be to fall \[into ruin\], and He will render their works fruitless.

# 4554

That is because they loathed what Allah has sent down, so He made their works fail.

# 4555

Have they not travelled through the land so that they may observe how was the fate of those who were before them? Allah destroyed them, and a similar \[fate\] awaits these faithless.

# 4556

That is because Allah is the protector of the faithful, and because the faithless have no protector.

# 4557

Indeed Allah will admit those who have faith and do righteous deeds into gardens with streams running in them. As for the faithless, they enjoy and eat like the cattle do, and the Fire will be their \[final\] abode.

# 4558

How many a town We have destroyed which was more powerful than your town which expelled you, and they had no helper.

# 4559

Is he who stands on a manifest proof from his Lord like those to whom the evil of their conduct is made to seem decorous and who follow their desires?

# 4560

A description of the paradise promised to the Godwary: therein are streams of unstaling water and streams of milk unchanging in flavour, and streams of wine delicious to the drinkers, and streams of purified honey; there will be every kind of fruit in it for them, and forgiveness from their Lord. \[Are such ones\] like those who abide in the Fire and are given to drink boiling water which cuts up their bowels?

# 4561

There are some among them who prick up their ears at you. But when they go out from your presence, they say to those who have been given knowledge, ‘What did he say just now?’ They are the ones on whose hearts Allah has set a seal, and they follow their own desires.

# 4562

As for those who are \[rightly\] guided, He enhances their guidance and invests them with their Godwariness.

# 4563

Do they await anything except that the Hour should overtake them suddenly? Its portents have already come. When it overtakes them of what avail will the admonitions they were given?

# 4564

Know that there is no god except Allah, and plead \[to Allah\] for forgiveness of your sin and for the faithful, men and women. Allah knows your itinerary and your \[final\] abode.

# 4565

The faithful say, ‘If only a surah were sent down!’ But when a conclusive surah is sent down and war is mentioned in it, you see those in whose hearts is a sickness looking upon you with the look of someone fainting at death. So woe to them!

# 4566

Obedience and upright speech.... So when the matter has been resolved upon \[concerning going to war\], if they remain true to Allah that will surely be better for them.

# 4567

May it not be that if you were to wield authority you would cause corruption in the land and ill-treat your blood relations?

# 4568

They are the ones whom Allah has cursed, so He made them deaf, and blinded their sight.

# 4569

Do they not contemplate the Quran, or are there locks on the hearts?

# 4570

Indeed those who turned their backs after the guidance had become clear to them, it was Satan who had seduced them, and he had given them \[far-flung\] hopes.

# 4571

That is because they said to those who loathed what Allah had sent down: ‘We shall obey you in some matters,’ and Allah knows their secret dealings.

# 4572

But how will it be \[with them\] when the angels take them away, striking their faces and their backs?!

# 4573

That, because they pursued what displeased Allah, and loathed His pleasure. So He has made their works fail.

# 4574

Do those in whose hearts is a sickness suppose that Allah will not expose their spite?

# 4575

If We wish, We will show them to you so that you recognize them by their mark. Yet you will recognize them by their tone of speech, and Allah knows your deeds.

# 4576

We will surely test you until We ascertain those of you who wage jihad and those who are steadfast, and We shall appraise your record.

# 4577

Indeed those who are faithless and bar from the way of Allah and defy the Apostle after guidance has become clear to them, they will not hurt Allah in the least, and He shall make their works fail.

# 4578

O you who have faith! Obey Allah and obey the Apostle, and do not render your works void.

# 4579

Indeed those who are faithless and bar from the way of Allah and then die faithless, Allah will never forgive them.

# 4580

So do not slacken and \[do not\] call for peace when you have the upper hand and Allah is with you, and He will not stint \[the reward of\] your works.

# 4581

The life of the world is just play and diversion, but if you are faithful and Godwary, He will give you your rewards, and will not ask your wealth \[in return\] from you.

# 4582

Should He ask it from you and press you, you will be stingy, and He will expose your spite.

# 4583

Ah! There you are, being invited to spend in the way of Allah; yet among you there are those who are stingy; and whoever is stingy is stingy only to himself. Allah is the All-sufficient, and you are all-needy, and if you turn away He will replace you with another people, and they will not be like you.

# 4584

Indeed We have inaugurated for you a clear victory,

# 4585

that Allah may forgive you what is past of your sin and what is to come, and that He may perfect His blessing upon you and guide you on a straight path,

# 4586

and Allah will help you with a mighty help.

# 4587

It is He who sent down composure into the hearts of the faithful that they might enhance in their faith. To Allah belong the hosts of the heavens and the earth, and Allah is all-knowing, all-wise.

# 4588

That He may admit the faithful, men and women, into gardens with streams running in them, to remain in them \[forever\], and that He may absolve them of their misdeeds. That is a great success with Allah.

# 4589

That He may punish the hypocrites, men and women, and the polytheists, men and women, who entertain a bad opinion of Allah. For them shall be an adverse turn of fortune: Allah is wrathful with them and He has cursed them, and prepared hell for them and it is an evil destination.

# 4590

To Allah belong the hosts of the heavens and the earth, and Allah is all-mighty, all-wise.

# 4591

Indeed We have sent you as a witness, and as a bearer of good news and warner,

# 4592

that you may have faith in Allah and His Apostle, and that you may support him and revere him, and that you may glorify Him morning and evening.

# 4593

Indeed those who swear allegiance to you, swear allegiance only to Allah: the hand of Allah is above their hands. Then whosoever breaks his oath, breaks it only to his own detriment, and whoever fulfills the covenant he has made with Allah, He will give him a great reward.

# 4594

The Bedouins who had stayed back \[from joining the Prophet in his ‘umrah journey to Makkah\] will tell you, ‘Our possessions and families kept us occupied. So plead \[to Allah\] for our forgiveness!’ They will say with their tongues what is not in their hearts. Say, ‘Whether He desires to cause you harm or desires to bring you benefit, who can be of any avail to you against Allah\[’s will\]? Indeed Allah is well aware of what you do.’

# 4595

Rather, you thought that the Apostle and the faithful will not ever return to their folks, and that was made to seem decorous to your hearts; you entertained evil thoughts, and you were a ruined lot.

# 4596

Those who have no faith in Allah and His Apostle \[should know that\] We have prepared a blaze for the faithless.

# 4597

To Allah belongs the kingdom of the heavens and the earth: He forgives whomever He wishes, and punishes whomever He wishes, and Allah is all-forgiving, all-merciful.

# 4598

\[In the near future\] when you will set out to capture booty, those who stayed behind \[in this journey\] will say, : ‘Let us follow you.’ They desire to change the word of Allah. Say, ‘You will never follow us! Allah has said thus beforehand.’ Then they will say, ‘You are envious of us.’ Indeed, they do not understand but a little.

# 4599

Say to the Bedouins who stayed behind, ‘\[Later on\] you will be called against a people of a great might: they will either embrace Islam, or you will fight them. So if you obey, Allah will give you a good reward; but if you turn away like you turned away before, He will punish you with a painful punishment.’

# 4600

There is no blame on the blind, nor is there any blame on the lame, nor is there blame on the sick \[if they are unable to go out with the troops to face the enemies\]; and whoever obeys Allah and His Apostle, He will admit him into gardens with streams running in them, and whoever refuses to comply, He will punish him with a painful punishment.

# 4601

Allah was certainly pleased with the faithful when they swore allegiance to you under the tree. He knew what was in their hearts, so He sent down composure on them, and requited them with a victory near at hand

# 4602

and abundant spoils that they will capture, and Allah is all-mighty, all-wise.

# 4603

Allah has promised you abundant spoils, which you will capture. He has expedited this one for you, and withheld men’s hands from you, so that it may be a sign for the faithful, and that He may guide you to a straight path.

# 4604

And other \[spoils as well\] which you have not yet captured: Allah has comprehended them, and Allah has power over all things.

# 4605

If the faithless fight you, they will turn their backs \[to flee\]. Then they will not find any protector or helper.

# 4606

\[It is\] Allah’s precedent that has passed before, and you will never find any change in Allah’s precedent.

# 4607

It is He who withheld their hands from you, and your hands from them, in the valley of Makkah, after He had given you victory over them, and Allah sees best what you do.

# 4608

They are the ones who disbelieved and barred you from the Sacred Mosque, and kept the offering from reaching its destination. And were it not for \[certain\] faithful men and faithful women, whom you did not know—lest you should trample them, and thus the blame for \[killing\] them should fall on you unawares; \[He held you back\] so that Allah may admit into His mercy whomever He wishes. Had they been separate, We would have surely punished the faithless among them with a painful punishment.

# 4609

When the faithless nourished bigotry in their hearts, the bigotry of pagan ignorance, Allah sent down His composure upon His Apostle and the faithful, and made them abide by the word of Godwariness, for they were the worthiest of it and deserved it, and Allah has knowledge of all things.

# 4610

Certainly Allah has fulfilled His Apostle’s vision in all truth: You will surely enter the Sacred Mosque, God willing, in safety and without any fear, with your heads shaven or hair cropped. So He knew what you did not know, and He assigned \[you\] besides that a victory near at hand.

# 4611

It is He who has sent His Apostle with guidance and the true religion, that He may make it prevail over all religions, and Allah suffices as witness.

# 4612

Muhammad, the Apostle of Allah, and those who are with him are hard against the faithless and merciful amongst themselves. You see them bowing and prostrating \[in worship\], seeking Allah’s grace, and \[His\] pleasure. Their mark is \[visible\] on their faces, from the effect of prostration. Such is their description in the Torah and their description in the Evangel. Like a tillage that sends out its shoots and builds them up, and they grow stout and settle on their stalks, impressing the sowers, so that He may enrage the faithless by them. Allah has promised those of them who have faith and do righteous deeds forgiveness and a great reward.

# 4613

O you who have faith! Do not venture ahead of Allah and His Apostle, and be wary of Allah. Indeed Allah is all-hearing, all-knowing.

# 4614

O you who have faith! Do not raise your voices above the voice of the Prophet, and do not speak aloud to him like you shout to one another, lest your works should fail without your being aware.

# 4615

Indeed those who lower their voices in the presence of the Apostle of Allah—they are the ones whose hearts Allah has tested for Godwariness. For them will be forgiveness and a great reward.

# 4616

Indeed those who call you from behind the apartments, most of them do not use their reason.

# 4617

Had they been patient until you came out for them, it would have been better for them, and Allah is all-forgiving, all-merciful.

# 4618

O you who have faith! If a vicious character brings you some news, verify it, lest you should visit \[harm\] on some people out of ignorance, and then become regretful for what you have done.

# 4619

Know that the Apostle of Allah is among you. Should he comply with you in many matters, you would surely suffer. But Allah has endeared faith to you and made it appealing in your hearts, and He has made hateful to you faithlessness, transgression and disobedience. It is such who are the right-minded—

# 4620

a grace and blessing from Allah, and Allah is all-knowing, all-wise.

# 4621

If two groups of the faithful fight one another, make peace between them. But if one party of them aggresses against the other, fight the one which aggresses until it returns to Allah’s ordinance. Then, if it returns, make peace between them fairly, and do justice. Indeed Allah loves the just.

# 4622

The faithful are indeed brothers. Therefore, make peace between your brothers and be wary of Allah, so that you may receive \[His\] mercy.

# 4623

O you who have faith! Let not any people ridicule another people: it may be that they are better than they are; nor let women \[ridicule\] women: it may be that they are better than they are. And do not defame one another, nor insult one another by \[calling\] nicknames. How evil are profane names subsequent to faith! As for those who are not penitent \[of their past conduct\]—such are the wrongdoers.

# 4624

O you who have faith! Avoid much suspicion; indeed some suspicions are sins. And do not spy on one another or backbite. Will any of you love to eat the flesh of his dead brother? You would hate it. Be wary of Allah; indeed Allah is all-clement, all-merciful.

# 4625

O mankind! Indeed, We created you from a male and a female, and made you nations and tribes that you may identify yourselves with one another. Indeed the noblest of you in the sight of Allah is the most Godwary among you. Indeed Allah is all-knowing, all-aware.

# 4626

The Bedouins say, ‘We have faith.’ Say, ‘You do not have faith yet; rather, say, ‘‘We have embraced Islam,’’ for faith has not yet entered into your hearts. Yet if you obey Allah and His Apostle, He will not stint anything of \[the reward of\] your works. Indeed Allah is all-forgiving, all-merciful.’

# 4627

The faithful are only those who have attained faith in Allah and His Apostle and then have never doubted, and who wage jihad with their possessions and their persons in the way of Allah. It is they who are the truthful.

# 4628

Say, ‘Will you inform Allah about your faith while Allah knows whatever there is in the heavens and whatever there is in the earth, and Allah has knowledge of all things?’

# 4629

They count it as a favour to you that they have embraced Islam. Say, ‘Do not count your embracing of Islam as a favour to me. No, it is Allah who has done you a favour in that He has guided you to faith, if you are truthful \[in your claim\].

# 4630

Indeed Allah knows the Unseen of the heavens and the earth, and Allah watches what you do.’

# 4631

Qaf. By the glorious Quran.

# 4632

Indeed they consider it odd that a warner from among themselves should have come to them. So the faithless say, ‘This is an odd thing.’

# 4633

‘What! When we are dead and have become dust, \[shall we be raised again\]? That is a far-fetched return!’

# 4634

We know what the earth diminishes from them, and with Us is a preserving Book.

# 4635

Indeed, they denied the truth when it came to them; so they are now in a perplexed state of affairs.

# 4636

Have they not, then, observed the heaven above them, how We have built it and adorned it, and that there are no cracks in it?

# 4637

And We spread out the earth, and cast in it firm mountains, and caused every delightful kind \[of vegetation\] to grow in it.

# 4638

\[In this there is\] an insight and admonition for every penitent servant.

# 4639

We send down from the sky salubrious water, with which We grow gardens and the grain which is harvested,

# 4640

and tall date palms with regularly set spathes,

# 4641

as a provision for Our servants, and with it We revive a dead country. Likewise will be the rising \[from the dead\].

# 4642

The people of Noah denied before them, and \[so did\] the people of Rass and Thamud,

# 4643

and ‘Ad, Pharaoh, and the brethren of Lot,

# 4644

and the inhabitants of Aykah and the people of Tubbac. Each \[of them\] impugned the apostles, and so My threat became due \[against them\].

# 4645

Have We been exhausted by the first creation? No, they are in doubt about a new creation.

# 4646

Certainly We have created man and We know to what his soul tempts him, and We are nearer to him than his jugular vein.

# 4647

When the twin recorders record \[his deeds\], seated on the right hand and on the left:

# 4648

he says no word but that there is a ready observer beside him.

# 4649

The throes of death bring the truth: ‘This is what you used to shun!’

# 4650

And the Trumpet will be blown: ‘This is the promised day.’

# 4651

Every soul will come accompanied by \[two angels\], a driver, and a witness:

# 4652

\[he will be told\] ‘You were certainly oblivious of this. We have removed your veil from you, and so today your eyesight is acute.’

# 4653

Then his companion \[angel\] will say, ‘This is what is ready with me \[of his record of deeds\].’

# 4654

\[The two angels accompany him will be told,\] ‘Cast every obdurate ingrate into hell,

# 4655

\[every\] hinderer of good, transgressor, and skeptic,

# 4656

who had set up another god along with Allah and cast him into the severe punishment.’

# 4657

His companion \[devil\] will say, ‘Our Lord! I did not incite him to rebel \[against You\], but he was \[himself\] in extreme error.’

# 4658

He will say, ‘Do not wrangle in My presence, for I had already warned you in advance.

# 4659

The word \[of judgement\] is unalterable with Me, and I am not tyrannical to My servants.’

# 4660

The day when We shall say to hell, ‘Are you full?’ It will say, ‘Is there any more?’

# 4661

And paradise will be brought near for the Godwary, it will not be distant \[any more\]:

# 4662

‘This is what you were promised. \[It is\] for every penitent and dutiful \[servant\]

# 4663

who fears the All-beneficent in secret and comes with a penitent heart.

# 4664

Enter it in peace! This is the day of immortality.’

# 4665

There they will have whatever they wish, and with Us there is yet more.

# 4666

How many generations We have destroyed before them, who were stronger than these, insomuch that they ransacked the towns?! So, is there any escape \[from Allah’s punishment\]?

# 4667

There is indeed an admonition in that for one who has a heart, or gives ear, being attentive.

# 4668

Certainly We created the heavens and the earth, and whatever is between them, in six days, and any fatigue did not touch Us.

# 4669

So be patient at what they say, and celebrate the praise of your Lord before the rising of the sun and before the sunset,

# 4670

and glorify Him through part of the night and after the prostrations.

# 4671

And be on the alert for the day when the caller calls from a close quarter,

# 4672

the day when they hear the Cry in all truth. That is the day of rising \[from the dead\].

# 4673

Indeed it is We who give life and bring death, and toward Us is the \[final\] destination.

# 4674

The day the earth is split open for \[disentombing\] them, \[they will come out\] hastening. That mustering is easy for Us \[to carry out\].

# 4675

We know well what they say, and you are not there to compel them. So admonish by the Quran those who fear My threat.

# 4676

By the scattering \[winds\] that scatter \[the clouds\];

# 4677

by the \[rain\] bearing \[clouds\] laden \[with water\];

# 4678

by \[the ships\] which move gently \[on the sea\];

# 4679

by \[the angels\] who dispense \[livelihood\] by \[His\] command:

# 4680

indeed what you are promised is true,

# 4681

and indeed the retribution will surely come to pass!

# 4682

By the sky full of adornment \[with stars\],

# 4683

indeed you are of different opinions!

# 4684

He who has been turned away \[from the truth\] is turned away from it.

# 4685

Perish the liars,

# 4686

who are heedless in a stupor!

# 4687

They ask, ‘When will be the Day of Retribution?’

# 4688

It is the day when they will be tormented in the Fire,

# 4689

\[and will be told\]: ‘Taste your torment. This is what you used to hasten.’

# 4690

Indeed the Godwary will be amid gardens and springs,

# 4691

receiving what their Lord has given them, for they had been virtuous aforetime.

# 4692

They used to sleep a little during the night,

# 4693

and at dawns they would plead for forgiveness,

# 4694

and there was a share in their wealth for the beggar and the deprived.

# 4695

In the earth are signs for those who have conviction,

# 4696

and in your souls \[as well\]. Will you not then perceive?

# 4697

And in the sky is your provision and what you are promised.

# 4698

By the Lord of the sky and the earth, it is indeed the truth, just as \[it is a fact that\] you speak.

# 4699

Did you receive the story of Abraham’s honoured guests?

# 4700

When they entered into his presence, they said, ‘Peace!’ ‘Peace!’ He answered, ‘\[You are\] an unfamiliar folk.’

# 4701

Then he retired to his family and brought a fat \[roasted\] calf,

# 4702

and put it near them. He said, ‘Will you not eat?’

# 4703

Then he felt a fear of them. They said, ‘Do not be afraid!’ and they gave him the good news of a wise son.

# 4704

Then his wife came forward crying \[with joy\]. She beat her face, and said, ‘A barren old woman!’

# 4705

They said, ‘So has your Lord said. Indeed He is the All-wise, the All-knowing.’

# 4706

He said, ‘O messengers, what is now your errand?’

# 4707

They said, ‘We have been sent toward a guilty people,

# 4708

that We may rain upon them stones of clay,

# 4709

sent for the transgressors from your Lord.

# 4710

So We picked out those who were in it of the faithful,

# 4711

but We did not find there other than one house of Muslims,

# 4712

and We have left therein a sign for those who fear a painful punishment.’

# 4713

And in Moses \[too there is a sign\] when We sent him to Pharaoh with a manifest authority.

# 4714

But he turned away assured of his might, and said, ‘A magician or a crazy man!’

# 4715

So We seized him and his hosts, and cast them into the sea, while he was blameworthy.

# 4716

And in ‘Ad when We unleashed upon them a barren wind.

# 4717

It left nothing that it came upon without making it like decayed bones.

# 4718

And in Thamud, when they were told, ‘Enjoy for a while.’

# 4719

Then they defied the command of their Lord; so the thunderbolt seized them as they looked on.

# 4720

So they were neither able to rise up, nor to come to one another’s aid.

# 4721

And the people of Noah aforetime. Indeed, they were a transgressing lot.

# 4722

We have built the heaven with might, and indeed it is We who are its expanders.

# 4723

And We have spread out the earth, so how excellent spreaders We have been!

# 4724

In all things We have created pairs so that you may take admonition.

# 4725

‘So flee toward Allah. Indeed, I am from Him a manifest warner to you.

# 4726

Do not set up another god besides Allah. Indeed I am from Him a manifest warner to you.’

# 4727

So it was that there did not come any apostle to those who were before them but they said, ‘A magician,’ or ‘A crazy man!’

# 4728

Did they enjoin this upon one another?! Rather, they were a rebellious lot.

# 4729

So turn away from them, as you will not be blameworthy.

# 4730

And admonish, for admonition indeed benefits the faithful.

# 4731

I did not create the jinn and the humans except that they may worship Me.

# 4732

I desire no provision from them, nor do I desire that they should feed Me.

# 4733

Indeed it is Allah who is the All-provider, Powerful and All-strong.

# 4734

Indeed the lot of those who do wrong \[now\] will be like the lot of their \[earlier\] counterparts. So let them not ask Me to hasten on \[that fate\].

# 4735

Woe to the faithless for the day they are promised!

# 4736

By the Mount \[Sinai\],

# 4737

by the Book inscribed

# 4738

on an unrolled parchment;

# 4739

by the House greatly frequented;

# 4740

by the vault raised high,

# 4741

by the surging sea:

# 4742

indeed your Lord’s punishment will surely befall.

# 4743

There is none who can avert it.

# 4744

On the day when the sky whirls violently,

# 4745

and the mountains move with an awful motion:

# 4746

woe to the deniers on that day

# 4747

—those who play around in vain talk,

# 4748

the day when they will be shoved forcibly toward the fire of hell, \[and told:\]

# 4749

‘This is the Fire which you used to deny!

# 4750

Is this, then, \[also\] magic, or is it you who do not perceive?

# 4751

Enter it, and it will be the same for you whether you are patient or impatient. You are only being requited for what you used to do.’

# 4752

Indeed the Godwary will be amid gardens and bliss,

# 4753

rejoicing because of what their Lord has given them, and that their Lord has saved them from the punishment of hell.

# 4754

\[They will be told:\] ‘Enjoy your food and drink, \[as a reward\] for what you used to do.’

# 4755

They will be reclining on arrayed couches, and We will wed them to big-eyed houris.

# 4756

The faithful and their descendants who followed them in faith—We will make their descendants join them, and We will not stint anything from \[the reward of\] their deeds. Every person is hostage to what he has earned.

# 4757

We will provide them with fruits and meat, such as they desire.

# 4758

There they will pass from hand to hand a cup wherein there will be neither any vain talk nor sinful speech.

# 4759

They will be waited upon by their youths, as if they were guarded pearls.

# 4760

They will turn to one another, questioning each other.

# 4761

They will say, ‘Indeed, aforetime, we used to be apprehensive about our families.

# 4762

But Allah showed us favour and He saved us from the punishment of the \[infernal\] miasma.

# 4763

We used to supplicate Him aforetime. Indeed He is the All-benign, the All-merciful.’

# 4764

So admonish. By your Lord’s blessing, you are not a soothsayer, nor mad.

# 4765

Do they say, ‘\[He is\] a poet, for whom we await a fatal accident’?

# 4766

Say, ‘Wait! I too am waiting along with you.’

# 4767

Is it their intellect which prompts them to \[say\] this, or are they a rebellious lot?

# 4768

Do they say, ‘He has improvised it \[himself\]?’ Rather, they have no faith!

# 4769

Let them bring a discourse like it, if they are truthful.

# 4770

Were they created from nothing? Or are they \[their own\] creators?

# 4771

Did they create the heavens and the earth? Rather, they have no certainty!

# 4772

Do they possess the treasuries of your Lord? Or do they control \[them\]?

# 4773

Do they have a ladder \[leading up to heaven\] whereby they eavesdrop? If so, let their eavesdropper produce a manifest authority.

# 4774

Does He have daughters while you have sons?

# 4775

Do you ask them for a reward, so that they are \[wary of\] being weighed down with debt?

# 4776

Do they have \[access to\] the Unseen, which they write down?

# 4777

Do they seek to outmaneuver \[Allah\]? But it is the faithless who are the outmaneuvered ones!

# 4778

Do they have any god other than Allah? Clear is Allah of any partners that they may ascribe \[to Him\]!

# 4779

Were they to see a fragment falling from the sky, they would say, ‘A cumulous cloud.’

# 4780

So leave them until they encounter the day when they will be thunderstruck,

# 4781

the day when their guile will not avail them in any way, nor will they be helped.

# 4782

Indeed there is a punishment besides that for those who do wrong, but most of them do not know.

# 4783

So submit patiently to the judgement of your Lord, for indeed you fare before Our eyes. And celebrate the praise of your Lord when you rise \[at dawn\],

# 4784

and also glorify Him during the night and at the receding of the stars.

# 4785

By the star when it sets:

# 4786

your companion has neither gone astray, nor amiss.

# 4787

Nor does he speak out of \[his own\] desire:

# 4788

it is just a revelation that is revealed \[to him\],

# 4789

taught him by one of great powers,

# 4790

possessed of sound judgement. He settled,

# 4791

while he was on the highest horizon.

# 4792

Then he drew nearer and nearer

# 4793

until he was within two bows’ length or even nearer,

# 4794

whereat He revealed to His servant whatever He revealed.

# 4795

The heart did not deny what it saw.

# 4796

Will you then dispute with him about what he saw?!

# 4797

Certainly he saw it yet another time,

# 4798

by the Lote Tree of the Ultimate Boundary,

# 4799

near which is the Garden of the Abode,

# 4800

when there covered the Lote Tree what covered it.

# 4801

His gaze did not swerve, nor did it overstep the bounds.

# 4802

Certainly he saw some of the greatest signs of his Lord.

# 4803

Have you considered Lat and ‘Uzza?

# 4804

and Manat, the third one?

# 4805

Are you to have males and He females?

# 4806

That, then, will be an unfair division!

# 4807

These are but names, which you have coined—you and your fathers—for which Allah has not sent down any authority. They follow nothing but conjectures and the desires of the \[lower\] soul, while there has already come to them the guidance from their Lord.

# 4808

Shall man have whatever he yearns for?

# 4809

Yet to Allah belong this world and the Hereafter.

# 4810

How many an angel there is in the heavens whose intercession is of not any avail, except after Allah permits whomever He wishes and approves of!

# 4811

Indeed those who do not believe in the Hereafter give female names to the angels.

# 4812

They do not have any knowledge of that. They follow nothing but conjectures, and conjecture is no substitute for the truth.

# 4813

So avoid those who turn away from Our remembrance and desire nothing but the life of the world.

# 4814

That is the ultimate reach of their knowledge. Indeed your Lord knows best those who stray from His way, and He knows best those who are \[rightly\] guided.

# 4815

To Allah belongs whatever is in the heavens and whatever is in the earth, that He may requite those who do evil for what they have done, and reward those who do good with the best \[of rewards\].

# 4816

Those who avoid major sins and indecencies, apart from \[minor and occasional\] lapses. Indeed your Lord is expansive in \[His\] forgiveness. He knows you best since \[the time\] He produced you from the earth and since you were foetuses in the bellies of your mothers. So do not flaunt your piety: He knows best those who are Godwary.

# 4817

Did you see him who turned away,

# 4818

gave a little and held off?

# 4819

Does he have the knowledge of the Unseen so that he sees?

# 4820

Has he not been informed of what is in the scriptures of Moses,

# 4821

and of Abraham, who fulfilled \[his summons\]:

# 4822

that no bearer shall bear another’s burden,

# 4823

that nothing belongs to man except what he strives for,

# 4824

and that he will soon be shown his endeavour,

# 4825

then he will be rewarded for it with the fullest reward;

# 4826

that the terminus is toward your Lord,

# 4827

that it is He who makes \[men\] laugh, and weep,

# 4828

that it is He who brings death and gives life,

# 4829

that it is He who created the mates, the male and the female,

# 4830

from a drop of \[seminal\] fluid when emitted;

# 4831

that with Him lies the second genesis,

# 4832

that it is He who enriches and grants possessions,

# 4833

that it is He who is the Lord of Sirius;

# 4834

that it is He who destroyed the former ‘Ad,

# 4835

and Thamud, sparing none \[of them\];

# 4836

and the people of Noah before that; indeed they were more unjust and rebellious;

# 4837

and He overthrew the town that was overturned,

# 4838

covering it with what covered it.

# 4839

Then which of the bounties of your Lord will you dispute?

# 4840

This is a warner, \[in the tradition\] of the warners of old.

# 4841

The Imminent \[Hour\] is near at hand.

# 4842

There is none who may unveil it besides Allah.

# 4843

Will you then wonder at this discourse,

# 4844

and laugh and not weep,

# 4845

while you remain heedless?!

# 4846

So prostrate yourselves to Allah and worship Him!

# 4847

The Hour has drawn near and the moon is split.

# 4848

If they see a sign, they turn away, and say, ‘An incessant magic!’

# 4849

They denied and followed their own desires, and every matter has a setting \[appropriate to it\].

# 4850

There have already come to them reports containing admonishment,

# 4851

\[and representing\] far-reaching wisdom; but warnings are of no avail!

# 4852

So turn away from them! The day when the Caller calls to a dire thing,

# 4853

they will emerge from the graves as if they were scattered locusts with a humbled look \[in their eyes\],

# 4854

scrambling toward the summoner. The faithless will say, ‘This is a hard day!’

# 4855

The people of Noah impugned before them. So they impugned Our servant and said, ‘A crazy man,’ and he was reviled.

# 4856

Thereat he invoked his Lord, \[saying,\] ‘I have been overcome, so help \[me\].’

# 4857

Then We opened the gates of the sky with pouring waters,

# 4858

and We made the earth burst forth with springs, and the waters met for a preordained purpose.

# 4859

We bore him on a vessel made of planks and nails,

# 4860

which sailed \[over the flood waters\] in Our sight, as a retribution for him who was met with disbelief.

# 4861

Certainly We have left it as a sign; so is there anyone who will be admonished?

# 4862

So how were My punishment and warnings?

# 4863

Certainly We have made the Quran simple for the sake of admonishment. So is there anyone who will be admonished?

# 4864

\[The people of\] ‘Ad impugned \[their apostle\]. So how were My punishment and warnings?

# 4865

Indeed We unleashed upon them an icy gale on an incessantly ill-fated day,

# 4866

knocking down people as if they were trunks of uprooted palm trees.

# 4867

So how were My punishment and warnings?!

# 4868

Certainly We have made the Quran simple for the sake of admonishment. So is there anyone who will be admonished?

# 4869

\[The people of\] Thamud denied the warnings,

# 4870

and they said, ‘Are we to follow a lone human from ourselves?! Indeed then we would be in error and madness.’

# 4871

‘Has the Reminder been cast upon him from among us? No, he is a self-conceited liar.’

# 4872

‘Tomorrow they will know who is a self-conceited liar.

# 4873

We are sending the She-camel as a trial for them; so watch them and be steadfast.

# 4874

Inform them that the water is to be shared between them; each of them showing up at his turn.’

# 4875

But they called their companion, and he took \[a knife\] and hamstrung \[her\].

# 4876

So how were My punishment and My warnings?!

# 4877

We sent against them a single Cry, and they became like the dry sticks of a corral builder.

# 4878

Certainly We have made the Quran simple for the sake of admonishment. So is there anyone who will be admonished?

# 4879

And the people of Lot denied the warnings.

# 4880

We unleashed upon them a rain of stones, excepting the family of Lot, whom We delivered at dawn

# 4881

as a blessing from Us. Thus do We reward those who give thanks.

# 4882

He had already warned them of Our punishment, but they disputed the warnings.

# 4883

They even solicited of him his guests, whereat We blotted out their eyes, \[saying,\] ‘Taste My punishment and My warnings!’

# 4884

Early at dawn there visited them an abiding punishment:

# 4885

‘Taste My punishment and warnings!’

# 4886

Certainly We have made the Quran simple for the sake of admonishment. So is there anyone who will be admonished?

# 4887

Certainly the warnings did come to Pharaoh’s clan

# 4888

who denied all of Our signs. So We seized them with the seizing of One \[who is\] all-mighty, Omnipotent.

# 4889

Are your faithless better than those? Have you \[been granted\] \[some sort of\] immunity in the scriptures?

# 4890

Do they say, ‘We are a confederate league’?

# 4891

The league will be routed and turn its back \[to flee\].

# 4892

Indeed, the Hour is their tryst; and the Hour will be most calamitous and bitter.

# 4893

Indeed the guilty are steeped in error and madness.

# 4894

The day when they are dragged on their faces into the Fire, \[it will be said to them,\] ‘Taste the touch of hell!’

# 4895

Indeed We have created everything in a measure,

# 4896

and Our command is but a single \[word\], like the twinkling of an eye.

# 4897

Certainly We have destroyed your likes. So is there anyone who will be admonished?

# 4898

Everything they have done is in the books,

# 4899

and everything big and small is committed to writing.

# 4900

Indeed the Godwary will be amid gardens and streams,

# 4901

in the abode of truthfulness with an omnipotent King.

# 4902

The All-beneficent

# 4903

has taught the Quran.

# 4904

He created man,

# 4905

\[and\] taught him articulate speech.

# 4906

The sun and the moon are \[disposed\] calculatedly,

# 4907

and the herb and the tree prostrate \[to Allah\].

# 4908

He raised the heaven high and set up the balance,

# 4909

declaring, ‘Do not infringe the balance!

# 4910

Maintain the weights with justice, and do not shorten the balance!’

# 4911

And the earth—He laid it out for mankind.

# 4912

In it are fruits and date-palms with sheaths,

# 4913

grain with husk, and fragrant herbs.

# 4914

So which of your Lord’s bounties will you both deny?

# 4915

He created man out of dry clay, like the potter’s,

# 4916

and created the jinn out of a flame of a fire.

# 4917

So which of your Lord’s bounties will you both deny?

# 4918

Lord of the two easts, and Lord of the two wests!

# 4919

So which of your Lord’s bounties will you both deny?

# 4920

He merged the two seas, meeting each other.

# 4921

There is a barrier between them, which they do not overstep.

# 4922

So which of your Lord’s bounties will you both deny?

# 4923

From them emerge the pearl and the coral.

# 4924

So which of your Lord’s bounties will you both deny?

# 4925

His are the sailing ships on the sea \[appearing\] like landmarks.

# 4926

So which of your Lord’s bounties will you both deny?

# 4927

Everyone on it is ephemeral,

# 4928

yet lasting is the majestic and munificent Face of your Lord.

# 4929

So which of your Lord’s bounties will you both deny?

# 4930

Everyone in the heavens and the earth asks Him. Every day He is engaged in some work.

# 4931

So which of your Lord’s bounties will you both deny?

# 4932

Soon We shall make Ourselves unoccupied for you, O you notable two!

# 4933

So which of your Lord’s bounties will you both deny?

# 4934

O company of jinn and humans! If you can pass through the confines of the heavens and the earth, then do pass through. But you will not pass through except by an authority \[from Allah\].

# 4935

So which of your Lord’s bounties will you both deny?

# 4936

There will be unleashed upon you a flash of fire and a smoke; then you will not be able to help one another.

# 4937

So which of your Lord’s bounties will you both deny?

# 4938

When the sky is split open, and turns crimson like tanned leather.

# 4939

So which of your Lord’s bounties will you both deny?

# 4940

On that day neither humans will be questioned about their sins nor jinn.

# 4941

So which of your Lord’s bounties will you both deny?

# 4942

The guilty will be recognized by their mark; so they will be seized by their forelocks and feet.

# 4943

So which of your Lord’s bounties will you both deny?

# 4944

‘This is the hell which the guilty would deny!’

# 4945

They shall circuit between it and boiling hot water.

# 4946

So which of your Lord’s bounties will you both deny?

# 4947

For him who stands in awe of his Lord will be two gardens.

# 4948

So which of your Lord’s bounties will you both deny?

# 4949

Both abounding in branches.

# 4950

So which of your Lord’s bounties will you both deny?

# 4951

In both of them will be two flowing springs.

# 4952

So which of your Lord’s bounties will you both deny?

# 4953

In both of them will be two kinds of every fruit.

# 4954

So which of your Lord’s bounties will you both deny?

# 4955

\[They will be\] reclining on beds lined with green silk. And the fruit of the two gardens will be near at hand.

# 4956

So which of your Lord’s bounties will you both deny?

# 4957

In them are maidens of restrained glances, whom no human has touched before, nor jinn.

# 4958

So which of your Lord’s bounties will you both deny?

# 4959

As though they were rubies and corals.

# 4960

So which of your Lord’s bounties will you both deny?

# 4961

Is the requital of goodness anything but goodness?

# 4962

So which of your Lord’s bounties will you both deny?

# 4963

Beside these two, there will be two \[other\] gardens.

# 4964

So which of your Lord’s bounties will you both deny?

# 4965

Dark green.

# 4966

So which of your Lord’s bounties will you both deny?

# 4967

In both of them will be two gushing springs.

# 4968

So which of your Lord’s bounties will you both deny?

# 4969

In both of them will be fruits, date-palms and pomegranates.

# 4970

So which of your Lord’s bounties will you both deny?

# 4971

In them are maidens good and lovely.

# 4972

So which of your Lord’s bounties will you both deny?

# 4973

Houris secluded in pavilions.

# 4974

So which of your Lord’s bounties will you both deny?

# 4975

Whom no human has touched before, nor jinn.

# 4976

So which of your Lord’s bounties will you both deny?

# 4977

Reclining on green cushions and lovely carpets.

# 4978

So which of your Lord’s bounties will you both deny?

# 4979

Blessed is the Name of your Lord, the Majestic and the Munificent!

# 4980

When the Imminent \[Hour\] befalls

# 4981

—there is no denying that it will befall—

# 4982

\[it will be\] lowering and exalting.

# 4983

When the earth is shaken violently,

# 4984

and the mountains are shattered into bits

# 4985

and become scattered dust,

# 4986

you will be three groups:

# 4987

The People of the Right Hand—and what are the People of the Right Hand?!

# 4988

And the People of the Left Hand—and what are the People of the Left Hand?!

# 4989

And the Foremost Ones are the foremost ones:

# 4990

they are the ones brought near \[to Allah\],

# 4991

\[who will reside\] in the gardens of bliss.

# 4992

A multitude from the former \[generations\]

# 4993

and a few from the latter ones.

# 4994

On brocaded couches

# 4995

reclining on them, face to face.

# 4996

They will be waited upon by immortal youths,

# 4997

with goblets and ewers and a cup of a clear wine,

# 4998

which causes them neither headache nor stupefaction,

# 4999

and such fruits as they prefer

# 5000

and such flesh of fowls as they desire,

# 5001

and big-eyed houris

# 5002

like guarded pearls,

# 5003

a reward for what they used to do.

# 5004

They will not hear therein any vain talk or sinful speech,

# 5005

but only the watchword, ‘Peace!’ ‘Peace!’

# 5006

And the People of the Right Hand—what are the People of the Right Hand?!

# 5007

Amid thornless lote trees

# 5008

and clustered spathes

# 5009

and extended shade,

# 5010

and ever-flowing water

# 5011

and abundant fruits,

# 5012

neither inaccessible, nor forbidden,

# 5013

and noble spouses.

# 5014

We have created them with a special creation,

# 5015

and made them virgins,

# 5016

loving, of a like age,

# 5017

for the People of the Right Hand.

# 5018

A multitude from the former \[generations\]

# 5019

and a multitude from the latter \[ones\].

# 5020

And the People of the Left Hand—what are the People of the Left Hand?!

# 5021

Amid infernal miasma and boiling water

# 5022

and the shadow of a dense black smoke,

# 5023

neither cool nor beneficial.

# 5024

Indeed they had been affluent before this,

# 5025

and they used to persist in the great sin.

# 5026

And they used to say, ‘What! When we are dead and become dust and bones, shall we be resurrected?!

# 5027

And our forefathers too?!’

# 5028

Say, ‘Indeed the former and latter generations

# 5029

will all be gathered for the tryst of a known day.

# 5030

Then indeed, you, astray deniers,

# 5031

will surely eat from the Zaqqum tree

# 5032

and stuff your bellies with it,

# 5033

and drink boiling water on top of it,

# 5034

drinking like thirsty camels.’

# 5035

Such will be the hospitality they receive on the Day of Retribution.

# 5036

We created you. Then why do you not acknowledge it?

# 5037

Have you considered the sperm that you emit?

# 5038

Is it you who create it, or are We the creator?

# 5039

We have ordained death among you, and We are not to be outmaneuvered

# 5040

from replacing you with your likes and recreating you in \[a realm\] you do not know.

# 5041

Certainly you have known the first genesis, then why do you not take admonition?

# 5042

Have you considered what you sow?

# 5043

Is it you who make it grow, or are We the grower?

# 5044

If We wish, We turn it into chaff, whereat you are left stunned \[saying to yourselves,\]

# 5045

‘Indeed we have suffered loss!

# 5046

No, we are deprived!’

# 5047

Have you considered the water that you drink?

# 5048

Is it you who bring it down from the rain cloud, or is it We who bring \[it\] down?

# 5049

If We wish We can make it bitter. Then why do you not give thanks?

# 5050

Have you considered the fire that you kindle?

# 5051

Was it you who caused its tree to grow, or were We the grower?

# 5052

It was We who made it a reminder and a boon for the desert-dwellers.

# 5053

So celebrate the Name of your Lord, the All-supreme.

# 5054

I swear by the places where the stars set!

# 5055

And indeed it is a great oath, should you know.

# 5056

This is indeed a noble Quran,

# 5057

in a guarded Book

# 5058

—no one touches it except the pure ones—

# 5059

sent down gradually from the Lord of all the worlds.

# 5060

What! Do you take lightly this discourse?

# 5061

And make your denial of it your vocation?

# 5062

So when it reaches the throat \[of the dying person\],

# 5063

and at that moment you are looking on \[at his bedside\]

# 5064

—and We are nearer to him than you are, though you do not perceive—

# 5065

then why do you not restore it, if you are not subject

# 5066

\[to Divine dispensation\], if you are truthful?

# 5067

Then, if he be of those brought near,

# 5068

then ease, abundance, and a garden of bliss.

# 5069

And if he be of the People of the Right Hand,

# 5070

then \[he will be told,\] ‘Peace be on you, from the People of the Right Hand!’

# 5071

But if he be of the impugners, the astray ones,

# 5072

then a treat of boiling water

# 5073

and entry into hell.

# 5074

Indeed this is certain truth.

# 5075

So celebrate the Name of your Lord, the All-supreme!

# 5076

Whatever there is in the heavens and \[whatever there is on\] the earth glorifies Allah and He is the All-mighty, the All-wise.

# 5077

To Him belongs the kingdom of the heavens and the earth: He gives life and brings death, and He has power over all things.

# 5078

He is the First and the Last, the Manifest and the Hidden, and He has knowledge of all things.

# 5079

It is He who created the heavens and the earth in six days; then settled on the Throne. He knows whatever enters the earth and whatever emerges from it and whatever descends from the sky and whatever ascends to it, and He is with you wherever you may be, and Allah watches what you do.

# 5080

To Him belongs the kingdom of the heavens and the earth, and to Allah all matters are returned.

# 5081

He makes the night pass into the day and makes the day pass into the night, and He knows best what is in the breasts.

# 5082

Have faith in Allah and His Apostle, and spend out of that of which He has made you heirs. There is a great reward for those of you who have faith and spend \[in Allah’s way\].

# 5083

Why should you not have faith in Allah when the Apostle invites you to have faith in your Lord, and He has certainly made a covenant with you, if you are \[genuinely\] faithful?

# 5084

It is He who sends down manifest signs to His servant that He may bring you out of darkness into light, and indeed Allah is most kind and merciful to you.

# 5085

Why should you not spend in the way of Allah, when to Allah belongs the heritage of the heavens and the earth? Those of you who spent \[their means\] and fought before the victory are not equal \[to others\]. They are greater in rank than those who have spent and fought afterwards. Yet Allah has promised the best reward to each and Allah is well aware of what you do.

# 5086

Who is it that will lend Allah a good loan, that He may multiply it for him and \[that\] there may be a noble reward for him?

# 5087

The day you will see the faithful, men and women, with their light moving swiftly in front of them and on their right, \[and they are greeted with the words:\] ‘There is good news for you today! Gardens with streams running in them, to remain in them \[forever\]. That is the great success.’

# 5088

The day the hypocrites, men and women, will say to the faithful, ‘Please wait, that we may glean something from your light!’ They will be told: ‘Go back and grope for light!’ Then there will be set up between them a wall with a gate, with mercy within and punishment without.

# 5089

They will call out to them, ‘Did we not use to be with you?’ They will say, ‘Yes! But you cast yourselves into perdition. You awaited and were skeptical, and \[false\] hopes deceived you until the edict of Allah came, and the Deceiver deceived you concerning Allah.

# 5090

So today no ransom shall be taken from you or the faithless. The Fire will be your abode: it is your \[ultimate\] refuge and an evil destination.’

# 5091

Is it not time yet for those who have faith that their hearts should be humbled for Allah’s remembrance and toward the truth which has come down \[to them\], and to be not like those who were given the Book before? Time took its toll on them and so their hearts were hardened, and many of them are transgressors.

# 5092

Know that Allah revives the earth after its death. We have certainly made the signs clear for you, so that you may exercise your reason.

# 5093

Indeed the charitable men and women and those who lend Allah a good loan—it shall be multiplied for them, and there will be a noble reward for them.

# 5094

Those who have faith in Allah and His apostles—it is they who are the truthful and witnesses with their Lord; they shall have their reward and their light. But as for those who are faithless and deny Our signs, they shall be the inmates of hell.

# 5095

Know that the life of this world is mere diversion and play, glamour and mutual vainglory among you and rivalry for wealth and children—like rain, whose growth impresses the farmer. Then it withers and you see it turn yellow, then it becomes chaff. Whereas in the Hereafter there is forgiveness from Allah and His approval and a severe punishment. The life of this world is nothing but the wares of delusion.

# 5096

Take the lead towards forgiveness from your Lord and a paradise as vast as the heavens and the earth, prepared for those who have faith in Allah and His apostles. That is Allah’s grace, which He grants to whomever He wishes, and Allah is dispenser of a great grace.

# 5097

No affliction visits the land or yourselves but it is in a Book before We bring it about—that is indeed easy for Allah—

# 5098

so that you may not grieve for what escapes you, nor boast for what comes your way, and Allah does not like any swaggering braggart.

# 5099

Such as are \[themselves\] stingy and bid \[other\] people to be stingy. And whoever refuses to comply \[should know that\] indeed Allah is the All-sufficient, the All-laudable.

# 5100

Certainly We sent Our apostles with manifest proofs, and We sent down with them the Book and the Balance, so that mankind may maintain justice; and We sent down iron, in which there is great might and uses for mankind, and so that Allah may know those who help Him and His apostles \[with faith\] in the Unseen. Indeed Allah is all-strong, all-mighty.

# 5101

Certainly We sent Noah and Abraham and We ordained among their descendants prophethood and the Book. Some of them are \[rightly\] guided, and many of them are transgressors.

# 5102

Then We followed them up with Our apostles and We followed \[them\] with Jesus son of Mary, and We gave him the Evangel, and We put kindness and mercy into the hearts of those who followed him. But as for monasticism, they innovated it—We had not prescribed it for them—only seeking Allah’s pleasure. Yet they did not observe it with due observance. So We gave to the faithful among them their \[due\] reward, but many of them are transgressors.

# 5103

O you who have faith! Be wary of Allah and have faith in His Apostle. He will grant you a double share of His mercy and a light to walk by, and He will forgive you, and Allah is all-forgiving, all-merciful;

# 5104

so that the People of the Book may know that they do not control Allah grace in any wise and that in Allah’s hand is all grace, which He grants to whomever He wishes and Allah is dispenser of a mighty grace.

# 5105

Allah has certainly heard the speech of her who pleads with you about her husband and complains to Allah. Allah hears the conversation between the two of you. Indeed Allah is all-hearing, all-seeing.

# 5106

As for those of you who repudiate their wives by zihar, they are not their mothers; their mothers are only those who bore them, and indeed they utter an outrage and a lie. Indeed Allah is all-excusing, all-forgiving.

# 5107

Those who repudiate their wives by 3ih¡r and then retract what they have said, shall set free a slave before they may touch each other. This you are advised \[to carry out\], and Allah is well aware of what you do.

# 5108

He who cannot afford \[to free a slave\] shall fast for two successive months before they may touch each other. If he cannot \[do so\], he shall feed sixty needy persons. This, that you may have faith in Allah and His Apostle. These are Allah’s bounds, and there is a painful punishment for the faithless.

# 5109

Indeed those who oppose Allah and His Apostle will be subdued just as those who passed before them were subdued. We have certainly sent down manifest signs, and there is a humiliating punishment for the faithless.

# 5110

The day when Allah will raise them all together, He will inform them about what they have done. Allah has kept account of it, while they have forgotten, and Allah is witness to all things.

# 5111

Have you not regarded that Allah knows whatever there is in the heavens and whatever there is in the earth? There dost not takes place any secret talk among three, but He is their fourth \[companion\], nor among five but He is their sixth, nor when they are less than that or more but He is with them wherever they may be. Then He will inform them about what they have done on the Day of Resurrection. Indeed Allah has knowledge of all things.

# 5112

Have you not regarded those who were forbidden from secret talks but again resumed what they had been forbidden from, and hold secret talks \[imbued\] with sin and transgression and disobedience to the Apostle? And when they come to you they greet you with words with which Allah never greeted you, and they say to themselves, ‘Why does not Allah punish us for what we say?!’ Let hell suffice them: they shall enter it, and it is an evil destination!

# 5113

O you who have faith! When you converse secretly, do not hold private conversations \[imbued\] with sin and aggression and disobedience to the Apostle, but converse in \[a spirit of\] piety and Godfearing, and be wary of Allah toward whom you will be gathered.

# 5114

Indeed \[malicious\] secret talks are from Satan, that he may upset the faithful, but he cannot harm them in any way except by Allah’s leave, and in Allah let all the faithful put their trust.

# 5115

O you who have faith! When you are told, ‘Make room,’ in sittings, then do make room; Allah will make room for you. And when you are told, ‘Rise up!’ Do rise up. Allah will raise in rank those of you who have faith and those who have been given knowledge, and Allah is well aware of what you do.

# 5116

O you who have faith! When you converse privately with the Apostle, offer a charity before your private talk. That is better for you and purer. But if you cannot afford \[to make the offering\], then Allah is indeed all-forgiving, all-merciful.

# 5117

Were you dismayed by having to offer charities before your private talks? Since you did not do it, and Allah has excused you \[for not be able to comply\], now maintain the prayer and pay the zakat, and obey Allah and His Apostle. Allah is well aware of what you do.

# 5118

Have you not regarded those who befriend a people at whom Allah is wrathful? They neither belong to you, nor to them, and they swear false oaths \[that they are with you\] and they know.

# 5119

Allah has prepared a severe punishment for them. Evil indeed is what they used to do.

# 5120

They make a shield of their oaths and bar \[people\] from the way of Allah; so there is a humiliating punishment for them.

# 5121

Their possessions and children will not avail them in any way against Allah. They shall be the inmates of the Fire and they shall remain in it \[forever\].

# 5122

The day when Allah will raise them all together, they will swear to Him, just like they swear to you \[now\], supposing that they stand on something. Look! They are indeed liars!

# 5123

Satan has prevailed upon them, so he has caused them to forget the remembrance of Allah. They are Satan’s confederates. Look! Indeed, it is Satan’s confederates who are the losers!

# 5124

Indeed those who oppose Allah and His Apostle—they will be among the most abased.

# 5125

Allah has ordained: ‘I shall surely prevail, I and My apostles.’ Indeed Allah is all-strong, all-mighty.

# 5126

You will not find a people believing in Allah and the Last Day endearing those who oppose Allah and His Apostle even though they were their own parents, or children, or brothers, or kinsfolk. \[For\] such, He has written faith into their hearts and strengthened them with a spirit from Him. He will admit them into gardens with streams running in them, to remain in them \[forever\], Allah is pleased with them, and they are pleased with Him. They are Allah’s confederates. Look! The confederates of Allah are indeed felicitous!

# 5127

Whatever there is in the heavens and whatever there is in the earth glorifies Allah, and He is the All-mighty, the All-wise.

# 5128

It is He who expelled the faithless belonging to the People of the Book from their homes at the outset of \[their\] en masse banishment. You did not think that they would go out, and they thought their fortresses would protect them from Allah. But Allah came at them from whence they did not suppose and He cast terror into their hearts. They demolish their houses with their own hands and the hands of the faithful. So take lesson, O you who have insight!

# 5129

If Allah had not ordained banishment for them, He would have surely punished them in this world, and in the Hereafter, there is the punishment of the Fire for them.

# 5130

That is because they defied Allah and His Apostle; and whoever defies Allah, Allah is indeed severe in retribution.

# 5131

Whatever palm trees you cut down or left standing on their roots, it was by Allah’s will and in order that He may disgrace the transgressors.

# 5132

The spoils that Allah gave to His Apostle from them, you did not spur any horse for its sake, nor any riding camel, but Allah makes His apostles prevail over whomever He wishes, and Allah has power over all things.

# 5133

The spoils that Allah gave to His Apostle from the people of the townships, are for Allah and the Apostle, the relatives and the orphans, the needy and the traveller, so that they do not circulate among the rich among you. Take whatever the Apostle gives you, and refrain from whatever he forbids you, and be wary of Allah. Indeed Allah is severe in retribution.

# 5134

\[They are also\] for the poor Emigrants who have been expelled from their homes and \[wrested of\] their possessions, who seek grace from Allah and \[His\] pleasure and help Allah and His Apostle. It is they who are the truthful.

# 5135

\[They are as well\] for those who were settled in the land and \[abided\] in faith before them, who love those who migrate toward them, and do not find in their breasts any privation for that which is given to them, but prefer \[the Immigrants\] to themselves, though poverty be their own lot. And those who are saved from their own greed—it is they who are the felicitous.

# 5136

And \[also for\] those who came in after them, who say, ‘Our Lord, forgive us and our brethren who were our forerunners in the faith, and do not put any rancour in our hearts toward the faithful. Our Lord, You are indeed most kind and merciful.’

# 5137

Have you not regarded the hypocrites who say to their brethren, the faithless from among the People of the Book, ‘If you are expelled, we will surely go out with you, and we will never obey anyone against you, and if you are fought against we will surely help you,’ and Allah bears witness that they are indeed liars.

# 5138

Surely, if they were expelled they will not go out with them, and if they were fought against they will not help them, and \[even if\] they were to help them they will turn their backs \[to flee\] and eventually they will not be helped.

# 5139

Indeed they have a greater awe of you in their hearts than of Allah. That is because they are a lot who do not understand.

# 5140

They will not fight against you together except in fortified townships or from behind walls. Their fierceness is great only within themselves. You suppose them to be united, but their hearts are divided. That is because they are a lot who do not exercise their reason,

# 5141

just like those who tasted the evil consequence of their conduct recently before them, and there is a painful punishment for them.

# 5142

\[The hypocrites are\] like Satan when he tells man to disbelieve, but when he disbelieves, he says, ‘I am absolved of you. Indeed I fear Allah, the Lord of all the worlds.’

# 5143

So the fate of both is that they will be in the Fire, to remain in it \[forever\]. Such is the requital of the wrongdoers.

# 5144

O you who have faith! Be wary of Allah, and let every soul consider what it sends ahead for Tomorrow, and be wary of Allah. Allah is indeed well aware of what you do

# 5145

Do not be like those who forget Allah, so He makes them forget their own souls. It is they who are the transgressors.

# 5146

Not equal are the inmates of the Fire and the inhabitants of paradise. It is the inhabitants of paradise who are the successful ones.

# 5147

Had We sent down this Quran upon a mountain, you would have seen it humbled \[and\] go to pieces with the fear of Allah. We draw such comparisons for mankind, so that they may reflect.

# 5148

He is Allah—there is no god except Him—Knower of the sensible and the Unseen, He is the All-beneficent, the All-merciful.

# 5149

He is Allah—there is no god except Him—the Sovereign, the All-holy, the All-benign, the Securer, the All-conserver, the All-mighty, the All-compeller, and the All-magnanimous. Clear is Allah of any partners that they may ascribe \[to Him\]!

# 5150

He is Allah, the Creator, the Maker, and the Former. To Him belong the Best Names. Whatever there is in the heavens and the earth glorifies Him and He is the All-mighty, the All-wise.

# 5151

O you who have faith! Do not take My enemy and your enemy for friends, \[secretly\] offering them affection, if you have set out for jihad in My way and to seek My pleasure, for they have certainly denied whatever has come to you of the truth, expelling the Apostle and you, because you have faith in Allah, your Lord. You secretly nourish affection for them, while I know well whatever you hide and whatever you disclose, and whoever among you does that has certainly strayed from the right way.

# 5152

If they were to confront you they would be your enemies, and would stretch out against you their hands and \[unleash\] their tongues with evil \[intentions\], and they are eager that you \[too\] should be faithless.

# 5153

Your relatives and children will not avail you on the Day of Resurrection: He will separate you \[from one another\], and Allah watches what you do.

# 5154

There is certainly a good exemplar for you in Abraham and those who were with him, when they said to their own people, ‘Indeed we repudiate you and whatever you worship besides Allah. We disown you, and enmity and hate have appeared between you and us for ever, unless you come to have faith in Allah alone,’ apart from Abraham’s saying to his father, ‘I will surely plead forgiveness for you, though I cannot avail you anything against Allah.’ ‘Our Lord! In You do we put our trust, and to You do we turn penitently, and toward You is the destination.

# 5155

Our Lord! Do not make us a test for the faithless, and forgive us. Our Lord! Indeed You are the All-mighty, the All-wise.’

# 5156

There is certainly a good exemplar for you in them—for those who look forward to Allah and the Last Day—and anyone who refuses to comply \[should know that\] indeed Allah is the All-sufficient, the All-laudable.

# 5157

It may be that Allah will bring about affection between you and those with whom you are at enmity, and Allah is all-powerful, and Allah is all-forgiving, all-merciful.

# 5158

Allah does not forbid you from dealing with kindness and justice with those \[polytheists\] who did not make war against you on account of religion and did not expel you from your homes. Indeed Allah loves the just.

# 5159

Allah forbids you only in regard to those who made war against you on account of religion and expelled you from your homes and supported \[the polytheists of Makkah\] in your expulsion, that you make friends with them, and whoever makes friends with them—it is they who are the wrongdoers.

# 5160

O you who have faith! When faithful women come to you as immigrants, test them. Allah knows best \[the state of\] their faith. Then, if you ascertain them to be \[genuinely\] faithful women, do not send them back to the faithless. They are not lawful for them, nor are they lawful for them, but give them what \[dowry\] they have spent \[for them\]. There is no sin upon you in marrying them when you have given them their dowries. Do not hold on to \[conjugal\] ties with faithless women. Demand \[from the infidels\] what you have spent \[as dowries\], and let the faithless demand \[from you\] what they have spent \[as dowries\]. That is Allah’s judgment; He judges between you, and Allah is all-knowing, all-wise.

# 5161

If anything \[of the dowries\] pertaining to your wives is not reclaimed from the faithless and then you have your turn, then give to those whose wives have left the like of what they have spent, and be wary of Allah in whom you have faith.

# 5162

O Prophet! If faithful women come to you, to take the oath of allegiance to you, \[pledging\] that they shall not ascribe any partners to Allah, that they shall not steal, nor commit adultery, nor kill their children, nor utter any slander that they may have intentionally fabricated, nor disobey you in what is right, then accept their allegiance, and plead for them to Allah for forgiveness. Indeed Allah is all-forgiving, all-merciful

# 5163

O you who have faith! Do not befriend a people at whom Allah is wrathful: they have despaired of the Hereafter, just as the faithless have despaired of the occupants of the graves.

# 5164

Whatever there is in the heavens and the earth glorifies Allah, and He is the All-mighty, the All-wise.

# 5165

O you who have faith! Why do you say what you do not do?

# 5166

It is greatly outrageous to Allah that you should say what you do not do.

# 5167

Indeed Allah loves those who fight in His way in ranks, as if they were a compact structure.

# 5168

When Moses said to his people, ‘O my people! Why do you torment me, when you certainly know that I am Allah’s apostle to you?’ So when they swerved \[from the right path\], Allah made their hearts swerve, and Allah does not guide the transgressing lot.

# 5169

And when Jesus son of Mary said, ‘O Children of Israel! Indeed I am the apostle of Allah to you, to confirm what is before me of the Torah, and to give the good news of an apostle who will come after me, whose name is Ahmad.’ But when he brought them manifest proofs, they said, ‘This is plain magic.’

# 5170

Who is a greater wrongdoer than him who fabricates falsehoods against Allah, while he is being summoned to Islam? And Allah does not guide the wrongdoing lot.

# 5171

They desire to put out the light of Allah with their mouths, but Allah will perfect His light though the faithless should be averse.

# 5172

It is He who has sent His Apostle with guidance and the true religion that He may make it prevail over all religions though the polytheists should be averse.

# 5173

O you who have faith! Shall I show you a deal that will deliver you from a painful punishment?

# 5174

Have faith in Allah and His Apostle, and wage jihad in the way of Allah with your persons and possessions. That is better for you, should you know.

# 5175

He will forgive your sins and admit you into gardens with streams running in them, and into good dwellings in the Gardens of Eden; that is the great success.

# 5176

And other \[blessings\] you cherish: help from Allah and a victory near at hand, and give good news to the faithful.

# 5177

O you who have faith! Be Allah’s helpers, just as Jesus son of Mary said to his disciples, ‘Who will be my helpers for Allah’s sake?’ The Disciples said, ‘We will be Allah’s helpers!’ So a group of the Children of Israel believed, and a group disbelieved. Then We strengthened the faithful against their enemies, and they came to prevail \[over them\].

# 5178

Whatever there is in the heavens and in the earth glorifies Allah, the Sovereign, the All-holy, the All-mighty, the All-wise.

# 5179

It is He who sent to the unlettered \[people\] an apostle from among themselves, to recite to them His signs, to purify them, and to teach them the Book and wisdom, and earlier they had indeed been in manifest error.

# 5180

And to others from among them \[as well\] who have not yet joined them. And He is the All-mighty, the All-wise.

# 5181

That is Allah’s grace, which He grants to whomever He wishes, and Allah is dispenser of a great grace.

# 5182

The example of those who were charged with the Torah, then failed to carry it, is that of an ass carrying books. Evil is the example of the people who deny Allah’s signs, and Allah does not guide the wrongdoing lot.

# 5183

Say, ‘O Jews! If you claim that you are Allah’s favourites, to the exclusion of other people, then long for death, should you be truthful.’

# 5184

Yet they will never long for it, because of what their hands have sent ahead, and Allah knows best the wrongdoers.

# 5185

Say, ‘The death that you flee will indeed encounter you. Then you will be returned to the Knower of the sensible and the Unseen, and He will inform you about what you used to do.’

# 5186

O you who have faith! When the call is made for prayer on Friday, hurry toward the remembrance of Allah, and leave all business. That is better for you, should you know.

# 5187

And when the prayer is finished disperse through the land and seek Allah’s grace, and remember Allah much so that you may be felicitous.

# 5188

When they sight a deal or a diversion, they scatter off towards it and leave you standing! Say, ‘What is with Allah is better than diversion and dealing, and Allah is the best of providers.’

# 5189

When the hypocrites come to you they say, ‘We bear witness that you are indeed the apostle of Allah.’ Allah knows that you are indeed His Apostle, and Allah bears witness that the hypocrites are indeed liars.

# 5190

They make a shield of their oaths, and bar from the way of Allah. Evil indeed is what they used to do.

# 5191

That is because they believed and then disbelieved, so their hearts were sealed. Hence, they do not understand.

# 5192

When you see them, their bodies impress you, and if they speak, you listen to their speech. Yet they are like dry logs set reclining \[against a wall\]. They suppose every cry is directed against them. They are the enemy, so beware of them. May Allah assail them, where do they stray?!

# 5193

When they are told, ‘Come, that Allah’s Apostle may plead for forgiveness for you,’ they twist their heads, and you see them turn away disdainfully.

# 5194

It is the same for them whether you plead for forgiveness for them, or do not plead for forgiveness for them: Allah will never forgive them. Indeed Allah does not guide the transgressing lot.

# 5195

They are the ones who say, ‘Do not spend on those who are with the Apostle of Allah until they scatter off \[from around him\].’ Yet to Allah belong the treasuries of the heavens and the earth, but the hypocrites do not understand.

# 5196

They say, ‘When we return to the city, the mighty will surely expel the weak from it.’ Yet all might belongs to Allah and His Apostle and the faithful, but the hypocrites do not know.

# 5197

O you who have faith! Do not let your possessions and children distract you from the remembrance of Allah, and whoever does that—it is they who are the losers.

# 5198

Spend out of what We have provided you before death comes to any of you, whereat he might say, ‘My Lord, why did You not respite me for a short time so that I could give charity and become one of the righteous!’

# 5199

But Allah will never respite anyone when his time has come, and Allah is well aware of what you do.

# 5200

Whatever there is in the heavens and the earth glorifies Allah. To Him belongs all sovereignty and to Him belongs all praise, and He has power over all things.

# 5201

It is He who created you. Then some of you are faithless and some of you are faithful, and Allah watches what you do.

# 5202

He created the heavens and the earth with consummate wisdom, and He formed you and perfected your forms, and toward Him is your destination.

# 5203

He knows whatever there is in the heavens and the earth, and He knows whatever you hide and whatever you disclose, and Allah knows best what is in your breasts.

# 5204

Has there not come to you the account of those who were faithless before? They tasted the evil consequence of their conduct, and there is a painful punishment for them.

# 5205

That was because their apostles would bring them manifest proofs, but they said, ‘Will humans be our guides?!’ So they disbelieved and turned away, and Allah had no need \[of their faith\] and Allah is all-sufficient, all-laudable.

# 5206

The faithless claim that they will not be resurrected. Say, ‘Yes, by my Lord, you will surely be resurrected; then you will surely be informed of what you did, and that is easy for Allah.’

# 5207

So have faith in Allah and His Apostle and the light, which We have sent down, and Allah is well aware of what you do.

# 5208

When He will you bring you together for the Day of Gathering, it will be a day of privation \[and regret\]. As for those who have faith in Allah and act righteously, He shall absolve them of their misdeeds and admit them into gardens with streams running in them, to remain in them forever. That is the great success.

# 5209

But as for those who are faithless and deny Our signs, they will be the inmates of the Fire, to remain in it \[forever\], and it is an evil destination.

# 5210

No affliction visits \[anyone\] except by Allah’s leave. Whoever has faith in Allah, He guides his heart, and Allah has knowledge of all things.

# 5211

Obey Allah and obey the Apostle; but if you turn away, then Our Apostle’s duty is only to communicate in clear terms.

# 5212

Allah—there is no god except Him—in Allah let all the faithful put their trust.

# 5213

O you who have faith! Indeed, you have enemies among your spouses and children; so beware of them. Yet if you excuse, forbear, and forgive, then Allah is indeed all-forgiving, all-merciful.

# 5214

Rather, your possessions, and children are a test, and Allah—with Him is a great reward!

# 5215

So be wary of Allah, as much as you can, and listen and obey, and spend \[in the way of Allah\]; that is better for yourselves. Those who are saved from their own greed—it is they who are the felicitous.

# 5216

If you lend Allah a good loan, He shall multiply it for you and forgive you, and Allah is all-appreciative, all-forbearing,

# 5217

Knower of the sensible and the Unseen, the All-mighty, the All-wise.

# 5218

O Prophet! When you divorce women, divorce them at \[the conclusion of\] their term and calculate the term, and be wary of Allah, your Lord. Do not turn them out from their homes, nor shall they go out, unless they commit a gross indecency. These are Allah’s bounds, and whoever transgresses the bounds of Allah certainly wrongs himself. You never know maybe Allah will bring off something new later on.

# 5219

Then, when they have completed their term, either retain them honourably or separate from them honourably, and take the witness of two honest men from among yourselves, and bear witness for the sake of Allah. Whoever believes in Allah and the Last Day is advised to \[comply with\] this. Whoever is wary of Allah, He shall make for him a way out \[of the adversities of the world and the Hereafter\]

# 5220

and provide for him from whence he does not count upon. And whoever puts his trust in Allah, He will suffice him. Indeed Allah carries through His commands. Certainly, Allah has ordained a measure \[and extent\] for everything.

# 5221

As for those of your wives who have ceased having menses—\[or\] if you have any doubts \[concerning its cause, whether it’s is age or something else\]—their term \[of waiting\] and of those who have not yet had menses, shall be three months. As for those who are pregnant, their term shall be until they deliver. And whoever is wary of Allah, He shall grant him ease in his affairs.

# 5222

That is Allah’s ordinance, which He has sent down to you, and whoever is wary of Allah, He shall absolve him of his misdeeds and give him a great reward.

# 5223

House them where you live, in accordance with your means, and do not harass them to put them in straits, and should they be pregnant, maintain them until they deliver. Then, if they suckle \[the baby\] for you, give them their wages and consult together honourably. But if you make things difficult for each other, then another woman will suckle \[the baby\] for him.

# 5224

Let the affluent man spend out of his affluence, and let he whose provision has been tightened spend out of what Allah has given him. Allah does not task any soul except \[according to\] what He has given it. Allah will bring about ease after hardship.

# 5225

How many a town defied the command of its Lord and His apostles, then We called it to a severe account and punished it with a dire punishment.

# 5226

So it tasted the evil consequences of its conduct, and the outcome of its conduct was ruin.

# 5227

Allah has prepared for them a severe punishment. So be wary of Allah, O you who possess intellect and have faith! Allah has already sent down to you a reminder,

# 5228

an apostle reciting to you the manifest signs of Allah that He may bring out those who have faith and do righteous deeds from darkness into light. And whoever has faith in Allah and does righteous deeds, He shall admit him into gardens with streams running in them, to remain in them forever. Allah has certainly granted him an excellent provision.

# 5229

It is Allah who has created seven heavens, and of the earth \[a number\] similar to them. The command gradually descends through them, that you may know that Allah has power over all things, and that Allah comprehends all things in knowledge.

# 5230

O Prophet! Why do you disallow \[yourself\] what Allah has made lawful for you, seeking to please your wives? And Allah is all-forgiving, all-merciful.

# 5231

Allah has certainly made lawful for you the dissolution of your oaths, and Allah is your master and He is the All-knowing, the All-wise.

# 5232

When the Prophet confided a matter to one of his wives, but when she divulged it \[instead of guarding the secret\] and Allah apprised him about it, he acquainted \[her\] with part of the matter and ignored part of it. So when he told her about it, she said, ‘Who informed you about it?’ He said, ‘The All-knowing and the All-aware has informed me.’

# 5233

If the two of you repent to Allah... for your hearts have certainly swerved, and if you back each other against him, then \[know that\] Allah is indeed his guardian, and his supporters are Gabriel, the righteous among the faithful and, thereafter, the angels.

# 5234

It may be that if he divorces you his Lord will give him, in \[your\] stead, wives better than you: \[such as are\] muslim, faithful, obedient, penitent, devout and given to fasting, virgins and non-virgins.

# 5235

O you who have faith! Save yourselves and your families from a Fire whose fuel will be people and stones, over which are \[assigned\] severe and mighty angels, who do not disobey whatever Allah commands them and carry out what they are commanded.

# 5236

\[They will call out to the faithless:\] ‘O faithless ones! Do not make any excuses today. You are being requited only for what you used to do.’

# 5237

O you who have faith! Repent to Allah with sincere repentance! Maybe your Lord will absolve you of your misdeeds and admit you into gardens with streams running in them, on the day when Allah will not let down the Prophet and the faithful who are with him. Their light will move swiftly before them and on their right. They will say, ‘Our Lord! Perfect our light for us, and forgive us! Indeed You have power over all things.’

# 5238

O Prophet! Wage jihad against the faithless and the hypocrites, and be severe with them. Their refuge will be hell, and it is an evil destination.

# 5239

Allah cites an example of the faithless: the wife of Noah and the wife of Lot. They were under two of our righteous servants, yet they betrayed them. So they did not avail them in any way against Allah, and it was said \[to them\], ‘Enter the Fire, along with those who enter \[it\].’

# 5240

Allah cites an example of the faithful: the wife of Pharaoh, when she said, ‘My Lord! Build me a home near You in paradise, and deliver me from Pharaoh and his conduct, and deliver me from the wrongdoing lot.’

# 5241

And Mary, daughter of Imran, who guarded the chastity of her womb, so We breathed into it of Our spirit. She confirmed the words of her Lord and His Books, and she was one of the obedient.

# 5242

Blessed is He in whose hands is all sovereignty, and He has power over all things.

# 5243

He, who created death and life that He may test you \[to see\] which of you is best in conduct. And He is the All-mighty, the All-forgiving.

# 5244

He created seven heavens in layers. You do not see any discordance in the creation of the All-beneficent. Look again! Do you see any flaw?

# 5245

Look again, once more. Your look will return to you humbled and weary.

# 5246

We have certainly adorned the lowest heaven with lamps, and made them \[the means of pelting\] missiles against the devils, and We have prepared for them a punishment of the Blaze.

# 5247

For those who defy their Lord is the punishment of hell, and it is an evil destination.

# 5248

When they are thrown in it, they hear it blaring, as it seethes,

# 5249

almost exploding with rage. Whenever a group is thrown in it, its keepers will ask them, ‘Did not any warner come to you?’

# 5250

They will say, ‘Yes, a warner did come to us, but we impugned \[him\] and said, ‘Allah did not send down anything; you are only in great error.’

# 5251

And they will say, ‘Had we listened or applied reason, we would not have been among inmates of the Blaze.’

# 5252

Thus they will admit their sin. So away with the inmates of the Blaze!

# 5253

Indeed for those who fear their Lord in secret there will be forgiveness and a great reward.

# 5254

Speak secretly, or do so openly, indeed He knows well what is in the breasts.

# 5255

Would He who has created not know? And He is the All-attentive, the All-aware.

# 5256

It is He who made the earth tractable for you; so walk on its flanks and eat of His provision, and towards Him is the resurrection.

# 5257

Are you secure that He who is in the sky will not make the earth swallow you while it quakes?

# 5258

Are you secure that He who is in the sky will not unleash upon you a rain of stones? Soon you will know how My warning has been!

# 5259

Certainly those who were before them had impugned \[My apostles\]; but then how was My rebuttal!

# 5260

Have they not regarded the birds above them spreading and closing their wings? No one sustains them except the All-beneficent. Indeed, He watches all things.

# 5261

Who is it that is your host who may help you, besides the All-beneficent? The faithless only dwell in delusion.

# 5262

Who is it that may provide for you if He withholds His provision? Indeed, they persist in defiance and aversion.

# 5263

Is he who walks prone on his face better guided, or he who walks upright on a straight path?

# 5264

Say, ‘It is He who created you, and made for you hearing, eyesight, and hearts. Little do you thank.’

# 5265

Say, ‘It is He who created you on the earth, and toward Him you will be mustered.’

# 5266

They say, ‘When will this promise be fulfilled, if you are truthful?’

# 5267

Say, ‘Its knowledge is only with Allah; I am only a manifest warner.’

# 5268

When they see it brought near, the countenances of the faithless will be contorted, and \[they will be\] told, ‘This is what you were asking for!’

# 5269

Say, ‘Tell me, whether Allah destroys me and those who are with me, or He has mercy on us, who will shelter the faithless from a painful punishment?’

# 5270

Say, ‘He is the All-beneficent; we have faith in Him, and in Him do we trust. Soon you will know who is in manifest error.’

# 5271

Say, ‘Tell me, should your water sink down \[into the ground\], who will bring you running water?’

# 5272

Nun. By the Pen and what they write:

# 5273

by your Lord’s blessing, you are not, crazy,

# 5274

and yours indeed will be an everlasting reward,

# 5275

and indeed you possess a great character.

# 5276

You will see and they will see,

# 5277

which one of you is crazy.

# 5278

Indeed your Lord knows best those who stray from His way, and He knows best those who are guided.

# 5279

So do not obey the deniers,

# 5280

who are eager that you should be flexible, so that they \[too\] may be flexible \[towards you\].

# 5281

And do not obey any vile swearer,

# 5282

scandal-monger, talebearer,

# 5283

hinderer of all good, sinful transgressor,

# 5284

callous and, on top of that, baseborn

# 5285

—\[who behaves in such a manner only\] because he has wealth and children.

# 5286

When Our signs are recited to him, he says, ‘Myths of the ancients!’

# 5287

Soon We shall brand him on his snout.

# 5288

Indeed we have tested them just as We tested the People of the Garden when they vowed they would gather its fruit at dawn,

# 5289

and they did not make any exception.

# 5290

Then, a visitation from your Lord visited it while they were asleep.

# 5291

So, by dawn it was like a harvested field.

# 5292

At dawn they called out to one another,

# 5293

‘Get off early to your field if you have to gather \[the fruits\].’

# 5294

So off they went, murmuring to one another:

# 5295

‘Today no needy man shall come to you in it.’

# 5296

And they set out at early morning, \[considering themselves\] able to deprive \[the poor of its fruit\].

# 5297

But when they saw it, they said, ‘We have indeed lost our way!’

# 5298

‘No, it is we who have been deprived!’

# 5299

The most upright among them said, ‘Did I not tell you, ‘‘Why do you not glorify \[Allah\]?’’ ’

# 5300

They said, ‘Immaculate is our Lord! We have indeed been wrongdoers!’

# 5301

Then they turned to one another, blaming each other.

# 5302

They said, ‘Woe to us! Indeed, we have been rebellious.

# 5303

Maybe our Lord will give us a better one in its place. Indeed we earnestly beseech our Lord.’

# 5304

Such was their punishment; and the punishment of the Hereafter is surely greater, had they known.

# 5305

Indeed for the Godwary there will be gardens of bliss near their Lord.

# 5306

Shall We treat those who submit \[to Us\] as \[We treat\] the guilty?

# 5307

What is the matter with you? How do you judge!

# 5308

Do you possess a scripture in which you read

# 5309

that you shall have in it whatever you choose?

# 5310

Do you have a pledge binding on Us until the Day of Resurrection, that you shall indeed have whatever you decide?

# 5311

Ask them, which of them will aver \[any of\] that!

# 5312

Do they have any ‘partners’ \[that they claim for Allah\]? Then let them produce their partners, if they are truthful.

# 5313

The day when the catastrophe occurs and they are summoned to prostrate themselves, they will not be able \[to do it\].

# 5314

With a humbled look \[in their eyes\], they will be overcast by abasement. Certainly, they were summoned to prostrate themselves while they were yet sound.

# 5315

So leave Me with those who deny this discourse. We will draw them imperceptibly \[into ruin\], whence they do not know.

# 5316

I will grant them respite, for My devising is indeed sure.

# 5317

Do you ask them for a reward, so that they are weighed down with debt?

# 5318

Do they possess \[access to\] the Unseen, so that they write it down?

# 5319

So submit patiently to the judgement of your Lord, and do not be like the Man of the Fish who called out as he choked with grief.

# 5320

Had it not been for a blessing that came to his rescue from his Lord, he would surely have been cast on the bare shore, being blameworthy.

# 5321

So his Lord chose him and made him one of the righteous.

# 5322

Indeed the faithless almost devour you with their eyes when they hear this Reminder, and they say, ‘He is indeed crazy.’

# 5323

Yet it is just a reminder for all the nations.

# 5324

The Besieger!

# 5325

What is the Besieger?!

# 5326

What will show you what is the Besieger?!

# 5327

Thamudand ‘Ad denied the Cataclysm.

# 5328

As for Thamud, they were destroyed by the Cry.

# 5329

And as for ‘Ad, they were destroyed by a fierce icy gale,

# 5330

which He clamped on them for seven gruelling nights and eight days, so that you could see the people there lying about prostrate as if they were hollow trunks of palm trees.

# 5331

So do you see any remaining trace of them?

# 5332

Then Pharaoh and those who were before him, and the towns that were overturned, brought about iniquity.

# 5333

They disobeyed the apostle of their Lord, so He seized them with a terrible seizing.

# 5334

Indeed when the Flood rose high, We carried you in a floating ark,

# 5335

that We might make it a reminder for you, and that receptive ears might remember it.

# 5336

When the Trumpet is blown with a single blast

# 5337

and the earth and the mountains are lifted and levelled with a single levelling,

# 5338

then, on that day, will the Imminent \[Hour\] befall

# 5339

and the sky will be split open—for it will be frail on that day—

# 5340

with the angels all over it, and the Throne of your Lord will be borne that day by eight \[angels\].

# 5341

That day you will be presented \[before your Lord\]: none of your secrets will remain hidden.

# 5342

As for him who is given his book in his right hand, he will say, ‘Here, take and read my book!

# 5343

Indeed I knew that I will encounter my account \[of deeds\].’

# 5344

So he will have a pleasant life,

# 5345

in an elevated garden,

# 5346

whose clusters \[of fruits\] will be within easy reach.

# 5347

\[He will be told\]: ‘Enjoy your food and drink, for what you had sent in advance in past days \[for your future life\].’

# 5348

But as for him who is given his book in his left hand, he will say, ‘I wish I had not been given my book,

# 5349

nor had I ever known what my account is!

# 5350

I wish death had been the end of it all!

# 5351

My wealth did not avail me.

# 5352

My authority has left me.’

# 5353

\[The angels will be told:\] ‘Seize him, and fetter him!

# 5354

Then put him into hell.

# 5355

Then bind him in a chain, seventy cubits in length.

# 5356

Indeed he had no faith in Allah, the All-supreme,

# 5357

and he did not urge the feeding of the needy,

# 5358

so he has no friend here today,

# 5359

nor any food except pus,

# 5360

which no one shall eat except the iniquitous.’

# 5361

I swear by what you see

# 5362

and what you do not see:

# 5363

it is indeed the speech of a noble apostle

# 5364

and it is not the speech of a poet. Little is the faith that you have!

# 5365

Nor is it the speech of a soothsayer. Little is the admonition that you take!

# 5366

Gradually sent down from the Lord of all the worlds.

# 5367

Had he faked any sayings in Our name,

# 5368

We would have surely seized him by the right hand

# 5369

and then cut off his aorta,

# 5370

and none of you could have held Us off from him.

# 5371

Indeed it is a reminder for the Godwary.

# 5372

Indeed We know that there are some among you who deny \[it\].

# 5373

And indeed it will be a \[matter of\] regret for the faithless.

# 5374

It is indeed certain truth.

# 5375

So celebrate the Name of your Lord, the All-supreme.

# 5376

An asker asked for a punishment sure to befall

# 5377

—which none can avert from the faithless —

# 5378

from Allah, Lord of the lofty stations.

# 5379

The angels and the Spirit ascend to Him in a day whose span is fifty thousand years.

# 5380

So be patient, with a patience that is graceful.

# 5381

Indeed they see it to be far off,

# 5382

and We see it to be near.

# 5383

The day when the sky will be like molten copper,

# 5384

and the mountains like \[tufts of\] dyed wool,

# 5385

and no friend will inquire about \[the welfare of his\] friend,

# 5386

\[though\] they will be placed within each other’s sight. The guilty one will wish he could ransom himself from the punishment of that day at the price of his children,

# 5387

his spouse and his brother,

# 5388

his kin, which had sheltered him

# 5389

and all those who are upon the earth, if that might deliver him.

# 5390

Never! Indeed, it is a blazing fire,

# 5391

which strips away the scalp.

# 5392

It invites him, who has turned back \[from the truth\] and forsaken \[it\],

# 5393

amassing \[wealth\] and hoarding \[it\].

# 5394

Indeed man has been created covetous:

# 5395

anxious when an ill befalls him

# 5396

and grudging \[charity\] when good comes his way

# 5397

—\[all are such\] except the prayerful,

# 5398

those who persevere in their prayers

# 5399

and there is a known share in whose wealth

# 5400

for the beggar and the deprived,

# 5401

and who affirm the Day of Retribution,

# 5402

and those who are apprehensive of the punishment of their Lord

# 5403

(there is indeed no security from the punishment of their Lord)

# 5404

and those who guard their private parts

# 5405

(apart from their spouses and their slave women, for then they are not blameworthy;

# 5406

but whoever seeks beyond that—it is they who are the transgressors)

# 5407

and those who keep their trusts and covenants,

# 5408

and those who are observant of their testimonies,

# 5409

and those who are watchful of their prayers.

# 5410

They will be in gardens, held in honour.

# 5411

What is the matter with the faithless that they scramble toward you,

# 5412

from left and right, in groups?

# 5413

Does each man among them hope to enter the garden of bliss?

# 5414

Never! Indeed, We created them from what they know.

# 5415

So I swear by the Lord of the easts and the wests that We are able

# 5416

to replace them with \[others\] better than them and We are not to be outmaneuvered.

# 5417

So leave them to gossip and play till they encounter the day they are promised:

# 5418

the day when they emerge from graves, hastening, as if racing toward a target,

# 5419

with a humbled look \[in their eyes\], overcast by abasement. That is the day they had been promised.

# 5420

Indeed We sent Noah to his people, \[saying,\] ‘Warn your people before a painful punishment overtakes them.’

# 5421

He said, ‘O my people! Indeed, I am a manifest warner to you.

# 5422

Worship Allah and be wary of Him, and obey me,

# 5423

that He may forgive you some of your sins and respite you until a specified time. Indeed when Allah’s \[appointed\] time comes, it cannot be deferred, if you know.’

# 5424

He said, ‘My Lord! Indeed, I have summoned my people night and day

# 5425

but my summons only increases their evasion.

# 5426

Indeed whenever I have summoned them, so that You might forgive them, they would put their fingers into their ears and draw their cloaks over their heads, and they were persistent \[in their unfaith\], and disdainful in \[their\] arrogance.

# 5427

Again I summoned them aloud,

# 5428

and again appealed to them publicly and confided with them privately,

# 5429

telling \[them\]: ‘‘Plead to your Lord for forgiveness. Indeed, He is all-forgiving.

# 5430

He will send for you abundant rains from the sky,

# 5431

and aid you with wealth and sons, and provide you with gardens and provide you with streams.

# 5432

What is the matter with you that you do not look upon Allah with veneration,

# 5433

though He has created you in \[various\] stages?

# 5434

Have you not seen how Allah has created the seven heavens in layers,

# 5435

and has made therein the moon for a light and the sun for a lamp?

# 5436

Allah made you grow from the earth, with a \[vegetable\] growth.

# 5437

Then He makes you return to it, and He will bring you forth \[without fail\].

# 5438

Allah has made the earth a vast expanse for you

# 5439

so that you may travel over its spacious ways.’’ ’

# 5440

Noah said, ‘My Lord! They have disobeyed me, following someone whose wealth and children only add to his loss,

# 5441

and they have devised an outrageous plot.

# 5442

They say, ‘‘Do not abandon your gods. Do not abandon Wadd, nor Suwa, nor Yaghuth, Ya‘uq and Nasr,’’

# 5443

and already they have led many astray. Do not increase the wrongdoers in anything but error.’

# 5444

They were drowned because of their iniquities, then made to enter a Fire, and they did not find any helpers for themselves besides Allah.

# 5445

And Noah said, ‘My Lord! ‘Do not leave on the earth any inhabitant from among the faithless.

# 5446

If You leave them, they will lead astray Your servants, and will beget none except vicious ingrates.

# 5447

My Lord! Forgive me and my parents, and whoever enters my house in faith, and the faithful men and women, and do not increase the wrongdoers in anything but ruin.’

# 5448

Say, ‘It has been revealed to me that a team of the jinn listened \[to the Quran\] and they said, “Indeed we heard a wonderful Quran,

# 5449

which guides to rectitude. Hence, we have believed in it and we will never ascribe any partner to our Lord.

# 5450

Exalted be the majesty of our Lord; He has taken neither any spouse nor son.

# 5451

The foolish ones among us used to speak atrocious lies concerning Allah.

# 5452

We thought that humans and jinn would never utter any falsehood concerning Allah.

# 5453

Indeed some persons from the humans would seek the protection of some persons from the jinn, thus only adding to their rebellion.

# 5454

They thought, just as you think, that Allah will not raise anyone from the dead.

# 5455

Indeed we made for the heaven and found it full of mighty sentries and flames.

# 5456

We used to sit in its positions to eavesdrop, but anyone listening now finds a flame waiting for him.

# 5457

We do not know whether ill is intended for those who are on the earth, or whether their Lord intends good for them.

# 5458

Among us some are righteous and some are otherwise: we are various sects.

# 5459

We know that we cannot frustrate Allah on the earth, nor can we frustrate Him by fleeing.

# 5460

When we heard the \[message of\] guidance, we believed in it. Whoever that has faith in his Lord will fear neither privation nor oppression.

# 5461

Among us some are Muslims and some of us are perverse.” ’ Those who submit \[to Allah\]—it is they who pursue rectitude.

# 5462

As for the perverse, they will be firewood for hell.

# 5463

If they are steadfast on the path \[of Allah\], We shall provide them with abundant water,

# 5464

so that We may test them therein, and whoever turns away from the remembrance of his Lord, He will let him into an escalating punishment.

# 5465

The places of worship belong to Allah, so do not invoke anyone along with Allah.

# 5466

When the servant of Allah rose to pray to Him, they almost crowded around him.

# 5467

Say, ‘I pray only to my Lord, and I do not ascribe any partner to Him.’

# 5468

Say, ‘I have no power to bring you any harm or good \[of my own accord\].’

# 5469

Say, ‘Neither can anyone shelter me from Allah, nor can I find any refuge besides Him.

# 5470

\[I have no duty\] except to transmit from Allah, and \[to communicate\] His messages; and whoever disobeys Allah and His apostle, there will indeed be for him the fire of hell, to remain in it forever.’

# 5471

When they see what they are promised, they will know who is weaker in supporters and fewer in numbers.

# 5472

Say, ‘I do not know if what you are promised is near, or if my Lord has set a \[long\] term for it.’

# 5473

Knower of the Unseen, He does not disclose His \[knowledge of the\] Unseen to anyone,

# 5474

except to an apostle He approves of. Then He dispatches a sentinel before and behind him

# 5475

so that He may ascertain that they have communicated the messages of their Lord, and He encompasses all that is with them, and He keeps an count of all things.

# 5476

O you wrapped up in your mantle!

# 5477

Stand vigil through the night, except for a little \[of it\],

# 5478

a half, or reduce a little from that

# 5479

or add to it, and recite the Quran in a measured tone.

# 5480

Indeed soon We shall cast on you a weighty discourse.

# 5481

Indeed the watch of the night is firmer in tread and more upright in respect to speech,

# 5482

for indeed during the day you have drawn-out engagements.

# 5483

So celebrate the Name of your Lord and dedicate yourself to Him with total dedication.

# 5484

Lord of the east and the west, there is no god except Him; so take Him for your trustee,

# 5485

and be patient over what they say, and distance yourself from them in a graceful manner.

# 5486

Leave Me \[to deal\] with the deniers, the opulent, and give them a little respite.

# 5487

Indeed with Us are heavy fetters and a fierce fire,

# 5488

and a food that chokes \[those who eat it\], and a painful punishment \[prepared for\]

# 5489

the day when the earth and the mountains will quake, and the mountains will be like dunes of shifting sand.

# 5490

Indeed We have sent to you an apostle, to be a witness to you, just as We sent an apostle to Pharaoh.

# 5491

But Pharaoh disobeyed the apostle; so We seized him with a terrible seizing.

# 5492

So, if you disbelieve, how will you avoid the day, which will make children white-headed,

# 5493

and wherein the sky will be rent apart? His promise is bound to be fulfilled.

# 5494

This is indeed a reminder. So let anyone who wishes take the way toward his Lord.

# 5495

Indeed your Lord knows that you stand vigil for nearly two thirds of the night—or \[at times\] a half or a third of it—along with a group of those who are with you. Allah measures the night and the day. He knows that you cannot calculate it \[exactly\], and so He was lenient toward you. So recite as much of the Quran as is feasible. He knows that some of you will be sick, while others will travel in the land seeking Allah’s bounty, and yet others will fight in the way of Allah. So recite as much of it as is feasible, and maintain the prayer and pay the zakat and lend Allah a good loan. Whatever good you send ahead for your souls you will find it with Allah \[in a form\] that is better and greater with respect to reward. And plead to Allah for forgiveness; indeed Allah is all-forgiving, all-merciful.

# 5496

O you wrapped up in your mantle!

# 5497

Rise up and warn!

# 5498

Magnify your Lord,

# 5499

and purify your clothes,

# 5500

and keep away from all impurity!

# 5501

Do not grant a favour seeking a greater gain,

# 5502

and be patient for the sake of your Lord.

# 5503

When the Trumpet will be sounded,

# 5504

that will be a day of hardship,

# 5505

not at all easy for the faithless.

# 5506

Leave Me \[to deal\] with him whom I created alone,

# 5507

and furnished him with extensive means,

# 5508

\[gave him\] sons to be at his side,

# 5509

and facilitated \[all matters\] for him.

# 5510

Still he is eager that I should give him more.

# 5511

No indeed! He is an obstinate opponent of Our signs.

# 5512

Soon I will overwhelm him with hardship.

# 5513

Indeed he reflected and decided.

# 5514

Perish he, how he decided!

# 5515

Again, perish he, how he decided!

# 5516

Then he looked;

# 5517

then frowned and scowled.

# 5518

Then he walked away disdainfully,

# 5519

saying, ‘It is nothing but traditional sorcery.

# 5520

It is nothing but the speech of a human.’

# 5521

Soon I will cast him into Saqar.

# 5522

And what will show you what is Saqar?

# 5523

It neither spares, nor leaves \[anything\].

# 5524

It burns the skin.

# 5525

There are nineteen \[keepers\] over it.

# 5526

We have assigned only angels as keepers of the Fire, and We have made their number merely a stumbling block for the faithless, and so that those who were given the Book may be reassured, and the faithful may increase in \[their\] faith, and so that those who were given the Book and the faithful may not be in doubt, and so that the faithless and those in whose hearts is a sickness may say, ‘What did Allah mean by this description?’ Thus does Allah lead astray whomever He wishes and guides whomever He wishes. No one knows the hosts of your Lord except Him, and it is just an admonition for all humans.

# 5527

No indeed! By the Moon!

# 5528

By the night when it recedes!

# 5529

By the dawn when it brightens!

# 5530

Indeed they are one of the greatest \[signs of God\]

# 5531

—a warner to all humans,

# 5532

\[alike\] for those of you who like to advance ahead and those who would remain behind.

# 5533

Every soul is hostage to what it has earned,

# 5534

except the People of the Right Hand.

# 5535

\[They will be\] in gardens, questioning

# 5536

the guilty:

# 5537

‘What drew you into Hell?’

# 5538

They will answer, ‘We were not among those who prayed.

# 5539

Nor did we feed the poor.

# 5540

We used to indulge in \[profane\] gossip along with the gossipers,

# 5541

and we used to deny the Day of Retribution

# 5542

until death came to us.’

# 5543

So the intercession of the intercessors will not avail them.

# 5544

What is the matter with them that they evade the Reminder

# 5545

as if they were terrified asses

# 5546

fleeing from a lion?

# 5547

But everyone of them desires to be given unrolled scriptures \[from Allah\]!

# 5548

No! Indeed, they do not fear the Hereafter.

# 5549

No! It is indeed a reminder.

# 5550

So let anyone who wishes be mindful of it.

# 5551

And they will not be mindful unless Allah wishes. He is worthy of \[your\] being wary \[of Him\] and He is worthy to forgive.

# 5552

I swear by the Day of Resurrection!

# 5553

And I swear by the self-critical soul!

# 5554

Does man suppose that We will not put together his bones \[at resurrection\]?

# 5555

Yes indeed, We are able to \[re\]shape \[even\] his fingertips!

# 5556

Indeed, man desires to go on living viciously.

# 5557

He asks, ‘When will be this “day of resurrection”?!’

# 5558

But when the eyes are dazzled,

# 5559

the moon is eclipsed,

# 5560

and the sun and the moon are brought together,

# 5561

that day man will say, ‘Where is the escape \[from this day\]?’

# 5562

No indeed! There will be no refuge!

# 5563

That day the \[final\] goal will be toward your Lord.

# 5564

That day man will be informed about what \[works\] he had sent ahead \[to the scene of judgement\] and \[the legacy that he had\] left behind.

# 5565

Indeed, man is a witness to himself,

# 5566

though he should offer excuses \[to justify his failings\].

# 5567

Do not move your tongue with it to hasten it.

# 5568

Indeed it is up to Us to put it together and to recite it.

# 5569

And when We have recited it, follow its recitation.

# 5570

Then, its exposition \[also\] lies with Us.

# 5571

No! Indeed, you love this transitory life

# 5572

and forsake the Hereafter.

# 5573

Some faces will be fresh on that day,

# 5574

looking to their Lord,

# 5575

and some faces will be scowling on that day,

# 5576

knowing that they will be dealt out a punishment breaking the spine.

# 5577

No indeed! When it reaches up to the collar bones

# 5578

and it is said, ‘Who will take him up?’

# 5579

and he knows that it is the \[time of\] parting,

# 5580

and each shank clasps the other shank,

# 5581

that day he shall be driven toward your Lord.

# 5582

He neither confirmed \[the messages of Allah\], nor did he pray,

# 5583

but denied \[them\] and turned away,

# 5584

and went back swaggering to his family.

# 5585

So, woe to you! Woe to you!

# 5586

Again, woe to you! Woe to you!

# 5587

Does man suppose that he has been abandoned to futility?

# 5588

Was he not a drop of emitted semen,

# 5589

and then a clinging mass? Whereat He created and proportioned \[him\],

# 5590

and made of him the two sexes, male and female.

# 5591

Is not \[someone like\] that able to revive the dead?

# 5592

Has there been a period of time for man when he was not anything worthy of mention?

# 5593

Indeed We created man from the drop of a mixed fluid so that We may put him to test, so We endowed with hearing and sight.

# 5594

Indeed We have guided him to the way, be he grateful or ungrateful.

# 5595

Indeed for the faithless We have prepared chains, iron collars, and a blaze.

# 5596

Indeed the pious will drink from a cup seasoned with Kafur,

# 5597

a spring where Allah’s servants will drink, making it gush forth as they please.

# 5598

They fulfill their vows and fear a day whose ill will be widespread.

# 5599

For the love of Him, they feed the needy, the orphan and the prisoner,

# 5600

\[saying,\] ‘We feed you only for the sake of Allah. We desire no reward from you, nor thanks.

# 5601

Indeed we fear a frowning and fateful day from our Lord.’

# 5602

So Allah saved them from that day’s ills and graced them with freshness \[on this faces\] and joy \[in their hearts\].

# 5603

He rewarded them for their patience with a garden and \[garments of\] silk,

# 5604

reclining therein on couches, without facing any \[scorching\] sun, or \[biting\] cold.

# 5605

Its shades will be close over them and its clusters \[of fruits\] will be hanging low.

# 5606

They will be served around with vessels of silver and goblets of crystal

# 5607

—crystal of silver— \[from\] which they will dispense in a precise measure.

# 5608

They will be served therein with a cup of a drink seasoned with Zanjabeel,

# 5609

from a spring in it named Salsabeel.

# 5610

They will be waited upon by immortal youths, whom, were you to see them, you will suppose them to be scattered pearls.

# 5611

As you look on, you will see there bliss and a great kingdom.

# 5612

Upon them will be cloaks of green silk and brocade and they will be adorned with bracelets of silver. Their Lord will give them to drink a pure drink.

# 5613

\[They will be told\]: ‘This is your reward, and your efforts have been well-appreciated.’

# 5614

Indeed We have sent down to you the Quran in a gradual descent.

# 5615

So submit patiently to the judgement of your Lord and do not obey any sinner or ingrate from among them,

# 5616

and celebrate the Name of your Lord morning and evening,

# 5617

and worship Him for a watch of the night and glorify Him the night long.

# 5618

Indeed they love this transitory life, and disregard a heavy day that is ahead of them.

# 5619

We created them and strengthened their joints, and We will replace them with others like them whenever We like.

# 5620

This is indeed a reminder. So let anyone who wishes take the way toward his Lord.

# 5621

But you will not wish unless it is willed by Allah. Indeed Allah is all-knowing, all-wise.

# 5622

He admits whomever He wishes into His mercy, and He has prepared a painful punishment for the wrongdoers.

# 5623

By the \[angelic\] emissaries sent successively,

# 5624

by those who sweep along like gale,

# 5625

by those who publish \[the Divine messages\] far and wide,

# 5626

by those who separate \[the truth from falsehood\] distinctly,

# 5627

by those who inspire \[God’s\] remembrance,

# 5628

as exemption or warning:

# 5629

what you are promised will surely befall.

# 5630

When the stars are blotted out

# 5631

and the sky is cleft,

# 5632

when the mountains are scattered \[like dust\]

# 5633

and time is set for the apostles \[to bear witness\]

# 5634

—for what day has \[all\] that been set \[to occur\]?

# 5635

For the Day of Judgement!

# 5636

And what will show you what is the Day of Judgement!?

# 5637

Woe to the deniers on that day!

# 5638

Did We not destroy the former generations,

# 5639

\[and\] then made the latter ones follow them?

# 5640

That is how We deal with the guilty.

# 5641

Woe to the deniers on that day!

# 5642

Have We not created you from a base fluid,

# 5643

\[and\] then lodged it in a secure abode

# 5644

until a known span \[of time\]?

# 5645

Then We determined; and how excellent determiners We are!

# 5646

Woe to the deniers on that day!

# 5647

Have We not made the earth a receptacle

# 5648

for the living and the dead,

# 5649

and set in it lofty \[and\] firm mountains, and given you agreeable water to drink?

# 5650

Woe to the deniers on that day!

# 5651

\[The faithless will be told:\] ‘Proceed toward what you used to deny!

# 5652

Proceed toward the triple-forked shadow,

# 5653

neither shady nor of any avail against the flames.

# 5654

Indeed it throws up \[giant\] sparks like castles,

# 5655

\[bright\] like yellow camels.

# 5656

Woe to the deniers on that day!

# 5657

This is a day wherein they will not speak,

# 5658

nor will they be permitted to offer excuses.

# 5659

Woe to the deniers on that day!

# 5660

‘This is the Day of Judgement. We have brought you together with the former generations.

# 5661

If you have any stratagems \[left\], try them out against Me!’

# 5662

Woe to the deniers on that day!

# 5663

Indeed the Godwary will be amid shades and springs

# 5664

and \[enjoying\] such fruits as they desire.

# 5665

\[They will be told:\] ‘Enjoy your food and drink, \[a reward\] for what you used to do.

# 5666

Thus do We reward the virtuous.’

# 5667

Woe to the deniers on that day!

# 5668

‘Eat and enjoy a little! You are indeed guilty.’

# 5669

Woe to the deniers on that day!

# 5670

When they are told, ‘Bow down \[in prayer\],’ they do not bow down!

# 5671

Woe to the deniers on that day!

# 5672

So what discourse will they believe after this?

# 5673

What is it that they are questioning each other about?!

# 5674

\[Is it\] about the Great Tiding,

# 5675

the one about which they differ?

# 5676

No indeed! Soon they will know!

# 5677

No indeed! Soon they will know for once again!

# 5678

Did We not make the earth a resting place?

# 5679

and the mountains stakes?

# 5680

and create you in pairs?

# 5681

and make your sleep for rest?

# 5682

and make the night a covering?

# 5683

and make the day for livelihood?

# 5684

and build above you the seven mighty heavens?

# 5685

and make \[the sun for\] a radiant lamp?

# 5686

and send down water pouring from the rain-clouds,

# 5687

that We may bring forth with it grains and plants,

# 5688

and luxuriant gardens?

# 5689

Indeed the Day of Judgement is the tryst,

# 5690

the day the Trumpet will be blown, and you will come in groups,

# 5691

and the sky will be opened and become gates,

# 5692

and the mountains will be set moving and become a mirage.

# 5693

Indeed hell is in ambush,

# 5694

a resort for the rebels,

# 5695

to reside therein for ages,

# 5696

tasting in it neither any coolness nor drink,

# 5697

except boiling water and pus,

# 5698

a fitting requital.

# 5699

Indeed they did not expect any reckoning,

# 5700

and they denied Our signs mendaciously,

# 5701

and We have figured everything in a Book.

# 5702

So \[now\] taste! We shall increase you in nothing but punishment!

# 5703

Indeed a triumph awaits the Godwary:

# 5704

gardens and vineyards,

# 5705

and buxom maidens of a like age,

# 5706

and brimming cups.

# 5707

Therein they shall hear neither vain talk nor lies

# 5708

—a reward and a sufficing bounty from your Lord,

# 5709

the All-beneficent, the Lord of the heavens and the earth and whatever is between them. They will not be able to address Him

# 5710

on the day when the Spirit and the angels stand in an array: none shall speak except someone who is permitted by the All-beneficent and says what is rightful.

# 5711

That day is true for certain. So let anyone who wishes take resort with his Lord.

# 5712

Indeed We have warned you of a punishment near at hand—the day when a person will observe what his hands have sent ahead and the faithless one will say, ‘I wish I were dust!’

# 5713

By those \[angels\] who wrest \[the soul\] violently,

# 5714

by those who draw \[it\] out gently,

# 5715

by those who swim smoothly,

# 5716

by those who, racing, take the lead,

# 5717

by those who direct the affairs \[of creatures\]:

# 5718

the day when the Quaker quakes

# 5719

and is followed by the Successor,

# 5720

hearts will be trembling on that day,

# 5721

bearing a humbled look.

# 5722

They will say, ‘Are we being returned to our earlier state?

# 5723

What, even after we have been decayed bones?!’

# 5724

They will say, ‘This is, then, a ruinous return!’

# 5725

Yet it will be only a single shout,

# 5726

and behold, they will be awake.

# 5727

Did you receive the story of Moses,

# 5728

when his Lord called out to him in the holy valley of Tuwa?

# 5729

\[And said,\] ‘Go to Pharaoh, for indeed he has rebelled,

# 5730

and say, ‘‘Would you purify yourself?

# 5731

I will guide you to your Lord, that you may fear \[Him\]?’’ ’

# 5732

Then he showed him the greatest sign.

# 5733

But he denied, and disobeyed.

# 5734

Then he turned back, walking swiftly,

# 5735

and gathered \[the people\] and proclaimed,

# 5736

saying, ‘I am your exalted lord!’

# 5737

So Allah seized him with the punishment of this life and the Hereafter.

# 5738

There is indeed a moral in that for someone who fears!

# 5739

Is your creation more prodigious or that of the heaven He has built?

# 5740

He raised its vault and fashioned it,

# 5741

and darkened its night, and brought forth its forenoon.

# 5742

Thereafter He spread out the earth,

# 5743

brought forth from it its water and pastures,

# 5744

setting firm the mountains,

# 5745

as a \[place of\] sustenance for you and your livestock.

# 5746

When the Greatest Catastrophe befalls

# 5747

—the day when man will remember his endeavours

# 5748

and hell is brought into view for those who can see—

# 5749

as for him who has been rebellious

# 5750

and preferred the life of this world,

# 5751

his refuge will indeed be hell.

# 5752

But as for him who is awed to stand before his Lord and restrains his soul from \[following\] desires,

# 5753

his refuge will indeed be paradise.

# 5754

They ask you concerning the Hour, “When will it set in,

# 5755

considering your frequent mention of it?”

# 5756

Its outcome is with your Lord.

# 5757

You are only a warner for those who are afraid it.

# 5758

The day they see it, it shall be as if they had not stayed \[in the world\] except for an evening or forenoon.

# 5759

He frowned and turned away

# 5760

when the blind man approached him.

# 5761

And how do you know, maybe he would purify himself,

# 5762

or take admonition, and the admonition would benefit him!

# 5763

But as for someone who is wealthy,

# 5764

you attend to him,

# 5765

though you are not liable if he does not purify himself.

# 5766

But as for someone who comes hurrying to you,

# 5767

while he fears \[Allah\],

# 5768

you are neglectful of him.

# 5769

No indeed! These \[verses of the Quran \] are a reminder

# 5770

—so let anyone who wishes remember—

# 5771

in honoured scriptures,

# 5772

exalted and purified,

# 5773

in the hands of envoys,

# 5774

noble and pious.

# 5775

Perish man! How ungrateful is he!

# 5776

From what did He create him?

# 5777

He created him from a drop of \[seminal\] fluid; then proportioned him.

# 5778

Then He made the way easy for him;

# 5779

then He made him die and buried him;

# 5780

and then, when He wished, resurrected him.

# 5781

No indeed! He has not yet carried out what He has commanded him.

# 5782

Let man consider his food:

# 5783

We pour down plenteous water \[from the sky\],

# 5784

then We split the earth making fissures in it

# 5785

and make the grain grow in it,

# 5786

as well as vines and vegetables,

# 5787

olives and date palms,

# 5788

and densely-planted gardens,

# 5789

fruits and pastures,

# 5790

as a sustenance for you and your livestock.

# 5791

So when the deafening Cry comes—

# 5792

the day when a man will evade his brother,

# 5793

his mother and his father,

# 5794

his spouse and his sons—

# 5795

each of them will have a task to keep him preoccupied on that day.

# 5796

Some faces will be bright on that day,

# 5797

laughing and joyous,

# 5798

and some faces on that day will be covered with dust,

# 5799

overcast with gloom.

# 5800

It is they who are the faithless, the vicious.

# 5801

When the sun is wound up,

# 5802

when the stars scatter,

# 5803

when the mountains are set moving,

# 5804

when the pregnant camels are neglected,

# 5805

when the wild beasts are mustered,

# 5806

when the seas are set afire,

# 5807

when the souls are assorted,

# 5808

when the girl buried-alive will be asked

# 5809

for what sin she was killed.

# 5810

When the records \[of deeds\] are unfolded,

# 5811

when the sky is stripped off,

# 5812

when hell is set ablaze,

# 5813

when paradise is brought near,

# 5814

then a soul shall know what it has readied \[for itself\].

# 5815

So I swear by the stars that return,

# 5816

the comets,

# 5817

by the night as it approaches,

# 5818

by the dawn as it breathes:

# 5819

it is indeed the speech of a noble apostle,

# 5820

powerful and eminent with the Lord of the Throne,

# 5821

one who is obeyed and is trustworthy as well.

# 5822

Your companion is not crazy:

# 5823

certainly he saw him on the manifest horizon,

# 5824

and he is not miserly concerning the Unseen.

# 5825

And it is not the speech of an outcast Satan.

# 5826

So where are you going?

# 5827

It is just a reminder for all the nations,

# 5828

for those of you who wish to walk straight;

# 5829

but you will not wish unless it is wished by Allah, the Lord of all the worlds.

# 5830

When the sky is rent apart,

# 5831

when the stars are scattered,

# 5832

when the seas are merged,

# 5833

when the graves are overturned,

# 5834

then a soul shall know what it has sent ahead and left behind.

# 5835

O man! What has deceived you about your generous Lord,

# 5836

who created you and proportioned you, and gave you an upright nature,

# 5837

and composed you in any form that He wished?

# 5838

No! Indeed, you deny the Retribution.

# 5839

Indeed, there are over you watchers,

# 5840

noble writers,

# 5841

who know whatever you do.

# 5842

Indeed the pious shall be amid bliss,

# 5843

and indeed the vicious shall be in hell,

# 5844

entering it on the Day of Retribution,

# 5845

and they shall not be absent from it.

# 5846

And what will show you what is the Day of Retribution?

# 5847

Again, what will show you what is the Day of Retribution?

# 5848

It is a day when no soul will be of any avail to another soul and all command that day will belong to Allah.

# 5849

Woe to the defrauders, who use short measures,

# 5850

who, when they measure \[a commodity bought\] from the people, take the full measure,

# 5851

but diminish when they measure or weigh for them.

# 5852

Do they not know that they will be resurrected

# 5853

on a tremendous day,

# 5854

a day when mankind will stand before the Lord of all the worlds?

# 5855

Indeed, the record of the vicious is in Sijjeen.

# 5856

And what will show you what is Sijjeen?

# 5857

It is a written record.

# 5858

Woe to the deniers on that day,

# 5859

who deny the Day of Retribution;

# 5860

and none denies it except every sinful transgressor.

# 5861

When Our signs are recited to him, he says, ‘Myths of the ancients!’

# 5862

No, that is not the case! Rather, their hearts have been sullied by what they have been earning.

# 5863

Indeed, they will be alienated from their Lord on that day.

# 5864

Afterward they will enter hell,

# 5865

then told, ‘This is what you used to deny!’

# 5866

Indeed, the record of the pious is in Illeeyun.

# 5867

And what will show you what is Illeeyun?

# 5868

It is a written record,

# 5869

witnessed by those brought near \[to Allah\].

# 5870

The pious shall be amid bliss,

# 5871

observing, \[as they recline\] on couches.

# 5872

You will perceive in their faces the freshness of bliss.

# 5873

They will be served with a sealed pure wine,

# 5874

whose seal is musk—for such let the viers vie—

# 5875

and whose seasoning is from Tasneem,

# 5876

a spring where those brought near \[to Allah\] drink.

# 5877

Indeed the guilty used to laugh at the faithful,

# 5878

and when they passed them by they would wink at each other,

# 5879

and when they returned to their folks they would return amused,

# 5880

and when they saw them they would say, ‘Indeed those are the astray!’

# 5881

Though they were not sent to watch over them.

# 5882

So today the faithful will laugh at the faithless,

# 5883

observing from their couches:

# 5884

Have the faithless been requited for what they used to do?

# 5885

When the sky is split open

# 5886

and gives ear to its Lord as it should.

# 5887

When the earth is spread out

# 5888

and throws out what is in it, emptying itself,

# 5889

and gives ear to its Lord as it should.

# 5890

O man! You are labouring toward your Lord laboriously, and you will encounter Him.

# 5891

Then, as for him who is given his record \[of deeds\] in his right hand,

# 5892

he will receive an easy reckoning,

# 5893

and he will return to his folks joyfully.

# 5894

But as for him who is given his record from behind his back,

# 5895

he will pray for annihilation

# 5896

and enter the Blaze.

# 5897

Indeed he used to be joyful among his folk,

# 5898

and he thought that he would never return.

# 5899

Yes, his Lord had been watching him.

# 5900

I swear by the evening glow,

# 5901

by the night and what it is fraught with,

# 5902

by the moon when it blooms full:

# 5903

you will surely fare from stage to stage.

# 5904

What is the matter with them that they will not believe,

# 5905

and will not prostrate when the Quran is recited to them?

# 5906

Indeed, the faithless impugn \[the Apostle\],

# 5907

and Allah knows best what they keep to themselves.

# 5908

So inform them of a painful punishment,

# 5909

excepting such as are faithful and do righteous deeds: for them there will be an everlasting reward.

# 5910

By the heaven with its Houses,

# 5911

by the Promised Day,

# 5912

by the Witness and the Witnessed:

# 5913

perish the People of the Ditch!

# 5914

The fire abounding in fuel,

# 5915

above which they sat

# 5916

as they were themselves witnesses to what they did to the faithful.

# 5917

They were vindictive towards them only because they had faith in Allah, the All-mighty and the All-laudable,

# 5918

to whom belongs the kingdom of the heavens and the earth, and Allah is witness to all things.

# 5919

Indeed those who persecute the faithful, men and women, and do not repent thereafter, there is the punishment of hell for them and the punishment of burning.

# 5920

Indeed those who have faith and do righteous deeds—for them will be gardens with streams running in them. That is the supreme success.

# 5921

Indeed your Lord’s striking is severe.

# 5922

It is indeed He who originates and brings back,

# 5923

and He is the All-forgiving, the All-affectionate,

# 5924

Lord of the Throne, the All-glorious,

# 5925

doer of what He desires.

# 5926

Did you receive the story of the hosts

# 5927

of Pharaoh and Thamud?

# 5928

Indeed the faithless dwell in denial,

# 5929

and Allah besieges them from all around.

# 5930

Indeed it is a glorious Quran,

# 5931

in a preserved tablet.

# 5932

By the heaven, and by the nightly visitor

# 5933

(and what will show you what is the nightly visitor?

# 5934

It is the brilliant star):

# 5935

there is a guard over every soul.

# 5936

So let man consider from what he was created.

# 5937

He was created from an effusing fluid

# 5938

which issues from between the loins and the breast-bones.

# 5939

Indeed He is able to bring him back \[after death\],

# 5940

on the day when the secrets are examined

# 5941

and he shall have neither power nor helper.

# 5942

By the resurgent heaven,

# 5943

and by the furrowed earth:

# 5944

it is indeed a conclusive discourse,

# 5945

and not a jest.

# 5946

Indeed they are devising a stratagem,

# 5947

and I \[too\] am devising a plan.

# 5948

So respite the faithless; give them a gentle respite.

# 5949

Celebrate the Name of your Lord, the Most Exalted,

# 5950

who created and proportioned,

# 5951

who determined and guided,

# 5952

who brought forth the pasture

# 5953

and then turned it into a black scum.

# 5954

We shall have you recite \[the Quran\], then you will not forget \[any of it\]

# 5955

except what Allah may wish. Indeed, He knows the open and what is hidden.

# 5956

And We shall ease you into facility.

# 5957

So admonish, for admonition is indeed beneficial:

# 5958

he who fears \[God\] will take admonition,

# 5959

and the most wretched will shun it

# 5960

—he who will enter the Great Fire,

# 5961

then he will neither live in it, nor die.

# 5962

‘Felicitous is he who purifies himself,

# 5963

celebrates the Name of his Lord, and prays.

# 5964

But you prefer the life of this world,

# 5965

while the Hereafter is better and more lasting.’

# 5966

This is indeed in the former scriptures,

# 5967

the scriptures of Abraham and Moses.

# 5968

Did you receive the account of the Enveloper?

# 5969

Some faces on that day will be humbled,

# 5970

wrought-up and weary:

# 5971

they will enter a scorching fire

# 5972

and made to drink from a boiling spring.

# 5973

They will have no food except cactus,

# 5974

neither nourishing, nor of avail against hunger.

# 5975

Some faces on that day will be joyous,

# 5976

pleased with their endeavour,

# 5977

in a lofty garden,

# 5978

where they will not hear any vain talk.

# 5979

In it is a flowing spring

# 5980

and raised couches,

# 5981

with goblets set,

# 5982

and cushions laid out in an array,

# 5983

and carpets spread out.

# 5984

Do they not observe the camel, \[to see\] how it has been created?

# 5985

and the sky, how it has been raised?

# 5986

and the mountains, how they have been set?

# 5987

and the earth, how it has been surfaced?

# 5988

So admonish—for you are only an admonisher,

# 5989

and not a taskmaster over them—

# 5990

except him who turns back and disbelieves.

# 5991

Him Allah will punish with the greatest punishment.

# 5992

Indeed to Us will be their return.

# 5993

Then, indeed, their reckoning will lie with Us.

# 5994

By the Dawn,

# 5995

by the ten nights,

# 5996

by the Even and the Odd,

# 5997

by the night when it departs!

# 5998

Is there an oath in that for one possessing intellect?

# 5999

Have you not regarded how your Lord dealt with \[the people of\] ‘Ad,

# 6000

\[and\] Iram, \[the city\] of the pillars,

# 6001

the like of which was not created among cities,

# 6002

and \[the people of\] Thamud, who hollowed out the rocks in the valley,

# 6003

and Pharaoh, the impaler

# 6004

—those who rebelled \[against Allah\] in their cities

# 6005

and caused much corruption in them,

# 6006

so your Lord poured on them lashes of punishment.

# 6007

Indeed your Lord is in ambush.

# 6008

As for man, whenever his Lord tests him, and grants him honour, and blesses him, he says, ‘My Lord has honoured me.’

# 6009

But when He tests him and tightens for him his provision, he says, ‘My Lord has humiliated me.’

# 6010

No indeed! No, you do not honour the orphan,

# 6011

and do not urge the feeding of the needy.

# 6012

You eat the inheritance rapaciously,

# 6013

and love wealth with much fondness.

# 6014

No indeed! When the earth is levelled to a plain,

# 6015

and your Lord \[’s edict\] arrives with the angels in ranks,

# 6016

the day when hell is brought \[near\], man will take admonition on that day, but what will that admonition avail him?

# 6017

He will say, ‘Alas, had I sent ahead for my life \[in the Hereafter\]!’

# 6018

On that day none shall punish as He punishes,

# 6019

and none shall bind as He binds.

# 6020

‘O soul at peace!

# 6021

Return to your Lord, pleased and pleasing!

# 6022

Then enter among My servants,

# 6023

and enter My paradise!’

# 6024

I swear by this town,

# 6025

as you reside in this town;

# 6026

\[and\] by the father and him whom he begot:

# 6027

certainly We created man in travail.

# 6028

Does he suppose that no one will ever have power over him?

# 6029

He says, ‘I have squandered immense wealth.’

# 6030

Does he suppose that no one sees him?

# 6031

Have We not made for him two eyes,

# 6032

a tongue, and two lips,

# 6033

and shown him the two paths \[of good and evil\]?

# 6034

Yet he has not embarked upon the uphill task.

# 6035

And what will show you what is the uphill task?

# 6036

\[It is\] the freeing of a slave,

# 6037

or feeding, during days of \[general\] starvation,

# 6038

an orphan among relatives

# 6039

or a needy man in desolation,

# 6040

while being one of those who have faith and enjoin one another to patience, and enjoin one another to compassion.

# 6041

They are the People of the Right Hand.

# 6042

But those who defy Our signs, they are the People of the Left Hand.

# 6043

A closed Fire will be \[imposed\] upon them.

# 6044

By the sun and her forenoon splendour,

# 6045

by the moon when he follows her,

# 6046

by the day when it reveals her,

# 6047

by the night when it covers her,

# 6048

by the sky and Him who built it,

# 6049

by the earth and Him who spread it,

# 6050

by the soul and Him who fashioned it,

# 6051

and inspired it with \[discernment between\] its virtues and vices:

# 6052

one who purifies it is felicitous,

# 6053

and one who betrays it fails.

# 6054

The \[people of\] Thamud denied \[Allah’s signs\] out of their rebellion,

# 6055

when the most wretched of them rose up.

# 6056

The apostle of Allah had told them, ‘This is Allah’s she-camel, let her drink!’

# 6057

But they impugned him and hamstrung her. So their Lord took them unawares by night because of their sin, and levelled it.

# 6058

And He does not fear its outcome.

# 6059

By the night when it envelops,

# 6060

by the day when it brightens,

# 6061

by Him who created the male and the female:

# 6062

your endeavours are indeed diverse.

# 6063

As for him who gives and is Godwary

# 6064

and confirms the best promise,

# 6065

We will surely ease him toward facility.

# 6066

But as for him, who is stingy and self-complacent,

# 6067

and denies the best promise,

# 6068

We will surely ease him toward hardship.

# 6069

His wealth will not avail him when he perishes.

# 6070

Indeed guidance rests with Us,

# 6071

and to Us belong the world and the Hereafter.

# 6072

So I warn you of a blazing fire,

# 6073

which none shall enter except the most wretched \[of persons\]

# 6074

—he who impugns \[God’s prophets\] and turns his back.

# 6075

The Godwary \[person\] will be spared of that

# 6076

—he who gives his wealth to purify himself

# 6077

and does not expect any reward from anyone,

# 6078

but seek only the pleasure of their Lord, the Most Exalted,

# 6079

and, surely, soon they will be well-pleased.

# 6080

By the morning brightness,

# 6081

and by the night when it is calm!

# 6082

Your Lord has neither forsaken you, nor is He displeased with you,

# 6083

and the Hereafter shall be better for you than the world.

# 6084

Soon your Lord will give you \[that with which\] you will be pleased.

# 6085

Did He not find you an orphan, and shelter you?

# 6086

Did He not find you astray, and guide you?

# 6087

Did He not find you needy, and enrich you?

# 6088

So, as for the orphan, do not oppress him;

# 6089

and as for the beggar, do not chide him;

# 6090

and as for your Lord’s blessing, proclaim it!

# 6091

Did We not open your breast for you

# 6092

and relieve you of your burden

# 6093

which \[almost\] broke your back?

# 6094

Did We not exalt your name?

# 6095

Indeed ease accompanies hardship.

# 6096

Indeed ease accompanies hardship.

# 6097

So when you are done, appoint,

# 6098

and supplicate your Lord.

# 6099

By the fig and the olive,

# 6100

by Mount Sinai,

# 6101

and by this secure town:

# 6102

We certainly created man in the best of forms;

# 6103

then We relegated him to the lowest of the low,

# 6104

except those who have faith and do righteous deeds. There will be an everlasting reward for them.

# 6105

So what makes you deny the Retribution?

# 6106

Is not Allah the fairest of all judges?

# 6107

Read in the Name of your Lord who created;

# 6108

created man from a clinging mass.

# 6109

Read, and your Lord is the most generous,

# 6110

who taught by the pen,

# 6111

taught man what he did not know.

# 6112

Indeed man becomes rebellious

# 6113

when he considers himself without need.

# 6114

Indeed to your Lord is the return.

# 6115

Tell me, he who forbids

# 6116

a servant when he prays,

# 6117

tell me, should he be on \[true\] guidance,

# 6118

or bid \[others\] to Godwariness,

# 6119

tell me, should he call him a liar and turn away

# 6120

—does he not know that Allah sees \[him\]?

# 6121

No indeed! If he does not cease, We shall seize him by the forelock,

# 6122

a lying, sinful forelock!

# 6123

Then let him call out his gang!

# 6124

We \[too\] shall call the keepers of hell.

# 6125

No indeed! Do not obey him, but prostrate and draw near \[to Allah\]!

# 6126

Indeed We sent it down on the Night of Ordainment.

# 6127

And what will show you what is the Night of Ordainment?

# 6128

The Night of Ordainment is better than a thousand months.

# 6129

In it the angels and the Spirit descend, by the leave of their Lord, with every command.

# 6130

It is peaceful until the rising of the dawn.

# 6131

The faithless from among the People of the Book and the polytheists were not set apart \[from the community of the faithful\] until the proof had come to them:

# 6132

an apostle from Allah reciting impeccable scriptures,

# 6133

wherein are upright writings.

# 6134

Those who were given the Book did not divide except after the proof had come to them.

# 6135

Though they were not commanded except to worship Allah, dedicating their faith to Him as men of pure faith, and to maintain the prayer and pay the zakat. That is the upright religion.

# 6136

Indeed the faithless from among the People of the Book and the polytheists will be in the fire of hell, to remain in it \[forever\]. It is they who are the worst of creatures.

# 6137

Indeed those who have faith and do righteous deeds—it is they who are the best of creatures.

# 6138

Their reward, near their Lord, is the Gardens of Eden, with streams running in them, to remain in them forever. Allah is pleased with them, and they are pleased with Him. That is for those who fear their Lord.

# 6139

When the earth is rocked with a terrible quake

# 6140

and discharges its burdens,

# 6141

and man says, ‘What is the matter with her?’

# 6142

On that day she will relate her chronicles

# 6143

for her Lord will have inspired her.

# 6144

On that day, mankind will issue forth in various groups to be shown their deeds.

# 6145

So whoever does an atom’s weight of good will see it,

# 6146

and whoever does an atom’s weight of evil will see it.

# 6147

By the snorting chargers,

# 6148

by the strikers of sparks \[with their hoofs\],

# 6149

by the raiders at dawn,

# 6150

raising therein a trail of dust,

# 6151

and cleaving therein a host!

# 6152

Indeed man is ungrateful to his Lord,

# 6153

and indeed he is \[himself\] witness to that!

# 6154

And indeed he is an avid lover of wealth.

# 6155

Does he not know, when what is \[buried\] in the graves is turned over,

# 6156

and what is \[concealed\] in the breasts is divulged,

# 6157

on that day their Lord will be well informed about them \[and their deeds\]?

# 6158

The Catastrophe!

# 6159

What is the Catastrophe?

# 6160

What will show you what is the Catastrophe?

# 6161

\[It is\] the day when mankind will be like scattered moths

# 6162

and the mountains like carded wool.

# 6163

As for him, whose deeds weigh heavy in the scales,

# 6164

he will have a pleasing life.

# 6165

But as for him, whose deeds weigh light in the scales,

# 6166

his home will be the Abyss.

# 6167

And what will show you what it is?

# 6168

It is a scorching fire!

# 6169

Rivalry \[and vainglory\] distracted you

# 6170

until you visited \[even\] the graves.

# 6171

No indeed, soon you will know!

# 6172

No indeed, soon you will know for yet another time!

# 6173

Indeed, were you to know with certain knowledge,

# 6174

you would have surely seen hell \[in this very life\].

# 6175

Afterward you will surely see it with the eye of certainty.

# 6176

Then, on that day, you will surely be questioned concerning the Blessing.

# 6177

By Time!

# 6178

Man is indeed in loss,

# 6179

except those who have faith and do righteous deeds, and enjoin one another to \[follow\] the truth, and enjoin one another to patience.

# 6180

Woe to every scandal-monger and slanderer,

# 6181

who amasses wealth and counts it over.

# 6182

He supposes his wealth will make him immortal!

# 6183

No indeed! He will surely be cast into the Crusher.

# 6184

And what will show you what is the Crusher?

# 6185

\[It is\] the fire of Allah, set ablaze,

# 6186

which will overspread the hearts.

# 6187

Indeed it will close in upon them

# 6188

in outstretched columns.

# 6189

Have you not regarded how your Lord dealt with the army of the elephants?

# 6190

Did He not make their stratagems go awry,

# 6191

and send against them flocks of birds

# 6192

pelting them with stones of shale,

# 6193

thus making them like chewed-up straw?

# 6194

\[In gratitude\] for solidarity among the Quraysh,

# 6195

their solidarity during winter and summer journeys,

# 6196

let them worship the Lord of this House,

# 6197

who has fed them \[and saved them\] from hunger, and secured them from fear.

# 6198

Did you see him who denies the Retribution?

# 6199

That is the one, who drives away the orphan,

# 6200

and does not urge the feeding of the needy.

# 6201

Woe to those who pray

# 6202

but are heedless of their prayers

# 6203

—who show off

# 6204

but deny aid.

# 6205

Indeed We have given you abundance.

# 6206

So pray to your Lord, and sacrifice \[the sacrificial camel\].

# 6207

Indeed it is your enemy who is without posterity.

# 6208

Say, ‘O faithless ones!

# 6209

I do not worship what you worship,

# 6210

nor do you worship what I worship;

# 6211

nor will I worship what you have worshipped,

# 6212

nor will you worship what I worship.

# 6213

To you your religion, and to me my religion.’

# 6214

When Allah’s help comes with victory,

# 6215

and you see the people entering Allah’s religion in throngs,

# 6216

celebrate the praise of your Lord, and plead to Him for forgiveness. Indeed, He is all-clement.

# 6217

Perish the hands of Abu Lahab, and perish he!

# 6218

Neither his wealth availed him, nor what he had earned.

# 6219

Soon he will enter the blazing fire,

# 6220

and his wife \[too\], the firewood carrier,

# 6221

with a rope of palm fibre around her neck.

# 6222

Say, ‘He is Allah, the One.

# 6223

Allah is the All-embracing.

# 6224

He neither begat, nor was begotten,

# 6225

nor has He any equal.’

# 6226

Say, ‘I seek the protection of the Lord of the daybreak

# 6227

from the evil of what He has created,

# 6228

and from the evil of the dark night when it falls,

# 6229

and from the evil of the witches, who blow on knots,

# 6230

and from the evil of the envious one when he envies.’

# 6231

Say, ‘I seek the protection of the Lord of humans,

# 6232

Sovereign of humans,

# 6233

God of humans,

# 6234

from the evil of the sneaky tempter

# 6235

who puts temptations into the breasts of humans,

# 6236

from among the jinn and humans.’

